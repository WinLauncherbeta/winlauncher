package com.example.winlauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppItem(val label: String, val icon: Drawable, val cn: ComponentName)

class Tile(
    val label: String,
    val icon: Int,
    val closes: Boolean,
    val active: () -> Boolean,
    val click: () -> Unit
) {
    var view: LinearLayout? = null
    var iconView: ImageView? = null
    var textView: TextView? = null
}

@Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
class MainActivity : Activity() {

    companion object {
        const val REQ_WP = 11
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var prefs: SharedPreferences
    private val ptBR = Locale("pt", "BR")

    private val cPanel = Color.parseColor("#F2202020")
    private val cTaskbar = Color.parseColor("#E61C1C1C")
    private val cTile = Color.parseColor("#26FFFFFF")
    private val cAccent = Color.parseColor("#4CC2FF")
    private val cSub = Color.parseColor("#B3FFFFFF")

    private lateinit var root: FrameLayout
    private lateinit var wallpaperHost: FrameLayout
    private lateinit var desktopFrame: FrameLayout
    private lateinit var desktopGrid: GridView
    private lateinit var desktopAdapter: AppAdapter
    private lateinit var overlay: FrameLayout

    private lateinit var taskbar: FrameLayout
    private lateinit var pinnedRow: LinearLayout
    private lateinit var startBtn: ImageView
    private lateinit var wifiIcon: ImageView
    private lateinit var volIcon: ImageView
    private lateinit var batIcon: ImageView

    private lateinit var startPanel: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var pinnedStart: LinearLayout
    private lateinit var startGrid: GridView
    private lateinit var startAdapter: AppAdapter

    private lateinit var quickPanel: LinearLayout
    private lateinit var brightSeek: SeekBar
    private lateinit var volSeek: SeekBar
    private lateinit var batText: TextView
    private val tiles = ArrayList<Tile>()

    private lateinit var calPanel: LinearLayout
    private lateinit var calDate: TextView
    private lateinit var calTitle: TextView
    private lateinit var calGrid: GridLayout
    private val calShown: Calendar = Calendar.getInstance()

    private var allApps: List<AppItem> = emptyList()
    private var video: VideoView? = null
    private var anim: AnimatedImageDrawable? = null
    private var torchOn = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps { onAppsLoaded() }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val screenW: Int
        get() = resources.displayMetrics.widthPixels

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun rip(color: Int, r: Int): RippleDrawable =
        RippleDrawable(
            ColorStateList.valueOf(Color.parseColor("#44FFFFFF")),
            rounded(color, r),
            rounded(Color.WHITE, r)
        )

    private fun panelW(): Int = minOf(dp(360), screenW - dp(16))

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun ic(a: AppItem): Drawable = a.icon.constantState?.newDrawable(resources) ?: a.icon

    private fun lpTop(m: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(m)
        return lp
    }

    private fun sectionLabel(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun iconBtn(res: Int, onClick: () -> Unit): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(res)
        iv.setPadding(dp(10), dp(10), dp(10), dp(10))
        iv.background = rip(Color.TRANSPARENT, 8)
        iv.setOnClickListener { onClick() }
        return iv
    }

    private fun getList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("|").filter { it.isNotEmpty() }

    private fun setList(k: String, l: List<String>) {
        prefs.edit().putString(k, l.joinToString("|")).apply()
    }

    private fun appFor(key: String): AppItem? =
        allApps.firstOrNull { it.cn.flattenToString() == key }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Não foi possível abrir")
        }
        closeAll()
    }

    private fun launch(cn: ComponentName) {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        i.component = cn
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(i)
    }

    // -------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("win", MODE_PRIVATE)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        applyWallpaper()

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addDataScheme("package")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, f)
        }

        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                    if (quickPanel.visibility == View.VISIBLE) refreshTiles()
                }
            }, null)
        } catch (e: Exception) {
        }

        loadApps { onAppsLoaded() }
    }

    override fun onResume() {
        super.onResume()
        video?.let { if (!it.isPlaying) it.start() }
        anim?.start()
        updateTray()
    }

    override fun onPause() {
        super.onPause()
        video?.pause()
        anim?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeAll()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay.visibility == View.VISIBLE) closeAll()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_WP && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            val type = contentResolver.getType(uri) ?: ""
            prefs.edit()
                .putString("wp", uri.toString())
                .putBoolean("wpVideo", type.startsWith("video/"))
                .apply()
            applyWallpaper()
        }
    }

    // ------------------------------------------------------------------- apps

    private fun loadApps(after: () -> Unit) {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN)
            q.addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(
                        ri.loadLabel(pm).toString(),
                        ri.loadIcon(pm),
                        ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                after()
            }
        }.start()
    }

    private fun initDefaults() {
        if (prefs.getBoolean("init", false)) return
        val pk = listOf(
            "com.android.chrome",
            "com.sec.android.app.sbrowser",
            "com.android.vending",
            "com.samsung.android.dialer",
            "com.sec.android.app.camera",
            "com.sec.android.gallery3d",
            "com.sec.android.app.myfiles",
            "com.android.settings"
        )
        val cns = pk.mapNotNull { packageManager.getLaunchIntentForPackage(it)?.component?.flattenToString() }
        setList("tb", cns)
        setList("st", cns)
        prefs.edit().putBoolean("init", true).apply()
    }

    private fun onAppsLoaded() {
        initDefaults()
        refreshPins()
        filterApps(searchBox.text?.toString() ?: "")
    }

    private fun refreshPins() {
        rebuildTaskbar()
        rebuildStartPinned()
        rebuildDesktop()
    }

    private fun filterApps(q: String) {
        startAdapter.items = if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, true) }
        startAdapter.notifyDataSetChanged()
    }

    private fun toggle(k: String, v: String) {
        val l = getList(k).toMutableList()
        if (!l.remove(v)) l.add(v)
        setList(k, l)
        refreshPins()
    }

    private fun appMenu(app: AppItem) {
        val key = app.cn.flattenToString()
        val tb = getList("tb")
        val st = getList("st")
        val dk = getList("dk")
        val labels = arrayOf(
            if (key in tb) "Desafixar da barra de tarefas" else "Fixar na barra de tarefas",
            if (key in st) "Desafixar do Iniciar" else "Fixar no Iniciar",
            if (key in dk) "Remover da área de trabalho" else "Adicionar à área de trabalho",
            "Informações do app",
            "Desinstalar"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(app.label)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> toggle("tb", key)
                    1 -> toggle("st", key)
                    2 -> toggle("dk", key)
                    3 -> safeStart(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + app.cn.packageName)
                        )
                    )
                    4 -> safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.cn.packageName)))
                }
            }
            .show()
    }

    // -------------------------------------------------------------- wallpaper

    private fun pickWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*"))
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_WP)
        } catch (e: Exception) {
            toast("Nenhum seletor de arquivos encontrado")
        }
    }

    private fun desktopMenu() {
        val labels = arrayOf(
            "Trocar wallpaper (vídeo, GIF ou imagem)",
            "Voltar ao wallpaper padrão",
            "Configurações do Android"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Área de trabalho")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> pickWallpaper()
                    1 -> {
                        prefs.edit().remove("wp").remove("wpVideo").apply()
                        applyWallpaper()
                    }
                    2 -> safeStart(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .show()
    }

    private fun applyWallpaper() {
        wallpaperHost.removeAllViews()
        video = null
        anim?.stop()
        anim = null
        wallpaperHost.background = null

        val s = prefs.getString("wp", null)
        if (s == null) {
            wallpaperHost.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#0B1E3F"),
                    Color.parseColor("#1B5FD0"),
                    Color.parseColor("#0A2A66")
                )
            )
            return
        }
        val uri = Uri.parse(s)
        try {
            if (prefs.getBoolean("wpVideo", false)) {
                val v = VideoView(this)
                wallpaperHost.addView(v, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
                v.setAudioFocusRequest(AudioManager.AUDIOFOCUS_NONE)
                v.setOnPreparedListener { mp ->
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    val vw = mp.videoWidth
                    val vh = mp.videoHeight
                    val w = wallpaperHost.width
                    val h = wallpaperHost.height
                    if (vw > 0 && vh > 0 && w > 0 && h > 0) {
                        val sc = maxOf(w.toFloat() / vw, h.toFloat() / vh)
                        v.layoutParams = FrameLayout.LayoutParams(
                            (vw * sc).toInt(),
                            (vh * sc).toInt(),
                            Gravity.CENTER
                        )
                    }
                    v.start()
                }
                v.setOnErrorListener { _, _, _ -> true }
                v.setVideoURI(uri)
                video = v
            } else {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                wallpaperHost.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
                if (Build.VERSION.SDK_INT >= 28) {
                    val src = ImageDecoder.createSource(contentResolver, uri)
                    val dm = resources.displayMetrics
                    val d = ImageDecoder.decodeDrawable(src) { decoder, info, _ ->
                        val sc = maxOf(
                            dm.widthPixels.toFloat() / info.size.width,
                            dm.heightPixels.toFloat() / info.size.height
                        )
                        if (sc < 1f) {
                            decoder.setTargetSize(
                                (info.size.width * sc).toInt(),
                                (info.size.height * sc).toInt()
                            )
                        }
                    }
                    iv.setImageDrawable(d)
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                        anim = d
                    }
                } else {
                    iv.setImageURI(uri)
                }
            }
        } catch (e: Exception) {
            toast("Não consegui abrir o wallpaper")
        }
    }

    // --------------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        wallpaperHost = FrameLayout(this)
        root.addView(wallpaperHost, FrameLayout.LayoutParams(MATCH, MATCH))

        val ui = LinearLayout(this)
        ui.orientation = LinearLayout.VERTICAL
        root.addView(ui, FrameLayout.LayoutParams(MATCH, MATCH))

        desktopFrame = FrameLayout(this)
        ui.addView(desktopFrame, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val catcher = View(this)
        catcher.setOnLongClickListener {
            desktopMenu()
            true
        }
        desktopFrame.addView(catcher, FrameLayout.LayoutParams(MATCH, MATCH))

        desktopGrid = GridView(this)
        desktopGrid.numColumns = maxOf(3, screenW / dp(84))
        desktopGrid.setPadding(dp(8), dp(12), dp(8), dp(8))
        desktopGrid.setSelector(ColorDrawable(Color.TRANSPARENT))
        desktopGrid.verticalSpacing = dp(8)
        desktopAdapter = AppAdapter(emptyList(), 44, 11f)
        desktopGrid.adapter = desktopAdapter
        desktopGrid.setOnItemClickListener { _, _, pos, _ -> launch(desktopAdapter.items[pos].cn) }
        desktopGrid.setOnItemLongClickListener { _, _, pos, _ ->
            appMenu(desktopAdapter.items[pos])
            true
        }
        desktopFrame.addView(desktopGrid, FrameLayout.LayoutParams(MATCH, WRAP))

        overlay = FrameLayout(this)
        overlay.visibility = View.GONE
        overlay.setOnClickListener { closeAll() }
        desktopFrame.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        buildStartPanel()
        buildQuickPanel()
        buildCalPanel()
        buildTaskbar()
        ui.addView(taskbar, LinearLayout.LayoutParams(MATCH, WRAP))

        root.setOnApplyWindowInsetsListener { _, ins ->
            taskbar.setPadding(0, 0, 0, ins.systemWindowInsetBottom)
            ui.setPadding(0, ins.systemWindowInsetTop, 0, 0)
            ins
        }
        setContentView(root)
        rebuildTaskbar()
    }

    private fun buildTaskbar() {
        taskbar = FrameLayout(this)
        taskbar.setBackgroundColor(cTaskbar)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        taskbar.addView(row, FrameLayout.LayoutParams(MATCH, dp(48)))

        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        startBtn = ImageView(this)
        startBtn.setImageResource(R.drawable.ic_start)
        startBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        startBtn.background = rip(Color.TRANSPARENT, 6)
        startBtn.setOnClickListener {
            if (startPanel.visibility == View.VISIBLE) closeAll() else openStart()
        }

        pinnedRow = LinearLayout(this)
        pinnedRow.orientation = LinearLayout.HORIZONTAL
        pinnedRow.gravity = Gravity.CENTER_VERTICAL
        row.addView(pinnedRow, LinearLayout.LayoutParams(WRAP, MATCH))

        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        wifiIcon = ImageView(this)
        wifiIcon.setImageResource(R.drawable.ic_wifi)
        volIcon = ImageView(this)
        volIcon.setImageResource(R.drawable.ic_volume)
        batIcon = ImageView(this)
        batIcon.setImageResource(R.drawable.ic_battery)

        val tray = LinearLayout(this)
        tray.orientation = LinearLayout.HORIZONTAL
        tray.gravity = Gravity.CENTER_VERTICAL
        tray.background = rip(Color.TRANSPARENT, 6)
        tray.setPadding(dp(4), 0, dp(4), 0)
        tray.setOnClickListener { showPanel(quickPanel) }
        for (iv in listOf(wifiIcon, volIcon, batIcon)) {
            val lp = LinearLayout.LayoutParams(dp(16), dp(16))
            lp.setMargins(dp(5), 0, dp(5), 0)
            tray.addView(iv, lp)
        }
        row.addView(tray, LinearLayout.LayoutParams(WRAP, dp(40)))

        val clock = TextClock(this)
        clock.format12Hour = "HH:mm\ndd/MM/yyyy"
        clock.format24Hour = "HH:mm\ndd/MM/yyyy"
        clock.setTextColor(Color.WHITE)
        clock.textSize = 11f
        clock.gravity = Gravity.CENTER
        clock.setPadding(dp(8), 0, dp(8), 0)
        clock.background = rip(Color.TRANSPARENT, 6)
        clock.setOnClickListener { showPanel(calPanel) }
        val clp = LinearLayout.LayoutParams(WRAP, dp(40))
        clp.rightMargin = dp(4)
        row.addView(clock, clp)
    }

    private fun rebuildTaskbar() {
        pinnedRow.removeAllViews()
        pinnedRow.addView(startBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        val slots = ((screenW - dp(150)) / dp(44)) - 1
        val apps = getList("tb").mapNotNull { appFor(it) }.take(maxOf(0, slots))
        for (a in apps) {
            val iv = ImageView(this)
            iv.setImageDrawable(ic(a))
            iv.setPadding(dp(8), dp(8), dp(8), dp(8))
            iv.background = rip(Color.TRANSPARENT, 6)
            iv.setOnClickListener { launch(a.cn) }
            iv.setOnLongClickListener {
                appMenu(a)
                true
            }
            pinnedRow.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
    }

    private fun rebuildDesktop() {
        desktopAdapter.items = getList("dk").mapNotNull { appFor(it) }
        desktopAdapter.notifyDataSetChanged()
    }

    private fun rebuildStartPinned() {
        pinnedStart.removeAllViews()
        val apps = getList("st").mapNotNull { appFor(it) }
        if (apps.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Nenhum app fixado. Segure um app abaixo para fixar."
            tv.setTextColor(cSub)
            tv.textSize = 12f
            tv.setPadding(0, dp(12), 0, dp(12))
            pinnedStart.addView(tv)
            return
        }
        for (a in apps) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(dp(4), dp(8), dp(4), dp(8))
            col.background = rip(Color.TRANSPARENT, 8)
            val iv = ImageView(this)
            iv.setImageDrawable(ic(a))
            col.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
            val tv = TextView(this)
            tv.text = a.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            val tlp = LinearLayout.LayoutParams(MATCH, WRAP)
            tlp.topMargin = dp(4)
            col.addView(tv, tlp)
            col.setOnClickListener { launch(a.cn) }
            col.setOnLongClickListener {
                appMenu(a)
                true
            }
            pinnedStart.addView(col, LinearLayout.LayoutParams(dp(72), WRAP))
        }
    }

    private fun buildStartPanel() {
        val h = minOf(dp(540), (resources.displayMetrics.heightPixels * 0.72f).toInt())
        startPanel = LinearLayout(this)
        startPanel.orientation = LinearLayout.VERTICAL
        startPanel.background = rounded(cPanel, 12)
        startPanel.setPadding(dp(16), dp(16), dp(16), dp(8))
        startPanel.visibility = View.GONE
        startPanel.isClickable = true
        startPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), h, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = dp(8)
        overlay.addView(startPanel, lp)

        searchBox = EditText(this)
        searchBox.hint = "Digite aqui para pesquisar"
        searchBox.setHintTextColor(cSub)
        searchBox.setTextColor(Color.WHITE)
        searchBox.textSize = 14f
        searchBox.background = rounded(cTile, 20)
        searchBox.setPadding(dp(14), 0, dp(14), 0)
        searchBox.setSingleLine(true)
        searchBox.imeOptions = EditorInfo.IME_ACTION_DONE
        searchBox.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        searchBox.compoundDrawablePadding = dp(8)
        startPanel.addView(searchBox, LinearLayout.LayoutParams(MATCH, dp(40)))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        searchBox.setOnEditorActionListener { _, _, _ ->
            startAdapter.items.firstOrNull()?.let { launch(it.cn) }
            true
        }

        startPanel.addView(sectionLabel("Fixados"), lpTop(12))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        pinnedStart = LinearLayout(this)
        pinnedStart.orientation = LinearLayout.HORIZONTAL
        hs.addView(pinnedStart)
        startPanel.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP))

        startPanel.addView(sectionLabel("Todos os aplicativos"), lpTop(8))
        startAdapter = AppAdapter(emptyList(), 40, 11f)
        startGrid = GridView(this)
        startGrid.numColumns = 4
        startGrid.setSelector(ColorDrawable(Color.TRANSPARENT))
        startGrid.isVerticalScrollBarEnabled = false
        startGrid.adapter = startAdapter
        startGrid.setOnItemClickListener { _, _, pos, _ -> launch(startAdapter.items[pos].cn) }
        startGrid.setOnItemLongClickListener { _, _, pos, _ ->
            appMenu(startAdapter.items[pos])
            true
        }
        startPanel.addView(startGrid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val line = View(this)
        line.setBackgroundColor(Color.parseColor("#22FFFFFF"))
        val llp = LinearLayout.LayoutParams(MATCH, dp(1))
        llp.topMargin = dp(4)
        startPanel.addView(line, llp)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL

        val avatar = TextView(this)
        avatar.text = "U"
        avatar.gravity = Gravity.CENTER
        avatar.setTextColor(Color.BLACK)
        avatar.textSize = 13f
        avatar.typeface = Typeface.DEFAULT_BOLD
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(cAccent)
        avatar.background = oval
        bar.addView(avatar, LinearLayout.LayoutParams(dp(30), dp(30)))

        val name = TextView(this)
        name.text = "Usuário"
        name.setTextColor(Color.WHITE)
        name.textSize = 13f
        val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        nlp.leftMargin = dp(10)
        bar.addView(name, nlp)

        bar.addView(
            iconBtn(R.drawable.ic_image) {
                closeAll()
                pickWallpaper()
            },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        bar.addView(
            iconBtn(R.drawable.ic_settings) { safeStart(Intent(Settings.ACTION_SETTINGS)) },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        startPanel.addView(bar, LinearLayout.LayoutParams(MATCH, dp(44)))
    }

    private fun sliderRow(icon: Int, seek: SeekBar): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.setImageResource(icon)
        row.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = dp(8)
        row.addView(seek, lp)
        return row
    }

    private fun buildQuickPanel() {
        quickPanel = LinearLayout(this)
        quickPanel.orientation = LinearLayout.VERTICAL
        quickPanel.background = rounded(cPanel, 12)
        quickPanel.setPadding(dp(16), dp(16), dp(16), dp(12))
        quickPanel.visibility = View.GONE
        quickPanel.isClickable = true
        quickPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(quickPanel, lp)

        tiles.clear()
        tiles.add(Tile("Wi-Fi", R.drawable.ic_wifi, true, { wifiOn() }, {
            if (Build.VERSION.SDK_INT >= 29) {
                safeStart(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            } else {
                safeStart(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        }))
        tiles.add(Tile("Bluetooth", R.drawable.ic_bluetooth, true, { btOn() }, {
            safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }))
        tiles.add(Tile("Modo avião", R.drawable.ic_airplane, true, {
            Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        }, {
            safeStart(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
        }))
        tiles.add(Tile("Lanterna", R.drawable.ic_flashlight, false, { torchOn }, { toggleTorch() }))
        tiles.add(Tile("Rotação", R.drawable.ic_rotate, false, {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        }, { toggleRotation() }))
        tiles.add(Tile("Economia", R.drawable.ic_battery, true, {
            (getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        }, {
            safeStart(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }))
        tiles.add(Tile("Não perturbe", R.drawable.ic_moon, true, {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
        }, {
            safeStart(Intent(Settings.ACTION_SOUND_SETTINGS))
        }))
        tiles.add(Tile("Localização", R.drawable.ic_location, true, {
            Build.VERSION.SDK_INT >= 28 &&
                (getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
        }, {
            safeStart(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }))
        tiles.add(Tile("Hotspot", R.drawable.ic_hotspot, true, { false }, {
            safeStart(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }))

        val tw = (panelW() - dp(32)) / 3 - dp(8)
        val g = GridLayout(this)
        g.columnCount = 3
        for (t in tiles) {
            val v = LinearLayout(this)
            v.orientation = LinearLayout.VERTICAL
            v.gravity = Gravity.CENTER
            v.setOnClickListener {
                t.click()
                if (t.closes) closeAll() else refreshQuick()
            }
            val iv = ImageView(this)
            iv.setImageResource(t.icon)
            val tv = TextView(this)
            tv.text = t.label
            tv.textSize = 11f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            v.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tlp = LinearLayout.LayoutParams(WRAP, WRAP)
            tlp.topMargin = dp(4)
            v.addView(tv, tlp)
            t.view = v
            t.iconView = iv
            t.textView = tv
            val glp = GridLayout.LayoutParams()
            glp.width = tw
            glp.height = dp(64)
            glp.setMargins(dp(4), dp(4), dp(4), dp(4))
            g.addView(v, glp)
        }
        quickPanel.addView(g, LinearLayout.LayoutParams(MATCH, WRAP))

        brightSeek = SeekBar(this)
        brightSeek.max = 255
        brightSeek.progressTintList = ColorStateList.valueOf(cAccent)
        brightSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        brightSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (Settings.System.canWrite(this@MainActivity)) {
                    Settings.System.putInt(
                        contentResolver,
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    )
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, maxOf(p, 1))
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                if (!Settings.System.canWrite(this@MainActivity)) {
                    toast("Permita \"Modificar configurações do sistema\" para controlar o brilho")
                    safeStart(
                        Intent(
                            Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + packageName)
                        )
                    )
                }
            }

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        quickPanel.addView(sliderRow(R.drawable.ic_brightness, brightSeek), lpTop(10))

        volSeek = SeekBar(this)
        volSeek.progressTintList = ColorStateList.valueOf(cAccent)
        volSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                } catch (e: Exception) {
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        quickPanel.addView(sliderRow(R.drawable.ic_volume, volSeek), lpTop(6))

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        batText = TextView(this)
        batText.setTextColor(Color.WHITE)
        batText.textSize = 13f
        batText.compoundDrawablePadding = dp(6)
        batText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_battery, 0, 0, 0)
        foot.addView(batText, LinearLayout.LayoutParams(0, WRAP, 1f))
        foot.addView(
            iconBtn(R.drawable.ic_settings) { safeStart(Intent(Settings.ACTION_SETTINGS)) },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        quickPanel.addView(foot, lpTop(8))
    }

    private fun buildCalPanel() {
        calPanel = LinearLayout(this)
        calPanel.orientation = LinearLayout.VERTICAL
        calPanel.background = rounded(cPanel, 12)
        calPanel.setPadding(dp(16), dp(16), dp(16), dp(12))
        calPanel.visibility = View.GONE
        calPanel.isClickable = true
        calPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(calPanel, lp)

        calDate = TextView(this)
        calDate.setTextColor(Color.WHITE)
        calDate.textSize = 16f
        calDate.typeface = Typeface.DEFAULT_BOLD
        calPanel.addView(calDate, lpTop(0))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        calTitle = TextView(this)
        calTitle.setTextColor(cSub)
        calTitle.textSize = 13f
        nav.addView(calTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        nav.addView(iconBtn(R.drawable.ic_chevron_up) { shiftMonth(-1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        nav.addView(iconBtn(R.drawable.ic_chevron_down) { shiftMonth(1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        calPanel.addView(nav, lpTop(8))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        for (d in listOf("D", "S", "T", "Q", "Q", "S", "S")) {
            val tv = TextView(this)
            tv.text = d
            tv.gravity = Gravity.CENTER
            tv.setTextColor(cSub)
            tv.textSize = 11f
            head.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        calPanel.addView(head, lpTop(4))

        calGrid = GridLayout(this)
        calGrid.columnCount = 7
        calPanel.addView(calGrid, lpTop(2))
    }

    private fun shiftMonth(d: Int) {
        calShown.add(Calendar.MONTH, d)
        buildCalGrid()
    }

    private fun showCalendar() {
        calShown.timeInMillis = System.currentTimeMillis()
        calDate.text = SimpleDateFormat("EEEE, d 'de' MMMM", ptBR)
            .format(Date())
            .replaceFirstChar { it.uppercase() }
        buildCalGrid()
    }

    private fun buildCalGrid() {
        calGrid.removeAllViews()
        calTitle.text = SimpleDateFormat("MMMM 'de' yyyy", ptBR)
            .format(calShown.time)
            .replaceFirstChar { it.uppercase() }
        val c = calShown.clone() as Calendar
        c.set(Calendar.DAY_OF_MONTH, 1)
        val offset = c.get(Calendar.DAY_OF_WEEK) - 1
        val days = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = Calendar.getInstance()
        val isThisMonth = today.get(Calendar.YEAR) == c.get(Calendar.YEAR) &&
            today.get(Calendar.MONTH) == c.get(Calendar.MONTH)
        val cell = (panelW() - dp(32)) / 7
        for (i in 0 until 42) {
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.textSize = 13f
            tv.setTextColor(Color.WHITE)
            val day = i - offset + 1
            if (day in 1..days) {
                tv.text = day.toString()
                if (isThisMonth && day == today.get(Calendar.DAY_OF_MONTH)) {
                    val oval = GradientDrawable()
                    oval.shape = GradientDrawable.OVAL
                    oval.setColor(cAccent)
                    tv.background = oval
                    tv.setTextColor(Color.BLACK)
                }
            }
            val glp = GridLayout.LayoutParams()
            glp.width = cell
            glp.height = cell
            calGrid.addView(tv, glp)
        }
    }

    // ----------------------------------------------------------------- panels

    private fun openStart() {
        showPanel(startPanel)
    }

    private fun showPanel(p: View) {
        for (x in listOf<View>(startPanel, quickPanel, calPanel)) {
            x.visibility = if (x === p) View.VISIBLE else View.GONE
        }
        overlay.visibility = View.VISIBLE
        p.alpha = 0f
        p.translationY = dp(24).toFloat()
        p.animate().alpha(1f).translationY(0f).setDuration(140).start()
        if (p === quickPanel) refreshQuick() else if (p === calPanel) showCalendar()
    }

    private fun closeAll() {
        if (!::overlay.isInitialized) return
        overlay.visibility = View.GONE
        startPanel.visibility = View.GONE
        quickPanel.visibility = View.GONE
        calPanel.visibility = View.GONE
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(root.windowToken, 0)
        } catch (e: Exception) {
        }
        searchBox.clearFocus()
        if (searchBox.text.isNotEmpty()) searchBox.setText("")
    }

    // ------------------------------------------------------------ system state

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun btOn(): Boolean = try {
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    } catch (e: Exception) {
        false
    }

    private fun updateTray() {
        if (!::wifiIcon.isInitialized) return
        wifiIcon.alpha = if (wifiOn()) 1f else 0.4f
    }

    private fun refreshTiles() {
        for (t in tiles) {
            val on = try {
                t.active()
            } catch (e: Exception) {
                false
            }
            t.view?.background = rip(if (on) cAccent else cTile, 8)
            val fg = if (on) Color.BLACK else Color.WHITE
            t.iconView?.setColorFilter(fg)
            t.textView?.setTextColor(fg)
        }
        updateTray()
    }

    private fun refreshQuick() {
        refreshTiles()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            volSeek.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volSeek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (e: Exception) {
        }
        try {
            brightSeek.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
        }
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (sc > 0 && lvl >= 0) lvl * 100 / sc else 0
            batText.text = "$pct%" + (if (chg) " · carregando" else "")
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("Lanterna indisponível")
                return
            }
            cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            toast("Lanterna indisponível")
        }
    }

    private fun toggleRotation() {
        if (Settings.System.canWrite(this)) {
            val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
        } else {
            toast("Permita \"Modificar configurações do sistema\" para esta opção")
            safeStart(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }
    }

    // ---------------------------------------------------------------- adapter

    inner class AppAdapter(var items: List<AppItem>, private val iconDp: Int, private val textSp: Float) :
        BaseAdapter() {

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView is LinearLayout) {
                row = convertView
            } else {
                row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.VERTICAL
                row.gravity = Gravity.CENTER_HORIZONTAL
                row.setPadding(dp(4), dp(8), dp(4), dp(8))
                val iv = ImageView(this@MainActivity)
                row.addView(iv, LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
                val tv = TextView(this@MainActivity)
                tv.setTextColor(Color.WHITE)
                tv.textSize = textSp
                tv.gravity = Gravity.CENTER
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                tv.setShadowLayer(3f, 0f, 1f, Color.BLACK)
                val tlp = LinearLayout.LayoutParams(MATCH, WRAP)
                tlp.topMargin = dp(4)
                row.addView(tv, tlp)
            }
            val app = items[position]
            (row.getChildAt(0) as ImageView).setImageDrawable(ic(app))
            (row.getChildAt(1) as TextView).text = app.label
            return row
        }
    }
}
