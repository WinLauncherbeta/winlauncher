package com.example.winlauncher;
import android.hardware.input.InputManagerGlobal;
import android.view.MotionEvent;
import java.io.ByteArrayInputStream;
import java.util.*;
public class InjTest {
    static int fails = 0, checks = 0;
    static void ck(boolean ok, String what) { checks++; if (!ok) { fails++; System.out.println("FALHOU: " + what); } }
    static String ev(MotionEvent e) {
        StringBuilder sb = new StringBuilder();
        sb.append(e.action).append(":");
        for (int i = 0; i < e.n; i++) sb.append(e.ids[i]).append("@").append((int) e.x[i]).append(",").append((int) e.y[i]).append(i + 1 < e.n ? ";" : "");
        return sb.toString();
    }
    static List<String> runCmds(String cmds) {
        InputManagerGlobal.LOG.clear();
        PadInjector.run(new ByteArrayInputStream(cmds.getBytes()));
        List<String> out = new ArrayList<String>();
        for (MotionEvent e : InputManagerGlobal.LOG) out.add(ev(e));
        return out;
    }
    public static void main(String[] a) {
        ck(PadInjector.init() == null, "init acha InputManagerGlobal");
        // um dedo: DOWN, MOVE, UP
        List<String> r = runCmds("D 0 100 200\nM 0 150 250\nF\nU 0\n");
        ck(r.equals(Arrays.asList("0:0@100,200", "2:0@150,250", "1:0@150,250")), "um dedo: " + r);
        // dois dedos: POINTER_DOWN com índice 1 (5 | 1<<8 = 261); MOVE com os dois; POINTER_UP do primeiro (6 | 0<<8) e UP do segundo
        r = runCmds("D 3 10 10\nD 7 20 20\nM 3 11 11\nM 7 21 21\nF\nU 3\nU 7\n");
        ck(r.equals(Arrays.asList("0:3@10,10", "261:3@10,10;7@20,20", "2:3@11,11;7@21,21", "6:3@11,11;7@21,21", "1:7@21,21")), "dois dedos: " + r);
        // move pendente é mandado antes de um DOWN novo
        r = runCmds("D 0 1 1\nM 0 5 5\nD 1 9 9\nX\n");
        ck(r.equals(Arrays.asList("0:0@1,1", "2:0@5,5", "261:0@5,5;1@9,9", "6:0@5,5;1@9,9", "1:1@9,9")), "move pendente + X: " + r);
        // fim da entrada solta os dedos presos
        r = runCmds("D 2 30 40\n");
        ck(r.equals(Arrays.asList("0:2@30,40", "1:2@30,40")), "EOF solta: " + r);
        // Q sai e solta
        r = runCmds("D 2 30 40\nQ\nD 4 1 1\n");
        ck(r.equals(Arrays.asList("0:2@30,40", "1:2@30,40")), "Q para de ler: " + r);
        // lixo, slot fora da faixa, UP sem DOWN, DOWN repetido (vira move)
        r = runCmds("lixo\nD x y z\nD 99 1 1\nU 5\nM 0 1 1\nF\nD 1 5 5\nD 1 6 6\nF\nU 1\n");
        ck(r.equals(Arrays.asList("0:1@5,5", "2:1@6,6", "1:1@6,6")), "entradas inválidas: " + r);
        // sistema recusando: não quebra
        InputManagerGlobal.refuse = true;
        r = runCmds("D 0 1 1\nU 0\n");
        ck(r.isEmpty(), "recusa não lança");
        InputManagerGlobal.refuse = false;
        // 10 dedos
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) sb.append("D ").append(i).append(" ").append(i).append(" ").append(i).append("\n");
        r = runCmds(sb.toString());
        ck(r.size() == 20 && r.get(9).startsWith(String.valueOf(5 | (9 << 8)) + ":"), "10 dedos sobem e descem: " + r.size());
        System.out.println(checks + " verificações, " + fails + " falhas");
        System.exit(fails == 0 ? 0 : 1);
    }
}
