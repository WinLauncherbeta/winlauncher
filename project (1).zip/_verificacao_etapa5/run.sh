#!/bin/sh
# Compila o PadInjector.java contra stubs do Android (NÃO é o android.jar) e roda InjTest.
# Confere a lógica de dedos/ações do MotionEvent e o protocolo; NÃO prova que o InputManager real do aparelho aceita a injeção.
cd "$(dirname "$0")"
rm -rf out && mkdir out
JAVAC="javac"
command -v javac >/dev/null 2>&1 || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -d out $(find android -name '*.java') ../app/src/main/java/com/example/winlauncher/PadInjector.java t/com/example/winlauncher/InjTest.java && java -cp out com.example.winlauncher.InjTest
