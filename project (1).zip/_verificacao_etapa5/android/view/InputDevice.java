package android.view;
public class InputDevice { public static final int SOURCE_TOUCHSCREEN = 0x1002; }
