package android.view;
public final class MotionEvent extends InputEvent {
    public static final int ACTION_DOWN = 0, ACTION_UP = 1, ACTION_MOVE = 2, ACTION_POINTER_DOWN = 5, ACTION_POINTER_UP = 6;
    public static final int ACTION_POINTER_INDEX_SHIFT = 8, TOOL_TYPE_FINGER = 1;
    public static class PointerProperties { public int id; public int toolType; public void clear() { id = -1; toolType = 0; } }
    public static class PointerCoords { public float x, y, pressure, size; public void clear() { x = y = pressure = size = 0; } }
    public int action, n; public int[] ids; public float[] x, y; public long downTime; public int source;
    public static MotionEvent obtain(long downTime, long eventTime, int action, int pointerCount, PointerProperties[] pp,
            PointerCoords[] pc, int meta, int buttons, float xp, float yp, int deviceId, int edge, int source, int flags) {
        MotionEvent e = new MotionEvent();
        e.downTime = downTime; e.action = action; e.n = pointerCount; e.source = source;
        e.ids = new int[pointerCount]; e.x = new float[pointerCount]; e.y = new float[pointerCount];
        for (int i = 0; i < pointerCount; i++) { e.ids[i] = pp[i].id; e.x[i] = pc[i].x; e.y[i] = pc[i].y; }
        return e;
    }
    public void recycle() { }
}
