package android.hardware.input;
import android.view.*;
import java.util.*;
public class InputManagerGlobal {
    public static final List<MotionEvent> LOG = new ArrayList<MotionEvent>();
    public static boolean refuse = false;
    private static InputManagerGlobal inst = new InputManagerGlobal();
    public static InputManagerGlobal getInstance() { return inst; }
    public boolean injectInputEvent(InputEvent e, int mode) { if (refuse) return false; LOG.add((MotionEvent) e); return true; }
}
