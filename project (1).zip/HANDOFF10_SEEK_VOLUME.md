# HANDOFF 10 — seek e volume pelo Remote (WinLauncher 2.6.0)

Não compilado (sem Android SDK). Compilar pelo GitHub Actions. Par do WinLauncher Remote 0.4.8.

- RemoteProtocol: comandos `seek` (campo `positionMs`, 0..24 h) e `volume` (campo `volume`, 0..100); capacidades `seek` e `volume`
  em SERVER_CAPS; campo opcional `vol` (0..100) no `state`; autotestes atualizados (lista de comandos, ida e volta, rejeições).
- RemoteBridge: `MediaPort.seekTo / setVolume / volumePercent` (padrão "indisponível", portas falsas dos testes continuam compilando);
  `volume` muda o volume de MÚSICA deste aparelho e reenvia o estado a todos os Remotes; o `state` leva `vol`.
- MediaSessionHub: `seekTo` (transportControls.seekTo), `volumePercent`, `setVolumePercent` (AudioManager STREAM_MUSIC; não depende de haver música tocando).
- Backup dos originais: `_backup_seek_volume/`.
- Aviso: `seek` depende do app de música aceitar ir para um ponto (alguns ignoram em silêncio).
