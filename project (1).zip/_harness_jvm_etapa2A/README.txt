Harness JVM (fora do build do app). Compila e roda os autotestes do Remote numa JVM com stubs.
1) keytool -genkeypair -alias k -keyalg EC -groupname secp256r1 -dname CN=harness -validity 30 -storetype PKCS12 -keystore ks.p12 -storepass changeit -keypass changeit
   (kt/RemoteAuth.kt aponta para /home/claude/work/harness/ks.p12: ajuste o caminho)
2) javac -d out $(find stubs -name "*.java")
3) kotlinc -jvm-target 17 -cp out kt/*.kt app/src/main/java/com/example/winlauncher/{RemoteProtocol,RemoteServer,RemoteBridge,RemoteBridgeTest}.kt -d out
4) java -cp out:kotlin-stdlib.jar MainKt   (servidor)   |   Main2Kt (integração)
Stubs/RemoteAuth/MediaSessionHub aqui NÃO são os do app.
