Ver README no ZIP da 2A: compilar com kotlinc + stubs (nao faz parte do build do app).
