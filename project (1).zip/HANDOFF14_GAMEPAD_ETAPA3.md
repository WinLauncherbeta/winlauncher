# HANDOFF 14 — Mapeador de gamepad, ETAPA 3 (FECHADA NO CÓDIGO): analógicos, turbo, macros, gradual, eixos (WinLauncher 2.9.1 / code 22)

NÃO compilado com Gradle e NÃO testado em aparelho. As etapas 1 e 2 também seguem sem teste no aparelho.
Verificado na JVM (kotlinc do Gradle + stubs de org.json): PadModel, TouchPlanner, PadEngine, GetEventParser = 77 verificações OK (JSON v2/v3, macro, gradual, turbo, ajustes, getevent). Os arquivos de interface (PadPanel, PadOverlayEditor, PadMapperService, PadAxisReader) só passaram numa checagem de sintaxe, sem android.jar.

## Correção de build (já estava no zip parcial)
- PadPanel.kt (PadLayoutView.onDraw): `when (b.mode)` só cobria TAP/HOLD/OFF -> erro de compilação. Agora cobre todos os modos.

## Novo nesta versão
- Ajustes NA INTERFACE (editor sobre o jogo e painel): Raio, Velocidade, Zona morta, Toques/s do turbo, Direção do gradual, tempos da macro. Botões −/+ (segurar repete). Definidos em `PadTuning` (PadModel.kt); os dois lugares desenham a mesma lista.
- Macros (modo "Macro", botões comuns e L2/R2): passos com ponto, tempo de toque (30–2000 ms) e espera (0–5000 ms), até 24. Toque na tela acrescenta passo, arrastar move, ‹ › escolhe, "Apagar passo". "Repetir: Sim" = repete enquanto o botão estiver apertado; "Uma vez" = roda inteira mesmo se soltar. Sair do app interrompe.
- Gatilho gradual (modo "Gradual", só L2/R2): o dedo anda na direção escolhida (cima/baixo/esq/dir) até o raio, proporcional ao aperto do eixo. Sem eixo (controle só digital, ou Android 13- sem Shizuku) a tecla vale "aperto total". Zona morta padrão 5%.
- Android 13 ou menor (Etapa 3B): leitor `getevent -lq` via Shizuku (PadAxisReader + GetEventParser). Liga só quando o perfil da frente precisa de eixos; precisa do Shizuku ligado e autorizado. Os eixos são classificados pelo valor em repouso (Xbox e PlayStation testados só em texto de exemplo). Ler evdev não tira os eixos do jogo.
- JSON dos perfis versão 3 (perfis antigos abrem).

## Pontos para o build/teste
1. onMotionEvent/motionEventSources (PadMapperService.kt): API 34, compileSdk 34.
2. Painel: mexer nos analógicos deve mudar a linha "Eixos (Acessibilidade|Shizuku)".
3. Android 13-: autorizar o Shizuku; a linha do painel mostra "[Shizuku: ...]" com o status do leitor. Se o `getevent` não abrir, ShizukuBridge.lastError diz o motivo.
4. Joystick/câmera/gradual/macro/turbo num jogo real. Mapeamento de eixos por controle é heurístico: se L/R trocarem, é em GetEventParser.layoutFor.

## FALTA (Etapa 4)
- Perfil automático ao abrir o jogo, botão flutuante liga/desliga, importar/exportar perfis, polimento.
- Gatilho com pressão real (o Android não deixa o serviço de acessibilidade mandar pressão de toque; o "Gradual" é a alternativa por deslocamento).
