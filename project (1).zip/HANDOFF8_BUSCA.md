# HANDOFF 8 — busca de música pelo Remote (WinLauncher 2.5.8)

Não compilado (sem Android SDK). Compilar pelo GitHub Actions.

- RemoteProtocol: comando `search` (exige `query`, 1..80 caracteres, recusa vazio/só espaços), `CAP_SEARCH` em `SERVER_CAPS`,
  autotestes atualizados (lista de comandos agora tem 5; o de Mouse estava desatualizado e foi corrigido).
- MediaSessionHub.playFromSearch(query): `transportControls.playFromSearch(q, Bundle())`; sem `ACTION_PLAY_FROM_SEARCH` anunciada devolve UNAVAILABLE.
- RemoteBridge: `MediaPort.playFromSearch` (padrão UNAVAILABLE, FakeMediaPort continua compilando), HubPort, handleCommand.
- Limite: o Android não devolve resultados; quem decide o que toca é o app de música.
