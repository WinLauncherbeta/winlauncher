package com.example.winlauncher

import android.app.Application
import android.content.Intent
import android.os.Build
import android.os.Process
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

/**
 * Captura qualquer falha fatal do app e abre a CrashActivity (outro processo) mostrando o erro,
 * em vez de só fechar. Serve para descobrir por que o launcher não abre.
 */
class WinApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val proc = if (Build.VERSION.SDK_INT >= 28) Application.getProcessName() else null
        if (proc != null && proc.endsWith(":crash")) return
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val txt = "Thread: ${t.name}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) ${Build.MANUFACTURER} ${Build.MODEL}\n\n$sw"
                try {
                    openFileOutput("crash.txt", MODE_PRIVATE).use { it.write(txt.toByteArray()) }
                } catch (x: Throwable) {
                }
                val i = Intent(this, CrashActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                i.putExtra("trace", txt.take(40000))
                startActivity(i)
                Thread.sleep(800)
                Process.killProcess(Process.myPid())
                exitProcess(10)
            } catch (x: Throwable) {
                old?.uncaughtException(t, e)
            }
        }
    }
}
