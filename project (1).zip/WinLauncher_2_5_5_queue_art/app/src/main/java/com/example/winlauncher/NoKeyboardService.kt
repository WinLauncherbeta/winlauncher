package com.example.winlauncher

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo

/**
 * Teclado "vazio": quando está selecionado como teclado do Android, nenhum teclado aparece na tela
 * em nenhum app (é o mesmo truque que o Button Mapper usa). O teclado físico continua funcionando,
 * pois as teclas físicas vão direto para o app, sem passar por aqui.
 */
class NoKeyboardService : InputMethodService() {

    override fun onEvaluateInputViewShown(): Boolean = false

    override fun onShowInputRequested(flags: Int, configChange: Boolean): Boolean = false

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View? = null

    override fun onCreateCandidatesView(): View? = null

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        // garante que nada fique visível
        try {
            requestHideSelf(0)
        } catch (e: Exception) {
        }
    }
}
