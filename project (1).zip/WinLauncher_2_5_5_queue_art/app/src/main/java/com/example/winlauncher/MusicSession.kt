package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder

/**
 * Publica o que o player do launcher está tocando como uma MediaSession do Android
 * (+ notificação de mídia). É isso que faz aparecer os controles de play/pause/próxima
 * no painel rápido do sistema, na tela de bloqueio, no chip da barra de tarefas e nos fones.
 */
object MusicSession {
    const val CHANNEL = "winlauncher_music"
    const val NOTIF_ID = 4711
    const val ACTION_PLAY_PAUSE = "com.example.winlauncher.MUSIC_PLAY_PAUSE"
    const val ACTION_NEXT = "com.example.winlauncher.MUSIC_NEXT"
    const val ACTION_PREV = "com.example.winlauncher.MUSIC_PREV"
    const val ACTION_STOP = "com.example.winlauncher.MUSIC_STOP"

    class Callbacks(
        val onPlay: () -> Unit,
        val onPause: () -> Unit,
        val onNext: () -> Unit,
        val onPrev: () -> Unit,
        val onSeek: (Long) -> Unit,
        val onStop: () -> Unit
    )

    private var session: MediaSession? = null
    private var callbacks: Callbacks? = null
    private var appCtx: Context? = null

    private var title = ""
    private var artist = ""
    private var durMs = 0L
    private var posMs = 0L
    private var playing = false
    private var art: Bitmap? = null

    /** Ações dos botões da notificação chegam por aqui (rodam na thread principal). */
    fun dispatch(action: String?) {
        val cb = callbacks ?: return
        when (action) {
            ACTION_PLAY_PAUSE -> if (playing) cb.onPause() else cb.onPlay()
            ACTION_NEXT -> cb.onNext()
            ACTION_PREV -> cb.onPrev()
            ACTION_STOP -> cb.onStop()
        }
    }

    private fun ensure(ctx: Context) {
        if (session != null) return
        val app = ctx.applicationContext
        appCtx = app
        val s = MediaSession(app, "WinLauncherMusic")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { callbacks?.onPlay?.invoke() }
            override fun onPause() { callbacks?.onPause?.invoke() }
            override fun onSkipToNext() { callbacks?.onNext?.invoke() }
            override fun onSkipToPrevious() { callbacks?.onPrev?.invoke() }
            override fun onSeekTo(pos: Long) { callbacks?.onSeek?.invoke(pos) }
            override fun onStop() { callbacks?.onStop?.invoke() }
        })
        s.isActive = true
        session = s

        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Reprodutor de música", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                }
            )
        }
    }

    /** Chame ao começar uma música ou quando título/duração mudarem. */
    fun update(
        ctx: Context, cb: Callbacks, title: String, artist: String,
        durMs: Long, posMs: Long, playing: Boolean, art: Bitmap? = null
    ) {
        ensure(ctx)
        callbacks = cb
        this.title = title
        this.artist = artist
        this.durMs = durMs
        this.posMs = posMs
        this.playing = playing
        if (art != null) this.art = art
        push()
    }

    /** Só estado (tocando/pausado/posição). */
    fun updateState(posMs: Long, playing: Boolean) {
        if (session == null) return
        this.posMs = posMs
        this.playing = playing
        push()
    }

    fun clear() {
        val app = appCtx ?: return
        try {
            session?.isActive = false
            session?.release()
        } catch (e: Exception) {
        }
        session = null
        callbacks = null
        art = null
        try {
            app.stopService(Intent(app, MusicService::class.java))
            (app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID)
        } catch (e: Exception) {
        }
    }

    private fun push() {
        val s = session ?: return
        val app = appCtx ?: return
        try {
            val md = MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durMs)
            art?.let { md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) }
            s.setMetadata(md.build())

            val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
                PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO or
                PlaybackState.ACTION_STOP
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(actions)
                    .setState(
                        if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                        posMs, if (playing) 1f else 0f
                    )
                    .build()
            )
            val n = buildNotification(app, s)
            if (playing) {
                // foreground enquanto toca: o Android não mata o app e mostra os controles
                val i = Intent(app, MusicService::class.java)
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
                MusicService.post(n)
            } else {
                (app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
                MusicService.post(n)
            }
        } catch (e: Exception) {
        }
    }

    private fun pi(ctx: Context, action: String, code: Int): PendingIntent {
        val i = Intent(ctx, MusicService::class.java).setAction(action)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getService(ctx, code, i, flags)
    }

    fun buildNotification(ctx: Context, s: MediaSession): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(title.ifEmpty { "Música" })
            .setContentText(artist)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(ctx, R.drawable.ic_media_prev),
                "Anterior", pi(ctx, ACTION_PREV, 1)).build())
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(
                    ctx, if (playing) R.drawable.ic_media_pause else R.drawable.ic_media_play),
                if (playing) "Pausar" else "Tocar", pi(ctx, ACTION_PLAY_PAUSE, 2)).build())
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(ctx, R.drawable.ic_media_next),
                "Próxima", pi(ctx, ACTION_NEXT, 3)).build())
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(s.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        art?.let { b.setLargeIcon(it) }
        return b.build()
    }
}

/** Serviço em primeiro plano que sustenta a notificação de mídia enquanto a música toca. */
class MusicService : Service() {
    companion object {
        @Volatile private var pending: Notification? = null
        @Volatile private var self: MusicService? = null

        fun post(n: Notification) {
            pending = n
            self?.show(n)
        }
    }

    private fun show(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(MusicSession.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(MusicSession.NOTIF_ID, n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onCreate() {
        super.onCreate()
        self = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // precisa chamar startForeground logo após startForegroundService
        pending?.let { show(it) }
        MusicSession.dispatch(intent?.action)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        self = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
