package com.example.winlauncher

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.DragEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebSettings
import android.widget.FrameLayout
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Arrastar e soltar entre as janelas do WinLauncher (Gerenciador de arquivos, Fotos, Navegador, Instalador de APK).
 *
 * Funciona assim: uma camada transparente fica no topo da tela e recebe todo o arraste do Android. Ela descobre
 * qual janela aberta está sob o dedo/mouse (a da frente vence) e entrega o conteúdo a ela. Cada janela se
 * registra com [register]. O que se arrasta é um [Payload]: arquivos locais, endereços da web (imagens do
 * navegador) ou conteúdo de outro app (quando o Android entrega URIs).
 *
 * Liga/desliga em Configurações → Bluetooth e dispositivos → Mouse e interação (chave "ui_dragdrop").
 */
object DragDrop {

    private const val LABEL = "winlauncher-drag"
    private const val MAX_DOWNLOAD = 200L * 1024 * 1024

    /** Uma coisa arrastada: arquivo local, endereço da web ou conteúdo de outro app. */
    class Item(val name: String, val file: File? = null, val url: String? = null, val uri: Uri? = null)

    class Payload(val items: List<Item>, val source: Any?, val startX: Float, val startY: Float) {
        /** Chamado uma vez no fim do arraste: (soltou em algum lugar?, o dedo andou?). */
        var onEnd: ((Boolean, Boolean) -> Unit)? = null
        var lastX = startX
        var lastY = startY
        val files: List<File> get() = items.mapNotNull { it.file }
        fun moved(slop: Float): Boolean =
            Math.abs(lastX - startX) > slop || Math.abs(lastY - startY) > slop
    }

    /** Uma janela que aceita soltar coisas. [win] é o retângulo da janela; [layer] serve para a ordem de empilhamento. */
    class Target(
        val layer: View,
        val win: View,
        val accepts: (Payload) -> Boolean,
        val over: ((Payload, Int, Int) -> Unit)? = null,
        val leave: (() -> Unit)? = null,
        val drop: (Payload, Int, Int) -> Boolean
    )

    private val targets = ArrayList<Target>()
    private var catcher: View? = null
    private var hot: Target? = null
    private var hotDrawable: Drawable? = null
    private var perm: Any? = null
    private val stub = Payload(listOf(Item("arquivo", uri = Uri.EMPTY)), null, 0f, 0f)

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("win", Context.MODE_PRIVATE).getBoolean("ui_dragdrop", true)

    // ------------------------------------------------------------------ registro

    fun register(act: Activity, root: FrameLayout, t: Target) {
        targets.add(t)
        if (catcher != null) return
        val v = View(act)
        root.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        v.setOnDragListener { view, ev -> onDrag(act, view, ev) }
        catcher = v
    }

    // ------------------------------------------------------------------ origem

    /** Começa a arrastar [items] a partir de [from] (precisa estar com o dedo/mouse pressionado). */
    fun start(
        act: Activity,
        from: View,
        items: List<Item>,
        source: Any?,
        x: Float = 0f,
        y: Float = 0f,
        onEnd: ((Boolean, Boolean) -> Unit)? = null
    ): Boolean {
        if (!enabled(act) || items.isEmpty()) return false
        val p = Payload(items, source, x, y)
        p.onEnd = onEnd
        val label = if (items.size == 1) items[0].name else items.size.toString() + " itens"
        val uris = items.mapNotNull { it.file }.filter { it.isFile }.map { FileShareProvider.uriFor(act, it) }
        var flags = View.DRAG_FLAG_OPAQUE
        val clip: ClipData
        if (uris.isNotEmpty()) {
            clip = ClipData.newRawUri(LABEL, uris[0])
            for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
            // permite soltar em outros apps (tela dividida / janelas flutuantes)
            flags = flags or View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ
        } else {
            clip = ClipData.newPlainText(LABEL, items.firstOrNull { it.url != null }?.url ?: label)
        }
        return try {
            from.startDragAndDrop(clip, ChipShadow(act, label), p, flags)
        } catch (t: Throwable) {
            false
        }
    }

    private class ChipShadow(ctx: Context, private val label: String) : View.DragShadowBuilder() {
        private val d = ctx.resources.displayMetrics.density
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tx = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text: String = if (label.length > 26) label.substring(0, 25) + "…" else label
        private val w: Int
        private val h = (36 * d).toInt()

        init {
            bg.color = Color.parseColor("#EE202A3A")
            line.color = Color.parseColor("#4CC2FF")
            line.style = Paint.Style.STROKE
            line.strokeWidth = 1.5f * d
            tx.color = Color.WHITE
            tx.textSize = 13f * d
            w = (tx.measureText(text) + 28 * d).toInt()
        }

        override fun onProvideShadowMetrics(outShadowSize: Point, outShadowTouchPoint: Point) {
            outShadowSize.set(w, h)
            outShadowTouchPoint.set(w / 2, h + (28 * d).toInt())
        }

        override fun onDrawShadow(canvas: Canvas) {
            val r = RectF(1f, 1f, w - 1f, h - 1f)
            canvas.drawRoundRect(r, 8 * d, 8 * d, bg)
            canvas.drawRoundRect(r, 8 * d, 8 * d, line)
            canvas.drawText(text, 14 * d, h / 2f + 5 * d, tx)
        }
    }

    // ------------------------------------------------------------------ despacho

    private fun raw(v: View, ev: DragEvent): IntArray {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return intArrayOf(loc[0] + ev.x.toInt(), loc[1] + ev.y.toInt())
    }

    private fun onDrag(act: Activity, v: View, ev: DragEvent): Boolean {
        when (ev.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                if (!enabled(act)) return false
                return ev.localState is Payload || ev.clipDescription?.hasMimeType("text/uri-list") == true
            }
            DragEvent.ACTION_DRAG_ENTERED -> return true
            DragEvent.ACTION_DRAG_LOCATION -> {
                val xy = raw(v, ev)
                val local = ev.localState as? Payload
                if (local != null) {
                    local.lastX = xy[0].toFloat()
                    local.lastY = xy[1].toFloat()
                }
                val p = local ?: stub
                val t = targetAt(xy[0], xy[1])?.takeIf { it.accepts(p) }
                setHot(t)
                t?.over?.invoke(p, xy[0], xy[1])
                return true
            }
            DragEvent.ACTION_DRAG_EXITED -> {
                setHot(null)
                return true
            }
            DragEvent.ACTION_DROP -> {
                val xy = raw(v, ev)
                val t = targetAt(xy[0], xy[1])
                setHot(null)
                val p = resolve(act, ev) ?: return false
                if (t == null || !t.accepts(p)) return false
                return try {
                    t.drop(p, xy[0], xy[1])
                } catch (e: Throwable) {
                    false
                }
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                setHot(null)
                val p = ev.localState as? Payload
                if (p != null) {
                    val cb = p.onEnd
                    p.onEnd = null
                    val slop = ViewConfiguration.get(act).scaledTouchSlop * 3f
                    cb?.invoke(ev.result, p.moved(slop))
                }
                return true
            }
        }
        return false
    }

    private fun targetAt(x: Int, y: Int): Target? {
        var best: Target? = null
        var bestZ = -1
        val loc = IntArray(2)
        for (t in targets) {
            if (!t.win.isShown) continue
            val par = t.layer.parent as? ViewGroup ?: continue
            val z = par.indexOfChild(t.layer)
            if (z < 0) continue
            t.win.getLocationOnScreen(loc)
            if (x < loc[0] || y < loc[1] || x >= loc[0] + t.win.width || y >= loc[1] + t.win.height) continue
            if (z > bestZ) {
                best = t
                bestZ = z
            }
        }
        return best
    }

    private fun setHot(t: Target?) {
        if (t === hot) return
        hot?.let { old ->
            hotDrawable?.let { old.win.overlay.remove(it) }
            hotDrawable = null
            old.leave?.invoke()
        }
        hot = t
        if (t != null) {
            val d = t.win.resources.displayMetrics.density
            val g = GradientDrawable()
            g.setColor(Color.argb(34, 76, 194, 255))
            g.setStroke((2 * d).toInt(), Color.parseColor("#4CC2FF"))
            g.cornerRadius = 6 * d
            g.setBounds(0, 0, t.win.width, t.win.height)
            t.win.overlay.add(g)
            hotDrawable = g
        }
    }

    /** Extrai o que foi solto: do próprio app (localState) ou de outro app (URIs no ClipData). */
    private fun resolve(act: Activity, ev: DragEvent): Payload? {
        (ev.localState as? Payload)?.let { return it }
        val cd = ev.clipData ?: return null
        try {
            (perm as? android.view.DragAndDropPermissions)?.release()
            perm = act.requestDragAndDropPermissions(ev)
        } catch (t: Throwable) {
        }
        val items = ArrayList<Item>()
        for (i in 0 until cd.itemCount) {
            val u = cd.getItemAt(i).uri ?: continue
            items.add(Item(displayName(act, u), uri = u))
        }
        return if (items.isEmpty()) null else Payload(items, null, 0f, 0f)
    }

    private fun displayName(ctx: Context, u: Uri): String {
        try {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (t: Throwable) {
        }
        return u.lastPathSegment ?: "arquivo"
    }

    // ------------------------------------------------------------------ salvar / ler

    /** Copia/baixa cada item para [dir] em segundo plano. [done] roda na thread principal: (arquivos salvos, erros). */
    fun saveAll(act: Activity, items: List<Item>, dir: File, done: (List<File>, Int) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        Thread {
            val ok = ArrayList<File>()
            var err = 0
            for (item in items) {
                try {
                    ok.add(saveOne(act, item, dir))
                } catch (t: Throwable) {
                    err++
                }
            }
            try {
                if (ok.isNotEmpty()) {
                    MediaScannerConnection.scanFile(act, ok.map { it.absolutePath }.toTypedArray(), null, null)
                }
            } catch (t: Throwable) {
            }
            h.post { done(ok, err) }
        }.start()
    }

    private fun saveOne(ctx: Context, item: Item, dir: File): File {
        dir.mkdirs()
        val f = item.file
        val u = item.uri
        val web = item.url
        if (f != null) {
            val dst = FileOps.uniqueFile(dir, f.name)
            FileOps.copy(f, dst, OpCtl())
            return dst
        }
        if (u != null) {
            val dst = FileOps.uniqueFile(dir, item.name)
            val ins = ctx.contentResolver.openInputStream(u) ?: throw IOException("sem acesso")
            ins.use { i -> FileOutputStream(dst).use { o -> i.copyTo(o) } }
            return dst
        }
        if (web != null) return download(ctx, web, dir)
        throw IOException("vazio")
    }

    private fun download(ctx: Context, u: String, dir: File): File {
        if (u.startsWith("data:", true)) {
            val comma = u.indexOf(',')
            if (comma < 0) throw IOException("data inválido")
            val meta = u.substring(5, comma)
            val data = u.substring(comma + 1)
            val bytes = if (meta.endsWith(";base64")) Base64.decode(data, Base64.DEFAULT) else Uri.decode(data).toByteArray()
            val mime = meta.substringBefore(';').ifEmpty { "application/octet-stream" }
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
            val dst = FileOps.uniqueFile(dir, "imagem.$ext")
            FileOutputStream(dst).use { it.write(bytes) }
            return dst
        }
        if (!u.startsWith("http://", true) && !u.startsWith("https://", true)) throw IOException("endereço não suportado")
        val c = URL(u).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            try {
                c.setRequestProperty("User-Agent", WebSettings.getDefaultUserAgent(ctx))
            } catch (t: Throwable) {
            }
            CookieManager.getInstance().getCookie(u)?.let { c.setRequestProperty("Cookie", it) }
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val mime = c.contentType?.substringBefore(';')
            val name = URLUtil.guessFileName(u, c.getHeaderField("Content-Disposition"), mime)
            val dst = FileOps.uniqueFile(dir, name)
            var total = 0L
            c.inputStream.use { i ->
                FileOutputStream(dst).use { o ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_DOWNLOAD) {
                            dst.delete()
                            throw IOException("arquivo grande demais")
                        }
                        o.write(buf, 0, n)
                    }
                }
            }
            return dst
        } finally {
            c.disconnect()
        }
    }

    /** Lê os bytes de um item local (arquivo ou URI) para enviar a uma página; null se passar de [max]. */
    fun readBytes(ctx: Context, item: Item, max: Int): ByteArray? {
        try {
            val f = item.file
            val u = item.uri
            if (f != null) {
                if (!f.isFile || f.length() > max) return null
                return f.readBytes()
            }
            if (u != null) {
                val ins = ctx.contentResolver.openInputStream(u) ?: return null
                ins.use { i ->
                    val out = java.io.ByteArrayOutputStream()
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > max) return null
                    }
                    return out.toByteArray()
                }
            }
        } catch (t: Throwable) {
        }
        return null
    }
}
