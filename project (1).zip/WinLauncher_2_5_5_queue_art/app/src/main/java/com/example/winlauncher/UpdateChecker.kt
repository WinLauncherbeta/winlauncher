package com.example.winlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Avisa o usuário quando existe uma versão nova publicada em GitHub Releases.
 *
 * Como usar ao lançar uma atualização:
 *  1. Aumente versionCode/versionName em app/build.gradle.kts.
 *  2. No GitHub, crie um Release com a tag igual à versionName (ex.: "v2.3" ou "2.3"),
 *     escreva as novidades na descrição e anexe o arquivo .apk.
 *
 * O launcher consulta o último Release ao abrir, compara com a versão instalada e, se for maior,
 * mostra um aviso. Ao tocar em "Atualizar", baixa o .apk e abre o instalador do WinLauncher.
 */
class UpdateChecker(
    private val act: Activity,
    private val prefs: SharedPreferences,
    private val apkWindow: ApkInstallerWindow
) {

    companion object {
        /** TROQUE pelo seu repositório no formato "usuario/repositorio". */
        const val GITHUB_REPO = "SEU_USUARIO/SEU_REPOSITORIO"

        /** Não consulta o GitHub mais de uma vez por esse intervalo (evita limite de requisições). */
        private const val MIN_INTERVAL_MS = 60L * 60L * 1000L
        private const val KEY_LAST_CHECK = "upd_last_check"
        private const val KEY_IGNORED = "upd_ignored"
    }

    private class Release(val version: String, val notes: String, val apkUrl: String)

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var busy = false

    /** Chamado ao abrir o launcher: respeita o intervalo mínimo e a versão ignorada. */
    fun checkOnStart() = check(manual = false)

    /** Para um botão "Verificar atualizações": ignora o intervalo e avisa mesmo se já estiver atualizado. */
    fun checkNow() = check(manual = true)

    private fun check(manual: Boolean) {
        if (GITHUB_REPO.startsWith("SEU_USUARIO")) return
        if (busy) return
        val now = System.currentTimeMillis()
        if (!manual && now - prefs.getLong(KEY_LAST_CHECK, 0L) < MIN_INTERVAL_MS) return
        busy = true
        io.execute {
            val rel = try {
                fetchLatest()
            } catch (t: Throwable) {
                null
            }
            handler.post {
                busy = false
                if (rel == null) {
                    if (manual) act.runOnUiThread { toast("Não foi possível verificar atualizações") }
                    return@post
                }
                prefs.edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply()
                val current = currentVersion()
                if (isNewer(rel.version, current)) {
                    if (!manual && prefs.getString(KEY_IGNORED, null) == rel.version) return@post
                    if (!act.isFinishing) showDialog(rel)
                } else if (manual) {
                    toast("Você já está na versão mais recente ($current)")
                }
            }
        }
    }

    // ------------------------------------------------------------------ rede

    private fun fetchLatest(): Release? {
        val c = URL("https://api.github.com/repos/$GITHUB_REPO/releases/latest").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "WinLauncher")
            if (c.responseCode != 200) return null
            val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val tag = json.optString("tag_name").trim()
            if (tag.isEmpty()) return null
            val assets = json.optJSONArray("assets") ?: return null
            var url: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    url = a.optString("browser_download_url")
                    break
                }
            }
            if (url.isNullOrEmpty()) return null
            return Release(tag, json.optString("body").trim(), url)
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, dest: File): Boolean {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "WinLauncher")
            if (c.responseCode != 200) return false
            dest.parentFile?.mkdirs()
            c.inputStream.use { ins -> dest.outputStream().use { out -> ins.copyTo(out) } }
            dest.length() > 0
        } catch (t: Throwable) {
            false
        } finally {
            c.disconnect()
        }
    }

    // ------------------------------------------------------------------ versão

    private fun currentVersion(): String = try {
        act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "0"
    } catch (t: Throwable) {
        "0"
    }

    /** Compara "v2.10" com "2.9" número a número. */
    private fun isNewer(remote: String, local: String): Boolean {
        fun parts(s: String) = Regex("\\d+").findAll(s).map { it.value.toLongOrNull() ?: 0L }.toList()
        val r = parts(remote)
        val l = parts(local)
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0L }
            val b = l.getOrElse(i) { 0L }
            if (a != b) return a > b
        }
        return false
    }

    // ------------------------------------------------------------------ interface

    private fun showDialog(rel: Release) {
        val notes = if (rel.notes.length > 600) rel.notes.take(600) + "…" else rel.notes
        val msg = buildString {
            append("Versão ${rel.version} disponível (você está na ${currentVersion()}).")
            if (notes.isNotEmpty()) append("\n\n").append(notes)
        }
        AlertDialog.Builder(act)
            .setTitle("Nova atualização do WinLauncher")
            .setMessage(msg)
            .setPositiveButton("Atualizar") { _, _ -> downloadAndInstall(rel) }
            .setNegativeButton("Depois", null)
            .setNeutralButton("Ignorar esta versão") { _, _ ->
                prefs.edit().putString(KEY_IGNORED, rel.version).apply()
            }
            .show()
    }

    private fun downloadAndInstall(rel: Release) {
        toast("Baixando atualização…")
        io.execute {
            val f = File(File(act.cacheDir, "update_dl"), "WinLauncher-${rel.version}.apk")
            val ok = download(rel.apkUrl, f)
            handler.post {
                if (act.isFinishing) return@post
                if (ok) apkWindow.openWith(Uri.fromFile(f)) else toast("Falha ao baixar a atualização")
            }
        }
    }

    private fun toast(s: String) = android.widget.Toast.makeText(act, s, android.widget.Toast.LENGTH_LONG).show()
}
