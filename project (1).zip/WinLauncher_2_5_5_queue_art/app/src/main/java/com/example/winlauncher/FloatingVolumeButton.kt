package com.example.winlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Botão de volume flutuante DENTRO do launcher (parte da própria janela do launcher).
 * Aparece sempre que o launcher está na tela, inclusive no monitor HDMI, sem criar janelas em outras telas.
 * Arraste com o mouse ou o dedo; clique abre o painel de volume; botão direito abre o menu (opacidade/tamanho/ocultar).
 * Opacidade e tamanho são compartilhados com o botão que aparece sobre outros apps (VolumeButtonService).
 */
class FloatingVolumeButton(
    private val ctx: Context,
    private val root: FrameLayout,
    private val sp: SharedPreferences,
    private val isRight: (MotionEvent) -> Boolean,
    private val onClick: () -> Unit,
    private val onRight: (Int, Int) -> Unit
) {
    companion object {
        const val MIN_SIZE_DP = 32
        const val MAX_SIZE_DP = 120
        const val DEF_SIZE_DP = 48
    }

    private val d = ctx.resources.displayMetrics.density
    val view = ImageView(ctx)
    private val lp = FrameLayout.LayoutParams(0, 0, Gravity.TOP or Gravity.START)

    fun sizeDp(): Int = sp.getInt("vb_size", DEF_SIZE_DP).coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)
    fun alphaPct(): Int = sp.getInt("vb_alpha", 100).coerceIn(20, 100)
    private fun px(): Int = (sizeDp() * d + 0.5f).toInt()
    private fun baseAlpha() = alphaPct() / 100f

    private fun rootW(): Int = if (root.width > 0) root.width else ctx.resources.displayMetrics.widthPixels
    private fun rootH(): Int = if (root.height > 0) root.height else ctx.resources.displayMetrics.heightPixels

    init {
        view.setImageResource(R.drawable.ic_volume)
        view.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(210, 30, 30, 30))
            setStroke(d.toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        view.isClickable = true
        view.elevation = 10 * d
        view.visibility = View.GONE
        lp.leftMargin = sp.getInt("vb_ix", -1)
        lp.topMargin = sp.getInt("vb_iy", -1)
        applyStyle()
        root.addView(view, lp)

        val slop = 8 * d
        var downX = 0f
        var downY = 0f
        var startL = 0
        var startT = 0
        var dragging = false
        var rightHandled = false

        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    if (isRight(ev)) {
                        rightHandled = true
                        onRight(ev.rawX.toInt(), ev.rawY.toInt())
                    } else {
                        rightHandled = false
                        downX = ev.rawX
                        downY = ev.rawY
                        startL = lp.leftMargin
                        startT = lp.topMargin
                        v.alpha = baseAlpha() * 0.7f
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!rightHandled) {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (!dragging && (dx * dx + dy * dy) > slop * slop) dragging = true
                        if (dragging) {
                            lp.leftMargin = (startL + dx).toInt().coerceIn(0, (rootW() - lp.width).coerceAtLeast(0))
                            lp.topMargin = (startT + dy).toInt().coerceIn(0, (rootH() - lp.height).coerceAtLeast(0))
                            v.layoutParams = lp
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.alpha = baseAlpha()
                    if (rightHandled) {
                        rightHandled = false
                    } else if (dragging) {
                        sp.edit().putInt("vb_ix", lp.leftMargin).putInt("vb_iy", lp.topMargin).apply()
                    } else {
                        onClick()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    rightHandled = false
                    v.alpha = baseAlpha()
                    true
                }
                else -> false
            }
        }
    }

    /** Tamanho, opacidade e posição (limitada à tela). */
    fun applyStyle() {
        val s = px()
        lp.width = s
        lp.height = s
        view.setPadding(s / 4, s / 4, s / 4, s / 4)
        view.alpha = baseAlpha()
        if (lp.leftMargin < 0) lp.leftMargin = rootW() - s - (16 * d).toInt()
        if (lp.topMargin < 0) lp.topMargin = (rootH() * 0.4f).toInt()
        lp.leftMargin = lp.leftMargin.coerceIn(0, (rootW() - s).coerceAtLeast(0))
        lp.topMargin = lp.topMargin.coerceIn(0, (rootH() - s).coerceAtLeast(0))
        view.layoutParams = lp
    }

    fun setSize(dp: Int) {
        sp.edit().putInt("vb_size", dp.coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)).apply()
        applyStyle()
        sp.edit().putInt("vb_ix", lp.leftMargin).putInt("vb_iy", lp.topMargin).apply()
    }

    fun setAlpha(pct: Int) {
        sp.edit().putInt("vb_alpha", pct.coerceIn(20, 100)).apply()
        view.alpha = baseAlpha()
    }

    /** Mostra ou esconde conforme a opção "Botão de volume flutuante". */
    fun applyVisibility() {
        val on = sp.getBoolean("ui_vol_btn", false)
        view.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            root.post {
                applyStyle()
                view.bringToFront()
            }
        }
    }
}
