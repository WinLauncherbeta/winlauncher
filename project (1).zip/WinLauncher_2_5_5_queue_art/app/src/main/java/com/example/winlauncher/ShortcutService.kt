package com.example.winlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Atalhos de teclado que funcionam DENTRO de outros apps (o Android só entrega teclas ao app em primeiro
 * plano; um serviço de acessibilidade com "filtrar eventos de teclas" é a única forma de ouvi-las).
 *
 * Por enquanto: ALT + V abre o painel de volume do Android. Com o launcher na frente, o próprio
 * MainActivity trata o atalho (painel de volume do launcher), então aqui deixamos passar.
 */
class ShortcutService : AccessibilityService() {

    companion object {
        /** true enquanto o serviço de acessibilidade está ligado nas configurações do Android. */
        @Volatile
        var running = false
    }

    override fun onServiceConnected() {
        running = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_V || !event.isAltPressed ||
            event.isCtrlPressed || event.isMetaPressed || event.isShiftPressed
        ) return false
        val dev = event.device
        if (dev == null || dev.isVirtual || !event.isFromSource(InputDevice.SOURCE_KEYBOARD)) return false
        // launcher na frente: quem trata é a MainActivity
        if (VolumeButtonService.launcherForeground) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) showVolumePanel()
        return true
    }

    private fun showVolumePanel() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_SAME,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (e: Exception) {
        }
    }
}
