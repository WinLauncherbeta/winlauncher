package com.example.winlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.webkit.MimeTypeMap
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Controle de uma operação em segundo plano (copiar, mover, excluir, compactar, extrair). */
class OpCtl {
    @Volatile
    var cancel = false

    @Volatile
    var total = 0

    @Volatile
    var done = 0

    @Volatile
    var current = ""

    @Volatile
    var errors = 0

    @Volatile
    var lastError: String? = null
}

/** Tipos de arquivo (decidem o ícone e o nome do tipo). */
object FKind {
    const val FOLDER = 0
    const val FILE = 1
    const val IMAGE = 2
    const val VIDEO = 3
    const val AUDIO = 4
    const val ARCHIVE = 5
    const val APK = 6
    const val DOC = 7
    const val SHEET = 8
    const val SLIDE = 9
    const val PDF = 10
    const val TEXT = 11

    // ícones das pastas especiais e do computador
    const val S_DOWNLOADS = 20
    const val S_DOCUMENTS = 21
    const val S_PICTURES = 22
    const val S_MUSIC = 23
    const val S_VIDEOS = 24
    const val DRIVE = 25
    const val PC = 26
    const val S_DESKTOP = 27

    private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
    private val VID = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v", "ts", "flv", "wmv")
    private val AUD = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma", "amr", "mid")
    private val ARC = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz")
    private val APKS = setOf("apk", "xapk", "apks", "apkm")
    private val DOCS = setOf("doc", "docx", "odt", "rtf", "dotx")
    private val SHEETS = setOf("xls", "xlsx", "ods", "csv")
    private val SLIDES = setOf("ppt", "pptx", "odp")
    private val TXT = setOf(
        "txt", "log", "md", "json", "xml", "yml", "yaml", "ini", "cfg", "conf", "html", "htm", "css", "js",
        "kt", "kts", "java", "py", "sh", "c", "cpp", "h", "gradle", "properties", "bat", "sql"
    )

    fun ext(name: String): String {
        val i = name.lastIndexOf('.')
        return if (i > 0 && i < name.length - 1) name.substring(i + 1).lowercase(Locale.ROOT) else ""
    }

    fun of(name: String, isDir: Boolean): Int {
        if (isDir) return FOLDER
        val e = ext(name)
        return when {
            e in IMG -> IMAGE
            e in VID -> VIDEO
            e in AUD -> AUDIO
            e in ARC -> ARCHIVE
            e in APKS -> APK
            e in DOCS -> DOC
            e in SHEETS -> SHEET
            e in SLIDES -> SLIDE
            e == "pdf" -> PDF
            e in TXT -> TEXT
            else -> FILE
        }
    }

    fun typeName(name: String, isDir: Boolean): String {
        if (isDir) return "Pasta de arquivos"
        val e = ext(name)
        return if (e.isEmpty()) "Arquivo" else "Arquivo " + e.uppercase(Locale.ROOT)
    }

    fun mime(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(name)) ?: "*/*"
}

object FileOps {

    class Cancelled : Exception()

    const val REPLACE = 0
    const val KEEP_BOTH = 1
    const val SKIP = 2
    const val CANCEL = 3

    private val PT = Locale("pt", "BR")

    // ------------------------------------------------------------------ formatação

    fun fmtSize(b: Long): String {
        if (b < 1024) return "$b bytes"
        val kb = b / 1024.0
        if (kb < 1024) return String.format(PT, if (kb < 10) "%.2f KB" else "%.0f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(PT, if (mb < 10) "%.2f MB" else "%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format(PT, "%.2f GB", gb)
    }

    fun fmtDate(ms: Long): String =
        java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", PT).format(java.util.Date(ms))

    // ------------------------------------------------------------------ nomes

    /** "nome (2).ext" quando já existe um arquivo com esse nome. */
    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 2
        while (true) {
            f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    /** "nome - Cópia.ext", "nome - Cópia (2).ext"... (copiar e colar na mesma pasta). */
    fun copyName(dir: File, name: String): File {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var f = File(dir, "$base - Cópia$ext")
        var i = 2
        while (f.exists()) {
            f = File(dir, "$base - Cópia ($i)$ext")
            i++
        }
        return f
    }

    fun validName(n: String): Boolean {
        val t = n.trim()
        if (t.isEmpty() || t == "." || t == "..") return false
        return !t.contains('/') && !t.contains('\u0000')
    }

    // ------------------------------------------------------------------ contagem

    private fun isLink(f: File): Boolean = try {
        java.nio.file.Files.isSymbolicLink(f.toPath())
    } catch (t: Throwable) {
        false
    }

    /** Quantidade de arquivos (pastas vazias contam 1) para a barra de progresso. */
    fun count(f: File, ctl: OpCtl? = null): Int {
        if (ctl?.cancel == true) throw Cancelled()
        if (f.isDirectory && !isLink(f)) {
            val kids = f.listFiles() ?: return 1
            if (kids.isEmpty()) return 1
            var n = 0
            for (k in kids) n += count(k, ctl)
            return n
        }
        return 1
    }

    /** Tamanho total e quantidade de arquivos/pastas de [f]. Devolve (bytes, arquivos, pastas). */
    fun measure(f: File, ctl: OpCtl): LongArray {
        val r = longArrayOf(0, 0, 0)
        fun walk(x: File) {
            if (ctl.cancel) return
            if (x.isDirectory && !isLink(x)) {
                r[2]++
                x.listFiles()?.forEach { walk(it) }
            } else {
                r[0] += x.length()
                r[1]++
            }
        }
        if (f.isDirectory) {
            f.listFiles()?.forEach { walk(it) }
        } else {
            r[0] = f.length()
            r[1] = 1
        }
        return r
    }

    // ------------------------------------------------------------------ copiar / mover / excluir

    private fun copyStream(src: File, dst: File, ctl: OpCtl) {
        FileInputStream(src).use { i ->
            FileOutputStream(dst).use { o ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (ctl.cancel) throw Cancelled()
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                }
            }
        }
        dst.setLastModified(src.lastModified())
    }

    /** Copia [src] para o caminho final [dst] (pasta: recursivo; arquivos existentes são sobrescritos). */
    fun copy(src: File, dst: File, ctl: OpCtl) {
        if (ctl.cancel) throw Cancelled()
        if (src.isDirectory) {
            if (isLink(src)) return
            if (!dst.exists() && !dst.mkdirs()) throw IOException("Não foi possível criar " + dst.name)
            val kids = src.listFiles() ?: throw IOException("Sem acesso a " + src.name)
            if (kids.isEmpty()) ctl.done++
            for (k in kids) copy(k, File(dst, k.name), ctl)
        } else {
            ctl.current = src.name
            copyStream(src, dst, ctl)
            ctl.done++
        }
    }

    fun deleteTree(f: File, ctl: OpCtl) {
        if (ctl.cancel) throw Cancelled()
        if (f.isDirectory && !isLink(f)) {
            f.listFiles()?.forEach { deleteTree(it, ctl) }
        }
        ctl.current = f.name
        if (!f.delete() && f.exists()) throw IOException("Não foi possível excluir " + f.name)
        ctl.done++
    }

    /** Move [src] para [dst]: tenta renomear (mesmo volume); senão copia e apaga a origem. */
    fun move(src: File, dst: File, ctl: OpCtl) {
        if (ctl.cancel) throw Cancelled()
        val before = ctl.done
        val n = count(src)
        if (src.renameTo(dst)) {
            ctl.current = src.name
            ctl.done = before + n
            return
        }
        copy(src, dst, ctl)
        val sub = OpCtl()
        deleteTree(src, sub)
    }

    // ------------------------------------------------------------------ zip

    fun zip(items: List<File>, out: File, ctl: OpCtl) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
            for (f in items) addToZip(z, f, f.name, ctl, out)
        }
    }

    private fun addToZip(z: ZipOutputStream, f: File, entry: String, ctl: OpCtl, out: File) {
        if (ctl.cancel) throw Cancelled()
        if (f.absolutePath == out.absolutePath) return
        if (f.isDirectory) {
            if (isLink(f)) return
            z.putNextEntry(ZipEntry("$entry/"))
            z.closeEntry()
            f.listFiles()?.forEach { addToZip(z, it, "$entry/${it.name}", ctl, out) }
            ctl.done++
        } else {
            ctl.current = f.name
            val e = ZipEntry(entry)
            e.time = f.lastModified()
            z.putNextEntry(e)
            FileInputStream(f).use { i ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (ctl.cancel) throw Cancelled()
                    val n = i.read(buf)
                    if (n < 0) break
                    z.write(buf, 0, n)
                }
            }
            z.closeEntry()
            ctl.done++
        }
    }

    fun zipCount(items: List<File>): Int {
        var n = 0
        for (f in items) n += count(f) + (if (f.isDirectory) 1 else 0)
        return n
    }

    /** Extrai [zip] em [outDir] (ignora entradas que tentam sair da pasta). */
    fun unzip(zip: File, outDir: File, ctl: OpCtl) {
        val base = outDir.canonicalPath + File.separator
        ZipFile(zip).use { zf ->
            ctl.total = zf.size()
            val en = zf.entries()
            while (en.hasMoreElements()) {
                if (ctl.cancel) throw Cancelled()
                val e = en.nextElement()
                val target = File(outDir, e.name)
                val canon = target.canonicalPath
                if (!canon.startsWith(base) && canon != outDir.canonicalPath) {
                    ctl.done++
                    continue
                }
                ctl.current = target.name
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    zf.getInputStream(e).use { i ->
                        FileOutputStream(target).use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                if (ctl.cancel) throw Cancelled()
                                val n = i.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                            }
                        }
                    }
                    if (e.time > 0) target.setLastModified(e.time)
                }
                ctl.done++
            }
        }
    }

    // ------------------------------------------------------------------ ordenação natural

    /** Ordem "natural" do Windows: arquivo2 vem antes de arquivo10; sem diferenciar maiúsculas. */
    val natural = Comparator<String> { a, b ->
        var i = 0
        var j = 0
        var res = 0
        while (res == 0 && i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                res = if (na.length != nb.length) na.length - nb.length else na.compareTo(nb)
                i = ei
                j = ej
            } else {
                res = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                i++
                j++
            }
        }
        if (res != 0) res else (a.length - i) - (b.length - j)
    }
}

/**
 * Ícones no estilo do Windows 11 desenhados em código (pasta amarela, arquivos por tipo, unidade, pastas
 * especiais). Escalam para qualquer tamanho.
 */
class KindDrawable(private val kind: Int, private val ext: String = "") : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()

    private fun rr(c: Canvas, l: Float, t: Float, rt: Float, b: Float, rad: Float, color: Int) {
        r.set(l, t, rt, b)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
        c.drawRoundRect(r, rad, rad, p)
    }

    private fun grad(c: Canvas, l: Float, t: Float, rt: Float, b: Float, rad: Float, c1: Int, c2: Int) {
        r.set(l, t, rt, b)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, t, 0f, b, c1, c2, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        p.shader = null
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(b.width() / 100f, b.height() / 100f)
        when (kind) {
            FKind.FOLDER -> folder(c, false)
            FKind.ARCHIVE -> folder(c, true)
            FKind.APK -> apk(c)
            FKind.VIDEO -> badge(c, "#7B4FD6", "#9B6BF0") { play(c, Color.WHITE) }
            FKind.AUDIO -> badge(c, "#E4573D", "#F58A5B") { note(c) }
            FKind.IMAGE -> badge(c, "#1E88E5", "#4CC2FF") { mountains(c) }
            FKind.S_DOWNLOADS -> badge(c, "#0FA37F", "#2BD4A8") { arrowDown(c) }
            FKind.S_DOCUMENTS -> badge(c, "#5C7FB5", "#9BB4DC") { lines(c, Color.WHITE) }
            FKind.S_PICTURES -> badge(c, "#1E88E5", "#4CC2FF") { mountains(c) }
            FKind.S_MUSIC -> badge(c, "#E4573D", "#F58A5B") { note(c) }
            FKind.S_VIDEOS -> badge(c, "#7B4FD6", "#9B6BF0") { play(c, Color.WHITE) }
            FKind.S_DESKTOP -> badge(c, "#1E88E5", "#4CC2FF") { lines(c, Color.WHITE) }
            FKind.DRIVE -> drive(c)
            FKind.PC -> pc(c)
            else -> page(c)
        }
        c.restore()
    }

    private fun folder(c: Canvas, zipper: Boolean) {
        rr(c, 6f, 14f, 94f, 86f, 8f, Color.parseColor("#E0A100"))
        rr(c, 6f, 10f, 44f, 30f, 6f, Color.parseColor("#E0A100"))
        grad(c, 6f, 26f, 94f, 88f, 8f, Color.parseColor("#FFE28A"), Color.parseColor("#FFC22E"))
        if (zipper) {
            var y = 26f
            var left = true
            while (y < 80f) {
                rr(c, if (left) 44f else 50f, y, if (left) 50f else 56f, y + 5f, 1.5f, Color.parseColor("#6B6B6B"))
                left = !left
                y += 6f
            }
            rr(c, 42f, 76f, 58f, 88f, 3f, Color.parseColor("#4F4F4F"))
        }
    }

    private fun page(c: Canvas) {
        val body = when (kind) {
            FKind.DOC -> "#2B79D8"
            FKind.SHEET -> "#1E9B5A"
            FKind.SLIDE -> "#D8552B"
            FKind.PDF -> "#D83B3B"
            else -> "#F4F4F4"
        }
        val colored = kind == FKind.DOC || kind == FKind.SHEET || kind == FKind.SLIDE || kind == FKind.PDF
        path.reset()
        path.moveTo(22f, 6f)
        path.lineTo(62f, 6f)
        path.lineTo(80f, 24f)
        path.lineTo(80f, 90f)
        path.quadTo(80f, 94f, 76f, 94f)
        path.lineTo(26f, 94f)
        path.quadTo(22f, 94f, 22f, 90f)
        path.close()
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = Color.parseColor(body)
        c.drawPath(path, p)
        path.reset()
        path.moveTo(62f, 6f)
        path.lineTo(62f, 20f)
        path.quadTo(62f, 24f, 66f, 24f)
        path.lineTo(80f, 24f)
        path.close()
        p.color = Color.parseColor(if (colored) "#33FFFFFF" else "#C9C9C9")
        c.drawPath(path, p)
        val lineColor = if (colored) Color.WHITE else Color.parseColor("#9A9A9A")
        if (kind == FKind.PDF) {
            p.color = Color.WHITE
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = 20f
            c.drawText("PDF", 51f, 66f, p)
        } else {
            for (i in 0..3) {
                rr(c, 32f, 40f + i * 12f, if (i == 3) 52f else 70f, 44f + i * 12f, 2f, lineColor)
            }
        }
    }

    private fun apk(c: Canvas) {
        grad(c, 14f, 38f, 86f, 92f, 8f, Color.parseColor("#F29B3A"), Color.parseColor("#D9741A"))
        rr(c, 40f, 56f, 60f, 62f, 3f, Color.parseColor("#8A4A10"))
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#2E9BE5")
        r.set(26f, 8f, 74f, 56f)
        c.drawArc(r, 180f, 180f, true, p)
        p.color = Color.parseColor("#8FD0FF")
        r.set(38f, 20f, 62f, 44f)
        c.drawArc(r, 180f, 180f, true, p)
    }

    private fun drive(c: Canvas) {
        grad(c, 6f, 40f, 94f, 70f, 10f, Color.parseColor("#E6E6E6"), Color.parseColor("#9A9A9A"))
        rr(c, 6f, 56f, 94f, 72f, 8f, Color.parseColor("#5A5A5A"))
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#3DDC84")
        c.drawCircle(18f, 64f, 3.2f, p)
    }

    private fun pc(c: Canvas) {
        rr(c, 8f, 14f, 92f, 68f, 6f, Color.parseColor("#2F2F2F"))
        grad(c, 12f, 18f, 88f, 64f, 3f, Color.parseColor("#4CC2FF"), Color.parseColor("#0A72D1"))
        rr(c, 42f, 68f, 58f, 80f, 2f, Color.parseColor("#9A9A9A"))
        rr(c, 28f, 80f, 72f, 86f, 3f, Color.parseColor("#BDBDBD"))
    }

    /** Quadrado colorido arredondado com um desenho branco no meio. */
    private fun badge(c: Canvas, top: String, bottom: String, glyph: () -> Unit) {
        grad(c, 10f, 10f, 90f, 90f, 16f, Color.parseColor(bottom), Color.parseColor(top))
        glyph()
    }

    private fun play(c: Canvas, color: Int) {
        path.reset()
        path.moveTo(40f, 30f)
        path.lineTo(72f, 50f)
        path.lineTo(40f, 70f)
        path.close()
        p.style = Paint.Style.FILL
        p.color = color
        c.drawPath(path, p)
    }

    private fun note(c: Canvas) {
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(40f, 68f, 9f, p)
        rr(c, 46f, 26f, 52f, 68f, 2f, Color.WHITE)
        path.reset()
        path.moveTo(52f, 26f)
        path.lineTo(72f, 34f)
        path.lineTo(72f, 46f)
        path.lineTo(52f, 38f)
        path.close()
        c.drawPath(path, p)
    }

    private fun mountains(c: Canvas) {
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        path.reset()
        path.moveTo(18f, 76f)
        path.lineTo(40f, 42f)
        path.lineTo(56f, 62f)
        path.lineTo(66f, 50f)
        path.lineTo(84f, 76f)
        path.close()
        c.drawPath(path, p)
        c.drawCircle(68f, 30f, 6f, p)
    }

    private fun arrowDown(c: Canvas) {
        rr(c, 46f, 24f, 54f, 56f, 2f, Color.WHITE)
        path.reset()
        path.moveTo(30f, 50f)
        path.lineTo(70f, 50f)
        path.lineTo(50f, 72f)
        path.close()
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawPath(path, p)
        rr(c, 28f, 78f, 72f, 83f, 2f, Color.WHITE)
    }

    private fun lines(c: Canvas, color: Int) {
        for (i in 0..3) rr(c, 26f, 28f + i * 12f, if (i == 3) 52f else 74f, 33f + i * 12f, 2f, color)
    }

    override fun setAlpha(a: Int) {
        p.alpha = a
    }

    override fun setColorFilter(f: ColorFilter?) {
        p.colorFilter = f
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getIntrinsicWidth(): Int = 96

    override fun getIntrinsicHeight(): Int = 96
}

/** Provider mínimo que entrega arquivos (somente leitura) a outros apps: abrir com, compartilhar. */
class FileShareProvider : android.content.ContentProvider() {

    companion object {
        fun authority(ctx: Context): String = ctx.packageName + ".files"

        fun uriFor(ctx: Context, f: File): android.net.Uri {
            val b = android.net.Uri.Builder().scheme("content").authority(authority(ctx)).appendPath("files")
            for (seg in f.absolutePath.split('/')) if (seg.isNotEmpty()) b.appendPath(seg)
            return b.build()
        }
    }

    private fun fileOf(uri: android.net.Uri): File? {
        val segs = uri.pathSegments ?: return null
        if (segs.size < 2 || segs[0] != "files") return null
        val f = File("/" + segs.drop(1).joinToString("/"))
        return try {
            val canon = f.canonicalPath
            val ok = canon.startsWith("/storage/") || canon.startsWith("/sdcard/") ||
                canon.startsWith(android.os.Environment.getExternalStorageDirectory().canonicalPath)
            if (ok) f else null
        } catch (t: Throwable) {
            null
        }
    }

    override fun onCreate(): Boolean = true

    override fun query(
        uri: android.net.Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): android.database.Cursor? {
        val f = fileOf(uri) ?: return null
        val cols = projection ?: arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE)
        val row = arrayOfNulls<Any>(cols.size)
        for ((i, c) in cols.withIndex()) {
            row[i] = when (c) {
                android.provider.OpenableColumns.DISPLAY_NAME -> f.name
                android.provider.OpenableColumns.SIZE -> f.length()
                else -> null
            }
        }
        val mc = android.database.MatrixCursor(cols, 1)
        mc.addRow(row)
        return mc
    }

    override fun getType(uri: android.net.Uri): String? = fileOf(uri)?.let { FKind.mime(it.name) }

    override fun openFile(uri: android.net.Uri, mode: String): android.os.ParcelFileDescriptor? {
        val f = fileOf(uri) ?: throw java.io.FileNotFoundException("Arquivo inválido")
        if (!f.isFile) throw java.io.FileNotFoundException("Não é um arquivo")
        return android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun insert(uri: android.net.Uri, values: android.content.ContentValues?): android.net.Uri? = null

    override fun delete(uri: android.net.Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: android.net.Uri,
        values: android.content.ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0
}
