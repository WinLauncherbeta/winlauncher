package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Serviço em primeiro plano (specialUse) que mantém o [RemoteServer] ligado enquanto o usuário quiser.
 *
 * - Liga: [start] (chamado pelo painel). A notificação persistente aparece e o servidor sobe numa thread própria.
 * - Desliga: [stop] (painel) ou o botão "Desligar" da notificação. Os sockets e threads são fechados numa thread
 *   própria; o serviço só termina depois disso.
 * - Falha ao ligar (por exemplo, porta ocupada): o estado fica em ERROR com o motivo, tudo é liberado e o serviço se encerra.
 * - Se o Android matar o serviço, ele NÃO volta sozinho (START_NOT_STICKY).
 * - Início automático (Parte 2): se a opção "ui_remote_autostart" (padrão DESLIGADA) estiver ligada, o launcher chama
 *   [autoStartIfEnabled] ao abrir. Não há receptor de BOOT_COMPLETED: só acontece quando o launcher abre.
 *
 * Etapa 3B, Parte 2: ao ligar, o serviço cria UM [RemoteBridge] e chama attach() (que faz um único start() do
 * MediaSessionHub); ao desligar, em erro e no onDestroy chama detach() (que faz o stop() correspondente). Também segura
 * um WifiLock enquanto o servidor estiver ligado e mostra uma notificação (só informa) quando chega um pedido de pareamento.
 * Tudo isso roda na thread principal; o envio para os sockets sai de threads do bridge.
 *
 * Etapa 3, Bloco 2 (desligar/religar rápido): as decisões de "ligar" e "desligar" passam por um [RemoteLifecycleGate]
 * (lógica pura, testada na JVM). Um "Ligar" durante o desligamento NÃO é ignorado: vira um religamento pendente, executado
 * em [finishStop] com um servidor novo, SEM encerrar o serviço (o primeiro plano continua, então o contrato do Android
 * "startForegroundService() => startForeground()" é cumprido). Um "Desligar" antes de o servidor terminar de ligar cancela
 * o início (o [RemoteServer] não liga depois de ter recebido stop(): nada de servidor órfão escutando). Um "Desligar"
 * enquanto o pedido de "Ligar" ainda não chegou ao serviço cancela esse pedido. A porta ocupada tem novas tentativas
 * curtas dentro do próprio [RemoteServer].
 */
class RemoteServerService : Service() {

    /** Foto do estado, enviada para o painel. */
    class Status(val state: RemoteServer.State, val port: Int, val clients: Int, val error: String)

    companion object {
        const val ACTION_START = "com.example.winlauncher.remote.START"
        const val ACTION_STOP = "com.example.winlauncher.remote.STOP"
        const val PREF_AUTOSTART = "ui_remote_autostart"
        private const val CHANNEL = "remote_server"
        private const val NOTIF_ID = 4715
        private const val PAIR_CHANNEL = "remote_pairing"
        private const val PAIR_NOTIF_ID = 4716

        /** WifiLock está ativo agora? (para o painel) */
        @Volatile
        var wifiLockHeld: Boolean = false
            private set

        @Volatile
        var status: Status = Status(RemoteServer.State.STOPPED, RemoteProtocol.DEFAULT_PORT, 0, "")
            private set

        @Volatile
        private var instance: RemoteServerService? = null

        private val ui = Handler(Looper.getMainLooper())

        /** Decide "ligar"/"desligar" que se cruzam (Etapa 3, Bloco 2). Vale para o processo todo. */
        private val gate = RemoteLifecycleGate()

        private val listeners = CopyOnWriteArrayList<(Status) -> Unit>()
        private val bridgeListeners = CopyOnWriteArrayList<() -> Unit>()
        private val logLines = ArrayList<String>()

        /** Registra quem quer saber das mudanças de estado. O retorno de chamada sempre roda na thread principal. */
        fun addListener(l: (Status) -> Unit) {
            listeners.add(l)
        }

        fun removeListener(l: (Status) -> Unit) {
            listeners.remove(l)
        }

        /** Quer saber quando o pareamento ou a lista de aparelhos muda. O retorno de chamada roda na thread principal. */
        fun addBridgeListener(l: () -> Unit) {
            bridgeListeners.add(l)
        }

        fun removeBridgeListener(l: () -> Unit) {
            bridgeListeners.remove(l)
        }

        private fun notifyBridge() {
            ui.post {
                for (l in bridgeListeners) {
                    try {
                        l()
                    } catch (e: Throwable) {
                    }
                }
            }
        }

        /** Foto do pareamento para o painel (thread principal). null = servidor desligado (sem bridge). */
        fun bridgeInfo(): RemoteBridge.Info? = instance?.bridge?.info()

        /** Abre a janela de pareamento (2 min). false se o servidor não está ligado. Thread principal. */
        fun openPairing(): Boolean = instance?.bridge?.openPairingWindow() ?: false

        fun closePairing() {
            instance?.bridge?.closePairingWindow()
        }

        /** "Permitir" no WinLauncher. false se não há pedido pendente. */
        fun approvePairing(): Boolean = instance?.bridge?.approve() ?: false

        /** "Negar" no WinLauncher. false se não há pedido pendente. */
        fun denyPairing(): Boolean = instance?.bridge?.deny() ?: false

        /**
         * Remove o pareamento (e derruba as conexões desse aparelho, se o servidor estiver ligado). Roda numa thread
         * própria (fechar socket e gravar preferências não devem ficar na principal); [done] volta na thread principal.
         */
        fun revokeDevice(id: String, done: (Boolean) -> Unit) {
            val br = instance?.bridge
            val t = Thread({
                val ok = try {
                    if (br != null) br.revoke(id) else RemoteAuth.removePaired(id)
                } catch (e: Throwable) {
                    false
                }
                ui.post {
                    done(ok)
                    notifyBridge()
                }
            }, "WinRemote-revoke")
            t.isDaemon = true
            t.start()
        }

        /** Chamado pelo launcher ao abrir: liga o servidor só se a opção estiver ligada (padrão: desligada). */
        fun autoStartIfEnabled(ctx: Context) {
            try {
                val on = ctx.applicationContext.getSharedPreferences("win", Context.MODE_PRIVATE).getBoolean(PREF_AUTOSTART, false)
                if (on && !isActive() && instance == null) {
                    addLog("início automático com o launcher")
                    start(ctx)
                }
            } catch (e: Throwable) {
            }
        }

        /** Servidor ligado ou ligando? */
        fun isActive(): Boolean = status.state == RemoteServer.State.STARTING || status.state == RemoteServer.State.RUNNING

        /** Últimas linhas do registro do servidor (para o painel). */
        fun recentLog(): List<String> = synchronized(logLines) { ArrayList(logLines) }

        private fun publish(s: Status) {
            status = s
            ui.post {
                for (l in listeners) {
                    try {
                        l(s)
                    } catch (e: Throwable) {
                    }
                }
            }
        }

        private fun addLog(line: String) {
            synchronized(logLines) {
                logLines.add(line)
                while (logLines.size > 40) logLines.removeAt(0)
            }
        }

        /**
         * Pede para ligar o servidor. Chame na thread principal, com o launcher na frente.
         * Se o servidor está desligando, o pedido NÃO é perdido: o serviço religa assim que o desligamento terminar.
         */
        fun start(ctx: Context) {
            when (gate.requestStart()) {
                RemoteLifecycleGate.StartDecision.ALREADY_ACTIVE -> return
                RemoteLifecycleGate.StartDecision.RESTART_AFTER_STOP -> {
                    addLog("pedido para ligar durante o desligamento: religa assim que terminar")
                    return
                }
                RemoteLifecycleGate.StartDecision.START_NOW -> {
                }
            }
            publish(Status(RemoteServer.State.STARTING, RemoteProtocol.DEFAULT_PORT, 0, ""))
            try {
                val i = Intent(ctx, RemoteServerService::class.java).setAction(ACTION_START)
                ctx.startForegroundService(i)
            } catch (e: Exception) {
                gate.startSendFailed()
                publish(
                    Status(
                        RemoteServer.State.ERROR, RemoteProtocol.DEFAULT_PORT, 0,
                        "não foi possível iniciar o serviço: " + e.javaClass.simpleName + " " + (e.message ?: "")
                    )
                )
            }
        }

        /** Pede para desligar o servidor. Chame na thread principal. */
        fun stop(ctx: Context) {
            val inst = instance
            if (inst != null) {
                inst.shutdown("")
            } else {
                // sem serviço: se um "Ligar" ainda não chegou ao serviço, ele é cancelado (chega e é descartado)
                if (gate.requestStop() == RemoteLifecycleGate.StopDecision.BEGIN_STOP) gate.stopFinished()
                if (status.state != RemoteServer.State.STOPPED) {
                    publish(Status(RemoteServer.State.STOPPED, RemoteProtocol.DEFAULT_PORT, 0, ""))
                }
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    /** Lido também pela thread "starter" (para detectar um desligamento que chegou antes do start()). */
    @Volatile
    private var server: RemoteServer? = null
    private var foreground = false
    private var shuttingDown = false
    private var pendingError = ""

    /** O serviço terminou o desligamento normal (finishStop) e já pediu stopSelf(). */
    private var finished = false

    @Volatile
    private var destroyed = false

    /** Integração com o Hub, pareamento e comandos. Criado ao ligar, solto em [shutdown]/[onDestroy] (thread principal). */
    @Volatile
    private var bridge: RemoteBridge? = null
    private var wifiLock: WifiManager.WifiLock? = null

    @Volatile
    private var clients = 0

    @Volatile
    private var port = RemoteProtocol.DEFAULT_PORT

    /**
     * Avisos de UM servidor. Cada servidor criado ([launchServer]) tem o seu: avisos atrasados de um servidor antigo (por
     * exemplo, um cliente que só terminou de sair depois do religamento) são ignorados e não mexem no servidor novo.
     */
    private inner class ServerEvents : RemoteServer.Events {
        @Volatile
        var owner: RemoteServer? = null

        override fun onState(state: RemoteServer.State, error: String) {
            val o = owner
            handler.post { if (o != null && o === server) onServerState(state, error) }
        }

        override fun onClients(count: Int) {
            val o = owner
            if (o != null && o === server) clients = count
            handler.post { if (o != null && o === server) onServerClients(count) }
        }

        override fun onLog(line: String) {
            addLog(line)
        }
    }

    private val bridgeEvents = object : RemoteBridge.Events {
        override fun onBridgeChanged() {
            notifyBridge()
        }

        override fun onPairingRequest(deviceName: String) {
            if (!shuttingDown) showPairingNotification(deviceName)
        }

        override fun onPairingResolved() {
            cancelPairingNotification()
            notifyBridge()
        }

        override fun onLog(line: String) {
            addLog(line)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            shutdown("")
            return START_NOT_STICKY
        }
        if (action != ACTION_START) {
            // reinício sem pedido do usuário: não liga sozinho
            if (!foreground) stopSelf()
            return START_NOT_STICKY
        }
        val decision = gate.onStartIntent()
        // Contrato do Android: todo startForegroundService() exige startForeground() logo depois, QUALQUER que seja a decisão
        // abaixo (inclusive pedido cancelado ou chegando durante um desligamento). Por isso vem antes de tudo.
        if (!ensureForeground()) {
            if (decision != RemoteLifecycleGate.IntentDecision.LAUNCH) stopSelf()
            return START_NOT_STICKY
        }
        when (decision) {
            RemoteLifecycleGate.IntentDecision.DROP -> {
                addLog("pedido de ligar cancelado por um desligamento posterior")
                if (server == null && !shuttingDown) endWithoutServer()
            }
            RemoteLifecycleGate.IntentDecision.RESTART_AFTER_STOP -> {
                addLog("pedido para ligar durante o desligamento: religa assim que terminar")
            }
            RemoteLifecycleGate.IntentDecision.LAUNCH -> {
                if (server == null && !shuttingDown) launchServer()
            }
        }
        return START_NOT_STICKY
    }

    /** Põe o serviço em primeiro plano (idempotente). false = o Android não permitiu; nesse caso já iniciou o desligamento com erro. */
    private fun ensureForeground(): Boolean {
        if (foreground) return true
        try {
            createChannel()
            val n = buildNotification("Iniciando o servidor…")
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
            foreground = true
            return true
        } catch (e: Exception) {
            val msg = "o Android não permitiu o serviço em primeiro plano: " + e.javaClass.simpleName + " " + (e.message ?: "")
            pendingError = msg
            shutdown(msg)
            return false
        }
    }

    /** Cria o servidor, o bridge e o WifiLock e liga o servidor numa thread própria. Thread principal. */
    private fun launchServer() {
        finished = false
        shuttingDown = false
        pendingError = ""
        clients = 0
        val ev = ServerEvents()
        val srv = RemoteServer(applicationContext, events = ev)
        ev.owner = srv
        server = srv
        // o bridge liga os ganchos do servidor e faz UM start() do Hub ANTES do servidor aceitar conexões
        val br = RemoteBridge(applicationContext, srv, HubPort, "main", events = bridgeEvents)
        bridge = br
        br.attach()
        acquireWifiLock()
        publish(Status(RemoteServer.State.STARTING, port, 0, ""))
        val t = Thread({
            val ok = srv.start()
            // Se o desligamento chegou antes/durante o start(), o RemoteServer já se recusa a ligar (stop() antes do start()
            // cancela). Este stop() extra é só um cinto de segurança: nunca deixa um servidor antigo escutando.
            if (server !== srv) {
                try {
                    srv.stop()
                } catch (e: Throwable) {
                }
            } else if (!ok && srv.state == RemoteServer.State.STOPPED) {
                handler.post {
                    if (!destroyed && server === srv && !shuttingDown) shutdown("o servidor não chegou a ligar")
                }
            }
        }, "WinRemote-starter")
        t.isDaemon = true
        t.start()
    }

    /** Um pedido de ligar foi cancelado e não há servidor: sai do primeiro plano e encerra o serviço. */
    private fun endWithoutServer() {
        try {
            stopForeground(true)
        } catch (e: Exception) {
        }
        foreground = false
        finished = true
        stopSelf()
    }

    // ------------------------------------------------------------------ eventos do servidor (thread principal)

    private fun onServerState(state: RemoteServer.State, error: String) {
        val srv = server ?: return
        if (shuttingDown) return
        when (state) {
            RemoteServer.State.RUNNING -> {
                port = srv.boundPort
                publish(Status(state, port, clients, ""))
                updateNotification()
            }
            RemoteServer.State.ERROR -> {
                // falha ao ligar (ou accept quebrado): libera tudo e mostra o motivo
                shutdown(if (error.isEmpty()) "falha desconhecida no servidor" else error)
            }
            else -> {
            }
        }
    }

    private fun onServerClients(count: Int) {
        if (shuttingDown) return
        val s = status
        if (s.state == RemoteServer.State.RUNNING) {
            publish(Status(s.state, s.port, count, ""))
            updateNotification()
        }
    }

    // ------------------------------------------------------------------ desligamento

    /**
     * Desliga o servidor numa thread própria e só então encerra o serviço (ou religa, se houve "Ligar" no meio do caminho).
     * [error] não vazio = termina em ERROR com esse motivo.
     */
    private fun shutdown(error: String) {
        when (gate.requestStop()) {
            RemoteLifecycleGate.StopDecision.NOTHING -> return
            RemoteLifecycleGate.StopDecision.CANCEL_RESTART -> {
                addLog("religamento cancelado pelo pedido de desligar")
                return
            }
            RemoteLifecycleGate.StopDecision.BEGIN_STOP -> {
            }
        }
        shuttingDown = true
        pendingError = error
        if (error.isEmpty()) publish(Status(RemoteServer.State.STOPPING, port, clients, ""))
        releaseBridgeAndLocks()
        val srv = server
        server = null
        val t = Thread({
            try {
                srv?.stop()
            } catch (e: Throwable) {
                addLog("erro ao desligar: " + e.javaClass.simpleName + " " + (e.message ?: ""))
            }
            handler.post { finishStop() }
        }, "WinRemote-stopper")
        t.isDaemon = true
        t.start()
    }

    private fun finishStop() {
        if (destroyed) return
        releaseBridgeAndLocks()
        val err = pendingError
        if (gate.stopFinished() == RemoteLifecycleGate.FinishDecision.RESTART) {
            // "Ligar" chegou durante o desligamento: liga um servidor NOVO neste mesmo serviço (primeiro plano mantido)
            addLog("religando o servidor (pedido feito durante o desligamento)")
            if (err.isNotEmpty()) addLog("o desligamento anterior terminou com erro: $err")
            shuttingDown = false
            pendingError = ""
            clients = 0
            if (ensureForeground()) {
                updateNotification()
                launchServer()
            }
            return
        }
        try {
            stopForeground(true)
        } catch (e: Exception) {
        }
        foreground = false
        shuttingDown = false
        finished = true
        if (err.isEmpty()) {
            publish(Status(RemoteServer.State.STOPPED, port, 0, ""))
        } else {
            publish(Status(RemoteServer.State.ERROR, port, 0, err))
        }
        stopSelf()
    }

    override fun onDestroy() {
        destroyed = true
        if (instance === this) instance = null
        // se o Android destruir o serviço sem passar pelo desligamento normal, não deixa socket/thread/Hub/WifiLock para trás
        releaseBridgeAndLocks()
        val srv = server
        server = null
        if (srv != null) {
            val t = Thread({
                try {
                    srv.stop()
                } catch (e: Throwable) {
                }
            }, "WinRemote-stopper")
            t.isDaemon = true
            t.start()
        }
        if (!finished) {
            // destruição sem o desligamento normal: o Gate volta a IDLE (um religamento pendente é descartado)
            gate.forceIdle()
            val st = status.state
            if (pendingError.isNotEmpty()) {
                publish(Status(RemoteServer.State.ERROR, port, 0, pendingError))
            } else if (st != RemoteServer.State.ERROR && st != RemoteServer.State.STOPPED) {
                publish(Status(RemoteServer.State.STOPPED, port, 0, ""))
            }
        }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ bridge, WifiLock (thread principal)

    /** Idempotente. detach() do bridge (solta o Hub com o stop() balanceado), solta o WifiLock e some com o aviso de pareamento. */
    private fun releaseBridgeAndLocks() {
        val br = bridge
        bridge = null
        if (br != null) {
            try {
                br.detach()
            } catch (e: Throwable) {
                addLog("erro ao soltar o bridge: " + e.javaClass.simpleName)
            }
        }
        releaseWifiLock()
        cancelPairingNotification()
    }

    private fun acquireWifiLock() {
        if (wifiLock?.isHeld == true) return
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val l = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "WinLauncher:RemoteServer")
            l.setReferenceCounted(false)
            l.acquire()
            wifiLock = l
            wifiLockHeld = l.isHeld
            addLog("WifiLock ativo")
        } catch (e: Throwable) {
            wifiLock = null
            wifiLockHeld = false
            addLog("não foi possível ativar o WifiLock: " + e.javaClass.simpleName)
        }
    }

    private fun releaseWifiLock() {
        val l = wifiLock
        wifiLock = null
        wifiLockHeld = false
        if (l != null) {
            try {
                if (l.isHeld) l.release()
                addLog("WifiLock liberado")
            } catch (e: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ notificação

    /**
     * Avisa que um aparelho pediu pareamento. SÓ informa: não tem botões de aprovar e NÃO mostra o número (a tela
     * bloqueada ou outro app poderiam vê-lo). A aprovação é feita dentro do WinLauncher, comparando o número nos dois celulares.
     */
    private fun showPairingNotification(deviceName: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(PAIR_CHANNEL, "Pedidos de pareamento do Remote", NotificationManager.IMPORTANCE_HIGH)
            )
            val open = PendingIntent.getActivity(
                this, 3,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, PAIR_CHANNEL)
                .setSmallIcon(R.drawable.ic_lock)
                .setContentTitle("Pedido de pareamento")
                .setContentText("\"" + deviceName + "\" quer parear com este aparelho.")
                .setStyle(
                    Notification.BigTextStyle().bigText(
                        "\"" + deviceName + "\" quer parear com este aparelho. Abra o WinLauncher > Configurações > Rede e Internet > " +
                            "Servidor do WinLauncher Remote, confira o número e toque em Permitir ou Negar."
                    )
                )
                .setContentIntent(open)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setTimeoutAfter(RemoteBridge.PENDING_MS)
                .build()
            nm.notify(PAIR_NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    private fun cancelPairingNotification() {
        try {
            getSystemService(NotificationManager::class.java).cancel(PAIR_NOTIF_ID)
        } catch (e: Exception) {
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Servidor do WinLauncher Remote", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, RemoteServerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_lock)
            .setContentTitle("Servidor do WinLauncher Remote ativo")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, "Desligar", stop).build())
            .build()
    }

    private fun updateNotification() {
        if (!foreground) return
        try {
            val ip = RemoteServer.localAddresses().firstOrNull()?.first
            val where = if (ip != null) "$ip:$port" else "porta $port"
            val txt = where + " · " + clients + (if (clients == 1) " cliente conectado" else " clientes conectados")
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(txt))
        } catch (e: Exception) {
        }
    }
}
