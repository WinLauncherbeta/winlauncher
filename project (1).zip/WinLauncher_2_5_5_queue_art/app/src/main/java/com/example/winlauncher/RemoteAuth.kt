package com.example.winlauncher

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyInfo
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.X509Certificate
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.ECGenParameterSpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.net.ssl.KeyManager
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.X509KeyManager
import javax.security.auth.x500.X500Principal

/**
 * Identidade e autenticação do servidor do WinLauncher Remote.
 *
 * Etapa 3A: chave + certificado autoassinado no Android Keystore (EC P-256, com RSA 2048 como alternativa),
 * hash SHA-256 do certificado, número de pareamento, tokens e cadastro de aparelhos pareados (só o hash do token
 * é guardado), mais um autoteste. NÃO existe servidor TLS aqui: o SSLContext é apenas criado para teste.
 *
 * Os dados do Remote ficam num arquivo de preferências próprio ("win_remote"), separado do "win" do launcher.
 * Se a chave for regenerada (ou desaparecer, por exemplo depois de restaurar um backup), todos os pareamentos
 * são apagados automaticamente: os celulares precisam ser pareados de novo.
 */
object RemoteAuth {

    const val ALIAS = "winlauncher_remote_server"
    private const val PROVIDER = "AndroidKeyStore"
    private const val PREFS = "win_remote"
    private const val K_FP = "key_fp"
    private const val K_EC_ERR = "key_ec_error"
    private const val K_CREATED = "key_created_ms"
    private const val K_PAIRED = "paired_json"
    private const val K_LAST_REGEN = "last_regen"
    private const val TAG = "WinRemoteAuth"
    private const val VALID_DAYS = 3650L
    private const val SUBJECT = "CN=WinLauncher Remote, O=WinLauncher"

    private var appCtx: Context? = null
    private val rnd = SecureRandom()

    /** Precisa ser chamado antes de qualquer outra função (pode ser chamado várias vezes). */
    fun init(ctx: Context) {
        if (appCtx == null) appCtx = ctx.applicationContext
    }

    private fun sp(): SharedPreferences {
        val c = appCtx ?: throw IllegalStateException("RemoteAuth.init() não foi chamado")
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    // ------------------------------------------------------------------ resultados

    class KeyReport(
        /** "EC P-256" ou "RSA 2048". */
        val algorithm: String,
        /** true = o EC P-256 não funcionou neste aparelho e foi usado RSA 2048. */
        val usedFallback: Boolean,
        /** Motivo da falha do EC (só quando usedFallback). */
        val fallbackReason: String,
        /** Onde a chave mora (hardware seguro, StrongBox ou software). */
        val securityLevel: String,
        /** SHA-256 do certificado (DER), 32 bytes. */
        val fingerprint: ByteArray,
        val notBefore: Date,
        val notAfter: Date,
        /** O certificado é autoassinado e a assinatura dele confere. */
        val selfSigned: Boolean,
        /** A chave foi criada nesta chamada. */
        val createdNow: Boolean,
        /** Quantos pareamentos foram apagados por causa de chave nova/ausente. */
        val pairingsCleared: Int
    )

    /** Prova de uma regeneração bem-sucedida (se algum passo falhar, regenerate() lança exceção com o motivo). */
    class RegenReport(
        /** Hash do certificado antigo (null = não havia chave). */
        val oldFingerprint: ByteArray?,
        val oldSerial: String?,
        /** A nova chave, lida de novo do Keystore depois de criada. */
        val key: KeyReport,
        val newSerial: String,
        val pairingsBefore: Int,
        val pairingsAfter: Int
    )

    class Check(val name: String, val ok: Boolean, val detail: String, val essential: Boolean = true)

    class SelfTestResult(val checks: List<Check>, val report: KeyReport?) {
        val essentialOk: Boolean get() = checks.filter { it.essential }.all { it.ok }
    }

    private class SigResult(val signed: Boolean, val verified: Boolean, val tamperRejected: Boolean, val error: String)

    class SslReport(val ok: Boolean, val detail: String, val protocols: String, val keyManagerAlias: String)

    class Paired(val id: String, val name: String, val tokenHash: String, val createdMs: Long)

    // ------------------------------------------------------------------ utilidades

    fun hex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) sb.append(String.format(Locale.ROOT, "%02x", x.toInt() and 0xff))
        return sb.toString()
    }

    private fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    /** SHA-256 do certificado inteiro (DER). */
    fun fingerprint(cert: X509Certificate): ByteArray = sha256(cert.encoded)

    /** "AB:CD:..." em duas linhas de 16 bytes. */
    fun formatFingerprint(fp: ByteArray): String {
        val sb = StringBuilder()
        for (i in fp.indices) {
            if (i > 0) sb.append(if (i % 16 == 0) '\n' else ':')
            sb.append(String.format(Locale.ROOT, "%02X", fp[i].toInt() and 0xff))
        }
        return sb.toString()
    }

    /** Primeiros 6 bytes, para mostrar em pouco espaço. */
    fun shortFingerprint(fp: ByteArray): String {
        val n = minOf(6, fp.size)
        val sb = StringBuilder()
        for (i in 0 until n) {
            if (i > 0) sb.append(':')
            sb.append(String.format(Locale.ROOT, "%02X", fp[i].toInt() and 0xff))
        }
        return sb.toString()
    }

    private fun fmtDate(d: Date): String = SimpleDateFormat("dd/MM/yyyy", Locale.ROOT).format(d)

    private fun loadKs(): KeyStore {
        val ks = KeyStore.getInstance(PROVIDER)
        ks.load(null)
        return ks
    }

    private fun certOrNull(): X509Certificate? {
        return try {
            loadKs().getCertificate(ALIAS) as? X509Certificate
        } catch (e: Exception) {
            null
        }
    }

    private fun algorithmOf(cert: X509Certificate): String {
        val pk = cert.publicKey
        return when (pk) {
            is ECPublicKey -> "EC P-" + pk.params.curve.field.fieldSize
            is RSAPublicKey -> "RSA " + pk.modulus.bitLength()
            else -> pk.algorithm
        }
    }

    @Suppress("DEPRECATION")
    private fun securityLevel(): String {
        return try {
            val key = loadKs().getKey(ALIAS, null) as PrivateKey
            val kf = KeyFactory.getInstance(key.algorithm, PROVIDER)
            val info = kf.getKeySpec(key, KeyInfo::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                when (info.securityLevel) {
                    KeyProperties.SECURITY_LEVEL_STRONGBOX -> "StrongBox (hardware dedicado)"
                    KeyProperties.SECURITY_LEVEL_TRUSTED_ENVIRONMENT -> "hardware seguro (TEE)"
                    KeyProperties.SECURITY_LEVEL_SOFTWARE -> "software (sem hardware seguro)"
                    else -> "nível desconhecido (${info.securityLevel})"
                }
            } else {
                if (info.isInsideSecureHardware) "hardware seguro (TEE)" else "software (sem hardware seguro)"
            }
        } catch (e: Throwable) {
            "não foi possível consultar (" + e.javaClass.simpleName + ")"
        }
    }

    // ------------------------------------------------------------------ chave no Keystore

    private fun generate(ec: Boolean) {
        val now = System.currentTimeMillis()
        val day = 24L * 3600L * 1000L
        val b = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
            .setCertificateSubject(X500Principal(SUBJECT))
            .setCertificateSerialNumber(BigInteger(64, rnd).add(BigInteger.ONE))
            .setCertificateNotBefore(Date(now - day))
            .setCertificateNotAfter(Date(now + VALID_DAYS * day))
            // DIGEST_NONE: alguns Androids assinam o handshake TLS sem pré-hash
            .setDigests(
                KeyProperties.DIGEST_NONE,
                KeyProperties.DIGEST_SHA256,
                KeyProperties.DIGEST_SHA384,
                KeyProperties.DIGEST_SHA512
            )
        if (ec) {
            b.setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
        } else {
            b.setKeySize(2048)
            b.setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1, KeyProperties.SIGNATURE_PADDING_RSA_PSS)
        }
        val kpg = KeyPairGenerator.getInstance(
            if (ec) KeyProperties.KEY_ALGORITHM_EC else KeyProperties.KEY_ALGORITHM_RSA,
            PROVIDER
        )
        kpg.initialize(b.build())
        kpg.generateKeyPair()
    }

    private fun deleteKey() {
        try {
            val ks = loadKs()
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        } catch (e: Throwable) {
        }
    }

    /** Apaga o alias e CONFIRMA (com uma instância nova do Keystore) que ele não existe mais. Lança exceção se continuar lá. */
    private fun deleteKeyStrict() {
        var err: Throwable? = null
        try {
            val ks = loadKs()
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        } catch (e: Throwable) {
            err = e
        }
        val still = try {
            loadKs().containsAlias(ALIAS)
        } catch (e: Throwable) {
            true
        }
        if (still) {
            val why = if (err != null) " (" + err.javaClass.simpleName + ": " + (err.message ?: "") + ")" else ""
            throw IllegalStateException("a chave antiga continua no Keystore depois de apagar$why")
        }
    }

    /** Assina dados aleatórios com a chave privada, confere com a pública do certificado e testa que dado alterado é recusado. */
    private fun signAndVerify(): SigResult {
        var signed = false
        var verified = false
        var rejected = false
        return try {
            val ks = loadKs()
            val key = ks.getKey(ALIAS, null) as? PrivateKey
                ?: return SigResult(false, false, false, "chave privada ausente no Keystore")
            val cert = ks.getCertificate(ALIAS) as? X509Certificate
                ?: return SigResult(false, false, false, "certificado ausente no Keystore")
            val alg = if (key.algorithm == "EC") "SHA256withECDSA" else "SHA256withRSA"
            val data = ByteArray(64)
            rnd.nextBytes(data)

            val s = Signature.getInstance(alg)
            s.initSign(key)
            s.update(data)
            val sig = s.sign()
            signed = sig.isNotEmpty()

            val v1 = Signature.getInstance(alg)
            v1.initVerify(cert.publicKey)
            v1.update(data)
            verified = v1.verify(sig)

            val bad = data.copyOf()
            bad[0] = (bad[0].toInt() xor 1).toByte()
            val v2 = Signature.getInstance(alg)
            v2.initVerify(cert.publicKey)
            v2.update(bad)
            rejected = !v2.verify(sig)

            SigResult(signed, verified, rejected, "")
        } catch (e: Throwable) {
            SigResult(signed, verified, rejected, e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }

    private fun selfSignedOk(cert: X509Certificate): Boolean {
        return try {
            cert.verify(cert.publicKey)
            cert.subjectX500Principal == cert.issuerX500Principal
        } catch (e: Throwable) {
            false
        }
    }

    /** Compara o certificado atual com o registrado; se mudou (ou sumiu), apaga os pareamentos. Devolve quantos apagou. */
    private fun syncPairings(cert: X509Certificate?): Int {
        val p = sp()
        if (cert == null) {
            val n = clearPaired()
            p.edit().remove(K_FP).apply()
            return n
        }
        val fp = hex(fingerprint(cert))
        val stored = p.getString(K_FP, "") ?: ""
        if (stored == fp) return 0
        val n = clearPaired()
        p.edit().putString(K_FP, fp).apply()
        return n
    }

    private fun report(cert: X509Certificate, createdNow: Boolean, cleared: Int): KeyReport {
        val isRsa = cert.publicKey is RSAPublicKey
        return KeyReport(
            algorithm = algorithmOf(cert),
            usedFallback = isRsa,
            fallbackReason = if (isRsa) (sp().getString(K_EC_ERR, "") ?: "") else "",
            securityLevel = securityLevel(),
            fingerprint = fingerprint(cert),
            notBefore = cert.notBefore,
            notAfter = cert.notAfter,
            selfSigned = selfSignedOk(cert),
            createdNow = createdNow,
            pairingsCleared = cleared
        )
    }

    private fun createKey(): KeyReport {
        deleteKey()
        var ecError = ""
        var ecOk = false
        try {
            generate(true)
            val r = signAndVerify()
            if (r.signed && r.verified) {
                ecOk = true
            } else {
                ecError = "EC gerado, mas assinar/verificar falhou" + (if (r.error.isNotEmpty()) " (" + r.error + ")" else "")
            }
        } catch (e: Throwable) {
            ecError = e.javaClass.simpleName + ": " + (e.message ?: "")
        }
        if (!ecOk) {
            deleteKey()
            generate(false) // se o RSA também falhar, a exceção sobe para quem chamou
        }
        sp().edit()
            .putString(K_EC_ERR, if (ecOk) "" else ecError)
            .putLong(K_CREATED, System.currentTimeMillis())
            .apply()
        val cert = certOrNull() ?: throw IllegalStateException("a chave foi criada, mas o certificado não foi encontrado")
        val cleared = syncPairings(cert)
        return report(cert, true, cleared)
    }

    /** Usa a chave existente ou cria uma (EC P-256; se falhar, RSA 2048). Lança exceção se nada funcionar. */
    @Synchronized
    fun ensureKey(): KeyReport {
        val existing = certOrNull()
        if (existing != null) {
            val cleared = syncPairings(existing)
            return report(existing, false, cleared)
        }
        return createKey()
    }

    /** Só consulta (não cria nada). null = ainda não existe chave. */
    @Synchronized
    fun inspect(): KeyReport? {
        val existing = certOrNull()
        val cleared = syncPairings(existing)
        return if (existing == null) null else report(existing, false, cleared)
    }

    /** Lançada por [regenerate] quando o servidor Remote está ligado/ligando/desligando. Nada foi alterado. */
    class RegenBlockedException(message: String) : IllegalStateException(message)

    /** Só para o autoteste: simula o estado do servidor. null = usar o estado real do serviço. */
    @Volatile
    private var testServerState: RemoteServer.State? = null

    /**
     * Motivo pelo qual a regeneração está proibida agora, ou null se está liberada. Consulta o estado REAL do servidor
     * ([RemoteServerService.status]); a chave está em uso em STARTING, RUNNING e também em STOPPING (sockets ainda fechando).
     */
    fun regenBlockedReason(): String? {
        val st = testServerState ?: RemoteServerService.status.state
        return when (st) {
            RemoteServer.State.STARTING, RemoteServer.State.RUNNING, RemoteServer.State.STOPPING ->
                "O servidor do WinLauncher Remote está ligado. Desligue o servidor primeiro para regenerar a chave."
            else -> null
        }
    }

    /**
     * Apaga a chave e cria outra. TODOS os pareamentos anteriores deixam de valer (são apagados).
     * Só é chamada pelo botão "Regenerar chave" (nunca automaticamente).
     *
     * Confirma cada passo e lança exceção (com o motivo) se algum falhar:
     * 1) o alias antigo sai do Keystore (conferido com uma instância nova);
     * 2) uma nova chave é gerada e o certificado é lido DE NOVO do Keystore;
     * 3) o hash do certificado novo é diferente do antigo;
     * 4) nenhum pareamento antigo sobra.
     * Se falhar depois de apagar a chave antiga, os pareamentos também são apagados (não valem mais).
     */
    @Synchronized
    fun regenerate(): RegenReport {
        // proteção na camada de dados: recusa ANTES de tocar na chave ou nos pareamentos
        regenBlockedReason()?.let { throw RegenBlockedException(it) }
        val oldCert = certOrNull()
        val oldFp = if (oldCert != null) fingerprint(oldCert) else null
        val oldSerial = oldCert?.serialNumber?.toString(16)
        val before = pairedList().size
        Log.i(TAG, "regenerate: início; chave antiga existe=" + (oldCert != null) + "; pareamentos=" + before)

        // se não conseguir nem apagar, nada mudou: chave e pareamentos continuam como estavam
        deleteKeyStrict()
        Log.i(TAG, "regenerate: alias antigo apagado e confirmado")

        try {
            val key = createKey()
            val newCert = certOrNull() ?: throw IllegalStateException("a nova chave foi criada, mas o certificado não foi encontrado")
            val newFp = fingerprint(newCert)
            if (oldFp != null && MessageDigest.isEqual(oldFp, newFp)) {
                throw IllegalStateException("a chave foi recriada, mas o hash do certificado não mudou")
            }
            if (pairedList().isNotEmpty()) clearPaired()
            val after = pairedList().size
            if (after != 0) throw IllegalStateException("$after pareamento(s) antigo(s) não foram apagados")

            val oldShort = if (oldFp != null) shortFingerprint(oldFp) else "—"
            sp().edit()
                .putString(K_FP, hex(newFp))
                .putString(
                    K_LAST_REGEN,
                    System.currentTimeMillis().toString() + "|" + oldShort + "|" + shortFingerprint(newFp) + "|" + key.algorithm
                )
                .apply()
            Log.i(TAG, "regenerate: concluído; " + oldShort + " -> " + shortFingerprint(newFp) + " (" + key.algorithm + ")")
            return RegenReport(oldFp, oldSerial, key, newCert.serialNumber.toString(16), before, after)
        } catch (e: Throwable) {
            // a chave antiga já não existe: os pareamentos antigos não valem mais
            try {
                clearPaired()
                sp().edit().remove(K_FP).apply()
            } catch (x: Throwable) {
            }
            Log.e(TAG, "regenerate: falhou", e)
            throw e
        }
    }

    /** Texto da última regeneração bem-sucedida ("data — hash antigo… → hash novo… (algoritmo)"), ou null. */
    fun lastRegenInfo(): String? {
        val p = (sp().getString(K_LAST_REGEN, "") ?: "").split("|")
        if (p.size < 4) return null
        val ms = p[0].toLongOrNull() ?: return null
        return SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ROOT).format(Date(ms)) +
            " — " + p[1] + "… → " + p[2] + "… (" + p[3] + ")"
    }

    // ------------------------------------------------------------------ SSLContext (apenas teste de criação)

    private fun keyManagers(): Array<KeyManager> {
        val ks = loadKs()
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, null)
        return kmf.keyManagers
    }

    /** SSLContext de servidor usando a chave do Keystore. Ainda não é usado por nenhum servidor (Etapa 3B). */
    fun buildServerSslContext(): SSLContext {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(keyManagers(), null, rnd)
        return ctx
    }

    /** Cria o SSLContext e um SSLEngine só para listar protocolos. Não faz handshake nem abre conexão. */
    fun testSslContext(): SslReport {
        return try {
            val kms = keyManagers()
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(kms, null, rnd)
            val engine = ctx.createSSLEngine()
            val protos = engine.enabledProtocols.joinToString(", ")
            val keyType = if (certOrNull()?.publicKey is RSAPublicKey) "RSA" else "EC"
            val alias = kms.filterIsInstance<X509KeyManager>().firstOrNull()?.chooseServerAlias(keyType, null, null)
            SslReport(true, "SSLContext criado (${ctx.protocol})", protos, alias ?: "")
        } catch (e: Throwable) {
            SslReport(false, e.javaClass.simpleName + ": " + (e.message ?: ""), "", "")
        }
    }

    // ------------------------------------------------------------------ pareamento

    /**
     * Número que os dois celulares mostram para o usuário comparar. Depende do hash do certificado que CADA lado
     * enxerga e dos dois nonces: se alguém interceptar a conexão com outro certificado, os números ficam diferentes.
     */
    fun pairingCode(serverFp: ByteArray, clientNonce: String, serverNonce: String): String {
        val d = sha256(("WLR1|pair|" + hex(serverFp) + "|" + clientNonce + "|" + serverNonce).toByteArray(Charsets.UTF_8))
        val n = ((d[0].toLong() and 0xff) shl 24) or ((d[1].toLong() and 0xff) shl 16) or
            ((d[2].toLong() and 0xff) shl 8) or (d[3].toLong() and 0xff)
        return String.format(Locale.ROOT, "%06d", n % 1_000_000L)
    }

    /** "123456" -> "123 456". */
    fun formatCode(code: String): String = if (code.length == 6) code.substring(0, 3) + " " + code.substring(3) else code

    fun newNonce(): String {
        val b = ByteArray(RemoteProtocol.NONCE_BYTES)
        rnd.nextBytes(b)
        return RemoteProtocol.b64(b)
    }

    fun newToken(): String {
        val b = ByteArray(RemoteProtocol.TOKEN_BYTES)
        rnd.nextBytes(b)
        return RemoteProtocol.b64(b)
    }

    fun hashToken(token: String): String = hex(sha256(token.toByteArray(Charsets.UTF_8)))

    fun tokenMatches(token: String, storedHash: String): Boolean =
        MessageDigest.isEqual(hashToken(token).toByteArray(Charsets.UTF_8), storedHash.toByteArray(Charsets.UTF_8))

    // ------------------------------------------------------------------ aparelhos pareados (só o hash do token)

    @Synchronized
    fun pairedList(): List<Paired> {
        val out = ArrayList<Paired>()
        try {
            val arr = JSONArray(sp().getString(K_PAIRED, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id", "")
                val hash = o.optString("hash", "")
                if (id.isEmpty() || hash.isEmpty()) continue
                out.add(Paired(id, o.optString("name", ""), hash, o.optLong("created", 0L)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun savePaired(list: List<Paired>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("hash", p.tokenHash)
            o.put("created", p.createdMs)
            arr.put(o)
        }
        sp().edit().putString(K_PAIRED, arr.toString()).apply()
    }

    /** Registra (ou substitui) um aparelho pareado. Só o hash do token é guardado. */
    @Synchronized
    fun addPaired(id: String, name: String, token: String) {
        val list = pairedList().filter { it.id != id }.toMutableList()
        list.add(Paired(id, RemoteProtocol.clip(name, RemoteProtocol.MAX_NAME), hashToken(token), System.currentTimeMillis()))
        savePaired(list)
    }

    @Synchronized
    fun removePaired(id: String): Boolean {
        val list = pairedList()
        val rest = list.filter { it.id != id }
        if (rest.size == list.size) return false
        savePaired(rest)
        return true
    }

    @Synchronized
    fun verifyPaired(id: String, token: String): Boolean {
        val p = pairedList().firstOrNull { it.id == id } ?: return false
        return tokenMatches(token, p.tokenHash)
    }

    /** Apaga todos os pareamentos. Devolve quantos existiam. */
    @Synchronized
    fun clearPaired(): Int {
        val n = pairedList().size
        sp().edit().remove(K_PAIRED).apply()
        return n
    }

    // ------------------------------------------------------------------ autoteste

    private fun pairingLogicTest(): String? {
        return try {
            val fp = ByteArray(32) { 0x11 }
            val fp2 = ByteArray(32) { 0x12 }
            val na = RemoteProtocol.b64(ByteArray(RemoteProtocol.NONCE_BYTES) { 0x22 })
            val nb = RemoteProtocol.b64(ByteArray(RemoteProtocol.NONCE_BYTES) { 0x33 })
            val c1 = pairingCode(fp, na, nb)
            val c2 = pairingCode(fp, na, nb)
            if (c1.length != 6 || !c1.all { it in '0'..'9' }) return "número de pareamento fora do formato: $c1"
            if (c1 != c2) return "número de pareamento não é determinístico"
            if (pairingCode(fp2, na, nb) == c1) return "número não muda quando o hash do certificado muda"

            val t = newToken()
            val raw = RemoteProtocol.unb64(t)
            if (raw == null || raw.size != RemoteProtocol.TOKEN_BYTES) return "token gerado fora do formato"
            val h = hashToken(t)
            if (!tokenMatches(t, h)) return "token válido foi recusado"
            if (tokenMatches(t, hashToken(newToken()))) return "token errado foi aceito"
            if (tokenMatches(t, h.substring(0, h.length - 1) + (if (h.last() == '0') '1' else '0'))) return "hash alterado foi aceito"
            val nonce = newNonce()
            val nr = RemoteProtocol.unb64(nonce)
            if (nr == null || nr.size != RemoteProtocol.NONCE_BYTES) return "nonce gerado fora do formato"
            null
        } catch (e: Throwable) {
            e.javaClass.simpleName + ": " + (e.message ?: "")
        }
    }

    /**
     * Teste não destrutivo da proteção contra regeneração (nunca regenera de verdade: apagaria a chave e os pareamentos).
     * Devolve null se tudo certo, ou o motivo da falha.
     */
    private fun regenGuardTest(): String? {
        val saved = testServerState
        try {
            val fpBefore = certOrNull()?.let { hex(fingerprint(it)) }
            val pairedBefore = pairedList().map { it.id + ":" + it.tokenHash }
            for (st in listOf(RemoteServer.State.STARTING, RemoteServer.State.RUNNING, RemoteServer.State.STOPPING)) {
                testServerState = st
                if (regenBlockedReason() == null) return "a proteção não bloqueou com o servidor em $st"
                var blocked = false
                try {
                    regenerate()
                } catch (e: RegenBlockedException) {
                    blocked = true
                }
                if (!blocked) return "regenerate() não recusou com o servidor em $st"
            }
            val fpAfter = certOrNull()?.let { hex(fingerprint(it)) }
            if (fpBefore != fpAfter) return "a chave mudou mesmo com a regeneração bloqueada"
            if (pairedBefore != pairedList().map { it.id + ":" + it.tokenHash }) return "os pareamentos mudaram com a regeneração bloqueada"
            for (st in listOf(RemoteServer.State.STOPPED, RemoteServer.State.ERROR)) {
                testServerState = st
                if (regenBlockedReason() != null) return "a proteção bloqueou com o servidor em $st (deveria liberar)"
            }
            return null
        } catch (e: Throwable) {
            return e.javaClass.simpleName + ": " + (e.message ?: "")
        } finally {
            testServerState = saved
        }
    }

    /**
     * Executa todos os testes da Etapa 3A. Pode demorar (gerar chave); chame fora da thread principal.
     * Itens "essenciais" decidem o resultado; os demais (ℹ/⚠) são só informativos.
     */
    fun selfTest(): SelfTestResult {
        val checks = ArrayList<Check>()
        val skipped = "não executado (a chave não está disponível)"

        // 1) chave no Keystore
        var rep: KeyReport? = null
        try {
            val r = ensureKey()
            rep = r
            val how = if (r.createdNow) "chave criada agora" else "chave já existia"
            val fb = if (r.usedFallback) {
                " — alternativa RSA em uso; EC P-256 falhou: " + (if (r.fallbackReason.isEmpty()) "motivo não registrado" else r.fallbackReason)
            } else {
                ""
            }
            checks.add(Check("Chave no Android Keystore", true, r.algorithm + ", " + how + fb))
        } catch (e: Throwable) {
            checks.add(Check("Chave no Android Keystore", false, e.javaClass.simpleName + ": " + (e.message ?: "")))
        }

        val rp = rep
        if (rp == null) {
            checks.add(Check("Certificado autoassinado e hash SHA-256", false, skipped))
            checks.add(Check("Assinatura com a chave privada", false, skipped))
            checks.add(Check("Verificação com a chave pública", false, skipped))
            checks.add(Check("SSLContext inicializado com a chave", false, skipped))
        } else {
            // 2) certificado
            val now = Date()
            val validNow = !now.before(rp.notBefore) && !now.after(rp.notAfter)
            checks.add(
                Check(
                    "Certificado autoassinado e hash SHA-256",
                    rp.selfSigned && validNow && rp.fingerprint.size == 32,
                    (if (rp.selfSigned) "autoassinatura confere" else "autoassinatura NÃO confere") +
                        "; válido de " + fmtDate(rp.notBefore) + " até " + fmtDate(rp.notAfter) +
                        (if (validNow) "" else " (fora da validade!)") +
                        "; SHA-256 " + shortFingerprint(rp.fingerprint) + "…"
                )
            )

            // 3) e 4) assinatura e verificação
            val sv = signAndVerify()
            checks.add(
                Check(
                    "Assinatura com a chave privada",
                    sv.signed,
                    if (sv.signed) "assinatura gerada" else (if (sv.error.isEmpty()) "falhou" else sv.error)
                )
            )
            checks.add(
                Check(
                    "Verificação com a chave pública",
                    sv.signed && sv.verified && sv.tamperRejected,
                    when {
                        !sv.signed -> "não executado (sem assinatura)"
                        !sv.verified -> "assinatura legítima foi recusada"
                        !sv.tamperRejected -> "dado alterado foi aceito (grave)"
                        else -> "assinatura legítima aceita; dado alterado recusado"
                    }
                )
            )

            // 5) SSLContext
            val ssl = testSslContext()
            checks.add(
                Check(
                    "SSLContext inicializado com a chave",
                    ssl.ok,
                    if (ssl.ok) "criado com sucesso (isto NÃO prova que um servidor TLS funciona; o handshake real fica para a Etapa 3B)" else ssl.detail
                )
            )

            // informativos
            checks.add(Check("Local da chave", true, rp.securityLevel, essential = false))
            checks.add(
                Check(
                    "Protocolos TLS habilitados neste aparelho",
                    ssl.protocols.isNotEmpty(),
                    if (ssl.protocols.isEmpty()) "não foi possível listar" else ssl.protocols,
                    essential = false
                )
            )
            checks.add(
                Check(
                    "Gerenciador de chaves enxerga a chave",
                    ssl.keyManagerAlias.isNotEmpty(),
                    if (ssl.keyManagerAlias.isNotEmpty()) "alias: " + ssl.keyManagerAlias
                    else "nenhum alias devolvido (informativo; só o handshake da Etapa 3B confirma)",
                    essential = false
                )
            )
            if (rp.pairingsCleared > 0) {
                checks.add(
                    Check(
                        "Pareamentos apagados",
                        false,
                        "${rp.pairingsCleared} pareamento(s) deixaram de valer porque a chave mudou ou sumiu; será preciso parear de novo",
                        essential = false
                    )
                )
            }
        }

        // 6) lógica do protocolo e do pareamento (não depende do Keystore)
        val proto = RemoteProtocol.selfTest()
        checks.add(Check("Protocolo: codificar, decodificar e validar", proto == null, proto ?: "todas as mensagens e rejeições OK"))
        val mouseProto = RemoteProtocol.selfTestMouse()
        checks.add(
            Check(
                "Mouse Flow: protocolo (codificar, decodificar e compatibilidade)",
                mouseProto == null,
                mouseProto ?: "mouse_sub/mouse_state/mouse, caps no hello, limites e quadros no formato antigo OK"
            )
        )
        val queueProto = RemoteProtocol.selfTestQueue()
        checks.add(
            Check(
                "Fila de reprodução: protocolo (janela, limite de quadro, rejeições e compatibilidade)",
                queueProto == null,
                queueProto ?: "mensagem queue, janela em torno do item atual, quadro dentro do limite e rejeições OK"
            )
        )
        val queueArtProto = RemoteProtocol.selfTestQueueArt()
        checks.add(
            Check(
                "Capas da fila: protocolo (queue_art, art_req, qart)",
                queueArtProto == null,
                queueArtProto ?: "art nos itens, art_req, qart em blocos, remontagem, rejeições e formato antigo OK"
            )
        )
        val pl = pairingLogicTest()
        checks.add(Check("Número de pareamento e tokens", pl == null, pl ?: "derivação do número e validação de tokens OK"))
        checks.add(Check("Aparelhos pareados salvos", true, pairedList().size.toString(), essential = false))
        val rg = regenGuardTest()
        checks.add(
            Check(
                "Proteção contra regeneração com o servidor ligado",
                rg == null,
                rg ?: "bloqueada com o servidor ligando/ligado/desligando (chave e pareamentos intactos); liberada com o servidor desligado ou em erro"
            )
        )

        return SelfTestResult(checks, rep)
    }
}
