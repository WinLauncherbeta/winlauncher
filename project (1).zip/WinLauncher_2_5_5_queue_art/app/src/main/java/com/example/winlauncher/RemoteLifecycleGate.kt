package com.example.winlauncher

/**
 * Etapa 3, Bloco 2: lógica PURA (sem Android) que decide o que fazer quando chegam pedidos de "ligar" e "desligar"
 * ao [RemoteServerService], inclusive quando eles se cruzam. Fica separada do serviço para poder ser testada na JVM.
 *
 * Fases:
 *  - [Phase.IDLE]: não há servidor nem desligamento em andamento.
 *  - [Phase.ACTIVE]: o servidor está ligando ou ligado (ou o pedido de ligar já foi enviado ao Android).
 *  - [Phase.STOPPING]: o desligamento está em andamento (os sockets ainda estão sendo fechados).
 *
 * Regras:
 *  - "Ligar" com IDLE liga agora. Com ACTIVE não faz nada. Com STOPPING NÃO é ignorado: vira um religamento pendente,
 *    executado quando o desligamento terminar ([stopFinished]).
 *  - "Desligar" com ACTIVE começa o desligamento e cancela qualquer religamento. Com STOPPING só cancela o religamento
 *    pendente (o desligamento já em andamento continua). Com IDLE não faz nada.
 *  - "Desligar" também cancela os pedidos de "Ligar" que o Android ainda não entregou ao serviço ([dropInFlight]):
 *    quando chegarem, [onStartIntent] devolve [IntentDecision.DROP].
 *  - Todos os métodos são sincronizados; o serviço os chama na thread principal, mas os testes os chamam em paralelo.
 */
class RemoteLifecycleGate {

    enum class Phase { IDLE, ACTIVE, STOPPING }

    enum class StartDecision {
        /** Fase era IDLE: envie o pedido de início ao serviço. */
        START_NOW,

        /** Já está ligando/ligado: nada a fazer. */
        ALREADY_ACTIVE,

        /** Há um desligamento em andamento: o religamento foi registrado e acontece quando ele terminar. */
        RESTART_AFTER_STOP
    }

    enum class StopDecision {
        /** Fase era ACTIVE: comece o desligamento. */
        BEGIN_STOP,

        /** Já está desligando; o religamento pendente foi cancelado. */
        CANCEL_RESTART,

        /** Nada a fazer (já desligado, ou já desligando sem religamento pendente). */
        NOTHING
    }

    enum class IntentDecision {
        /** Ligue o servidor (se ele ainda não existir). */
        LAUNCH,

        /** Este pedido foi cancelado por um "Desligar" posterior: não ligue. */
        DROP,

        /** Há um desligamento em andamento: o religamento foi registrado. */
        RESTART_AFTER_STOP
    }

    enum class FinishDecision {
        /** O desligamento terminou e não há religamento: encerre o serviço. */
        DONE,

        /** O desligamento terminou e há um religamento pendente: ligue um servidor novo (sem encerrar o serviço). */
        RESTART
    }

    private val lock = Any()
    private var phase = Phase.IDLE
    private var restartPending = false
    private var inFlight = 0
    private var dropCount = 0

    fun phase(): Phase = synchronized(lock) { phase }

    fun restartPending(): Boolean = synchronized(lock) { restartPending }

    /** Pedidos de "Ligar" enviados ao Android e ainda não entregues ao serviço. */
    fun inFlight(): Int = synchronized(lock) { inFlight }

    /** Pedido de "Ligar" vindo do painel, do início automático etc. (companion do serviço). */
    fun requestStart(): StartDecision = synchronized(lock) {
        when (phase) {
            Phase.IDLE -> {
                phase = Phase.ACTIVE
                inFlight++
                StartDecision.START_NOW
            }
            Phase.ACTIVE -> StartDecision.ALREADY_ACTIVE
            Phase.STOPPING -> {
                restartPending = true
                StartDecision.RESTART_AFTER_STOP
            }
        }
    }

    /** O envio do pedido ao Android falhou: desfaz o [requestStart] que devolveu [StartDecision.START_NOW]. */
    fun startSendFailed() {
        synchronized(lock) {
            if (inFlight > 0) inFlight--
            if (dropCount > inFlight) dropCount = inFlight
            if (phase == Phase.ACTIVE && inFlight == 0) phase = Phase.IDLE
        }
    }

    /** Pedido de "Desligar" (painel, botão da notificação, erro de inicialização). */
    fun requestStop(): StopDecision = synchronized(lock) {
        dropCount = inFlight
        when (phase) {
            Phase.ACTIVE -> {
                phase = Phase.STOPPING
                restartPending = false
                StopDecision.BEGIN_STOP
            }
            Phase.STOPPING -> {
                if (restartPending) {
                    restartPending = false
                    StopDecision.CANCEL_RESTART
                } else {
                    StopDecision.NOTHING
                }
            }
            Phase.IDLE -> StopDecision.NOTHING
        }
    }

    /**
     * O Android entregou um pedido de "Ligar" ao serviço (onStartCommand). O serviço SEMPRE deve chamar startForeground()
     * antes de consultar isto: o Android exige isso para todo startForegroundService(), qualquer que seja a decisão.
     */
    fun onStartIntent(): IntentDecision = synchronized(lock) {
        if (inFlight > 0) inFlight--
        if (dropCount > 0) {
            dropCount--
            return@synchronized IntentDecision.DROP
        }
        when (phase) {
            Phase.IDLE -> {
                phase = Phase.ACTIVE
                IntentDecision.LAUNCH
            }
            Phase.ACTIVE -> IntentDecision.LAUNCH
            Phase.STOPPING -> {
                restartPending = true
                IntentDecision.RESTART_AFTER_STOP
            }
        }
    }

    /** O desligamento (sockets fechados) terminou. */
    fun stopFinished(): FinishDecision = synchronized(lock) {
        if (phase == Phase.STOPPING && restartPending) {
            restartPending = false
            phase = Phase.ACTIVE
            FinishDecision.RESTART
        } else {
            restartPending = false
            // um "Ligar" já enviado ao Android e não cancelado mantém a fase ACTIVE (o serviço antigo está só se despedindo)
            phase = if (inFlight > dropCount) Phase.ACTIVE else Phase.IDLE
            FinishDecision.DONE
        }
    }

    /** O serviço foi destruído sem passar pelo desligamento normal: volta a IDLE e descarta o religamento pendente. */
    fun forceIdle() {
        synchronized(lock) {
            phase = if (inFlight > dropCount) Phase.ACTIVE else Phase.IDLE
            restartPending = false
        }
    }

    /** Só para testes. */
    fun reset() {
        synchronized(lock) {
            phase = Phase.IDLE
            restartPending = false
            inFlight = 0
            dropCount = 0
        }
    }
}
