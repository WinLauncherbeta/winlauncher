package com.example.winlauncher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * Xadrez básico para a página "Jogos" das Configurações: tabuleiro, regras, bot (fácil/médio/difícil)
 * ou 2 jogadores no mesmo aparelho, desfazer e tela cheia (o dono da tela decide o que cada modo
 * significa e é avisado por [onFullscreen]).
 *
 * Sem barra no topo: as opções ficam num menu lateral (botão ☰ no canto) e, quando a partida
 * termina, aparece "Você venceu" ou "Você perdeu" por cima do tabuleiro.
 */
class ChessPanel(private val ctx: Context, private val onFullscreen: () -> Unit) : FrameLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val handler = Handler(Looper.getMainLooper())

    private val cText = Color.WHITE
    private val cSub = Color.parseColor("#9AA5B8")
    private val cAcc = Color.parseColor("#19B4F0")

    // ---- estado do jogo
    private var pos = ChessEngine.start()
    private val history = ArrayList<ChessEngine.Pos>()
    private var lastFrom = -1
    private var lastTo = -1
    private var selected = -1
    private var targets: List<ChessEngine.Move> = emptyList()
    private var vsBot = true
    private var level = 1 // 0 fácil, 1 médio, 2 difícil
    private var thinking = false
    private var generation = 0
    private var over = false
    private var result = ""
    private var resultTone = 0 // 1 = bom (verde), -1 = ruim (vermelho), 0 = neutro
    private var resultDismissed = false

    private val board = BoardView(ctx)
    private val menuBtn = MenuButton(ctx)
    private val menuLayer = FrameLayout(ctx)
    private val drawer = LinearLayout(ctx)
    private val resultLayer = FrameLayout(ctx)
    private val resultTitle = TextView(ctx)
    private lateinit var fsItem: TextView
    private lateinit var modeItem: TextView
    private lateinit var levelItem: TextView

    private val levelNames = arrayOf("Fácil", "Médio", "Difícil")
    private val drawerW get() = dp(250)

    /** 0 = janela, 1 = tela cheia com barra de tarefas, 2 = tela cheia total. */
    fun setFullscreenMode(m: Int) {
        fsItem.text = when (m) {
            0 -> "⛶  Tela cheia"
            1 -> "⛶  Tela cheia total"
            else -> "⮌  Sair da tela cheia"
        }
    }

    init {
        addView(board, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        menuBtn.setOnClickListener { toggleMenu(true) }
        addView(menuBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.START).apply {
            topMargin = dp(6)
            leftMargin = dp(6)
        })

        buildResult()
        addView(resultLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildMenu()
        addView(menuLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        refreshMenu()
        updateStatus()
    }

    // ------------------------------------------------------------------ menu lateral

    private fun menuItem(text: String, click: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 14f
        t.setTextColor(cText)
        t.gravity = Gravity.CENTER_VERTICAL
        t.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#1AFFFFFF"))
        bg.cornerRadius = dp(8).toFloat()
        t.background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), bg, null)
        t.isClickable = true
        t.setOnClickListener { click() }
        t.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
        return t
    }

    private fun buildMenu() {
        menuLayer.visibility = View.GONE
        menuLayer.isClickable = true

        val scrim = View(ctx)
        scrim.setBackgroundColor(Color.parseColor("#88000000"))
        scrim.setOnClickListener { toggleMenu(false) }
        menuLayer.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        drawer.orientation = LinearLayout.VERTICAL
        drawer.setPadding(dp(14), dp(18), dp(14), dp(14))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#F2111A33"))
        val r = dp(16).toFloat()
        bg.cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        bg.setStroke(dp(1), Color.parseColor("#26FFFFFF"))
        drawer.background = bg
        drawer.isClickable = true

        val title = TextView(ctx)
        title.text = "Xadrez"
        title.textSize = 18f
        title.setTextColor(cText)
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setPadding(dp(6), 0, dp(6), dp(14))
        drawer.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        drawer.addView(menuItem("Novo jogo") { newGame(); toggleMenu(false) })
        drawer.addView(menuItem("Desfazer") { undo(); toggleMenu(false) })
        modeItem = menuItem("") { vsBot = !vsBot; newGame(); refreshMenu() }
        drawer.addView(modeItem)
        levelItem = menuItem("") { level = (level + 1) % 3; refreshMenu(); if (vsBot) newGame() }
        drawer.addView(levelItem)
        fsItem = menuItem("⛶  Tela cheia") { toggleMenu(false); onFullscreen() }
        drawer.addView(fsItem)

        menuLayer.addView(drawer, FrameLayout.LayoutParams(drawerW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START))
    }

    private fun toggleMenu(show: Boolean) {
        if (show) {
            menuLayer.visibility = View.VISIBLE
            drawer.translationX = -drawerW.toFloat()
            drawer.animate().translationX(0f).setDuration(160).start()
        } else if (menuLayer.visibility == View.VISIBLE) {
            drawer.animate().translationX(-drawerW.toFloat()).setDuration(140)
                .withEndAction { menuLayer.visibility = View.GONE }.start()
        }
    }

    private fun refreshMenu() {
        modeItem.text = if (vsBot) "Modo: contra o bot" else "Modo: 2 jogadores"
        levelItem.text = "Nível: " + levelNames[level]
        levelItem.alpha = if (vsBot) 1f else 0.4f
    }

    // ------------------------------------------------------------------ resultado (venceu / perdeu)

    private fun buildResult() {
        resultLayer.visibility = View.GONE
        resultLayer.isClickable = true
        resultLayer.setBackgroundColor(Color.parseColor("#99000000"))
        // tocar fora do cartão só esconde o aviso (dá para olhar o tabuleiro); "Novo jogo" fica no menu
        resultLayer.setOnClickListener { resultDismissed = true; resultLayer.visibility = View.GONE }

        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dp(28), dp(26), dp(28), dp(22))
        card.minimumWidth = dp(260)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#F2111A33"))
        bg.cornerRadius = dp(18).toFloat()
        bg.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        card.background = bg
        card.isClickable = true

        resultTitle.textSize = 30f
        resultTitle.gravity = Gravity.CENTER
        resultTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        card.addView(resultTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val again = TextView(ctx)
        again.text = "Jogar de novo"
        again.textSize = 14f
        again.setTextColor(Color.WHITE)
        again.gravity = Gravity.CENTER
        again.setPadding(dp(22), dp(11), dp(22), dp(11))
        val abg = GradientDrawable()
        abg.setColor(cAcc)
        abg.cornerRadius = dp(10).toFloat()
        again.background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), abg, null)
        again.isClickable = true
        again.setOnClickListener { newGame() }
        card.addView(again, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(18)
        })

        resultLayer.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    private fun updateStatus() {
        if (over && !resultDismissed) {
            resultTitle.text = result
            resultTitle.setTextColor(
                when (resultTone) {
                    1 -> Color.parseColor("#4ADE80")
                    -1 -> Color.parseColor("#FF6B6B")
                    else -> Color.WHITE
                }
            )
            resultLayer.visibility = View.VISIBLE
        } else {
            resultLayer.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------ jogo

    private fun newGame() {
        generation++
        thinking = false
        pos = ChessEngine.start()
        history.clear()
        lastFrom = -1
        lastTo = -1
        selected = -1
        targets = emptyList()
        over = false
        result = ""
        resultTone = 0
        resultDismissed = false
        refreshMenu()
        updateStatus()
        board.invalidate()
    }

    private fun undo() {
        if (history.isEmpty()) return
        generation++ // cancela o bot, se estiver pensando
        thinking = false
        // contra o bot volta até a vez das brancas (a sua)
        do {
            pos = history.removeAt(history.lastIndex)
        } while (vsBot && !pos.white && history.isNotEmpty())
        lastFrom = -1
        lastTo = -1
        selected = -1
        targets = emptyList()
        over = false
        result = ""
        resultTone = 0
        resultDismissed = false
        updateStatus()
        board.invalidate()
    }

    private fun onCell(sq: Int) {
        if (over || thinking) return
        if (vsBot && !pos.white) return
        val p = pos.b[sq]
        if (selected != -1) {
            val m = targets.firstOrNull { it.to == sq }
            if (m != null) {
                play(m)
                return
            }
        }
        if (p != 0 && (p > 0) == pos.white) {
            selected = sq
            targets = ChessEngine.legalFrom(pos, sq)
        } else {
            selected = -1
            targets = emptyList()
        }
        board.invalidate()
    }

    private fun play(m: ChessEngine.Move) {
        history.add(pos)
        pos = ChessEngine.apply(pos, m)
        lastFrom = m.from
        lastTo = m.to
        selected = -1
        targets = emptyList()
        when (ChessEngine.status(pos)) {
            ChessEngine.CHECKMATE -> {
                over = true
                val whiteWon = !pos.white
                if (vsBot) {
                    result = if (whiteWon) "Você venceu" else "Você perdeu"
                    resultTone = if (whiteWon) 1 else -1
                } else {
                    result = if (whiteWon) "Brancas venceram" else "Pretas venceram"
                    resultTone = 1
                }
            }
            ChessEngine.STALEMATE -> {
                over = true
                result = "Empate"
                resultTone = 0
            }
        }
        updateStatus()
        board.invalidate()
        if (!over && vsBot && !pos.white) botMove()
    }

    private fun botMove() {
        thinking = true
        val gen = ++generation
        val snapshot = pos
        val lv = level
        Thread {
            val start = System.currentTimeMillis()
            val m = try {
                ChessEngine.bestMove(snapshot, lv)
            } catch (t: Throwable) {
                null
            }
            val wait = 350L - (System.currentTimeMillis() - start)
            if (wait > 0) try { Thread.sleep(wait) } catch (e: InterruptedException) { }
            handler.post {
                if (gen != generation) return@post
                thinking = false
                if (m != null) play(m) else updateStatus()
            }
        }.start()
    }

    // ------------------------------------------------------------------ botão do menu (☰)

    private inner class MenuButton(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            isClickable = true
        }

        override fun onDraw(canvas: Canvas) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#C0101830")
            val rad = dp(10).toFloat()
            canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), rad, rad, p)
            p.color = Color.WHITE
            val w = width * 0.46f
            val h = dp(2).toFloat()
            val x0 = (width - w) / 2f
            for (i in -1..1) {
                val cy = height / 2f + i * dp(6)
                canvas.drawRoundRect(x0, cy - h / 2f, x0 + w, cy + h / 2f, h, h, p)
            }
        }
    }

    // ------------------------------------------------------------------ tabuleiro

    private inner class BoardView(c: Context) : View(c) {
        private val light = Color.parseColor("#DCE6F5")
        private val dark = Color.parseColor("#5B7DB1")
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pieceFill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pieceStroke = Paint(Paint.ANTI_ALIAS_FLAG)
        private val label = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glyphs = arrayOf("", "\u265F\uFE0E", "\u265E", "\u265D", "\u265C", "\u265B", "\u265A")
        private var cell = 0f
        private var ox = 0f
        private var oy = 0f

        init {
            val tf = try {
                Typeface.createFromAsset(c.assets, "fonts/chess_pieces.ttf")
            } catch (t: Throwable) {
                Typeface.DEFAULT
            }
            pieceFill.typeface = tf
            pieceStroke.typeface = tf
            pieceFill.textAlign = Paint.Align.CENTER
            pieceStroke.textAlign = Paint.Align.CENTER
            pieceStroke.style = Paint.Style.STROKE
            label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

        override fun onDraw(canvas: Canvas) {
            val side = min(width, height).toFloat()
            cell = side / 8f
            ox = (width - side) / 2f
            oy = (height - side) / 2f
            val kingSq = kingSquare()
            val checked = ChessEngine.inCheck(pos.b, pos.white)

            for (sq in 0 until 64) {
                val r = sq / 8
                val c = sq % 8
                val x = ox + c * cell
                val y = oy + r * cell
                paint.style = Paint.Style.FILL
                paint.color = if ((r + c) % 2 == 0) light else dark
                canvas.drawRect(x, y, x + cell, y + cell, paint)
                if (sq == lastFrom || sq == lastTo) {
                    paint.color = Color.parseColor("#55FFE066")
                    canvas.drawRect(x, y, x + cell, y + cell, paint)
                }
                if (sq == selected) {
                    paint.color = Color.parseColor("#8819B4F0")
                    canvas.drawRect(x, y, x + cell, y + cell, paint)
                }
                if (checked && sq == kingSq) {
                    paint.color = Color.parseColor("#88FF3B30")
                    canvas.drawRect(x, y, x + cell, y + cell, paint)
                }
                // coordenadas
                label.textSize = cell * 0.17f
                label.color = if ((r + c) % 2 == 0) dark else light
                if (c == 0) {
                    label.textAlign = Paint.Align.LEFT
                    canvas.drawText((8 - r).toString(), x + cell * 0.06f, y + cell * 0.2f, label)
                }
                if (r == 7) {
                    label.textAlign = Paint.Align.RIGHT
                    canvas.drawText(('a' + c).toString(), x + cell * 0.94f, y + cell * 0.95f, label)
                }
            }

            // peças
            val size = cell * 0.82f
            pieceFill.textSize = size
            pieceStroke.textSize = size
            pieceStroke.strokeWidth = cell * 0.025f
            val fm = pieceFill.fontMetrics
            val dy = -(fm.ascent + fm.descent) / 2f
            for (sq in 0 until 64) {
                val p = pos.b[sq]
                if (p == 0) continue
                val cx = ox + (sq % 8) * cell + cell / 2f
                val cy = oy + (sq / 8) * cell + cell / 2f
                val white = p > 0
                pieceFill.color = if (white) Color.WHITE else Color.parseColor("#1A1A22")
                pieceStroke.color = if (white) Color.parseColor("#1A1A22") else Color.parseColor("#C8D3E6")
                val g = glyphs[abs(p)]
                canvas.drawText(g, cx, cy + dy, pieceFill)
                canvas.drawText(g, cx, cy + dy, pieceStroke)
            }

            // destinos possíveis
            for (m in targets) {
                val cx = ox + (m.to % 8) * cell + cell / 2f
                val cy = oy + (m.to / 8) * cell + cell / 2f
                if (pos.b[m.to] != 0) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = cell * 0.08f
                    paint.color = Color.parseColor("#CCFF6B5E")
                    canvas.drawCircle(cx, cy, cell * 0.44f, paint)
                } else {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#AA19B4F0")
                    canvas.drawCircle(cx, cy, cell * 0.14f, paint)
                }
            }
        }

        private fun kingSquare(): Int {
            val k = if (pos.white) 6 else -6
            for (i in 0 until 64) if (pos.b[i] == k) return i
            return -1
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> return true
                MotionEvent.ACTION_UP -> {
                    val c = ((e.x - ox) / cell).toInt()
                    val r = ((e.y - oy) / cell).toInt()
                    if (e.x >= ox && e.y >= oy && c in 0..7 && r in 0..7) {
                        onCell(r * 8 + c)
                        performClick()
                    }
                    return true
                }
            }
            return super.onTouchEvent(e)
        }

        override fun performClick(): Boolean = super.performClick()
    }
}
