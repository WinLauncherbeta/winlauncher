package com.example.winlauncher

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Tira uma foto reduzida de uma view visível (usada na miniatura da janelinha). */
fun snapView(v: View, maxW: Int): Bitmap? {
    if (v.visibility != View.VISIBLE || v.width <= 0 || v.height <= 0) return null
    val s = minOf(1f, maxW.toFloat() / v.width)
    val bw = maxOf(1, (v.width * s).toInt())
    val bh = maxOf(1, (v.height * s).toInt())
    return try {
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.scale(s, s)
        v.draw(c)
        b
    } catch (t: Throwable) {
        null
    }
}

/** Um app nativo do launcher que aparece na janelinha: título, ícone, estado, miniatura, abrir e fechar. */
class PreviewEntry(
    val title: String,
    val icon: () -> Drawable?,
    val isOpen: () -> Boolean,
    val snapshot: (Int) -> Bitmap?,
    val activate: () -> Unit,
    val close: () -> Unit
)

/**
 * Janelinha de pré-visualização igual à do Windows: ao passar o mouse no ícone de um app nativo aberto, aparece um
 * cartão com o nome, a miniatura da janela e um botão de fechar. Clicar no cartão abre/traz a janela do app.
 * [colors] devolve (fundo, texto, destaque); [barOnTop] diz se a barra de tarefas está no topo da tela.
 */
class TaskbarPreview(
    private val act: Activity,
    private val root: FrameLayout,
    private val colors: () -> IntArray,
    private val barOnTop: () -> Boolean
) {
    val layer = FrameLayout(act)
    private val handler = Handler(Looper.getMainLooper())
    private var card: View? = null
    private var entry: PreviewEntry? = null
    private var anchorView: View? = null

    private val hideRun = Runnable { hide() }

    private fun dp(v: Int): Int = (v * act.resources.displayMetrics.density + 0.5f).toInt()

    fun attachBelow(menuLayer: View) {
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Liga a janelinha ao ícone [anchor]; só aparece enquanto o app estiver aberto. */
    fun attach(anchor: View, provider: () -> PreviewEntry) {
        anchor.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_HOVER_MOVE -> {
                    handler.removeCallbacks(hideRun)
                    if (anchorView !== v || card == null) {
                        val e = provider()
                        if (e.isOpen()) scheduleShow(v, e, if (card != null) 0L else 400L)
                    }
                }
                MotionEvent.ACTION_HOVER_EXIT -> {
                    handler.removeCallbacks(showRun)
                    scheduleHide()
                }
            }
            false
        }
    }

    private var pendingAnchor: View? = null
    private var pendingEntry: PreviewEntry? = null
    private val showRun = Runnable {
        val a = pendingAnchor
        val e = pendingEntry
        if (a != null && e != null && a.isAttachedToWindow && e.isOpen()) show(a, e)
    }

    private fun scheduleShow(a: View, e: PreviewEntry, delay: Long) {
        pendingAnchor = a
        pendingEntry = e
        handler.removeCallbacks(showRun)
        handler.postDelayed(showRun, delay)
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRun)
        handler.postDelayed(hideRun, 280)
    }

    /** Mantém a janelinha aberta enquanto o mouse estiver nela (ou em qualquer parte dela). */
    private fun keepAlive(v: View) {
        v.setOnHoverListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_HOVER_MOVE -> handler.removeCallbacks(hideRun)
                MotionEvent.ACTION_HOVER_EXIT -> scheduleHide()
            }
            false
        }
    }

    fun hide() {
        handler.removeCallbacks(hideRun)
        handler.removeCallbacks(showRun)
        card?.let { layer.removeView(it) }
        card = null
        entry = null
        anchorView = null
    }

    /** Chamada quando a barra de tarefas se redesenha: fecha a janelinha se o app já foi fechado. */
    fun refresh() {
        val e = entry ?: return
        if (!e.isOpen()) hide()
    }

    private fun show(anchor: View, e: PreviewEntry) {
        hide()
        val (bg, fg, accent) = colors().let { Triple(it[0], it[1], it[2]) }
        val w = minOf(dp(250), act.resources.displayMetrics.widthPixels - dp(16))

        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(8), dp(6), dp(8), dp(8))
        c.background = GradientDrawable().apply {
            setColor(bg or (0xF0 shl 24))
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        }
        c.elevation = dp(10).toFloat()
        c.isClickable = true
        c.setOnClickListener {
            hide()
            e.activate()
        }
        keepAlive(c)

        // cabeçalho: ícone + título + fechar
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ic = ImageView(act)
        ic.setImageDrawable(e.icon())
        head.addView(ic, LinearLayout.LayoutParams(dp(16), dp(16)))
        val t = TextView(act)
        t.text = e.title
        t.setTextColor(fg)
        t.textSize = 12f
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(8)
        head.addView(t, tlp)
        val x = ImageView(act)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(fg)
        x.setPadding(dp(6), dp(6), dp(6), dp(6))
        x.isClickable = true
        x.background = rr(Color.TRANSPARENT, 6)
        x.setOnClickListener {
            hide()
            e.close()
        }
        keepAlive(x)
        x.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> {
                    handler.removeCallbacks(hideRun)
                    v.background = rr(Color.parseColor("#E5484D"), 6)
                }
                MotionEvent.ACTION_HOVER_MOVE -> handler.removeCallbacks(hideRun)
                MotionEvent.ACTION_HOVER_EXIT -> {
                    v.background = rr(Color.TRANSPARENT, 6)
                    scheduleHide()
                }
            }
            false
        }
        head.addView(x, LinearLayout.LayoutParams(dp(26), dp(26)))
        c.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // miniatura da janela (ou o ícone do app, se não der para fotografar)
        val thumbW = w - dp(16)
        val shot = e.snapshot(thumbW)
        val frame = FrameLayout(act)
        frame.background = rr(Color.parseColor("#33000000"), 6)
        val thumb = ImageView(act)
        if (shot != null) {
            thumb.setImageBitmap(shot)
            thumb.scaleType = ImageView.ScaleType.FIT_CENTER
            thumb.adjustViewBounds = true
            frame.addView(thumb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        } else {
            thumb.setImageDrawable(e.icon())
            frame.addView(thumb, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        }
        val flp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flp.topMargin = dp(4)
        if (shot == null) flp.height = dp(110)
        c.addView(frame, flp)

        layer.addView(c, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.LEFT or Gravity.TOP))
        c.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ch = c.measuredHeight

        val a = IntArray(2)
        anchor.getLocationOnScreen(a)
        val r = IntArray(2)
        layer.getLocationOnScreen(r)
        val sw = layer.width.takeIf { it > 0 } ?: act.resources.displayMetrics.widthPixels
        val sh = layer.height.takeIf { it > 0 } ?: act.resources.displayMetrics.heightPixels
        val gap = dp(8)
        var px = a[0] - r[0] + anchor.width / 2 - w / 2
        px = px.coerceIn(dp(8), maxOf(dp(8), sw - w - dp(8)))
        var py = if (barOnTop()) a[1] - r[1] + anchor.height + gap else a[1] - r[1] - ch - gap
        py = py.coerceIn(dp(4), maxOf(dp(4), sh - ch - dp(4)))
        val lp = c.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = px
        lp.topMargin = py
        c.layoutParams = lp
        c.alpha = 0f
        c.animate().alpha(1f).setDuration(120).start()

        card = c
        entry = e
        anchorView = anchor
    }

    private fun rr(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
        }

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    }
}
