package com.example.winlauncher

import kotlin.math.abs

/**
 * Motor de xadrez simples, sem dependências do Android.
 *
 * Tabuleiro: 64 casas, índice = linha * 8 + coluna; linha 0 = 8ª fileira (pretas), linha 7 = 1ª fileira (brancas).
 * Peças: 1 peão, 2 cavalo, 3 bispo, 4 torre, 5 dama, 6 rei; positivo = branca, negativo = preta.
 * Regras: movimentos legais (sem deixar o rei em xeque), roque, en passant e promoção automática para dama.
 */
object ChessEngine {

    class Move(val from: Int, val to: Int, val promo: Int = 0)

    class Pos(val b: IntArray, val white: Boolean, val cas: Int, val ep: Int)

    const val CHECKMATE = 1
    const val STALEMATE = 2
    const val ONGOING = 0

    private const val MATE = 100000
    private val VAL = intArrayOf(0, 100, 320, 330, 500, 900, 0)

    private val KN = arrayOf(
        intArrayOf(-2, -1), intArrayOf(-2, 1), intArrayOf(-1, -2), intArrayOf(-1, 2),
        intArrayOf(1, -2), intArrayOf(1, 2), intArrayOf(2, -1), intArrayOf(2, 1)
    )
    private val KG = arrayOf(
        intArrayOf(-1, -1), intArrayOf(-1, 0), intArrayOf(-1, 1), intArrayOf(0, -1),
        intArrayOf(0, 1), intArrayOf(1, -1), intArrayOf(1, 0), intArrayOf(1, 1)
    )
    private val DIAG = arrayOf(intArrayOf(-1, -1), intArrayOf(-1, 1), intArrayOf(1, -1), intArrayOf(1, 1))
    private val ORTH = arrayOf(intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1))

    fun start(): Pos {
        val b = IntArray(64)
        val back = intArrayOf(4, 2, 3, 5, 6, 3, 2, 4)
        for (c in 0 until 8) {
            b[c] = -back[c]
            b[8 + c] = -1
            b[48 + c] = 1
            b[56 + c] = back[c]
        }
        return Pos(b, true, 15, -1)
    }

    // ------------------------------------------------------------------ ataques e xeque

    private fun isAttacked(b: IntArray, sq: Int, byWhite: Boolean): Boolean {
        val r = sq / 8
        val c = sq % 8
        val s = if (byWhite) 1 else -1
        // peões: branco ataca para cima (linha diminui)
        val pr = if (byWhite) r + 1 else r - 1
        if (pr in 0..7) {
            if (c > 0 && b[pr * 8 + c - 1] == s) return true
            if (c < 7 && b[pr * 8 + c + 1] == s) return true
        }
        for (d in KN) {
            val nr = r + d[0]
            val nc = c + d[1]
            if (nr in 0..7 && nc in 0..7 && b[nr * 8 + nc] == 2 * s) return true
        }
        for (d in KG) {
            val nr = r + d[0]
            val nc = c + d[1]
            if (nr in 0..7 && nc in 0..7 && b[nr * 8 + nc] == 6 * s) return true
        }
        for (d in DIAG) {
            var nr = r + d[0]
            var nc = c + d[1]
            while (nr in 0..7 && nc in 0..7) {
                val p = b[nr * 8 + nc]
                if (p != 0) {
                    if (p == 3 * s || p == 5 * s) return true
                    break
                }
                nr += d[0]
                nc += d[1]
            }
        }
        for (d in ORTH) {
            var nr = r + d[0]
            var nc = c + d[1]
            while (nr in 0..7 && nc in 0..7) {
                val p = b[nr * 8 + nc]
                if (p != 0) {
                    if (p == 4 * s || p == 5 * s) return true
                    break
                }
                nr += d[0]
                nc += d[1]
            }
        }
        return false
    }

    fun inCheck(b: IntArray, white: Boolean): Boolean {
        val k = if (white) 6 else -6
        for (i in 0 until 64) if (b[i] == k) return isAttacked(b, i, !white)
        return false
    }

    // ------------------------------------------------------------------ geração de lances

    private fun pseudo(pos: Pos): ArrayList<Move> {
        val b = pos.b
        val white = pos.white
        val s = if (white) 1 else -1
        val out = ArrayList<Move>(48)
        for (i in 0 until 64) {
            val p = b[i]
            if (p == 0 || (p > 0) != white) continue
            val r = i / 8
            val c = i % 8
            when (abs(p)) {
                1 -> {
                    val dr = if (white) -1 else 1
                    val startRow = if (white) 6 else 1
                    val promoRow = if (white) 0 else 7
                    val nr = r + dr
                    if (nr in 0..7) {
                        if (b[nr * 8 + c] == 0) {
                            out.add(Move(i, nr * 8 + c, if (nr == promoRow) 5 else 0))
                            if (r == startRow && b[(r + 2 * dr) * 8 + c] == 0) out.add(Move(i, (r + 2 * dr) * 8 + c))
                        }
                        for (dc in intArrayOf(-1, 1)) {
                            val nc = c + dc
                            if (nc !in 0..7) continue
                            val t = nr * 8 + nc
                            if ((b[t] != 0 && (b[t] > 0) != white) || t == pos.ep) {
                                out.add(Move(i, t, if (nr == promoRow) 5 else 0))
                            }
                        }
                    }
                }
                2 -> for (d in KN) addStep(out, b, i, r + d[0], c + d[1], white)
                6 -> {
                    for (d in KG) addStep(out, b, i, r + d[0], c + d[1], white)
                    addCastling(out, pos, i)
                }
                3 -> for (d in DIAG) addSlide(out, b, i, d, white)
                4 -> for (d in ORTH) addSlide(out, b, i, d, white)
                5 -> {
                    for (d in DIAG) addSlide(out, b, i, d, white)
                    for (d in ORTH) addSlide(out, b, i, d, white)
                }
            }
        }
        return out
    }

    private fun addStep(out: ArrayList<Move>, b: IntArray, from: Int, nr: Int, nc: Int, white: Boolean) {
        if (nr !in 0..7 || nc !in 0..7) return
        val t = nr * 8 + nc
        if (b[t] == 0 || (b[t] > 0) != white) out.add(Move(from, t))
    }

    private fun addSlide(out: ArrayList<Move>, b: IntArray, from: Int, d: IntArray, white: Boolean) {
        var nr = from / 8 + d[0]
        var nc = from % 8 + d[1]
        while (nr in 0..7 && nc in 0..7) {
            val t = nr * 8 + nc
            if (b[t] == 0) {
                out.add(Move(from, t))
            } else {
                if ((b[t] > 0) != white) out.add(Move(from, t))
                break
            }
            nr += d[0]
            nc += d[1]
        }
    }

    private fun addCastling(out: ArrayList<Move>, pos: Pos, k: Int) {
        val b = pos.b
        if (pos.white) {
            if (k != 60) return
            if (pos.cas and 3 == 0) return
            if (isAttacked(b, 60, false)) return
            if (pos.cas and 1 != 0 && b[61] == 0 && b[62] == 0 && b[63] == 4 &&
                !isAttacked(b, 61, false) && !isAttacked(b, 62, false)
            ) out.add(Move(60, 62))
            if (pos.cas and 2 != 0 && b[59] == 0 && b[58] == 0 && b[57] == 0 && b[56] == 4 &&
                !isAttacked(b, 59, false) && !isAttacked(b, 58, false)
            ) out.add(Move(60, 58))
        } else {
            if (k != 4) return
            if (pos.cas and 12 == 0) return
            if (isAttacked(b, 4, true)) return
            if (pos.cas and 4 != 0 && b[5] == 0 && b[6] == 0 && b[7] == -4 &&
                !isAttacked(b, 5, true) && !isAttacked(b, 6, true)
            ) out.add(Move(4, 6))
            if (pos.cas and 8 != 0 && b[3] == 0 && b[2] == 0 && b[1] == 0 && b[0] == -4 &&
                !isAttacked(b, 3, true) && !isAttacked(b, 2, true)
            ) out.add(Move(4, 2))
        }
    }

    fun apply(pos: Pos, m: Move): Pos {
        val nb = pos.b.clone()
        val piece = nb[m.from]
        val a = abs(piece)
        val s = if (piece > 0) 1 else -1
        if (a == 1 && m.to == pos.ep && nb[m.to] == 0 && m.from % 8 != m.to % 8) {
            nb[(m.from / 8) * 8 + m.to % 8] = 0 // en passant
        }
        nb[m.to] = piece
        nb[m.from] = 0
        if (a == 1 && (m.to / 8 == 0 || m.to / 8 == 7)) nb[m.to] = s * (if (m.promo != 0) m.promo else 5)
        if (a == 6 && abs(m.to - m.from) == 2) {
            if (m.to > m.from) {
                nb[m.from + 1] = nb[m.from + 3]
                nb[m.from + 3] = 0
            } else {
                nb[m.from - 1] = nb[m.from - 4]
                nb[m.from - 4] = 0
            }
        }
        var cas = pos.cas
        if (a == 6) cas = cas and (if (s > 0) 3 else 12).inv()
        if (m.from == 63 || m.to == 63) cas = cas and 1.inv()
        if (m.from == 56 || m.to == 56) cas = cas and 2.inv()
        if (m.from == 7 || m.to == 7) cas = cas and 4.inv()
        if (m.from == 0 || m.to == 0) cas = cas and 8.inv()
        val ep = if (a == 1 && abs(m.to - m.from) == 16) (m.from + m.to) / 2 else -1
        return Pos(nb, !pos.white, cas, ep)
    }

    fun legalMoves(pos: Pos): List<Move> {
        val out = ArrayList<Move>()
        for (m in pseudo(pos)) if (!inCheck(apply(pos, m).b, pos.white)) out.add(m)
        return out
    }

    /** Lances legais a partir de uma casa. */
    fun legalFrom(pos: Pos, from: Int): List<Move> = legalMoves(pos).filter { it.from == from }

    fun status(pos: Pos): Int {
        if (legalMoves(pos).isNotEmpty()) return ONGOING
        return if (inCheck(pos.b, pos.white)) CHECKMATE else STALEMATE
    }

    // ------------------------------------------------------------------ avaliação e busca

    private fun centre(r: Int, c: Int): Int {
        val dr = minOf(r, 7 - r)
        val dc = minOf(c, 7 - c)
        return dr + dc // 0 (canto) .. 6 (centro)
    }

    /** Pontuação do ponto de vista das brancas. */
    private fun evalWhite(b: IntArray): Int {
        var sc = 0
        for (i in 0 until 64) {
            val p = b[i]
            if (p == 0) continue
            val a = abs(p)
            val r = i / 8
            val c = i % 8
            var v = VAL[a]
            when (a) {
                1 -> {
                    val adv = if (p > 0) 6 - r else r - 1 // 0..5
                    v += adv * 6 + centre(r, c) * 2
                }
                2, 3 -> v += centre(r, c) * 6
                5 -> v += centre(r, c)
                6 -> {
                    // rei: fica atrás no começo (sem cálculo de final de jogo, jogo básico)
                    val home = if (p > 0) r == 7 else r == 0
                    v += if (home) 10 else -10
                }
            }
            sc += if (p > 0) v else -v
        }
        return sc
    }

    private fun evalSide(pos: Pos): Int = if (pos.white) evalWhite(pos.b) else -evalWhite(pos.b)

    private var deadline = 0L
    private var timeUp = false
    private var nodes = 0

    private fun checkTime() {
        nodes++
        if (nodes and 1023 == 0 && System.currentTimeMillis() > deadline) timeUp = true
    }

    private fun order(pos: Pos, moves: List<Move>): List<Move> {
        val b = pos.b
        return moves.sortedByDescending {
            val cap = abs(b[it.to])
            val mover = abs(b[it.from])
            (if (cap != 0) 10 * VAL[cap] - VAL[mover] else 0) + (if (it.promo != 0) 800 else 0)
        }
    }

    private fun quiesce(pos: Pos, alphaIn: Int, beta: Int, qd: Int): Int {
        checkTime()
        val stand = evalSide(pos)
        if (qd <= 0 || timeUp) return stand
        if (stand >= beta) return beta
        var alpha = maxOf(alphaIn, stand)
        val caps = ArrayList<Move>()
        for (m in pseudo(pos)) {
            if (pos.b[m.to] != 0 || (m.to == pos.ep && abs(pos.b[m.from]) == 1)) caps.add(m)
        }
        for (m in order(pos, caps)) {
            val np = apply(pos, m)
            if (inCheck(np.b, pos.white)) continue
            val sc = -quiesce(np, -beta, -alpha, qd - 1)
            if (timeUp) return alpha
            if (sc >= beta) return beta
            if (sc > alpha) alpha = sc
        }
        return alpha
    }

    private fun negamax(pos: Pos, depth: Int, alphaIn: Int, beta: Int, ply: Int): Int {
        checkTime()
        if (timeUp) return 0
        val moves = legalMoves(pos)
        if (moves.isEmpty()) return if (inCheck(pos.b, pos.white)) -(MATE - ply) else 0
        if (depth <= 0) return quiesce(pos, alphaIn, beta, 4)
        var alpha = alphaIn
        for (m in order(pos, moves)) {
            val sc = -negamax(apply(pos, m), depth - 1, -beta, -alpha, ply + 1)
            if (timeUp) return 0
            if (sc >= beta) return beta
            if (sc > alpha) alpha = sc
        }
        return alpha
    }

    /** Nível: 0 fácil, 1 médio, 2 difícil. Roda em segundo plano (pode levar alguns segundos no difícil). */
    fun bestMove(pos: Pos, level: Int): Move? {
        val moves = legalMoves(pos)
        if (moves.isEmpty()) return null
        val rnd = java.util.Random()
        if (level <= 0) {
            val caps = moves.filter { pos.b[it.to] != 0 }
            return if (caps.isNotEmpty() && rnd.nextInt(100) < 40) caps[rnd.nextInt(caps.size)]
            else moves[rnd.nextInt(moves.size)]
        }
        val maxDepth = if (level == 1) 2 else 4
        deadline = System.currentTimeMillis() + (if (level == 1) 1500L else 3000L)
        timeUp = false
        nodes = 0
        val ordered = order(pos, moves)
        var best: Move = ordered[0]
        for (depth in 1..maxDepth) {
            var bestHere: Move? = null
            var bestScore = Int.MIN_VALUE
            var alpha = -MATE * 2
            for (m in ordered) {
                val sc = -negamax(apply(pos, m), depth - 1, -MATE * 2, -alpha, 1) + rnd.nextInt(3)
                if (timeUp) break
                if (sc > bestScore) {
                    bestScore = sc
                    bestHere = m
                }
                if (sc > alpha) alpha = sc
            }
            if (timeUp) break
            if (bestHere != null) best = bestHere
            if (bestScore > MATE - 100) break // mate encontrado
        }
        return best
    }
}
