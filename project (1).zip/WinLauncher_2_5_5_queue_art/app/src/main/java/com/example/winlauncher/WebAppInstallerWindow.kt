package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Janela "Instalador de Aplicativos": cria um app a partir de um link.
 *
 * Nome + link + ícone (o do próprio site, carregado automaticamente, ou uma foto da galeria).
 * O app sempre entra na janela de aplicativos; as caixinhas escolhem se ele também fica fixado na barra de tarefas
 * e/ou na área de trabalho. Ao abrir, o link é aberto no navegador embutido (veja [WebApps]).
 *
 * É uma janela autônoma, igual à [ApkInstallerWindow]: arrasta pela barra de título e fecha no X.
 */
class WebAppInstallerWindow(private val act: MainActivity, private val root: FrameLayout) {

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    /** Chamado quando o app foi criado: (app, fixar na barra de tarefas, atalho na área de trabalho). */
    var onInstalled: ((WebApps.Entry, Boolean, Boolean) -> Unit)? = null

    val isOpen: Boolean get() = open

    private val d = act.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private val ink = Color.parseColor("#F2F5FA")
    private val sub = Color.parseColor("#A9B3C6")
    private val accent = Color.parseColor("#4CC2FF")
    private val field = Color.parseColor("#2EFFFFFF")

    private lateinit var win: FrameLayout
    private lateinit var nameEt: EditText
    private lateinit var urlEt: EditText
    private lateinit var iconIv: ImageView
    private lateinit var status: TextView
    private lateinit var installBtn: TextView
    private lateinit var siteCheck: CheckRow
    private lateinit var pinCheck: CheckRow
    private lateinit var deskCheck: CheckRow

    private var open = false
    private var placed = false
    private var busy = false

    /** Incrementa ao abrir/fechar e a cada busca nova; respostas antigas da internet são descartadas. */
    private var gen = 0

    private var pickedIcon: Bitmap? = null
    private var siteIcon: Bitmap? = null
    private var siteTitle: String? = null
    private var fetchedUrl: String? = null

    init {
        build()
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    // ================================================================== API pública

    fun show() {
        WindowStack.raise(root, layer, stackAbove)
        if (open) return
        open = true
        busy = false
        gen++
        pickedIcon = null
        siteIcon = null
        siteTitle = null
        fetchedUrl = null
        nameEt.setText("")
        urlEt.setText("")
        status.text = ""
        siteCheck.checked = true
        pinCheck.checked = true
        deskCheck.checked = true
        setInstallEnabled(true)
        refreshPreview()
        win.background = makeBg()
        win.animate().cancel()
        sizeWindow()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    fun close() {
        if (!open) return
        open = false
        gen++
        hideKeyboard()
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (!open) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    /** Insere a janela logo abaixo da camada do menu de contexto (o menu continua por cima). */
    private var stackAbove: View? = null

    fun attachBelow(menuLayer: View) {
        stackAbove = menuLayer
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Foto escolhida na galeria para ser o ícone (chamado pela MainActivity). */
    fun onIconPicked(bmp: Bitmap) {
        if (!open) return
        pickedIcon = bmp
        siteCheck.checked = false
        refreshPreview()
    }

    // ================================================================== lógica

    private fun hideKeyboard() {
        try {
            val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(win.windowToken, 0)
        } catch (e: Exception) {
        }
        nameEt.clearFocus()
        urlEt.clearFocus()
    }

    private fun setInstallEnabled(on: Boolean) {
        installBtn.alpha = if (on) 1f else 0.5f
        installBtn.isClickable = on
    }

    private fun currentUrl(): String? = WebApps.normalizeUrl(urlEt.text?.toString() ?: "")

    /** Mostra o ícone que vai ser usado: foto escolhida > ícone do site > letra colorida. */
    private fun refreshPreview() {
        val url = currentUrl() ?: ""
        val bmp = pickedIcon
            ?: (if (siteCheck.checked) siteIcon else null)
            ?: WebApps.letterIcon(nameEt.text?.toString().orEmpty().ifBlank { WebApps.hostOf(url) }, url)
        iconIv.setImageDrawable(BitmapDrawable(act.resources, bmp))
    }

    /** Busca o ícone e o título do site (sem travar a tela). */
    private fun fetchSite() {
        val url = currentUrl() ?: return
        if (url == fetchedUrl) return
        fetchedUrl = url
        val g = ++gen
        status.text = "Buscando ícone e nome do site..."
        Thread {
            val info = WebApps.fetchInfo(url)
            handler.post {
                if (!open || g != gen) return@post
                siteIcon = info.icon
                siteTitle = info.title
                status.text = if (info.icon == null) "Ícone do site não encontrado" else ""
                if (nameEt.text.isNullOrBlank() && !info.title.isNullOrBlank()) nameEt.setText(info.title)
                refreshPreview()
            }
        }.start()
    }

    private fun install() {
        if (busy) return
        val url = currentUrl()
        if (url == null) {
            toast("Digite um link válido, por exemplo https://www.app.com")
            urlEt.requestFocus()
            return
        }
        hideKeyboard()
        val needFetch = (siteCheck.checked && pickedIcon == null && siteIcon == null && fetchedUrl != url) ||
            (nameEt.text.isNullOrBlank() && siteTitle == null && fetchedUrl != url)
        busy = true
        setInstallEnabled(false)
        status.text = "Instalando..."
        val g = ++gen
        Thread {
            val info = if (needFetch) WebApps.fetchInfo(url) else null
            handler.post {
                if (!open || g != gen) return@post
                busy = false
                finishInstall(url, info)
            }
        }.start()
    }

    private fun finishInstall(url: String, info: WebApps.SiteInfo?) {
        val title = siteTitle ?: info?.title
        val name = nameEt.text?.toString()?.trim().orEmpty().ifBlank { title ?: WebApps.hostOf(url) }
        val entry = WebApps.add(act, name, url)
        val picked = pickedIcon
        if (picked != null) {
            AppCustom.setIcon(act, entry.cn, picked)
        } else if (siteCheck.checked) {
            val ic = siteIcon ?: info?.icon
            if (ic != null) WebApps.saveSiteIcon(act, entry, ic)
        }
        val pin = pinCheck.checked
        val desk = deskCheck.checked
        close()
        onInstalled?.invoke(entry, pin, desk)
        toast("\"$name\" instalado")
    }

    // ================================================================== posição / tamanho

    private fun sizeWindow() {
        val rw = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = minOf(dp(640), rw - dp(24))
        win.layoutParams = lp
    }

    private fun place() {
        if (!placed) {
            val rw = root.width.toFloat()
            val rh = root.height.toFloat()
            win.x = ((rw - win.width) / 2f).coerceAtLeast(dp(8).toFloat())
            // mais para cima que o centro: sobra espaço para o teclado
            win.y = ((rh - win.height) / 4f).coerceAtLeast(dp(8).toFloat())
            placed = true
        } else {
            moveTo(win.x, win.y)
        }
        win.invalidate()
    }

    private fun moveTo(nx: Float, ny: Float) {
        val minX = -(win.width - dp(96)).toFloat()
        val maxX = (root.width - dp(96)).toFloat()
        val maxY = (root.height - dp(48)).toFloat().coerceAtLeast(0f)
        win.x = nx.coerceIn(minX, maxOf(minX, maxX))
        win.y = ny.coerceIn(0f, maxY)
        win.invalidate() // o vidro depende da posição na tela
    }

    // ================================================================== interface

    private fun makeBg(): android.graphics.drawable.Drawable {
        val radius = dp(14).toFloat()
        val border = GradientDrawable()
        border.cornerRadius = radius
        border.setColor(Color.TRANSPARENT)
        border.setStroke(dp(1), Color.parseColor("#40FFFFFF"))
        val base: android.graphics.drawable.Drawable = if (Glass.bitmap != null) {
            GlassDrawable(win, Color.parseColor("#D9181C22"), radius)
        } else {
            GradientDrawable().also {
                it.setColor(Color.parseColor("#F2181C22"))
                it.cornerRadius = radius
            }
        }
        return LayerDrawable(arrayOf(base, border))
    }

    private fun build() {
        layer.tag = CursorController.NOHAND

        win = FrameLayout(act)
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.elevation = dp(16).toFloat()
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                outline.alpha = 0.55f
            }
        }

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(buildTitleBar(), LinearLayout.LayoutParams(MATCH, dp(44)))

        val body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(22), dp(10), dp(22), dp(6))
        col.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- nome + link (esquerda) e ícone (direita)
        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        body.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val left = LinearLayout(act)
        left.orientation = LinearLayout.VERTICAL
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        nameEt = EditText(act)
        nameEt.hint = "Nome do aplicativo"
        nameEt.setHintTextColor(Color.parseColor("#80A9B3C6"))
        nameEt.setTextColor(ink)
        nameEt.textSize = 24f
        nameEt.background = null
        nameEt.setPadding(dp(2), dp(4), dp(2), dp(8))
        nameEt.isSingleLine = true
        nameEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        nameEt.imeOptions = EditorInfo.IME_ACTION_NEXT
        nameEt.tag = CursorController.NOHAND
        nameEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (pickedIcon == null && !(siteCheck.checked && siteIcon != null)) refreshPreview()
            }
        })
        left.addView(nameEt, LinearLayout.LayoutParams(MATCH, WRAP))

        val line = View(act)
        line.setBackgroundColor(Color.parseColor("#33FFFFFF"))
        left.addView(line, LinearLayout.LayoutParams(MATCH, dp(1)))

        urlEt = EditText(act)
        urlEt.hint = "https://www.app.com"
        urlEt.setHintTextColor(Color.parseColor("#80A9B3C6"))
        urlEt.setTextColor(ink)
        urlEt.textSize = 17f
        urlEt.setPadding(dp(12), dp(11), dp(12), dp(11))
        urlEt.isSingleLine = true
        urlEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlEt.imeOptions = EditorInfo.IME_ACTION_GO
        urlEt.tag = CursorController.NOHAND
        urlEt.background = GradientDrawable().also {
            it.setColor(field)
            it.cornerRadius = dp(8).toFloat()
        }
        urlEt.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard()
                fetchSite()
                true
            } else {
                false
            }
        }
        urlEt.setOnFocusChangeListener { _, has -> if (!has) fetchSite() }
        left.addView(urlEt, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        siteCheck = CheckRow("Usar o ícone do site (carregamento automático)", true) { on ->
            if (on) {
                pickedIcon = null
                if (siteIcon == null) fetchedUrl = null
                fetchSite()
            }
            refreshPreview()
        }
        left.addView(siteCheck, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        // ---- ícone: toque para trocar por uma foto da galeria
        val right = LinearLayout(act)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.CENTER_HORIZONTAL
        top.addView(right, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(20) })

        iconIv = ImageView(act)
        iconIv.scaleType = ImageView.ScaleType.FIT_CENTER
        iconIv.setPadding(dp(14), dp(14), dp(14), dp(14))
        iconIv.isClickable = true
        iconIv.background = GradientDrawable().also {
            it.setColor(Color.parseColor("#2EFFFFFF"))
            it.cornerRadius = dp(14).toFloat()
        }
        iconIv.setOnClickListener {
            hideKeyboard()
            act.pickWebAppIcon()
        }
        right.addView(iconIv, LinearLayout.LayoutParams(dp(96), dp(96)))

        val cap = text("Toque para trocar", 11.5f, sub)
        cap.gravity = Gravity.CENTER
        right.addView(cap, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })

        // ---- onde o app aparece
        body.addView(
            text("Onde aparece", 15f, ink, true),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) }
        )
        val always = CheckRow("Janela de aplicativos (sempre)", true) {}
        always.alpha = 0.7f
        always.isEnabled = false
        always.locked = true
        body.addView(always, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        pinCheck = CheckRow("Fixar na barra de tarefas", true) {}
        body.addView(pinCheck, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        deskCheck = CheckRow("Criar atalho na área de trabalho", true) {}
        body.addView(deskCheck, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // ---- rodapé: estado + Instalar
        val foot = LinearLayout(act)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.setPadding(dp(22), dp(10), dp(22), dp(16))
        col.addView(foot, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })

        status = text("", 12.5f, sub)
        foot.addView(status, LinearLayout.LayoutParams(0, WRAP, 1f))

        installBtn = text("Instalar", 14f, Color.parseColor("#0B1B2B"), true)
        installBtn.gravity = Gravity.CENTER
        installBtn.setPadding(dp(40), dp(11), dp(40), dp(11))
        installBtn.background = GradientDrawable().also {
            it.setColor(accent)
            it.cornerRadius = dp(8).toFloat()
        }
        installBtn.isClickable = true
        installBtn.setOnClickListener { install() }
        foot.addView(installBtn, LinearLayout.LayoutParams(WRAP, WRAP))

        layer.addView(win, FrameLayout.LayoutParams(dp(640), WRAP, Gravity.TOP or Gravity.START))
    }

    private fun buildTitleBar(): View {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(14), 0, dp(8), 0)

        val ic = ImageView(act)
        ic.setImageResource(R.drawable.ic_web_install)
        ic.setColorFilter(accent)
        bar.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))

        val t = text("Instalador de Aplicativos", 15f, ink)
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })

        val x = ImageView(act)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(ink)
        x.setPadding(dp(9), dp(9), dp(9), dp(9))
        x.isClickable = true
        x.background = closeBg(false)
        x.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = closeBg(true)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = closeBg(false)
            }
            false
        }
        x.setOnClickListener { close() }
        bar.addView(x, LinearLayout.LayoutParams(dp(36), dp(36)))

        var offX = 0f
        var offY = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                }
                MotionEvent.ACTION_MOVE -> moveTo(ev.rawX + offX, ev.rawY + offY)
            }
            true
        }
        return bar
    }

    private fun closeBg(hover: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(if (hover) Color.parseColor("#60E5484D") else Color.TRANSPARENT)
        g.cornerRadius = dp(8).toFloat()
        return g
    }

    private fun text(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(act)
        tv.text = t
        tv.textSize = sp
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return tv
    }

    /** Caixinha de marcar no estilo do Windows 11 (quadrado azul com o visto). */
    private inner class CheckRow(label: String, initial: Boolean, private val onChange: (Boolean) -> Unit) :
        LinearLayout(act) {
        private val box = FrameLayout(act)
        private val tick = ImageView(act)
        var locked = false

        var checked: Boolean = initial
            set(v) {
                field = v
                paint()
            }

        init {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            tick.setImageResource(R.drawable.ic_fm_check)
            tick.setColorFilter(Color.parseColor("#0B1B2B"))
            box.addView(tick, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            addView(box, LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(
                text(label, 15f, ink),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) }
            )
            isClickable = true
            setOnClickListener {
                if (locked) return@setOnClickListener
                checked = !checked
                onChange(checked)
            }
            paint()
        }

        private fun paint() {
            val g = GradientDrawable()
            g.cornerRadius = dp(6).toFloat()
            if (checked) {
                g.setColor(accent)
            } else {
                g.setColor(Color.TRANSPARENT)
                g.setStroke(dp(2), Color.parseColor("#99FFFFFF"))
            }
            box.background = g
            tick.visibility = if (checked) View.VISIBLE else View.INVISIBLE
        }
    }
}
