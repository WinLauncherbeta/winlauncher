package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Apps criados a partir de um link (instalador de aplicativos do WinLauncher).
 *
 * Cada app tem um componente "virtual" (com.example.winlauncher / web.<id>), igual aos apps nativos do launcher:
 * assim ele entra na janela de aplicativos, na barra de tarefas e na área de trabalho, e o nome e o ícone podem
 * ser trocados pelo [AppCustom]. Ao abrir, o link vai para o navegador embutido do launcher.
 *
 * A lista fica no SharedPreferences("win") (chave "webapps_json"); o ícone padrão (o do site) fica em
 * filesDir/webapp_icons/<id>.png. Um ícone escolhido pelo usuário (AppCustom) tem prioridade sobre o do site.
 */
object WebApps {
    const val PKG = "com.example.winlauncher"
    private const val PREFIX = "web."
    private const val KEY = "webapps_json"
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    class Entry(val id: String, val name: String, val url: String) {
        val cn: ComponentName get() = ComponentName(PKG, PREFIX + id)
    }

    class SiteInfo(val title: String?, val icon: Bitmap?)

    fun isWeb(cn: ComponentName): Boolean = cn.packageName == PKG && cn.className.startsWith(PREFIX)

    private fun sp(ctx: Context) = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)

    fun list(ctx: Context): List<Entry> {
        val raw = sp(ctx).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optString("id")
                val url = o.optString("url")
                if (id.isEmpty() || url.isEmpty()) null else Entry(id, o.optString("name", url), url)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(ctx: Context, l: List<Entry>) {
        val arr = JSONArray()
        for (e in l) arr.put(JSONObject().put("id", e.id).put("name", e.name).put("url", e.url))
        sp(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun find(ctx: Context, cn: ComponentName): Entry? =
        if (!isWeb(cn)) null else list(ctx).firstOrNull { it.cn == cn }

    fun add(ctx: Context, name: String, url: String): Entry {
        val e = Entry(java.lang.Long.toString(System.currentTimeMillis(), 36), name, url)
        save(ctx, list(ctx) + e)
        return e
    }

    fun remove(ctx: Context, cn: ComponentName) {
        val e = find(ctx, cn) ?: return
        save(ctx, list(ctx).filter { it.id != e.id })
        AppCustom.resetAll(ctx, cn)
        defaultIconFile(ctx, e.id).delete()
    }

    // ------------------------------------------------------------------ ícones

    private fun defaultIconFile(ctx: Context, id: String): File =
        File(File(ctx.filesDir, "webapp_icons").also { it.mkdirs() }, "$id.png")

    fun saveSiteIcon(ctx: Context, e: Entry, bmp: Bitmap) {
        defaultIconFile(ctx, e.id).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    /** Ícone do app: o escolhido pelo usuário, senão o do site, senão uma letra colorida. */
    fun icon(ctx: Context, e: Entry): Drawable {
        AppCustom.icon(ctx, e.cn)?.let { return it }
        val f = defaultIconFile(ctx, e.id)
        if (f.exists()) {
            BitmapFactory.decodeFile(f.absolutePath)?.let { return BitmapDrawable(ctx.resources, it) }
        }
        return BitmapDrawable(ctx.resources, letterIcon(e.name, e.url))
    }

    /** Quadrado colorido com a inicial do nome (a cor vem do endereço, então é sempre a mesma para o mesmo site). */
    fun letterIcon(name: String, url: String, size: Int = 192): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val hue = ((hostOf(url).hashCode() and 0x7FFFFFFF) % 360).toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.78f))
        c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.22f, size * 0.22f, p)
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = size * 0.5f
        val ch = name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "?"
        c.drawText(ch, size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p)
        return out
    }

    /** Encaixa a imagem num quadrado (sem cortar), mantendo a transparência. */
    fun square(src: Bitmap, size: Int = 192): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val s = minOf(size.toFloat() / src.width, size.toFloat() / src.height)
        val w = src.width * s
        val h = src.height * s
        c.drawBitmap(
            src, null,
            RectF((size - w) / 2f, (size - h) / 2f, (size + w) / 2f, (size + h) / 2f),
            Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        )
        return out
    }

    // ------------------------------------------------------------------ endereço

    /** Completa o endereço (https:// se faltar) e confere se parece válido. Null se não der para usar. */
    fun normalizeUrl(input: String): String? {
        var s = input.trim()
        if (s.isEmpty() || s.contains(' ')) return null
        if (!s.contains("://")) s = "https://$s"
        return try {
            val u = URL(s)
            if (u.protocol != "http" && u.protocol != "https") return null
            val h = u.host
            if (h.isNullOrEmpty() || (!h.contains('.') && h != "localhost")) null else s
        } catch (e: Exception) {
            null
        }
    }

    fun hostOf(url: String): String = try {
        URL(url).host.removePrefix("www.")
    } catch (e: Exception) {
        url
    }

    // ------------------------------------------------------------------ rede (chamar fora da thread principal)

    private fun readBytes(u: String, max: Int): ByteArray? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        if (c.responseCode !in 200..299) {
            null
        } else {
            c.inputStream.use { ins ->
                val bo = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                while (bo.size() < max) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    bo.write(buf, 0, n)
                }
                bo.toByteArray()
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun decode(b: ByteArray?): Bitmap? {
        if (b == null || b.isEmpty()) return null
        return try {
            BitmapFactory.decodeByteArray(b, 0, b.size)?.takeIf { it.width >= 16 && it.height >= 16 }
        } catch (e: Exception) {
            null
        }
    }

    private fun unescape(s: String): String = s
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">")

    /** Lê o título e o ícone do site (apple-touch-icon, <link rel=icon>, favicon do Google, /favicon.ico). */
    fun fetchInfo(url: String): SiteInfo {
        var title: String? = null
        val apple = ArrayList<String>()
        val icons = ArrayList<String>()
        val base = try {
            URL(url)
        } catch (e: Exception) {
            return SiteInfo(null, null)
        }
        val html = readBytes(url, 200_000)?.toString(Charsets.UTF_8)
        if (html != null) {
            title = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(html)?.groupValues?.get(1)?.let { unescape(it) }
                ?.replace(Regex("\\s+"), " ")?.trim()
                ?.split(Regex("\\s[-|–—·:]\\s"))?.firstOrNull()?.trim()?.take(40)
                ?.takeIf { it.isNotEmpty() }
            for (m in Regex("<link\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html)) {
                val tag = m.value
                val rel = Regex("rel=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1)?.lowercase() ?: continue
                val href = Regex("href=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1) ?: continue
                val abs = try {
                    URL(base, unescape(href)).toString()
                } catch (e: Exception) {
                    continue
                }
                if (rel.contains("apple-touch-icon")) apple.add(abs)
                else if (rel.split(" ").contains("icon")) icons.add(abs)
            }
        }
        val cands = ArrayList<String>()
        cands.addAll(apple)
        cands.addAll(icons)
        cands.add("https://www.google.com/s2/favicons?domain=${base.host}&sz=128")
        try {
            cands.add(URL(base, "/favicon.ico").toString())
        } catch (e: Exception) {
        }
        for (c in cands.distinct().take(8)) {
            val bmp = decode(readBytes(c, 2_000_000))
            if (bmp != null) return SiteInfo(title, square(bmp))
        }
        return SiteInfo(title, null)
    }
}
