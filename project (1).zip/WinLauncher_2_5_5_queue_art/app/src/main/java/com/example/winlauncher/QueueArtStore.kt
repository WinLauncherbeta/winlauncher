package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory

/**
 * Origem da capa de UMA faixa da fila, como o app de música a publicou em [android.media.MediaDescription]:
 * [bitmap] = iconBitmap (preferido) e [uri] = iconUri (alternativa, só usada se não houver bitmap). Nada além disso:
 * nunca captura de tela, nunca ícone de aplicativo. [key] identifica a origem para o cache (não é o id do protocolo).
 */
class QueueArtSource(val key: String, val bitmap: Bitmap?, val uri: String)

/**
 * Prepara e guarda as capas individuais da fila para o protocolo "queue_art".
 *
 *  - [prepare] (thread principal) recebe a janela de faixas que vai para o Remote. Cada origem ainda não conhecida vai para UMA
 *    thread própria ("WinRemote-<tag>-qart"): decodifica (bitmap ou iconUri), reduz para no máx. [SIDE] px (lado maior), comprime
 *    em JPEG e calcula o id (16 primeiros hex do SHA-256 do JPEG, igual ao protocolo). Nada disso roda na thread principal.
 *  - Quando termina algo novo, [onReady] é chamado UMA vez na thread principal (vários trabalhos seguidos viram um aviso);
 *    o RemoteBridge então reenvia a fila já com os ids.
 *  - [idOf] devolve o id da capa de uma faixa da janela ("" = sem capa disponível, ainda sendo preparada ou falhou).
 *  - [chunks] (qualquer thread) devolve os blocos "qart" de um id, para responder "art_req". Id desconhecido = null.
 *  - Cache: LRU por origem, até [MAX_ENTRIES] capas e [MAX_BYTES] bytes. Origem que falhou só é tentada de novo depois de
 *    [RETRY_FAIL_MS]. Sem capa de verdade, o campo "art" simplesmente não vai.
 */
class QueueArtStore(ctx: Context, tag: String, private val onReady: () -> Unit) {

    companion object {
        const val SIDE = 256
        const val MAX_ENTRIES = 96
        const val MAX_BYTES = 6 * 1024 * 1024
        const val RETRY_FAIL_MS = 60_000L
        private const val MAX_DOWNLOAD = 8 * 1024 * 1024
        private val QUALITIES = intArrayOf(85, 70, 55, 40)

        /** Reduz [src] para no máximo [SIDE] px no lado maior e comprime em JPEG de até [RemoteProtocol.MAX_ART_BYTES]. null se não couber. */
        fun encode(src: Bitmap): ByteArray? {
            if (src.isRecycled) return null
            val soft: Bitmap? = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else null
            val base: Bitmap = soft ?: src
            try {
                val w0 = base.width
                val h0 = base.height
                if (w0 <= 0 || h0 <= 0) return null
                val scale = minOf(1f, SIDE.toFloat() / maxOf(w0, h0).toFloat())
                val w = maxOf(1, Math.round(w0 * scale))
                val h = maxOf(1, Math.round(h0 * scale))
                val scaled: Bitmap = if (w == w0 && h == h0) base else Bitmap.createScaledBitmap(base, w, h, true)
                try {
                    for (q in QUALITIES) {
                        val bos = ByteArrayOutputStream()
                        val ok = scaled.compress(Bitmap.CompressFormat.JPEG, q, bos)
                        val n = bos.size()
                        if (ok && n >= 1 && n <= RemoteProtocol.MAX_ART_BYTES) return bos.toByteArray()
                    }
                    return null
                } finally {
                    if (scaled !== base) scaled.recycle()
                }
            } finally {
                if (soft != null) soft.recycle()
            }
        }
    }

    private class Entry(val id: String, val bytes: ByteArray)

    private val app: Context = ctx.applicationContext
    private val ui = Handler(Looper.getMainLooper())
    private val exec: ExecutorService = Executors.newSingleThreadExecutor(ThreadFactory { r ->
        val t = Thread(r, "WinRemote-$tag-qart")
        t.isDaemon = true
        t
    })
    private val lock = Any()

    // protegidos por [lock]
    private val cache = object : LinkedHashMap<String, Entry>(16, 0.75f, true) {}
    private var cacheBytes = 0
    private val failed = HashMap<String, Long>()
    private val queued = HashSet<String>()

    // thread principal
    private var idByQueueId: Map<Long, String> = emptyMap()
    private var notifyPosted = false

    @Volatile
    private var closed = false

    /**
     * Thread principal. [window] = faixas que vão no próximo "queue" (queueId + origem da capa, null se a faixa não tem imagem).
     * Mantém o mapa queueId -> id das capas já prontas e agenda o que falta.
     */
    fun prepare(window: List<Pair<Long, QueueArtSource?>>) {
        if (closed) return
        val map = HashMap<Long, String>()
        val todo = ArrayList<QueueArtSource>()
        val now = System.currentTimeMillis()
        synchronized(lock) {
            for ((qid, src) in window) {
                if (src == null) continue
                val e = cache[src.key]
                if (e != null) {
                    map[qid] = e.id
                    continue
                }
                val f = failed[src.key]
                if (f != null && now - f < RETRY_FAIL_MS) continue
                if (queued.add(src.key)) todo.add(src)
            }
        }
        idByQueueId = map
        for (src in todo) {
            try {
                exec.execute { work(src) }
            } catch (e: RejectedExecutionException) {
                synchronized(lock) { queued.remove(src.key) }
            }
        }
    }

    /** Thread principal. Id da capa pronta da faixa [queueId] da última janela preparada; "" se não há. */
    fun idOf(queueId: Long): String = idByQueueId[queueId] ?: ""

    /** Qualquer thread. Blocos "qart" da capa [artId], ou null se este id não está (mais) no cache. */
    fun chunks(artId: String): List<RemoteProtocol.Message.QueueArtChunk>? {
        val bytes: ByteArray = synchronized(lock) {
            var found: ByteArray? = null
            for (e in cache.values) {
                if (e.id == artId) {
                    found = e.bytes
                    break
                }
            }
            found
        } ?: return null
        return try {
            RemoteProtocol.queueArtChunks(bytes)
        } catch (e: Throwable) {
            null
        }
    }

    /** Quantas capas estão em cache (diagnóstico/autoteste). */
    fun size(): Int = synchronized(lock) { cache.size }

    fun shutdown() {
        closed = true
        try {
            exec.shutdownNow()
        } catch (e: Throwable) {
        }
        synchronized(lock) {
            cache.clear()
            cacheBytes = 0
            failed.clear()
            queued.clear()
        }
        idByQueueId = emptyMap()
    }

    // ------------------------------------------------------------------ thread própria

    private fun work(src: QueueArtSource) {
        var entry: Entry? = null
        try {
            if (!closed) {
                val bmp: Bitmap? = src.bitmap ?: if (src.uri.isNotEmpty()) decodeUri(src.uri) else null
                val jpeg = if (bmp != null) encode(bmp) else null
                if (jpeg != null) {
                    val sha = RemoteProtocol.sha256Hex(jpeg)
                    entry = Entry(RemoteProtocol.artIdOf(sha), jpeg)
                }
                // bitmap vindo da URI é nosso: libera. O de iconBitmap pertence ao app de música/Hub: não mexe.
                if (bmp != null && src.bitmap == null) bmp.recycle()
            }
        } catch (t: Throwable) {
            entry = null
        }
        var notify = false
        synchronized(lock) {
            queued.remove(src.key)
            val e = entry
            if (e == null) {
                failed[src.key] = System.currentTimeMillis()
                if (failed.size > 256) failed.entries.removeAll { System.currentTimeMillis() - it.value > RETRY_FAIL_MS }
            } else {
                val old = cache.put(src.key, e)
                if (old != null) cacheBytes -= old.bytes.size
                cacheBytes += e.bytes.size
                while (cache.size > MAX_ENTRIES || cacheBytes > MAX_BYTES) {
                    val iter = cache.entries.iterator()
                    if (!iter.hasNext()) break
                    val x = iter.next()
                    cacheBytes -= x.value.bytes.size
                    iter.remove()
                }
                notify = true
            }
        }
        if (notify && !closed) postReady()
    }

    /** Vários trabalhos terminando juntos geram um único aviso. */
    private fun postReady() {
        ui.post {
            if (closed) return@post
            try {
                onReady()
            } catch (e: Throwable) {
            }
        }
    }

    /** iconUri: http(s) (mesmos limites da capa do player: 4 s, 8 MB) ou content/file. Só imagem; qualquer outra coisa falha. */
    private fun decodeUri(uri: String): Bitmap? {
        val bytes: ByteArray = if (uri.startsWith("http://") || uri.startsWith("https://")) {
            val con = URL(uri).openConnection() as HttpURLConnection
            con.connectTimeout = 4000
            con.readTimeout = 4000
            try {
                con.inputStream.use { readLimited(it) } ?: return null
            } finally {
                con.disconnect()
            }
        } else if (uri.startsWith("content://") || uri.startsWith("file://")) {
            app.contentResolver.openInputStream(Uri.parse(uri))?.use { readLimited(it) } ?: return null
        } else {
            return null
        }
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= SIDE && o.outHeight / (sample * 2) >= SIDE) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    private fun readLimited(input: java.io.InputStream): ByteArray? {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            bos.write(buf, 0, n)
            if (bos.size() > MAX_DOWNLOAD) return null
        }
        return bos.toByteArray()
    }
}
