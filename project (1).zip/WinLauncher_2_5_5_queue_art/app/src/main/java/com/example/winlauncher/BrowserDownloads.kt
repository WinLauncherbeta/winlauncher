package com.example.winlauncher

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

const val DL_RUNNING = 0
const val DL_DONE = 1
const val DL_FAILED = 2

/** Um download do navegador (em andamento, concluído ou com erro). */
class DownloadItem(
    val id: Long,
    @Volatile var name: String,
    val url: String
) {
    @Volatile var path: String = ""
    @Volatile var total: Long = -1L
    @Volatile var done: Long = 0L
    @Volatile var state: Int = DL_RUNNING
    @Volatile var cancelled: Boolean = false
    @Volatile var error: String = ""
    var time: Long = System.currentTimeMillis()
}

/**
 * Downloads do navegador embutido. Baixa por conta própria (sem abrir aba e sem depender do DownloadManager, que só
 * aceita http/https): links http/https, data: e blob:. Guarda a lista dos concluídos para a tela "Downloads".
 */
class BrowserDownloads private constructor(private val ctx: Context) {

    companion object {
        private var inst: BrowserDownloads? = null

        fun get(ctx: Context): BrowserDownloads {
            val i = inst
            if (i != null) return i
            val n = BrowserDownloads(ctx.applicationContext)
            inst = n
            return n
        }

        fun clean(raw: String?): String {
            var n = (raw ?: "").replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.')
            if (n.isEmpty()) n = "download"
            if (n.length > 120) {
                val dot = n.lastIndexOf('.')
                val ext = if (dot > 0 && n.length - dot <= 10) n.substring(dot) else ""
                n = n.substring(0, 120 - ext.length) + ext
            }
            return n
        }
    }

    /** Mais novo primeiro. Só mexa nesta lista na thread principal. */
    val items = ArrayList<DownloadItem>()

    /** Chamados na thread principal quando algo muda (novo download, progresso, fim). */
    val listeners = ArrayList<() -> Unit>()

    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val store = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)
    private var nextId = System.currentTimeMillis()
    private val blobs = HashMap<String, BlobJob>()
    private var lastNotify = 0L

    /** Ponte JavaScript usada para baixar blob: (cada pedido usa um token de uso único). */
    val bridge = Bridge()

    init {
        load()
    }

    // ------------------------------------------------------------------ persistência

    private fun load() {
        try {
            val arr = JSONArray(store.getString("browserDownloads", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val it = DownloadItem(o.getLong("id"), o.getString("name"), o.optString("url"))
                it.path = o.optString("path")
                it.total = o.optLong("total", -1L)
                it.done = it.total
                it.time = o.optLong("time", 0L)
                it.state = DL_DONE
                items.add(it)
            }
        } catch (e: Exception) {
        }
    }

    private fun save() {
        try {
            val arr = JSONArray()
            for (it in items) {
                if (it.state != DL_DONE) continue
                val o = JSONObject()
                o.put("id", it.id)
                o.put("name", it.name)
                o.put("url", it.url)
                o.put("path", it.path)
                o.put("total", it.total)
                o.put("time", it.time)
                arr.put(o)
                if (arr.length() >= 100) break
            }
            store.edit().putString("browserDownloads", arr.toString()).apply()
        } catch (e: Exception) {
        }
    }

    private fun changed(force: Boolean = true) {
        val now = System.currentTimeMillis()
        if (!force && now - lastNotify < 250) return
        lastNotify = now
        main.post { for (l in ArrayList(listeners)) l() }
    }

    // ------------------------------------------------------------------ ações

    fun runningCount(): Int = items.count { it.state == DL_RUNNING }

    fun cancel(item: DownloadItem) {
        item.cancelled = true
        if (item.state == DL_RUNNING) {
            // blob: o JS pode ainda estar enviando pedaços; o próximo pedaço percebe o cancelamento
            removeLater(item)
        }
    }

    fun remove(item: DownloadItem) {
        items.remove(item)
        save()
        changed()
    }

    fun clearFinished() {
        items.removeAll { it.state != DL_RUNNING }
        save()
        changed()
    }

    private fun removeLater(item: DownloadItem) {
        main.post {
            items.remove(item)
            changed()
        }
    }

    // ------------------------------------------------------------------ pasta e nomes

    private fun targetDir(): File {
        try {
            val pub = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pub.exists() || pub.mkdirs()) {
                val t = File(pub, ".wl_test" + System.nanoTime())
                if (t.createNewFile()) {
                    t.delete()
                    return pub
                }
            }
        } catch (e: Exception) {
        }
        val app = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        if (app != null) {
            app.mkdirs()
            return app
        }
        return ctx.cacheDir
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 1
        while (f.exists() && n < 1000) {
            f = File(dir, "$base ($n)$ext")
            n++
        }
        return f
    }

    private fun finish(item: DownloadItem, tmp: File, dest: File) {
        if (!tmp.renameTo(dest)) {
            tmp.copyTo(dest, true)
            tmp.delete()
        }
        item.path = dest.absolutePath
        item.name = dest.name
        item.time = System.currentTimeMillis()
        if (item.total < 0) item.total = dest.length()
        item.done = item.total
        item.state = DL_DONE
        try {
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), null, null)
        } catch (e: Exception) {
        }
        main.post { save() }
        changed()
    }

    private fun fail(item: DownloadItem, tmp: File?, msg: String) {
        try {
            tmp?.delete()
        } catch (e: Exception) {
        }
        if (item.cancelled) {
            removeLater(item)
            return
        }
        item.error = msg
        item.state = DL_FAILED
        changed()
    }

    // ------------------------------------------------------------------ http / https

    fun start(url: String, ua: String?, cd: String?, mime: String?, referer: String?) {
        val item = DownloadItem(nextId++, clean(URLUtil.guessFileName(url, cd, mime)), url)
        items.add(0, item)
        changed()
        pool.execute { runHttp(item, ua, referer) }
    }

    private fun openConn(u: String, ua: String?, referer: String?): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.instanceFollowRedirects = false
        if (!ua.isNullOrBlank()) c.setRequestProperty("User-Agent", ua)
        val ck = CookieManager.getInstance().getCookie(u)
        if (!ck.isNullOrBlank()) c.setRequestProperty("Cookie", ck)
        if (!referer.isNullOrBlank()) c.setRequestProperty("Referer", referer)
        return c
    }

    private fun runHttp(item: DownloadItem, ua: String?, referer: String?) {
        var conn: HttpURLConnection? = null
        var tmp: File? = null
        try {
            var u = item.url
            var hops = 0
            while (true) {
                conn = openConn(u, ua, referer)
                val code = conn.responseCode
                if (code in 300..399 && hops < 8) {
                    val loc = conn.getHeaderField("Location")
                    if (loc.isNullOrBlank()) break
                    u = URL(URL(u), loc).toString()
                    conn.disconnect()
                    hops++
                    continue
                }
                if (code !in 200..299) throw java.io.IOException("Erro $code do servidor")
                break
            }
            val c = conn!!
            item.total = c.contentLengthLong
            val cdh = c.getHeaderField("Content-Disposition")
            if (!cdh.isNullOrBlank()) {
                item.name = clean(URLUtil.guessFileName(u, cdh, c.contentType?.substringBefore(';')))
            }
            val dir = targetDir()
            val dest = uniqueFile(dir, item.name)
            item.name = dest.name
            val part = File(dir, dest.name + ".part")
            tmp = part
            changed()
            c.inputStream.use { ins ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        if (item.cancelled) throw java.io.IOException("cancelado")
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        item.done += n
                        changed(false)
                    }
                }
            }
            finish(item, part, dest)
        } catch (e: Exception) {
            fail(item, tmp, e.message ?: "Falha no download")
        } finally {
            try {
                conn?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ data:

    fun startData(dataUrl: String, cd: String?) {
        val comma = dataUrl.indexOf(',')
        if (comma < 5) return
        val meta = dataUrl.substring(5, comma)
        val mime = meta.substringBefore(';').ifBlank { "application/octet-stream" }
        val item = DownloadItem(nextId++, clean(URLUtil.guessFileName("download", cd, mime)), dataUrl.take(40))
        items.add(0, item)
        changed()
        pool.execute {
            var tmp: File? = null
            try {
                val payload = dataUrl.substring(comma + 1)
                val bytes = if (meta.contains(";base64")) Base64.decode(payload, Base64.DEFAULT) else Uri.decode(payload).toByteArray()
                val dir = targetDir()
                val dest = uniqueFile(dir, item.name)
                item.name = dest.name
                val part = File(dir, dest.name + ".part")
                tmp = part
                item.total = bytes.size.toLong()
                FileOutputStream(part).use { it.write(bytes) }
                item.done = item.total
                finish(item, part, dest)
            } catch (e: Exception) {
                fail(item, tmp, e.message ?: "Falha ao salvar")
            }
        }
    }

    // ------------------------------------------------------------------ blob:

    private class BlobJob(val item: DownloadItem) {
        var out: FileOutputStream? = null
        var tmp: File? = null
        var dest: File? = null
    }

    /** Baixa um blob: pedindo à própria página que leia o blob e mande os pedaços pela ponte. */
    fun startBlob(web: WebView, url: String, cd: String?, mime: String?) {
        val token = java.util.UUID.randomUUID().toString().replace("-", "")
        val item = DownloadItem(nextId++, clean(URLUtil.guessFileName(url, cd, mime)), url)
        items.add(0, item)
        synchronized(blobs) { blobs[token] = BlobJob(item) }
        changed()
        val safeUrl = url.replace("\\", "\\\\").replace("'", "\\'")
        val js = "(function(){var T='" + token + "';function f(m){try{WinDl.fail(T,String(m))}catch(e){}}" +
            "try{fetch('" + safeUrl + "').then(function(r){return r.blob()}).then(function(b){" +
            "WinDl.begin(T,String(b.size),b.type||'');var CH=786432,pos=0;" +
            "function next(){if(pos>=b.size){WinDl.end(T);return}" +
            "var fr=new FileReader();" +
            "fr.onload=function(){var s=fr.result;if(WinDl.chunk(T,s.substring(s.indexOf(',')+1))===false)return;pos+=CH;next()};" +
            "fr.onerror=function(){f('leitura')};fr.readAsDataURL(b.slice(pos,pos+CH))}" +
            "next()}).catch(function(e){f(e)})}catch(e){f(e)}})()"
        try {
            web.evaluateJavascript(js, null)
        } catch (e: Exception) {
            bridge.fail(token, "falha")
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun begin(token: String, size: String, mime: String) {
            val job = synchronized(blobs) { blobs[token] } ?: return
            val item = job.item
            try {
                item.total = size.toLongOrNull() ?: -1L
                if (!item.name.contains('.') && mime.isNotBlank()) {
                    item.name = clean(URLUtil.guessFileName("download", null, mime))
                }
                val dir = targetDir()
                val dest = uniqueFile(dir, item.name)
                item.name = dest.name
                val part = File(dir, dest.name + ".part")
                job.dest = dest
                job.tmp = part
                job.out = FileOutputStream(part)
                changed()
            } catch (e: Exception) {
                fail(token, e.message ?: "falha")
            }
        }

        /** Retorna false para a página parar de enviar (cancelado ou erro). */
        @JavascriptInterface
        fun chunk(token: String, b64: String): Boolean {
            val job = synchronized(blobs) { blobs[token] } ?: return false
            if (job.item.cancelled) {
                fail(token, "cancelado")
                return false
            }
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                job.out?.write(bytes)
                job.item.done += bytes.size
                changed(false)
                true
            } catch (e: Exception) {
                fail(token, e.message ?: "falha")
                false
            }
        }

        @JavascriptInterface
        fun end(token: String) {
            val job = synchronized(blobs) { blobs.remove(token) } ?: return
            try {
                job.out?.close()
                val tmp = job.tmp
                val dest = job.dest
                if (tmp == null || dest == null) throw java.io.IOException("sem arquivo")
                finish(job.item, tmp, dest)
            } catch (e: Exception) {
                this@BrowserDownloads.fail(job.item, job.tmp, e.message ?: "falha")
            }
        }

        @JavascriptInterface
        fun fail(token: String, msg: String) {
            val job = synchronized(blobs) { blobs.remove(token) } ?: return
            try {
                job.out?.close()
            } catch (e: Exception) {
            }
            this@BrowserDownloads.fail(job.item, job.tmp, msg)
        }
    }
}
