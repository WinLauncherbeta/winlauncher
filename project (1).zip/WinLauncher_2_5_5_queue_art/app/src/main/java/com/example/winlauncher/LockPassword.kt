package com.example.winlauncher

import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom

/** Senha da tela de bloqueio do WinLauncher. Guarda só o hash (com sal), nunca a senha em texto. */
object LockPassword {
    private const val K_HASH = "lock_pass_hash"
    private const val K_SALT = "lock_pass_salt"
    const val MIN_LENGTH = 4

    fun has(p: SharedPreferences): Boolean = !p.getString(K_HASH, null).isNullOrEmpty()

    fun set(p: SharedPreferences, pass: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString(K_SALT, hex(salt))
            .putString(K_HASH, digest(salt, pass))
            .apply()
    }

    fun check(p: SharedPreferences, pass: String): Boolean {
        val saltHex = p.getString(K_SALT, null) ?: return false
        val stored = p.getString(K_HASH, null) ?: return false
        return digest(unhex(saltHex), pass) == stored
    }

    fun remove(p: SharedPreferences) {
        p.edit().remove(K_HASH).remove(K_SALT).apply()
    }

    private fun digest(salt: ByteArray, pass: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        return hex(md.digest(pass.toByteArray(Charsets.UTF_8)))
    }

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun unhex(s: String): ByteArray =
        ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}
