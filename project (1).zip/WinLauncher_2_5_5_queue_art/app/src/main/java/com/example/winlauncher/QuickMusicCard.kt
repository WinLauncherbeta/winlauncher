package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Cartão de música do painel rápido (entre os botões e o brilho).
 *
 * - Aparece só enquanto algum app estiver tocando música; pausou ou parou, ele some (com um pequeno
 *   atraso para não piscar na troca de faixa).
 * - Retângulo de cantos retos, com as cores do tema claro/escuro que o launcher já usa.
 * - Linha de progresso clicável: toque (ou arraste) em qualquer ponto para pular para aquela parte.
 * - Usa o mesmo acesso às notificações que o launcher já pede. Sem ele, o cartão simplesmente não aparece.
 */
class QuickMusicCard(private val ctx: Context) : LinearLayout(ctx) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d + 0.5f).toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val listener = ComponentName(ctx, LauncherNotificationListener::class.java)

    private var textColor = Color.WHITE
    private var accent = Color.parseColor("#4FC3F7")

    private val cover = ImageView(ctx)
    private val title = TextView(ctx)
    private val artist = TextView(ctx)
    private val btnPrev = ImageView(ctx)
    private val btnPlay = ImageView(ctx)
    private val btnNext = ImageView(ctx)
    private val seekLine = SeekLine(ctx)

    private var msm: MediaSessionManager? = null
    private var ctrl: MediaController? = null
    private var listening = false

    private var durationMs = 0L
    private var basePosMs = 0L
    private var baseTimeMs = 0L
    private var speed = 1f
    private var playing = false
    private var scrubbing = false

    private val tick = object : Runnable {
        override fun run() {
            if (!playing) return
            if (!scrubbing) seekLine.setFraction(currentFraction())
            ui.postDelayed(this, 500L)
        }
    }

    private val hideRun = Runnable { setShown(false) }

    init {
        orientation = VERTICAL
        background = ColorDrawable(Color.TRANSPARENT)
        visibility = GONE
        setPadding(dp(8), dp(6), dp(8), dp(6))

        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        addView(row, LayoutParams(MATCH, WRAP))

        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        cover.setImageResource(R.drawable.ic_music_note)
        row.addView(cover, LayoutParams(dp(40), dp(40)))

        val col = LinearLayout(ctx)
        col.orientation = VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        row.addView(col, LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })

        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        title.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        title.isSingleLine = true
        title.ellipsize = TextUtils.TruncateAt.MARQUEE
        title.marqueeRepeatLimit = -1
        title.isSelected = true
        col.addView(title, LayoutParams(MATCH, WRAP))

        artist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        artist.isSingleLine = true
        artist.ellipsize = TextUtils.TruncateAt.END
        col.addView(artist, LayoutParams(MATCH, WRAP))
        col.addView(seekLine, LayoutParams(MATCH, dp(14)).apply { topMargin = dp(3) })

        val controls = LinearLayout(ctx)
        controls.orientation = HORIZONTAL
        controls.gravity = Gravity.CENTER_VERTICAL
        row.addView(controls, LayoutParams(WRAP, WRAP))
        for ((iv, res) in listOf(
            btnPrev to R.drawable.ic_media_prev,
            btnPlay to R.drawable.ic_media_play,
            btnNext to R.drawable.ic_media_next
        )) {
            iv.setImageResource(res)
            iv.setPadding(dp(6), dp(6), dp(6), dp(6))
            iv.isClickable = true
            controls.addView(iv, LayoutParams(dp(30), dp(30)))
        }
        btnPrev.setOnClickListener { try { ctrl?.transportControls?.skipToPrevious() } catch (e: Exception) {} }
        btnNext.setOnClickListener { try { ctrl?.transportControls?.skipToNext() } catch (e: Exception) {} }
        btnPlay.setOnClickListener {
            val c = ctrl ?: return@setOnClickListener
            try {
                if (isPlayingState(c)) c.transportControls.pause() else c.transportControls.play()
            } catch (e: Exception) {}
        }

        seekLine.onSeekRequest = { fraction, finished ->
            scrubbing = !finished
            if (finished) {
                val c = ctrl
                if (c != null && durationMs > 0) {
                    try {
                        c.transportControls.seekTo((durationMs * fraction).toLong())
                    } catch (e: Exception) {}
                    basePosMs = (durationMs * fraction).toLong()
                    baseTimeMs = SystemClock.elapsedRealtime()
                }
            }
        }

        applyColors(textColor, Color.TRANSPARENT, accent)
    }

    // ------------------------------------------------------------------ tema

    /** Chamado pelo launcher quando o tema claro/escuro (ou a cor de destaque) muda. */
    fun applyColors(text: Int, bg: Int, accentColor: Int) {
        textColor = text
        accent = accentColor
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(bg)
        }
        title.setTextColor(text)
        artist.setTextColor((text and 0xFFFFFF) or (0xB3 shl 24))
        for (iv in listOf(btnPrev, btnPlay, btnNext)) iv.setColorFilter(text)
        seekLine.colors(text, accentColor)
        invalidate()
    }

    // ------------------------------------------------------------------ sessões

    fun start() {
        if (listening) return
        listening = true
        val m = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, listener, ui)
            bind(m.getActiveSessions(listener))
        } catch (e: SecurityException) {
            bind(emptyList())
        } catch (e: Exception) {
            bind(emptyList())
        }
    }

    fun stop() {
        if (!listening) return
        listening = false
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) {}
        try { ctrl?.unregisterCallback(cb) } catch (e: Exception) {}
        ctrl = null
        playing = false
        ui.removeCallbacks(tick)
        ui.removeCallbacks(hideRun)
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list ?: emptyList())
    }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = render()
        override fun onPlaybackStateChanged(state: PlaybackState?) = render()
        override fun onSessionDestroyed() = refreshSessions()
    }

    private fun isPlayingState(c: MediaController): Boolean {
        val s = c.playbackState?.state
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    private fun refreshSessions() {
        val m = msm ?: return
        try { bind(m.getActiveSessions(listener)) } catch (e: Exception) { bind(emptyList()) }
    }

    private fun bind(list: List<MediaController>) {
        val best = list.firstOrNull { isPlayingState(it) } ?: list.firstOrNull { it.metadata != null }
        if (best?.sessionToken != ctrl?.sessionToken) {
            try { ctrl?.unregisterCallback(cb) } catch (e: Exception) {}
            ctrl = best
            try { best?.registerCallback(cb, ui) } catch (e: Exception) {}
        }
        render()
    }

    // ------------------------------------------------------------------ conteúdo

    private fun render() {
        val c = ctrl
        val md = c?.metadata
        val isPlay = c != null && isPlayingState(c)

        if (md != null) {
            title.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            val a = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
            artist.text = a
            artist.visibility = if (a.isBlank()) GONE else VISIBLE
            durationMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION).coerceAtLeast(0L)
            val bmp: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            if (bmp != null) cover.setImageBitmap(bmp) else cover.setImageResource(R.drawable.ic_music_note)
        }

        val st = c?.playbackState
        if (st != null) {
            basePosMs = st.position
            baseTimeMs = st.lastPositionUpdateTime
            speed = if (st.playbackSpeed > 0f) st.playbackSpeed else 1f
        }
        playing = isPlay
        btnPlay.setImageResource(if (isPlay) R.drawable.ic_media_pause else R.drawable.ic_media_play)

        if (!scrubbing) seekLine.setFraction(currentFraction())

        ui.removeCallbacks(tick)
        if (isPlay) {
            ui.removeCallbacks(hideRun)
            setShown(true)
            ui.post(tick)
        } else {
            // pequena tolerância: na troca de faixa o estado passa por "parado" por um instante
            ui.removeCallbacks(hideRun)
            ui.postDelayed(hideRun, 1200L)
        }
    }

    private fun setShown(show: Boolean) {
        val was = visibility == VISIBLE
        if (show == was) return
        visibility = if (show) VISIBLE else GONE
        if (!show) playing = false
    }

    private fun currentFraction(): Float {
        if (durationMs <= 0L) return 0f
        val pos = if (playing) basePosMs + ((SystemClock.elapsedRealtime() - baseTimeMs) * speed).toLong()
        else basePosMs
        return (pos.toFloat() / durationMs).coerceIn(0f, 1f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    /** Linha de progresso: traço fino, bolinha no ponto atual; toque ou arraste para escolher a parte. */
    private class SeekLine(ctx: Context) : View(ctx) {
        var onSeekRequest: ((Float, Boolean) -> Unit)? = null
        private var fraction = 0f
        private var trackColor = Color.WHITE
        private var fillColor = Color.CYAN
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val density = resources.displayMetrics.density

        fun colors(track: Int, fill: Int) {
            trackColor = track
            fillColor = fill
            invalidate()
        }

        fun setFraction(f: Float) {
            fraction = f.coerceIn(0f, 1f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val cy = height / 2f
            val pad = 5f * density
            val x0 = pad
            val x1 = width - pad
            val x = x0 + (x1 - x0) * fraction
            paint.strokeWidth = 2f * density
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = (trackColor and 0xFFFFFF) or (0x66 shl 24)
            canvas.drawLine(x0, cy, x1, cy, paint)
            paint.color = fillColor
            canvas.drawLine(x0, cy, x, cy, paint)
            paint.style = Paint.Style.FILL
            canvas.drawCircle(x, cy, 4f * density, paint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val pad = 5f * density
            val w = (width - 2 * pad).coerceAtLeast(1f)
            val f = ((event.x - pad) / w).coerceIn(0f, 1f)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    fraction = f
                    invalidate()
                    onSeekRequest?.invoke(f, false)
                }
                MotionEvent.ACTION_MOVE -> {
                    fraction = f
                    invalidate()
                    onSeekRequest?.invoke(f, false)
                }
                MotionEvent.ACTION_UP -> {
                    fraction = f
                    invalidate()
                    onSeekRequest?.invoke(f, true)
                }
                MotionEvent.ACTION_CANCEL -> onSeekRequest?.invoke(fraction, true)
            }
            return true
        }
    }
}
