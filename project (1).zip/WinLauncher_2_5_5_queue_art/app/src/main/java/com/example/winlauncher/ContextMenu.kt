package com.example.winlauncher

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MenuItem(
    val label: String,
    val icon: Int = 0,
    val checked: Boolean = false,
    val enabled: Boolean = true,
    val children: List<MenuItem>? = null,
    val panel: (() -> View)? = null,
    val action: (() -> Unit)? = null
)

/**
 * ScrollView que rola com a roda do mouse (e também com o dedo). O evento da roda é tratado ANTES dos filhos,
 * então nenhum controle dentro do painel (barras, botões, linhas do menu) consegue engolir a rolagem.
 */
class WheelScrollView(ctx: Context, private val step: Int) : ScrollView(ctx) {
    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_SCROLL && ev.isFromSource(InputDevice.SOURCE_CLASS_POINTER)) {
            val range = (getChildAt(0)?.height ?: 0) - (height - paddingTop - paddingBottom)
            if (range > 0) {
                val dy = (-ev.getAxisValue(MotionEvent.AXIS_VSCROLL) * step).toInt()
                if (dy != 0) scrollBy(0, dy)
                return true
            }
        }
        return super.dispatchGenericMotionEvent(ev)
    }
}

/**
 * Menu de contexto estilo Windows 11: cartão compacto, branco ~70% translúcido, cantos
 * arredondados e sombra suave. Submenus abrem ao passar o mouse (ou por toque).
 */
class ContextMenuHost(
    private val act: Activity,
    private val root: FrameLayout,
    private val hoverOpens: () -> Boolean,
    private val isDark: () -> Boolean = { false }
) {
    val layer = FrameLayout(act)

    private val cards = ArrayList<View>()
    private val lists = ArrayList<List<MenuItem>>()
    private val d = act.resources.displayMetrics.density
    // Cores do menu do Windows 11: claro (#F9F9F9) ou escuro (#2C2C2C)
    private val dark: Boolean get() = isDark()
    private val ink: Int get() = Color.parseColor(if (dark) "#FFFFFF" else "#1F1F1F")
    private val hoverBg: Int get() = Color.parseColor(if (dark) "#1AFFFFFF" else "#0F000000")

    private companion object {
        /** Opacidade da película do vidro, igual em todos os cartões. */
        const val GLASS_TINT = 0xEB
    }

    val isShowing: Boolean get() = layer.visibility == View.VISIBLE

    init {
        layer.visibility = View.GONE
        layer.tag = CursorController.NOHAND
        layer.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) hide()
            true
        }
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private fun sw(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun sh(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    fun hide() {
        layer.removeAllViews()
        cards.clear()
        lists.clear()
        layer.visibility = View.GONE
    }

    /** x e y em coordenadas de tela (rawX/rawY). */
    fun show(items: List<MenuItem>, screenX: Int, screenY: Int) {
        hide()
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        val x = screenX - loc[0]
        val y = screenY - loc[1]
        layer.visibility = View.VISIBLE
        val card = buildList(items, 0)
        lists.add(items)
        cards.add(card)
        layer.addView(card)
        val m = dp(8)
        val w = cardWidth(card)
        val full = measuredHeight(card, w)
        val h = minOf(full, sh() - 2 * m) // lista maior que a tela: limita e rola
        var left = x
        if (left + w > sw() - m) left = x - w
        left = left.coerceIn(m, maxOf(m, sw() - w - m))
        var top = y
        if (top + h > sh() - m) top = y - h
        top = top.coerceIn(m, maxOf(m, sh() - h - m))
        position(card, left, top, w, if (h < full) h else ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    /** Abre programaticamente a linha [index] do nível [level] (usado após recriar a tela). */
    fun openRow(level: Int, index: Int) {
        if (level >= cards.size) return
        val items = lists[level]
        val holder = cards[level]
        val card = ((holder as? ScrollView)?.getChildAt(0) as? ViewGroup) ?: (holder as? ViewGroup) ?: return
        if (index < 0 || index >= items.size) return
        val row = card.getChildAt(index) ?: return
        openChild(level, items[index], row)
    }

    private fun cardWidth(card: View): Int = (card.layoutParams?.width ?: dp(220)).let {
        if (it > 0) minOf(it, sw() - dp(16)) else dp(220)
    }

    private fun measuredHeight(card: View, w: Int): Int {
        card.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return card.measuredHeight
    }

    private fun position(card: View, left: Int, top: Int, w: Int, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        val lp = FrameLayout.LayoutParams(w, height, Gravity.TOP or Gravity.START)
        lp.leftMargin = left
        lp.topMargin = top
        card.layoutParams = lp
    }

    /**
     * Vidro único de TODOS os cartões (menu raiz, submenus e painéis de configuração):
     * desfoque real do wallpaper ([GlassDrawable]) + película branca translúcida + borda fina + cantos arredondados.
     */
    private fun applyGlass(v: View) {
        val r = dp(8).toFloat()
        val glass = GlassDrawable(v, argb(GLASS_TINT, Color.parseColor(if (dark) "#2C2C2C" else "#F9F9F9")), r)
        val border = GradientDrawable()
        border.setColor(Color.TRANSPARENT)
        border.cornerRadius = r
        border.setStroke(dp(1), Color.parseColor(if (dark) "#33FFFFFF" else "#1F000000"))
        v.background = LayerDrawable(arrayOf<Drawable>(glass, border))
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
                outline.alpha = 0.5f
            }
        }
        v.clipToOutline = false
    }

    private fun argb(a: Int, rgb: Int): Int = (a shl 24) or (rgb and 0xFFFFFF)

    private fun buildList(items: List<MenuItem>, level: Int): View {
        val rows = LinearLayout(act)
        rows.orientation = LinearLayout.VERTICAL
        rows.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (mi in items) {
            rows.addView(buildRow(mi, level), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))
        }
        // O cartão é um ScrollView: quando a lista é maior que a tela (celular) ela rola com a roda do mouse ou o dedo.
        val sv = WheelScrollView(act, dp(40))
        applyGlass(sv)
        sv.elevation = dp(12).toFloat()
        sv.isClickable = true
        sv.tag = CursorController.NOHAND
        sv.isVerticalScrollBarEnabled = true
        sv.addView(rows)
        sv.layoutParams = FrameLayout.LayoutParams(dp(232), ViewGroup.LayoutParams.WRAP_CONTENT)
        return sv
    }

    private fun buildRow(item: MenuItem, level: Int): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(8), 0, dp(8), 0)

        val lead = FrameLayout(act)
        if (item.icon != 0) {
            val iv = ImageView(act)
            iv.setImageResource(item.icon)
            iv.setColorFilter(ink)
            lead.addView(iv, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        } else if (item.checked) {
            val tv = TextView(act)
            tv.text = "✓"
            tv.setTextColor(ink)
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            lead.addView(tv, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        }
        r.addView(lead, LinearLayout.LayoutParams(dp(24), dp(24)))

        val tv = TextView(act)
        tv.text = if (item.checked && item.icon != 0) "✓  " + item.label else item.label
        tv.setTextColor(ink)
        tv.textSize = 13f
        tv.maxLines = 1
        tv.alpha = if (item.enabled) 1f else 0.4f
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(8)
        r.addView(tv, tlp)

        if (item.children != null || item.panel != null) {
            val ch = TextView(act)
            ch.text = "›"
            ch.setTextColor(ink)
            ch.textSize = 16f
            r.addView(ch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        r.background = rowBg(false)
        r.isClickable = true
        r.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> {
                    v.background = rowBg(true)
                    if (item.enabled) {
                        if (item.children != null || item.panel != null) {
                            if (hoverOpens()) openChild(level, item, v) else closeAbove(level)
                        } else {
                            closeAbove(level)
                        }
                    }
                }
                MotionEvent.ACTION_HOVER_EXIT -> v.background = rowBg(false)
            }
            false
        }
        r.setOnClickListener { v ->
            if (item.enabled) {
                if (item.children != null || item.panel != null) {
                    openChild(level, item, v)
                } else {
                    hide()
                    item.action?.invoke()
                }
            }
        }
        return r
    }

    private fun rowBg(hover: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(if (hover) hoverBg else Color.TRANSPARENT)
        g.cornerRadius = dp(5).toFloat()
        return g
    }

    private fun closeAbove(level: Int) {
        while (cards.size > level + 1) {
            val c = cards.removeAt(cards.size - 1)
            layer.removeView(c)
            if (lists.size > cards.size) lists.removeAt(lists.size - 1)
        }
    }

    private fun openChild(level: Int, item: MenuItem, anchor: View) {
        if (level >= cards.size) return
        closeAbove(level)
        val parent = cards[level]
        val plp = parent.layoutParams as FrameLayout.LayoutParams
        val m = dp(8)

        val card: View
        if (item.children != null) {
            card = buildList(item.children, level + 1)
            lists.add(item.children)
        } else {
            val content = item.panel!!.invoke()
            val sv = WheelScrollView(act, dp(40))
            applyGlass(sv)
            sv.elevation = dp(12).toFloat()
            sv.isClickable = true
            sv.tag = CursorController.NOHAND
            content.setPadding(dp(8), dp(6), dp(8), dp(6))
            sv.isVerticalScrollBarEnabled = true
            sv.isScrollbarFadingEnabled = false
            sv.addView(content)
            sv.layoutParams = FrameLayout.LayoutParams(dp(195), ViewGroup.LayoutParams.WRAP_CONTENT)
            card = sv
            lists.add(emptyList())
        }
        cards.add(card)
        layer.addView(card)

        val w = cardWidth(card)
        var h = measuredHeight(card, w)
        val avail = sh() - 2 * m
        // Listas ocupam até a tela toda. Painéis mantêm ~30% da tela, mas nunca menos que ~240dp (telas pequenas).
        val maxH = if (item.children != null) avail
        else minOf(avail, maxOf((sh() * 0.3f).toInt(), minOf(dp(240), avail)))
        val needsCap = h > maxH
        if (needsCap) h = maxH

        val pw = plp.width
        var left = plp.leftMargin + pw - dp(2)
        if (left + w > sw() - m) left = plp.leftMargin - w + dp(2)
        left = left.coerceIn(m, maxOf(m, sw() - w - m))

        val loc = IntArray(2)
        val rloc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        root.getLocationOnScreen(rloc)
        var top = loc[1] - rloc[1] - dp(4)
        top = top.coerceIn(m, maxOf(m, sh() - h - m))

        val lp = FrameLayout.LayoutParams(w, if (needsCap) h else ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        lp.leftMargin = left
        lp.topMargin = top
        card.layoutParams = lp
    }
}
