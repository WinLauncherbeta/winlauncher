package com.example.winlauncher

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Integração mínima e segura com o Shizuku: apenas estado e autorização.
 * Tudo é protegido por try/catch; sem o Shizuku o launcher funciona normalmente.
 */
object ShizukuBridge {
    const val PKG = "moe.shizuku.privileged.api"
    const val REQ = 4242

    enum class State { NOT_INSTALLED, NOT_RUNNING, NEEDS_PERMISSION, GRANTED, UNSUPPORTED }

    @Volatile
    var onChange: (() -> Unit)? = null

    private var listenersAdded = false

    @Volatile
    private var foundPkg: String? = null

    /** Último erro ao rodar comando via Shizuku (para diagnóstico no painel de desempenho). */
    @Volatile
    var lastError: String? = null

    /** Pacote do Shizuku instalado: o oficial ou uma versão modificada (nome contendo "shizuku"). */
    fun pkg(ctx: Context): String? {
        try {
            ctx.packageManager.getPackageInfo(PKG, 0)
            return PKG
        } catch (e: Exception) {
        }
        foundPkg?.let {
            try {
                ctx.packageManager.getPackageInfo(it, 0)
                return it
            } catch (e: Exception) {
                foundPkg = null
            }
        }
        return try {
            val pm = ctx.packageManager
            val i = android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            val hit = pm.queryIntentActivities(i, 0).firstOrNull {
                val n = it.activityInfo.packageName
                n != ctx.packageName && (n.contains("shizuku", true) ||
                    it.loadLabel(pm).toString().contains("shizuku", true))
            }?.activityInfo?.packageName
            foundPkg = hit
            hit
        } catch (e: Exception) {
            null
        }
    }

    fun installed(ctx: Context): Boolean = pkg(ctx) != null

    fun state(ctx: Context): State = try {
        // o serviço manda o binder ao app mesmo em versões modificadas; por isso testa ele primeiro
        val ping = Shizuku.pingBinder()
        when {
            !ping && !installed(ctx) -> State.NOT_INSTALLED
            !ping -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.GRANTED
            else -> State.NEEDS_PERMISSION
        }
    } catch (t: Throwable) {
        State.UNSUPPORTED
    }

    /** Retorna false quando o Shizuku já bloqueou novos pedidos (usuário precisa liberar no app). */
    fun request(): Boolean = try {
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            false
        } else {
            Shizuku.requestPermission(REQ)
            true
        }
    } catch (t: Throwable) {
        false
    }

    fun open(act: Activity): Boolean = try {
        val i = pkg(act)?.let { act.packageManager.getLaunchIntentForPackage(it) }
        if (i != null) {
            act.startActivity(i)
            true
        } else {
            false
        }
    } catch (t: Throwable) {
        false
    }

    /**
     * Roda um comando no shell com privilégios do Shizuku e devolve a saída (null se falhar).
     * Usa reflexão porque Shizuku.newProcess é privado na API 13.x. Chamar fora da thread principal.
     */
    fun exec(args: Array<String>): String? {
        var proc: Process? = null
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            proc = m.invoke(null, args, null, null) as Process
            val out = proc.inputStream.bufferedReader().readText()
            try {
                proc.waitFor()
            } catch (e: Exception) {
            }
            lastError = null
            out
        } catch (t: Throwable) {
            val c = (t as? java.lang.reflect.InvocationTargetException)?.targetException ?: t
            lastError = c.javaClass.simpleName + (c.message?.let { ": $it" } ?: "")
            null
        } finally {
            try {
                proc?.destroy()
            } catch (t: Throwable) {
            }
        }
    }

    fun addListeners() {
        if (listenersAdded) return
        try {
            Shizuku.addBinderReceivedListener { onChange?.invoke() }
            Shizuku.addBinderDeadListener { onChange?.invoke() }
            Shizuku.addRequestPermissionResultListener { _, _ -> onChange?.invoke() }
            listenersAdded = true
        } catch (t: Throwable) {
        }
    }
}
