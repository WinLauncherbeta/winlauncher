package com.example.winlauncher

import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

/**
 * Widget "Relógio e calendário": dia da semana, data e hora direto sobre o wallpaper
 * (sem cartão, borda ou fundo). Usa a data e a hora locais do aparelho, sem internet.
 *
 * Esta classe só cuida do visual, do texto e das fontes. Posição e colisão com os ícones ficam
 * no mecanismo da área de trabalho (MainActivity + DesktopSpacing), para não existir um sistema paralelo.
 */
class ClockWidget(private val a: MainActivity, private val p: Prefs) {

    companion object {
        const val DAY = 0
        const val DATE = 1
        const val TIME = 2
        const val MIN_PCT = 40
        const val MAX_PCT = 250
    }

    private val d = a.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val cream = Color.parseColor("#F5EBDD")

    val view = LinearLayout(a)
    private val day = TextView(a)
    private val date = TextView(a)
    private val time = TextView(a)

    private var lastW = 0
    private var lastH = 0

    /** Chamado quando o tamanho ocupado muda sozinho (ex.: mês com nome mais longo); a tela refaz a acomodação. */
    var onResize: (() -> Unit)? = null

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 60_000L - (System.currentTimeMillis() % 60_000L) + 30L)
        }
    }

    /** Anurati (embutida em assets/fonts) é a fonte padrão dos três textos do relógio; se falhar, usa a do sistema. */
    private val anurati: Typeface? by lazy {
        try {
            Typeface.createFromAsset(a.assets, "fonts/anurati-regular.otf")
        } catch (e: Exception) {
            null
        }
    }

    init {
        view.orientation = LinearLayout.VERTICAL
        view.gravity = Gravity.CENTER_HORIZONTAL
        view.isClickable = false
        view.isFocusable = false
        view.clipChildren = false
        view.clipToPadding = false
        view.visibility = View.GONE
        for (tv in listOf(day, date, time)) {
            tv.setTextColor(cream)
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.includeFontPadding = false
            tv.isClickable = false
            view.addView(
                tv,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        applyScale(p.wgScale)
        applyFonts()
        updateText()
    }

    // ------------------------------------------------------------------ texto

    private fun loc(): Locale = Locale.getDefault()

    fun text(target: Int): String {
        val l = loc()
        val now = Date()
        return when (target) {
            DAY -> SimpleDateFormat("EEEE", l).format(now).substringBefore('-').trim().uppercase(l)
            DATE -> SimpleDateFormat("dd MMMM, yyyy", l).format(now).uppercase(l) + "."
            else -> {
                val f = if (DateFormat.is24HourFormat(a)) "HH:mm" else "h:mm a"
                "- " + SimpleDateFormat(f, l).format(now).uppercase(l) + " -"
            }
        }
    }

    private fun updateText() {
        day.text = text(DAY)
        date.text = text(DATE)
        time.text = text(TIME)
    }

    /** Atualiza os textos (chamado a cada minuto e ao voltar para o launcher). */
    fun refresh() {
        updateText()
        if (!p.wgOn) return
        val sz = measureDp()
        if (sz[0] != lastW || sz[1] != lastH) onResize?.invoke()
    }

    fun start() {
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() {
        handler.removeCallbacks(tick)
    }

    // ------------------------------------------------------------------ fontes

    fun defaultTypeface(target: Int): Typeface =
        anurati ?: if (target == DAY) Typeface.create("sans-serif-light", Typeface.NORMAL)
        else Typeface.create("sans-serif", Typeface.NORMAL)

    fun fontFile(target: Int): String = when (target) {
        DAY -> p.wgFontDay
        DATE -> p.wgFontDate
        else -> p.wgFontTime
    }

    fun setFontFile(target: Int, file: String) {
        when (target) {
            DAY -> p.wgFontDay = file
            DATE -> p.wgFontDate = file
            else -> p.wgFontTime = file
        }
    }

    /** Fonte importada se existir e for válida; senão a padrão. */
    fun typefaceFor(target: Int): Typeface =
        FontStore.typeface(a, fontFile(target)) ?: defaultTypeface(target)

    /** Aplica as três fontes escolhidas (em tempo real). */
    fun applyFonts() {
        day.typeface = typefaceFor(DAY)
        date.typeface = typefaceFor(DATE)
        time.typeface = typefaceFor(TIME)
        day.requestLayout()
        date.requestLayout()
        time.requestLayout()
    }

    // ------------------------------------------------------------------ tamanho

    /** Escala proporcional de dia, data e hora (100 = padrão). */
    fun applyScale(percent: Int) {
        val s = percent.coerceIn(MIN_PCT, MAX_PCT) / 100f
        style(day, 40f * s, 0.28f, 0, s)
        style(date, 17f * s, 0.10f, 10, s)
        style(time, 19f * s, 0.12f, 6, s)
    }

    private fun style(tv: TextView, sp: Float, spacing: Float, topDp: Int, s: Float) {
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        tv.letterSpacing = spacing
        // o espaçamento entre letras também sobra depois da última: o recuo à esquerda mantém o texto centralizado
        val trail = (spacing * tv.textSize).toInt()
        val pad = (6f * d * s).toInt()
        tv.setPadding(pad + trail, pad, pad, pad)
        // sombra suave só para dar legibilidade em qualquer wallpaper (não é um fundo nem uma borda)
        tv.setShadowLayer(10f * d * s, 0f, 1f * d * s, 0x99000000.toInt())
        val lp = tv.layoutParams as LinearLayout.LayoutParams
        lp.topMargin = ((topDp * d * s).toInt() - (if (topDp == 0) 0 else (pad / 2))).coerceAtLeast(0)
        tv.layoutParams = lp
    }

    /** Área realmente ocupada pelo widget, em dp, no tamanho atual. */
    fun measureDp(): IntArray {
        view.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return intArrayOf(
            ceil(view.measuredWidth / d.toDouble()).toInt(),
            ceil(view.measuredHeight / d.toDouble()).toInt()
        )
    }

    /**
     * Acha o retângulo do widget (x, y, largura, altura em dp) o mais perto possível do centro salvo,
     * sem tocar nos ícones ([icons]) e dentro da área de trabalho (que já exclui a barra de tarefas).
     * Se o tamanho escolhido não couber em nenhum espaço livre, reduz o widget aos poucos; se nem o
     * menor tamanho couber, devolve null (o widget fica oculto em vez de cobrir ícones).
     */
    fun place(areaW: Int, areaH: Int, icons: Collection<IntArray>, cellW: Int, cellH: Int, total: Int): IntArray? {
        var s = p.wgScale.coerceIn(MIN_PCT, MAX_PCT)
        while (true) {
            applyScale(s)
            val sz = measureDp()
            val x0 = Math.round(p.wgCx * areaW - sz[0] / 2f)
            val y0 = Math.round(p.wgCy * areaH - sz[1] / 2f)
            val pos = DesktopSpacing.placeBlock(x0, y0, sz[0], sz[1], icons, areaW, areaH, cellW, cellH, total)
            if (pos != null) {
                lastW = sz[0]
                lastH = sz[1]
                return intArrayOf(pos[0], pos[1], sz[0], sz[1])
            }
            if (s <= MIN_PCT) {
                lastW = sz[0]
                lastH = sz[1]
                return null
            }
            s = maxOf(MIN_PCT, s - 10)
        }
    }
}
