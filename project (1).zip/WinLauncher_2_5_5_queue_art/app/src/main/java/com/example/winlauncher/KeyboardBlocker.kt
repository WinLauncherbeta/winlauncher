package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.inputmethod.InputMethodManager

/**
 * Liga/desliga o bloqueio do teclado na tela: troca o teclado padrão do Android pelo [NoKeyboardService]
 * (teclado vazio) e, ao desligar, volta para o teclado que estava em uso antes.
 * A troca automática usa o Shizuku (comandos "ime enable/set"); sem ele, o painel guia o usuário
 * pelas configurações do Android.
 */
object KeyboardBlocker {
    private const val PREV = "ui_kbd_prev"

    fun id(ctx: Context): String =
        ComponentName(ctx, NoKeyboardService::class.java).flattenToShortString()

    fun current(ctx: Context): String = try {
        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
    } catch (e: Exception) {
        ""
    }

    /** true quando o teclado vazio é o teclado padrão do Android agora. */
    fun isActive(ctx: Context): Boolean = current(ctx) == id(ctx)

    /** true quando o teclado vazio está ativado nas configurações (mesmo sem ser o padrão). */
    fun isEnabled(ctx: Context): Boolean = try {
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.any { it.id == id(ctx) }
    } catch (e: Exception) {
        false
    }

    /**
     * Liga (on = true) ou desliga o bloqueio usando o Shizuku. Chamar fora da thread principal.
     * Retorna true se o estado final é o pedido.
     */
    fun set(ctx: Context, prefs: Prefs, on: Boolean): Boolean {
        val me = id(ctx)
        if (on) {
            val cur = current(ctx)
            if (cur.isNotEmpty() && cur != me) prefs.putStr(PREV, cur)
            ShizukuBridge.exec(arrayOf("ime", "enable", me))
            ShizukuBridge.exec(arrayOf("ime", "set", me))
        } else {
            val prev = prefs.str(PREV, "")
            if (prev.isNotEmpty() && prev != me && isEnabledId(ctx, prev)) {
                ShizukuBridge.exec(arrayOf("ime", "set", prev))
            } else {
                ShizukuBridge.exec(arrayOf("ime", "reset"))
            }
            if (isActive(ctx)) ShizukuBridge.exec(arrayOf("ime", "reset"))
            ShizukuBridge.exec(arrayOf("ime", "disable", me))
        }
        return isActive(ctx) == on
    }

    private fun isEnabledId(ctx: Context, id: String): Boolean = try {
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.any { it.id == id }
    } catch (e: Exception) {
        false
    }

    /** true quando o app recebeu WRITE_SECURE_SETTINGS (via adb ou Shizuku): dá para trocar o teclado direto. */
    fun canWriteSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** Troca o teclado escrevendo direto nas configurações seguras. Chamar só se [canWriteSecure]. */
    fun setDirect(ctx: Context, prefs: Prefs, on: Boolean): Boolean {
        val me = id(ctx)
        return try {
            val cr = ctx.contentResolver
            val enabled = (Settings.Secure.getString(cr, Settings.Secure.ENABLED_INPUT_METHODS) ?: "")
                .split(":").filter { it.isNotEmpty() }.toMutableList()
            if (on) {
                val cur = current(ctx)
                if (cur.isNotEmpty() && cur != me) prefs.putStr(PREV, cur)
                if (me !in enabled) enabled.add(me)
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_INPUT_METHODS, enabled.joinToString(":"))
                Settings.Secure.putString(cr, Settings.Secure.DEFAULT_INPUT_METHOD, me)
            } else {
                val prev = prefs.str(PREV, "")
                if (prev.isNotEmpty() && prev != me && prev in enabled) {
                    Settings.Secure.putString(cr, Settings.Secure.DEFAULT_INPUT_METHOD, prev)
                } else {
                    val other = enabled.firstOrNull { it != me }
                    if (other != null) Settings.Secure.putString(cr, Settings.Secure.DEFAULT_INPUT_METHOD, other)
                }
                enabled.remove(me)
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_INPUT_METHODS, enabled.joinToString(":"))
            }
            isActive(ctx) == on
        } catch (e: Exception) {
            false
        }
    }

    /** Mostra o seletor de teclado do Android (precisa do WinLauncher na frente). */
    fun showPicker(ctx: Context) {
        try {
            (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        } catch (e: Exception) {
        }
    }
}
