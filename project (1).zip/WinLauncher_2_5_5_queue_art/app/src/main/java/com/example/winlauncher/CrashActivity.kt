package com.example.winlauncher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Mostra o erro que fechou o launcher. Roda em processo separado (:crash). */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra("trace") ?: "Sem detalhes."
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(Color.parseColor("#202020"))
        col.setPadding(32, 64, 32, 32)

        val title = TextView(this)
        title.text = "O WinLauncher fechou por um erro"
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        col.addView(title)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val copy = Button(this)
        copy.text = "Copiar erro"
        copy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("erro", trace))
            Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
        }
        val close = Button(this)
        close.text = "Fechar"
        close.setOnClickListener { finishAndRemoveTask() }
        row.addView(copy)
        row.addView(close)
        col.addView(row)

        val tv = TextView(this)
        tv.text = trace
        tv.setTextColor(Color.parseColor("#FF8A80"))
        tv.textSize = 11f
        tv.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.addView(tv)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(col)
    }
}
