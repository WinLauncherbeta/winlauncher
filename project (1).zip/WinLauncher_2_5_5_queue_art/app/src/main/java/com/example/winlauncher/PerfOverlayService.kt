package com.example.winlauncher

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Display
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.random.Random

/** Foto instantânea dos números mostrados no painel. null = o Android não deixa ler (mostra "--"). */
class PerfData(
    val gpuName: String,
    val cpuName: String,
    val api: String,
    val gpuTemp: Int,
    val cpuTemp: Int,
    val gpuLoad: Int?,
    val gpuMhz: Int?,
    val gpuMemMb: Int?,
    val cpuLoad: Int?,
    val cpuMhz: Int?,
    val ramMb: Int?,
    val fps: Int?,
    val frameMs: Float?,
    val graph: FloatArray,
    val note: String? = null
)

/**
 * Painel de desempenho flutuante (estilo MSI Afterburner) sobre qualquer app.
 *
 * Tudo é lido de verdade do aparelho, EXCETO as temperaturas (CPU e GPU), que são um valor fixo
 * por volta de 42 °C. Leituras de sistema (uso de CPU/GPU, MHz, FPS do app aberto) exigem o Shizuku autorizado;
 * sem ele essas linhas mostram "--".
 *
 * Botão direito (ou segurar) no painel: Mover, Opacidade, Tamanho e Fechar.
 * Preferências: ui_perf_on, ui_perf_alpha (20..100), ui_perf_scale (50..200), ui_perf_anchor (bit0 = direita,
 * bit1 = embaixo), ui_perf_x / ui_perf_y (distância até a borda ancorada, em px).
 */
class PerfOverlayService : Service() {

    companion object {
        private const val CHANNEL = "perf_overlay"
        private const val NOTIF_ID = 4714

        @Volatile
        var instance: PerfOverlayService? = null

        /** Avisado quando o painel liga/desliga (a barra de tarefas atualiza o indicador). */
        @Volatile
        var onStateChanged: (() -> Unit)? = null

        fun isOn(ctx: Context): Boolean =
            ctx.getSharedPreferences("win", Context.MODE_PRIVATE).getBoolean("ui_perf_on", false)

        fun setOn(ctx: Context, on: Boolean) {
            ctx.getSharedPreferences("win", Context.MODE_PRIVATE).edit().putBoolean("ui_perf_on", on).apply()
            sync(ctx)
            onStateChanged?.invoke()
        }

        /** Liga, desliga ou atualiza o painel conforme as preferências. */
        fun sync(ctx: Context) {
            val on = isOn(ctx) && Settings.canDrawOverlays(ctx)
            val inst = instance
            if (on) {
                if (inst == null) {
                    try {
                        ctx.startForegroundService(Intent(ctx, PerfOverlayService::class.java))
                    } catch (e: Exception) {
                    }
                } else {
                    inst.handler.post { inst.applyStyle() }
                }
            } else if (inst != null) {
                inst.handler.post {
                    inst.shutdown()
                    inst.stopSelf()
                }
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val sp get() = getSharedPreferences("win", MODE_PRIVATE)

    private var wm: WindowManager? = null
    private var ctx: Context? = null
    private var view: PerfView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var menuView: View? = null
    private var moveMode = false

    // ---- amostragem (thread própria)
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    @Volatile
    private var running = false

    private var cpuName = "CPU"
    private var gpuName = "GPU"
    private var apiName = "GLES"
    private var staticReady = false

    private var prevTotal = 0L
    private var prevIdle = 0L

    private var topPkg = ""
    private var layers: List<String> = emptyList()
    private var tickN = 0
    private var layersAge = 0
    private var lastTs = 0L
    private var lastLayer = ""
    private val graph = ArrayList<Float>()

    // ---- FPS sem Shizuku: quadros que o Android entrega na tela (Choreographer), na thread principal
    private var chRunning = false
    private var chFrames = 0
    private var chStartNs = 0L
    private var chLastNs = 0L
    @Volatile
    private var chFps: Int? = null
    @Volatile
    private var chMs: Float? = null
    private val chDeltas = ArrayList<Float>()
    private val chCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!chRunning) return
            if (chLastNs != 0L) {
                val dms = (frameTimeNanos - chLastNs) / 1_000_000f
                if (dms in 0.5f..250f) synchronized(chDeltas) {
                    chDeltas.add(dms)
                    if (chDeltas.size > 600) chDeltas.removeAt(0)
                }
            }
            chLastNs = frameTimeNanos
            if (chStartNs == 0L) {
                chStartNs = frameTimeNanos
                chFrames = 0
            } else {
                chFrames++
                val el = frameTimeNanos - chStartNs
                if (el >= 500_000_000L) {
                    chFps = Math.round(chFrames * 1_000_000_000.0 / el).toInt()
                    chMs = el / chFrames / 1_000_000f
                    chFrames = 0
                    chStartNs = frameTimeNanos
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun startChoreo() {
        if (chRunning) return
        chRunning = true
        chFrames = 0
        chStartNs = 0L
        chLastNs = 0L
        chFps = null
        chMs = null
        Choreographer.getInstance().postFrameCallback(chCb)
    }

    private fun stopChoreo() {
        chRunning = false
        try {
            Choreographer.getInstance().removeFrameCallback(chCb)
        } catch (t: Throwable) {
        }
    }

    /** FPS/frametime medidos pelo Choreographer; alimenta também o gráfico. */
    private fun choreoFrames(): Pair<Int?, Float?> {
        if (lastLayer != "@choreo") {
            lastLayer = "@choreo"
            lastTs = 0
            graph.clear()
        }
        val add = synchronized(chDeltas) {
            val a = ArrayList(chDeltas)
            chDeltas.clear()
            a
        }
        for (v in add.takeLast(90)) graph.add(v)
        while (graph.size > 120) graph.removeAt(0)
        return Pair(chFps, chMs)
    }

    // temperaturas falsas (únicas coisas que não são reais)
    private var fakeCpu = 42
    private var fakeGpu = 41

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Monitor de desempenho", NotificationManager.IMPORTANCE_MIN)
            )
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_speed)
                .setContentTitle("WinLauncher")
                .setContentText("Monitor de desempenho ativo")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.post {
            if (view == null) addPanel()
            startSampling()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        shutdown()
        instance = null
        super.onDestroy()
    }

    private fun shutdown() {
        running = false
        stopChoreo()
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        worker = null
        wh = null
        hideMenu()
        val v = view
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
            }
        }
        view = null
        lp = null
        wm = null
    }

    // ================================================================== painel (janela flutuante)

    private fun overlayContext(): Context {
        return try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
            val d = dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
            val dc = createDisplayContext(d)
            if (Build.VERSION.SDK_INT >= 30) {
                dc.createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
            } else dc
        } catch (e: Exception) {
            this
        }
    }

    /** Tamanho REAL da tela (com a área da barra); o painel usa isso para nunca sair pelos cantos. */
    private fun screenSize(c: Context, w: WindowManager): IntArray {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = w.maximumWindowMetrics.bounds
                if (b.width() > 0 && b.height() > 0) return intArrayOf(b.width(), b.height())
            }
        } catch (e: Exception) {
        }
        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
            val d = dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
            val p = Point()
            @Suppress("DEPRECATION")
            d.getRealSize(p)
            if (p.x > 0 && p.y > 0) return intArrayOf(p.x, p.y)
        } catch (e: Exception) {
        }
        val m = c.resources.displayMetrics
        return intArrayOf(m.widthPixels, m.heightPixels)
    }

    private fun addPanel() {
        var c = overlayContext()
        try {
            buildPanel(c)
        } catch (e: Exception) {
            try {
                c = this
                buildPanel(c)
            } catch (e2: Exception) {
            }
        }
    }

    private fun anchorGravity(a: Int): Int =
        (if (a and 1 != 0) Gravity.END else Gravity.START) or (if (a and 2 != 0) Gravity.BOTTOM else Gravity.TOP)

    private fun buildPanel(c: Context) {
        val w = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = c.resources.displayMetrics.density
        val v = PerfView(c)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val anchor = sp.getInt("ui_perf_anchor", 0)
        p.gravity = anchorGravity(anchor)
        p.x = sp.getInt("ui_perf_x", (12 * d).toInt())
        p.y = sp.getInt("ui_perf_y", (12 * d).toInt())

        // toque / mouse
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                if (!moveMode) showMenu(e.rawX.toInt(), e.rawY.toInt())
            }
        })
        v.setOnTouchListener { _, ev ->
            // botão direito do mouse
            if (ev.actionMasked == MotionEvent.ACTION_DOWN &&
                (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
            ) {
                showMenu(ev.rawX.toInt(), ev.rawY.toInt())
                return@setOnTouchListener true
            }
            if (!moveMode) {
                gd.onTouchEvent(ev)
                return@setOnTouchListener true
            }
            // modo mover: arrasta o painel; ao soltar, termina
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = p.x
                    startY = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val a = sp.getInt("ui_perf_anchor", 0)
                    val dx = (ev.rawX - downX).toInt()
                    val dy = (ev.rawY - downY).toInt()
                    val scr = screenSize(c, w)
                    val maxX = (scr[0] - v.width).coerceAtLeast(0)
                    val maxY = (scr[1] - v.height).coerceAtLeast(0)
                    // com âncora na direita/embaixo, mover o dedo para a direita/baixo diminui a distância até a borda
                    p.x = (if (a and 1 != 0) startX - dx else startX + dx).coerceIn(0, maxX)
                    p.y = (if (a and 2 != 0) startY - dy else startY + dy).coerceIn(0, maxY)
                    try {
                        w.updateViewLayout(v, p)
                    } catch (e: Exception) {
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endMove()
            }
            true
        }

        w.addView(v, p)
        wm = w
        ctx = c
        view = v
        lp = p
        applyStyle()
    }

    /** Opacidade e tamanho vindos das preferências; depois garante que o painel continua dentro da tela. */
    fun applyStyle() {
        val v = view ?: return
        v.scale = sp.getInt("ui_perf_scale", 100).coerceIn(50, 200) / 100f
        v.alpha = sp.getInt("ui_perf_alpha", 100).coerceIn(20, 100) / 100f
        v.post { clampToScreen() }
    }

    /** Depois de mudar o tamanho (ou a tela girar) o painel cresce para dentro, nunca para fora dos cantos. */
    private fun clampToScreen() {
        val v = view ?: return
        val p = lp ?: return
        val w = wm ?: return
        val c = ctx ?: return
        if (v.width <= 0) return
        val scr = screenSize(c, w)
        val maxX = (scr[0] - v.width).coerceAtLeast(0)
        val maxY = (scr[1] - v.height).coerceAtLeast(0)
        val nx = p.x.coerceIn(0, maxX)
        val ny = p.y.coerceIn(0, maxY)
        if (nx != p.x || ny != p.y) {
            p.x = nx
            p.y = ny
            try {
                w.updateViewLayout(v, p)
            } catch (e: Exception) {
            }
        }
    }

    private fun startMove() {
        moveMode = true
        view?.moveMode = true
    }

    /** Termina o modo mover: o painel escolhe o canto mais próximo como âncora e salva a posição. */
    private fun endMove() {
        moveMode = false
        val v = view ?: return
        v.moveMode = false
        val p = lp ?: return
        val w = wm ?: return
        val c = ctx ?: return
        val scr = screenSize(c, w)
        val a = sp.getInt("ui_perf_anchor", 0)
        val left = if (a and 1 != 0) scr[0] - v.width - p.x else p.x
        val top = if (a and 2 != 0) scr[1] - v.height - p.y else p.y
        val right = left + v.width / 2 > scr[0] / 2
        val bottom = top + v.height / 2 > scr[1] / 2
        val na = (if (right) 1 else 0) or (if (bottom) 2 else 0)
        p.gravity = anchorGravity(na)
        p.x = (if (right) scr[0] - v.width - left else left).coerceIn(0, (scr[0] - v.width).coerceAtLeast(0))
        p.y = (if (bottom) scr[1] - v.height - top else top).coerceIn(0, (scr[1] - v.height).coerceAtLeast(0))
        try {
            w.updateViewLayout(v, p)
        } catch (e: Exception) {
        }
        sp.edit().putInt("ui_perf_anchor", na).putInt("ui_perf_x", p.x).putInt("ui_perf_y", p.y).apply()
    }

    // ================================================================== menu do botão direito

    private fun hideMenu() {
        val m = menuView ?: return
        try {
            wm?.removeView(m)
        } catch (e: Exception) {
        }
        menuView = null
    }

    private fun showMenu(rx: Int, ry: Int) {
        hideMenu()
        val c = ctx ?: return
        val w = wm ?: return
        val d = c.resources.displayMetrics.density
        fun dp(v: Int) = (v * d + 0.5f).toInt()
        val acc = Color.parseColor("#19B4F0")

        val card = LinearLayout(c)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(8), dp(8), dp(8), dp(8))
        card.background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2181C24"))
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        }

        fun item(text: String, onClick: () -> Unit): TextView {
            val t = TextView(c)
            t.text = text
            t.textSize = 14f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(10), dp(10), dp(10), dp(10))
            t.isClickable = true
            t.setOnClickListener { onClick() }
            return t
        }

        fun slider(title: String, key: String, min: Int, max: Int, def: Int) {
            val cur = sp.getInt(key, def).coerceIn(min, max)
            val tv = TextView(c)
            tv.setTextColor(Color.WHITE)
            tv.textSize = 13f
            tv.setPadding(dp(10), dp(8), dp(10), 0)
            tv.text = "$title: $cur%"
            val sb = SeekBar(c)
            sb.max = max - min
            sb.progress = cur - min
            sb.progressTintList = ColorStateList.valueOf(acc)
            sb.thumbTintList = ColorStateList.valueOf(acc)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    val real = min + value
                    tv.text = "$title: $real%"
                    if (fromUser) {
                        sp.edit().putInt(key, real).apply()
                        applyStyle()
                    }
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            card.addView(tv)
            card.addView(sb)
        }

        card.addView(item("Mover") {
            hideMenu()
            startMove()
        })
        slider("Opacidade", "ui_perf_alpha", 20, 100, 100)
        slider("Tamanho", "ui_perf_scale", 50, 200, 100)
        card.addView(item("Fechar painel") {
            hideMenu()
            setOn(this, false)
        })

        val width = dp(230)
        card.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val scr = screenSize(c, w)
        val p = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = rx.coerceIn(0, (scr[0] - width).coerceAtLeast(0))
        p.y = ry.coerceIn(0, (scr[1] - card.measuredHeight).coerceAtLeast(0))
        card.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                hideMenu()
                true
            } else false
        }
        try {
            w.addView(card, p)
            menuView = card
        } catch (e: Exception) {
        }
    }

    // ================================================================== leitura dos números

    private fun startSampling() {
        if (running) return
        running = true
        if (worker == null) {
            worker = HandlerThread("perf-sampler").also { it.start() }
            wh = Handler(worker!!.looper)
        }
        startChoreo()
        wh?.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val data = try {
                sample()
            } catch (t: Throwable) {
                null
            }
            if (data != null) handler.post { view?.setData(data) }
            wh?.postDelayed(this, 500)
        }
    }

    private fun shortCpu(s: String): String =
        s.replace("Qualcomm ", "").replace("MediaTek ", "").replace("Samsung ", "")
            .replace("Snapdragon", "SD").trim().uppercase().take(14)

    private fun shortGpu(s: String): String =
        s.replace("(TM)", "").replace(Regex("\\s+"), " ").trim().uppercase().take(14)

    private fun initStatic() {
        try {
            val c = HwInfo.loadCpu()
            cpuName = shortCpu(c.title ?: c.model ?: Build.HARDWARE)
        } catch (t: Throwable) {
            cpuName = shortCpu(Build.HARDWARE)
        }
        gpuName = shortGpu(GpuName.get())
        apiName = try {
            val vk = packageManager.systemAvailableFeatures
                .firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }?.version ?: 0
            if (vk > 0) {
                "VULKAN"
            } else {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val v = am.deviceConfigurationInfo.reqGlEsVersion
                "GLES " + (v shr 16) + "." + (v and 0xffff)
            }
        } catch (t: Throwable) {
            "GLES"
        }
        staticReady = true
    }

    /** Script único (um processo por ciclo): CPU, GPU e, no fim, as latências das camadas do app aberto. */
    private val statScript = """
r(){ [ -r "§2" ] && echo "§1=§(head -1 "§2" 2>/dev/null)"; }
echo '@@S'
head -1 /proc/stat
for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do r cf "§f"; done
k=/sys/class/kgsl/kgsl-3d0
r kb §k/gpu_busy_percentage
r kg §k/gpubusy
r kc §k/gpuclk
r kd §k/devfreq/cur_freq
r kh §k/clock_mhz
r km /sys/class/kgsl/kgsl/page_alloc
r mb /sys/kernel/gpu/gpu_busy
r mc /sys/kernel/gpu/gpu_clock
for d in /sys/class/devfreq/*; do case "§d" in *mali*|*gpu*|*g3d*) r dc "§d/cur_freq"; r dl "§d/load";; esac; done
r mt /sys/kernel/ged/hal/gpu_utilization
r mf /sys/kernel/ged/hal/current_freqency
r mu /sys/class/misc/mali0/device/utilisation
r ml /sys/module/ged/parameters/gpu_loading
for f in /sys/devices/platform/*mali*/clock /sys/devices/platform/*mali*/cur_freq /sys/devices/platform/*mali*/devfreq/*/cur_freq /sys/devices/platform/*gpu*/devfreq/*/cur_freq /sys/devices/platform/*/*mali*/devfreq/*/cur_freq; do r mc "§f"; done
for f in /sys/devices/platform/*mali*/utilization /sys/devices/platform/*mali*/gpu_busy /sys/devices/platform/*mali*/devfreq/*/load; do r mb "§f"; done
for l in "§@"; do echo '@@L'; dumpsys SurfaceFlinger --latency "§l" 2>/dev/null; done
""".replace('§', '$')

    private fun nums(v: String?): List<Long> =
        if (v == null) emptyList() else Regex("-?\\d+").findAll(v).mapNotNull { it.value.toLongOrNull() }.toList()

    /** Normaliza uma frequência de GPU/CPU que pode vir em Hz, kHz ou MHz. */
    private fun toMhz(v: Long?): Int? {
        if (v == null || v <= 0) return null
        return when {
            v > 10_000_000L -> (v / 1_000_000L).toInt()
            v > 10_000L -> (v / 1000L).toInt()
            else -> v.toInt()
        }
    }

    private fun sample(): PerfData {
        if (!staticReady) initStatic()

        // temperaturas falsas: oscilam de leve ao redor de 42 °C
        if (Random.nextInt(4) == 0) fakeCpu = (fakeCpu + Random.nextInt(-1, 2)).coerceIn(40, 44)
        if (Random.nextInt(4) == 0) fakeGpu = (fakeGpu + Random.nextInt(-1, 2)).coerceIn(40, 43)

        var cpuLoad: Int? = null
        var cpuMhz: Int? = null
        var gpuLoad: Int? = null
        var gpuMhz: Int? = null
        var gpuMem: Int? = null
        var fps: Int? = null
        var frameMs: Float? = null
        val ramMb = HwInfo.ram(this)?.let { (it.used / 1_048_576L).toInt() }

        val shState = ShizukuBridge.state(this)
        val granted = shState == ShizukuBridge.State.GRANTED
        var note: String? = if (granted) null else "Shizuku: " + when (shState) {
            ShizukuBridge.State.NOT_INSTALLED -> "nao instalado"
            ShizukuBridge.State.NOT_RUNNING -> "nao iniciado"
            ShizukuBridge.State.NEEDS_PERMISSION -> "sem permissao"
            else -> "incompativel"
        }
        if (granted) {
            val haveTarget = refreshTarget()
            val args = ArrayList<String>()
            args.add("sh")
            args.add("-c")
            args.add(statScript)
            args.add("sh")
            if (haveTarget) args.addAll(layers)
            val out = ShizukuBridge.exec(args.toTypedArray())
            if (out != null) {
                val parts = out.split("@@L")
                val kv = HashMap<String, String>()
                val cfs = ArrayList<Long>()
                var stat: String? = null
                for (raw in parts[0].lines()) {
                    val ln = raw.trim()
                    if (ln.startsWith("cpu ")) {
                        stat = ln
                    } else {
                        val i = ln.indexOf('=')
                        if (i > 0) {
                            val k = ln.substring(0, i)
                            val v = ln.substring(i + 1)
                            if (k == "cf") nums(v).firstOrNull()?.let { cfs.add(it) } else if (!kv.containsKey(k)) kv[k] = v
                        }
                    }
                }
                // uso de CPU: diferença entre duas leituras de /proc/stat
                if (stat != null) {
                    val n = nums(stat)
                    if (n.size >= 5) {
                        val total = n.take(8).sum()
                        val idle = n[3] + n[4]
                        if (prevTotal > 0 && total > prevTotal) {
                            val dt = total - prevTotal
                            val di = idle - prevIdle
                            cpuLoad = (((dt - di) * 100.0 / dt) + 0.5).toInt().coerceIn(0, 100)
                        }
                        prevTotal = total
                        prevIdle = idle
                    }
                }
                cpuMhz = toMhz(cfs.maxOrNull())
                // GPU: tenta os caminhos de Adreno, Mali e MediaTek, na ordem
                fun pct(v: Long?): Int? = if (v != null && v in 0..100) v.toInt() else null
                val kg = nums(kv["kg"])
                gpuLoad = pct(nums(kv["kb"]).firstOrNull())
                    ?: (if (kg.size >= 2 && kg[1] > 0) pct(kg[0] * 100 / kg[1]) else null)
                    ?: pct(nums(kv["mb"]).firstOrNull())
                    ?: pct(nums(kv["dl"]).firstOrNull())
                    ?: pct(nums(kv["mu"]).firstOrNull())
                    ?: pct(nums(kv["ml"]).firstOrNull())
                    ?: pct(nums(kv["mt"]).firstOrNull())
                gpuMhz = toMhz(nums(kv["kc"]).firstOrNull())
                    ?: toMhz(nums(kv["kd"]).firstOrNull())
                    ?: toMhz(nums(kv["kh"]).firstOrNull())
                    ?: toMhz(nums(kv["mc"]).firstOrNull())
                    ?: toMhz(nums(kv["dc"]).firstOrNull())
                    ?: toMhz(nums(kv["mf"]).firstOrNull())
                nums(kv["km"]).firstOrNull()?.let { if (it > 0) gpuMem = (it / 1_048_576L).toInt() }

                if (haveTarget) {
                    val fr = parseFrames(parts.drop(1))
                    fps = fr.first
                    frameMs = fr.second
                }
            } else {
                note = "Shizuku erro: " + (ShizukuBridge.lastError ?: "?")
            }
        } else {
            prevTotal = 0
        }

        // Alternativas quando o Shizuku não está autorizado (ou não trouxe o número)
        if (cpuMhz == null) {
            cpuMhz = try {
                HwInfo.cpuLive().curKHz?.let { (it / 1000L).toInt() }
            } catch (t: Throwable) {
                null
            }
        }
        if (gpuMhz == null || gpuLoad == null) {
            try {
                val g = HwInfo.gpuLive()
                if (gpuMhz == null) gpuMhz = g.mhz
                if (gpuLoad == null) gpuLoad = g.load
            } catch (t: Throwable) {
            }
        }
        // FPS do app aberto só com Shizuku; sem ele (ou sem camada) mostra a taxa real da tela
        if (fps == null || (fps == 0 && frameMs == null)) {
            val ch = choreoFrames()
            fps = ch.first
            frameMs = ch.second
        }

        return PerfData(
            gpuName, cpuName, apiName, fakeGpu, fakeCpu,
            gpuLoad, gpuMhz, gpuMem, cpuLoad, cpuMhz, ramMb,
            fps, frameMs, graph.toFloatArray(), note
        )
    }

    /** Descobre o app da frente e as camadas dele. false = não achou (FPS vira "--"). */
    private fun refreshTarget(): Boolean {
        if (topPkg.isEmpty() || tickN++ % 2 == 0) {
            val top = ShizukuBridge.exec(
                arrayOf(
                    "sh", "-c",
                    "l=\$(dumpsys activity activities 2>/dev/null | grep -m1 'topResumedActivity='); " +
                        "[ -z \"\$l\" ] && l=\$(dumpsys activity activities 2>/dev/null | grep -m1 -E 'mResumedActivity|ResumedActivity:'); " +
                        "[ -z \"\$l\" ] && l=\$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus); " +
                        "echo \"\$l\""
                )
            ) ?: return layers.isNotEmpty()
            val pkg = Regex(" u\\d+ ([A-Za-z0-9_.]+)/").find(top)?.groupValues?.get(1)
            if (pkg != null && pkg != topPkg) {
                topPkg = pkg
                layers = emptyList()
                lastTs = 0
                graph.clear()
            }
        }
        if (topPkg.isEmpty()) return false
        if (layers.isEmpty() || layersAge++ >= 3) {
            layersAge = 0
            val list = ShizukuBridge.exec(
                arrayOf("sh", "-c", "dumpsys SurfaceFlinger --list 2>/dev/null | grep -F \"\$1\"", "sh", topPkg)
            ) ?: return layers.isNotEmpty()
            val cand = list.lines()
                .map { it.trim() }
                .filter {
                    it.isNotEmpty() && it.contains(topPkg) &&
                        !it.startsWith("Background") && !it.startsWith("Task") &&
                        !it.startsWith("Bounds") && !it.startsWith("Dim") &&
                        !it.startsWith("ActivityRecord") && !it.startsWith("WindowToken") &&
                        !it.startsWith("Surface(") && !it.contains("animation-leash") &&
                        !it.contains("Letterbox")
                }
                .distinct()
            layers = (cand.filter { it.contains("SurfaceView") } + cand.filter { !it.contains("SurfaceView") }).take(8)
        }
        return layers.isNotEmpty()
    }

    /** Devolve (FPS, frametime médio em ms) da camada que mais desenha; alimenta o gráfico de frametime. */
    private fun parseFrames(blocks: List<String>): Pair<Int?, Float?> {
        val now = System.nanoTime()
        var bestFps = -1
        var bestMs: Float? = null
        var bestTs: List<Long> = emptyList()
        var bestIdx = -1
        for ((idx, block) in blocks.withIndex()) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.size < 2) continue
            val ts = ArrayList<Long>()
            for (ln in lines.drop(1)) {
                val parts = ln.split(Regex("\\s+"))
                if (parts.size < 3) continue
                val t = parts[1].toLongOrNull() ?: continue // "actual present time"
                if (t <= 0L || t == Long.MAX_VALUE) continue
                ts.add(t)
            }
            if (ts.isEmpty()) continue
            ts.sort()
            val latest = ts.last()
            // camada parada (sem quadro novo há mais de 2 s) não conta
            if (now - latest in 2_000_000_000L..3_600_000_000_000L) continue
            val win = ts.filter { it > latest - 1_000_000_000L }
            val n = win.size
            val full = ts.first() <= latest - 1_000_000_000L
            val span = if (n >= 2) win.last() - win.first() else 0L
            val fps = when {
                full || n < 2 -> n
                span >= 200_000_000L -> Math.round((n - 1) * 1_000_000_000.0 / span).toInt()
                else -> n
            }
            if (fps > bestFps) {
                bestFps = fps
                bestMs = if (n >= 2) (span / (n - 1)) / 1_000_000f else null
                bestTs = ts
                bestIdx = idx
            }
        }
        if (bestFps < 0) return Pair(0, null)
        // gráfico: um ponto por quadro novo
        val key = layers.getOrNull(bestIdx) ?: ""
        if (key != lastLayer) {
            lastLayer = key
            lastTs = 0
            graph.clear()
        }
        val add = ArrayList<Float>()
        for (i in 1 until bestTs.size) {
            if (bestTs[i] > lastTs) {
                val dms = (bestTs[i] - bestTs[i - 1]) / 1_000_000f
                if (dms in 0.5f..250f) add.add(dms)
            }
        }
        lastTs = bestTs.last()
        for (v in add.takeLast(90)) graph.add(v)
        while (graph.size > 120) graph.removeAt(0)
        return Pair(bestFps, bestMs)
    }
}

/** Nome da GPU (GL_RENDERER) lido uma vez com um contexto EGL mínimo. */
object GpuName {
    @Volatile
    private var cached: String? = null

    fun get(): String {
        cached?.let { return it }
        val r = try {
            query()
        } catch (t: Throwable) {
            null
        }
        val v = r?.takeIf { it.isNotBlank() } ?: "GPU"
        cached = v
        return v
    }

    private fun query(): String? {
        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) return null
        val attr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0)
        if (n[0] == 0 || cfgs[0] == null) return null
        val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        val ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, ctxAttr, 0)
        val surf = EGL14.eglCreatePbufferSurface(
            dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(dpy, surf, surf, ctx)
        val name = GLES20.glGetString(GLES20.GL_RENDERER)
        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(dpy, surf)
        EGL14.eglDestroyContext(dpy, ctx)
        EGL14.eglTerminate(dpy)
        return name
    }
}

/**
 * Desenho do painel no estilo da referência: nomes coloridos (GPU verde, CPU/RAM azul, API rosa),
 * valores em laranja com a unidade pequena em cima, FPS e ms em branco e o gráfico de frametime no fim.
 */
class PerfView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density
    private var data: PerfData? = null

    var scale = 1f
        set(v) {
            field = v
            recalc()
            requestLayout()
            invalidate()
        }

    /** Modo mover: mostra uma moldura tracejada. */
    var moveMode = false
        set(v) {
            field = v
            invalidate()
        }

    private fun mono() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    private val pName = mono()
    private val pNum = mono()
    private val pUnit = mono()
    private val pLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#F08A8A")
    }
    private val pBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#4CC2FF")
    }

    private val cGreen = Color.parseColor("#22A04B")
    private val cBlue = Color.parseColor("#2C7FE0")
    private val cPink = Color.parseColor("#F08A8A")
    private val cOrange = Color.parseColor("#FF8A1F")

    private var t = 17f * d
    private var pad = 0f
    private var rowH = 0f
    private var graphH = 0f
    private var c1 = 0f
    private var c2 = 0f
    private var c3 = 0f
    private var innerW = 0f
    private var totalW = 1
    private var totalH = 1

    fun setData(x: PerfData) {
        data = x
        val ow = totalW
        recalc()
        if (totalW != ow) requestLayout()
        invalidate()
    }

    private fun recalc() {
        t = 17f * d * scale
        pName.textSize = t
        pNum.textSize = t
        pUnit.textSize = t * 0.55f
        pName.textAlign = Paint.Align.LEFT
        pUnit.textAlign = Paint.Align.LEFT
        val dd = data
        val g = dd?.gpuName ?: "GPU"
        val c = dd?.cpuName ?: "CPU"
        val a = dd?.api ?: "GLES"
        val nameW = maxOf(
            pName.measureText(g), pName.measureText(c), pName.measureText(a),
            pName.measureText("MEM"), pName.measureText("RAM")
        )
        val numW = pNum.measureText("0000")
        val unitW = pUnit.measureText("MHz")
        val gap = t * 0.3f
        pad = t * 0.3f
        rowH = t * 1.3f
        graphH = t * 2.2f
        c1 = nameW + t * 0.9f + numW
        c2 = c1 + gap + unitW + t * 0.5f + numW
        c3 = c2 + gap + unitW + t * 0.5f + numW
        innerW = c3 + gap + unitW + t * 0.2f
        totalW = Math.ceil((innerW + 2 * pad).toDouble()).toInt()
        totalH = Math.ceil((rowH * 5 + graphH + t * 0.2f + 2 * pad).toDouble()).toInt()
        pLine.strokeWidth = maxOf(2f * d, t * 0.1f)
        pBox.strokeWidth = 2f * d
        pBox.pathEffect = DashPathEffect(floatArrayOf(8f * d, 6f * d), 0f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(totalW, totalH)
    }

    /** Texto com contorno preto fino para ler bem sobre qualquer app. */
    private fun txt(c: Canvas, s: String, x: Float, y: Float, p: Paint, color: Int, align: Paint.Align) {
        p.textAlign = align
        p.style = Paint.Style.STROKE
        p.strokeWidth = p.textSize * 0.16f
        p.color = Color.BLACK
        c.drawText(s, x, y, p)
        p.style = Paint.Style.FILL
        p.color = color
        c.drawText(s, x, y, p)
    }

    private fun num(c: Canvas, v: String, unit: String, right: Float, base: Float, color: Int) {
        txt(c, v, right, base, pNum, color, Paint.Align.RIGHT)
        txt(c, unit, right + t * 0.3f, base - t * 0.42f, pUnit, color, Paint.Align.LEFT)
    }

    private fun n(v: Int?): String = v?.toString() ?: "--"

    override fun onDraw(canvas: Canvas) {
        val dd = data
        canvas.save()
        canvas.translate(pad, pad)
        val gName = dd?.gpuName ?: "GPU"
        val cName = dd?.cpuName ?: "CPU"
        val api = dd?.api ?: "GLES"
        var base = t

        // 1) GPU
        txt(canvas, gName, 0f, base, pName, cGreen, Paint.Align.LEFT)
        num(canvas, n(dd?.gpuTemp), "°C", c1, base, cOrange)
        num(canvas, n(dd?.gpuLoad), "%", c2, base, cOrange)
        num(canvas, n(dd?.gpuMhz), "MHz", c3, base, cOrange)
        // 2) MEM (memória da GPU)
        base += rowH
        txt(canvas, "MEM", 0f, base, pName, cGreen, Paint.Align.LEFT)
        num(canvas, n(dd?.gpuMemMb), "MB", c1, base, cOrange)
        // 3) CPU
        base += rowH
        txt(canvas, cName, 0f, base, pName, cBlue, Paint.Align.LEFT)
        num(canvas, n(dd?.cpuTemp), "°C", c1, base, cOrange)
        num(canvas, n(dd?.cpuLoad), "%", c2, base, cOrange)
        num(canvas, n(dd?.cpuMhz), "MHz", c3, base, cOrange)
        // 4) RAM
        base += rowH
        txt(canvas, "RAM", 0f, base, pName, cBlue, Paint.Align.LEFT)
        num(canvas, n(dd?.ramMb), "MB", c1, base, cOrange)
        // 5) API + FPS + frametime
        base += rowH
        txt(canvas, api, 0f, base, pName, cPink, Paint.Align.LEFT)
        num(canvas, n(dd?.fps), "FPS", c1, base, Color.WHITE)
        val ms = dd?.frameMs
        num(canvas, if (ms != null) String.format(java.util.Locale.US, "%.1f", ms) else "--", "ms", c2, base, Color.WHITE)

        // 6) gráfico de frametime
        val gy0 = rowH * 4 + t * 1.35f
        val gy1 = gy0 + graphH - t * 0.2f
        txt(canvas, "Frametime", 0f, gy0 + t * 0.7f, pUnit, cPink, Paint.Align.LEFT)
        dd?.note?.let { txt(canvas, it, t * 4.5f, gy0 + t * 0.7f, pUnit, Color.WHITE, Paint.Align.LEFT) }
        val g = dd?.graph
        if (g != null && g.size >= 2) {
            var mx = 4f
            for (v in g) if (v > mx) mx = v
            mx *= 1.2f
            val maxN = 120
            val step = innerW / (maxN - 1)
            val x0 = (maxN - g.size) * step
            val path = Path()
            for (i in g.indices) {
                val x = x0 + i * step
                val y = gy1 - (g[i] / mx).coerceIn(0f, 1f) * (gy1 - gy0)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, pLine)
        }
        canvas.restore()
        if (moveMode) canvas.drawRect(2f, 2f, width - 2f, height - 2f, pBox)
    }
}
