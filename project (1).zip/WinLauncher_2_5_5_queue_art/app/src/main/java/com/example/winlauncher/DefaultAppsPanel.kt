package com.example.winlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

/**
 * Lista os apps nativos da WinLauncher e leva para o padrão de cada um.
 * O navegador tem papel próprio no Android e é definido direto; galeria, arquivos e
 * instalador de APK são escolhidos em Apps padrão do Android (o Android não deixa o app definir sozinho).
 */
class DefaultAppsPanel private constructor(
    ctx: Context,
    private val light: Boolean,
    private val browserDefault: () -> Boolean,
    private val request: (String) -> Unit
) : FrameLayout(ctx) {

    companion object {
        fun show(
            root: FrameLayout,
            ctx: Context,
            light: Boolean,
            browserDefault: () -> Boolean,
            request: (String) -> Unit
        ) {
            val p = DefaultAppsPanel(ctx, light, browserDefault, request)
            root.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            p.bringToFront()
        }
    }

    private class Item(val name: String, val icon: Int, val kind: String, val note: String)

    private val d = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val cText = if (light) Color.parseColor("#1F1F1F") else Color.WHITE
    private val cSub = if (light) Color.parseColor("#88000000") else Color.parseColor("#B3FFFFFF")
    private val cCard = if (light) Color.parseColor("#F5F5F5") else Color.parseColor("#202020")
    private val cRow = if (light) Color.parseColor("#14000000") else Color.parseColor("#26FFFFFF")
    private val cAccent = Color.parseColor("#3D9DFF")

    init {
        isClickable = true
        setBackgroundColor(Color.parseColor("#66000000"))
        setOnClickListener { close() }

        val cardW = min(dp(360), resources.displayMetrics.widthPixels - dp(32))
        val card = LinearLayout(context)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(20), dp(18), dp(20), dp(18))
        card.background = rounded(cCard, 16)
        card.isClickable = true
        addView(card, FrameLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val title = TextView(context)
        title.text = "Aplicativos padrão"
        title.setTextColor(cText)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        title.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        card.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sub = TextView(context)
        sub.text = "Escolha o app padrão de cada app nativo."
        sub.setTextColor(cSub)
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        card.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })

        val items = listOf(
            Item("Navegador", R.drawable.ic_browser, "browser", "Links e páginas da web"),
            Item("Galeria", R.drawable.ic_gallery, "gallery", "Fotos e imagens"),
            Item("Arquivos", R.drawable.ic_files, "files", "Pastas e arquivos"),
            Item("Instalador de aplicativos", R.drawable.ic_install, "apk", "Arquivos .apk"),
            Item("Reprodutor de música", R.drawable.ic_music_note, "audio", "Músicas e áudios")
        )
        for (item in items) {
            card.addView(row(item), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
    }

    private fun row(item: Item): LinearLayout {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(12), dp(10), dp(12), dp(10))
        r.background = rounded(cRow, 12)

        val icon = ImageView(context)
        icon.setImageResource(item.icon)
        r.addView(icon, LinearLayout.LayoutParams(dp(28), dp(28)))

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        val name = TextView(context)
        name.text = item.name
        name.setTextColor(cText)
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        name.isSingleLine = true
        col.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val status = TextView(context)
        status.text = if (item.kind == "browser" && browserDefault()) "Padrão do WinLauncher" else item.note
        status.setTextColor(cSub)
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        status.isSingleLine = true
        col.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10) })

        val btn = TextView(context)
        btn.text = "Definir"
        btn.setTextColor(Color.WHITE)
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        btn.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        btn.gravity = Gravity.CENTER
        btn.setPadding(dp(14), dp(8), dp(14), dp(8))
        btn.background = rounded(cAccent, 8)
        btn.isClickable = true
        btn.setOnClickListener {
            close()
            request(item.kind)
        }
        r.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        return r
    }

    private fun close() {
        (parent as? ViewGroup)?.removeView(this)
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }
}
