package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Servidor TLS local do WinLauncher Remote (Etapa 3B, Parte 1).
 *
 * O que faz nesta parte:
 *  - SSLServerSocket em 0.0.0.0 usando [RemoteAuth.buildServerSslContext] (chave do Android Keystore), TLS 1.2 e 1.3
 *    (o que o aparelho suportar; TLS 1.2 é obrigatório).
 *  - Só atende IPv4 de rede local (10.x, 172.16–31.x, 192.168.x, 169.254.x). Qualquer outro endereço é fechado
 *    logo depois do accept(), ANTES do handshake TLS.
 *  - No máximo [MAX_CLIENTS] clientes ao mesmo tempo; uma thread por cliente.
 *  - Mensagens do [RemoteProtocol] (uma por linha, no máximo 16 KB). Nesta parte: hello, ping, pong, error.
 *    Mensagem inválida, grande demais ou fora de ordem => error + conexão encerrada.
 *  - Pareamento, autenticação, estado musical e comandos NÃO são feitos aqui: sem gancho, auth/command recebem
 *    NOT_PAIRED e pair_request recebe PAIRING_DENIED. A Parte 2 ([RemoteBridge]) entra pelos ganchos [onMessage] e
 *    [onClientClosed] e trata tudo isso.
 *
 * Este arquivo NÃO usa o MediaSessionHub e não toca no ciclo de vida dele (quem faz isso é o [RemoteBridge]).
 *
 * Threads: [start] e [stop] podem ser chamados de qualquer thread, mas NÃO da thread principal em [stop] se houver
 * clientes lentos (o fechamento é rápido, porém o join espera até ~2 s). O serviço chama [stop] numa thread própria.
 */
class RemoteServer(
    ctx: Context,
    private val port: Int = RemoteProtocol.DEFAULT_PORT,
    /** Só para os autotestes (conexão local de teste). O servidor real nunca aceita loopback. */
    private val allowLoopback: Boolean = false,
    private val maxClients: Int = MAX_CLIENTS,
    /** Nome usado nas threads (\"WinRemote-<tag>-...\"). */
    private val tag: String = "main",
    private val idleMs: Long = IDLE_MS,
    private val pingMs: Long = PING_EVERY_MS,
    private val events: Events? = null
) {

    enum class State { STOPPED, STARTING, RUNNING, STOPPING, ERROR }

    /** Avisos do servidor. Chamados em threads do servidor: quem recebe deve postar na thread principal se for mexer na tela. */
    interface Events {
        fun onState(state: State, error: String)
        fun onClients(count: Int)
        fun onLog(line: String)
    }

    companion object {
        const val MAX_CLIENTS = 4
        const val HANDSHAKE_MS = 10_000L
        const val IDLE_MS = 45_000L
        const val PING_EVERY_MS = 15_000L
        /** Tempo máximo para uma mensagem chegar inteira depois do primeiro byte. */
        const val PARTIAL_MS = 10_000L
        private const val BACKLOG = 8
        private const val TAG = "WinRemoteServer"
        private const val NL = '\n'.code.toByte()

        /** Endereço IPv4 de rede local? (10/8, 172.16/12, 192.168/16, 169.254/16.) Loopback só se [allowLoopback]. */
        fun isAllowedAddress(a: InetAddress?, allowLoopback: Boolean = false): Boolean {
            if (a == null || a !is Inet4Address) return false
            if (a.isAnyLocalAddress || a.isMulticastAddress) return false
            if (a.isLoopbackAddress) return allowLoopback
            val b = a.address
            if (b.size != 4) return false
            val b0 = b[0].toInt() and 0xff
            val b1 = b[1].toInt() and 0xff
            return b0 == 10 ||
                (b0 == 172 && b1 in 16..31) ||
                (b0 == 192 && b1 == 168) ||
                (b0 == 169 && b1 == 254)
        }

        /** Endereços IPv4 locais deste aparelho que o servidor atende: pares (ip, interface). Wi-Fi/hotspot primeiro. */
        fun localAddresses(): List<Pair<String, String>> {
            val out = ArrayList<Pair<String, String>>()
            try {
                val en = NetworkInterface.getNetworkInterfaces() ?: return out
                for (ni in Collections.list(en)) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in Collections.list(ni.inetAddresses)) {
                        if (ia is Inet4Address && isAllowedAddress(ia, false)) {
                            out.add(Pair(ia.hostAddress ?: continue, ni.name ?: "?"))
                        }
                    }
                }
            } catch (e: Exception) {
            }
            fun rank(n: String): Int = when {
                n.startsWith("wlan") || n.startsWith("swlan") || n.startsWith("ap") -> 0
                n.startsWith("eth") -> 1
                else -> 2
            }
            return out.sortedBy { rank(it.second) }
        }
    }

    private val app: Context = ctx.applicationContext
    private val lifecycle = Any()
    private val clients = ArrayList<Client>()
    private val clientCount = AtomicInteger(0)
    private val rejected = AtomicInteger(0)
    private val nextClientId = AtomicInteger(1)
    private val logLines = ArrayList<String>()

    @Volatile
    var state: State = State.STOPPED
        private set

    @Volatile
    var lastError: String = ""
        private set

    @Volatile
    var boundPort: Int = 0
        private set

    @Volatile
    var protocols: String = ""
        private set

    @Volatile
    private var stopping = false

    private var serverSocket: SSLServerSocket? = null
    private var acceptThread: Thread? = null
    private var serverId = ""
    private var serverName = "WinLauncher"

    /** Nome que o servidor mostra aos clientes (modelo do aparelho). */
    val displayName: String get() = serverName

    /**
     * Gancho da Parte 2: recebe pair_request, auth e command de um cliente que já fez hello. Devolva true se tratou a
     * mensagem. Roda na thread do cliente. Sem gancho (Parte 1), o servidor responde com erro.
     */
    @Volatile
    var onMessage: ((Client, RemoteProtocol.Message) -> Boolean)? = null

    /** Parte 2: avisa que um cliente foi desconectado (qualquer motivo). Roda na thread do cliente, no fim da conexão. */
    @Volatile
    var onClientClosed: ((Client) -> Unit)? = null

    fun clientCount(): Int = clientCount.get()

    /** Conexões fechadas por vir de IP não permitido ou por excesso de clientes desde que o servidor ligou. */
    fun rejectedCount(): Int = rejected.get()

    fun clientsSnapshot(): List<Client> = synchronized(clients) { ArrayList(clients) }

    /** Threads do servidor ainda vivas (aceitação + clientes). Zero depois de [stop]. */
    fun liveThreads(): Int {
        var n = 0
        if (acceptThread?.isAlive == true) n++
        for (c in clientsSnapshot()) if (c.thread?.isAlive == true) n++
        return n
    }

    private fun log(s: String) {
        Log.i(TAG, s)
        synchronized(logLines) {
            logLines.add(s)
            while (logLines.size > 40) logLines.removeAt(0)
        }
        try {
            events?.onLog(s)
        } catch (e: Throwable) {
        }
    }

    fun recentLog(): List<String> = synchronized(logLines) { ArrayList(logLines) }

    private fun setState(s: State, err: String = "") {
        state = s
        lastError = err
        try {
            events?.onState(s, err)
        } catch (e: Throwable) {
        }
    }

    private fun notifyClients() {
        try {
            events?.onClients(clientCount.get())
        } catch (e: Throwable) {
        }
    }

    // ------------------------------------------------------------------ ligar / desligar

    /** Liga o servidor. Nunca lança exceção: em caso de falha o estado vira ERROR (com o motivo) e tudo é liberado. */
    fun start(): Boolean = synchronized(lifecycle) { startLocked() }

    private fun startLocked(): Boolean {
        if (state == State.RUNNING) return true
        if (state == State.STARTING || state == State.STOPPING) return false
        stopping = false
        clientCount.set(0)
        rejected.set(0)
        synchronized(clients) { clients.clear() }
        setState(State.STARTING)
        var ss: SSLServerSocket? = null
        try {
            RemoteAuth.init(app)
            val rep = RemoteAuth.ensureKey()
            serverId = RemoteAuth.hex(rep.fingerprint).take(32)
            serverName = RemoteProtocol.clip(
                (Build.MODEL ?: "").trim().ifEmpty { "WinLauncher" }, RemoteProtocol.MAX_NAME
            )
            val ctx = RemoteAuth.buildServerSslContext()
            val sock = ctx.serverSocketFactory.createServerSocket(port, BACKLOG, InetAddress.getByName("0.0.0.0")) as SSLServerSocket
            ss = sock
            val supported = sock.supportedProtocols.toSet()
            val want = listOf("TLSv1.3", "TLSv1.2").filter { it in supported }
            if (!want.contains("TLSv1.2")) throw IOException("este Android não oferece TLS 1.2")
            sock.enabledProtocols = want.toTypedArray()
            sock.needClientAuth = false
            sock.wantClientAuth = false
            serverSocket = sock
            boundPort = sock.localPort
            protocols = want.joinToString(", ")
            val t = Thread({ acceptLoop(sock) }, "WinRemote-$tag-accept")
            t.isDaemon = true
            acceptThread = t
            t.start()
            log("servidor ligado na porta $boundPort (TLS: $protocols)")
            setState(State.RUNNING)
            return true
        } catch (e: Throwable) {
            val msg = describe(e)
            log("falha ao ligar: $msg")
            try {
                ss?.close()
            } catch (x: Exception) {
            }
            serverSocket = null
            acceptThread = null
            boundPort = 0
            setState(State.ERROR, msg)
            return false
        }
    }

    /** Desliga: fecha o socket de escuta e todos os clientes, e espera as threads terminarem (até ~2 s). Pode ser chamado várias vezes. */
    fun stop() {
        synchronized(lifecycle) {
            if (state == State.STOPPED) return
            if (state == State.STARTING) return
            stopping = true
            val wasError = state == State.ERROR
            if (!wasError) setState(State.STOPPING)
            val ss = serverSocket
            serverSocket = null
            try {
                ss?.close()
            } catch (e: Exception) {
            }
            for (c in clientsSnapshot()) c.forceClose()
            val deadline = SystemClock.elapsedRealtime() + 2000L
            joinUntil(acceptThread, deadline)
            for (c in clientsSnapshot()) joinUntil(c.thread, deadline)
            val left = liveThreads()
            if (left > 0) log("aviso: $left thread(s) ainda terminando depois do desligamento")
            acceptThread = null
            synchronized(clients) { clients.clear() }
            clientCount.set(0)
            boundPort = 0
            log("servidor desligado")
            setState(State.STOPPED)
            notifyClients()
        }
    }

    private fun joinUntil(t: Thread?, deadline: Long) {
        if (t == null || t === Thread.currentThread()) return
        val left = deadline - SystemClock.elapsedRealtime()
        if (left <= 0) return
        try {
            t.join(left)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun describe(e: Throwable): String {
        val m = e.message
        return e.javaClass.simpleName + (if (m.isNullOrBlank()) "" else ": $m")
    }

    // ------------------------------------------------------------------ aceitação

    private fun acceptLoop(ss: SSLServerSocket) {
        var failures = 0
        while (!stopping && !ss.isClosed) {
            val raw: Socket = try {
                ss.accept()
            } catch (e: IOException) {
                if (stopping || ss.isClosed) break
                failures++
                log("erro no accept (${failures}): " + describe(e))
                if (failures >= 20) {
                    log("accept falhou 20 vezes seguidas; servidor será desligado")
                    setState(State.ERROR, "falha repetida ao aceitar conexões: " + describe(e))
                    break
                }
                try {
                    Thread.sleep(250)
                } catch (x: InterruptedException) {
                    break
                }
                continue
            }
            failures = 0
            handleAccepted(raw)
        }
    }

    private fun handleAccepted(raw: Socket) {
        val remote = raw.inetAddress
        if (!isAllowedAddress(remote, allowLoopback)) {
            rejected.incrementAndGet()
            log("recusado (IP fora da rede local): " + (remote?.hostAddress ?: "?"))
            closeQuiet(raw, true)
            return
        }
        val sock = raw as? SSLSocket
        if (sock == null) {
            closeQuiet(raw, true)
            return
        }
        if (clientCount.incrementAndGet() > maxClients) {
            clientCount.decrementAndGet()
            rejected.incrementAndGet()
            log("recusado (limite de $maxClients clientes): " + (remote?.hostAddress ?: "?"))
            closeQuiet(raw, true)
            return
        }
        val c = Client(sock, nextClientId.getAndIncrement(), remote?.hostAddress ?: "?")
        val t = Thread({ c.run() }, "WinRemote-$tag-client-${c.id}")
        t.isDaemon = true
        c.thread = t
        synchronized(clients) { clients.add(c) }
        if (stopping) {
            c.forceClose()
        }
        t.start()
        notifyClients()
    }

    private fun closeQuiet(s: Socket, hard: Boolean) {
        if (hard) {
            try {
                s.setSoLinger(true, 0)
            } catch (e: Exception) {
            }
        }
        try {
            s.close()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ cliente

    /** Uma conexão de cliente. Uma thread própria lê as mensagens; [send] pode ser chamado de outras threads (nunca da principal). */
    inner class Client internal constructor(private val sock: SSLSocket, val id: Int, val address: String) {

        @Volatile
        var thread: Thread? = null
            internal set

        /** Nome/id informados no hello (\"\" antes do hello). */
        @Volatile
        var deviceId: String = ""
            private set

        @Volatile
        var deviceName: String = ""
            private set

        /** Fez hello? */
        @Volatile
        var helloDone: Boolean = false
            private set

        /** Vira true quando o [RemoteBridge] valida o token do aparelho pareado (ou conclui o pareamento). Sem ele, nunca é true. */
        @Volatile
        var authenticated: Boolean = false

        @Volatile
        private var out: OutputStream? = null
        private val writeLock = Any()

        @Volatile
        private var drainOnClose = false

        @Volatile
        private var closed = false

        /** Envia uma mensagem (thread-safe). Lança IOException se a conexão caiu. */
        fun send(m: RemoteProtocol.Message) {
            val o = out ?: throw IOException("conexão ainda não está pronta")
            val bytes = RemoteProtocol.encodeFrame(m)
            synchronized(writeLock) {
                o.write(bytes)
                o.flush()
            }
        }

        private fun sendQuiet(m: RemoteProtocol.Message) {
            try {
                send(m)
            } catch (e: Exception) {
            }
        }

        /** Fecha na hora (usado no desligamento): RST em vez de fechamento educado, para nunca travar. */
        fun forceClose() {
            closed = true
            closeQuiet(sock, true)
        }

        private fun fail(code: RemoteProtocol.ErrorCode, text: String, id: Long? = null) {
            sendQuiet(RemoteProtocol.Message.ErrorMsg(code, RemoteProtocol.clip(text, RemoteProtocol.MAX_TEXT), id))
            drainOnClose = true
            closed = true
        }

        fun run() {
            log("cliente #$id conectou: $address")
            try {
                sock.soTimeout = HANDSHAKE_MS.toInt()
                sock.startHandshake()
                val poll = minOf(5000L, pingMs / 2, idleMs / 3).coerceAtLeast(100L).toInt()
                sock.soTimeout = poll
                out = sock.outputStream
                val reader = FrameReader(sock.inputStream)
                var lastRx = SystemClock.elapsedRealtime()
                var lastPing = lastRx
                while (!stopping && !closed) {
                    val line: String? = try {
                        reader.next()
                    } catch (e: SocketTimeoutException) {
                        val now = SystemClock.elapsedRealtime()
                        if (reader.hasPartial && now - reader.partialSince > PARTIAL_MS) {
                            fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "mensagem incompleta")
                            break
                        }
                        if (now - lastRx > idleMs) {
                            log("cliente #$id inativo; desconectado")
                            break
                        }
                        if (helloDone && now - maxOf(lastRx, lastPing) >= pingMs) {
                            sendQuiet(RemoteProtocol.Message.Ping)
                            lastPing = now
                        }
                        continue
                    }
                    if (line == null) break
                    lastRx = SystemClock.elapsedRealtime()
                    val msg = try {
                        RemoteProtocol.decode(line)
                    } catch (e: RemoteProtocol.ProtocolException) {
                        fail(e.code, e.message ?: "mensagem inválida")
                        break
                    }
                    handle(msg)
                }
            } catch (e: RemoteProtocol.ProtocolException) {
                fail(e.code, e.message ?: "mensagem inválida")
            } catch (e: Throwable) {
                if (!stopping && !closed) log("cliente #$id: " + describe(e))
            } finally {
                finish()
            }
        }

        private fun handle(msg: RemoteProtocol.Message) {
            if (!helloDone) {
                if (msg !is RemoteProtocol.Message.Hello) {
                    fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "envie hello primeiro")
                    return
                }
                if (msg.role != "remote") {
                    fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "role inválido")
                    return
                }
                if (msg.version != RemoteProtocol.VERSION) {
                    fail(RemoteProtocol.ErrorCode.UNSUPPORTED_VERSION, "versão de protocolo não suportada")
                    return
                }
                deviceId = msg.deviceId
                deviceName = msg.deviceName
                try {
                    send(RemoteProtocol.Message.Hello(RemoteProtocol.VERSION, serverId, serverName, "server"))
                } catch (e: Exception) {
                    closed = true
                    return
                }
                helloDone = true
                log("cliente #$id: hello de \"${RemoteProtocol.clip(msg.deviceName, 32)}\"")
                return
            }
            when (msg) {
                RemoteProtocol.Message.Ping -> sendQuiet(RemoteProtocol.Message.Pong)
                RemoteProtocol.Message.Pong -> {
                }
                is RemoteProtocol.Message.Hello -> fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "hello repetido")
                is RemoteProtocol.Message.PairRequest -> {
                    if (!offer(msg)) {
                        sendQuiet(
                            RemoteProtocol.Message.ErrorMsg(
                                RemoteProtocol.ErrorCode.PAIRING_DENIED, "pareamento ainda não disponível nesta versão", null
                            )
                        )
                    }
                }
                is RemoteProtocol.Message.Auth -> {
                    if (!offer(msg)) {
                        sendQuiet(
                            RemoteProtocol.Message.ErrorMsg(
                                RemoteProtocol.ErrorCode.NOT_PAIRED, "autenticação ainda não disponível nesta versão", null
                            )
                        )
                    }
                }
                is RemoteProtocol.Message.CommandMsg -> {
                    if (!offer(msg)) {
                        sendQuiet(
                            RemoteProtocol.Message.ErrorMsg(
                                RemoteProtocol.ErrorCode.NOT_PAIRED, "aparelho não pareado", msg.id
                            )
                        )
                    }
                }
                else -> fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "tipo de mensagem não aceito do cliente")
            }
        }

        private fun offer(msg: RemoteProtocol.Message): Boolean {
            val h = onMessage ?: return false
            return try {
                h(this, msg)
            } catch (e: Throwable) {
                log("cliente #$id: erro no tratamento de ${msg.type}: " + describe(e))
                false
            }
        }

        /** Depois de um erro fatal, lê e descarta o que o cliente ainda mandou (até 64 KB / 0,5 s) para o erro chegar antes do fechamento. */
        private fun drainInput() {
            try {
                sock.soTimeout = 200
                val input = sock.inputStream
                val buf = ByteArray(4096)
                var total = 0
                val end = SystemClock.elapsedRealtime() + 500L
                while (total < 65536 && SystemClock.elapsedRealtime() < end) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                }
            } catch (e: Exception) {
            }
        }

        private fun finish() {
            if (drainOnClose) drainInput()
            closeQuiet(sock, false)
            val removed = synchronized(clients) { clients.remove(this) }
            if (removed) clientCount.decrementAndGet()
            log("cliente #$id desconectou")
            try {
                onClientClosed?.invoke(this)
            } catch (e: Throwable) {
            }
            notifyClients()
        }
    }
}

// ---------------------------------------------------------------------- leitura de linhas

/**
 * Lê mensagens (linhas terminadas em '\n', no máximo [RemoteProtocol.MAX_FRAME_BYTES] bytes sem o '\n').
 * Diferente de [RemoteProtocol.readFrame], guarda os bytes já lidos quando o socket dá timeout no meio da mensagem.
 */
private class FrameReader(private val input: InputStream) {
    private val store = ByteArray(RemoteProtocol.MAX_FRAME_BYTES + 4096)
    private var start = 0
    private var end = 0

    val hasPartial: Boolean get() = end > start

    /** Instante (elapsedRealtime) em que chegou o primeiro byte da mensagem em andamento. */
    var partialSince = 0L
        private set

    /** Próxima mensagem; null = o cliente fechou a conexão limpo. Pode lançar SocketTimeoutException (estado preservado). */
    fun next(): String? {
        while (true) {
            var i = start
            while (i < end && store[i] != '\n'.code.toByte()) i++
            if (i < end) {
                val len = i - start
                if (len > RemoteProtocol.MAX_FRAME_BYTES) {
                    throw RemoteProtocol.ProtocolException(RemoteProtocol.ErrorCode.TOO_LARGE, "mensagem grande demais")
                }
                val s = String(store, start, len, Charsets.UTF_8)
                start = i + 1
                if (start >= end) {
                    start = 0
                    end = 0
                    partialSince = 0L
                } else {
                    partialSince = SystemClock.elapsedRealtime()
                }
                return s
            }
            if (end - start > RemoteProtocol.MAX_FRAME_BYTES) {
                throw RemoteProtocol.ProtocolException(RemoteProtocol.ErrorCode.TOO_LARGE, "mensagem grande demais")
            }
            if (start > 0) {
                System.arraycopy(store, start, store, 0, end - start)
                end -= start
                start = 0
            }
            val n = input.read(store, end, store.size - end)
            if (n < 0) {
                if (end - start == 0) return null
                throw RemoteProtocol.ProtocolException(
                    RemoteProtocol.ErrorCode.BAD_REQUEST, "conexão encerrada no meio de uma mensagem"
                )
            }
            if (n > 0 && end == start) partialSince = SystemClock.elapsedRealtime()
            end += n
        }
    }
}

// ---------------------------------------------------------------------- autotestes

/**
 * Autoteste local do servidor (Etapa 3B, Parte 1). Sobe servidores de teste em portas efêmeras (porta 0) e conecta
 * clientes TLS reais por 127.0.0.1; não mexe no servidor "de verdade" nem na porta 48655.
 * Chame fora da thread principal (leva alguns segundos).
 */
object RemoteServerTest {

    private class PinTrust(private val expected: ByteArray) : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {
            throw CertificateException("não usado")
        }

        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {
            val c = chain?.firstOrNull() ?: throw CertificateException("servidor não apresentou certificado")
            if (!MessageDigest.isEqual(RemoteAuth.fingerprint(c), expected)) {
                throw CertificateException("hash do certificado não confere")
            }
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    private class TestClient(val s: SSLSocket) {
        private val reader = FrameReader(s.inputStream)
        private val out = s.outputStream

        fun send(m: RemoteProtocol.Message) {
            out.write(RemoteProtocol.encodeFrame(m))
            out.flush()
        }

        fun sendRaw(b: ByteArray) {
            out.write(b)
            out.flush()
        }

        /** Próxima mensagem ou null se a conexão fechou limpa. */
        fun recv(): RemoteProtocol.Message? {
            val l = reader.next() ?: return null
            return RemoteProtocol.decode(l)
        }

        fun close() {
            try {
                s.close()
            } catch (e: Exception) {
            }
        }
    }

    private const val CLIENT_ID = "AutotesteRemote01"

    private fun hello(role: String = "remote", version: Int = RemoteProtocol.VERSION) =
        RemoteProtocol.Message.Hello(version, CLIENT_ID, "Autoteste", role)

    private fun connect(port: Int, trust: TrustManager?, protocols: Array<String>? = null, timeoutMs: Int = 5000): TestClient {
        val c = SSLContext.getInstance("TLS")
        c.init(null, if (trust == null) null else arrayOf(trust), null)
        val raw = Socket()
        try {
            raw.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 3000)
        } catch (e: Throwable) {
            try {
                raw.close()
            } catch (x: Exception) {
            }
            throw e
        }
        val s = c.socketFactory.createSocket(raw, "127.0.0.1", port, true) as SSLSocket
        try {
            if (protocols != null) s.enabledProtocols = protocols
            s.soTimeout = timeoutMs
            s.startHandshake()
        } catch (e: Throwable) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            throw e
        }
        return TestClient(s)
    }

    private fun check(checks: MutableList<RemoteAuth.Check>, name: String, essential: Boolean = true, block: () -> String) {
        try {
            checks.add(RemoteAuth.Check(name, true, block(), essential))
        } catch (e: Throwable) {
            checks.add(RemoteAuth.Check(name, false, e.javaClass.simpleName + ": " + (e.message ?: ""), essential))
        }
    }

    private fun expectHello(c: TestClient): RemoteProtocol.Message.Hello {
        val m = c.recv()
        if (m !is RemoteProtocol.Message.Hello || m.role != "server") throw IllegalStateException("esperava hello do servidor, veio: $m")
        return m
    }

    private fun expectError(c: TestClient, code: RemoteProtocol.ErrorCode) {
        val m = c.recv()
        if (m !is RemoteProtocol.Message.ErrorMsg) throw IllegalStateException("esperava erro ${code.wire}, veio: $m")
        if (m.code != code) throw IllegalStateException("esperava erro ${code.wire}, veio ${m.code.wire}")
    }

    private fun expectClosed(c: TestClient) {
        var closed = false
        try {
            while (true) {
                val m = c.recv()
                if (m == null) {
                    closed = true
                    break
                }
                if (m !is RemoteProtocol.Message.Ping) break // chegou outra coisa: não fechou
            }
        } catch (e: SocketTimeoutException) {
        } catch (e: IOException) {
            closed = true
        } catch (e: RemoteProtocol.ProtocolException) {
            closed = true
        }
        if (!closed) throw IllegalStateException("a conexão deveria ter sido encerrada pelo servidor")
    }

    private fun waitUntil(ms: Long, cond: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < end) {
            if (cond()) return true
            try {
                Thread.sleep(50)
            } catch (e: InterruptedException) {
                return cond()
            }
        }
        return cond()
    }

    private fun ip(a: Int, b: Int, c: Int, d: Int): InetAddress =
        InetAddress.getByAddress(byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte()))

    private fun testThreads(): List<String> =
        Thread.getAllStackTraces().keys.filter { it.isAlive && it.name.startsWith("WinRemote-test") }.map { it.name }

    fun selfTest(ctx: Context): List<RemoteAuth.Check> {
        val checks = ArrayList<RemoteAuth.Check>()
        val app = ctx.applicationContext
        RemoteAuth.init(app)

        var fpHolder: ByteArray? = null
        check(checks, "Chave e certificado do servidor") {
            val r = RemoteAuth.ensureKey()
            fpHolder = r.fingerprint
            r.algorithm + ", SHA-256 " + RemoteAuth.shortFingerprint(r.fingerprint) + "…"
        }
        val fp = fpHolder
        if (fp == null) {
            checks.add(RemoteAuth.Check("Demais testes", false, "não executados (sem chave/certificado)"))
            return checks
        }
        val pin = PinTrust(fp)

        // regra de endereços (sem rede)
        check(checks, "Regra de IPs: só rede local IPv4") {
            val ok = listOf(
                ip(192, 168, 1, 5), ip(10, 0, 0, 2), ip(172, 16, 0, 1), ip(172, 31, 255, 1), ip(169, 254, 1, 1)
            )
            val bad = listOf(
                ip(8, 8, 8, 8), ip(172, 15, 0, 1), ip(172, 32, 0, 1), ip(100, 64, 0, 1), ip(127, 0, 0, 1),
                ip(0, 0, 0, 0), ip(224, 0, 0, 1), ip(192, 169, 0, 1), InetAddress.getByName("::1")
            )
            for (a in ok) if (!RemoteServer.isAllowedAddress(a)) throw IllegalStateException("deveria aceitar ${a.hostAddress}")
            for (a in bad) if (RemoteServer.isAllowedAddress(a)) throw IllegalStateException("deveria recusar ${a.hostAddress}")
            if (!RemoteServer.isAllowedAddress(ip(127, 0, 0, 1), true)) throw IllegalStateException("loopback de teste deveria passar")
            "${ok.size} endereços aceitos e ${bad.size} recusados, como esperado"
        }

        val srv = RemoteServer(app, port = 0, allowLoopback = true, maxClients = RemoteServer.MAX_CLIENTS, tag = "test1")
        val srvNet = RemoteServer(app, port = 0, allowLoopback = false, tag = "test2")
        val srvIdle = RemoteServer(app, port = 0, allowLoopback = true, tag = "test3", idleMs = 1500L, pingMs = 400L)
        try {
            // 1) inicialização
            var port = 0
            check(checks, "Servidor liga (porta de teste)") {
                if (!srv.start()) throw IllegalStateException("não ligou: " + srv.lastError)
                if (srv.state != RemoteServer.State.RUNNING) throw IllegalStateException("estado ${srv.state}")
                port = srv.boundPort
                if (port !in 1..65535) throw IllegalStateException("porta inválida: $port")
                "porta efêmera $port (a porta real é ${RemoteProtocol.DEFAULT_PORT}); TLS habilitado: ${srv.protocols}"
            }
            if (port == 0) {
                checks.add(RemoteAuth.Check("Demais testes do servidor", false, "não executados (o servidor de teste não ligou)"))
                return checks
            }

            // 2) handshake TLS real
            check(checks, "Handshake TLS real (cliente fixando o hash do certificado)") {
                val c = connect(port, pin)
                try {
                    val sess = c.s.session
                    val peer = sess.peerCertificates.firstOrNull() as? X509Certificate
                        ?: throw IllegalStateException("sem certificado do servidor")
                    if (!MessageDigest.isEqual(RemoteAuth.fingerprint(peer), fp)) throw IllegalStateException("certificado diferente do esperado")
                    "negociado ${sess.protocol} com ${sess.cipherSuite}; certificado confere com o hash da Etapa 3A"
                } finally {
                    c.close()
                }
            }
            check(checks, "TLS 1.2 aceito") {
                val c = connect(port, pin, arrayOf("TLSv1.2"))
                try {
                    "negociado " + c.s.session.protocol
                } finally {
                    c.close()
                }
            }
            val supports13 = try {
                SSLContext.getDefault().supportedSSLParameters.protocols.contains("TLSv1.3")
            } catch (e: Exception) {
                false
            }
            if (supports13) {
                check(checks, "TLS 1.3 aceito", essential = false) {
                    val c = connect(port, pin, arrayOf("TLSv1.3"))
                    try {
                        "negociado " + c.s.session.protocol
                    } finally {
                        c.close()
                    }
                }
            } else {
                checks.add(RemoteAuth.Check("TLS 1.3 aceito", false, "este Android não oferece TLS 1.3 no cliente (normal abaixo do Android 10); só o TLS 1.2 foi testado", false))
            }
            check(checks, "Cliente que não confia no certificado é recusado no handshake", essential = false) {
                var refused = false
                try {
                    connect(port, PinTrust(ByteArray(32))).close()
                } catch (e: IOException) {
                    refused = true
                }
                if (!refused) throw IllegalStateException("handshake com hash errado foi aceito")
                var refused2 = false
                try {
                    connect(port, null).close()
                } catch (e: IOException) {
                    refused2 = true
                }
                if (!refused2) throw IllegalStateException("handshake com a confiança padrão do sistema foi aceito (certificado autoassinado!)")
                "hash errado e confiança padrão do sistema: ambos recusaram (esperado para certificado autoassinado)"
            }

            // 3) hello, ping/pong, não autenticado
            check(checks, "Mensagem hello") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    val h = expectHello(c)
                    if (h.version != RemoteProtocol.VERSION) throw IllegalStateException("versão ${h.version}")
                    "servidor respondeu hello (versão ${h.version}, nome \"${h.deviceName}\")"
                } finally {
                    c.close()
                }
            }
            check(checks, "Ping e pong") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.Ping)
                    val m = c.recv()
                    if (m != RemoteProtocol.Message.Pong) throw IllegalStateException("esperava pong, veio: $m")
                    "ping respondido com pong"
                } finally {
                    c.close()
                }
            }
            check(checks, "Cliente sem pareamento não executa comandos") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.CommandMsg(5L, RemoteProtocol.Command.NEXT))
                    expectError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                    c.send(RemoteProtocol.Message.Auth(CLIENT_ID, RemoteProtocol.b64(ByteArray(RemoteProtocol.TOKEN_BYTES) { 1 })))
                    expectError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                    c.send(RemoteProtocol.Message.Ping)
                    if (c.recv() != RemoteProtocol.Message.Pong) throw IllegalStateException("conexão deveria continuar viva")
                    "command e auth recusados com not_paired; a conexão continua válida"
                } finally {
                    c.close()
                }
            }

            // 4) mensagens inválidas
            check(checks, "Rejeita mensagem fora de ordem, JSON inválido e versão errada") {
                var c = connect(port, pin)
                try {
                    c.send(RemoteProtocol.Message.Ping)
                    expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.sendRaw("{nao e json\n".toByteArray(Charsets.UTF_8))
                    expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                c = connect(port, pin)
                try {
                    c.sendRaw("{\"v\":99,\"t\":\"ping\"}\n".toByteArray(Charsets.UTF_8))
                    expectError(c, RemoteProtocol.ErrorCode.UNSUPPORTED_VERSION)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                c = connect(port, pin)
                try {
                    c.send(hello(role = "server"))
                    expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                "ping antes do hello, JSON quebrado, versão 99 e role errado: todos com erro e conexão encerrada"
            }
            check(checks, "Rejeita mensagem maior que 16 KB") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    val big = ByteArray(RemoteProtocol.MAX_FRAME_BYTES + 10) { 'a'.code.toByte() }
                    c.sendRaw(big)
                    c.sendRaw(byteArrayOf('\n'.code.toByte()))
                    expectError(c, RemoteProtocol.ErrorCode.TOO_LARGE)
                    expectClosed(c)
                    "mensagem de ${big.size} bytes recusada com too_large e conexão encerrada"
                } finally {
                    c.close()
                }
            }

            // 5) limite de clientes
            check(checks, "Limite de ${RemoteServer.MAX_CLIENTS} clientes simultâneos") {
                if (!waitUntil(3000) { srv.clientCount() == 0 }) throw IllegalStateException("clientes anteriores não saíram (${srv.clientCount()})")
                val cs = ArrayList<TestClient>()
                try {
                    repeat(RemoteServer.MAX_CLIENTS) {
                        val c = connect(port, pin)
                        cs.add(c)
                        c.send(hello())
                        expectHello(c)
                    }
                    if (srv.clientCount() != RemoteServer.MAX_CLIENTS) throw IllegalStateException("contagem ${srv.clientCount()}")
                    var served = false
                    try {
                        val c5 = connect(port, pin)
                        try {
                            c5.send(hello())
                            served = c5.recv() is RemoteProtocol.Message.Hello
                        } finally {
                            c5.close()
                        }
                    } catch (e: IOException) {
                    } catch (e: RemoteProtocol.ProtocolException) {
                    }
                    if (served) throw IllegalStateException("o quinto cliente foi atendido")
                    cs.removeAt(0).close()
                    if (!waitUntil(3000) { srv.clientCount() < RemoteServer.MAX_CLIENTS }) {
                        throw IllegalStateException("vaga não foi liberada depois que um cliente saiu")
                    }
                    val again = connect(port, pin)
                    cs.add(again)
                    again.send(hello())
                    expectHello(again)
                    "4 clientes atendidos, o 5º recusado; depois de um sair, um novo entrou (recusados: ${srv.rejectedCount()})"
                } finally {
                    for (c in cs) c.close()
                }
            }

            // 6) cliente de IP não permitido
            check(checks, "Cliente de IP não permitido é recusado") {
                if (!srvNet.start()) throw IllegalStateException("servidor de teste não ligou: " + srvNet.lastError)
                var answered = false
                try {
                    val c = connect(srvNet.boundPort, pin)
                    try {
                        c.send(hello())
                        answered = c.recv() is RemoteProtocol.Message.Hello
                    } finally {
                        c.close()
                    }
                } catch (e: IOException) {
                } catch (e: RemoteProtocol.ProtocolException) {
                }
                if (answered) throw IllegalStateException("cliente de IP fora da regra foi atendido")
                if (!waitUntil(2000) { srvNet.rejectedCount() >= 1 }) throw IllegalStateException("o servidor não registrou a recusa")
                "conexão de 127.0.0.1 (fora da regra no servidor de teste sem loopback) fechada antes do hello; recusas: ${srvNet.rejectedCount()}"
            }

            // 7) ping do servidor e timeout de inatividade
            check(checks, "Ping do servidor mantém a conexão; silêncio é desconectado") {
                if (!srvIdle.start()) throw IllegalStateException("servidor de teste não ligou: " + srvIdle.lastError)
                val c = connect(srvIdle.boundPort, pin, null, 6000)
                try {
                    c.send(hello())
                    expectHello(c)
                    var pings = 0
                    val t0 = SystemClock.elapsedRealtime()
                    while (SystemClock.elapsedRealtime() - t0 < 3200L) {
                        val m = c.recv() ?: throw IllegalStateException("servidor fechou apesar dos pongs")
                        if (m == RemoteProtocol.Message.Ping) {
                            pings++
                            c.send(RemoteProtocol.Message.Pong)
                        }
                    }
                    if (pings < 2) throw IllegalStateException("poucos pings recebidos ($pings)")
                    // agora fica em silêncio: não responde mais
                    expectClosed(c)
                    "$pings pings recebidos e respondidos por mais que o limite de inatividade (1,5 s no teste); sem resposta, foi desconectado"
                } finally {
                    c.close()
                }
            }

            // 8) desligamento
            check(checks, "Desligamento fecha sockets e threads") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    srv.stop()
                    if (srv.state != RemoteServer.State.STOPPED) throw IllegalStateException("estado ${srv.state}")
                    expectClosed(c)
                } finally {
                    c.close()
                }
                var refused = false
                try {
                    connect(port, pin, null, 1500).close()
                } catch (e: IOException) {
                    refused = true
                }
                if (!refused) throw IllegalStateException("a porta continua aceitando conexões")
                srvNet.stop()
                srvIdle.stop()
                if (!waitUntil(2000) { testThreads().isEmpty() }) {
                    throw IllegalStateException("threads ainda vivas: " + testThreads().joinToString(", "))
                }
                if (srv.liveThreads() != 0) throw IllegalStateException("${srv.liveThreads()} thread(s) do servidor ainda vivas")
                "cliente conectado foi desconectado, a porta fechou e nenhuma thread \"WinRemote-test\" sobrou"
            }
        } finally {
            try {
                srv.stop()
            } catch (e: Throwable) {
            }
            try {
                srvNet.stop()
            } catch (e: Throwable) {
            }
            try {
                srvIdle.stop()
            } catch (e: Throwable) {
            }
        }
        return checks
    }
}
