package org.json;
import java.util.*;
/** Mini org.json só para o harness JVM: objetos planos com string/número/booleano/null. */
public class JSONObject {
  private final LinkedHashMap<String,Object> m = new LinkedHashMap<>();
  public JSONObject() {}
  public JSONObject(String s) throws JSONException {
    int[] p = {0}; ws(s,p);
    if (p[0]>=s.length() || s.charAt(p[0])!='{') throw new JSONException("not object");
    p[0]++; ws(s,p);
    if (s.charAt(p[0])=='}') { p[0]++; } else {
      while (true) {
        ws(s,p); String k = str(s,p); ws(s,p);
        if (s.charAt(p[0])!=':') throw new JSONException("colon"); p[0]++; ws(s,p);
        m.put(k, val(s,p)); ws(s,p);
        char c = s.charAt(p[0]++);
        if (c==',') continue; if (c=='}') break; throw new JSONException("bad");
      }
    }
    ws(s,p); if (p[0]!=s.length()) throw new JSONException("trailing");
  }
  private static void ws(String s,int[] p){ while(p[0]<s.length() && Character.isWhitespace(s.charAt(p[0]))) p[0]++; }
  private static String str(String s,int[] p) throws JSONException {
    if (s.charAt(p[0])!='"') throw new JSONException("string"); p[0]++;
    StringBuilder b=new StringBuilder();
    while(true){ char c=s.charAt(p[0]++);
      if(c=='"') break;
      if(c=='\\'){ char e=s.charAt(p[0]++); switch(e){case 'n':b.append('\n');break;case 't':b.append('\t');break;case 'r':b.append('\r');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'u':b.append((char)Integer.parseInt(s.substring(p[0],p[0]+4),16));p[0]+=4;break;default:b.append(e);} }
      else b.append(c); }
    return b.toString();
  }
  private static Object val(String s,int[] p) throws JSONException {
    char c=s.charAt(p[0]);
    if(c=='"') return str(s,p);
    if(s.startsWith("true",p[0])){p[0]+=4;return Boolean.TRUE;}
    if(s.startsWith("false",p[0])){p[0]+=5;return Boolean.FALSE;}
    if(s.startsWith("null",p[0])){p[0]+=4;return NULL;}
    int st=p[0]; while(p[0]<s.length() && "+-0123456789.eE".indexOf(s.charAt(p[0]))>=0) p[0]++;
    if(st==p[0]) throw new JSONException("value");
    String n=s.substring(st,p[0]);
    try { return n.contains(".")||n.contains("e")||n.contains("E") ? (Object)Double.valueOf(n) : (Object)Long.valueOf(n);} catch(NumberFormatException e){ throw new JSONException("num"); }
  }
  public static final Object NULL = new Object(){ public String toString(){return "null";} };
  public JSONObject put(String k,Object v){ m.put(k,v); return this; }
  public JSONObject put(String k,int v){ m.put(k,(long)v); return this; }
  public JSONObject put(String k,long v){ m.put(k,v); return this; }
  public JSONObject put(String k,boolean v){ m.put(k,v); return this; }
  public JSONObject put(String k,double v){ m.put(k,v); return this; }
  public boolean has(String k){ return m.containsKey(k); }
  public Object opt(String k){ Object o=m.get(k); return o; }
  public String optString(String k){ Object o=m.get(k); return o==null?"":o.toString(); }
  public String optString(String k,String d){ Object o=m.get(k); return o==null?d:o.toString(); }
  @Override public String toString(){
    StringBuilder b=new StringBuilder("{"); boolean f=true;
    for(Map.Entry<String,Object> e:m.entrySet()){ if(!f)b.append(','); f=false; b.append(q(e.getKey())).append(':'); Object v=e.getValue();
      if(v instanceof String) b.append(q((String)v)); else b.append(v); }
    return b.append('}').toString();
  }
  private static String q(String s){ StringBuilder b=new StringBuilder("\""); for(char c: s.toCharArray()){ switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default: if(c<0x20) b.append(String.format("\\u%04x",(int)c)); else b.append(c);} } return b.append('"').toString(); }
}
