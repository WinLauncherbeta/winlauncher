package android.os;
import java.util.concurrent.*;
import java.util.*;
/** Handler de harness: uma thread "main" única; post/postDelayed/removeCallbacks como no Android. */
public class Handler {
  private static final ScheduledThreadPoolExecutor EX = new ScheduledThreadPoolExecutor(1, r -> { Thread t=new Thread(r,"harness-main"); t.setDaemon(true); return t; });
  static { EX.setRemoveOnCancelPolicy(true); }
  private final Map<Runnable,Set<ScheduledFuture<?>>> pending = new ConcurrentHashMap<>();
  public Handler(Looper l) {}
  public boolean post(Runnable r){ return postDelayed(r,0); }
  public boolean postDelayed(Runnable r,long ms){
    ScheduledFuture<?>[] f=new ScheduledFuture<?>[1];
    f[0]=EX.schedule(() -> { Set<ScheduledFuture<?>> s=pending.get(r); if(s!=null) s.remove(f[0]); try{ r.run(); }catch(Throwable t){ t.printStackTrace(); } }, ms, TimeUnit.MILLISECONDS);
    pending.computeIfAbsent(r,k->ConcurrentHashMap.newKeySet()).add(f[0]);
    return true;
  }
  public void removeCallbacks(Runnable r){ Set<ScheduledFuture<?>> s=pending.remove(r); if(s!=null) for(ScheduledFuture<?> f:s) f.cancel(false); }
}
