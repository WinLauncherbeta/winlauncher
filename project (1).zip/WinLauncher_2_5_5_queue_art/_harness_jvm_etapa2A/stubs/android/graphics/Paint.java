package android.graphics;
public class Paint { private int c; public void setColor(int v){ c=v; } public int getColor(){ return c; } }
