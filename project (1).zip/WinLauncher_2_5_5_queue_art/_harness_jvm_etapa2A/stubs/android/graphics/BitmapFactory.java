package android.graphics;
public class BitmapFactory { public static Bitmap decodeByteArray(byte[] b,int o,int l){ try{ java.awt.image.BufferedImage i=javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(b,o,l)); return i==null?null:new Bitmap(i);}catch(Exception e){return null;} } }
