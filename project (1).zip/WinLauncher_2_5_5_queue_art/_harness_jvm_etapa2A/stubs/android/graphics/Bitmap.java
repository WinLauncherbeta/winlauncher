package android.graphics;
import java.awt.image.BufferedImage;
import java.io.*;
public class Bitmap {
  public enum Config { ARGB_8888, HARDWARE }
  public enum CompressFormat { JPEG, PNG }
  public BufferedImage img; private boolean rec;
  public Bitmap(BufferedImage i){ img=i; }
  public static Bitmap createBitmap(int w,int h,Config c){ return new Bitmap(new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB)); }
  public static Bitmap createScaledBitmap(Bitmap s,int w,int h,boolean f){
    BufferedImage o=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB); java.awt.Graphics2D g=o.createGraphics();
    g.drawImage(s.img.getScaledInstance(w,h,java.awt.Image.SCALE_SMOOTH),0,0,null); g.dispose(); return new Bitmap(o); }
  public Bitmap copy(Config c,boolean m){ BufferedImage o=new BufferedImage(getWidth(),getHeight(),BufferedImage.TYPE_INT_RGB); o.getGraphics().drawImage(img,0,0,null); return new Bitmap(o); }
  public int getWidth(){ return img.getWidth(); } public int getHeight(){ return img.getHeight(); }
  public Config getConfig(){ return Config.ARGB_8888; } public boolean isRecycled(){ return rec; } public void recycle(){ rec=true; }
  public boolean compress(CompressFormat f,int q,OutputStream os){ try{ javax.imageio.ImageWriter w=javax.imageio.ImageIO.getImageWritersByFormatName("jpeg").next();
      javax.imageio.ImageWriteParam p=w.getDefaultWriteParam(); p.setCompressionMode(javax.imageio.ImageWriteParam.MODE_EXPLICIT); p.setCompressionQuality(q/100f);
      javax.imageio.stream.ImageOutputStream ios=javax.imageio.ImageIO.createImageOutputStream(os); w.setOutput(ios); w.write(null,new javax.imageio.IIOImage(img,null,null),p); ios.close(); w.dispose(); return true; }catch(Exception e){ return false; } }
}
