package android.graphics;
public class Canvas { private final Bitmap b; public Canvas(Bitmap b){ this.b=b; }
  public void drawColor(int c){ java.awt.Graphics2D g=b.img.createGraphics(); g.setColor(new java.awt.Color(c)); g.fillRect(0,0,b.getWidth(),b.getHeight()); g.dispose(); }
  public void drawRect(float l,float t,float r,float bt,Paint p){ java.awt.Graphics2D g=b.img.createGraphics(); g.setColor(new java.awt.Color(p.getColor())); g.fillRect((int)l,(int)t,(int)(r-l),(int)(bt-t)); g.dispose(); } }
