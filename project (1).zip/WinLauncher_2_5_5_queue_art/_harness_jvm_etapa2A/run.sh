#!/bin/bash
# uso: run.sh  -> compila e roda os dois autotestes sobre /home/claude/work/proj
export PATH=/home/claude/work/tc/kotlinc/bin:$PATH
P=/home/claude/work/proj/app/src/main/java/com/example/winlauncher
cd /home/claude/work/harness
rm -rf out && mkdir out
javac -nowarn -d out $(find stubs -name "*.java") 2>&1 | grep -v Picked
kotlinc -nowarn -jvm-target 17 -cp out kt/RemoteAuth.kt kt/MediaSessionHub.kt kt/Main.kt kt/Main2.kt $P/RemoteProtocol.kt $P/RemoteLifecycleGate.kt $P/RemoteServer.kt $P/RemoteBridge.kt $P/RemoteBridgeTest.kt -d out 2>&1 | grep -E "error" | sed 's|.*/winlauncher/||'
CP=out:/home/claude/work/tc/kotlinc/lib/kotlin-stdlib.jar
echo "== SERVIDOR"; java -cp $CP MainKt 2>&1 | grep -v Picked | iconv -f utf-8 -t ascii//TRANSLIT | grep -E "${1:-FALHA|total}"
echo "== INTEGRACAO"; java -Djava.awt.headless=true -cp $CP Main2Kt 2>&1 | grep -v Picked | iconv -f utf-8 -t ascii//TRANSLIT | grep -E "${1:-FALHA|total}"
