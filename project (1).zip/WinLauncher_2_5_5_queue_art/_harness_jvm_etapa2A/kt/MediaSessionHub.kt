package com.example.winlauncher
import android.graphics.Bitmap
object MediaSessionHub {
    enum class Result { OK, NO_ACCESS, NO_SESSION, UNAVAILABLE, ERROR }

    /** Uma sessão de mídia ativa no aparelho. */
    class SessionInfo(
        val pkg: String,
        val label: String,
        val playing: Boolean,
        val title: String,
        /** Parece YouTube Music (pacote oficial ou nome/pacote parecido). */
        val ytLike: Boolean,
        /** É o player da própria WinLauncher. */
        val own: Boolean
    )

    /** App instalado que parece YouTube Music (mesmo sem sessão ativa). */
    class Installed(val pkg: String, val label: String)

    /** Foto imutável da sessão controlada. */
    class State(
        val hasSession: Boolean,
        /** O launcher pode ler as sessões (acesso às notificações concedido e funcionando)? */
        val access: Boolean,
        /** Pacote real e nome do app da sessão controlada ("" quando não há). */
        val pkg: String,
        val appLabel: String,
        /** Pacote escolhido manualmente ("" = modo automático). */
        val selectedPkg: String,
        /** Todas as sessões de mídia ativas agora. */
        val sessions: List<SessionInfo>,
        val playing: Boolean,
        /** PlaybackState.STATE_*; -1 quando o app não publicou estado. */
        val stateCode: Int,
        val title: String,
        val artist: String,
        val album: String,
        val art: Bitmap?,
        /** De onde veio a capa (diagnóstico). */
        val artInfo: String,
        val actions: Long,
        val canPlay: Boolean,
        val canPause: Boolean,
        val canNext: Boolean,
        val canPrev: Boolean,
        val durationMs: Long,
        val positionMs: Long,
        val speed: Float,
        val customActions: List<String>
    ) {
        val canPlayPause: Boolean get() = if (playing) canPause else canPlay
        val manual: Boolean get() = selectedPkg.isNotEmpty()
    }

    interface Listener { fun onMediaState(s: State) }
    fun start(ctx: android.content.Context) {}
    fun stop() {}
    fun addListener(l: Listener) {}
    fun removeListener(l: Listener) {}
    fun refresh() {}
    fun state(): State = throw UnsupportedOperationException()
    fun togglePlayPause(): Result = Result.OK
    fun next(): Result = Result.OK
    fun previous(): Result = Result.OK
}
