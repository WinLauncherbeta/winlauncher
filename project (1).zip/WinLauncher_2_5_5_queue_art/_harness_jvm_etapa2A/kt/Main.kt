import android.content.Context
import com.example.winlauncher.*
fun main() {
    val t0 = System.currentTimeMillis()
    val r = RemoteServerTest.selfTest(Context())
    for (c in r) println((if (c.ok) "OK   " else "FALHA") + (if (!c.essential) " (info) " else " ") + c.name + " -> " + c.detail)
    println("total ${r.size}, falhas essenciais: ${r.count { !it.ok && it.essential }}, ${(System.currentTimeMillis()-t0)/1000}s")
}
