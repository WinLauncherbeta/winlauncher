package com.example.winlauncher
import android.content.Context
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import javax.net.ssl.*
/** Stub SÓ do harness JVM (o RemoteAuth real usa Android Keystore). */
object RemoteAuth {
    class KeyReport(val algorithm: String, val fingerprint: ByteArray)
    class Check(val name: String, val ok: Boolean, val detail: String, val essential: Boolean = true)
    private val ks = KeyStore.getInstance("PKCS12").also { java.io.FileInputStream("/home/claude/work/harness/ks.p12").use { f -> it.load(f, "changeit".toCharArray()) } }
    fun init(ctx: Context) {}
    fun fingerprint(c: X509Certificate): ByteArray = MessageDigest.getInstance("SHA-256").digest(c.encoded)
    fun ensureKey(): KeyReport = KeyReport("EC P-256 (stub JVM)", fingerprint(ks.getCertificate("k") as X509Certificate))
    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    fun shortFingerprint(fp: ByteArray): String = hex(fp).take(16)
    fun buildServerSslContext(): SSLContext {
        val kmf = KeyManagerFactory.getInstance("SunX509"); kmf.init(ks, "changeit".toCharArray())
        val c = SSLContext.getInstance("TLS"); c.init(kmf.keyManagers, null, null); return c
    }

    class Paired(val id: String, val name: String, val tokenHash: String, val createdMs: Long)
    private val paired = java.util.concurrent.CopyOnWriteArrayList<Paired>()
    private val rnd = java.security.SecureRandom()
    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b)
    fun inspect(): KeyReport? = ensureKey()
    fun pairingCode(serverFp: ByteArray, clientNonce: String, serverNonce: String): String {
        val d = sha(("WLR1|pair|" + hex(serverFp) + "|" + clientNonce + "|" + serverNonce).toByteArray(Charsets.UTF_8))
        val n = ((d[0].toLong() and 0xff) shl 24) or ((d[1].toLong() and 0xff) shl 16) or ((d[2].toLong() and 0xff) shl 8) or (d[3].toLong() and 0xff)
        return String.format(java.util.Locale.ROOT, "%06d", n % 1_000_000L)
    }
    fun newNonce(): String { val b = ByteArray(RemoteProtocol.NONCE_BYTES); rnd.nextBytes(b); return RemoteProtocol.b64(b) }
    fun newToken(): String { val b = ByteArray(RemoteProtocol.TOKEN_BYTES); rnd.nextBytes(b); return RemoteProtocol.b64(b) }
    fun pairedList(): List<Paired> = ArrayList(paired)
    fun addPaired(id: String, name: String, token: String) { paired.removeAll { it.id == id }; paired.add(Paired(id, name, hex(sha(token.toByteArray())), System.currentTimeMillis())) }
    fun removePaired(id: String): Boolean = paired.removeAll { it.id == id }
    fun verifyPaired(id: String, token: String): Boolean = paired.any { it.id == id && it.tokenHash == hex(sha(token.toByteArray())) }
}
