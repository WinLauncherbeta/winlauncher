Harness JVM (fora do build do app); ver HANDOFF.
