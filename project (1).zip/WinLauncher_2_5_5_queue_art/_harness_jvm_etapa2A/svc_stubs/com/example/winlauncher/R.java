package com.example.winlauncher; public class R { public static class drawable { public static final int ic_lock=1; } }
