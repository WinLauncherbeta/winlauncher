package com.example.winlauncher; public class MainActivity {}
