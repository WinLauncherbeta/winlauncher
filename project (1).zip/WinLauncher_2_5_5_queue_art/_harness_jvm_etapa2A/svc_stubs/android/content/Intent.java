package android.content;
public class Intent { public static final int FLAG_ACTIVITY_NEW_TASK=1, FLAG_ACTIVITY_SINGLE_TOP=2;
 public Intent(Context c, Class<?> k){} public Intent setAction(String a){return this;} public String getAction(){return null;} public Intent addFlags(int f){return this;} }
