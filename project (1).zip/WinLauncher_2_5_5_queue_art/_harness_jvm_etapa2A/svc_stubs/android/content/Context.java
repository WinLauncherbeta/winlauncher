package android.content;
public class Context {
  public static final String WIFI_SERVICE="wifi"; public static final int MODE_PRIVATE=0;
  public Context getApplicationContext(){ return this; }
  public Object getSystemService(String n){ return null; }
  public <T> T getSystemService(Class<T> c){ return null; }
  public android.content.SharedPreferences getSharedPreferences(String n,int m){ return null; }
  public android.content.ComponentName startForegroundService(Intent i){ return null; }
}
