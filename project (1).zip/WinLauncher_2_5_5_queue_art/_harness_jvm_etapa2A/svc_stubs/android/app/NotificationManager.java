package android.app; public class NotificationManager { public static final int IMPORTANCE_LOW=2, IMPORTANCE_HIGH=4;
 public void createNotificationChannel(NotificationChannel c){} public void notify(int i,Notification n){} public void cancel(int i){} }
