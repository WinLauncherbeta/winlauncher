package android.app;
import android.content.Context;
public class Notification {
  public static final String CATEGORY_STATUS="status"; public static final int VISIBILITY_PRIVATE=0;
  public static class Style {}
  public static class BigTextStyle extends Style { public BigTextStyle bigText(CharSequence s){return this;} }
  public static class Action { public static class Builder { public Builder(Object icon,CharSequence t,PendingIntent p){} public Action build(){return new Action();} } }
  public static class Builder { public Builder(Context c,String ch){}
    public Builder setSmallIcon(int i){return this;} public Builder setContentTitle(CharSequence s){return this;} public Builder setContentText(CharSequence s){return this;}
    public Builder setStyle(Style s){return this;} public Builder setContentIntent(PendingIntent p){return this;} public Builder setAutoCancel(boolean b){return this;}
    public Builder setCategory(String s){return this;} public Builder setVisibility(int v){return this;} public Builder setTimeoutAfter(long l){return this;}
    public Builder setOngoing(boolean b){return this;} public Builder setOnlyAlertOnce(boolean b){return this;} public Builder addAction(Action a){return this;}
    public Notification build(){return new Notification();} }
}
