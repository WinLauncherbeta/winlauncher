import os, re, sys
from pygments.lexers import KotlinLexer
from pygments.token import Token
kt='<RAIZ_DO_PROJETO>/WinLauncherRemote/app/src/main/java/com/winlauncher/remote'
ok=True
def fail(m):
    global ok; ok=False; print('FALHA:',m)
files=sorted(f for f in os.listdir(kt) if f.endswith('.kt'))
lex=KotlinLexer()
pairs={')':'(',']':'[','}':'{'}
for f in files:
    s=open(f'{kt}/{f}',encoding='utf-8').read()
    stack=[]; errs=0; nlines=s.count('\n')+1
    line=1
    for tt,val in lex.get_tokens(s):
        if tt is Token.Error: errs+=1; fail(f'{f}:{line}: token de erro {val!r}')
        if tt in Token.Punctuation or tt in Token.Operator:
            for ch in val:
                if ch in '([{': stack.append((ch,line))
                elif ch in ')]}':
                    if not stack or stack[-1][0]!=pairs[ch]: fail(f'{f}:{line}: {ch} sem par')
                    else: stack.pop()
        line+=val.count('\n')
    if stack: fail(f'{f}: não fechados: {stack[-3:]}')
    # aspas de string ímpares por linha (heurística)
    print(f'{f}: {nlines} linhas, erros léxicos={errs}, delimitadores abertos={len(stack)}')
    # tabs / CRLF / BOM
    raw=open(f'{kt}/{f}','rb').read()
    if b'\r' in raw: print('  aviso: CRLF em',f)
    if raw.startswith(b'\xef\xbb\xbf'): print('  aviso: BOM em',f)
    pk=re.match(r'package (\S+)',s)
    if not pk or pk.group(1)!='com.winlauncher.remote': fail(f'{f}: package errado')

# declarações top-level (funções) com nº de parâmetros
decl={}
src={f:open(f'{kt}/{f}',encoding='utf-8').read() for f in files}
def split_params(p):
    out=[];d=0;cur=''
    for ch in p:
        if ch in '(<[{': d+=1
        if ch in ')>]}': d-=1
        if ch==',' and d==0: out.append(cur);cur=''
        else: cur+=ch
    if cur.strip(): out.append(cur)
    return out
for f,s in src.items():
    for m in re.finditer(r'^fun (?:(\w+)\.)?(\w+)\((.*?)\)\s*(?::\s*[^{=]+)?\s*[{=]',s,re.M|re.S):
        recv,name,params=m.groups()
        ps=split_params(params)
        req=sum(1 for p in ps if '=' not in p); tot=len(ps)
        decl.setdefault(name,[]).append((recv,req,tot,f))
print('\nFunções top-level:')
for n,v in sorted(decl.items()): print(' ',n,v)
# chamadas
def args_of(s,i):
    # s[i]=='(' ; retorna lista de args top-level e índice após ')'
    d=0;cur='';out=[];j=i
    instr=False
    while j<len(s):
        ch=s[j]
        if ch=='"' and s[j-1]!='\\': instr=not instr
        if not instr:
            if ch in '([{<' and not (ch=='<' ): d+=1
            elif ch in ')]}':
                d-=1
                if d==0:
                    if cur.strip(): out.append(cur)
                    return out,j+1
            if ch==',' and d==1: out.append(cur);cur='';j+=1;continue
        if j>i: cur+=ch
        j+=1
    return out,j
print('\nConferência de chamadas:')
for f,s in src.items():
    for name,decls in decl.items():
        for m in re.finditer(r'(?<![\w.])(?:\w+\.)?'+name+r'\(',s):
            # ignora a própria declaração
            ls=s.rfind('\n',0,m.start())+1
            if s[ls:m.start()].lstrip().startswith('fun '): continue
            if re.search(r'fun \w*\.?$',s[ls:m.end()-len(name)-1]): continue
            a,end=args_of(s,m.end()-1)
            n=len(a)
            # lambda final
            trail = s[end:end+2].lstrip().startswith('{') or re.match(r'\s*\{',s[end:end+3] or '')
            n_eff=n+(1 if trail else 0)
            okc=any(req<=n_eff<=tot for (_,req,tot,_) in decls)
            line=s.count('\n',0,m.start())+1
            if not okc: fail(f'{f}:{line}: {name}() com {n_eff} args; declarações {[(r,q,t) for r,q,t,_ in decls]}')
print('RESULTADO','OK' if ok else 'COM FALHAS')
