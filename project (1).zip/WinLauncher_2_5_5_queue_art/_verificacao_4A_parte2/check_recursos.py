import os, re, sys
import xml.etree.ElementTree as ET
base='<RAIZ_DO_PROJETO>/WinLauncherRemote/app/src/main'
res=base+'/res'; kt=base+'/java/com/winlauncher/remote'
ok=True
def fail(m):
    global ok; ok=False; print('FALHA:',m)

# 1. XML bem formado
xmls=[]
for d,_,fs in os.walk(base):
    for f in fs:
        if f.endswith('.xml'):
            p=os.path.join(d,f); xmls.append(p)
            try: ET.parse(p)
            except Exception as e: fail(f'{p}: {e}')
print('XMLs analisados:',len(xmls))

# 2. pathData: gramática SVG
cmds=set('MmLlHhVvCcSsQqTtAaZz')
nargs={'M':2,'L':2,'H':1,'V':1,'C':6,'S':4,'Q':4,'T':2,'A':7,'Z':0}
tok=re.compile(r'([MmLlHhVvCcSsQqTtAaZz])|(-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)')
ns='{http://schemas.android.com/apk/res/android}'
vec=0
for f in sorted(os.listdir(res+'/drawable')):
    r=ET.parse(res+'/drawable/'+f).getroot()
    if r.tag!='vector': continue
    vec+=1
    for k in ('width','height','viewportWidth','viewportHeight'):
        if ns+k not in r.attrib: fail(f'{f}: falta {k}')
    for p in r.iter('path'):
        d=p.attrib.get(ns+'pathData','')
        # texto sem tokens reconhecíveis?
        rest=tok.sub('',d).replace(',','').replace(' ','')
        if rest: fail(f'{f}: caracteres inválidos em pathData: {rest!r}')
        items=tok.findall(d)
        if not items or items[0][0] not in 'Mm': fail(f'{f}: não começa com M')
        i=0; cur=None; nums=[]
        def flush():
            global cur,nums
            if cur is None: return
            n=nargs[cur.upper()]
            if n==0:
                if nums: fail(f'{f}: Z com números')
            elif len(nums)==0 or len(nums)%n!=0:
                fail(f'{f}: comando {cur} com {len(nums)} números (múltiplo de {n} esperado)')
        for c,num in items:
            if c:
                flush(); cur=c; nums=[]
            else: nums.append(num)
        flush()
print('vetores analisados:',vec)

# 3. referências R.drawable / mipmap / color / string / style
drawables={f[:-4] for f in os.listdir(res+'/drawable')}
mipmaps={f[:-4] for f in os.listdir(res+'/mipmap-anydpi-v26')}
colors=set(); strings=set(); styles=set()
for f in os.listdir(res+'/values'):
    r=ET.parse(res+'/values/'+f).getroot()
    for e in r:
        {'color':colors,'string':strings,'style':styles}.get(e.tag,set()).add(e.attrib['name'].replace('.','_'))
used=set()
for f in os.listdir(kt):
    s=open(kt+'/'+f,encoding='utf-8').read()
    for m in re.findall(r'R\.drawable\.(\w+)',s):
        used.add(m)
        if m not in drawables: fail(f'{f}: R.drawable.{m} inexistente')
print('R.drawable usados no Kotlin:',sorted(used))
print('ícones (sem launcher/logo):',len([d for d in drawables if d.startswith('ic_') and d not in('ic_launcher_foreground','ic_logo')]))
# refs dentro de XML
allref=re.compile(r'@(\w+)/([\w.]+)')
for p in xmls:
    s=open(p,encoding='utf-8').read()
    for t,n in allref.findall(s):
        if t=='drawable' and n not in drawables: fail(f'{p}: @drawable/{n}')
        if t=='mipmap' and n not in mipmaps: fail(f'{p}: @mipmap/{n}')
        if t=='color' and n not in colors: fail(f'{p}: @color/{n}')
        if t=='string' and n not in strings: fail(f'{p}: @string/{n}')
        if t=='style' and n.replace('.','_') not in styles: fail(f'{p}: @style/{n}')
print('ícones definidos mas não usados ainda:',sorted(d for d in drawables if d not in used))
print('RESULTADO' ,'OK' if ok else 'COM FALHAS')
