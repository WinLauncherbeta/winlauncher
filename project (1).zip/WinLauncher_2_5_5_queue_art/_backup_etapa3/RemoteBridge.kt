package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicInteger

/**
 * Porta de acesso à música usada pelo [RemoteBridge]. Em produção é o [HubPort] (que só repassa ao [MediaSessionHub]);
 * nos autotestes é uma porta falsa, para testar o fluxo completo sem depender de um player tocando.
 * Tudo aqui é chamado na THREAD PRINCIPAL (como o próprio Hub exige).
 */
interface MediaPort {
    fun start(ctx: Context)
    fun stop()
    fun addListener(l: MediaSessionHub.Listener)
    fun removeListener(l: MediaSessionHub.Listener)
    fun refresh()
    fun state(): MediaSessionHub.State
    fun command(c: RemoteProtocol.Command): MediaSessionHub.Result
}

/** Liga o Remote ao [MediaSessionHub] de verdade. Não muda nada no Hub: só usa a API pública dele. */
object HubPort : MediaPort {
    override fun start(ctx: Context) = MediaSessionHub.start(ctx)
    override fun stop() = MediaSessionHub.stop()
    override fun addListener(l: MediaSessionHub.Listener) = MediaSessionHub.addListener(l)
    override fun removeListener(l: MediaSessionHub.Listener) = MediaSessionHub.removeListener(l)
    override fun refresh() = MediaSessionHub.refresh()
    override fun state(): MediaSessionHub.State = MediaSessionHub.state()

    /** Sem "force": se o app de música não anuncia a ação, o resultado é UNAVAILABLE (vira erro `unavailable` no protocolo). */
    override fun command(c: RemoteProtocol.Command): MediaSessionHub.Result = when (c) {
        RemoteProtocol.Command.PLAY_PAUSE -> MediaSessionHub.togglePlayPause()
        RemoteProtocol.Command.NEXT -> MediaSessionHub.next()
        RemoteProtocol.Command.PREVIOUS -> MediaSessionHub.previous()
    }
}

/**
 * Etapa 3B, Parte 2: liga o [RemoteServer] (TLS) ao [MediaSessionHub].
 *
 * O que faz:
 *  - Pareamento: janela de [pairWindowMs] (2 min) aberta por [openPairingWindow]; pair_request -> pair_challenge ->
 *    número de 6 dígitos ([RemoteAuth.pairingCode]) comparado nos dois celulares -> o usuário toca em Permitir
 *    ([approve]) DENTRO do WinLauncher -> pair_ok(token). Só um pedido pendente por vez; o pedido pendente vale
 *    [pendingMs]. A janela fecha assim que um pedido é aceito para análise.
 *  - Autenticação: auth(deviceId, token) confere o hash guardado ([RemoteAuth.verifyPaired]). 5 erros do mesmo IP em
 *    60 s bloqueiam esse IP por 60 s (rate_limited). Sem autenticar, nenhum comando é executado e nenhum estado é enviado.
 *  - Música: o ouvinte do Hub empurra o estado (state) e a capa (art, em blocos) para os clientes autenticados.
 *  - Comandos: command (play_pause, next, previous) executa no Hub (thread principal) e responde command_result.
 *
 * Ciclo de vida do Hub: [attach] faz UM par balanceado start()/stop() na contagem de usos do Hub e registra/remove só o
 * próprio ouvinte. Nunca reinicia o Hub nem chama stop() fora desse par. [attach]/[detach] são da thread principal.
 *
 * Threads: os ganchos do servidor chegam nas threads dos clientes; o Hub fala na principal; todo envio para socket sai
 * de uma fila própria por cliente, processada em threads de um pool (nunca da principal).
 */
class RemoteBridge(
    ctx: Context,
    private val server: RemoteServer,
    private val media: MediaPort = HubPort,
    /** Nome usado nas threads ("WinRemote-<tag>-io-N"). */
    private val tag: String = "main",
    private val pairWindowMs: Long = PAIR_WINDOW_MS,
    private val pendingMs: Long = PENDING_MS,
    private val events: Events? = null
) {

    /** Avisos para o serviço/painel. [onBridgeChanged], [onPairingRequest] e [onPairingResolved] chegam na thread principal. */
    interface Events {
        fun onBridgeChanged()
        fun onPairingRequest(deviceName: String)
        fun onPairingResolved()
        /** Qualquer thread. */
        fun onLog(line: String)
    }

    class PendingInfo(val deviceName: String, val address: String, val code: String, val leftMs: Long)

    class Info(
        val windowOpen: Boolean,
        val windowLeftMs: Long,
        val pending: PendingInfo?,
        val paired: List<RemoteAuth.Paired>,
        /** Ids dos aparelhos pareados que estão conectados e autenticados agora. */
        val connectedIds: Set<String>
    )

    companion object {
        const val PAIR_WINDOW_MS = 120_000L
        const val PENDING_MS = 120_000L
        const val MAX_FAILS = 5
        const val FAIL_WINDOW_MS = 60_000L
        const val LOCK_MS = 60_000L
        private const val MAX_QUEUE = 64
        private const val MAX_CMDS_PER_SEC = 10
        private const val TAG = "WinRemoteBridge"
    }

    private class Pending(
        val client: RemoteServer.Client,
        val deviceId: String,
        val deviceName: String,
        val address: String,
        val code: String,
        val serverNonce: String,
        val createdMs: Long
    )

    private class Offer(val pending: Pending?, val error: RemoteProtocol.Message.ErrorMsg?)

    private class Fail(var count: Int, var firstMs: Long, var lockedUntil: Long)

    private class ArtData(val id: String, val chunks: List<RemoteProtocol.Message.ArtChunk>)

    private val app: Context = ctx.applicationContext
    private val ui = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val outs = ConcurrentHashMap<Int, Out>()
    private val ioCount = AtomicInteger(0)
    private val pool: ExecutorService = Executors.newCachedThreadPool(ThreadFactory { r ->
        val t = Thread(r, "WinRemote-$tag-io-" + ioCount.incrementAndGet())
        t.isDaemon = true
        t
    })

    @Volatile
    private var attached = false

    /** Uso único: depois do [detach] o pool de threads está encerrado, então este objeto não liga de novo (crie outro). */
    @Volatile
    private var finished = false

    // thread principal
    private var started = false
    private var lastArtKey = ""
    private var art: ArtData? = null
    private var lastState: RemoteProtocol.Message.StateMsg? = null

    // protegidos por [lock]
    private var windowEnd = 0L
    private var pending: Pending? = null
    private var serverFp: ByteArray? = null
    private val fails = HashMap<String, Fail>()

    private val windowTimer = Runnable { onWindowTimer() }
    private val pendingTimer = Runnable { onPendingTimer() }

    private val hubListener = object : MediaSessionHub.Listener {
        override fun onMediaState(s: MediaSessionHub.State) {
            onHubState(s)
        }
    }

    private fun now(): Long = SystemClock.elapsedRealtime()

    private fun log(s: String) {
        Log.i(TAG, s)
        try {
            events?.onLog(s)
        } catch (e: Throwable) {
        }
    }

    private fun changed() {
        ui.post {
            try {
                events?.onBridgeChanged()
            } catch (e: Throwable) {
            }
        }
    }

    private fun resolved() {
        ui.post {
            try {
                events?.onPairingResolved()
            } catch (e: Throwable) {
            }
        }
    }

    private fun exec(r: Runnable) {
        try {
            pool.execute(r)
        } catch (e: Exception) {
            // pool já desligado (detach)
        }
    }

    // ------------------------------------------------------------------ ciclo de vida (thread principal)

    /** Liga a integração: registra os ganchos do servidor e o ouvinte do Hub e faz o start() do Hub (um só). */
    fun attach() {
        if (attached || finished) return
        attached = true
        server.onMessage = { c, m -> onMessage(c, m) }
        server.onClientClosed = { c -> onClientClosed(c) }
        media.addListener(hubListener)
        try {
            media.start(app)
            started = true
        } catch (e: Throwable) {
            log("não foi possível ligar o MediaSessionHub: " + e.javaClass.simpleName)
        }
    }

    /** Desliga a integração: remove ganchos e ouvinte, solta o Hub (stop() só se o start() foi feito aqui) e encerra o pool. */
    fun detach() {
        if (!attached) return
        attached = false
        finished = true
        server.onMessage = null
        server.onClientClosed = null
        ui.removeCallbacks(windowTimer)
        ui.removeCallbacks(pendingTimer)
        media.removeListener(hubListener)
        if (started) {
            started = false
            try {
                media.stop()
            } catch (e: Throwable) {
            }
        }
        val hadPending = synchronized(lock) {
            val had = pending != null
            pending = null
            windowEnd = 0L
            fails.clear()
            had
        }
        outs.clear()
        art = null
        lastState = null
        lastArtKey = ""
        try {
            pool.shutdownNow()
        } catch (e: Throwable) {
        }
        if (hadPending) resolved()
        changed()
    }

    // ------------------------------------------------------------------ mensagens dos clientes (threads dos clientes)

    private fun onMessage(c: RemoteServer.Client, m: RemoteProtocol.Message): Boolean = when (m) {
        is RemoteProtocol.Message.PairRequest -> {
            handlePair(c, m)
            true
        }
        is RemoteProtocol.Message.Auth -> {
            handleAuth(c, m)
            true
        }
        is RemoteProtocol.Message.CommandMsg -> {
            handleCommand(c, m)
            true
        }
        else -> false
    }

    private fun onClientClosed(c: RemoteServer.Client) {
        outs.remove(c.id)
        val dropped = synchronized(lock) {
            val p = pending
            if (p != null && p.client === c) {
                pending = null
                true
            } else {
                false
            }
        }
        if (dropped) {
            ui.removeCallbacks(pendingTimer)
            resolved()
            changed()
        } else if (c.authenticated) {
            changed()
        }
    }

    /** Resposta direta na thread do cliente (erros). Falha de envio é ignorada: o servidor já trata a conexão caída. */
    private fun reply(c: RemoteServer.Client, m: RemoteProtocol.Message) {
        try {
            c.send(m)
        } catch (e: Exception) {
        }
    }

    private fun cleanName(s: String): String {
        val t = s.filter { !it.isISOControl() }.trim()
        return if (t.isEmpty()) "Aparelho" else RemoteProtocol.clip(t, RemoteProtocol.MAX_NAME)
    }

    // ------------------------------------------------------------------ pareamento

    /** Abre a janela de pareamento por [pairWindowMs]. Só funciona com a integração ligada. */
    fun openPairingWindow(): Boolean {
        if (!attached) return false
        synchronized(lock) { windowEnd = now() + pairWindowMs }
        ui.removeCallbacks(windowTimer)
        ui.postDelayed(windowTimer, pairWindowMs + 50L)
        log("janela de pareamento aberta")
        changed()
        return true
    }

    fun closePairingWindow() {
        synchronized(lock) { windowEnd = 0L }
        ui.removeCallbacks(windowTimer)
        changed()
    }

    private fun onWindowTimer() {
        synchronized(lock) {
            if (windowEnd != 0L && now() >= windowEnd) windowEnd = 0L
        }
        changed()
    }

    private fun serverFingerprint(): ByteArray? {
        val cached = synchronized(lock) { serverFp }
        if (cached != null) return cached
        val fp = try {
            RemoteAuth.inspect()?.fingerprint
        } catch (e: Throwable) {
            null
        }
        if (fp != null) synchronized(lock) { serverFp = fp }
        return fp
    }

    private fun handlePair(c: RemoteServer.Client, m: RemoteProtocol.Message.PairRequest) {
        if (m.deviceId != c.deviceId) {
            reply(c, RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.BAD_REQUEST, "deviceId diferente do hello", null))
            return
        }
        val fp = serverFingerprint()
        if (fp == null) {
            reply(c, RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.INTERNAL, "certificado do servidor indisponível", null))
            return
        }
        val offer = synchronized(lock) {
            if (pending != null) {
                Offer(
                    null,
                    RemoteProtocol.Message.ErrorMsg(
                        RemoteProtocol.ErrorCode.PAIRING_BUSY, "já existe um pareamento aguardando aprovação", null
                    )
                )
            } else if (!(windowEnd != 0L && now() < windowEnd)) {
                Offer(
                    null,
                    RemoteProtocol.Message.ErrorMsg(
                        RemoteProtocol.ErrorCode.PAIRING_DENIED, "o pareamento não está aberto no WinLauncher", null
                    )
                )
            } else {
                val serverNonce = RemoteAuth.newNonce()
                val code = RemoteAuth.pairingCode(fp, m.clientNonce, serverNonce)
                val np = Pending(c, m.deviceId, cleanName(m.deviceName), c.address, code, serverNonce, now())
                pending = np
                windowEnd = 0L
                Offer(np, null)
            }
        }
        val err = offer.error
        if (err != null) {
            reply(c, err)
            return
        }
        val np = offer.pending ?: return
        ui.removeCallbacks(windowTimer)
        ui.removeCallbacks(pendingTimer)
        ui.postDelayed(pendingTimer, pendingMs)
        try {
            c.send(RemoteProtocol.Message.PairChallenge(np.serverNonce, server.displayName))
        } catch (e: Exception) {
            synchronized(lock) { if (pending === np) pending = null }
            ui.removeCallbacks(pendingTimer)
            resolved()
            changed()
            return
        }
        log("pedido de pareamento de \"${RemoteProtocol.clip(np.deviceName, 32)}\" (${np.address})")
        ui.post {
            try {
                events?.onPairingRequest(np.deviceName)
            } catch (e: Throwable) {
            }
        }
        changed()
    }

    private fun onPendingTimer() {
        val p = synchronized(lock) {
            val x = pending
            pending = null
            x
        } ?: return
        log("pedido de pareamento expirou")
        outOf(p.client).post(
            RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.PAIRING_DENIED, "tempo para aprovar o pareamento esgotou", null)
        )
        resolved()
        changed()
    }

    /** O usuário tocou em "Permitir" no WinLauncher. Devolve false se não há pedido pendente. Qualquer thread. */
    fun approve(): Boolean {
        val p = synchronized(lock) {
            val x = pending
            pending = null
            x
        } ?: return false
        ui.removeCallbacks(pendingTimer)
        resolved()
        exec(Runnable {
            val token = RemoteAuth.newToken()
            try {
                RemoteAuth.addPaired(p.deviceId, p.deviceName, token)
                p.client.send(RemoteProtocol.Message.PairOk(token, server.displayName))
                log("pareado: \"${RemoteProtocol.clip(p.deviceName, 32)}\"")
                onAuthenticated(p.client)
            } catch (e: Throwable) {
                try {
                    RemoteAuth.removePaired(p.deviceId)
                } catch (x: Throwable) {
                }
                log("pareamento não concluído: " + e.javaClass.simpleName)
                changed()
            }
        })
        changed()
        return true
    }

    /** O usuário tocou em "Negar". Devolve false se não há pedido pendente. Qualquer thread. */
    fun deny(): Boolean {
        val p = synchronized(lock) {
            val x = pending
            pending = null
            x
        } ?: return false
        ui.removeCallbacks(pendingTimer)
        log("pareamento negado")
        outOf(p.client).post(
            RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.PAIRING_DENIED, "pareamento negado no WinLauncher", null)
        )
        resolved()
        changed()
        return true
    }

    /** Remove o pareamento e derruba as conexões desse aparelho. Devolve true se havia pareamento. Qualquer thread. */
    fun revoke(deviceId: String): Boolean {
        val removed = RemoteAuth.removePaired(deviceId)
        for (c in server.clientsSnapshot()) {
            if (c.deviceId == deviceId) {
                c.authenticated = false
                c.forceClose()
            }
        }
        log("aparelho removido")
        changed()
        return removed
    }

    /** Foto para o painel. Qualquer thread. */
    fun info(): Info {
        val t = now()
        var open = false
        var left = 0L
        var pi: PendingInfo? = null
        synchronized(lock) {
            if (windowEnd != 0L && t < windowEnd) {
                open = true
                left = windowEnd - t
            }
            val p = pending
            if (p != null) {
                pi = PendingInfo(p.deviceName, p.address, p.code, (p.createdMs + pendingMs - t).coerceAtLeast(0L))
            }
        }
        val paired = try {
            RemoteAuth.pairedList()
        } catch (e: Throwable) {
            emptyList<RemoteAuth.Paired>()
        }
        val ids = HashSet<String>()
        for (c in server.clientsSnapshot()) if (c.authenticated) ids.add(c.deviceId)
        return Info(open, left, pi, paired, ids)
    }

    // ------------------------------------------------------------------ autenticação

    private fun lockedLeftMs(ip: String): Long = synchronized(lock) {
        val f = fails[ip]
        if (f == null) {
            0L
        } else {
            val left = f.lockedUntil - now()
            if (left > 0L) left else 0L
        }
    }

    /** Registra uma falha. Devolve true se o IP acabou de ser bloqueado. */
    private fun recordFailure(ip: String): Boolean = synchronized(lock) {
        val t = now()
        var f: Fail = fails[ip] ?: Fail(0, t, 0L)
        if (t - f.firstMs > FAIL_WINDOW_MS) f = Fail(0, t, 0L)
        fails[ip] = f
        f.count++
        if (fails.size > 64) {
            fails.entries.removeAll { it.value.lockedUntil < t && t - it.value.firstMs > FAIL_WINDOW_MS }
        }
        if (f.count >= MAX_FAILS) {
            f.lockedUntil = t + LOCK_MS
            f.count = 0
            f.firstMs = t
            true
        } else {
            false
        }
    }

    private fun handleAuth(c: RemoteServer.Client, m: RemoteProtocol.Message.Auth) {
        val ip = c.address
        val wait = lockedLeftMs(ip)
        if (wait > 0L) {
            reply(
                c,
                RemoteProtocol.Message.ErrorMsg(
                    RemoteProtocol.ErrorCode.RATE_LIMITED, "muitas tentativas; aguarde ${(wait + 999L) / 1000L} s", null
                )
            )
            return
        }
        val ok = m.deviceId == c.deviceId && RemoteAuth.verifyPaired(m.deviceId, m.token)
        if (!ok) {
            val nowLocked = recordFailure(ip)
            if (nowLocked) {
                log("muitas tentativas de autenticação erradas; IP bloqueado por ${LOCK_MS / 1000L} s")
                reply(
                    c,
                    RemoteProtocol.Message.ErrorMsg(
                        RemoteProtocol.ErrorCode.RATE_LIMITED, "muitas tentativas; aguarde ${LOCK_MS / 1000L} s", null
                    )
                )
            } else {
                reply(c, RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.NOT_PAIRED, "credenciais inválidas", null))
            }
            return
        }
        synchronized(lock) { fails.remove(ip) }
        try {
            c.send(RemoteProtocol.Message.AuthOk(server.displayName, RemoteProtocol.VERSION))
        } catch (e: Exception) {
            return
        }
        onAuthenticated(c)
    }

    private fun onAuthenticated(c: RemoteServer.Client) {
        c.authenticated = true
        log("cliente #${c.id} autenticado")
        ui.post {
            if (attached) {
                try {
                    media.refresh()
                } catch (e: Throwable) {
                }
                sendFull(c)
            }
        }
        changed()
    }

    // ------------------------------------------------------------------ comandos

    private fun handleCommand(c: RemoteServer.Client, m: RemoteProtocol.Message.CommandMsg) {
        if (!c.authenticated) {
            reply(c, RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.NOT_PAIRED, "aparelho não autenticado", m.id))
            return
        }
        val o = outOf(c)
        if (!o.allowCommand()) {
            reply(c, RemoteProtocol.Message.ErrorMsg(RemoteProtocol.ErrorCode.RATE_LIMITED, "comandos demais; vá mais devagar", m.id))
            return
        }
        ui.post {
            val r = if (attached) {
                try {
                    media.command(m.command)
                } catch (e: Throwable) {
                    MediaSessionHub.Result.ERROR
                }
            } else {
                MediaSessionHub.Result.UNAVAILABLE
            }
            val err = RemoteProtocol.errorFor(r)
            o.post(RemoteProtocol.Message.CommandResult(m.id, err == null, err))
        }
    }

    // ------------------------------------------------------------------ estado musical e capa (thread principal)

    private fun onHubState(s: MediaSessionHub.State) {
        if (!attached) return
        val bmp = s.art
        val key = if (bmp == null) "" else s.pkg + "|" + s.title + "|" + s.artist + "|" + s.album + "|" + bmp.width + "x" + bmp.height
        if (key != lastArtKey) {
            lastArtKey = key
            art = null
            if (bmp != null) startArtJob(bmp, key)
        }
        val st = RemoteProtocol.stateOf(s).copy(artId = art?.id ?: "")
        lastState = st
        for (o in outs.values) {
            if (o.client.authenticated) o.post(st, true)
        }
    }

    /** Cliente recém-autenticado: capa já pronta (se houver) e depois o estado atual. */
    private fun sendFull(c: RemoteServer.Client) {
        val o = outOf(c)
        val a = art
        val base = lastState ?: RemoteProtocol.stateOf(media.state())
        if (a != null) {
            for (ch in a.chunks) o.post(ch)
        }
        o.post(base.copy(artId = a?.id ?: ""), true)
    }

    /**
     * Cópia própria da capa, de no máximo 320 px, feita na THREAD PRINCIPAL (o Hub pode reciclar o bitmap dele depois).
     * null se o bitmap já está inutilizável ou a cópia falhar.
     */
    private fun snapshotArt(src: Bitmap): Bitmap? {
        return try {
            if (src.isRecycled) return null
            val w0 = src.width
            val h0 = src.height
            if (w0 <= 0 || h0 <= 0) return null
            val scale = minOf(1f, 320f / maxOf(w0, h0).toFloat())
            val w = maxOf(1, Math.round(w0 * scale))
            val h = maxOf(1, Math.round(h0 * scale))
            val soft: Bitmap? = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else null
            val base: Bitmap = soft ?: src
            val out = Bitmap.createScaledBitmap(base, w, h, true)
            // createScaledBitmap devolve o próprio bitmap quando o tamanho não muda: faz cópia para não depender do Hub
            val own = if (out === src) src.copy(Bitmap.Config.ARGB_8888, false) else out
            if (soft != null && soft !== own) soft.recycle()
            own
        } catch (e: Throwable) {
            null
        }
    }

    private fun startArtJob(bmp: Bitmap, key: String) {
        val snap = snapshotArt(bmp)
        if (snap == null) {
            log("a capa não pôde ser copiada (bitmap indisponível)")
            return
        }
        exec(Runnable {
            val bytes = try {
                encodeJpeg(snap)
            } catch (e: Throwable) {
                null
            } finally {
                try {
                    snap.recycle()
                } catch (e: Throwable) {
                }
            }
            if (bytes == null) {
                log("a capa não pôde ser preparada (formato ou tamanho)")
                return@Runnable
            }
            val chunks = try {
                RemoteProtocol.artChunks(bytes)
            } catch (e: Throwable) {
                return@Runnable
            }
            val data = ArtData(chunks[0].artId, chunks)
            ui.post { onArtReady(data, key) }
        })
    }

    private fun onArtReady(a: ArtData, key: String) {
        if (!attached || key != lastArtKey) return
        art = a
        val st = lastState?.copy(artId = a.id)
        lastState = st
        for (o in outs.values) {
            if (!o.client.authenticated) continue
            for (ch in a.chunks) o.post(ch)
            if (st != null) o.post(st, true)
        }
    }

    /** Capa -> JPEG de até 320 px e [RemoteProtocol.MAX_ART_BYTES]. null se não couber ou o bitmap estiver inutilizável. */
    private fun encodeJpeg(src: Bitmap): ByteArray? {
        if (src.isRecycled) return null
        val copy: Bitmap? = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else null
        val base: Bitmap = copy ?: src
        try {
            val w0 = base.width
            val h0 = base.height
            if (w0 <= 0 || h0 <= 0) return null
            val tries = listOf(Pair(320, 82), Pair(320, 60), Pair(240, 55), Pair(160, 50))
            for ((side, quality) in tries) {
                val scale = minOf(1f, side.toFloat() / maxOf(w0, h0).toFloat())
                val w = maxOf(1, Math.round(w0 * scale))
                val h = maxOf(1, Math.round(h0 * scale))
                val scaled: Bitmap = if (w == w0 && h == h0) base else Bitmap.createScaledBitmap(base, w, h, true)
                val bos = ByteArrayOutputStream()
                val ok = scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
                if (scaled !== base) scaled.recycle()
                val n = bos.size()
                if (ok && n >= 1 && n <= RemoteProtocol.MAX_ART_BYTES) return bos.toByteArray()
            }
            return null
        } finally {
            if (copy != null) copy.recycle()
        }
    }

    // ------------------------------------------------------------------ fila de envio por cliente

    private fun outOf(c: RemoteServer.Client): Out = outs.getOrPut(c.id) { Out(c) }

    /**
     * Fila de saída de um cliente: mantém a ordem, junta estados repetidos (só o mais novo importa) e processa numa
     * thread do pool. Cliente lento que deixa a fila encher é desconectado.
     */
    private inner class Out(val client: RemoteServer.Client) {
        private val q = ArrayDeque<RemoteProtocol.Message>()
        private var draining = false
        private var cmdStart = 0L
        private var cmdCount = 0

        fun post(m: RemoteProtocol.Message, coalesce: Boolean = false) {
            var start = false
            var overflow = false
            synchronized(this) {
                if (coalesce && m is RemoteProtocol.Message.StateMsg) {
                    q.removeAll { it is RemoteProtocol.Message.StateMsg }
                }
                if (q.size >= MAX_QUEUE) {
                    overflow = true
                } else {
                    q.addLast(m)
                    if (!draining) {
                        draining = true
                        start = true
                    }
                }
            }
            if (overflow) {
                log("cliente #${client.id} lento demais; desconectado")
                client.forceClose()
                return
            }
            if (start) exec(Runnable { drain() })
        }

        private fun drain() {
            while (true) {
                val m: RemoteProtocol.Message? = synchronized(this) {
                    val x = q.removeFirstOrNull()
                    if (x == null) draining = false
                    x
                }
                if (m == null) return
                try {
                    client.send(m)
                } catch (e: Exception) {
                    synchronized(this) {
                        q.clear()
                        draining = false
                    }
                    client.forceClose()
                    return
                }
            }
        }

        fun allowCommand(): Boolean = synchronized(this) {
            val t = now()
            if (t - cmdStart >= 1000L) {
                cmdStart = t
                cmdCount = 0
            }
            cmdCount++
            cmdCount <= MAX_CMDS_PER_SEC
        }
    }
}
