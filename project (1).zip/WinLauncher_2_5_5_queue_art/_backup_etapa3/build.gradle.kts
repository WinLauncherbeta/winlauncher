plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.winlauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.winlauncher"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "2.5.0"
    }

    // Chave de debug fixa: mantém a mesma assinatura entre builds do GitHub Actions,
    // permitindo atualizar o app por cima sem perder as preferências.
    // Só é usada se o arquivo existir; caso contrário, vale a chave de debug padrão.
    val fixedDebugKeystore = file("debug.keystore")
    if (fixedDebugKeystore.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = fixedDebugKeystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Shizuku: apenas estado e autorização (opcional em tempo de execução)
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
