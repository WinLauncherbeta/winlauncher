# HANDOFF — Gerenciador de arquivos do WinLauncher (INCOMPLETO)

Projeto Android (Kotlin, só framework, sem androidx; minSdk 26, targetSdk 34). Não há SDK no ambiente onde foi escrito,
então NADA foi compilado: revise erros de compilação ao terminar.

## Pedido do usuário
Gerenciador de arquivos igual ao do Windows 11, com todas as funções funcionando, modo janela e modo "tela cheia que
mostra a barra de tarefas e o X de fechar", usando `res/drawable-nodpi/ic_files.png` como ícone, e com as MESMAS opções
dos apps nativos da launcher (Navegador = `BrowserWindow.kt` é o modelo: minimizar/maximizar/tela cheia/fechar, ícone
fixado na barra de tarefas com menu de clique direito "Abrir/Minimizar/Desafixar/Trocar ícone/Restaurar ícone/Mover/
Fechar janela", janelinha de pré-visualização ao passar o mouse, botão extra quando aberto e desafixado).
Referência visual: Explorador de Arquivos do Windows 11 escuro (título "Este PC", barra com voltar/avançar/subir/
atualizar, caminho "Início › storage › emulated › 0 › Pasta", busca, barra lateral com Downloads/Documentos/Imagens/
Música/Vídeos + "Este PC" > "Interno (C:)", Este PC mostra "Pastas (5)" e "Dispositivos e unidades" com barra de uso
"41,2 GB livres de 105,6 GB", pastas amarelas, miniaturas, agrupamento por data "Ontem/Esta semana", "Esta pasta está vazia.").

## JÁ PRONTO (dentro do projeto)
- `res/drawable-nodpi/ic_files.png` (ícone do usuário) e vetores `res/drawable/ic_fm_*.xml`
  (up, cut, copy, paste, rename, sort, newfolder, zip, share, check, details).
- `app/src/main/java/com/example/winlauncher/FileOps.kt`: `OpCtl`, `FKind` (tipos/ext/mime), `FileOps` (formatação,
  nomes únicos, count/measure, copy/move/deleteTree, zip/unzip com proteção zip-slip, ordem natural), `KindDrawable`
  (ícones desenhados em código) e `FileShareProvider` (ContentProvider somente leitura para abrir/compartilhar).
- Correções anteriores (painel FPS/MHz em PerfOverlayService/HwInfo/ShizukuBridge, menu de contexto claro/escuro).

## EM ANDAMENTO: `FileManagerWindow.kt`
Parte 1 escrita em `_wip/fm/p1_FileManagerWindow_parte1.kt.txt` (renomeie/junte em
`app/src/main/java/com/example/winlauncher/FileManagerWindow.kt`). Ela contém: imports, doc, constantes, classes
privadas (FItem, Row, Drive, Btn), todos os campos de estado e de views, API pública (show/minimize/restore/
toggleFromTaskbar/close/handleBack/onHostResume/refreshIcon/attachBelow/handleKey), animações, modos
(janela/max/tela cheia, copiados do BrowserWindow), onResized, helpers (toast, rr, lp, hideKeyboard).
A parte 1 NÃO fecha a classe (falta a `}` final) e referencia funções ainda não escritas:

Falta escrever (partes 2-4, dentro da mesma classe):
1. `build()` (layout: titleBar com ícone `act.filesIcon()` + min/max/full/close; navBar com voltar/avançar/subir/
   atualizar + caixa de caminho (crumbScroll/crumbRow clicáveis + addrEdit) + searchBox; cmdBar horizontal com Novo,
   Recortar, Copiar, Colar, Renomear, Excluir, Compartilhar, Compactar, Classificar, Exibir, ⋯; sidebar; content com
   listCol(detailsHeader + ListView) / homeScroll / msgBox; statusText; grip de redimensionar; fsBar (restaurar+fechar
   no modo tela cheia); dlgLayer para diálogos). Inicializar `layer.tag = CursorController.NOHAND`, `win.tag` idem,
   `win.setOnTouchListener{DOWN -> active = true}` e `layer.setOnTouchListener{DOWN -> active = false; false}`.
2. Navegação: `navigate(path: String?, push: Boolean = true)`, `goBack/goForward/goUp`, `reload()`, `loadDir()` (listFiles
   em `io{}`, monta FItem, erro de permissão), `applySortFilter()`, `buildRows()` (agrupa por data quando sortKey==SORT_DATE),
   `computePerRow()`, `RowAdapter` (BaseAdapter, 2 tipos: cabeçalho e linha de células), `Cell` (inner class; modos
   LARGE/MEDIUM/LIST/DETAILS; miniaturas de imagem/vídeo/APK com `thumbs` LruCache + thumbExec), `buildHome()` (Pastas +
   unidades com StatFs), `rebuildSidebar()`/destaque, `buildCrumbs()`, `startAddrEdit()/stopAddrEdit()`, `updateDetailsHeader()`,
   `updateChrome()` (título, breadcrumbs, estado dos botões, status "N itens / N selecionados").
3. Seleção: `selectedItems()`, `selectAll()`, `clearSelection()`, clique do mouse = seleciona, duplo clique = abre,
   Ctrl = alterna, Shift = intervalo, toque = abre (ou alterna se `selectMode`), toque longo = seleciona + menu,
   botão direito = menu de contexto (`act.menu.show(items, rawX, rawY)`; `MenuItem(label, icon, checked, enabled, children, action)`).
4. Operações: `copySel(cut)`, `paste(target)` (conflitos via `askConflict` bloqueando a thread com ArrayBlockingQueue;
   REPLACE/KEEP_BOTH/SKIP/CANCEL e "aplicar a todos"), `deleteSel()` (confirmação), `renameSel()`, `newFolder()`,
   `newTextFile()`, `zipSel()`, `unzip(file)`, `properties()`, `shareSel()`, `copyPath()`, `openItem(item)` (pasta → navega;
   .apk → `act.openApk(FileShareProvider.uriFor(act, f))`; zip → pergunta extrair; resto → ACTION_VIEW com
   FLAG_GRANT_READ_URI_PERMISSION), `openWith`, busca recursiva `runSearch(q)`, `runOp(title, work, after)` com diálogo de
   progresso e cancelar, diálogos `dialog(title, body, btns)`, `promptText`, `confirm`, `closeDialog`, `stopTicker`,
   permissão de acesso a todos os arquivos (`Environment.isExternalStorageManager()` → botão que abre
   `Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION`; API<30 usa `requestPermissions`).

## FALTA INTEGRAR (não feito ainda)
- `AndroidManifest.xml`: permissões `MANAGE_EXTERNAL_STORAGE` (tools:ignore="ScopedStorage"), `READ_EXTERNAL_STORAGE`,
  `WRITE_EXTERNAL_STORAGE` (maxSdkVersion 29), `android:requestLegacyExternalStorage="true"` no <application>, e
  `<provider android:name=".FileShareProvider" android:authorities="${applicationId}.files" android:exported="false"
  android:grantUriPermissions="true" />`.
- `AppCustom.kt`: `val FILES = ComponentName("com.example.winlauncher", "native.Files")`.
- `MainActivity.kt` (copiar o padrão do Navegador, procure por `browser`/`TB_BROWSER`):
  `const val TB_FILES = "__files__"`; `private lateinit var files: FileManagerWindow` criado junto de `browser`
  (`FileManagerWindow(this, root) { taskbarInsets() }`, `attachBelow(menu.layer)`, `onStateChange = { rebuildTaskbar() }`);
  `tbPresent` aceitar TB_FILES; `ensureFilesPinned()` (fixa na 1ª vez, ao lado do navegador); em `rebuildTaskbar` contar
  `filesOpen` nos slots, ramo `TB_FILES -> addFilesPinned`, e `addFilesButton` quando aberto e desafixado;
  `addFilesPinned/filesPinnedMenu/addFilesButton/entryFiles()` (PreviewEntry "Arquivos"); `fun filesIcon()` =
  `AppCustom.icon(this, AppCustom.FILES) ?: resources.getDrawable(R.drawable.ic_files, theme)`; `filesMenuItems()` (Trocar
  ícone/Restaurar ícone); `afterAppCustomized()` chamar `files.refreshIcon()`; `fun openApk(uri: Uri) { apkWindow.openWith(uri) }`;
  `onBackPressed` chamar `files.handleBack()` antes do navegador; `dispatchKeyEvent` chamar `files.handleKey(event)`;
  `onResume` chamar `files.onHostResume()`.
- Ajustar `CustomizeUi.WIDGETS`/índices se mexer em categorias (já ajustado: WIDGETS=5, themeChanged(2)).

## Dicas
- `snapView`, `CursorController.NOHAND`, `ContextMenuHost`/`MenuItem` e `PreviewEntry` já existem no projeto.
- O app é todo em português do Brasil.
- Não há como compilar aqui: confira imports, nulabilidade e referências cruzadas depois de juntar tudo.
