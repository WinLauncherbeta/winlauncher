// Projeto Gradle INDEPENDENTE do WinLauncher Remote (Etapa 4A).
// Não faz parte do build do launcher principal (que fica na raiz do repositório).
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "WinLauncherRemote"
include(":app")
