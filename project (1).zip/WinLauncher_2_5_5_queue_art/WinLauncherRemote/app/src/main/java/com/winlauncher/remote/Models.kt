package com.winlauncher.remote

enum class Connection { CONNECTED, CONNECTING, DISCONNECTED }

enum class RepeatMode { OFF, ALL, ONE }

/** [coverKind] escolhe a capa demonstrativa gerada por código (CoverArt). */
data class Track(val id: String, val title: String, val artist: String, val durationMs: Long, val coverKind: Int)

data class Playlist(val id: String, val name: String, val subtitle: String, val coverKind: Int, val trackIds: List<String>)

/** Retrato completo do que a interface mostra. A interface nunca altera isto: só chama o repositório. */
data class PlayerState(
    val connection: Connection,
    val demo: Boolean,
    val track: Track?,
    val playing: Boolean,
    val positionMs: Long,
    val shuffle: Boolean,
    val repeat: RepeatMode,
    val volume: Int,
    val queue: List<Track>,
    val queueIndex: Int,
    val recents: List<Track>
)
