package com.winlauncher.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import kotlin.random.Random

/**
 * Capas DEMONSTRATIVAS geradas por código (cenas estilizadas originais). Na integração real,
 * a capa virá do servidor e este gerador só servirá de reserva.
 */
object CoverArt {
    const val KINDS = 6
    private val cache = HashMap<String, Bitmap>()

    fun get(kind: Int, px: Int): Bitmap {
        val k = ((kind % KINDS) + KINDS) % KINDS
        return cache.getOrPut("$k@$px") { render(k, px) }
    }

    private fun c(h: String): Int = Color.parseColor(h)

    private fun vgrad(cv: Canvas, s: Float, colors: IntArray, stops: FloatArray) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, s, colors, stops, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, s, s, p)
    }

    private fun glow(cv: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(x, y, r, color, Color.argb(0, Color.red(color), Color.green(color), Color.blue(color)), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r, p)
    }

    private fun stars(cv: Canvas, s: Float, seed: Int, n: Int, maxY: Float) {
        val r = Random(seed)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until n) {
            p.color = Color.argb(120 + r.nextInt(0, 120), 255, 255, 255)
            cv.drawCircle(r.nextFloat() * s, r.nextFloat() * s * maxY, s * (0.003f + r.nextFloat() * 0.005f), p)
        }
    }

    private fun render(kind: Int, px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val s = px.toFloat()
        when (kind) {
            0 -> moonTree(cv, s)
            1 -> city(cv, s)
            2 -> skyFigure(cv, s)
            3 -> anime(cv, s)
            4 -> aurora(cv, s)
            else -> sunset(cv, s)
        }
        return bmp
    }

    // 0: lua cheia sobre uma árvore em silhueta
    private fun moonTree(cv: Canvas, s: Float) {
        vgrad(cv, s, intArrayOf(c("#071560"), c("#26299A"), c("#7A4CC8"), c("#18287A")), floatArrayOf(0f, 0.45f, 0.74f, 1f))
        stars(cv, s, 11, 46, 0.55f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // nuvens
        p.color = Color.argb(46, 150, 120, 255)
        for (i in 0 until 7) cv.drawOval(RectF(s * (0.05f + i * 0.14f), s * (0.42f + (i % 3) * 0.04f), s * (0.30f + i * 0.14f), s * (0.50f + (i % 3) * 0.04f)), p)
        // lua
        glow(cv, s * 0.27f, s * 0.20f, s * 0.22f, Color.argb(110, 190, 215, 255))
        p.color = c("#EAF2FF")
        cv.drawCircle(s * 0.27f, s * 0.20f, s * 0.085f, p)
        p.color = Color.argb(40, 120, 140, 190)
        cv.drawCircle(s * 0.25f, s * 0.19f, s * 0.018f, p)
        cv.drawCircle(s * 0.29f, s * 0.22f, s * 0.013f, p)
        // água
        val w = Paint(Paint.ANTI_ALIAS_FLAG)
        w.shader = LinearGradient(0f, s * 0.80f, 0f, s, c("#16227A"), c("#050A30"), Shader.TileMode.CLAMP)
        cv.drawRect(0f, s * 0.80f, s, s, w)
        // árvore
        val t = Paint(Paint.ANTI_ALIAS_FLAG)
        t.color = c("#050824")
        val trunk = Path()
        trunk.moveTo(s * 0.455f, s * 0.82f)
        trunk.quadTo(s * 0.49f, s * 0.66f, s * 0.47f, s * 0.48f)
        trunk.lineTo(s * 0.53f, s * 0.48f)
        trunk.quadTo(s * 0.53f, s * 0.66f, s * 0.57f, s * 0.82f)
        trunk.close()
        cv.drawPath(trunk, t)
        val r = Random(5)
        for (i in 0 until 70) {
            val a = r.nextFloat() * 6.2831855f
            val d = Math.sqrt(r.nextFloat().toDouble()).toFloat()
            val x = s * 0.5f + Math.cos(a.toDouble()).toFloat() * d * s * 0.31f
            val y = s * 0.36f + Math.sin(a.toDouble()).toFloat() * d * s * 0.21f
            cv.drawCircle(x, y, s * (0.035f + r.nextFloat() * 0.05f), t)
        }
        val br = Paint(Paint.ANTI_ALIAS_FLAG)
        br.color = c("#050824")
        br.style = Paint.Style.STROKE
        br.strokeWidth = s * 0.014f
        cv.drawLine(s * 0.5f, s * 0.56f, s * 0.30f, s * 0.44f, br)
        cv.drawLine(s * 0.5f, s * 0.56f, s * 0.72f, s * 0.43f, br)
        // reflexo
        t.alpha = 70
        cv.drawRect(s * 0.40f, s * 0.82f, s * 0.60f, s * 0.97f, t)
    }

    // 1: cidade neon à noite
    private fun city(cv: Canvas, s: Float) {
        vgrad(cv, s, intArrayOf(c("#0A0E38"), c("#3A1A7A"), c("#C2308F"), c("#1A0A40")), floatArrayOf(0f, 0.42f, 0.7f, 0.72f))
        val r = Random(21)
        val b = Paint(Paint.ANTI_ALIAS_FLAG)
        var x = 0f
        while (x < s) {
            val w = s * (0.06f + r.nextFloat() * 0.07f)
            val h = s * (0.18f + r.nextFloat() * 0.40f)
            b.color = c("#0A0C26")
            cv.drawRect(x, s * 0.72f - h, x + w, s * 0.72f, b)
            val wp = Paint(Paint.ANTI_ALIAS_FLAG)
            var yy = s * 0.72f - h + s * 0.02f
            while (yy < s * 0.70f) {
                var xx = x + w * 0.12f
                while (xx < x + w * 0.85f) {
                    if (r.nextInt(0, 3) != 0) {
                        wp.color = when (r.nextInt(0, 3)) {
                            0 -> Color.argb(210, 90, 230, 255)
                            1 -> Color.argb(210, 255, 90, 200)
                            else -> Color.argb(210, 255, 200, 90)
                        }
                        cv.drawRect(xx, yy, xx + s * 0.008f, yy + s * 0.012f, wp)
                    }
                    xx += s * 0.022f
                }
                yy += s * 0.03f
            }
            x += w + s * 0.004f
        }
        glow(cv, s * 0.5f, s * 0.5f, s * 0.35f, Color.argb(70, 80, 220, 255))
        // rua com reflexos
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.shader = LinearGradient(0f, s * 0.72f, 0f, s, c("#2A1260"), c("#07051C"), Shader.TileMode.CLAMP)
        cv.drawRect(0f, s * 0.72f, s, s, g)
        val l = Paint(Paint.ANTI_ALIAS_FLAG)
        l.style = Paint.Style.STROKE
        l.strokeWidth = s * 0.006f
        l.color = Color.argb(110, 255, 90, 200)
        for (i in 0 until 9) cv.drawLine(s * 0.5f, s * 0.72f, s * (i / 8f * 1.6f - 0.3f), s, l)
        for (i in 0 until 14) {
            val sx = r.nextFloat() * s
            l.color = if (i % 2 == 0) Color.argb(120, 80, 230, 255) else Color.argb(120, 255, 90, 200)
            l.strokeWidth = s * 0.012f
            cv.drawLine(sx, s * 0.74f, sx, s * (0.84f + r.nextFloat() * 0.14f), l)
        }
    }

    // 2: céu azul com raios e silhueta
    private fun skyFigure(cv: Canvas, s: Float) {
        vgrad(cv, s, intArrayOf(c("#06237D"), c("#1E6BFF"), c("#4CC3FF")), floatArrayOf(0f, 0.6f, 1f))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(30, 255, 255, 255)
        for (i in 0 until 12) {
            val a0 = Math.PI * (1.05 + i * 0.075)
            val a1 = a0 + 0.035
            val path = Path()
            path.moveTo(s * 0.5f, s * 0.62f)
            path.lineTo(s * 0.5f + Math.cos(a0).toFloat() * s * 1.4f, s * 0.62f + Math.sin(a0).toFloat() * s * 1.4f)
            path.lineTo(s * 0.5f + Math.cos(a1).toFloat() * s * 1.4f, s * 0.62f + Math.sin(a1).toFloat() * s * 1.4f)
            path.close()
            cv.drawPath(path, p)
        }
        glow(cv, s * 0.5f, s * 0.62f, s * 0.40f, Color.argb(150, 190, 235, 255))
        val f = Paint(Paint.ANTI_ALIAS_FLAG)
        f.color = c("#041033")
        cv.drawCircle(s * 0.60f, s * 0.77f, s * 0.062f, f)
        cv.drawOval(RectF(s * 0.46f, s * 0.82f, s * 0.76f, s * 1.12f), f)
    }

    // 3: cena roxa com figura abstrata
    private fun anime(cv: Canvas, s: Float) {
        vgrad(cv, s, intArrayOf(c("#1A0B3D"), c("#4B1F8E"), c("#9B59D6")), floatArrayOf(0f, 0.55f, 1f))
        stars(cv, s, 33, 30, 0.6f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        glow(cv, s * 0.30f, s * 0.35f, s * 0.35f, Color.argb(90, 120, 200, 255))
        p.color = c("#120726")
        cv.drawCircle(s * 0.64f, s * 0.46f, s * 0.36f, p)
        val hair = Path()
        hair.moveTo(s * 0.30f, s * 0.30f)
        hair.quadTo(s * 0.42f, s * 0.95f, s * 0.70f, s * 1.0f)
        hair.lineTo(s * 1.0f, s * 1.0f)
        hair.lineTo(s * 1.0f, s * 0.2f)
        hair.close()
        cv.drawPath(hair, p)
        p.color = c("#C99AD9")
        cv.drawOval(RectF(s * 0.46f, s * 0.30f, s * 0.78f, s * 0.74f), p)
        p.color = c("#120726")
        cv.drawOval(RectF(s * 0.44f, s * 0.22f, s * 0.84f, s * 0.46f), p)
        val e = Paint(Paint.ANTI_ALIAS_FLAG)
        e.style = Paint.Style.STROKE
        e.strokeWidth = s * 0.012f
        e.color = c("#2B1450")
        cv.drawLine(s * 0.52f, s * 0.52f, s * 0.60f, s * 0.53f, e)
        cv.drawLine(s * 0.66f, s * 0.53f, s * 0.73f, s * 0.52f, e)
        e.color = Color.argb(170, 110, 220, 255)
        e.strokeWidth = s * 0.008f
        cv.drawArc(RectF(s * 0.28f, s * 0.26f, s * 0.96f, s * 1.0f), 100f, 70f, false, e)
    }

    // 4: aurora boreal
    private fun aurora(cv: Canvas, s: Float) {
        vgrad(cv, s, intArrayOf(c("#02101C"), c("#0A3446"), c("#0B2A3A")), floatArrayOf(0f, 0.65f, 1f))
        stars(cv, s, 44, 60, 0.7f)
        for (b in 0 until 3) {
            val top = s * (0.12f + b * 0.12f)
            val path = Path()
            path.moveTo(0f, top + s * 0.2f)
            path.cubicTo(s * 0.25f, top - s * 0.12f, s * 0.5f, top + s * 0.28f, s * 0.75f, top - s * 0.05f)
            path.lineTo(s, top + s * 0.02f)
            path.lineTo(s, top + s * 0.40f)
            path.cubicTo(s * 0.7f, top + s * 0.55f, s * 0.4f, top + s * 0.22f, 0f, top + s * 0.48f)
            path.close()
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val col = if (b == 1) c("#9B6BFF") else c("#3DFFB0")
            p.shader = LinearGradient(
                0f, top - s * 0.1f, 0f, top + s * 0.5f,
                intArrayOf(Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)), Color.argb(150, Color.red(col), Color.green(col), Color.blue(col)), Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            cv.drawPath(path, p)
        }
        val m = Paint(Paint.ANTI_ALIAS_FLAG)
        m.color = c("#03090F")
        val mt = Path()
        mt.moveTo(0f, s)
        mt.lineTo(0f, s * 0.82f)
        mt.lineTo(s * 0.18f, s * 0.68f)
        mt.lineTo(s * 0.34f, s * 0.80f)
        mt.lineTo(s * 0.55f, s * 0.62f)
        mt.lineTo(s * 0.78f, s * 0.82f)
        mt.lineTo(s, s * 0.72f)
        mt.lineTo(s, s)
        mt.close()
        cv.drawPath(mt, m)
    }

    // 5: pôr do sol
    private fun sunset(cv: Canvas, s: Float) {
        vgrad(cv, s, intArrayOf(c("#2B1259"), c("#B83B7A"), c("#FF9A4D"), c("#2A1650")), floatArrayOf(0f, 0.5f, 0.7f, 0.701f))
        glow(cv, s * 0.5f, s * 0.64f, s * 0.38f, Color.argb(140, 255, 210, 120))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = c("#FFE7A8")
        cv.drawCircle(s * 0.5f, s * 0.60f, s * 0.14f, p)
        val w = Paint(Paint.ANTI_ALIAS_FLAG)
        w.shader = LinearGradient(0f, s * 0.70f, 0f, s, c("#5B2A6E"), c("#150A30"), Shader.TileMode.CLAMP)
        cv.drawRect(0f, s * 0.70f, s, s, w)
        val l = Paint(Paint.ANTI_ALIAS_FLAG)
        l.color = Color.argb(150, 255, 210, 140)
        for (i in 0 until 6) cv.drawRect(s * (0.5f - 0.12f + i * 0.01f), s * (0.73f + i * 0.04f), s * (0.5f + 0.12f - i * 0.01f), s * (0.745f + i * 0.04f), l)
    }
}

/** Capa com cantos arredondados, reflexo suave e borda de luz (aparência de vidro). */
class RoundedCoverDrawable(ctx: Context, private val bmp: Bitmap, radiusDp: Float) : Drawable() {
    private val d = ctx.resources.displayMetrics.density
    private val radius = radiusDp * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    private val rect = RectF()

    init {
        paint.shader = shader
        border.style = Paint.Style.STROKE
        border.strokeWidth = 1.2f * d
    }

    override fun onBoundsChange(b: Rect) {
        rect.set(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat())
        val mt = Matrix()
        mt.setScale(rect.width() / bmp.width, rect.height() / bmp.height)
        mt.postTranslate(rect.left, rect.top)
        shader.setLocalMatrix(mt)
        gloss.shader = LinearGradient(0f, rect.top, 0f, rect.top + rect.height() * 0.45f, Color.argb(46, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        border.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.argb(150, 255, 255, 255), Color.argb(30, 255, 255, 255), Color.argb(80, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        if (rect.isEmpty) return
        canvas.drawRoundRect(rect, radius, radius, paint)
        canvas.drawRoundRect(rect, radius, radius, gloss)
        val h = border.strokeWidth / 2f
        canvas.drawRoundRect(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h, radius, radius, border)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
