package com.winlauncher.remote

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * PROVISÓRIA (checkpoint da Parte 2): galeria dos componentes visuais (vidro, pílulas, botões, slider, capas).
 * Substituída pela interface real na Parte 3.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(px(9), px(24), px(9), px(24))
        sv.addView(col, lp(MATCH, WRAP))

        col.addView(label("WinLauncher Remote — componentes (Parte 2)", 18f, Ui.TEXT, 2), lp(WRAP, WRAP, 0f, px(9), 0, 0, px(12)))

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val pills = ArrayList<LinearLayout>()
        val names = listOf("Início" to R.drawable.ic_home, "Biblioteca" to R.drawable.ic_music, "Fila" to R.drawable.ic_queue)
        for ((i, n) in names.withIndex()) {
            val p = glassPill(n.second, n.first) {
                for ((j, q) in pills.withIndex()) applyPill(q, j == i)
            }
            pills.add(p)
            tabs.addView(p)
        }
        applyPill(pills[0], true)
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(tabs)
        col.addView(hs)

        val card = glassCard()
        card.addView(sectionHeader("Cartão de vidro", "Ver tudo", { soon("Ver tudo") }))
        val covers = LinearLayout(this)
        covers.orientation = LinearLayout.HORIZONTAL
        for (k in 0 until CoverArt.KINDS) covers.addView(coverView(k, 84, 20f), lp(px(84), px(84), 0f, 0, px(12), px(10), 0))
        val cs = HorizontalScrollView(this)
        cs.isHorizontalScrollBarEnabled = false
        cs.addView(covers)
        card.addView(cs)
        val sl = GlassSlider(this)
        sl.setValue(0.4f)
        card.addView(sl, lp(MATCH, WRAP, 0f, 0, px(14), 0, 0))
        val ctr = LinearLayout(this)
        ctr.gravity = Gravity.CENTER_VERTICAL
        ctr.addView(cell(iconButton(R.drawable.ic_shuffle, 28, 56) { soon("Aleatório") }))
        ctr.addView(cell(iconButton(R.drawable.ic_prev, 30, 56) { soon("Anterior") }))
        ctr.addView(cell(primaryButton(R.drawable.ic_pause, 72, 30) { soon("Play/Pause") }))
        ctr.addView(cell(iconButton(R.drawable.ic_next, 30, 56) { soon("Próxima") }))
        ctr.addView(cell(iconButton(R.drawable.ic_repeat, 28, 56) { soon("Repetir") }))
        card.addView(ctr, lp(MATCH, WRAP, 0f, 0, px(10), 0, 0))
        col.addView(card, lp(MATCH, WRAP, 0f, 0, px(8), 0, 0))
        setContentView(sv)
    }
}
