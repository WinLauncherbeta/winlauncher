package com.winlauncher.remote

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Barra deslizante com visual de vidro: trilho fino translúcido, preenchimento branco e "bolinha" branca.
 * Valores de 0 a 1. [onDrag] é chamado enquanto arrasta; [onDone] ao soltar.
 */
class GlassSlider(ctx: Context, private val thumbDp: Float = 14f) : View(ctx) {

    var onDrag: ((Float) -> Unit)? = null
    var onDone: ((Float) -> Unit)? = null

    private var value = 0f
    var dragging = false
        private set

    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    init {
        track.color = Color.argb(70, 255, 255, 255)
        fillP.color = Color.argb(245, 255, 255, 255)
        thumb.color = Color.WHITE
        isClickable = true
    }

    /** Define o valor por código (ignorado enquanto o usuário arrasta). */
    fun setValue(v: Float) {
        if (dragging) return
        val nv = v.coerceIn(0f, 1f)
        if (nv != value) {
            value = nv
            invalidate()
        }
    }

    fun current(): Float = value

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = px((thumbDp * 2f + 10f).toInt())
        setMeasuredDimension(resolveSize(px(200), widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val tr = pxf(thumbDp) / 2f
        val th = pxf(4f)
        val cy = height / 2f
        val left = tr
        val right = width - tr
        r.set(left, cy - th / 2f, right, cy + th / 2f)
        canvas.drawRoundRect(r, th / 2f, th / 2f, track)
        val x = left + (right - left) * value
        r.set(left, cy - th / 2f, x, cy + th / 2f)
        if (x > left) canvas.drawRoundRect(r, th / 2f, th / 2f, fillP)
        // halo suave + bolinha
        halo.color = Color.argb(28, 0, 0, 0)
        canvas.drawCircle(x, cy + pxf(1f), tr + pxf(2.5f), halo)
        halo.color = Color.argb(40, 255, 255, 255)
        canvas.drawCircle(x, cy, tr + pxf(1.5f), halo)
        canvas.drawCircle(x, cy, tr, thumb)
    }

    private fun update(ev: MotionEvent) {
        val tr = pxf(thumbDp) / 2f
        val span = (width - 2f * tr).coerceAtLeast(1f)
        value = ((ev.x - tr) / span).coerceIn(0f, 1f)
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                update(event)
                onDrag?.invoke(value)
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    update(event)
                    onDrag?.invoke(value)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    update(event)
                    dragging = false
                    onDone?.invoke(value)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    onDone?.invoke(value)
                }
            }
        }
        return true
    }
}
