package com.winlauncher.remote

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** ImageView sempre quadrada (largura = altura). */
class SquareImageView(ctx: Context) : ImageView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, w)
    }
}

/** Cartão vertical de vidro fosco, já com o espaço da sombra + [innerDp] de respiro interno. */
fun Context.glassCard(radiusDp: Float = 30f, innerDp: Int = 16): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = GlassDrawable(this, radiusDp, GlassStyle.CARD)
    val pad = px(9 + innerDp)
    c.setPadding(pad, pad, pad, pad)
    return c
}

/**
 * Botão só com ícone. Em repouso é transparente (como na referência); ao tocar, aparece um círculo de vidro.
 * [hitDp] é a área total tocável; o ícone fica centralizado.
 */
fun Context.iconButton(res: Int, iconDp: Int, hitDp: Int, tint: Int = Ui.TEXT, onClick: () -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    val sl = StateListDrawable()
    sl.addState(intArrayOf(android.R.attr.state_pressed), GlassDrawable(this, 0f, GlassStyle.BUTTON, true))
    sl.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
    v.background = sl
    val pad = px((hitDp - iconDp) / 2)
    v.setPadding(pad, pad, pad, pad)
    v.layoutParams = LinearLayout.LayoutParams(px(hitDp), px(hitDp))
    v.isClickable = true
    v.setOnClickListener { onClick() }
    return v
}

/** Botão principal (play/pause): círculo de vidro branco com brilho. [visibleDp] é o diâmetro do círculo. */
fun Context.primaryButton(res: Int, visibleDp: Int, iconDp: Int, onClick: () -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(Ui.DARK)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    v.background = GlassDrawable(this, 0f, GlassStyle.PRIMARY, true)
    val pad = px(6 + (visibleDp - iconDp) / 2)
    v.setPadding(pad, pad, pad, pad)
    v.layoutParams = LinearLayout.LayoutParams(px(visibleDp + 12), px(visibleDp + 12))
    v.isClickable = true
    v.setOnClickListener { onClick() }
    return v
}

/** Pílula de vidro com ícone + texto (abas). Use [applyPill] para alternar selecionada/normal. */
fun Context.glassPill(iconRes: Int, text: String, onClick: () -> Unit): LinearLayout {
    val p = LinearLayout(this)
    p.orientation = LinearLayout.HORIZONTAL
    p.gravity = Gravity.CENTER_VERTICAL
    p.addView(icon(iconRes, 22, Ui.TEXT))
    val t = label(text, 17f, Ui.TEXT, 1)
    p.addView(t, lp(WRAP, WRAP, 0f, px(8), 0, 0, 0))
    p.isClickable = true
    p.setOnClickListener { onClick() }
    applyPill(p, false)
    return p
}

fun applyPill(p: LinearLayout, selected: Boolean) {
    val ctx = p.context
    p.background = GlassDrawable(ctx, 26f, if (selected) GlassStyle.SELECTED else GlassStyle.BUTTON)
    // o drawable redefine o padding ao ser atribuído; ajusta de novo
    p.setPadding(ctx.px(6 + 16), ctx.px(6 + 11), ctx.px(6 + 18), ctx.px(6 + 11))
    val col = if (selected) Ui.DARK else Ui.TEXT
    (p.getChildAt(0) as ImageView).setColorFilter(col)
    (p.getChildAt(1) as TextView).setTextColor(col)
}

/** Cabeçalho de seção: título à esquerda e, opcionalmente, "ação >" à direita. */
fun Context.sectionHeader(title: String, action: String? = null, onAction: (() -> Unit)? = null, iconRes: Int? = null): LinearLayout {
    val h = LinearLayout(this)
    h.orientation = LinearLayout.HORIZONTAL
    h.gravity = Gravity.CENTER_VERTICAL
    if (iconRes != null) h.addView(icon(iconRes, 26, Ui.TEXT), lp(px(26), px(26), 0f, 0, 0, px(12), 0))
    h.addView(label(title, if (iconRes != null) 20f else 24f, Ui.TEXT, 2), lp(0, WRAP, 1f))
    if (action != null) {
        val a = LinearLayout(this)
        a.orientation = LinearLayout.HORIZONTAL
        a.gravity = Gravity.CENTER_VERTICAL
        a.addView(label(action, 17f, Ui.TEXT2, 1))
        a.addView(icon(R.drawable.ic_chevron, 22, Ui.TEXT2))
        if (onAction != null) a.tap(onAction)
        h.addView(a)
    }
    return h
}

/** Capa quadrada com cantos arredondados, pronta para uso. */
fun Context.coverView(kind: Int, sizeDp: Int, radiusDp: Float): ImageView {
    val iv = ImageView(this)
    iv.scaleType = ImageView.ScaleType.FIT_XY
    iv.setImageDrawable(RoundedCoverDrawable(this, CoverArt.get(kind, px(sizeDp)), radiusDp))
    iv.layoutParams = LinearLayout.LayoutParams(px(sizeDp), px(sizeDp))
    return iv
}

/** Linha de faixa (número opcional, miniatura, título/artista e menu "⋮"). */
fun Context.trackRow(index: Int?, t: Track, current: Boolean, onClick: () -> Unit): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, px(6), 0, px(6))
    if (index != null) {
        val n = label(index.toString(), 19f, if (current) Ui.ACCENT else Ui.TEXT, 2)
        row.addView(n, lp(px(30), WRAP))
    }
    row.addView(coverView(t.coverKind, 54, 12f), lp(px(54), px(54), 0f, if (index != null) px(6) else 0, 0, 0, 0))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(label(t.title, 19f, if (current) Ui.ACCENT else Ui.TEXT, 1))
    col.addView(label(t.artist, 16f, Ui.TEXT2, 0), lp(WRAP, WRAP, 0f, 0, px(3), 0, 0))
    row.addView(col, lp(0, WRAP, 1f, px(16), 0, px(8), 0))
    row.addView(iconButton(R.drawable.ic_more, 24, 44, Ui.TEXT2) { soon("Menu da faixa") })
    row.tap(onClick)
    return row
}

/** Item de capa em lista horizontal (capa + título + subtítulo). */
fun Context.coverItem(kind: Int, sizeDp: Int, title: String, subtitle: String, onClick: () -> Unit): LinearLayout {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(coverView(kind, sizeDp, 22f))
    col.addView(label(title, 17f, Ui.TEXT, 1), lp(px(sizeDp), WRAP, 0f, 0, px(8), 0, 0))
    col.addView(label(subtitle, 15f, Ui.TEXT2, 0), lp(px(sizeDp), WRAP, 0f, 0, px(2), 0, 0))
    col.tap(onClick)
    return col
}

/** Coloca [v] dentro de uma célula de peso 1 (distribuição uniforme de botões em linha). */
fun Context.cell(v: View): FrameLayout {
    val f = FrameLayout(this)
    f.addView(v, FrameLayout.LayoutParams(v.layoutParams.width, v.layoutParams.height, Gravity.CENTER))
    f.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
    return f
}
