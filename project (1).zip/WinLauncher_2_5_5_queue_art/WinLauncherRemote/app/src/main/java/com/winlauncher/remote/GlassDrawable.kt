package com.winlauncher.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import kotlin.random.Random

/** Estado global do efeito de vidro. [strength] (0,4–1,6) escala a transparência e os reflexos. */
object Glass {
    @Volatile
    var strength: Float = 1.0f

    /** Sobe a cada mudança de intensidade; os drawables reconstroem seus gradientes ao notar. */
    @Volatile
    var version: Int = 0

    fun set(s: Float) {
        strength = s.coerceIn(0.4f, 1.6f)
        version++
    }

    /** Granulado fino (ruído branco de baixíssima opacidade) que dá a textura de vidro fosco. */
    val noise: Bitmap by lazy {
        val n = 96
        val px = IntArray(n * n)
        val r = Random(7)
        for (i in px.indices) px[i] = Color.argb(r.nextInt(0, 26), 255, 255, 255)
        Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }
}

enum class GlassStyle {
    /** Cartão grande de vidro fosco. */
    CARD,

    /** Botão/pílula de vidro (não selecionado). */
    BUTTON,

    /** Pílula selecionada: vidro claro, quase branco, com brilho. */
    SELECTED,

    /** Botão principal (play): vidro branco com brilho. */
    PRIMARY
}

/**
 * Vidro fosco desenhado por código, sobre fundo cinza sólido:
 * sombra suave em camadas, película translúcida em degradê, reflexo no topo, sombreamento inferior,
 * granulado, borda de luz diagonal. O próprio drawable reserva [insetDp] de margem para a sombra
 * (getPadding), então a view que o usa já ganha esse espaço.
 */
class GlassDrawable(
    ctx: Context,
    private val radiusDp: Float,
    private val style: GlassStyle = GlassStyle.CARD,
    private val circle: Boolean = false
) : Drawable() {

    private val d = ctx.resources.displayMetrics.density
    private val m = (if (style == GlassStyle.CARD) 9f else 6f) * d
    private val glow = style == GlassStyle.SELECTED || style == GlassStyle.PRIMARY
    private val solid = glow

    private val rect = RectF()
    private val path = Path()
    private var rr = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val noisePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var dirty = true
    private var builtVersion = -1
    private var pressed = false

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 1.2f * d
        shadow.style = Paint.Style.FILL
        pressPaint.color = Color.argb(34, 255, 255, 255)
        noisePaint.shader = BitmapShader(Glass.noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    /** Margem (em px) reservada para a sombra. */
    val insetPx: Int get() = m.toInt()

    private fun wa(a: Float): Int {
        val v = (255f * (a * Glass.strength)).coerceIn(0f, 255f)
        return Color.argb(v.toInt(), 255, 255, 255)
    }

    override fun onBoundsChange(bounds: Rect) {
        dirty = true
    }

    override fun getPadding(padding: Rect): Boolean {
        padding.set(m.toInt(), m.toInt(), m.toInt(), m.toInt())
        return true
    }

    private fun build() {
        val b = bounds
        rect.set(b.left + m, b.top + m, b.right - m, b.bottom - m)
        val h = rect.height()
        val maxR = minOf(rect.width(), rect.height()) / 2f
        rr = if (circle) maxR else minOf(radiusDp * d, maxR)

        when (style) {
            GlassStyle.CARD ->
                fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, wa(0.15f), wa(0.07f), Shader.TileMode.CLAMP)
            GlassStyle.BUTTON ->
                fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, wa(0.22f), wa(0.10f), Shader.TileMode.CLAMP)
            else ->
                fill.shader = LinearGradient(
                    0f, rect.top, 0f, rect.bottom,
                    Color.parseColor("#FFFFFF"), Color.parseColor("#DCDCE0"), Shader.TileMode.CLAMP
                )
        }
        // Reflexo suave no topo (vidro)
        val sheenA = if (solid) 0.0f else 0.22f
        sheen.shader = LinearGradient(0f, rect.top, 0f, rect.top + h * 0.55f, wa(sheenA), wa(0f), Shader.TileMode.CLAMP)
        // Sombreamento inferior (profundidade)
        val shadeA = (46f * Glass.strength).coerceIn(0f, 120f).toInt()
        shade.shader = LinearGradient(
            0f, rect.bottom - h * 0.35f, 0f, rect.bottom,
            Color.argb(0, 0, 0, 0), Color.argb(if (solid) 0 else shadeA, 0, 0, 0), Shader.TileMode.CLAMP
        )
        // Borda de luz: forte no canto superior esquerdo e inferior direito
        stroke.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(wa(0.62f), wa(0.12f), wa(0.07f), wa(0.32f)),
            floatArrayOf(0f, 0.35f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        noisePaint.alpha = (255f * (0.9f * Glass.strength).coerceIn(0f, 1f)).toInt()

        path.reset()
        path.addRoundRect(rect, rr, rr, Path.Direction.CW)
        dirty = false
        builtVersion = Glass.version
    }

    override fun draw(canvas: Canvas) {
        if (bounds.isEmpty) return
        if (dirty || builtVersion != Glass.version) build()

        // Sombra suave em anéis concêntricos (funciona em qualquer versão do Android)
        val steps = 7
        val dy = if (glow) 0f else m * 0.3f
        shadow.color = if (glow) Color.argb(10, 255, 255, 255) else Color.argb(11, 0, 0, 0)
        for (i in 0 until steps) {
            val g = m * 0.7f * (steps - i) / steps
            canvas.drawRoundRect(
                rect.left - g, rect.top - g + dy, rect.right + g, rect.bottom + g + dy,
                rr + g, rr + g, shadow
            )
        }

        canvas.drawPath(path, fill)

        canvas.save()
        canvas.clipPath(path)
        canvas.drawRect(rect, sheen)
        canvas.drawRect(rect, shade)
        if (!solid) canvas.drawRect(rect, noisePaint)
        if (pressed) canvas.drawPath(path, pressPaint)
        canvas.restore()

        if (!solid) {
            val sw = stroke.strokeWidth / 2f
            canvas.drawRoundRect(
                rect.left + sw, rect.top + sw, rect.right - sw, rect.bottom - sw,
                maxOf(0f, rr - sw), maxOf(0f, rr - sw), stroke
            )
        }
    }

    override fun isStateful(): Boolean = true

    override fun onStateChange(state: IntArray): Boolean {
        val p = state.contains(android.R.attr.state_pressed)
        if (p != pressed) {
            pressed = p
            invalidateSelf()
            return true
        }
        return false
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
