package com.winlauncher.remote

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Cores fixas do tema. O fundo é SEMPRE cinza sólido (nunca derivado da capa). */
object Ui {
    val BG: Int = Color.parseColor("#38393B")
    val TEXT: Int = Color.parseColor("#F4F4F5")
    val TEXT2: Int = Color.parseColor("#B4B5B9")
    val DIM: Int = Color.parseColor("#9A9BA0")
    val ACCENT: Int = Color.parseColor("#4CC2FF")
    val GREEN: Int = Color.parseColor("#3DDC84")
    val AMBER: Int = Color.parseColor("#FFC247")
    val RED: Int = Color.parseColor("#FF6B6B")
    val DARK: Int = Color.parseColor("#141416")
}

const val MATCH: Int = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP: Int = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.px(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.pxf(v: Float): Float = v * resources.displayMetrics.density
fun View.px(v: Int): Int = context.px(v)
fun View.pxf(v: Float): Float = context.pxf(v)

/** Parâmetros de layout para filhos de LinearLayout. */
fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(l, t, r, b)
    return p
}

/** Aviso padrão para ações que ainda não estão integradas (serão ligadas na próxima etapa). */
fun Context.soon(feature: String) {
    Toast.makeText(this, "$feature: disponível na próxima etapa", Toast.LENGTH_SHORT).show()
}

/** weight: 0 = normal, 1 = médio, 2 = negrito. */
fun Context.label(text: CharSequence, sp: Float, color: Int = Ui.TEXT, weight: Int = 0): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    t.typeface = when (weight) {
        2 -> Typeface.create("sans-serif", Typeface.BOLD)
        1 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else -> Typeface.create("sans-serif", Typeface.NORMAL)
    }
    t.includeFontPadding = false
    t.maxLines = 1
    t.ellipsize = TextUtils.TruncateAt.END
    return t
}

/** Ícone vetorial pintado com [tint]. */
fun Context.icon(res: Int, sizeDp: Int, tint: Int = Ui.TEXT): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    v.layoutParams = ViewGroup.LayoutParams(px(sizeDp), px(sizeDp))
    return v
}

fun fmt(ms: Long): String {
    val s = (if (ms < 0L) 0L else ms) / 1000L
    return String.format(Locale.ROOT, "%02d:%02d", s / 60L, s % 60L)
}

/** Toque com leve feedback de opacidade. */
fun View.tap(onClick: () -> Unit) {
    isClickable = true
    setOnClickListener { onClick() }
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.alpha = 0.6f
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
        }
        false
    }
}

/** Invalida a árvore inteira (usado quando a intensidade do vidro muda). */
fun invalidateTree(v: View) {
    v.invalidate()
    if (v is ViewGroup) {
        for (i in 0 until v.childCount) invalidateTree(v.getChildAt(i))
    }
}
