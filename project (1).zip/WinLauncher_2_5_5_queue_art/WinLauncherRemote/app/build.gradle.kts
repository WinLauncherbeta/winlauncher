plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.winlauncher.remote"
    compileSdk = 34

    defaultConfig {
        // applicationId PRÓPRIO: diferente de com.example.winlauncher, instala junto com o launcher.
        applicationId = "com.winlauncher.remote"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    // Mesma assinatura de debug do projeto principal, SOMENTE LEITURA:
    // o arquivo é lido em ../../app/debug.keystore (raiz do repositório) e nunca é copiado nem modificado.
    // Se não existir (ex.: pasta copiada sozinha), vale a chave de debug padrão do Android.
    val sharedDebugKeystore = file("../../app/debug.keystore")
    if (sharedDebugKeystore.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = sharedDebugKeystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sem dependências externas: só o framework Android (mesmo estilo do launcher principal).
dependencies {
}
