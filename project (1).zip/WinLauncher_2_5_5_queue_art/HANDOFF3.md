# HANDOFF 3 — estado atual (continuação do HANDOFF2.md)

Nada foi compilado (sem Android SDK / rede). Rode `./gradlew assembleDebug` no fim e corrija os erros.

## JÁ ESCRITO em FileManagerWindow.kt (~1900 linhas, a classe AINDA NÃO FECHA)
- Parte 1 (HANDOFF2) + ajustes: `REQ_STORAGE` público, `ERR_ACCESS`, campos novos ANTES do `init`
  (clipSet, lastMouse/Ctrl/Shift, lastRawX/Y, progBar/progText/progShown, opStart, lastTitleTap, thumbFail, driveCache),
  Enter nos diálogos (`dlgOk`).
- Chunk A: `build()`, `buildTitleBar`, `buildNavBar` (crumbs + addrEdit + searchBox), `buildCmdBar`, `cmdBtn/setCmd/showMenuUnder`,
  `titleButton(res, danger, pad=9, onClick)`, `btnBg`, `releaseFocus`, `GripView`.
- Chunk B: `curPath`, `navigate/goBack/goForward/goUp/reload/setCurrent`, `hasAccess/requestAccess/primaryRoot/isShared/isRootDir`,
  `loadDir`, `applyPending`, `comparator/applySortFilter`, `DateRef`, `contentWidth/computePerRow/buildRows`,
  `setView/setSort/setSortDir/setShowHidden`, `onSearchTyped/stopSearchTick/runSearch/revealItem`,
  `buildCrumbs/crumb/startAddrEdit/stopAddrEdit/commitAddrEdit`.
- Cópias dos chunks em `_wip/fm/chunk*.txt` (só referência; JÁ estão dentro do .kt, não duplicar).

## FALTA escrever (dentro da classe, depois do chunk B, e fechar com `}`)
REGRA: não declarar propriedades novas depois do `init` se `build()` as usar (ficam null). Funções/classes aninhadas podem ir em qualquer lugar.
1. `RowAdapter` (BaseAdapter; 2 tipos; isEnabled=false; getView usa key=viewMode*100+perRow), `RowView`, `Cell` (inner),
   `colFlags()`, miniaturas `requestThumb/loadThumb` (usa thumbs, thumbFail, thumbExec).
2. `updateDetailsHeader`, `updateContentState` (home/erro/ERR_ACCESS com botão/vazio), `updateChrome` (título, botões, status, setCmd),
   `buildHome` (Pastas(5) + unidades com StatFs; preenche `driveCache`), `drives()`, classe `Special`, `specialFolders()`,
   `rebuildSidebar/highlightSidebar`.
3. Seleção: `selectedItems/selectAll/clearSelection/selectRange/refreshSelection`, `onItemClick/onItemRightClick/onItemLongPress`.
4. Menus: `showSelectionMenu`, `showBgMenu(x,y)`, `newItems/sortItems/viewItems/moreItems` (List<MenuItem>).
5. Operações: `copySel/paste/askConflict/showConflict/deleteSel/renameSel/newFolder/newTextFile/zipSel/unzip/properties/shareSel/copyPath/
   openItem/openExternal(file, chooser)/runOp/showProgress/dialog/promptText/confirm/closeDialog/stopTicker`.
   `closeDialog()` deve limpar dlgOk/progBar/progText/progShown e invocar `dlgOnClose` (uma vez).
6. Fechar a classe `}`.

## INTEGRAÇÃO (nada feito) — igual ao HANDOFF2.md seção B
Manifest, AppCustom.FILES, MainActivity (TB_FILES, files, ensureFilesPinned, rebuildTaskbar, addFilesPinned/Button, entryFiles,
filesIcon(), filesMenuItems(), openApk(uri), onBackPressed, dispatchKeyEvent, onResume, afterAppCustomized,
onRequestPermissionsResult → `FileManagerWindow.REQ_STORAGE` chama `files.onHostResume()`).
