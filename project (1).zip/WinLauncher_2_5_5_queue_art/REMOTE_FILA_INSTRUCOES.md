# Fila de reprodução — o que o WinLauncher Remote precisa fazer

O ZIP recebido NÃO continha `RemoteClient.kt`, `RemoteProtocol.kt` do Remote, `MediaControlService`, `RemoteHub` nem a tela de Fila
(só a Parte 2 da 4A: componentes visuais). Por isso o lado do Remote NÃO foi alterado nem verificado. O lado do WinLauncher
(servidor) está pronto; abaixo está o contrato exato para o Remote.

## 1. Handshake (obrigatório, senão o servidor nunca envia a fila)
- No `Hello` enviado, acrescentar a capacidade: `caps = listOf("mouse", "queue")` (hoje só "mouse").
- O hello do servidor agora traz `caps` com "queue". Se NÃO trouxer, o WinLauncher é antigo: mostrar "atualize o WinLauncher".

## 2. Mensagem nova (servidor -> cliente): `queue`
`{"v":1,"t":"queue","st":"ok","title":"...","cur":3,"total":120,"from":0,"items":[{"id":1,"title":"...","sub":"..."}]}`
- `st`: ok | empty | not_published | no_session | no_access | unknown
- Retrato COMPLETO: cada mensagem substitui a anterior (não mesclar).
- `items` é uma janela (até 50): `from` = posição do 1º item na fila inteira, `total` = tamanho da fila inteira,
  `cur` = posição do item tocando na fila inteira (-1 = desconhecida). Posição na janela = `cur - from`.
- Mensagem exibida na tela de Fila:
  - ok: lista; marcar o item `cur`; se `total > items.size`, mostrar "X–Y de N".
  - not_published: "O app de música não publica a fila pelo Android" (é limitação do app, não erro do WinLauncher).
  - empty: "A fila está vazia". no_session: "Nenhuma música tocando". no_access: "Conceda o acesso às notificações no WinLauncher".
  - Só usar "O app WinLauncher não informou a fila" quando o servidor não anunciou "queue" (WinLauncher antigo).
- Nunca montar fila a partir do histórico.

## 3. Código a copiar para o `RemoteProtocol.kt` do Remote
(trecho idêntico ao do WinLauncher; ajustar só o que faltar)
- `Types`: `const val QUEUE = "queue"`
- Dentro de `sealed class Message`:
```kotlin
data class QueueMsg(
    val status: QueueCode, val title: String, val cur: Int, val total: Int, val from: Int, val items: List<QueueRow>
) : Message(Types.QUEUE)
```
- `toJson`: ramo `is Message.QueueMsg` (só necessário se o Remote codifica; o `when` é exaustivo).
- `decode`: `Types.QUEUE -> decodeQueue(o)`
- Bloco abaixo (constantes, `QueueCode`, `QueueRow`, `queueRowJson`, `decodeQueue`; precisa dos helpers `reqStr/optStr/reqIntIn/reqWhole/bad` que o Remote já tem, pois o protocolo é o mesmo):
```kotlin
    const val CAP_QUEUE = "queue"

    /** Capacidades que o servidor anuncia no hello. */
    val SERVER_CAPS: List<String> = listOf(CAP_QUEUE)

    const val MAX_QUEUE_ITEMS = 50
    const val MAX_QUEUE_TOTAL = 5000
    const val QUEUE_PRE_ITEMS = 5
    const val QUEUE_TITLE_MAX = 100
    const val QUEUE_SUB_MAX = 80
    const val QUEUE_NAME_MAX = 100

    /** Sobra mantida no quadro da fila (o quadro inteiro nunca passa de [MAX_FRAME_BYTES]). */
    private const val QUEUE_FRAME_MARGIN = 512

    enum class QueueCode(val wire: String) {
        OK("ok"),
        EMPTY("empty"),
        NOT_PUBLISHED("not_published"),
        NO_SESSION("no_session"),
        NO_ACCESS("no_access"),
        UNKNOWN("unknown");

        companion object {
            /** Valor que este programa não conhece vira UNKNOWN (um servidor mais novo pode ter acrescentado outros). */
            fun fromWire(s: String?): QueueCode = values().firstOrNull { it.wire == s } ?: UNKNOWN
        }
    }

    /** Um item da fila no protocolo. */
    data class QueueRow(val id: Long, val title: String, val subtitle: String)

    private fun queueRowJson(r: QueueRow): JSONObject {
        val o = JSONObject()
        o.put("id", r.id)
        o.put("title", r.title)
        o.put("sub", r.subtitle)
        return o
    }

    private fun decodeQueue(o: JSONObject): Message.QueueMsg {
        val code = QueueCode.fromWire(o.reqStr("st", 16))
        val title = o.optStr("title", QUEUE_NAME_MAX)
        val total = o.reqIntIn("total", 0, MAX_QUEUE_TOTAL)
        val from = o.reqIntIn("from", 0, MAX_QUEUE_TOTAL)
        val cur = o.reqIntIn("cur", -1, MAX_QUEUE_TOTAL - 1)
        val arr = o.opt("items")
        if (arr !is JSONArray || arr.length() > MAX_QUEUE_ITEMS) throw bad("campo 'items' inválido")
        val rows = ArrayList<QueueRow>(arr.length())
        for (i in 0 until arr.length()) {
            val item = arr.opt(i)
            if (item !is JSONObject) throw bad("item da fila inválido")
            rows.add(
                QueueRow(
                    id = item.reqWhole("id", Long.MIN_VALUE, Long.MAX_VALUE),
                    title = item.optStr("title", QUEUE_TITLE_MAX),
                    subtitle = item.optStr("sub", QUEUE_SUB_MAX)
                )
            )
        }
        if (from + rows.size > total) throw bad("janela da fila passa do total")
        if (cur >= total) throw bad("item atual fora da fila")
        if (code == QueueCode.OK) {
            if (rows.isEmpty()) throw bad("fila 'ok' sem itens")
        } else if (rows.isNotEmpty() || total != 0 || from != 0 || cur != -1) {
            throw bad("fila sem itens com dados")
        }
        return Message.QueueMsg(code, title, cur, total, from, rows)
    }

```
Remover do bloco colado o que depende do Hub (`queueOf`, `selfTestQueue`): já não estão neste trecho.

## 4. RemoteClient
- Ramo no `loop()` para `QueueMsg` -> `listener.onQueue(msg)` (novo método COM corpo padrão vazio, como foi feito com onMouse).
- Guardar `serverSupportsQueue = hello.caps.contains("queue")`.
- Sem mudar nada em play/pause/próxima/anterior.

## 5. ATUALIZAÇÃO (launcher 2.5.4): seleção de música na fila
- O servidor agora anuncia também `queue_select` no hello (`caps = ["queue","queue_select"]`).
- Comando cliente -> servidor: `{"v":1,"t":"command","id":N,"cmd":"play_queue_item","queueId":<id do item, o mesmo de items[].id>}`.
  `queueId` é obrigatório nesse comando. Resposta: `command_result` (`ok` ou erro `unavailable` se o id saiu da fila / o app não permite pular para item).
- O Remote só envia `play_queue_item` se o hello trouxe `queue_select`; senão mostra "Atualize o WinLauncher".
- A fila nova e o estado voltam pelas mensagens `queue` e `state` de sempre; o Remote não altera a lista localmente.
