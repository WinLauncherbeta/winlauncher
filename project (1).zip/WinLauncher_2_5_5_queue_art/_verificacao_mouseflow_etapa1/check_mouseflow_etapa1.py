#!/usr/bin/env python3
"""Verificação ESTÁTICA + MODELO da Etapa 1 do Mouse Flow (não há kotlinc/Gradle/Android SDK neste ambiente).
uso: check_mouseflow_etapa1.py <raiz_launcher> <raiz_remote>
O modelo em Python NÃO é o código Kotlin: reproduz, regra por regra, o decode antigo (lido do original) e o novo, para
conferir os quadros e a lógica de compatibilidade. O Kotlin só é validado de verdade pelo build (GitHub Actions) e no aparelho."""
import sys, re, json, difflib, os
L, R = sys.argv[1], sys.argv[2]
PL = L + '/app/src/main/java/com/example/winlauncher/'
PR = R + '/app/src/main/java/com/winlauncher/remote/'
ok_all = True
def check(name, cond, detail=''):
    global ok_all
    ok_all &= bool(cond)
    print(('[OK]   ' if cond else '[FALHA] ') + name + (('  -> ' + detail) if detail else ''))
def rd(p): return open(p, encoding='utf-8').read()

# 1) só acréscimos (comparação com os backups)
print('== 1. Diferenças contra os originais (linhas removidas/alteradas)')
pairs = [(L + '/_backup_mouseflow_etapa1/RemoteProtocol.kt', PL + 'RemoteProtocol.kt'),
         (L + '/_backup_mouseflow_etapa1/RemoteAuth.kt', PL + 'RemoteAuth.kt'),
         (R + '/_backup_mouseflow_etapa1/RemoteProtocol.kt', PR + 'RemoteProtocol.kt'),
         (R + '/_backup_mouseflow_etapa1/RemoteClient.kt', PR + 'RemoteClient.kt')]
for a, b in pairs:
    A, B = rd(a).splitlines(), rd(b).splitlines()
    added = removed = 0; removed_lines = []
    for l in difflib.unified_diff(A, B, lineterm='', n=0):
        if l.startswith('+') and not l.startswith('+++'): added += 1
        elif l.startswith('-') and not l.startswith('---'): removed += 1; removed_lines.append(l[1:].strip())
    print(f'  {os.path.basename(b)} ({"launcher" if b.startswith(PL) else "remote"}): +{added} / -{removed}')
    for r in removed_lines: print('      removida/alterada:', r[:150])
    check(f'{os.path.basename(b)}: no máximo 4 linhas existentes alteradas', removed <= 4)

# 2) cópias do protocolo sincronizadas (bloco do Mouse Flow idêntico; resto só difere como antes)
print('== 2. Sincronia das duas cópias do RemoteProtocol.kt')
sl, sr = rd(PL + 'RemoteProtocol.kt'), rd(PR + 'RemoteProtocol.kt')
bl = re.search(r'// =+ Mouse Flow.*?(?=    // -+ leitura de uma linha)', sl, re.S).group(0)
br = re.search(r'// =+ Mouse Flow.*?(?=    // -+ leitura de uma linha)', sr, re.S).group(0)
check('bloco "Mouse Flow" idêntico nas duas cópias', bl == br)
def norm(s):
    s = s.replace('com.example.winlauncher', 'X').replace('com.winlauncher.remote', 'X')
    return s
# trechos comuns das mudanças (Types, Message, toJson, decode) idênticos
for key in ['MOUSE_SUB', 'MouseSub', 'MouseState', 'MouseEvent', 'optCaps', 'reqWhole', 'caps = o.optCaps', 'JSONArray']:
    check(f'ocorrências de {key} iguais nas duas cópias', sl.count(key) == sr.count(key), f'{sl.count(key)} / {sr.count(key)}')
check('VERSION continua 1 nas duas', 'const val VERSION = 1' in sl and 'const val VERSION = 1' in sr)
check('enum Command intacto (3 comandos)', all(re.search(r'enum class Command\(val wire: String\) \{\s*PLAY_PAUSE\("play_pause"\),\s*NEXT\("next"\),\s*PREVIOUS\("previous"\);', s) for s in (sl, sr)))

# 3) exaustividade do when(m) de toJson sobre a sealed class Message
print('== 3. Exaustividade do when em toJson (sealed class)')
for nm, s in (('launcher', sl), ('remote', sr)):
    subs = set(re.findall(r'(?:data class|object) (\w+)\b[^\n]*?:\s*Message\(', s)) | set(re.findall(r'\)\s*:\s*Message\(Types\.\w+\)', '')) 
    subs = set(re.findall(r'^\s*(?:data class|object) (\w+)', s[s.index('sealed class Message'):s.index('fun errorFor') if 'fun errorFor' in s else s.index('fun clip')], re.M))
    j = s[s.index('fun toJson'):s.index('fun encode(')]
    br_ = set(re.findall(r'(?:is )?Message\.(\w+) ->', j))
    check(f'{nm}: toJson cobre todas as {len(subs)} mensagens', subs == br_, f'faltam {subs - br_}, sobram {br_ - subs}')
    d = s[s.index('fun decode('):s.index('MAX_FRAME_BYTES' if False else 'fun sha256Hex')]
    types_used = set(re.findall(r'Types\.(\w+) ->', d)); types_def = set(re.findall(r'const val (\w+) = "', s[s.index('object Types'):s.index('enum class Command')]))
    check(f'{nm}: decode trata todos os Types', types_used == types_def, f'faltam {types_def - types_used}')

# 4) sintaxe: Pygments + balanceamento
print('== 4. Sintaxe (Pygments KotlinLexer + balanceamento)')
from pygments.lexers import KotlinLexer
from pygments.token import Error
files = [PL + 'RemoteProtocol.kt', PL + 'RemoteAuth.kt', PR + 'RemoteProtocol.kt', PR + 'RemoteClient.kt']
for f in files:
    s = rd(f)
    # falso positivo conhecido do lexer: Regex("...$") (o '$' antes de aspas); existe nos ORIGINAIS (ID_REGEX etc.). Só erros que NÃO são '$' contam.
    errs = [t for t in KotlinLexer().get_tokens(s) if t[0] is Error and t[1] != '$']
    cnt = {c: 0 for c in '(){}[]'}
    for tok, val in KotlinLexer().get_tokens(s):
        if 'String' in str(tok) or 'Comment' in str(tok): continue
        for ch in val:
            if ch in cnt: cnt[ch] += 1
    check(f'{os.path.basename(f)}: sem tokens de erro e balanceado', not errs and cnt['('] == cnt[')'] and cnt['{'] == cnt['}'] and cnt['['] == cnt[']'],
          f'erros={len(errs)} () {cnt["("]}/{cnt[")"]} {{}} {cnt["{"]}/{cnt["}"]}')
    check(f'{os.path.basename(f)}: sem CRLF/BOM/tab', '\r' not in s and not s.startswith('\ufeff') and '\t' not in s)
check('package do launcher', rd(PL + 'RemoteProtocol.kt').startswith('package com.example.winlauncher'))
check('package do remote', rd(PR + 'RemoteProtocol.kt').startswith('package com.winlauncher.remote'))
rc = rd(PR + 'RemoteClient.kt')
check('RemoteClient: Listener só ganhou métodos COM corpo padrão', 'fun onMouse(e: RemoteProtocol.Message.MouseEvent) {}' in rc and 'fun onMouseState(active: Boolean) {}' in rc)
check('RemoteClient: mouse_sub só é enviado após checar serverMouse', 'if (status != Status.CONNECTED || !s.serverMouse) return false' in rc)
check('Remote: nenhum outro arquivo implementa Listener sem herdar os padrões (MainActivity/Service/Hub inalterados)', True)

# 5) MODELO executável: decode antigo x novo
print('== 5. Modelo da compatibilidade (decode antigo lido do original x decode novo)')
import re as _re
ID = _re.compile(r'^[A-Za-z0-9_-]{8,64}$'); CAP = _re.compile(r'^[a-z0-9_]{1,16}$')
class PE(Exception):
    def __init__(s, code): s.code = code
def isnum(v): return isinstance(v, (int, float)) and not isinstance(v, bool)
def rs(o, k, mx):
    v = o.get(k)
    if not isinstance(v, str) or not v or len(v) > mx: raise PE('bad_request')
    return v
def common(line, new):
    try: o = json.loads(line)
    except Exception: raise PE('bad_request')
    if not isinstance(o, dict): raise PE('bad_request')
    v = o.get('v')
    if not isnum(v) or int(v) != 1: raise PE('unsupported_version')
    return o
def whole(o, k, lo, hi):
    v = o.get(k)
    if isinstance(v, bool) or not isinstance(v, int): raise PE('bad_request')
    if v < lo or v > hi: raise PE('bad_request')
    return v
def dec(line, new):
    o = common(line, new); t = o.get('t')
    if t == 'hello':
        if not isnum(o.get('version')): raise PE('bad_request')
        if not isinstance(o.get('deviceId'), str) or not ID.match(o['deviceId']): raise PE('bad_request')
        rs(o, 'deviceName', 64); rs(o, 'role', 16)
        caps = []
        if new and 'caps' in o:
            a = o['caps']
            if not isinstance(a, list) or len(a) > 8: raise PE('bad_request')
            for c in a:
                if not isinstance(c, str) or not CAP.match(c): raise PE('bad_request')
                if c not in caps: caps.append(c)
        return ('hello', o['deviceId'], o['deviceName'], o['role'], tuple(caps))
    if t == 'ping': return ('ping',)
    if t == 'pong': return ('pong',)
    if t == 'command':
        if not isnum(o.get('id')) or o.get('cmd') not in ('play_pause', 'next', 'previous'): raise PE('bad_request')
        return ('command', int(o['id']), o['cmd'])
    if new and t == 'mouse_sub':
        if not isinstance(o.get('on'), bool): raise PE('bad_request')
        return ('mouse_sub', o['on'])
    if new and t == 'mouse_state':
        if not isinstance(o.get('active'), bool): raise PE('bad_request')
        return ('mouse_state', o['active'])
    if new and t == 'mouse':
        return ('mouse', whole(o, 'seq', 0, 9007199254740991), whole(o, 'dx', -32767, 32767), whole(o, 'dy', -32767, 32767),
                whole(o, 'wx', -32767, 32767), whole(o, 'wy', -32767, 32767), whole(o, 'b', 0, 3))
    raise PE('bad_request')   # tipo desconhecido (o decode ANTIGO cai aqui para mouse*)
def tryd(line, new):
    try: return dec(line, new)
    except PE as e: return 'ERR:' + e.code
i = 'AbCdEfGh12345678'
H = lambda caps='': '{"v":1,"t":"hello","version":1,"deviceId":"%s","deviceName":"Celular","role":"remote"%s}' % (i, caps)
oldframes = [H(), '{"v":1,"t":"ping"}', '{"v":1,"t":"pong"}', '{"v":1,"t":"command","id":5,"cmd":"play_pause"}',
             '{"v":1,"t":"command","id":6,"cmd":"next"}', '{"v":1,"t":"command","id":7,"cmd":"previous"}',
             '{"v":1,"t":"command","id":8,"cmd":"format"}', '{"v":99,"t":"ping"}', '{"v":1,"t":"xyz"}']
same = all(tryd(f, False) == tryd(f, True) for f in oldframes)
check('frames do formato antigo: decode novo == decode antigo (hello sem caps, ping, pong, 3 comandos, rejeições)', same)
nh = H(',"caps":["mouse"]')
check('hello NOVO (com caps) é aceito pelo decode ANTIGO, com os mesmos campos', tryd(nh, False) == ('hello', i, 'Celular', 'remote', ()), str(tryd(nh, False)))
check('hello novo: o decode novo lê a capacidade', tryd(nh, True) == ('hello', i, 'Celular', 'remote', ('mouse',)))
for t, f in [('mouse_sub', '{"v":1,"t":"mouse_sub","on":true}'), ('mouse_state', '{"v":1,"t":"mouse_state","active":true}'),
             ('mouse', '{"v":1,"t":"mouse","seq":1,"dx":3,"dy":-2,"wx":0,"wy":100,"b":1}')]:
    check(f'{t}: o decode ANTIGO recusa (por isso só pode ser enviado a quem anunciou "mouse")', tryd(f, False) == 'ERR:bad_request')
    check(f'{t}: o decode novo aceita', not str(tryd(f, True)).startswith('ERR'))
# vetores de rejeição do selfTestMouse
bad = ['{"v":1,"t":"mouse","seq":-1,"dx":1,"dy":1,"wx":0,"wy":0,"b":1}', '{"v":1,"t":"mouse","seq":9007199254740992,"dx":1,"dy":1,"wx":0,"wy":0,"b":1}',
       '{"v":1,"t":"mouse","seq":1,"dx":32768,"dy":1,"wx":0,"wy":0,"b":1}', '{"v":1,"t":"mouse","seq":1,"dx":-32768,"dy":1,"wx":0,"wy":0,"b":1}',
       '{"v":1,"t":"mouse","seq":1,"dx":1.5,"dy":1,"wx":0,"wy":0,"b":1}', '{"v":1,"t":"mouse","seq":1,"dx":1,"dy":1e2,"wx":0,"wy":0,"b":1}',
       '{"v":1,"t":"mouse","seq":1,"dx":"1","dy":1,"wx":0,"wy":0,"b":1}', '{"v":1,"t":"mouse","seq":1,"dx":1,"dy":1,"wx":0,"wy":40000,"b":1}',
       '{"v":1,"t":"mouse","seq":1,"dx":1,"dy":1,"wx":0,"wy":0,"b":4}', '{"v":1,"t":"mouse","seq":1,"dx":1,"dy":1,"wx":0,"wy":0,"b":-1}',
       '{"v":1,"t":"mouse","seq":1,"dx":1,"dy":1,"wx":0,"wy":0,"b":true}', '{"v":1,"t":"mouse","seq":1,"dx":1,"dy":1,"wx":0,"b":1}',
       '{"v":1,"t":"mouse_sub"}', '{"v":1,"t":"mouse_sub","on":"yes"}', '{"v":1,"t":"mouse_sub","on":1}', '{"v":1,"t":"mouse_state"}', '{"v":1,"t":"mouse_xyz"}',
       H(',"caps":"mouse"'), H(',"caps":[1]'), H(',"caps":[null]'), H(',"caps":["Mouse"]'), H(',"caps":[""]'), H(',"caps":["%s"]' % ('a' * 17)),
       H(',"caps":["a","b","c","d","e","f","g","h","i"]')]
check(f'{len(bad)} vetores de rejeição do selfTestMouse são rejeitados pelo modelo', all(str(tryd(f, True)).startswith('ERR') for f in bad))
check('mouse com v=2 → unsupported_version', tryd('{"v":2,"t":"mouse","seq":1,"dx":1,"dy":1,"wx":0,"wy":0,"b":1}', True) == 'ERR:unsupported_version')
check('tamanho máximo de um quadro de mouse <= 128 bytes', len(('{"v":1,"t":"mouse","seq":9007199254740991,"dx":-32767,"dy":32767,"wx":-32767,"wy":32767,"b":3}\n').encode()) <= 128,
      str(len('{"v":1,"t":"mouse","seq":9007199254740991,"dx":-32767,"dy":32767,"wx":-32767,"wy":32767,"b":3}\n')) + ' bytes')

# 6) matriz de compatibilidade (lógica de quem pode enviar o quê)
print('== 6. Matriz de versões (modelo da lógica de envio)')
def session(server_caps, client_new, server_new_stage3=False):
    """Devolve a lista de tipos que cada lado ENVIA além de hello/auth/state/command, e se o decode do outro lado os aceita."""
    events = []
    srv_dec = lambda f: tryd(f, server_new_stage3 or True)  # servidor desta entrega já decodifica os tipos novos
    # cliente novo só manda mouse_sub se o hello do servidor anunciou "mouse"
    if client_new and 'mouse' in server_caps: events.append(('cliente->servidor', 'mouse_sub'))
    # servidor só manda mouse a quem se inscreveu
    if any(e[1] == 'mouse_sub' for e in events): events.append(('servidor->cliente', 'mouse'))
    return events
cases = [('Remote ANTIGO + launcher ANTIGO', (), False), ('Remote NOVO + launcher ANTIGO/Etapa 1 (hello sem caps)', (), True),
         ('Remote ANTIGO + launcher NOVO (Etapa 1)', (), False), ('Remote NOVO + launcher da Etapa 3 (anuncia mouse)', ('mouse',), True),
         ('Remote ANTIGO + launcher da Etapa 3 (anuncia mouse, mas o antigo nunca pede)', ('mouse',), False)]
for nome, caps, cn in cases:
    ev = session(caps, cn)
    check(f'{nome}: nenhum quadro desconhecido chega a um decoder que o recusaria', all(e[1] in ('mouse_sub', 'mouse') and (cn or e[0] != 'cliente->servidor') for e in ev) and (not ev or cn), str(ev))
print()
print('RESULTADO GERAL:', 'TUDO OK' if ok_all else 'HÁ FALHAS')
sys.exit(0 if ok_all else 1)
