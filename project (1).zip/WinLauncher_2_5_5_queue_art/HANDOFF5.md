# HANDOFF 5 — arrastar e soltar entre apps nativos

## FEITO (nada foi compilado: sem Android SDK / kotlinc neste ambiente)
- DragDrop.kt (novo): camada transparente no topo do root recebe o arraste do Android, acha a janela aberta sob o dedo
  (a da frente vence) e entrega o conteúdo. Origem: DragDrop.start(). Destino: DragDrop.register(Target).
  Aceita arquivos locais, URLs (imagens do navegador, http/https/data) e URIs de outros apps. Destaque azul na janela alvo.
- Opção liga/desliga: Configurações > Bluetooth e dispositivos > Mouse e interação > "Arrastar e soltar entre apps" (Prefs.dragDrop, chave ui_dragdrop, padrão ligado).
- Gerenciador: arrasta selecionados (toque: segurar e arrastar; mouse: clicar e arrastar). Solta na pasta atual ou sobre uma pasta.
  Dentro do gerenciador = mover; vindo de outra janela = copiar (reaproveita paste() com conflitos/progresso); URL/URI = baixa/copia para a pasta.
  Toque longo sem arrastar continua abrindo o menu como antes.
- Fotos: arrasta a foto; solta fotos/imagens da web em Pictures (aparece no topo da grade).
- Navegador: segurar imagem e arrastar (vira download na pasta/Fotos); soltar arquivos na página (dragenter/dragover/drop + preenche input file; limite 20 MB).
- Instalador de APK: solta .apk e abre a instalação.
- Configurações, Config. do PC e Clima não recebem arquivos (nada a fazer com eles).

## FALTA
1. Compilar (`./gradlew assembleDebug` / GitHub Actions) e corrigir erros.
2. Testar no aparelho: toque e mouse, soltar em pasta, imagem do site -> Fotos, arquivo -> site com upload, .apk -> instalador.
3. Não coberto: arrastar de dentro do visualizador de foto aberto; blob: URLs; soltar no app Chrome real (só funciona se o Android permitir arraste global entre janelas).
