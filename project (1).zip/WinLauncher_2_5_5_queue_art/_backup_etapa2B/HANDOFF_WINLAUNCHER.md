# HANDOFF_WINLAUNCHER — histórico e próximas etapas

Documento principal de continuidade. Os arquivos antigos `HANDOFF.md` … `HANDOFF7.md` continuam no projeto, sem alteração
(são o histórico das funcionalidades do launcher: gerenciador de arquivos, arrastar e soltar, downloads do navegador,
música na barra de tarefas etc.). A partir daqui, atualizar SOMENTE este arquivo.

## Projeto (não mudar sem necessidade)
- Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, Java 17, compileSdk/targetSdk 34, minSdk 26.
- Package/applicationId/namespace: `com.example.winlauncher`.
- Assinatura fixa: `app/debug.keystore` (alias `androiddebugkey`, senha `android`), configurada em `app/build.gradle.kts`.
  Mantém a mesma assinatura entre builds para atualizar o app por cima sem perder dados.
- Interface programática (Views), só framework Android; única dependência: Shizuku (opcional).
- Build: GitHub Actions (Java 17, Gradle 8.7, `assembleDebug`). O arquivo do workflow NÃO está dentro do ZIP
  (vive no repositório); o ZIP não traz `gradlew`/wrapper. O ZIP do projeto é enviado ao repositório e o workflow gera o APK.
- O ambiente onde o código é escrito NÃO tem Android SDK nem kotlinc: nada é compilado aqui. Só o GitHub Actions compila.
- `_wip/` contém rascunhos `.txt` antigos (fora do build). Não mexer.

## Versões
- 2.2 (versionCode 4): versão funcional da Etapa 2.
- 2.3 (versionCode 5): Etapa 3A (primeiro teste no aparelho).
- 2.3.1 (versionCode 6): Etapa 3A + correção 3A.1 da regeneração de chave. Versão subida só para o APK atualizar por cima da 2.3 já instalada.
- 2.4.0 (versionCode 7): Etapa 3B, Parte 1 (servidor TLS local). Sobe por cima da 2.3.1 (mesma assinatura, versionCode maior).
- **2.5.0 (versionCode 8): Etapa 3B, Parte 2 (pareamento, autenticação, música e comandos) — CÓDIGO ESCRITO, NÃO COMPILADO, NÃO TESTADO** (este ZIP). Sobe por cima da 2.4.0.

## Mapa de etapas do WinLauncher Remote
Numeração atual (a do dono). Equivalência com o antigo HANDOFF7: "etapa 3 = protocolo + servidor de teste" e
"etapa 4 = TLS/Keystore + pareamento" foram reorganizadas em 3A/3B/… abaixo.

- **Etapa 2 — CONCLUÍDA e testada no aparelho real** (YouTube Music ReVanced Morphe): `MediaSessionHub`
  (detecção automática da sessão, identificação do app, capa/título/artista, play/pause, próxima, anterior, abrir o app
  correto) + página de diagnóstico `ytdiag`. NÃO MODIFICAR sem necessidade comprovada.
- **Etapa 3A — IMPLEMENTADA, aguardando teste no aparelho** (ver abaixo).
- **Etapa 3B — dividida em duas partes.**
  - **Parte 1 — IMPLEMENTADA, NÃO COMPILADA e NÃO TESTADA no aparelho** (ver "Etapa 3B, Parte 1" abaixo): servidor TLS real, serviço em primeiro plano, painel básico e autoteste com handshake TLS real.
  - **Parte 2 — IMPLEMENTADA NO CÓDIGO (2.5.0), NÃO COMPILADA e NÃO TESTADA**: pareamento, aprovação, música, comandos, WifiLock, início automático, notificação de pedido, painel e autoteste da integração (ver a seção "Etapa 3B, Parte 2" no fim).
- Depois (rascunho, sem compromisso): pareamento completo com número + "Permitir"; NSD + serviço em primeiro plano +
  painel em Configurações; app WinLauncher Remote (projeto Android separado, interface estilo Windows 11); testes em Android 8+.

## Etapa 3A — o que foi feito
Objetivo: base de protocolo e autenticação + teste da chave no Android Keystore + hash do certificado na página de diagnóstico.

Arquivos CRIADOS
- `app/src/main/java/com/example/winlauncher/RemoteProtocol.kt`
- `app/src/main/java/com/example/winlauncher/RemoteAuth.kt`
- `HANDOFF_WINLAUNCHER.md` (este arquivo)

Arquivos MODIFICADOS (somente acréscimos; única linha alterada fora o build.gradle: `})` virou `}),` no SettingsWindow.kt para encaixar a nova linha)
- `app/build.gradle.kts`: versionCode 4→6, versionName 2.2→2.3.1 (5/2.3 na 3A; 6/2.3.1 na correção 3A.1).
- `app/src/main/java/com/example/winlauncher/CustomizeUi.kt`: nova rota `"remotediag"` em `panel()` e nova função
  `remoteDiagPanel()` (logo antes de `mousePanel()`).
- `app/src/main/java/com/example/winlauncher/SettingsWindow.kt`: nova linha "Diagnóstico do Remote (chave e certificado)"
  em Rede e Internet, abaixo do diagnóstico do YouTube Music.

NÃO modificados: `MediaSessionHub.kt`, `AndroidManifest.xml`, `settings.gradle.kts`, `build.gradle.kts` da raiz,
`debug.keystore`, package name. Nenhuma dependência nova (Keystore, JSSE e org.json são do framework).

### RemoteProtocol.kt
- Constantes: VERSION=1, DEFAULT_PORT=48655 e SERVICE_TYPE `_winlauncher._tcp.` (reservadas, ainda não usadas),
  limite de 16 KB por mensagem.
- Mensagens JSON, uma por linha (UTF-8 + `\n`), sempre com `v` e `t`: hello, pair_request, pair_challenge, pair_ok,
  auth, auth_ok, command (play_pause/next/previous), command_result, state, error, ping, pong.
- Validação rígida na decodificação (tipos, tamanhos, formato de id/nonce/token, versão). `readFrame()` lê uma linha com limite.
- `errorFor(MediaSessionHub.Result)` e `stateOf(MediaSessionHub.State)` (só LEEM tipos do Hub; capa fica para depois).
- `selfTest()`: ida e volta de todas as mensagens, rejeições (JSON quebrado, versão, tipo/comando desconhecido, nonce curto,
  id inválido, mensagem/linha enorme, linha cortada) e leitura de linhas.
- Fluxo planejado (documentado no cabeçalho do arquivo): pareamento com número comparado nos dois celulares + "Permitir".

### RemoteAuth.kt
- Chave `winlauncher_remote_server` no Android Keystore: EC P-256 (secp256r1); se falhar (geração ou teste de assinatura),
  apaga e gera RSA 2048. Certificado autoassinado (CN=WinLauncher Remote), validade de 10 anos, criado pelo próprio Keystore.
  Digests: NONE/SHA-256/384/512 (NONE por compatibilidade com o TLS de alguns aparelhos); RSA também PKCS1 e PSS.
- Hash do certificado: SHA-256 do DER (`fingerprint`, `formatFingerprint`, `shortFingerprint`).
- `pairingCode(fpDoServidor, clientNonce, serverNonce)`: 6 dígitos = SHA-256("WLR1|pair|<fp hex>|<nonce cliente>|<nonce servidor>")
  (primeiros 4 bytes mod 1.000.000). Cada lado usa o hash que ELE enxerga, então um intermediário com outro certificado
  gera números diferentes.
- Tokens: 32 bytes aleatórios (base64url); só o SHA-256 do token é guardado. Cadastro de pareados em
  SharedPreferences próprio `win_remote` (separado do `win`): `addPaired`, `removePaired`, `verifyPaired`, `clearPaired`, `pairedList`.
- **Regeneração/perda da chave apaga todos os pareamentos** (também detecta chave ausente ou trocada, por exemplo após restaurar
  backup, comparando o hash guardado com o do certificado atual). A página avisa que os celulares precisarão ser pareados de novo.
- `buildServerSslContext()` e `testSslContext()`: criam SSLContext/SSLEngine com a chave do Keystore apenas para teste.
  **Isso NÃO prova que um servidor TLS funciona**; o handshake real é da Etapa 3B.
- `selfTest()` com itens essenciais (✔/✘) e informativos (ℹ/⚠).

### Página de diagnóstico (temporária)
Configurações > Rede e Internet > "Diagnóstico do Remote (chave e certificado)":
- Estado da chave (algoritmo, local — hardware/StrongBox/software —, validade, pareamentos salvos) e hash SHA-256 do certificado
  (selecionável via botão "Copiar hash do certificado").
- "Executar autoteste": cria a chave se não existir e roda os testes abaixo.
- "Regenerar chave": pede confirmação (tocar duas vezes em 8 s), apaga pareamentos e roda o autoteste de novo.

Itens essenciais do autoteste: 1) chave no Keystore; 2) certificado autoassinado + validade + hash; 3) assinatura;
4) verificação (inclui recusar dado alterado); 5) SSLContext inicializado; 6) protocolo; 7) número de pareamento e tokens.
Informativos: local da chave, protocolos TLS habilitados, alias no gerenciador de chaves, pareamentos salvos/apagados.

## Resultado do primeiro teste no aparelho (Etapa 3A, build 2.3)
- Autoteste: TODOS os itens essenciais ✔. Chave EC P-256 (sem precisar do RSA), local: hardware seguro (TEE),
  TLS habilitado: TLSv1.2 e TLSv1.3, gerenciador de chaves enxerga o alias.
- Fechar e reabrir o app: o hash do certificado CONTINUA o mesmo (chave persiste). ✔
- **"Regenerar chave": o hash NÃO mudou (reportado pelo dono).** Ainda sem causa comprovada.

## Correção 3A.1 — regeneração de chave (arquivos: RemoteAuth.kt e CustomizeUi.kt; versão 2.3.1 / code 6)
Análise do código anterior: `regenerate()` só é chamado pelo botão (nunca ao abrir o app). Ele chamava `deleteKey()`,
que engolia QUALQUER erro em silêncio, e depois `createKey()`; nada confirmava que o alias tinha saído do Keystore e nada
comparava o hash antigo com o novo. Pela leitura, o fluxo parecia correto, então NÃO foi possível apontar a causa só no
papel; a correção faz a regeneração provar cada passo (ou falhar com o motivo), para o próximo teste mostrar onde está o problema.

`RemoteAuth.regenerate()` agora devolve `RegenReport` e lança exceção com o motivo se algum passo falhar:
1. `deleteKeyStrict()`: apaga o alias e confere com uma instância NOVA do Keystore que ele não existe mais; se continuar,
   aborta (chave e pareamentos ficam intactos).
2. `createKey()`: gera nova chave EC P-256 (RSA 2048 se falhar), com assinatura/verificação de teste; o certificado é lido
   de novo do Keystore.
3. Compara o SHA-256 antigo com o novo; se forem iguais, falha com "o hash do certificado não mudou".
4. Apaga os pareamentos e confere que sobraram 0. Se algo falhar depois de apagar a chave antiga, os pareamentos também são apagados.
5. Guarda "última regeneração" (data, hash antigo → novo, algoritmo) e escreve no logcat (tag `WinRemoteAuth`).
Nada em cache: o hash exibido sai sempre do certificado lido no Keystore (`certOrNull()` abre uma instância nova a cada vez).

Interface (Diagnóstico do Remote):
- Sucesso: "✔ CHAVE REGENERADA COM SUCESSO" com: chave antiga apagada (conferido), algoritmo e local da nova chave,
  hash antigo e novo, serial antigo → novo, pareamentos antes/depois e o aviso de que todos precisam ser refeitos.
  O hash na caixa é atualizado na hora e o autoteste roda em seguida.
- Erro: "✘ REGENERAÇÃO FALHOU" com o motivo e o estado real do Keystore depois da tentativa.
- A linha "Última regeneração: …" aparece no status (persiste entre aberturas).
- A regeneração continua SOMENTE pelo botão, com confirmação (tocar duas vezes em 8 s). Nunca automática.

Teste pedido ao dono: abrir o Diagnóstico do Remote, anotar o hash, tocar duas vezes em "Regenerar chave" (segundo toque em
até 8 s) e enviar o texto que aparecer (sucesso ou erro). Se o hash ainda não mudar, o texto do erro (ou o logcat `WinRemoteAuth`) diz o passo.

## Etapa 3B, Parte 1 — servidor TLS local (versão 2.4.0 / code 7)
Objetivo: infraestrutura do servidor, sem pareamento e sem música. A 3A (RemoteAuth, RemoteProtocol, diagnóstico `remotediag`) foi preservada.

Arquivos CRIADOS
- `app/src/main/java/com/example/winlauncher/RemoteServer.kt` (servidor, leitor de linhas, autoteste)
- `app/src/main/java/com/example/winlauncher/RemoteServerService.kt` (serviço em primeiro plano)

Arquivos MODIFICADOS (somente acréscimos, exceto versão)
- `app/build.gradle.kts`: versionCode 6→7, versionName 2.3.1→2.4.0.
- `app/src/main/AndroidManifest.xml`: novo `<service android:name=".RemoteServerService">` (exported=false, foregroundServiceType=specialUse + property de subtipo). Nenhuma permissão nova (INTERNET, FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE e POST_NOTIFICATIONS já existiam).
- `app/src/main/java/com/example/winlauncher/CustomizeUi.kt`: rota `"remoteserver"` em `panel()` e função `remoteServerPanel()` (antes de `mousePanel()`).
- `app/src/main/java/com/example/winlauncher/SettingsWindow.kt`: nova linha "Servidor do WinLauncher Remote" em Rede e Internet (a linha anterior passou de `})` para `}),`).
- `HANDOFF_WINLAUNCHER.md` (este arquivo).

NÃO modificados: `RemoteAuth.kt`, `RemoteProtocol.kt`, `MediaSessionHub.kt`, `debug.keystore`, `settings.gradle.kts`, `build.gradle.kts` da raiz, package name, assinatura. Nenhuma dependência nova.

### RemoteServer.kt
- `RemoteServer(ctx, port=48655, allowLoopback=false, maxClients=4, tag, idleMs=45000, pingMs=15000, events)`. Estados: STOPPED, STARTING, RUNNING, STOPPING, ERROR. `start()` nunca lança (falha => ERROR com motivo e tudo liberado); `stop()` é idempotente.
- `start()`: `RemoteAuth.init` + `RemoteAuth.ensureKey()` (cria a chave se não existir; pode apagar pareamentos se a chave tiver mudado, comportamento da 3A) + `RemoteAuth.buildServerSslContext()` + `SSLServerSocket` em 0.0.0.0 (`createServerSocket(port, backlog, InetAddress)`). Protocolos habilitados = TLSv1.3 e TLSv1.2 que o aparelho suportar; sem TLS 1.2 não liga. Sem certificado de cliente.
- Filtro de IP logo depois do `accept()`, ANTES do handshake: só `Inet4Address` em 10/8, 172.16/12, 192.168/16, 169.254/16. Loopback só com `allowLoopback=true` (usado somente nos servidores de teste). Fora disso: fecha com RST e conta em `rejectedCount()`.
- Limite de 4 clientes (contador atômico incluindo quem ainda está no handshake); o 5º é fechado na hora. Uma thread daemon por cliente (`WinRemote-<tag>-client-N`) + uma de aceitação (`WinRemote-<tag>-accept`).
- Tempos: handshake 10 s; leitura com timeout curto; mensagem incompleta por mais de 10 s => erro; sem receber nada por 45 s => desconecta; servidor manda `ping` quando fica 15 s sem receber nada e o cliente deve responder `pong` (qualquer mensagem recebida zera o relógio).
- Protocolo: o primeiro quadro tem de ser `hello` (role "remote", versão 1); o servidor responde `hello` (role "server", id = 32 primeiros hex do hash do certificado, nome = Build.MODEL). `ping`→`pong`. JSON inválido, versão errada, tipo não aceito do cliente, hello repetido, mensagem antes do hello ou maior que 16 KB => `error` + descarta o que sobrou (até 64 KB / 0,5 s, para o erro chegar) + fecha. `auth`/`command` => `error not_paired` (a conexão continua); `pair_request` => `error pairing_denied` ("ainda não disponível"). Gancho `onMessage` (pair_request, auth, command) é onde a Parte 2 entra.
- Leitor próprio `FrameReader` (privado no arquivo) em vez de `RemoteProtocol.readFrame`: o `readFrame` perde os bytes já lidos se o socket der timeout no meio da mensagem. Mesmo limite (16384 bytes sem o `\n`) e mesma decodificação (`RemoteProtocol.decode`).
- `Client.send()` é thread-safe mas NÃO deve ser chamado da thread principal (escrita em socket pode bloquear).
- `stop()`: fecha o socket de escuta, fecha todos os clientes com RST (não trava em cliente lento), espera as threads até ~2 s no total. Deve ser chamado fora da thread principal (o serviço já faz isso).
- `RemoteServer.localAddresses()`: IPv4 locais do aparelho (Wi-Fi/hotspot primeiro) para o painel.
- NÃO referencia o `MediaSessionHub`.

### RemoteServerService.kt
- `RemoteServerService.start(ctx)` / `stop(ctx)` (thread principal), `status` (estado, porta, clientes, erro), `addListener`/`removeListener` (callbacks na thread principal) e `recentLog()` (últimas 40 linhas do servidor).
- Em `onStartCommand(ACTION_START)`: `startForeground` primeiro (notificação persistente, canal `remote_server`, ícone `ic_lock`, id 4715, tipo specialUse no Android 14+), depois o servidor sobe numa thread. A notificação mostra IP:porta e o número de clientes e tem o botão "Desligar" (ACTION_STOP).
- Desligar: `shutdown()` roda `server.stop()` numa thread própria e só então `stopForeground` + `stopSelf`. Falha ao ligar (ex.: porta ocupada): `shutdown(motivo)` => estado final ERROR com o motivo, serviço encerra, nada fica ativo.
- `START_NOT_STICKY`: se o Android matar o serviço, o servidor NÃO volta sozinho (o início automático é da Parte 2). `onDestroy` ainda fecha o servidor se o serviço morrer sem o desligamento normal.
- Sem WifiLock (Parte 2): com a tela apagada o Wi-Fi do aparelho pode dormir e atrapalhar conexões.
- Se as notificações do app estiverem bloqueadas no Android, o serviço funciona mas a notificação não aparece (o painel avisa).

### Painel (Configurações > Rede e Internet > "Servidor do WinLauncher Remote")
Botão Ligar/Desligar, estado, porta, IPs locais (com a interface), clientes conectados (x de 4), protocolo/limites, hash curto do certificado (leitura sem criar chave), erro, últimos eventos e "Executar autoteste do servidor". Não há lista de pareados.

### Autoteste do servidor (`RemoteServerTest.selfTest`)
Roda em thread própria; sobe servidores de teste em porta 0 (NÃO usa a 48655 nem mexe no servidor ligado) e conecta clientes TLS reais por 127.0.0.1 com um TrustManager que fixa o hash do certificado (o mesmo que o app Remote fará). Itens: chave/certificado; regra de IPs (aceita 192.168/10/172.16–31/169.254, recusa públicos, 172.15/172.32, 100.64, loopback, 0.0.0.0, multicast, IPv6); servidor liga; handshake TLS real + certificado confere com o hash da 3A; TLS 1.2; TLS 1.3 (informativo, depende do Android); cliente com hash errado/confiança padrão recusa o handshake (informativo); hello; ping/pong; command/auth sem pareamento => not_paired com a conexão viva; ping antes do hello, JSON quebrado, versão 99, role errado => erro + fechamento; mensagem > 16 KB => too_large + fechamento; limite de 4 clientes (5º recusado, vaga liberada depois); cliente de IP não permitido (servidor de teste sem loopback) recusado antes do hello; ping do servidor e timeout de inatividade (servidor de teste com 1,5 s); desligamento (cliente conectado é desconectado, porta fecha, nenhuma thread `WinRemote-test*` sobra).

### O que FOI e o que NÃO FOI verificado (honestidade)
- NÃO compilado (este ambiente não tem kotlinc nem Android SDK): erros de compilação são possíveis; corrigir o que o GitHub Actions apontar.
- NÃO testado em aparelho: nenhum handshake TLS, nenhuma conexão, nenhum teste da interface, do serviço ou da notificação foi executado de verdade. O autoteste existe, mas ainda não foi rodado.
- Feito aqui: conferência de balanço de chaves/parênteses nos arquivos alterados e um teste da LÓGICA do leitor de linhas portada para Java (mensagem partida por timeout, duas mensagens no mesmo bloco, limite de 16384 bytes, linha cortada). Isso não prova que o código Kotlin compila nem que funciona no Android.

## FALTA — testar no aparelho (Etapa 3B, Parte 1)
1. O build do GitHub Actions compila; o APK 2.4.0 atualiza por cima da 2.3.1 sem perder dados.
2. Etapas 2 e 3A continuam funcionando (diagnóstico do YouTube Music e do Remote, regenerar chave).
3. Painel: ligar => notificação aparece, estado "LIGADO", IP e porta corretos; desligar pelo painel e pelo botão da notificação.
4. "Executar autoteste do servidor": anotar todos os itens (✔/✘/⚠), a versão do Android e o protocolo TLS negociado. Atenção a: TLS 1.2 com chave EC no Keystore, TLS 1.3, contagem de threads no desligamento.
5. Ligar com a porta 48655 ocupada (ou ligar duas vezes) deve dar erro claro e não deixar serviço/notificação.
6. Com o servidor ligado, fechar o launcher/limpar recentes: ver se o serviço continua (esperado) e se desligar ainda funciona.
7. De outro aparelho na mesma rede (ex.: `openssl s_client -connect IP:48655` ou o futuro app Remote): handshake, hello, ping. De fora da rede/IP público: recusado.
8. Hotspot: o IP do aparelho como hotspot (interface ap0/swlan0) aparece na lista e aceita clientes?

## Plano original da Parte 2 (HISTÓRICO: já implementado no código; o estado atual está na seção "Etapa 3B, Parte 2" no fim)
- Pareamento: janela de 2 minutos aberta ao tocar em "Permitir novo pareamento"; fluxo `pair_request` → `pair_challenge` → número de 6 dígitos (`RemoteAuth.pairingCode`) comparado nos dois celulares → `pair_ok(token)`; `RemoteAuth.addPaired`. Fora da janela: `pairing_denied`/`pairing_busy`. Só um pareamento pendente por vez.
- Aprovar/negar SOMENTE dentro do WinLauncher; a notificação só avisa do pedido (sem botões de aprovar).
- `auth` com `RemoteAuth.verifyPaired` (limite de tentativas/`rate_limited`), marcar `Client.authenticated`; lista e revogação de aparelhos no painel.
- Estado musical e comandos: o servidor só REGISTRA um `MediaSessionHub.Listener` (addListener) e o REMOVE (removeListener); nunca reinicia o Hub. ATENÇÃO (achado desta análise): hoje NINGUÉM mantém o Hub ligado — só a página `ytdiag` chama `MediaSessionHub.start()/stop()` (contagem de usos; TaskbarMusic, QuickMusicCard e MusicWidget não usam o Hub). Sem alguém ter chamado `start()`, o Hub não tem sessão e os comandos devolvem NO_SESSION. A Parte 2 precisa de uma decisão do dono sobre quem chama `start()` enquanto o servidor estiver ligado (por exemplo, o servidor usar um par balanceado `start()`/`stop()` da própria contagem de usos do Hub, o que não afeta os outros usuários; ou outra forma). Não chamar `stop()` fora desse par. Os callbacks do Hub vêm na thread principal: o envio para os sockets deve sair dela.
- Mensagens novas no protocolo (acréscimos em `RemoteProtocol.kt`): blocos de capa de até 16 KB com id da capa, índice, total e validação (hash/tamanho) — cada mensagem continua com limite de 16 KB nos dois sentidos.
- `command` (play_pause, next, previous) → `MediaSessionHub.togglePlayPause/next/previous` (postar na thread principal) → `command_result`.
- WifiLock enquanto o servidor estiver ligado (liberar no desligamento e no `onDestroy`).
- Opção "Iniciar o servidor junto com o launcher", desligada por padrão (preferência nova, chave com prefixo `ui_`), com `START_NOT_STICKY` mantido ou decisão explícita.
- Notificação de solicitação de pareamento (canal próprio, só informa).
- Estender o autoteste: pareamento, autenticação, comandos, blocos de capa, WifiLock liberado.
- Depois (sem compromisso): NSD (`_winlauncher._tcp.`), app WinLauncher Remote.

## FALTA — testar no aparelho real (Etapa 3A) antes da 3B
1. O build do GitHub Actions compila (o código NÃO foi compilado aqui; corrigir qualquer erro de compilação que aparecer).
2. O app atualiza por cima da versão 2.2 sem perder preferências (mesma assinatura).
3. Etapa 2 continua funcionando: página "Diagnóstico do YouTube Music", play/pause, próxima, anterior, capa, abrir o app.
4. Abrir "Diagnóstico do Remote": executar o autoteste e anotar:
   - algoritmo usado (EC P-256 ou RSA 2048, e o motivo se for RSA), local da chave, protocolos TLS listados;
   - se todos os itens essenciais aparecem com ✔;
   - o hash SHA-256 mostrado.
5. Fechar e reabrir o app: o hash deve ser o MESMO (a chave persiste).
6. "Regenerar chave": o hash deve MUDAR; deve aparecer "✔ CHAVE REGENERADA COM SUCESSO" (ou "✘ REGENERAÇÃO FALHOU" com o motivo). (Correção 3A.1)
7. Se algum item ✘ aparecer, copiar o texto do detalhe (modelo do aparelho e versão do Android também).

## Riscos e observações
- `allowBackup=true` no Manifest: chaves do Keystore não vão no backup, mas preferências podem ir. Mitigação já feita:
  pareamentos são apagados se o hash guardado não bater com o certificado atual. Não foi alterado o Manifest.
- Android 8–10 usa TLS 1.2 (TLS 1.3 só no 10+ em alguns casos); a 3B deve validar o handshake nesses níveis.
- Chave com `DIGEST_NONE` adicional: só afeta assinaturas dessa chave (que nunca sai do Keystore).
- As páginas de diagnóstico (`ytdiag` e `remotediag`) são temporárias: NÃO remover sem confirmação do dono.
- O MediaSessionHub em modo automático só escolhe sessões que "parecem YouTube Music"; outros apps exigem escolha manual
  (comportamento já testado). O Remote controlará a sessão selecionada pelo Hub.

## Regras de trabalho combinadas
- Não avançar de etapa sem autorização do dono.
- Ao fim de cada etapa: ZIP completo do projeto + este arquivo atualizado + lista exata de arquivos criados/modificados.
- Preservar package, assinatura, funcionalidades existentes e o MediaSessionHub.
- Sem Shizuku e sem servidores externos no Remote; comunicação local por Wi-Fi com TLS e pareamento seguro.


## Etapa 3B, Parte 2 — IMPLEMENTADA NO CÓDIGO (2.5.0 / code 8) — NÃO COMPILADA, NÃO TESTADA

Decisões aprovadas pelo dono: (1) o servidor controla o MediaSessionHub por attach()/detach() com start()/stop() balanceados, sem interromper outros usuários do Hub; (2) limite de tentativas mantido POR IP (5 erros = bloqueio de 60 s) nesta versão; (3) início automático com o launcher, DESLIGADO por padrão.

### Arquivos
CRIADO
- `RemoteBridgeTest.kt`: `FakeMediaPort` (Hub falso: conta start/stop/refresh, registra ouvintes e comandos, devolve o Result escolhido, publica estados na thread principal) e `RemoteBridgeTest.selfTest` (autoteste da integração).

MODIFICADOS nesta sessão (o `RemoteBridge.kt` e os acréscimos do `RemoteProtocol.kt` já vinham do ZIP parcial)
- `RemoteBridge.kt`: uso único (`finished`: depois do detach() não liga de novo); `snapshotArt()` copia/reduz a capa (máx. 320 px) NA THREAD PRINCIPAL antes de ir ao pool (o Hub pode reciclar o bitmap dele).
- `RemoteServerService.kt`: cria UM `RemoteBridge(HubPort)` ao ligar e chama `attach()` ANTES do servidor aceitar conexões; `releaseBridgeAndLocks()` (idempotente) chama `detach()`, solta o WifiLock e cancela o aviso de pareamento em `shutdown()` (inclui falha ao ligar/porta ocupada), `finishStop()` e `onDestroy()`; WifiLock (`WIFI_MODE_FULL_HIGH_PERF`, não contado, `WakeLock` não usado); notificação de pedido de pareamento (canal `remote_pairing`, importância alta, id 4716, expira em 120 s; SÓ informa, sem botões e SEM o número); API estática para o painel: `bridgeInfo`, `openPairing`, `closePairing`, `approvePairing`, `denyPairing`, `revokeDevice` (em thread própria), `addBridgeListener`/`removeBridgeListener`, `wifiLockHeld`, `autoStartIfEnabled`.
- `CustomizeUi.kt` (`remoteServerPanel`): opção "Iniciar o servidor junto com o WinLauncher"; seção Pareamento (botão "Permitir novo pareamento (2 minutos)", contagem regressiva, número de 6 dígitos com Permitir/Negar, cancelar janela); lista de aparelhos pareados com "Remover" (dois toques em 6 s); linha do WifiLock no status; segundo botão "Executar autoteste da integração"; textos atualizados.
- `Prefs.kt`: `remoteAutostart` (`ui_remote_autostart`, padrão false). `MainActivity.kt`: `window.decorView.post { RemoteServerService.autoStartIfEnabled(this) }` no fim do onCreate.
- `AndroidManifest.xml`: permissão `WAKE_LOCK` (necessária ao WifiLock). `app/build.gradle.kts`: versionCode 7→8, versionName 2.4.0→2.5.0.
NÃO modificados: `MediaSessionHub.kt`, `RemoteAuth.kt`, `RemoteServer.kt`, `debug.keystore`, package e assinatura.

### Como funciona
- Ligar: serviço em primeiro plano -> bridge.attach() (um start() do Hub, ouvinte registrado) + WifiLock -> servidor sobe numa thread. Desligar/erro/onDestroy: bridge.detach() (stop() só se o start() deu certo; remove o ouvinte) + WifiLock liberado + servidor parado.
- Pareamento: janela de 2 min aberta pelo botão; pair_request -> pair_challenge; o painel mostra o número de 6 dígitos que o Remote também calcula; Permitir/Negar SÓ dentro do WinLauncher; um pedido pendente por vez (pairing_busy); pedido pendente expira em 120 s; janela fecha ao aceitar um pedido.
- Autenticação: `auth` com `RemoteAuth.verifyPaired`; 5 erros do mesmo IP em 60 s bloqueiam o IP por 60 s (rate_limited), inclusive com token certo. Estado e capa só vão a clientes autenticados. Comandos: máx. 10 por segundo por cliente.
- Revogar: remove o pareamento e derruba (RST) todas as conexões desse aparelho; funciona também com o servidor desligado (só apaga o pareamento).
- Início automático: só quando o launcher abre (não há receptor de BOOT_COMPLETED). Se o Android recusar iniciar o serviço em segundo plano, o painel mostra o erro.

### Autoteste da integração (`RemoteBridgeTest`, botão no painel)
Sobe 3 servidores de teste (porta aleatória) + bridges com `FakeMediaPort` e clientes TLS reais por 127.0.0.1. Não usa a porta 48655, não mexe no servidor ligado nem no Hub real; usa ids `BridgeTestDevA01/B02/C03`, removidos no começo e no fim (os pareamentos reais não são tocados). Itens: Hub start/stop balanceados e bridge de uso único; start() que falha não gera stop(); pareamento sem janela negado; pareamento completo (número confere, token válido); Negar; pairing_busy; expiração da janela e do pedido; auth certo/errado/id trocado; comando sem auth; play_pause/next/previous no Hub; unavailable/no_session no command_result; rate_limited de comandos; estado só para autenticados; capa em blocos (SHA-256, artId, JPEG ≤ 320 px, cliente tardio recebe a mesma capa); revogação; 5 erros por IP; desligamento (Hub 1x start/1x stop, ouvinte removido, nenhuma thread `WinRemote-btest*`).

### O que FOI e o que NÃO FOI verificado (honestidade)
- NÃO compilado: este ambiente não tem kotlinc nem Android SDK. Só foram feitas conferência de balanço de chaves/parênteses nos arquivos alterados e checagem manual de símbolos/assinaturas contra o código existente. Erros de compilação são possíveis; corrigir o que o GitHub Actions apontar.
- NÃO executado: o autoteste da integração (e o do servidor) nunca rodou; nenhum teste em aparelho; WifiLock, notificação, painel e início automático não foram vistos funcionando.
- Teste manual possível sem o app Remote: `openssl s_client -quiet -connect IP:48655`, mandar linhas JSON (`{"v":1,"t":"hello","version":1,"deviceId":"ManualTest0001","deviceName":"openssl","role":"remote"}`, `{"v":1,"t":"ping"}`) cobre hello/ping/erros. O pareamento completo exige calcular o número (SHA-256) e só é coberto pelo autoteste da integração ou pelo futuro app Remote.

### Riscos e limites conhecidos
- Limite de tentativas por IP: em hotspot/NAT vários aparelhos podem compartilhar o IP e se bloquear juntos (aceito pelo dono nesta versão).
- Um aparelho da rede pode ocupar a janela de pareamento com um pedido; o usuário deve negar se o número não for igual ao do Remote. O nome do aparelho aparece na notificação e no painel: é texto enviado pelo cliente (controles removidos, 64 caracteres).
- Cliente não autenticado pode ocupar uma das 4 vagas (rede local, timeout de 45 s). Escrita em socket travada não tem timeout (o desligamento fecha com RST).
- WifiLock: `FULL_HIGH_PERF` está obsoleto no Android recente e pode não ser respeitado com a tela apagada; não há WakeLock de CPU (decisão de bateria). Testar com a tela apagada.
- `allowBackup=true`: pareamentos vão no backup mas a chave do Keystore não; ao restaurar, o hash não bate e os pareamentos são apagados (comportamento da 3A, testar).
- O Hub só escolhe sozinho sessões "tipo YouTube Music"; outros players exigem escolha manual (Etapa 2).

## FALTA — testar no aparelho (Etapa 3B, Parte 2)
1. O build do GitHub Actions compila (corrigir erros). O APK 2.5.0 atualiza por cima da 2.4.0.
2. Etapas 2, 3A e 3B Parte 1 continuam funcionando (ytdiag, remotediag, servidor, autoteste do servidor).
3. "Executar autoteste da integração": anotar todos os itens (✔/✘/⚠) e a versão do Android.
4. Ligar o servidor: aparece a linha "WifiLock: ativo"; o Hub funciona sem abrir o ytdiag; música do YouTube Music segue funcionando na barra de tarefas e no cartão rápido (o Remote não deve atrapalhar).
5. Desligar (painel e notificação) e fechar o launcher com o servidor ligado: nada fica ativo; o ytdiag continua fazendo seu próprio start()/stop().
6. Pareamento com o app Remote real quando existir (ou script): número igual nos dois lados, Permitir, Negar, expiração, remover.
7. Início automático: ligar a opção, fechar e abrir o launcher; desligar a opção e confirmar que não liga sozinho.
8. Tela apagada por alguns minutos com o Remote conectado: a conexão sobrevive?

## Próxima etapa sugerida
Compilar e testar a Parte 2 no aparelho; só depois iniciar o app WinLauncher Remote (projeto Android separado) e, opcionalmente, NSD (`_winlauncher._tcp.`). Não avançar sem autorização do dono.

## Etapa 1A — Permissão de notificações (POST_NOTIFICATIONS)
- `MainActivity.kt`: novo `startRemoteServerAskingNotifications()` (usado pelo botão "Ligar servidor"). No Android 13+, se a permissão não está concedida e ainda não foi pedida (`remote_notif_asked` em prefs "win"), pede uma vez e liga o servidor no `onRequestPermissionsResult` (REQ_NOTIF_REMOTE=21), concedida ou negada. Caso contrário liga direto. Guarda `remoteNotifPending` contra toques repetidos.
- `CustomizeUi.kt`: botão de ligar chama o método acima. Início automático não pede permissão. Backups em `_backup_etapa1A/`. Não compilado nem testado.

## Etapa 1B — Proteção contra regeneração da chave (CONCLUÍDA no código; NÃO compilada nem executada)
- `RemoteAuth.kt`: `regenBlockedReason()` consulta o estado real (`RemoteServerService.status.state`): bloqueia em STARTING, RUNNING e STOPPING; libera em STOPPED e ERROR. `regenerate()` chama a verificação ANTES de tocar na chave/pareamentos e lança `RegenBlockedException` (nada é alterado). Novo teste não destrutivo `regenGuardTest()` (simula estados via `testServerState`, confere que chave e pareamentos não mudam) incluído no `selfTest()` como "Proteção contra regeneração com o servidor ligado". Nenhum teste existente foi removido.
- `CustomizeUi.kt`: o botão "Regenerar chave" consulta `regenBlockedReason()` a cada toque (antes de armar e antes de confirmar), mostra a mensagem "desligue o servidor primeiro" e trata `RegenBlockedException` caso o servidor ligue entre o toque e a execução.
- Não alterados: pareamentos, protocolo, notificações (Etapa 1A), RemoteServerService, assinatura/applicationId. Backups em `_backup_etapa1B/`.
- Limite do teste: a regeneração real com servidor desligado não é exercida no autoteste (apagaria a chave e os pareamentos); só a decisão de liberar é testada.

## Etapa 2A — Timeout de autenticação (CONCLUÍDA no código; verificada numa JVM, NÃO compilada com Gradle/Android)
Arquivos modificados: `RemoteServer.kt`, `RemoteBridgeTest.kt`, `HANDOFF_WINLAUNCHER.md`. Backups em `_backup_etapa2A/`. Não alterados: protocolo, pareamento, RemoteBridge.kt, RemoteAuth.kt, limite de conexões por IP, Etapas 1A/1B.
- `RemoteServer`: novo parâmetro `authMs` (padrão `AUTH_TIMEOUT_MS = 15_000`). Uma thread vigia por servidor (`WinRemote-<tag>-watchdog`, daemon) verifica a cada ≤250 ms e fecha com RST todo cliente que NUNCA se autenticou e passou de `authMs` desde o accept() (o prazo inclui o handshake TLS; cliente mudo, cliente só com hello e cliente ativo com ping/pong são todos desconectados; atividade não estende o prazo; fechar o socket também destrava handshake parado).
- Clientes autenticados nunca são desconectados por isso. `Client.authenticated` agora tem setter que marca `authSeen`; se o pareamento for revogado depois (`authenticated=false`) o prazo não reabre.
- Liberação: a thread do cliente cai no `finish()` existente (remove da lista, devolve a vaga, `onClientClosed` -> o bridge descarta pedido de pareamento pendente do cliente). A vigia é interrompida e aguardada no `stop()`; `liveThreads()` a conta. Novos: `authTimeoutMs`, `authTimeoutCount()`.
- ATENÇÃO (decisão do dono): o prazo é duro e vale também para pedido de pareamento aguardando "Permitir" (antes o pedido durava até 120 s; agora o usuário precisa tocar em Permitir em até 15 s desde a conexão do Remote). Para isentar clientes com pedido pendente, basta o vigia pular o cliente que for o `pending` do bridge (alteração pequena, não feita).
- O servidor não envia mensagem de erro antes de fechar por timeout (RST direto, para o vigia nunca travar em escrita); o cliente vê a conexão cair.
- Testes novos: `RemoteServerTest.selfTest` +7 itens (prazo padrão 15 s; 15 s reais ~15 s de duração; cliente mudo; cliente ativo sem autenticar; TCP sem handshake TLS; autenticado sobrevive e o vizinho não autenticado cai, inclusive após `authenticated=false`; vagas voltam e threads não sobram; desligamento confere `liveThreads()==0`). `RemoteBridgeTest.selfTest` +1 item (servidor 4, prazo 3 s, id `BridgeTestDevD04`: pedido pendente descartado, cliente mudo desconectado, autenticado permanece, novo pedido aceito depois). Nenhum teste existente removido. O autoteste do servidor fica ~17 s mais longo.
- VERIFICAÇÃO REAL feita aqui (kotlinc 1.9.24 + JVM 21, pasta `_harness_jvm_etapa2A/`): `RemoteProtocol.kt`, `RemoteServer.kt`, `RemoteBridge.kt`, `RemoteBridgeTest.kt` compilados juntos e os dois autotestes executados com TLS real em 127.0.0.1: servidor 23/23 OK (33 s), integração 20/20 OK (9 s), incluindo todos os testes antigos. Prazo real medido ~15,0–15,2 s.
- LIMITES: o harness usa stubs de `android.*`, `org.json` e `MediaSessionHub`, e um `RemoteAuth` falso (chave de keytool, pareamentos em memória). NÃO foram compilados nem executados: `RemoteAuth.kt` real, Android Keystore, Gradle/AGP, Conscrypt (comportamento de `close()` durante handshake no Android), notificações, painel. Rodar os dois autotestes no aparelho e anotar ✔/✘.
- Pendente para o aparelho: confirmar que o prazo de 15 s é suficiente para o fluxo real de pareamento (tocar em Permitir).

