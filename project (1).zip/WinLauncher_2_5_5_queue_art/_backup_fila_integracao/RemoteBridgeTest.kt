package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/**
 * Porta de música FALSA para os autotestes da integração (Etapa 3B, Parte 2). Faz o papel do [MediaSessionHub] sem
 * precisar de um player tocando: registra start()/stop(), ouvintes e comandos, devolve o [Result] que o teste mandar e
 * publica estados (com ou sem capa) nos ouvintes na THREAD PRINCIPAL, como o Hub de verdade faz.
 */
class FakeMediaPort : MediaPort {
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<MediaSessionHub.Listener>()

    val startCalls = AtomicInteger(0)
    val stopCalls = AtomicInteger(0)
    val refreshCalls = AtomicInteger(0)
    val commands = CopyOnWriteArrayList<RemoteProtocol.Command>()

    /** true = start() lança exceção (simula o Hub falhando ao ligar). */
    @Volatile
    var failStart = false

    /** Resultado devolvido pelos próximos comandos. */
    @Volatile
    var result: MediaSessionHub.Result = MediaSessionHub.Result.OK

    @Volatile
    var current: MediaSessionHub.State = idle()

    /** Fila "publicada pelo app" de mentira (começa sem sessão). */
    @Volatile
    var currentQueue: MediaSessionHub.Queue = MediaSessionHub.NO_QUEUE

    fun listenerCount(): Int = listeners.size

    override fun start(ctx: Context) {
        if (failStart) throw IllegalStateException("falha simulada ao ligar o Hub")
        startCalls.incrementAndGet()
    }

    override fun stop() {
        stopCalls.incrementAndGet()
    }

    override fun addListener(l: MediaSessionHub.Listener) {
        listeners.addIfAbsent(l)
    }

    override fun removeListener(l: MediaSessionHub.Listener) {
        listeners.remove(l)
    }

    override fun refresh() {
        refreshCalls.incrementAndGet()
    }

    override fun state(): MediaSessionHub.State = current

    override fun queue(): MediaSessionHub.Queue = currentQueue

    override fun command(c: RemoteProtocol.Command): MediaSessionHub.Result {
        commands.add(c)
        return result
    }

    /** Publica uma fila como o Hub faria: guarda como atual e chama [MediaSessionHub.Listener.onQueue] na thread principal. */
    fun emitQueue(q: MediaSessionHub.Queue) {
        currentQueue = q
        main.post {
            for (l in listeners) l.onQueue(q)
        }
    }

    /** Publica um estado como o Hub faria: guarda como atual e chama os ouvintes na thread principal. */
    fun emit(s: MediaSessionHub.State) {
        current = s
        main.post {
            for (l in listeners) l.onMediaState(s)
        }
    }

    companion object {
        fun idle(): MediaSessionHub.State = MediaSessionHub.State(
            hasSession = false, access = true, pkg = "", appLabel = "", selectedPkg = "", sessions = emptyList(),
            playing = false, stateCode = -1, title = "", artist = "", album = "", art = null, artInfo = "",
            actions = 0L, canPlay = false, canPause = false, canNext = false, canPrev = false,
            durationMs = 0L, positionMs = 0L, speed = 1f, customActions = emptyList()
        )

        fun playing(title: String, artist: String, art: Bitmap? = null): MediaSessionHub.State = MediaSessionHub.State(
            hasSession = true, access = true, pkg = "test.pkg", appLabel = "App de teste", selectedPkg = "", sessions = emptyList(),
            playing = true, stateCode = 3, title = title, artist = artist, album = "Álbum de teste", art = art, artInfo = "teste",
            actions = 0L, canPlay = true, canPause = true, canNext = true, canPrev = true,
            durationMs = 180_000L, positionMs = 1_000L, speed = 1f, customActions = emptyList()
        )
    }
}

/**
 * Autoteste da integração Remote <-> Hub (Etapa 3B, Parte 2). Sobe servidores TLS de teste em portas efêmeras com um
 * [RemoteBridge] ligado a uma [FakeMediaPort] e conecta clientes TLS reais por 127.0.0.1. NÃO usa a porta 48655, NÃO
 * mexe no servidor "de verdade" nem no MediaSessionHub real. Os aparelhos de teste usam ids próprios ("BridgeTestDev…")
 * e são removidos no fim (e no começo, caso uma execução anterior tenha sido interrompida): os pareamentos reais não são tocados.
 * Chame fora da thread principal (leva alguns segundos; a thread principal precisa estar livre porque o bridge posta nela).
 *
 * Etapa 3, Bloco 3 (fila de capas): os bridges 5 (fila normal), 6 (fila de 2 mensagens) e 7 (cliente que para de ler, buffer de envio de 8 KB)
 * testam a thread única de capas, o descarte de trabalho obsoleto, o [RemoteBridge.Out.postArt] (capa inteira ou nada) e o detach. Aparelhos de teste E, F e G.
 */
object RemoteBridgeTest {

    private const val ID_A = "BridgeTestDevA01"
    private const val ID_B = "BridgeTestDevB02"
    private const val ID_C = "BridgeTestDevC03"
    private const val ID_D = "BridgeTestDevD04"

    // Etapa 3, Bloco 3 (fila de capas): um aparelho de teste por bridge de capas
    private const val ID_E = "BridgeTestDevE05"
    private const val ID_F = "BridgeTestDevF06"
    private const val ID_G = "BridgeTestDevG07"
    private val TEST_IDS = listOf(ID_A, ID_B, ID_C, ID_D, ID_E, ID_F, ID_G)

    private class Pin(private val expected: ByteArray) : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {
            throw CertificateException("não usado")
        }

        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {
            val c = chain?.firstOrNull() ?: throw CertificateException("servidor não apresentou certificado")
            if (!MessageDigest.isEqual(RemoteAuth.fingerprint(c), expected)) throw CertificateException("hash do certificado não confere")
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    /** Cliente de teste. Guarda os bytes já lidos quando o socket dá timeout no meio de uma mensagem. */
    private class Cli(val s: SSLSocket) {
        private val input: InputStream = s.inputStream
        private val out = s.outputStream
        private val acc = ByteArrayOutputStream()
        private val buf = ByteArray(8192)
        private var pos = 0
        private var lim = 0

        fun send(m: RemoteProtocol.Message) {
            out.write(RemoteProtocol.encodeFrame(m))
            out.flush()
        }

        /** Próxima mensagem; null = o servidor fechou limpo. Pode lançar SocketTimeoutException (estado preservado). */
        fun recv(): RemoteProtocol.Message? {
            while (true) {
                var i = pos
                while (i < lim && buf[i] != '\n'.code.toByte()) i++
                if (i < lim) {
                    acc.write(buf, pos, i - pos)
                    pos = i + 1
                    val line = acc.toString("UTF-8")
                    acc.reset()
                    return RemoteProtocol.decode(line)
                }
                acc.write(buf, pos, lim - pos)
                pos = lim
                if (acc.size() > RemoteProtocol.MAX_FRAME_BYTES + 16) throw IOException("linha grande demais")
                val n = input.read(buf, 0, buf.size)
                if (n < 0) {
                    if (acc.size() == 0) return null
                    throw IOException("conexão encerrada no meio de uma mensagem")
                }
                pos = 0
                lim = n
            }
        }

        fun close() {
            try {
                s.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun now(): Long = SystemClock.elapsedRealtime()

    private fun hello(id: String, caps: List<String> = emptyList()) =
        RemoteProtocol.Message.Hello(RemoteProtocol.VERSION, id, "Autoteste $id".take(RemoteProtocol.MAX_NAME), "remote", caps)

    private fun connect(port: Int, trust: X509TrustManager, rcvBuf: Int = 0): Cli {
        val c = SSLContext.getInstance("TLS")
        c.init(null, arrayOf(trust), null)
        val raw = Socket()
        // Etapa 3, Bloco 3: buffer de recepção pequeno (antes de conectar) para simular cliente lento
        if (rcvBuf > 0) raw.receiveBufferSize = rcvBuf
        try {
            raw.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 3000)
        } catch (e: Throwable) {
            try {
                raw.close()
            } catch (x: Exception) {
            }
            throw e
        }
        val s = c.socketFactory.createSocket(raw, "127.0.0.1", port, true) as SSLSocket
        try {
            s.soTimeout = 5000
            s.startHandshake()
        } catch (e: Throwable) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            throw e
        }
        return Cli(s)
    }

    /** Conecta e faz o hello (já consome o hello do servidor). */
    private fun open(port: Int, trust: X509TrustManager, id: String, rcvBuf: Int = 0, caps: List<String> = emptyList()): Cli {
        val c = connect(port, trust, rcvBuf)
        try {
            c.send(hello(id, caps))
            await(c) { it is RemoteProtocol.Message.Hello && it.role == "server" }
        } catch (e: Throwable) {
            c.close()
            throw e
        }
        return c
    }

    /** Espera a primeira mensagem que [accept] aceita (as outras são descartadas). */
    private fun await(c: Cli, ms: Long = 4000L, accept: (RemoteProtocol.Message) -> Boolean): RemoteProtocol.Message {
        val end = now() + ms
        while (true) {
            val left = end - now()
            if (left <= 0L) throw IllegalStateException("tempo esgotado esperando a mensagem esperada")
            c.s.soTimeout = left.toInt().coerceAtLeast(50)
            val m = (try {
                c.recv()
            } catch (e: SocketTimeoutException) {
                throw IllegalStateException("tempo esgotado esperando a mensagem esperada")
            }) ?: throw IllegalStateException("o servidor fechou a conexão antes da mensagem esperada")
            if (accept(m)) return m
        }
    }

    private fun awaitError(c: Cli, code: RemoteProtocol.ErrorCode, ms: Long = 4000L): RemoteProtocol.Message.ErrorMsg {
        val m = await(c, ms) { it is RemoteProtocol.Message.ErrorMsg }
        m as RemoteProtocol.Message.ErrorMsg
        if (m.code != code) throw IllegalStateException("esperava erro ${code.wire}, veio ${m.code.wire}")
        return m
    }

    /** Falha se chegar algo que [reject] reprove dentro de [ms]; conexão fechada também encerra a espera. */
    private fun expectNone(c: Cli, ms: Long, reject: (RemoteProtocol.Message) -> Boolean) {
        val end = now() + ms
        while (now() < end) {
            c.s.soTimeout = (end - now()).toInt().coerceAtLeast(50)
            val m = (try {
                c.recv()
            } catch (e: SocketTimeoutException) {
                return
            } catch (e: IOException) {
                return
            }) ?: return
            if (reject(m)) throw IllegalStateException("recebeu \"${m.type}\" sem estar autorizado")
        }
    }

    private fun expectClosed(c: Cli, ms: Long = 3000L) {
        val end = now() + ms
        while (now() < end) {
            c.s.soTimeout = (end - now()).toInt().coerceAtLeast(100)
            try {
                if (c.recv() == null) return
            } catch (e: SocketTimeoutException) {
                break
            } catch (e: IOException) {
                return
            } catch (e: RemoteProtocol.ProtocolException) {
                return
            }
        }
        throw IllegalStateException("a conexão deveria ter sido encerrada pelo servidor")
    }

    private fun waitUntil(ms: Long, cond: () -> Boolean): Boolean {
        val end = now() + ms
        while (now() < end) {
            if (cond()) return true
            try {
                Thread.sleep(40)
            } catch (e: InterruptedException) {
                return cond()
            }
        }
        return cond()
    }

    private fun check(checks: MutableList<RemoteAuth.Check>, name: String, essential: Boolean = true, block: () -> String) {
        try {
            checks.add(RemoteAuth.Check(name, true, block(), essential))
        } catch (e: Throwable) {
            checks.add(RemoteAuth.Check(name, false, e.javaClass.simpleName + ": " + (e.message ?: ""), essential))
        }
    }

    private fun testThreads(): List<String> =
        Thread.getAllStackTraces().keys.filter { it.isAlive && it.name.startsWith("WinRemote-btest") }.map { it.name }

    private fun isPaired(id: String): Boolean = RemoteAuth.pairedList().any { it.id == id }

    private fun cleanup() {
        for (id in TEST_IDS) {
            try {
                RemoteAuth.removePaired(id)
            } catch (e: Throwable) {
            }
        }
    }

    /** Pareia [id] pelo caminho completo (janela, pedido, número conferido, Permitir). Devolve a conexão (já autenticada) e o token. */
    private fun pairDevice(br: RemoteBridge, port: Int, pin: X509TrustManager, fp: ByteArray, id: String): Pair<Cli, String> {
        if (!br.openPairingWindow()) throw IllegalStateException("não foi possível abrir a janela de pareamento")
        val c = open(port, pin, id)
        try {
            val nonce = RemoteAuth.newNonce()
            c.send(RemoteProtocol.Message.PairRequest(id, "Autoteste " + id.takeLast(3), nonce))
            val ch = await(c) { it is RemoteProtocol.Message.PairChallenge || it is RemoteProtocol.Message.ErrorMsg }
            if (ch !is RemoteProtocol.Message.PairChallenge) throw IllegalStateException("esperava pair_challenge, veio: $ch")
            val code = RemoteAuth.pairingCode(fp, nonce, ch.serverNonce)
            if (!waitUntil(2000L) { br.info().pending?.code == code }) {
                throw IllegalStateException("o número mostrado no WinLauncher não confere com o calculado pelo cliente")
            }
            if (br.info().windowOpen) throw IllegalStateException("a janela deveria fechar quando um pedido é aceito")
            if (!br.approve()) throw IllegalStateException("approve() devolveu false")
            val ok = await(c) { it is RemoteProtocol.Message.PairOk || it is RemoteProtocol.Message.ErrorMsg }
            if (ok !is RemoteProtocol.Message.PairOk) throw IllegalStateException("esperava pair_ok, veio: $ok")
            return Pair(c, ok.token)
        } catch (e: Throwable) {
            c.close()
            throw e
        }
    }

    private fun makeCover(): Bitmap {
        val b = Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val paint = Paint()
        val rnd = java.util.Random(42L)
        cv.drawColor(Color.rgb(30, 60, 90))
        for (i in 0 until 400) {
            paint.color = Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
            val x = rnd.nextInt(600).toFloat()
            val y = rnd.nextInt(440).toFloat()
            cv.drawRect(x, y, x + rnd.nextInt(60) + 4, y + rnd.nextInt(60) + 4, paint)
        }
        return b
    }

    /** Lê blocos de capa até chegar um "state" com artId; devolve a imagem remontada, o artId e a quantidade de blocos. */
    private fun collectArt(c: Cli): Triple<ByteArray, String, Int> {
        val asm = RemoteProtocol.ArtAssembler()
        var img: ByteArray? = null
        var chunks = 0
        while (true) {
            val m = await(c, 7000L) {
                it is RemoteProtocol.Message.ArtChunk || (it is RemoteProtocol.Message.StateMsg && it.artId.isNotEmpty())
            }
            if (m is RemoteProtocol.Message.ArtChunk) {
                chunks++
                val r = asm.add(m)
                if (r != null) img = r
            } else if (m is RemoteProtocol.Message.StateMsg) {
                val done = img ?: throw IllegalStateException("o estado chegou com artId antes da capa completa")
                return Triple(done, m.artId, chunks)
            }
        }
    }

    // ------------------------------------------------------------------ Etapa 3, Bloco 3: auxiliares da fila de capas

    /** Capa diferente para cada [seed] (artId diferente), com ruído suficiente para virar vários blocos de 9000 bytes. */
    private fun makeCoverSeed(seed: Int): Bitmap {
        val b = Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val paint = Paint()
        val rnd = java.util.Random(1000L + seed)
        cv.drawColor(Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)))
        for (i in 0 until 900) {
            paint.color = Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
            val x = rnd.nextInt(620).toFloat()
            val y = rnd.nextInt(460).toFloat()
            cv.drawRect(x, y, x + rnd.nextInt(30) + 3, y + rnd.nextInt(30) + 3, paint)
        }
        return b
    }

    /** Conexão nova de um aparelho já pareado: hello + auth, espera o auth_ok. Depois dele chegam o estado (e a capa, se houver). */
    private fun authOpen(port: Int, trust: X509TrustManager, id: String, token: String, rcvBuf: Int = 0): Cli {
        val c = open(port, trust, id, rcvBuf)
        try {
            c.send(RemoteProtocol.Message.Auth(id, token))
            await(c) { it is RemoteProtocol.Message.AuthOk }
        } catch (e: Throwable) {
            c.close()
            throw e
        }
        return c
    }

    /** O que um cliente viu na conexão, como o app Remote veria (capas remontadas e conferidas pelo [RemoteProtocol.ArtAssembler]). */
    private class ArtStream(
        /** ids das capas que chegaram inteiras e conferem com o hash, na ordem. */
        val completed: List<String>,
        /** quantas vezes chegou o bloco 0 de cada capa. */
        val zeroChunks: Map<String, Int>,
        val chunks: Int,
        /** artIds citados por estados antes de a capa correspondente ter chegado inteira (deve ser vazio). */
        val dangling: List<String>,
        /** o estado que encerrou a leitura. */
        val last: RemoteProtocol.Message.StateMsg
    )

    /** Lê blocos de capa e estados até [done] aceitar um estado. Estoura o tempo [ms] => IllegalStateException. */
    private fun readArt(c: Cli, ms: Long, done: (RemoteProtocol.Message.StateMsg) -> Boolean): ArtStream {
        val asm = RemoteProtocol.ArtAssembler()
        val completed = ArrayList<String>()
        val zero = HashMap<String, Int>()
        val dangling = ArrayList<String>()
        var chunks = 0
        val end = now() + ms
        while (true) {
            val left = end - now()
            if (left <= 0L) {
                throw IllegalStateException("tempo esgotado esperando o estado final (blocos recebidos: $chunks, capas completas: ${completed.size})")
            }
            val m = await(c, left) { it is RemoteProtocol.Message.ArtChunk || it is RemoteProtocol.Message.StateMsg }
            if (m is RemoteProtocol.Message.ArtChunk) {
                chunks++
                if (m.index == 0) zero[m.artId] = (zero[m.artId] ?: 0) + 1
                val img = asm.add(m)
                if (img != null) completed.add(RemoteProtocol.artIdOf(RemoteProtocol.sha256Hex(img)))
            } else if (m is RemoteProtocol.Message.StateMsg) {
                if (m.artId.isNotEmpty() && !completed.contains(m.artId)) dangling.add(m.artId)
                if (done(m)) return ArtStream(completed, zero, chunks, dangling, m)
            }
        }
    }

    /** Tudo o que chegar em [ms] (sem exigir nada). Timeout de leitura encerra a janela; conexão fechada também. */
    private fun readWindow(c: Cli, ms: Long): List<RemoteProtocol.Message> {
        val out = ArrayList<RemoteProtocol.Message>()
        val end = now() + ms
        while (now() < end) {
            c.s.soTimeout = (end - now()).toInt().coerceAtLeast(50)
            val m: RemoteProtocol.Message? = try {
                c.recv()
            } catch (e: SocketTimeoutException) {
                null
            }
            if (m == null) break
            out.add(m)
        }
        return out
    }

    private fun recycleAll(list: List<Bitmap>) {
        for (b in list) {
            try {
                b.recycle()
            } catch (e: Throwable) {
            }
        }
    }

    private fun artThreadNames(): List<String> = testThreads().filter { it.endsWith("-art") && (it.contains("btest5") || it.contains("btest6") || it.contains("btest7")) }

    fun selfTest(ctx: Context): List<RemoteAuth.Check> {
        val checks = ArrayList<RemoteAuth.Check>()
        val app = ctx.applicationContext
        RemoteAuth.init(app)

        var fpHolder: ByteArray? = null
        check(checks, "Chave e certificado do servidor") {
            val r = RemoteAuth.ensureKey()
            fpHolder = r.fingerprint
            r.algorithm + ", SHA-256 " + RemoteAuth.shortFingerprint(r.fingerprint) + "…"
        }
        val fp = fpHolder
        if (fp == null) {
            checks.add(RemoteAuth.Check("Demais testes", false, "não executados (sem chave/certificado)"))
            return checks
        }
        val pin = Pin(fp)
        cleanup()

        val fake = FakeMediaPort()
        val srv = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest1", maxPerIp = 16)
        val br = RemoteBridge(app, srv, fake, tag = "btest1", pairWindowMs = 5000L, pendingMs = 5000L)
        val srv2 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest2", maxPerIp = 16)
        val br2 = RemoteBridge(app, srv2, FakeMediaPort(), tag = "btest2", pairWindowMs = 700L, pendingMs = 900L)
        val srv3 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest3", maxPerIp = 16)
        val fake3 = FakeMediaPort()
        val br3 = RemoteBridge(app, srv3, fake3, tag = "btest3", pairWindowMs = 5000L, pendingMs = 5000L)
        // Etapa 2A: servidor com prazo de autenticação curto (3 s, folga para o pareamento no aparelho) para testar o timeout junto com o pareamento
        val authTest = 3000L
        val srv4 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest4", authMs = authTest, maxPerIp = 16)
        val br4 = RemoteBridge(app, srv4, FakeMediaPort(), tag = "btest4", pairWindowMs = 5000L, pendingMs = 5000L)
        val lifeFake = FakeMediaPort()
        val lifeBr = RemoteBridge(app, RemoteServer(app, port = 0, allowLoopback = true, tag = "btestlife"), lifeFake, tag = "btestlife")
        val failFake = FakeMediaPort()
        failFake.failStart = true
        val failBr = RemoteBridge(app, RemoteServer(app, port = 0, allowLoopback = true, tag = "btestfail"), failFake, tag = "btestfail")

        // Etapa 3, Bloco 3 (fila de capas): bridge 5 = fila normal; bridge 6 = fila de só 2 mensagens; bridge 7 = envio travável (buffer de 8 KB, prazo de escrita de 120 s)
        val fake5 = FakeMediaPort()
        val srv5 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest5", maxPerIp = 16)
        val br5 = RemoteBridge(app, srv5, fake5, tag = "btest5", pairWindowMs = 5000L, pendingMs = 5000L)
        val fake6 = FakeMediaPort()
        val srv6 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest6", maxPerIp = 16)
        val br6 = RemoteBridge(app, srv6, fake6, tag = "btest6", pairWindowMs = 5000L, pendingMs = 5000L, maxQueue = 2)
        val fake7 = FakeMediaPort()
        val srv7 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "btest7", writeMs = 120_000L, sndBufBytes = 8192, maxPerIp = 16)
        val br7 = RemoteBridge(app, srv7, fake7, tag = "btest7", pairWindowMs = 5000L, pendingMs = 5000L)

        val conns = ArrayList<Cli>()
        fun track(c: Cli): Cli {
            conns.add(c)
            return c
        }

        /** Fecha uma conexão temporária do teste e libera a vaga (as longas, a1 e a2, só fecham no fim). */
        fun drop(c: Cli) {
            c.close()
            conns.remove(c)
        }

        var tokenA: String? = null
        var a1: Cli? = null
        var a2: Cli? = null
        var bmp: Bitmap? = null
        try {
            // 1) ciclo de vida do Hub: um start()/stop() balanceado, ouvinte registrado e removido
            check(checks, "Hub: attach()/detach() fazem um único start()/stop() balanceado") {
                lifeBr.attach()
                lifeBr.attach()
                if (lifeFake.startCalls.get() != 1) throw IllegalStateException("start() chamado ${lifeFake.startCalls.get()}x (esperado 1)")
                if (lifeFake.listenerCount() != 1) throw IllegalStateException("ouvintes registrados: ${lifeFake.listenerCount()} (esperado 1)")
                lifeBr.detach()
                lifeBr.detach()
                if (lifeFake.stopCalls.get() != 1) throw IllegalStateException("stop() chamado ${lifeFake.stopCalls.get()}x (esperado 1)")
                if (lifeFake.listenerCount() != 0) throw IllegalStateException("o ouvinte não foi removido")
                lifeBr.attach()
                if (lifeFake.startCalls.get() != 1) throw IllegalStateException("um bridge já encerrado não pode ligar o Hub de novo")
                "start 1x, stop 1x, ouvinte removido; attach/detach repetidos são ignorados; bridge encerrado não religa"
            }
            check(checks, "Hub: se o start() falhar, o detach() não chama stop()") {
                failBr.attach()
                failBr.detach()
                if (failFake.stopCalls.get() != 0) throw IllegalStateException("stop() chamado sem start() ter dado certo")
                "stop() não foi chamado (não derruba quem estiver usando o Hub)"
            }

            // 2) servidores de teste
            var port = 0
            var port2 = 0
            var port3 = 0
            var port4 = 0
            check(checks, "Servidores de teste ligam (porta aleatória) com o bridge ligado") {
                br.attach()
                br2.attach()
                br3.attach()
                br4.attach()
                if (fake.startCalls.get() != 1 || fake.listenerCount() != 1) throw IllegalStateException("attach() não ligou o Hub de teste")
                if (!srv.start()) throw IllegalStateException("servidor 1 não ligou: " + srv.lastError)
                if (!srv2.start()) throw IllegalStateException("servidor 2 não ligou: " + srv2.lastError)
                if (!srv3.start()) throw IllegalStateException("servidor 3 não ligou: " + srv3.lastError)
                if (!srv4.start()) throw IllegalStateException("servidor 4 não ligou: " + srv4.lastError)
                port4 = srv4.boundPort
                port = srv.boundPort
                port2 = srv2.boundPort
                port3 = srv3.boundPort
                "portas $port, $port2 e $port3 (a porta real ${RemoteProtocol.DEFAULT_PORT} não é usada)"
            }
            if (port == 0 || port2 == 0 || port3 == 0 || port4 == 0) {
                checks.add(RemoteAuth.Check("Demais testes da integração", false, "não executados (os servidores de teste não ligaram)"))
                return checks
            }

            // 3) pareamento
            check(checks, "Pareamento: sem a janela aberta o pedido é negado") {
                val c = track(open(port, pin, ID_B))
                c.send(RemoteProtocol.Message.PairRequest(ID_B, "Autoteste B", RemoteAuth.newNonce()))
                awaitError(c, RemoteProtocol.ErrorCode.PAIRING_DENIED)
                drop(c)
                if (isPaired(ID_B)) throw IllegalStateException("o aparelho ficou pareado sem permissão")
                "pairing_denied e nada foi salvo"
            }
            check(checks, "Pareamento: número de 6 dígitos confere e Permitir conclui (pair_ok + token)") {
                val (c, token) = pairDevice(br, port, pin, fp, ID_A)
                a1 = track(c)
                tokenA = token
                if (!RemoteAuth.verifyPaired(ID_A, token)) throw IllegalStateException("o token entregue não confere com o guardado")
                if (!waitUntil(2000L) { br.info().connectedIds.contains(ID_A) }) throw IllegalStateException("o aparelho não aparece como conectado")
                await(c) { it is RemoteProtocol.Message.StateMsg }
                "número igual nos dois lados, janela fechada ao aceitar o pedido, token válido e primeiro estado recebido"
            }
            check(checks, "Pareamento: Negar recusa e não salva nada") {
                if (!br.openPairingWindow()) throw IllegalStateException("não abriu a janela")
                val c = track(open(port, pin, ID_B))
                c.send(RemoteProtocol.Message.PairRequest(ID_B, "Autoteste B", RemoteAuth.newNonce()))
                await(c) { it is RemoteProtocol.Message.PairChallenge }
                if (!waitUntil(2000L) { br.info().pending != null }) throw IllegalStateException("o pedido não apareceu no painel")
                if (!br.deny()) throw IllegalStateException("deny() devolveu false")
                awaitError(c, RemoteProtocol.ErrorCode.PAIRING_DENIED)
                drop(c)
                if (isPaired(ID_B)) throw IllegalStateException("ficou pareado depois de Negar")
                if (br.info().pending != null) throw IllegalStateException("o pedido continuou pendente")
                "pairing_denied entregue ao aparelho, nada salvo"
            }
            check(checks, "Pareamento: só um pedido pendente por vez (pairing_busy)") {
                if (!br.openPairingWindow()) throw IllegalStateException("não abriu a janela")
                val b = track(open(port, pin, ID_B))
                b.send(RemoteProtocol.Message.PairRequest(ID_B, "Autoteste B", RemoteAuth.newNonce()))
                await(b) { it is RemoteProtocol.Message.PairChallenge }
                val c = track(open(port, pin, ID_C))
                c.send(RemoteProtocol.Message.PairRequest(ID_C, "Autoteste C", RemoteAuth.newNonce()))
                awaitError(c, RemoteProtocol.ErrorCode.PAIRING_BUSY)
                br.deny()
                awaitError(b, RemoteProtocol.ErrorCode.PAIRING_DENIED)
                drop(b)
                drop(c)
                "o segundo pedido recebeu pairing_busy; o primeiro foi negado e liberou a vaga"
            }
            check(checks, "Pareamento: a janela expira e o pedido pendente expira") {
                val c = track(open(port2, pin, ID_B))
                if (!br2.openPairingWindow()) throw IllegalStateException("não abriu a janela (bridge 2)")
                if (!waitUntil(2500L) { !br2.info().windowOpen }) throw IllegalStateException("a janela não fechou sozinha")
                c.send(RemoteProtocol.Message.PairRequest(ID_B, "Autoteste B", RemoteAuth.newNonce()))
                awaitError(c, RemoteProtocol.ErrorCode.PAIRING_DENIED)
                drop(c)

                // a conexão é aberta ANTES de abrir a janela curta (o handshake TLS pode demorar mais que 0,7 s em aparelho lento)
                val d = track(open(port2, pin, ID_B))
                if (!br2.openPairingWindow()) throw IllegalStateException("não abriu a janela de novo")
                d.send(RemoteProtocol.Message.PairRequest(ID_B, "Autoteste B", RemoteAuth.newNonce()))
                await(d) { it is RemoteProtocol.Message.PairChallenge }
                awaitError(d, RemoteProtocol.ErrorCode.PAIRING_DENIED, 4000L)
                drop(d)
                if (br2.info().pending != null) throw IllegalStateException("o pedido expirado continuou pendente")
                if (isPaired(ID_B)) throw IllegalStateException("ficou pareado depois de expirar")
                "janela (0,7 s) e pedido (0,9 s) de teste expiraram; nada foi salvo"
            }

            // 4) autenticação
            check(checks, "Autenticação: token certo entra (auth_ok + estado); token errado e id trocado são recusados") {
                val token = tokenA ?: throw IllegalStateException("pré-requisito: o pareamento do aparelho A falhou")
                val c = track(open(port, pin, ID_A))
                c.send(RemoteProtocol.Message.Auth(ID_A, RemoteAuth.newToken()))
                awaitError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                c.send(RemoteProtocol.Message.Auth("BridgeTestDevZZ9", token))
                awaitError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                c.send(RemoteProtocol.Message.Auth(ID_A, token))
                await(c) { it is RemoteProtocol.Message.AuthOk }
                await(c) { it is RemoteProtocol.Message.StateMsg }
                a2 = c
                "a conexão continuou viva depois dos erros; com o token certo veio auth_ok e o estado atual"
            }

            // 5) comandos
            check(checks, "Comandos: sem autenticar são recusados (not_paired) e não chegam ao Hub") {
                val c = track(open(port, pin, ID_C))
                val before = fake.commands.size
                c.send(RemoteProtocol.Message.CommandMsg(77L, RemoteProtocol.Command.NEXT))
                val e = awaitError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                if (e.id != 77L) throw IllegalStateException("o erro não trouxe o id do comando")
                drop(c)
                if (fake.commands.size != before) throw IllegalStateException("o comando chegou ao Hub sem autenticação")
                "not_paired com o id do comando; Hub não foi acionado"
            }
            check(checks, "Comandos: play/pause, próxima e anterior chegam ao Hub e voltam com command_result") {
                val c = a2 ?: throw IllegalStateException("pré-requisito: autenticação falhou")
                fake.commands.clear()
                fake.result = MediaSessionHub.Result.OK
                val list = listOf(RemoteProtocol.Command.PLAY_PAUSE, RemoteProtocol.Command.NEXT, RemoteProtocol.Command.PREVIOUS)
                for ((i, cmd) in list.withIndex()) {
                    val id = 10L + i
                    c.send(RemoteProtocol.Message.CommandMsg(id, cmd))
                    val r = await(c) { it is RemoteProtocol.Message.CommandResult && it.id == id }
                    r as RemoteProtocol.Message.CommandResult
                    if (!r.ok) throw IllegalStateException("command_result de $cmd veio com falha")
                }
                if (fake.commands.toList() != list) throw IllegalStateException("o Hub recebeu ${fake.commands} em vez de $list")
                "ordem e resultados corretos"
            }
            check(checks, "Comandos: falhas do Hub viram erro certo no command_result (unavailable, no_session)") {
                val c = a2 ?: throw IllegalStateException("pré-requisito: autenticação falhou")
                try {
                    fake.result = MediaSessionHub.Result.UNAVAILABLE
                    c.send(RemoteProtocol.Message.CommandMsg(20L, RemoteProtocol.Command.NEXT))
                    val r1 = await(c) { it is RemoteProtocol.Message.CommandResult && it.id == 20L } as RemoteProtocol.Message.CommandResult
                    if (r1.ok || r1.error != RemoteProtocol.ErrorCode.UNAVAILABLE) throw IllegalStateException("esperava unavailable, veio $r1")
                    fake.result = MediaSessionHub.Result.NO_SESSION
                    c.send(RemoteProtocol.Message.CommandMsg(21L, RemoteProtocol.Command.PLAY_PAUSE))
                    val r2 = await(c) { it is RemoteProtocol.Message.CommandResult && it.id == 21L } as RemoteProtocol.Message.CommandResult
                    if (r2.ok || r2.error != RemoteProtocol.ErrorCode.NO_SESSION) throw IllegalStateException("esperava no_session, veio $r2")
                } finally {
                    fake.result = MediaSessionHub.Result.OK
                }
                "unavailable e no_session chegam ao cliente"
            }
            check(checks, "Comandos: mais de 10 por segundo recebem rate_limited") {
                val c = a2 ?: throw IllegalStateException("pré-requisito: autenticação falhou")
                Thread.sleep(1100L)
                for (i in 0 until 20) c.send(RemoteProtocol.Message.CommandMsg(100L + i, RemoteProtocol.Command.PLAY_PAUSE))
                var okCount = 0
                var limited = 0
                for (i in 0 until 20) {
                    val m = await(c) {
                        (it is RemoteProtocol.Message.CommandResult && it.id >= 100L) ||
                            (it is RemoteProtocol.Message.ErrorMsg && (it.id ?: 0L) >= 100L)
                    }
                    if (m is RemoteProtocol.Message.CommandResult) okCount++
                    else if (m is RemoteProtocol.Message.ErrorMsg && m.code == RemoteProtocol.ErrorCode.RATE_LIMITED) limited++
                }
                if (limited < 1) throw IllegalStateException("nenhum comando foi limitado ($okCount ok)")
                "$okCount executados e $limited limitados de 20 enviados de uma vez"
            }

            // 6) estado e capa
            check(checks, "Estado: só clientes autenticados recebem a música") {
                val c = a2 ?: throw IllegalStateException("pré-requisito: autenticação falhou")
                val u = track(open(port, pin, ID_C))
                fake.emit(FakeMediaPort.playing("Música de teste", "Artista de teste"))
                val m = await(c) { it is RemoteProtocol.Message.StateMsg && it.title == "Música de teste" } as RemoteProtocol.Message.StateMsg
                if (!m.playing || m.artist != "Artista de teste") throw IllegalStateException("estado recebido não bate com o enviado")
                expectNone(u, 700L) { it is RemoteProtocol.Message.StateMsg || it is RemoteProtocol.Message.ArtChunk }
                drop(u)
                "o autenticado recebeu título/artista/tocando; o cliente sem autenticação não recebeu nada"
            }
            check(checks, "Capa: JPEG em blocos remonta com SHA-256 certo e artId bate com o do estado") {
                val c = a2 ?: throw IllegalStateException("pré-requisito: autenticação falhou")
                val token = tokenA ?: throw IllegalStateException("pré-requisito: pareamento falhou")
                val cover = makeCover()
                bmp = cover
                fake.emit(FakeMediaPort.playing("Música com capa", "Artista de teste", cover))
                val (img, artId, chunks) = collectArt(c)
                if (RemoteProtocol.artIdOf(RemoteProtocol.sha256Hex(img)) != artId) throw IllegalStateException("artId não bate com o hash da imagem")
                val dec = BitmapFactory.decodeByteArray(img, 0, img.size) ?: throw IllegalStateException("a capa remontada não é um JPEG válido")
                if (maxOf(dec.width, dec.height) > 320) throw IllegalStateException("capa maior que 320 px: ${dec.width}x${dec.height}")
                val w = dec.width
                val h = dec.height
                dec.recycle()
                // cliente que se autentica depois recebe a capa que já está pronta
                val late = track(open(port, pin, ID_A))
                late.send(RemoteProtocol.Message.Auth(ID_A, token))
                val (img2, artId2, _) = collectArt(late)
                drop(late)
                if (artId2 != artId || !MessageDigest.isEqual(img, img2)) throw IllegalStateException("o cliente tardio recebeu uma capa diferente")
                "capa ${w}x$h, ${img.size} bytes em $chunks bloco(s); cliente que entrou depois recebeu a mesma capa"
            }

            // 6b) fila de reprodução: capacidade "queue", fila real da sessão, atualizações e janela
            fun fq(titles: List<String>, activeIdx: Int, status: MediaSessionHub.QueueStatus = MediaSessionHub.QueueStatus.OK): MediaSessionHub.Queue {
                val items = titles.mapIndexed { i, t -> MediaSessionHub.QueueEntry(500L + i, t, "Artista de $t", "mid-$t") }
                val activeId = if (activeIdx in items.indices) items[activeIdx].queueId else -1L
                return MediaSessionHub.Queue(status, "test.pkg", "Fila de teste", activeId, activeIdx, items)
            }

            fun names(n: Int) = (0 until n).map { "Faixa $it" }

            fun queueClient(token: String): Cli {
                val c = track(open(port, pin, ID_A, caps = listOf(RemoteProtocol.CAP_QUEUE)))
                c.send(RemoteProtocol.Message.Auth(ID_A, token))
                return c
            }

            fun awaitQueue(c: Cli, what: String, accept: (RemoteProtocol.Message.QueueMsg) -> Boolean): RemoteProtocol.Message.QueueMsg {
                try {
                    return await(c) { it is RemoteProtocol.Message.QueueMsg && accept(it) } as RemoteProtocol.Message.QueueMsg
                } catch (e: IllegalStateException) {
                    throw IllegalStateException("$what: " + (e.message ?: ""))
                }
            }

            check(checks, "Fila: o servidor anuncia \"queue\"; só quem anunciou E autenticou recebe; cliente antigo nunca recebe") {
                val old = a2 ?: throw IllegalStateException("pré-requisito: autenticação falhou")
                val token = tokenA ?: throw IllegalStateException("pré-requisito: pareamento falhou")
                val probe = connect(port, pin)
                try {
                    probe.send(hello(ID_A))
                    val sh = await(probe) { it is RemoteProtocol.Message.Hello && it.role == "server" } as RemoteProtocol.Message.Hello
                    if (!sh.caps.contains(RemoteProtocol.CAP_QUEUE)) throw IllegalStateException("o hello do servidor não anuncia \"queue\": ${sh.caps}")
                } finally {
                    probe.close()
                }
                fake.emitQueue(fq(names(3), 1))
                // anunciou "queue", mas NÃO se autenticou: nada
                val anon = track(open(port, pin, ID_C, caps = listOf(RemoteProtocol.CAP_QUEUE)))
                fake.emitQueue(fq(names(3), 2))
                expectNone(anon, 700L) { it is RemoteProtocol.Message.QueueMsg }
                drop(anon)
                // anunciou e se autenticou depois da fila existir: recebe a fila ATUAL logo após o auth
                val qc = queueClient(token)
                val first = awaitQueue(qc, "fila inicial") { true }
                if (first.status != RemoteProtocol.QueueCode.OK || first.total != 3 || first.cur != 2 || first.from != 0) {
                    throw IllegalStateException("fila inicial errada: $first")
                }
                if (first.items.map { it.title } != names(3)) throw IllegalStateException("títulos da fila errados: ${first.items}")
                if (first.items[1].subtitle != "Artista de Faixa 1") throw IllegalStateException("subtítulo errado: ${first.items[1]}")
                // cliente antigo (hello sem caps, já autenticado): recebe estado, mas nenhuma fila
                fake.emitQueue(fq(names(4), 0))
                awaitQueue(qc, "atualização para o cliente com a capacidade") { it.total == 4 }
                expectNone(old, 600L) { it is RemoteProtocol.Message.QueueMsg }
                drop(qc)
                "o hello do servidor anuncia queue; sem auth nada chega; o autenticado recebe a fila atual; o cliente antigo não recebeu nenhuma mensagem queue"
            }
            check(checks, "Fila: acompanha música que muda, avanço/retrocesso, item adicionado/removido, fila trocada e fila que some") {
                val token = tokenA ?: throw IllegalStateException("pré-requisito: pareamento falhou")
                val qc = queueClient(token)
                fake.emitQueue(fq(names(5), 1))
                var m = awaitQueue(qc, "fila de 5") { it.total == 5 && it.cur == 1 }
                // avançar e retroceder (só o item ativo muda)
                fake.emitQueue(fq(names(5), 2))
                m = awaitQueue(qc, "avançou") { it.cur == 2 && it.total == 5 }
                if (m.items[2].title != "Faixa 2") throw IllegalStateException("o item atual não está na posição indicada")
                fake.emitQueue(fq(names(5), 1))
                awaitQueue(qc, "retrocedeu") { it.cur == 1 }
                // item adicionado no fim
                fake.emitQueue(fq(names(6), 1))
                m = awaitQueue(qc, "item adicionado") { it.total == 6 }
                if (m.items.last().title != "Faixa 5" || m.cur != 1) throw IllegalStateException("item adicionado errado: $m")
                // item do meio removido (a música atual continua sendo a "Faixa 1")
                val without2 = names(6).filter { it != "Faixa 2" }
                fake.emitQueue(fq(without2, 1))
                m = awaitQueue(qc, "item removido") { it.total == 5 }
                if (m.items.any { it.title == "Faixa 2" } || m.items[m.cur].title != "Faixa 1") throw IllegalStateException("remoção errada: $m")
                // fila inteira trocada (outra lista, outro título)
                val other = listOf("Novo A", "Novo B", "Novo C")
                fake.emitQueue(fq(other, 2))
                m = awaitQueue(qc, "fila trocada") { it.items.firstOrNull()?.title == "Novo A" }
                if (m.items.map { it.title } != other || m.cur != 2) throw IllegalStateException("fila trocada errada: $m")
                // posição do atual desconhecida: cur = -1 (nada é adivinhado)
                fake.emitQueue(fq(other, -1))
                m = awaitQueue(qc, "atual desconhecido") { it.cur == -1 && it.total == 3 }
                // o app deixa de publicar a fila: o cliente é informado do MOTIVO, sem itens
                fake.emitQueue(fq(emptyList(), -1, MediaSessionHub.QueueStatus.NOT_PUBLISHED))
                m = awaitQueue(qc, "não publicada") { it.status == RemoteProtocol.QueueCode.NOT_PUBLISHED }
                if (m.items.isNotEmpty() || m.total != 0 || m.cur != -1) throw IllegalStateException("fila não publicada com dados: $m")
                fake.emitQueue(MediaSessionHub.NO_QUEUE)
                awaitQueue(qc, "sem sessão") { it.status == RemoteProtocol.QueueCode.NO_SESSION }
                // volta a existir
                fake.emitQueue(fq(names(2), 0))
                awaitQueue(qc, "fila voltou") { it.status == RemoteProtocol.QueueCode.OK && it.total == 2 }
                // os controles de música continuam funcionando na mesma conexão
                qc.send(RemoteProtocol.Message.CommandMsg(77L, RemoteProtocol.Command.PLAY_PAUSE))
                val r = await(qc) { it is RemoteProtocol.Message.CommandResult && it.id == 77L } as RemoteProtocol.Message.CommandResult
                if (!r.ok) throw IllegalStateException("o comando play_pause falhou na conexão com fila: $r")
                drop(qc)
                "avançar/retroceder, adicionar, remover, trocar a fila, atual desconhecido, fila não publicada, sem sessão e retorno: tudo chegou; play_pause segue ok"
            }
            check(checks, "Fila: fila grande vira janela de até ${RemoteProtocol.MAX_QUEUE_ITEMS} itens; rajada de atualizações não derruba o cliente") {
                val token = tokenA ?: throw IllegalStateException("pré-requisito: pareamento falhou")
                val qc = queueClient(token)
                val big = (0 until 400).map { "Faixa grande número $it" }
                fake.emitQueue(fq(big, 250))
                val m = awaitQueue(qc, "fila de 400") { it.total == 400 }
                if (m.items.size > RemoteProtocol.MAX_QUEUE_ITEMS || m.from != 250 - RemoteProtocol.QUEUE_PRE_ITEMS || m.cur != 250) {
                    throw IllegalStateException("janela errada: from=${m.from} cur=${m.cur} itens=${m.items.size}")
                }
                if (m.items[m.cur - m.from].title != "Faixa grande número 250") throw IllegalStateException("o item atual não está na posição indicada da janela")
                // rajada sem ler: só o retrato mais novo precisa chegar; a conexão continua
                for (i in 0 until 40) fake.emitQueue(fq(big, 100 + i))
                val last = awaitQueue(qc, "fim da rajada") { it.cur == 139 }
                qc.send(RemoteProtocol.Message.Ping)
                await(qc) { it == RemoteProtocol.Message.Pong }
                drop(qc)
                "janela from=${m.from}, ${m.items.size} itens de ${m.total}; rajada de 40 terminou em cur=${last.cur} e o cliente continuou conectado"
            }

            // 7) revogação
            check(checks, "Revogação: remove o pareamento e derruba todas as conexões do aparelho") {
                val token = tokenA ?: throw IllegalStateException("pré-requisito: pareamento falhou")
                if (!br.revoke(ID_A)) throw IllegalStateException("revoke() disse que não havia pareamento")
                a1?.let { expectClosed(it) }
                a2?.let { expectClosed(it) }
                if (isPaired(ID_A)) throw IllegalStateException("o pareamento continua salvo")
                if (RemoteAuth.verifyPaired(ID_A, token)) throw IllegalStateException("o token antigo ainda vale")
                val c = track(open(port, pin, ID_A))
                c.send(RemoteProtocol.Message.Auth(ID_A, token))
                awaitError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                drop(c)
                if (br.revoke(ID_A)) throw IllegalStateException("revogar de novo deveria devolver false")
                "conexões fechadas, pareamento e token apagados, novo auth recusado"
            }

            // 8) limite de tentativas por IP (bridge 3, para não bloquear o IP dos demais testes)
            check(checks, "Limite de tentativas: 5 erros bloqueiam o IP por 60 s (rate_limited), mesmo com token certo") {
                val (cOk, token) = pairDevice(br3, port3, pin, fp, ID_C)
                track(cOk)
                val c = track(open(port3, pin, ID_C))
                for (i in 1..4) {
                    c.send(RemoteProtocol.Message.Auth(ID_C, RemoteAuth.newToken()))
                    awaitError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                }
                c.send(RemoteProtocol.Message.Auth(ID_C, RemoteAuth.newToken()))
                awaitError(c, RemoteProtocol.ErrorCode.RATE_LIMITED)
                c.send(RemoteProtocol.Message.Auth(ID_C, token))
                awaitError(c, RemoteProtocol.ErrorCode.RATE_LIMITED)
                val other = track(open(port3, pin, ID_C))
                other.send(RemoteProtocol.Message.Auth(ID_C, token))
                awaitError(other, RemoteProtocol.ErrorCode.RATE_LIMITED)
                "4 erros normais, o 5º bloqueou; com o token certo continuou bloqueado, inclusive em outra conexão do mesmo IP"
            }

            // 8b) Etapa 2A: prazo de autenticação junto com o pareamento (servidor 4, prazo de 3 s)
            check(checks, "Timeout de autenticação: pedido pendente é descartado, o autenticado fica e a vaga/janela são liberadas") {
                val before = srv4.authTimeoutCount()
                // aparelho autenticado pelo caminho completo de pareamento (fica conectado além do prazo)
                val (ok, _) = pairDevice(br4, port4, pin, fp, ID_B)
                track(ok)
                // 1) cliente com pedido de pareamento pendente que ninguém aprova
                if (!br4.openPairingWindow()) throw IllegalStateException("não abriu a janela (bridge 4)")
                val p = track(open(port4, pin, ID_D))
                p.send(RemoteProtocol.Message.PairRequest(ID_D, "Autoteste D", RemoteAuth.newNonce()))
                await(p) { it is RemoteProtocol.Message.PairChallenge }
                if (!waitUntil(2000L) { br4.info().pending != null }) throw IllegalStateException("o pedido não apareceu no painel")
                // 2) cliente que só fez hello
                val h = track(open(port4, pin, ID_C))
                expectClosed(p, authTest + 4000L)
                expectClosed(h, authTest + 4000L)
                if (!waitUntil(2000L) { br4.info().pending == null }) throw IllegalStateException("o pedido do cliente desconectado continuou pendente")
                if (br4.approve()) throw IllegalStateException("approve() aceitou um pedido de cliente já desconectado")
                if (isPaired(ID_D)) throw IllegalStateException("ficou pareado um cliente que estourou o prazo")
                if (!waitUntil(2000L) { srv4.clientCount() == 1 }) throw IllegalStateException("clientes no servidor: ${srv4.clientCount()} (esperado 1, o autenticado)")
                if (srv4.authTimeoutCount() != before + 2) {
                    throw IllegalStateException("timeouts: ${srv4.authTimeoutCount() - before} (esperado 2)")
                }
                // o aparelho autenticado continua conectado e válido, mesmo muito depois do prazo
                if (!br4.info().connectedIds.contains(ID_B)) throw IllegalStateException("o autenticado saiu da lista de conectados")
                ok.send(RemoteProtocol.Message.Ping)
                await(ok) { it == RemoteProtocol.Message.Pong }
                // a vaga de pareamento foi liberada: um novo pedido recebe pair_challenge (não pairing_busy) e pode ser negado
                if (!br4.openPairingWindow()) throw IllegalStateException("não abriu a janela de novo")
                val n = track(open(port4, pin, ID_D))
                n.send(RemoteProtocol.Message.PairRequest(ID_D, "Autoteste D", RemoteAuth.newNonce()))
                await(n) { it is RemoteProtocol.Message.PairChallenge }
                if (!br4.deny()) throw IllegalStateException("deny() devolveu false")
                awaitError(n, RemoteProtocol.ErrorCode.PAIRING_DENIED)
                "pedido pendente e cliente mudo desconectados em ~${authTest} ms (2 timeouts); pedido descartado, nada salvo; o autenticado seguiu conectado; novo pedido aceito depois"
            }

            // 8c) Etapa 3, Bloco 3: fila de capas (bridges 5, 6 e 7)
            var port5 = 0
            var port6 = 0
            var port7 = 0
            check(checks, "Capas: servidores de teste ligam (bridge 5 normal, 6 com fila de 2, 7 com envio travável)") {
                br5.attach()
                br6.attach()
                br7.attach()
                if (!srv5.start()) throw IllegalStateException("servidor 5 não ligou: " + srv5.lastError)
                if (!srv6.start()) throw IllegalStateException("servidor 6 não ligou: " + srv6.lastError)
                if (!srv7.start()) throw IllegalStateException("servidor 7 não ligou: " + srv7.lastError)
                port5 = srv5.boundPort
                port6 = srv6.boundPort
                port7 = srv7.boundPort
                "portas $port5, $port6 e $port7; fila máxima ${RemoteBridge.MAX_QUEUE} (bridge 6: 2); buffer de envio do servidor 7: 8 KB"
            }
            if (port5 == 0 || port6 == 0 || port7 == 0) {
                checks.add(RemoteAuth.Check("Demais testes da fila de capas", false, "não executados (os servidores de teste das capas não ligaram)"))
            } else {
                var tokenE: String? = null
                var tokenF: String? = null
                var tokenG: String? = null
                check(checks, "Capas: pareamento dos aparelhos de teste E (bridge 5), F (bridge 6) e G (bridge 7)") {
                    val (ce, te) = pairDevice(br5, port5, pin, fp, ID_E)
                    ce.close()
                    tokenE = te
                    val (cf, tf) = pairDevice(br6, port6, pin, fp, ID_F)
                    cf.close()
                    tokenF = tf
                    val (cg, tg) = pairDevice(br7, port7, pin, fp, ID_G)
                    cg.close()
                    tokenG = tg
                    "três aparelhos pareados pelo caminho completo; as conexões de pareamento foram fechadas (os testes seguintes entram com auth)"
                }

                check(checks, "Capas: troca rápida de faixas — só 1 trabalho espera, os obsoletos são descartados e só a última capa é entregue") {
                    val token = tokenE ?: throw IllegalStateException("pré-requisito: o pareamento do aparelho E falhou")
                    val covers = ArrayList<Bitmap>()
                    val c = track(authOpen(port5, pin, ID_E, token))
                    try {
                        val s0 = br5.artJobsSubmitted()
                        val e0 = br5.artJobsEncoded()
                        val d0 = br5.artJobsDiscarded()
                        br5.artEncodeDelayMs = 400L
                        for (i in 1..5) {
                            val b = makeCoverSeed(100 + i)
                            covers.add(b)
                            fake5.emit(FakeMediaPort.playing("Faixa rápida $i", "Artista de teste", b))
                        }
                        val st = readArt(c, 15000L) { it.title == "Faixa rápida 5" && it.artId.isNotEmpty() }
                        if (st.dangling.isNotEmpty()) throw IllegalStateException("estado citou artId sem a capa ter chegado: ${st.dangling}")
                        if (!st.completed.contains(st.last.artId)) throw IllegalStateException("a capa citada no estado final não chegou inteira")
                        if (!waitUntil(4000L) { br5.artPendingJobs() == 0 && br5.artLiveSnapshots() == 0 }) {
                            throw IllegalStateException("cópias de capa não liberadas: vivas=${br5.artLiveSnapshots()}, esperando=${br5.artPendingJobs()}")
                        }
                        val submitted = br5.artJobsSubmitted() - s0
                        val encoded = br5.artJobsEncoded() - e0
                        val discarded = br5.artJobsDiscarded() - d0
                        if (submitted != 5) throw IllegalStateException("trabalhos recebidos: $submitted (esperado 5)")
                        if (encoded < 1) throw IllegalStateException("nenhuma capa foi codificada")
                        if (encoded >= submitted) throw IllegalStateException("nenhum trabalho foi poupado: $encoded codificados de $submitted")
                        if (discarded < 1) throw IllegalStateException("nenhum trabalho foi descartado")
                        val artThreads = Thread.getAllStackTraces().keys.count { it.isAlive && it.name == "WinRemote-btest5-art" }
                        if (artThreads > 1) throw IllegalStateException("$artThreads threads de capa do bridge 5 (esperado no máximo 1)")
                        "5 faixas em sequência: $encoded codificada(s), $discarded descartada(s); a capa final chegou inteira (${st.chunks} bloco[s] no total), nenhum estado citou capa que não chegou; cópias vivas 0; $artThreads thread de capa"
                    } finally {
                        br5.artEncodeDelayMs = 0L
                        recycleAll(covers)
                        drop(c)
                    }
                }

                check(checks, "Capas: faixa sem capa cancela o trabalho que esperava e nenhuma capa antiga chega depois") {
                    val token = tokenE ?: throw IllegalStateException("pré-requisito: o pareamento do aparelho E falhou")
                    val covers = ArrayList<Bitmap>()
                    val c = track(authOpen(port5, pin, ID_E, token))
                    try {
                        if (!waitUntil(4000L) { br5.artPendingJobs() == 0 && br5.artLiveSnapshots() == 0 }) throw IllegalStateException("havia trabalho de capa pendente antes do teste")
                        val e0 = br5.artJobsEncoded()
                        br5.artEncodeDelayMs = 700L
                        val b1 = makeCoverSeed(201)
                        val b2 = makeCoverSeed(202)
                        covers.add(b1)
                        covers.add(b2)
                        fake5.emit(FakeMediaPort.playing("Troca 1", "Artista de teste", b1))
                        fake5.emit(FakeMediaPort.playing("Troca 2", "Artista de teste", b2))
                        fake5.emit(FakeMediaPort.playing("Sem capa agora", "Artista de teste"))
                        val st = readArt(c, 8000L) { it.title == "Sem capa agora" }
                        if (st.last.artId.isNotEmpty()) throw IllegalStateException("o estado da faixa sem capa citou artId '${st.last.artId}'")
                        if (st.dangling.isNotEmpty()) throw IllegalStateException("estado citou artId sem a capa ter chegado: ${st.dangling}")
                        val extra = readWindow(c, 1500L)
                        if (extra.any { it is RemoteProtocol.Message.ArtChunk }) throw IllegalStateException("chegou bloco de capa depois da faixa sem capa")
                        if (extra.any { it is RemoteProtocol.Message.StateMsg && it.artId.isNotEmpty() }) throw IllegalStateException("chegou estado com artId depois da faixa sem capa")
                        if (!waitUntil(3000L) { br5.artPendingJobs() == 0 && br5.artLiveSnapshots() == 0 }) {
                            throw IllegalStateException("cópias de capa não liberadas: vivas=${br5.artLiveSnapshots()}, esperando=${br5.artPendingJobs()}")
                        }
                        if (br5.artJobsEncoded() != e0) throw IllegalStateException("foi codificada uma capa de faixa que já tinha mudado (${br5.artJobsEncoded() - e0})")
                        "2 trabalhos de capa cancelados pela faixa sem capa: 0 codificados, 0 blocos depois do estado sem capa, cópias vivas 0"
                    } finally {
                        br5.artEncodeDelayMs = 0L
                        recycleAll(covers)
                        drop(c)
                    }
                }

                check(checks, "Capas: se a capa não cabe na fila do cliente, ele recebe só o estado (artId vazio) e continua conectado") {
                    val token = tokenF ?: throw IllegalStateException("pré-requisito: o pareamento do aparelho F falhou")
                    val cover = makeCoverSeed(6)
                    val c = track(authOpen(port6, pin, ID_F, token))
                    try {
                        val skipped0 = br6.artSkippedCount()
                        fake6.emit(FakeMediaPort.playing("Capa que não cabe", "Artista de teste", cover))
                        if (!waitUntil(8000L) { br6.artSkippedCount() > skipped0 }) {
                            throw IllegalStateException("a capa coube na fila de 2 mensagens (artSkippedCount não subiu); o JPEG de teste ficou com um bloco só?")
                        }
                        // outro estado da MESMA faixa (a capa continua no bridge): o cliente que não a recebeu continua sem artId
                        fake6.emit(FakeMediaPort.playing("Capa que não cabe", "Artista de teste", cover))
                        val got = readWindow(c, 1500L)
                        if (got.any { it is RemoteProtocol.Message.ArtChunk }) throw IllegalStateException("chegou bloco de capa mesmo sem caber na fila")
                        val states = got.filterIsInstance<RemoteProtocol.Message.StateMsg>()
                        if (states.none { it.title == "Capa que não cabe" }) throw IllegalStateException("o cliente não recebeu o estado da faixa")
                        if (states.any { it.artId.isNotEmpty() }) throw IllegalStateException("estado citou artId de capa que o cliente não recebeu")
                        c.send(RemoteProtocol.Message.Ping)
                        await(c) { it == RemoteProtocol.Message.Pong }
                        if (!br6.info().connectedIds.contains(ID_F)) throw IllegalStateException("o cliente saiu da lista de conectados")
                        "capa pulada ${br6.artSkippedCount() - skipped0}x; ${states.size} estado(s) sem artId, nenhum bloco de capa; Ping/Pong ok; cliente continua conectado"
                    } finally {
                        drop(c)
                        recycleAll(listOf(cover))
                    }
                }

                var slowCompleted = -1
                var slowDropped = -1
                var slowTotal = 0
                check(checks, "Capas: cliente lento com troca rápida de faixas não é desconectado, não acumula capas e recebe a última") {
                    val token = tokenG ?: throw IllegalStateException("pré-requisito: o pareamento do aparelho G falhou")
                    val covers = ArrayList<Bitmap>()
                    val c = track(authOpen(port7, pin, ID_G, token, 4096))
                    try {
                        await(c) { it is RemoteProtocol.Message.StateMsg }
                        // a partir daqui o cliente NÃO lê mais: o envio do servidor trava e a fila cresce
                        val total = 16
                        slowTotal = total
                        val e0 = br7.artJobsEncoded()
                        for (i in 1..total) {
                            // as duas últimas faixas usam o MESMO bitmap (mesmo artId): a capa não deve ser duplicada na fila
                            val b = if (i == total) covers.last() else makeCoverSeed(300 + i).also { covers.add(it) }
                            val title = if (i == total) "Capa final" else "Faixa lenta $i"
                            fake7.emit(FakeMediaPort.playing(title, "Artista de teste", b))
                            // espera esta capa ficar pronta antes da próxima (senão o trabalho seria substituído, e o teste não encheria a fila)
                            if (!waitUntil(8000L) { br7.artJobsEncoded() >= e0 + i }) throw IllegalStateException("a capa $i não foi preparada a tempo")
                            Thread.sleep(80L)
                        }
                        if (!waitUntil(2000L) { br7.info().connectedIds.contains(ID_G) }) {
                            throw IllegalStateException("o cliente lento foi desconectado enquanto não lia (fila cheia?)")
                        }
                        slowDropped = br7.artChunksDropped()
                        // agora o cliente volta a ler
                        val st = readArt(c, 25000L) { it.title == "Capa final" && it.artId.isNotEmpty() }
                        if (st.dangling.isNotEmpty()) throw IllegalStateException("estado citou artId sem a capa ter chegado: ${st.dangling}")
                        if (!st.completed.contains(st.last.artId)) throw IllegalStateException("a capa final não chegou inteira")
                        if (!br7.info().connectedIds.contains(ID_G)) throw IllegalStateException("o cliente não está mais conectado")
                        slowCompleted = st.completed.size
                        val zeros = st.zeroChunks[st.last.artId] ?: 0
                        "$total faixas com o cliente sem ler: ${st.completed.size} capa(s) completa(s) entregue(s), ${st.chunks} bloco(s); blocos antigos removidos da fila: $slowDropped; a última capa chegou (início dela recebido ${zeros}x); nenhum estado citou capa que não chegou; cliente continua conectado"
                    } finally {
                        recycleAll(covers)
                        drop(c)
                    }
                }
                check(checks, "Capas (informativo): o cliente lento deixou de receber capas antigas", essential = false) {
                    if (slowCompleted < 0) throw IllegalStateException("o teste anterior não chegou ao fim")
                    if (slowDropped <= 0 && slowCompleted >= slowTotal) {
                        throw IllegalStateException("o envio não travou (buffers do sistema grandes): $slowCompleted de $slowTotal capas chegaram e nada foi removido; o teste anterior não exercitou a remoção")
                    }
                    "$slowCompleted de $slowTotal capas chegaram; $slowDropped bloco(s) de capas antigas removido(s) da fila"
                }

                check(checks, "Capas: detach() com trabalho em andamento libera as cópias e encerra a thread das capas") {
                    val b = makeCoverSeed(400)
                    try {
                        if (!waitUntil(3000L) { br5.artPendingJobs() == 0 && br5.artLiveSnapshots() == 0 }) throw IllegalStateException("havia trabalho de capa pendente antes do teste")
                        br5.artEncodeDelayMs = 3000L
                        fake5.emit(FakeMediaPort.playing("Detach no meio", "Artista de teste", b))
                        if (!waitUntil(3000L) { br5.artLiveSnapshots() == 1 }) throw IllegalStateException("o trabalho de capa não começou")
                        br5.detach()
                        br6.detach()
                        br7.detach()
                        srv5.stop()
                        srv6.stop()
                        srv7.stop()
                        if (!waitUntil(4000L) { br5.artLiveSnapshots() == 0 && br5.artPendingJobs() == 0 }) {
                            throw IllegalStateException("cópias não liberadas depois do detach: vivas=${br5.artLiveSnapshots()}, esperando=${br5.artPendingJobs()}")
                        }
                        if (!waitUntil(4000L) { artThreadNames().isEmpty() }) throw IllegalStateException("threads de capa ainda vivas: " + artThreadNames().joinToString(", "))
                        if (br5.outCount() != 0 || br6.outCount() != 0 || br7.outCount() != 0) throw IllegalStateException("filas de clientes não foram esvaziadas")
                        if (srv5.liveThreads() != 0 || srv6.liveThreads() != 0 || srv7.liveThreads() != 0) {
                            throw IllegalStateException("threads dos servidores 5-7 ainda vivas")
                        }
                        "trabalho de 3 s interrompido pelo detach: cópias vivas 0, nenhuma thread de capa, filas vazias, servidores 5, 6 e 7 desligados"
                    } finally {
                        br5.artEncodeDelayMs = 0L
                        recycleAll(listOf(b))
                    }
                }
            }

            // 9) desligamento
            check(checks, "Desligamento: detach() solta o Hub e nenhuma thread de teste sobra") {
                for (c in conns) c.close()
                conns.clear()
                br.detach()
                br2.detach()
                br3.detach()
                br4.detach()
                srv.stop()
                srv2.stop()
                srv3.stop()
                srv4.stop()
                if (srv4.liveThreads() != 0) throw IllegalStateException("${srv4.liveThreads()} thread(s) do servidor 4 ainda vivas")
                if (fake.startCalls.get() != 1 || fake.stopCalls.get() != 1) {
                    throw IllegalStateException("Hub: start ${fake.startCalls.get()}x / stop ${fake.stopCalls.get()}x (esperado 1 e 1)")
                }
                if (fake.listenerCount() != 0) throw IllegalStateException("o ouvinte continuou registrado")
                if (!waitUntil(3000L) { testThreads().isEmpty() }) {
                    throw IllegalStateException("threads ainda vivas: " + testThreads().joinToString(", "))
                }
                "Hub: start 1x / stop 1x, ouvinte removido, nenhuma thread \"WinRemote-btest\" sobrou"
            }
        } finally {
            for (c in conns) c.close()
            try {
                bmp?.recycle()
            } catch (e: Throwable) {
            }
            for (b in listOf(br, br2, br3, br4, br5, br6, br7, lifeBr, failBr)) {
                try {
                    b.detach()
                } catch (e: Throwable) {
                }
            }
            for (sv in listOf(srv, srv2, srv3, srv4, srv5, srv6, srv7)) {
                try {
                    sv.stop()
                } catch (e: Throwable) {
                }
            }
            cleanup()
        }
        return checks
    }
}
