# HANDOFF 2 — estado real do projeto (continuação do HANDOFF.md)

Nada foi compilado (sem Android SDK; Maven/Google bloqueados no ambiente). Revise erros de compilação ao final.

## O que JÁ está feito
- Tudo do HANDOFF.md original (FileOps.kt, ícones fm_*, ic_files.png).
- Analisei BrowserWindow.kt, ContextMenu.kt (MenuItem, WheelScrollView), TaskbarPreview.kt (PreviewEntry, snapView),
  MainActivity.kt (padrão do navegador) e ApkInstallerWindow.openWith(uri).
- Criado `app/src/main/java/com/example/winlauncher/FileManagerWindow.kt` = parte 1 (copiada de _wip/fm) +
  imports extras (BitmapFactory, ThumbnailUtils, ViewConfiguration) + campos novos antes do `init`:
  `suppressSearch, searchTick, opTitle, dlgOnClose`.
  A classe AINDA NÃO FECHA (falta `}` final) e não compila até as partes abaixo existirem.

## O que FALTA (nada abaixo foi escrito)
### A) Dentro de FileManagerWindow.kt (anexar depois da função `lp(...)` e fechar a classe)
1. `titleButton`, `btnBg`, `GripView` (copiar do BrowserWindow.kt linhas ~646-672 e 1120-1136).
2. `build()`: `layer.tag=NOHAND`; `layer.setOnTouchListener{DOWN->active=false; false}`; `win` como FrameLayout anônimo cujo
   `dispatchTouchEvent` seta `active=true` no DOWN (listener comum não dispara se um filho consome); col vertical:
   titleBar(40dp) / navBar(46dp) / cmdBar(44dp) / linha / body(horizontal: sidebar 190dp + divisor + content) / status(28dp).
   Views obrigatórias (lateinit já declaradas na parte 1): titleBar,titleText,titleIcon,maxBtn,fullBtn,navBar,backBtn,fwdBtn,
   upBtn,crumbScroll,crumbRow,addrEdit,searchBox,cmdBar,cmdRow,cmdViews,sidebar(WheelScrollView),sideCol,sideDivider,content,
   listCol,detailsHeader,listView,homeScroll,homeCol,msgBox,msgText,msgBtn,statusText,grip,fsBar,dlgLayer.
   Terminar com `layer.addView(win, ...)`, `applyModeStyle()`, `rebuildSidebar()`. Barra de título com arrastar (igual Browser).
   OBS: crumbScroll consome toques; detectar "toque em área vazia" por OnTouchListener (retornando false) para chamar startAddrEdit().
   Após `clearFocus()` de EditText, dar foco ao `win` (isFocusableInTouchMode=true) senão o foco pula pro searchBox.
3. Navegação: navigate(path:String?, push=true) (histórico usa "" = Este PC), goBack/goForward/goUp (raiz de drive -> Este PC),
   reload, loadDir (listFiles em io{}, checa loadGen), applySortFilter (pastas primeiro, exceto SORT_DATE; natural de FileOps),
   buildRows (cabeçalhos de data Hoje/Ontem/Esta semana/Semana passada/Este mês/Mês passado/No início deste ano/Há muito tempo),
   computePerRow (LARGE w/104dp, MEDIUM w/88dp, LIST w/220dp, DETAILS=1), RowAdapter (2 tipos, `key` p/ recriar ao mudar
   modo/colunas; NÃO usar lateinit no init do adapter), RowView/Cell (inner class, toque: mouse=seleciona/Ctrl/Shift/duplo clique,
   toque=abre ou alterna se selectMode, longo=seleciona+menu, botão direito=menu), miniaturas com `thumbs` LruCache + thumbExec
   (imagem/vídeo/APK), buildHome (Pastas(5) + Dispositivos e unidades com StatFs e barra de uso "41,2 GB livres de 105,6 GB"),
   rebuildSidebar+destaque, buildCrumbs ("Início › storage › emulated › 0 › ..."), startAddrEdit/stopAddrEdit,
   updateDetailsHeader (Nome/Data/Tipo/Tamanho clicáveis), updateChrome (título, botões, status "N itens"/"N selecionados").
4. Seleção: selectedItems, selectAll, clearSelection, selectRange, refreshSelection.
5. Operações: copySel(cut), paste(target=curDir) com askConflict (ArrayBlockingQueue, REPLACE/KEEP_BOTH/SKIP/CANCEL, bit 16 =
   aplicar a todos; botões do diálogo com auto=false e `dlgOnClose` oferecendo CANCEL), deleteSel (confirma), renameSel,
   newFolder, newTextFile, zipSel, unzip, properties, shareSel (FileShareProvider.uriFor + ACTION_SEND), copyPath,
   openItem (pasta→navega; .apk→act.openApk(uri); zip→pergunta extrair; resto→ACTION_VIEW c/ FLAG_GRANT_READ_URI_PERMISSION),
   openWith, runSearch(q) recursiva (Enter na caixa de busca; digitar só filtra a pasta atual), runOp (progresso com atraso de 350ms
   + Cancelar), dialog/promptText/confirm/closeDialog/stopTicker/showProgress, hasAccess/requestAccess
   (isExternalStorageManager + ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION; API<30 requestPermissions).
   Proteger de excluir/mover a raiz do armazenamento.

### B) Integração (nada feito)
- AndroidManifest.xml: MANAGE_EXTERNAL_STORAGE (tools:ignore="ScopedStorage"), READ_EXTERNAL_STORAGE,
  WRITE_EXTERNAL_STORAGE maxSdkVersion=29, `android:requestLegacyExternalStorage="true"` no <application>, e
  `<provider android:name=".FileShareProvider" android:authorities="${applicationId}.files" android:exported="false" android:grantUriPermissions="true"/>`.
- AppCustom.kt: `val FILES = ComponentName("com.example.winlauncher", "native.Files")`.
- MainActivity.kt (espelhar tudo do navegador): `TB_FILES="__files__"`; campo `files: FileManagerWindow` criado após `browser` (~linha 1283)
  com `attachBelow(menu.layer)` e `onStateChange={rebuildTaskbar()}`; `tbPresent` aceitar TB_FILES; `ensureFilesPinned()`
  (prefs "filesPinnedOnce", ao lado do navegador); em `rebuildTaskbar` (~1635): `filesOpen`, subtrair de `slots`, ramo
  `TB_FILES -> addFilesPinned`, `if (filesOpen) addFilesButton`; criar `addFilesPinned/filesPinnedMenu/addFilesButton/entryFiles()`
  (PreviewEntry "Arquivos"); `fun filesIcon()`; `filesMenuItems()` (Trocar ícone/Restaurar ícone);
  `afterAppCustomized()` → `files.refreshIcon()`; `fun openApk(uri: Uri){ apkWindow.openWith(uri) }`;
  `onBackPressed` → `files.handleBack()` antes do browser (~linha 531); `dispatchKeyEvent` → `files.handleKey(event)` antes do
  `return super...` (~788); `onResume` → `files.onHostResume()`.

## Dica final
Para checar compilação, abra no Android Studio / GitHub Actions (`./gradlew assembleDebug`) e corrija o que aparecer.
