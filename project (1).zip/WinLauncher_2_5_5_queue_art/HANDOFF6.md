# HANDOFF 6 — downloads do navegador

## FEITO (nada foi compilado: sem Android SDK neste ambiente)
- BrowserDownloads.kt (novo): baixador próprio (http/https com redirecionamento, cookies, UA e Referer; data:; blob: via ponte JS "WinDl" com token de uso único). Salva em Downloads (ou na pasta do app se não houver permissão). Lista dos concluídos fica em prefs (browserDownloads).
- BrowserWindow.kt:
  - Pop-ups (window.open / target=_blank) nascem como aba escondida (Tab.pending) e só aparecem quando a página carrega; se viram download ou abrem outro app, somem sem aparecer (dropPending).
  - Download não abre aba: aviso pequeno embaixo com progresso (toque abre a lista) + menu ⋮ > Downloads (lista com progresso, abrir, cancelar, remover, limpar).
  - "Precisa de um app": antes qualquer falha do DownloadManager (blob:, data:, sem permissão) caía em openExternal. Agora blob/data são baixados direto; intent: usa browser_fallback_url ou abre a Play Store; market: vira link https da Play Store.
## FALTA
1. Compilar e testar: link com target=_blank que baixa, download de blob (site que gera arquivo por JS), data:, APK pela lista.
2. Sem notificação do sistema (só aviso dentro do navegador).

# Música na barra de tarefas (TaskbarMusic.kt, novo)
- Chip no canto esquerdo da barra (capa + nome/artista + ondinhas animadas), só enquanto toca música. Pausada: some depois de 20 s (sem sessão: 1,5 s; com o painel aberto espera ele fechar). Sem espaço antes do grupo central: fica só capa + ondinhas, e some se nem isso couber.
- Toque no chip: painel de vidro sobe (showPanel/closeAll do MainActivity já conhecem `music.panel`): capa, nome, artista, voltar / pausar / avançar; fundo = papel de parede borrado + degradê com as cores da capa (AlbumPalette) + granulado + brilho. Toque no nome abre o app de música.
- Usa o acesso às notificações que o launcher já pede (sem ele o chip não aparece). As ondinhas são só efeito visual (não leem o áudio).
- Ganchos no MainActivity: campo `music`, criação depois de buildTaskbar(), showPanel/closeAll/placePanels/applyTaskbarMetrics/invalidateGlass, onResume (refreshAccess) e onDestroy (stop).
- NÃO COMPILADO. Testar: chip aparece ao tocar, cores mudam com a capa, barra em cima/embaixo, tela estreita.

# Apps padrão (navegador, galeria, arquivos)
- AndroidManifest: a MainActivity agora também aceita VIEW de http/https (navegador), image/* (galeria), pastas (resource/folder, vnd.android.document/directory, inode/directory) e o .apk de antes.
- MainActivity.handleViewIntent (no lugar de openApkFromIntent): link -> browser.show(url) em nova aba; foto -> gallery.openImage (content:// é copiada para cacheDir/viewed); pasta -> files.show(path) (só consegue caminhos file:// e primary: do armazenamento); .apk -> instalador.
- MainActivity.requestDefault(kind): navegador pede o papel BROWSER (RoleManager, Android 10+); galeria e arquivos não têm papel no Android: aviso + abre Apps padrão (o padrão se define em "Abrir com > Sempre").
- Menus: "Definir como navegador padrão" (⋮ do navegador e botão direito no ícone), "Definir como padrão" nos menus da galeria e dos arquivos.
- NÃO COMPILADO.
