package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Servidor TLS local do WinLauncher Remote (Etapa 3B, Parte 1).
 *
 * O que faz nesta parte:
 *  - SSLServerSocket em 0.0.0.0 usando [RemoteAuth.buildServerSslContext] (chave do Android Keystore), TLS 1.2 e 1.3
 *    (o que o aparelho suportar; TLS 1.2 é obrigatório).
 *  - Só atende IPv4 de rede local (10.x, 172.16–31.x, 192.168.x, 169.254.x). Qualquer outro endereço é fechado
 *    logo depois do accept(), ANTES do handshake TLS.
 *  - No máximo [MAX_CLIENTS] clientes ao mesmo tempo; uma thread por cliente.
 *  - Mensagens do [RemoteProtocol] (uma por linha, no máximo 16 KB). Nesta parte: hello, ping, pong, error.
 *    Mensagem inválida, grande demais ou fora de ordem => error + conexão encerrada.
 *  - Pareamento, autenticação, estado musical e comandos NÃO são feitos aqui: sem gancho, auth/command recebem
 *    NOT_PAIRED e pair_request recebe PAIRING_DENIED. A Parte 2 ([RemoteBridge]) entra pelos ganchos [onMessage] e
 *    [onClientClosed] e trata tudo isso.
 *
 * Este arquivo NÃO usa o MediaSessionHub e não toca no ciclo de vida dele (quem faz isso é o [RemoteBridge]).
 *
 * Threads: [start] e [stop] podem ser chamados de qualquer thread, mas NÃO da thread principal em [stop] se houver
 * clientes lentos (o fechamento é rápido, porém o join espera até ~2 s). O serviço chama [stop] numa thread própria.
 */
class RemoteServer(
    ctx: Context,
    private val port: Int = RemoteProtocol.DEFAULT_PORT,
    /** Só para os autotestes (conexão local de teste). O servidor real nunca aceita loopback. */
    private val allowLoopback: Boolean = false,
    private val maxClients: Int = MAX_CLIENTS,
    /** Nome usado nas threads (\"WinRemote-<tag>-...\"). */
    private val tag: String = "main",
    private val idleMs: Long = IDLE_MS,
    private val pingMs: Long = PING_EVERY_MS,
    private val events: Events? = null,
    /** Etapa 2A: prazo máximo, desde o accept(), para o cliente se autenticar ou parear. Os autotestes usam valores curtos. */
    private val authMs: Long = AUTH_TIMEOUT_MS,
    /** Etapa 2B: máximo de conexões simultâneas do mesmo IP (inclui as ainda em handshake TLS ou aguardando autenticação). */
    private val maxPerIp: Int = MAX_PER_IP,
    /** Etapa 3: prazo máximo de UMA escrita num socket (cliente que parou de ler). Passou disso, a conexão é fechada. */
    private val writeMs: Long = WRITE_TIMEOUT_MS,
    /** Só para testes: tamanho do buffer de envio dos sockets aceitos (0 = padrão do sistema). */
    private val sndBufBytes: Int = 0,
    /** Etapa 3, Bloco 2: tentativas de bind quando a porta está ocupada ("Address already in use"). 1 = sem nova tentativa. */
    private val bindAttempts: Int = BIND_ATTEMPTS,
    /** Etapa 3, Bloco 2: espera entre as tentativas de bind. */
    private val bindRetryMs: Long = BIND_RETRY_MS
) {

    enum class State { STOPPED, STARTING, RUNNING, STOPPING, ERROR }

    /** Avisos do servidor. Chamados em threads do servidor: quem recebe deve postar na thread principal se for mexer na tela. */
    interface Events {
        fun onState(state: State, error: String)
        fun onClients(count: Int)
        fun onLog(line: String)
    }

    companion object {
        const val MAX_CLIENTS = 4
        const val HANDSHAKE_MS = 10_000L
        /** Etapa 2A: prazo máximo (contado desde o accept(), inclui o handshake TLS) para o cliente concluir autenticação ou pareamento. */
        const val AUTH_TIMEOUT_MS = 15_000L
        /** Etapa 2B: conexões simultâneas por endereço IP. */
        const val MAX_PER_IP = 2
        /** Etapa 3: uma única escrita que fique parada mais que isso (cliente que não lê) derruba a conexão. */
        const val WRITE_TIMEOUT_MS = 10_000L
        /** Etapa 3, Bloco 2: porta ocupada (por exemplo, religamento logo após desligar) => até 12 tentativas, 250 ms entre elas (~3 s). */
        const val BIND_ATTEMPTS = 12
        const val BIND_RETRY_MS = 250L
        const val IDLE_MS = 45_000L
        const val PING_EVERY_MS = 15_000L
        /** Tempo máximo para uma mensagem chegar inteira depois do primeiro byte. */
        const val PARTIAL_MS = 10_000L
        private const val BACKLOG = 8
        private const val TAG = "WinRemoteServer"
        private const val NL = '\n'.code.toByte()

        /** Endereço IPv4 de rede local? (10/8, 172.16/12, 192.168/16, 169.254/16.) Loopback só se [allowLoopback]. */
        fun isAllowedAddress(a: InetAddress?, allowLoopback: Boolean = false): Boolean {
            if (a == null || a !is Inet4Address) return false
            if (a.isAnyLocalAddress || a.isMulticastAddress) return false
            if (a.isLoopbackAddress) return allowLoopback
            val b = a.address
            if (b.size != 4) return false
            val b0 = b[0].toInt() and 0xff
            val b1 = b[1].toInt() and 0xff
            return b0 == 10 ||
                (b0 == 172 && b1 in 16..31) ||
                (b0 == 192 && b1 == 168) ||
                (b0 == 169 && b1 == 254)
        }

        /** Endereços IPv4 locais deste aparelho que o servidor atende: pares (ip, interface). Wi-Fi/hotspot primeiro. */
        fun localAddresses(): List<Pair<String, String>> {
            val out = ArrayList<Pair<String, String>>()
            try {
                val en = NetworkInterface.getNetworkInterfaces() ?: return out
                for (ni in Collections.list(en)) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in Collections.list(ni.inetAddresses)) {
                        if (ia is Inet4Address && isAllowedAddress(ia, false)) {
                            out.add(Pair(ia.hostAddress ?: continue, ni.name ?: "?"))
                        }
                    }
                }
            } catch (e: Exception) {
            }
            fun rank(n: String): Int = when {
                n.startsWith("wlan") || n.startsWith("swlan") || n.startsWith("ap") -> 0
                n.startsWith("eth") -> 1
                else -> 2
            }
            return out.sortedBy { rank(it.second) }
        }
    }

    private val app: Context = ctx.applicationContext
    private val lifecycle = Any()
    private val clients = ArrayList<Client>()
    private val clientCount = AtomicInteger(0)
    private val rejected = AtomicInteger(0)
    private val nextClientId = AtomicInteger(1)
    private val authTimeouts = AtomicInteger(0)
    private val ipRejected = AtomicInteger(0)
    private val writeTimeouts = AtomicInteger(0)
    private val limiter = IpLimiter(maxPerIp)
    private val logLines = ArrayList<String>()

    @Volatile
    var state: State = State.STOPPED
        private set

    @Volatile
    var lastError: String = ""
        private set

    @Volatile
    var boundPort: Int = 0
        private set

    @Volatile
    var protocols: String = ""
        private set

    @Volatile
    private var stopping = false

    /**
     * Etapa 3, Bloco 2: um [stop] foi pedido e ainda não terminou. Faz um [start] concorrente (ou a espera por porta livre)
     * desistir logo, em vez de ligar um servidor que já nasceria condenado (servidor órfão).
     */
    private val pendingStops = AtomicInteger(0)
    private val abortStart: Boolean get() = pendingStops.get() > 0

    /** Este servidor já chegou a ficar RUNNING alguma vez? (só então um [stop] parado em STOPPED é um desligamento normal). */
    @Volatile
    private var startedOnce = false

    /** [stop] chamado numa instância que nunca ligou: o [start] seguinte não liga (evita servidor órfão). */
    @Volatile
    private var cancelled = false

    private var serverSocket: SSLServerSocket? = null
    private var acceptThread: Thread? = null
    private var watchdogThread: Thread? = null
    private var serverId = ""
    private var serverName = "WinLauncher"

    /** Nome que o servidor mostra aos clientes (modelo do aparelho). */
    val displayName: String get() = serverName

    /**
     * Gancho da Parte 2: recebe pair_request, auth e command de um cliente que já fez hello. Devolva true se tratou a
     * mensagem. Roda na thread do cliente. Sem gancho (Parte 1), o servidor responde com erro.
     */
    @Volatile
    var onMessage: ((Client, RemoteProtocol.Message) -> Boolean)? = null

    /** Parte 2: avisa que um cliente foi desconectado (qualquer motivo). Roda na thread do cliente, no fim da conexão. */
    @Volatile
    var onClientClosed: ((Client) -> Unit)? = null

    fun clientCount(): Int = clientCount.get()

    /** [stop] foi chamado antes de este servidor ligar: [start] não liga mais. */
    val isCancelled: Boolean get() = cancelled

    /** Prazo de uma escrita em uso (10 s no servidor real). */
    val writeTimeoutMs: Long get() = writeMs

    /** Conexões encerradas porque uma escrita ficou parada além do prazo, desde que o servidor ligou. */
    fun writeTimeoutCount(): Int = writeTimeouts.get()

    /** Limite de conexões por IP em uso (2 no servidor real). */
    val maxConnectionsPerIp: Int get() = maxPerIp

    /** Conexões recusadas por já haver [maxPerIp] do mesmo IP, desde que o servidor ligou. */
    fun ipRejectedCount(): Int = ipRejected.get()

    /** Vagas por IP ocupadas agora por [ip] (diagnóstico/testes). */
    fun ipClientCount(ip: String): Int = limiter.count(ip)

    /** Quantos IPs têm registro no controle por IP agora (zero quando não há conexões: nada fica abandonado). */
    fun trackedIpCount(): Int = limiter.trackedIps()

    /** Prazo de autenticação em uso (15 s no servidor real). */
    val authTimeoutMs: Long get() = authMs

    /** Conexões encerradas por não se autenticarem dentro do prazo desde que o servidor ligou. */
    fun authTimeoutCount(): Int = authTimeouts.get()

    /** Conexões fechadas por vir de IP não permitido ou por excesso de clientes desde que o servidor ligou. */
    fun rejectedCount(): Int = rejected.get()

    fun clientsSnapshot(): List<Client> = synchronized(clients) { ArrayList(clients) }

    /** Threads do servidor ainda vivas (aceitação + vigia do prazo + clientes). Zero depois de [stop]. */
    fun liveThreads(): Int {
        var n = 0
        if (acceptThread?.isAlive == true) n++
        if (watchdogThread?.isAlive == true) n++
        for (c in clientsSnapshot()) if (c.thread?.isAlive == true) n++
        return n
    }

    private fun log(s: String) {
        Log.i(TAG, s)
        synchronized(logLines) {
            logLines.add(s)
            while (logLines.size > 40) logLines.removeAt(0)
        }
        try {
            events?.onLog(s)
        } catch (e: Throwable) {
        }
    }

    fun recentLog(): List<String> = synchronized(logLines) { ArrayList(logLines) }

    private fun setState(s: State, err: String = "") {
        state = s
        lastError = err
        try {
            events?.onState(s, err)
        } catch (e: Throwable) {
        }
    }

    private fun notifyClients() {
        try {
            events?.onClients(clientCount.get())
        } catch (e: Throwable) {
        }
    }

    // ------------------------------------------------------------------ ligar / desligar

    /** Liga o servidor. Nunca lança exceção: em caso de falha o estado vira ERROR (com o motivo) e tudo é liberado. */
    fun start(): Boolean = synchronized(lifecycle) { startLocked() }

    private fun startLocked(): Boolean {
        if (state == State.RUNNING) return true
        if (state == State.STARTING || state == State.STOPPING) return false
        if (cancelled || abortStart) {
            // Etapa 3, Bloco 2: stop() chegou antes do start(): não liga (o estado continua STOPPED, sem erro)
            log("início cancelado: o desligamento foi pedido antes de o servidor ligar")
            return false
        }
        stopping = false
        clientCount.set(0)
        rejected.set(0)
        authTimeouts.set(0)
        ipRejected.set(0)
        writeTimeouts.set(0)
        limiter.reset()
        synchronized(clients) { clients.clear() }
        setState(State.STARTING)
        var ss: SSLServerSocket? = null
        try {
            RemoteAuth.init(app)
            val rep = RemoteAuth.ensureKey()
            serverId = RemoteAuth.hex(rep.fingerprint).take(32)
            serverName = RemoteProtocol.clip(
                (Build.MODEL ?: "").trim().ifEmpty { "WinLauncher" }, RemoteProtocol.MAX_NAME
            )
            val ctx = RemoteAuth.buildServerSslContext()
            val sock = bindWithRetry(ctx)
            ss = sock
            if (abortStart) throw StartAborted()
            val supported = sock.supportedProtocols.toSet()
            val want = listOf("TLSv1.3", "TLSv1.2").filter { it in supported }
            if (!want.contains("TLSv1.2")) throw IOException("este Android não oferece TLS 1.2")
            sock.enabledProtocols = want.toTypedArray()
            sock.needClientAuth = false
            sock.wantClientAuth = false
            serverSocket = sock
            boundPort = sock.localPort
            protocols = want.joinToString(", ")
            val t = Thread({ acceptLoop(sock) }, "WinRemote-$tag-accept")
            t.isDaemon = true
            acceptThread = t
            t.start()
            val w = Thread({ watchdogLoop() }, "WinRemote-$tag-watchdog")
            w.isDaemon = true
            watchdogThread = w
            w.start()
            log("servidor ligado na porta $boundPort (TLS: $protocols)")
            startedOnce = true
            setState(State.RUNNING)
            return true
        } catch (e: StartAborted) {
            // stop() chegou durante o início: solta tudo e termina em STOPPED (não é erro)
            try {
                ss?.close()
            } catch (x: Exception) {
            }
            serverSocket = null
            acceptThread = null
            watchdogThread = null
            boundPort = 0
            log("início cancelado: o desligamento foi pedido durante a inicialização")
            setState(State.STOPPED)
            return false
        } catch (e: Throwable) {
            val msg = describe(e)
            log("falha ao ligar: $msg")
            try {
                ss?.close()
            } catch (x: Exception) {
            }
            serverSocket = null
            acceptThread = null
            watchdogThread = null
            boundPort = 0
            setState(State.ERROR, msg)
            return false
        }
    }

    private class StartAborted : RuntimeException("início cancelado")

    private fun isAddressInUse(e: IOException): Boolean {
        if (e !is java.net.BindException) return false
        val m = (e.message ?: "").lowercase()
        return m.contains("in use") || m.contains("eaddrinuse")
    }

    /**
     * Etapa 3, Bloco 2: cria e liga o socket de escuta com SO_REUSEADDR. Se a porta estiver ocupada (por exemplo, o
     * religamento logo depois de desligar, ou o sistema ainda soltando o socket anterior), tenta de novo até [bindAttempts]
     * vezes, esperando [bindRetryMs] entre elas; um [stop] pedido nesse meio tempo interrompe a espera na hora.
     * Se o Android não oferecer o socket "sem ligar" (createServerSocket()), usa o createServerSocket(porta, backlog, endereço) de antes.
     */
    private fun bindWithRetry(ctx: SSLContext): SSLServerSocket {
        val addr = InetAddress.getByName("0.0.0.0")
        val attempts = if (bindAttempts < 1) 1 else bindAttempts
        var lastErr: IOException? = null
        for (i in 1..attempts) {
            if (abortStart) throw StartAborted()
            var sock: SSLServerSocket? = null
            try {
                val made: SSLServerSocket = try {
                    val raw = ctx.serverSocketFactory.createServerSocket() as SSLServerSocket
                    try {
                        raw.reuseAddress = true
                        raw.bind(InetSocketAddress(addr, port), BACKLOG)
                    } catch (e: Throwable) {
                        try {
                            raw.close()
                        } catch (x: Exception) {
                        }
                        throw e
                    }
                    raw
                } catch (e: java.net.BindException) {
                    throw e
                } catch (e: IOException) {
                    // fábrica sem socket "sem ligar": caminho antigo
                    ctx.serverSocketFactory.createServerSocket(port, BACKLOG, addr) as SSLServerSocket
                } catch (e: UnsupportedOperationException) {
                    ctx.serverSocketFactory.createServerSocket(port, BACKLOG, addr) as SSLServerSocket
                }
                sock = made
                if (i > 1) log("porta $port liberada na tentativa $i de $attempts")
                return made
            } catch (e: IOException) {
                try {
                    sock?.close()
                } catch (x: Exception) {
                }
                if (!isAddressInUse(e) || i == attempts) throw e
                lastErr = e
                log("porta $port ocupada (tentativa $i de $attempts); tentando de novo em $bindRetryMs ms")
                val until = SystemClock.elapsedRealtime() + bindRetryMs
                while (!abortStart) {
                    val left = until - SystemClock.elapsedRealtime()
                    if (left <= 0) break
                    try {
                        Thread.sleep(minOf(left, 25L))
                    } catch (ie: InterruptedException) {
                        Thread.currentThread().interrupt()
                        throw StartAborted()
                    }
                }
            }
        }
        throw lastErr ?: IOException("não foi possível abrir a porta $port")
    }

    /** Desliga: fecha o socket de escuta e todos os clientes, e espera as threads terminarem (até ~2 s). Pode ser chamado várias vezes. */
    fun stop() {
        // Etapa 3, Bloco 2: sinaliza ANTES de pegar o lock. Um start() em andamento (esperando a porta ficar livre) enxerga
        // isto, desiste e solta o lock; um start() que ainda não começou ao entrar vê o sinal e não liga.
        pendingStops.incrementAndGet()
        try {
            stopLocked()
        } finally {
            pendingStops.decrementAndGet()
        }
    }

    private fun stopLocked() {
        synchronized(lifecycle) {
            if (state == State.STOPPED) {
                // nunca ligou: o start() seguinte (por exemplo, a thread "starter" do serviço, que pode chegar depois) não liga
                if (!startedOnce && !cancelled) {
                    cancelled = true
                    log("desligamento antes de ligar: este servidor não vai mais ligar")
                }
                return
            }
            if (state == State.STARTING) return
            stopping = true
            val wasError = state == State.ERROR
            if (!wasError) setState(State.STOPPING)
            val ss = serverSocket
            serverSocket = null
            try {
                ss?.close()
            } catch (e: Exception) {
            }
            for (c in clientsSnapshot()) c.forceClose()
            watchdogThread?.interrupt()
            val deadline = SystemClock.elapsedRealtime() + 2000L
            joinUntil(acceptThread, deadline)
            joinUntil(watchdogThread, deadline)
            for (c in clientsSnapshot()) joinUntil(c.thread, deadline)
            val left = liveThreads()
            if (left > 0) log("aviso: $left thread(s) ainda terminando depois do desligamento")
            acceptThread = null
            watchdogThread = null
            synchronized(clients) { clients.clear() }
            clientCount.set(0)
            limiter.reset()
            boundPort = 0
            log("servidor desligado")
            setState(State.STOPPED)
            notifyClients()
        }
    }

    /**
     * Etapa 2A: vigia do prazo de autenticação. Uma única thread por servidor (não uma por cliente): a cada poucos
     * décimos de segundo fecha, com RST, todo cliente que nunca se autenticou e passou de [authMs] desde o accept().
     * Fechar o socket de outra thread também destrava um handshake TLS ou uma leitura parados; a thread do cliente
     * então cai no `finally` normal ([Client.finish]), que remove o cliente da lista, devolve a vaga e avisa o bridge
     * (que descarta um pedido de pareamento pendente desse cliente). Clientes autenticados nunca são tocados.
     */
    private fun watchdogLoop() {
        val step = (minOf(authMs, writeMs) / 4).coerceIn(50L, 250L)
        while (!stopping) {
            try {
                Thread.sleep(step)
            } catch (e: InterruptedException) {
                break
            }
            val now = SystemClock.elapsedRealtime()
            for (c in clientsSnapshot()) {
                try {
                    c.enforceAuthDeadline(now)
                    c.enforceWriteDeadline(now)
                } catch (e: Throwable) {
                }
            }
        }
    }

    private fun joinUntil(t: Thread?, deadline: Long) {
        if (t == null || t === Thread.currentThread()) return
        val left = deadline - SystemClock.elapsedRealtime()
        if (left <= 0) return
        try {
            t.join(left)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun describe(e: Throwable): String {
        val m = e.message
        return e.javaClass.simpleName + (if (m.isNullOrBlank()) "" else ": $m")
    }

    // ------------------------------------------------------------------ aceitação

    private fun acceptLoop(ss: SSLServerSocket) {
        var failures = 0
        while (!stopping && !ss.isClosed) {
            val raw: Socket = try {
                ss.accept()
            } catch (e: IOException) {
                if (stopping || ss.isClosed) break
                failures++
                log("erro no accept (${failures}): " + describe(e))
                if (failures >= 20) {
                    log("accept falhou 20 vezes seguidas; servidor será desligado")
                    setState(State.ERROR, "falha repetida ao aceitar conexões: " + describe(e))
                    break
                }
                try {
                    Thread.sleep(250)
                } catch (x: InterruptedException) {
                    break
                }
                continue
            }
            failures = 0
            handleAccepted(raw)
        }
    }

    private fun handleAccepted(raw: Socket) {
        val remote = raw.inetAddress
        if (!isAllowedAddress(remote, allowLoopback)) {
            rejected.incrementAndGet()
            log("recusado (IP fora da rede local): " + (remote?.hostAddress ?: "?"))
            closeQuiet(raw, true)
            return
        }
        val sock = raw as? SSLSocket
        if (sock == null) {
            closeQuiet(raw, true)
            return
        }
        val ipKey = remote?.hostAddress ?: "?"
        if (sndBufBytes > 0) {
            try {
                sock.sendBufferSize = sndBufBytes
            } catch (e: Exception) {
            }
        }
        // Etapa 2B: vaga por IP reservada de forma atômica, ANTES do handshake TLS e antes de criar a thread
        val slot = limiter.tryAcquire(ipKey)
        if (slot == null) {
            rejected.incrementAndGet()
            ipRejected.incrementAndGet()
            log("recusado (limite de $maxPerIp conexões por IP): $ipKey")
            closeQuiet(raw, true)
            return
        }
        if (clientCount.incrementAndGet() > maxClients) {
            clientCount.decrementAndGet()
            slot.release()
            rejected.incrementAndGet()
            log("recusado (limite de $maxClients clientes): $ipKey")
            closeQuiet(raw, true)
            return
        }
        val c = Client(sock, nextClientId.getAndIncrement(), ipKey, slot)
        val t = Thread({ c.run() }, "WinRemote-$tag-client-${c.id}")
        t.isDaemon = true
        c.thread = t
        synchronized(clients) { clients.add(c) }
        if (stopping) {
            c.forceClose()
        }
        try {
            t.start()
        } catch (e: Throwable) {
            // a thread não nasceu: ninguém chamará finish(); desfaz tudo aqui (a vaga só é liberada uma vez)
            log("falha ao iniciar a thread do cliente #${c.id}: " + describe(e))
            c.abandon()
            return
        }
        notifyClients()
    }

    private fun closeQuiet(s: Socket, hard: Boolean) {
        if (hard) {
            try {
                s.setSoLinger(true, 0)
            } catch (e: Exception) {
            }
        }
        try {
            s.close()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ cliente

    /** Uma conexão de cliente. Uma thread própria lê as mensagens; [send] pode ser chamado de outras threads (nunca da principal). */
    inner class Client internal constructor(
        private val sock: SSLSocket,
        val id: Int,
        val address: String,
        private val ipSlot: IpLimiter.Slot
    ) {

        @Volatile
        var thread: Thread? = null
            internal set

        /** Nome/id informados no hello (\"\" antes do hello). */
        @Volatile
        var deviceId: String = ""
            private set

        @Volatile
        var deviceName: String = ""
            private set

        /** Capacidades opcionais que o cliente anunciou no hello (ex.: "queue"). Vazio antes do hello e para clientes antigos. */
        @Volatile
        var caps: List<String> = emptyList()
            private set

        /** Fez hello? */
        @Volatile
        var helloDone: Boolean = false
            private set

        /** Vira true quando o [RemoteBridge] valida o token do aparelho pareado (ou conclui o pareamento). Sem ele, nunca é true. */
        @Volatile
        var authenticated: Boolean = false
            set(v) {
                if (v) authSeen = true
                field = v
            }

        /** Etapa 2A: true assim que o cliente se autenticou alguma vez (não volta a false; revogação não reabre o prazo). */
        @Volatile
        private var authSeen: Boolean = false

        /** Instante do accept() (elapsedRealtime): início do prazo de autenticação. */
        private val connectedAt: Long = SystemClock.elapsedRealtime()

        @Volatile
        private var out: OutputStream? = null
        private val writeLock = Any()

        /** Etapa 3: instante em que a escrita em andamento começou (0 = nenhuma). Só quem tem o [writeLock] mexe. */
        @Volatile
        private var writeSince = 0L

        @Volatile
        private var drainOnClose = false

        @Volatile
        private var closed = false

        /** Envia uma mensagem (thread-safe). Lança IOException se a conexão caiu. */
        fun send(m: RemoteProtocol.Message) {
            val o = out ?: throw IOException("conexão ainda não está pronta")
            val bytes = RemoteProtocol.encodeFrame(m)
            synchronized(writeLock) {
                // Etapa 3: o vigia fecha o socket se esta escrita passar de [writeMs] (cliente que parou de ler)
                writeSince = SystemClock.elapsedRealtime()
                try {
                    o.write(bytes)
                    o.flush()
                } finally {
                    writeSince = 0L
                }
            }
        }

        private fun sendQuiet(m: RemoteProtocol.Message) {
            try {
                send(m)
            } catch (e: Exception) {
            }
        }

        /** Etapa 2A: chamado pelo vigia. Fecha o cliente se nunca se autenticou e o prazo acabou. Cliente autenticado: não faz nada. */
        internal fun enforceAuthDeadline(now: Long) {
            if (closed || authSeen || authenticated) return
            if (now - connectedAt < authMs) return
            if (authSeen || authenticated) return
            authTimeouts.incrementAndGet()
            log("cliente #$id não se autenticou em ${authMs / 1000.0} s; desconectado")
            forceClose()
        }

        /**
         * Etapa 3: chamado pelo vigia. Uma escrita parada além de [writeMs] (o outro lado não lê e o buffer encheu)
         * fecha a conexão com RST; isso destrava a thread que escrevia e quem esperava pelo [writeLock]. Vale para
         * clientes autenticados também (o prazo de autenticação não os alcança).
         */
        internal fun enforceWriteDeadline(now: Long) {
            val ws = writeSince
            if (ws == 0L || closed) return
            if (now - ws < writeMs) return
            if (writeSince != ws) return
            writeTimeouts.incrementAndGet()
            log("cliente #$id não leu por ${writeMs / 1000.0} s (escrita parada); desconectado")
            forceClose()
        }

        /** Fecha na hora (usado no desligamento): RST em vez de fechamento educado, para nunca travar. */
        fun forceClose() {
            closed = true
            closeQuiet(sock, true)
        }

        private fun fail(code: RemoteProtocol.ErrorCode, text: String, id: Long? = null) {
            sendQuiet(RemoteProtocol.Message.ErrorMsg(code, RemoteProtocol.clip(text, RemoteProtocol.MAX_TEXT), id))
            drainOnClose = true
            closed = true
        }

        fun run() {
            log("cliente #$id conectou: $address")
            try {
                sock.soTimeout = HANDSHAKE_MS.toInt()
                sock.startHandshake()
                val poll = minOf(5000L, pingMs / 2, idleMs / 3).coerceAtLeast(100L).toInt()
                sock.soTimeout = poll
                out = sock.outputStream
                val reader = FrameReader(sock.inputStream)
                var lastRx = SystemClock.elapsedRealtime()
                var lastPing = lastRx
                while (!stopping && !closed) {
                    val line: String? = try {
                        reader.next()
                    } catch (e: SocketTimeoutException) {
                        val now = SystemClock.elapsedRealtime()
                        if (reader.hasPartial && now - reader.partialSince > PARTIAL_MS) {
                            fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "mensagem incompleta")
                            break
                        }
                        if (now - lastRx > idleMs) {
                            log("cliente #$id inativo; desconectado")
                            break
                        }
                        if (helloDone && now - maxOf(lastRx, lastPing) >= pingMs) {
                            sendQuiet(RemoteProtocol.Message.Ping)
                            lastPing = now
                        }
                        continue
                    }
                    if (line == null) break
                    lastRx = SystemClock.elapsedRealtime()
                    val msg = try {
                        RemoteProtocol.decode(line)
                    } catch (e: RemoteProtocol.ProtocolException) {
                        fail(e.code, e.message ?: "mensagem inválida")
                        break
                    }
                    handle(msg)
                }
            } catch (e: RemoteProtocol.ProtocolException) {
                fail(e.code, e.message ?: "mensagem inválida")
            } catch (e: Throwable) {
                if (!stopping && !closed) log("cliente #$id: " + describe(e))
            } finally {
                finish()
            }
        }

        private fun handle(msg: RemoteProtocol.Message) {
            if (!helloDone) {
                if (msg !is RemoteProtocol.Message.Hello) {
                    fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "envie hello primeiro")
                    return
                }
                if (msg.role != "remote") {
                    fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "role inválido")
                    return
                }
                if (msg.version != RemoteProtocol.VERSION) {
                    fail(RemoteProtocol.ErrorCode.UNSUPPORTED_VERSION, "versão de protocolo não suportada")
                    return
                }
                deviceId = msg.deviceId
                deviceName = msg.deviceName
                caps = msg.caps
                try {
                    send(RemoteProtocol.Message.Hello(RemoteProtocol.VERSION, serverId, serverName, "server", RemoteProtocol.SERVER_CAPS))
                } catch (e: Exception) {
                    closed = true
                    return
                }
                helloDone = true
                log("cliente #$id: hello de \"${RemoteProtocol.clip(msg.deviceName, 32)}\"")
                return
            }
            when (msg) {
                RemoteProtocol.Message.Ping -> sendQuiet(RemoteProtocol.Message.Pong)
                RemoteProtocol.Message.Pong -> {
                }
                is RemoteProtocol.Message.Hello -> fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "hello repetido")
                is RemoteProtocol.Message.PairRequest -> {
                    if (!offer(msg)) {
                        sendQuiet(
                            RemoteProtocol.Message.ErrorMsg(
                                RemoteProtocol.ErrorCode.PAIRING_DENIED, "pareamento ainda não disponível nesta versão", null
                            )
                        )
                    }
                }
                is RemoteProtocol.Message.Auth -> {
                    if (!offer(msg)) {
                        sendQuiet(
                            RemoteProtocol.Message.ErrorMsg(
                                RemoteProtocol.ErrorCode.NOT_PAIRED, "autenticação ainda não disponível nesta versão", null
                            )
                        )
                    }
                }
                is RemoteProtocol.Message.CommandMsg -> {
                    if (!offer(msg)) {
                        sendQuiet(
                            RemoteProtocol.Message.ErrorMsg(
                                RemoteProtocol.ErrorCode.NOT_PAIRED, "aparelho não pareado", msg.id
                            )
                        )
                    }
                }
                else -> fail(RemoteProtocol.ErrorCode.BAD_REQUEST, "tipo de mensagem não aceito do cliente")
            }
        }

        private fun offer(msg: RemoteProtocol.Message): Boolean {
            val h = onMessage ?: return false
            return try {
                h(this, msg)
            } catch (e: Throwable) {
                log("cliente #$id: erro no tratamento de ${msg.type}: " + describe(e))
                false
            }
        }

        /** Depois de um erro fatal, lê e descarta o que o cliente ainda mandou (até 64 KB / 0,5 s) para o erro chegar antes do fechamento. */
        private fun drainInput() {
            try {
                sock.soTimeout = 200
                val input = sock.inputStream
                val buf = ByteArray(4096)
                var total = 0
                val end = SystemClock.elapsedRealtime() + 500L
                while (total < 65536 && SystemClock.elapsedRealtime() < end) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                }
            } catch (e: Exception) {
            }
        }

        /** Etapa 2B: só para quando a thread do cliente não pôde ser iniciada. */
        internal fun abandon() {
            closeQuiet(sock, true)
            val removed = synchronized(clients) { clients.remove(this) }
            if (removed) clientCount.decrementAndGet()
            ipSlot.release()
            notifyClients()
        }

        private fun finish() {
            if (drainOnClose) drainInput()
            closeQuiet(sock, false)
            val removed = synchronized(clients) { clients.remove(this) }
            if (removed) clientCount.decrementAndGet()
            ipSlot.release() // Etapa 2B: devolve a vaga do IP (idempotente; só a primeira chamada conta)
            log("cliente #$id desconectou")
            try {
                onClientClosed?.invoke(this)
            } catch (e: Throwable) {
            }
            notifyClients()
        }
    }
}

// ---------------------------------------------------------------------- limite por IP (Etapa 2B)

/**
 * Controle de conexões simultâneas por IP. [tryAcquire] reserva uma vaga de forma atômica (sob um único lock, sem
 * "verifica e depois incrementa"), então conexões simultâneas nunca passam de [max]. Cada [Slot] libera a vaga uma
 * única vez ([Slot.release] é idempotente); o registro do IP é removido quando chega a zero (nada fica abandonado) e
 * o contador nunca fica negativo. [reset] (ligar/desligar o servidor) troca a "época": vagas antigas liberadas depois
 * não mexem nas contagens da nova época.
 */
class IpLimiter(private val max: Int) {
    private val lock = Any()
    private val counts = HashMap<String, Int>()
    private var epoch = 0L

    inner class Slot internal constructor(val ip: String, private val slotEpoch: Long) {
        private val done = java.util.concurrent.atomic.AtomicBoolean(false)

        fun release() {
            if (done.compareAndSet(false, true)) releaseInternal(ip, slotEpoch)
        }
    }

    /** Reserva uma vaga para [ip]; null se o IP já tem [max] conexões. */
    fun tryAcquire(ip: String): Slot? = synchronized(lock) {
        val cur = counts[ip] ?: 0
        if (cur >= max) {
            null
        } else {
            counts[ip] = cur + 1
            Slot(ip, epoch)
        }
    }

    private fun releaseInternal(ip: String, slotEpoch: Long) {
        synchronized(lock) {
            if (slotEpoch != epoch) return
            val cur = counts[ip] ?: return
            if (cur <= 1) counts.remove(ip) else counts[ip] = cur - 1
        }
    }

    fun count(ip: String): Int = synchronized(lock) { counts[ip] ?: 0 }

    fun trackedIps(): Int = synchronized(lock) { counts.size }

    fun total(): Int = synchronized(lock) { counts.values.sum() }

    fun reset() {
        synchronized(lock) {
            epoch++
            counts.clear()
        }
    }
}

// ---------------------------------------------------------------------- leitura de linhas

/**
 * Lê mensagens (linhas terminadas em '\n', no máximo [RemoteProtocol.MAX_FRAME_BYTES] bytes sem o '\n').
 * Diferente de [RemoteProtocol.readFrame], guarda os bytes já lidos quando o socket dá timeout no meio da mensagem.
 */
private class FrameReader(private val input: InputStream) {
    private val store = ByteArray(RemoteProtocol.MAX_FRAME_BYTES + 4096)
    private var start = 0
    private var end = 0

    val hasPartial: Boolean get() = end > start

    /** Instante (elapsedRealtime) em que chegou o primeiro byte da mensagem em andamento. */
    var partialSince = 0L
        private set

    /** Próxima mensagem; null = o cliente fechou a conexão limpo. Pode lançar SocketTimeoutException (estado preservado). */
    fun next(): String? {
        while (true) {
            var i = start
            while (i < end && store[i] != '\n'.code.toByte()) i++
            if (i < end) {
                val len = i - start
                if (len > RemoteProtocol.MAX_FRAME_BYTES) {
                    throw RemoteProtocol.ProtocolException(RemoteProtocol.ErrorCode.TOO_LARGE, "mensagem grande demais")
                }
                val s = String(store, start, len, Charsets.UTF_8)
                start = i + 1
                if (start >= end) {
                    start = 0
                    end = 0
                    partialSince = 0L
                } else {
                    partialSince = SystemClock.elapsedRealtime()
                }
                return s
            }
            if (end - start > RemoteProtocol.MAX_FRAME_BYTES) {
                throw RemoteProtocol.ProtocolException(RemoteProtocol.ErrorCode.TOO_LARGE, "mensagem grande demais")
            }
            if (start > 0) {
                System.arraycopy(store, start, store, 0, end - start)
                end -= start
                start = 0
            }
            val n = input.read(store, end, store.size - end)
            if (n < 0) {
                if (end - start == 0) return null
                throw RemoteProtocol.ProtocolException(
                    RemoteProtocol.ErrorCode.BAD_REQUEST, "conexão encerrada no meio de uma mensagem"
                )
            }
            if (n > 0 && end == start) partialSince = SystemClock.elapsedRealtime()
            end += n
        }
    }
}

// ---------------------------------------------------------------------- autotestes

/**
 * Autoteste local do servidor (Etapa 3B, Parte 1). Sobe servidores de teste em portas efêmeras (porta 0) e conecta
 * clientes TLS reais por 127.0.0.1; não mexe no servidor "de verdade" nem na porta 48655.
 * Chame fora da thread principal (leva alguns segundos).
 */
object RemoteServerTest {

    private class PinTrust(private val expected: ByteArray) : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {
            throw CertificateException("não usado")
        }

        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {
            val c = chain?.firstOrNull() ?: throw CertificateException("servidor não apresentou certificado")
            if (!MessageDigest.isEqual(RemoteAuth.fingerprint(c), expected)) {
                throw CertificateException("hash do certificado não confere")
            }
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    private class TestClient(val s: SSLSocket) {
        private val reader = FrameReader(s.inputStream)
        private val out = s.outputStream

        fun send(m: RemoteProtocol.Message) {
            out.write(RemoteProtocol.encodeFrame(m))
            out.flush()
        }

        fun sendRaw(b: ByteArray) {
            out.write(b)
            out.flush()
        }

        /** Próxima mensagem ou null se a conexão fechou limpa. */
        fun recv(): RemoteProtocol.Message? {
            val l = reader.next() ?: return null
            return RemoteProtocol.decode(l)
        }

        fun close() {
            try {
                s.close()
            } catch (e: Exception) {
            }
        }
    }

    private const val CLIENT_ID = "AutotesteRemote01"

    private fun hello(role: String = "remote", version: Int = RemoteProtocol.VERSION) =
        RemoteProtocol.Message.Hello(version, CLIENT_ID, "Autoteste", role)

    private fun connect(port: Int, trust: TrustManager?, protocols: Array<String>? = null, timeoutMs: Int = 5000): TestClient {
        val c = SSLContext.getInstance("TLS")
        c.init(null, if (trust == null) null else arrayOf(trust), null)
        val raw = Socket()
        try {
            raw.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 3000)
        } catch (e: Throwable) {
            try {
                raw.close()
            } catch (x: Exception) {
            }
            throw e
        }
        val s = c.socketFactory.createSocket(raw, "127.0.0.1", port, true) as SSLSocket
        try {
            if (protocols != null) s.enabledProtocols = protocols
            s.soTimeout = timeoutMs
            s.startHandshake()
        } catch (e: Throwable) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            throw e
        }
        return TestClient(s)
    }

    private fun check(checks: MutableList<RemoteAuth.Check>, name: String, essential: Boolean = true, block: () -> String) {
        try {
            checks.add(RemoteAuth.Check(name, true, block(), essential))
        } catch (e: Throwable) {
            checks.add(RemoteAuth.Check(name, false, e.javaClass.simpleName + ": " + (e.message ?: ""), essential))
        }
    }

    private fun expectHello(c: TestClient): RemoteProtocol.Message.Hello {
        val m = c.recv()
        if (m !is RemoteProtocol.Message.Hello || m.role != "server") throw IllegalStateException("esperava hello do servidor, veio: $m")
        return m
    }

    private fun expectError(c: TestClient, code: RemoteProtocol.ErrorCode) {
        val m = c.recv()
        if (m !is RemoteProtocol.Message.ErrorMsg) throw IllegalStateException("esperava erro ${code.wire}, veio: $m")
        if (m.code != code) throw IllegalStateException("esperava erro ${code.wire}, veio ${m.code.wire}")
    }

    private fun expectClosed(c: TestClient) {
        var closed = false
        try {
            while (true) {
                val m = c.recv()
                if (m == null) {
                    closed = true
                    break
                }
                if (m !is RemoteProtocol.Message.Ping) break // chegou outra coisa: não fechou
            }
        } catch (e: SocketTimeoutException) {
        } catch (e: IOException) {
            closed = true
        } catch (e: RemoteProtocol.ProtocolException) {
            closed = true
        }
        if (!closed) throw IllegalStateException("a conexão deveria ter sido encerrada pelo servidor")
    }

    /**
     * Etapa 2A: espera o servidor fechar a conexão e devolve quanto tempo levou. Com [keepAlive] o cliente fica ativo
     * (manda ping a cada ~200 ms e responde aos pings do servidor): atividade NÃO pode estender o prazo de autenticação.
     * Lança se a conexão não fechar em [maxMs].
     */
    private fun timeToClose(c: TestClient, maxMs: Long, keepAlive: Boolean = false): Long {
        val t0 = SystemClock.elapsedRealtime()
        c.s.soTimeout = 200
        while (SystemClock.elapsedRealtime() - t0 < maxMs) {
            try {
                val m = c.recv() ?: return SystemClock.elapsedRealtime() - t0
                if (keepAlive && m == RemoteProtocol.Message.Ping) c.send(RemoteProtocol.Message.Pong)
            } catch (e: SocketTimeoutException) {
                if (keepAlive) {
                    try {
                        c.send(RemoteProtocol.Message.Ping)
                    } catch (x: IOException) {
                        return SystemClock.elapsedRealtime() - t0
                    }
                }
            } catch (e: IOException) {
                return SystemClock.elapsedRealtime() - t0
            } catch (e: RemoteProtocol.ProtocolException) {
                return SystemClock.elapsedRealtime() - t0
            }
        }
        throw IllegalStateException("a conexão não foi encerrada em $maxMs ms")
    }

    private fun requireWindow(elapsed: Long, authMs: Long, what: String): String {
        if (elapsed < authMs - 150L) throw IllegalStateException("$what: desconectado cedo demais (${elapsed} ms, prazo $authMs ms)")
        if (elapsed > authMs + 2500L) throw IllegalStateException("$what: desconectado tarde demais (${elapsed} ms, prazo $authMs ms)")
        return "$elapsed ms"
    }

    private fun tryHello(port: Int, trust: TrustManager?, bindIp: String? = null): TestClient? {
        // devolve o cliente já com o hello do servidor recebido, ou null se a conexão foi recusada/encerrada
        val c = SSLContext.getInstance("TLS")
        c.init(null, if (trust == null) null else arrayOf(trust), null)
        val raw = Socket()
        try {
            if (bindIp != null) raw.bind(InetSocketAddress(InetAddress.getByName(bindIp), 0))
            raw.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 3000)
        } catch (e: IOException) {
            try {
                raw.close()
            } catch (x: Exception) {
            }
            return null
        }
        val s = c.socketFactory.createSocket(raw, "127.0.0.1", port, true) as SSLSocket
        try {
            s.soTimeout = 3000
            s.startHandshake()
            val tc = TestClient(s)
            tc.send(hello())
            val m = tc.recv()
            if (m is RemoteProtocol.Message.Hello) return tc
            tc.close()
            return null
        } catch (e: IOException) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            return null
        } catch (e: RemoteProtocol.ProtocolException) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            return null
        }
    }

    private fun alive(c: TestClient): Boolean = try {
        c.s.soTimeout = 3000
        c.send(RemoteProtocol.Message.Ping)
        c.recv() == RemoteProtocol.Message.Pong
    } catch (e: Exception) {
        false
    }

    /** Mensagem grande (~12 KB) só para encher buffers; o servidor só a codifica (não valida como cliente). */
    private fun bigMessage(): RemoteProtocol.Message =
        RemoteProtocol.artChunks(ByteArray(RemoteProtocol.ART_CHUNK_BYTES) { (it * 31 + 7).toByte() })[0]

    /** Cliente TLS autenticado (pelo gancho de teste) que quase não tem buffer de recepção: depois do hello NÃO lê mais. */
    private fun connectSmallBuffer(port: Int, trust: TrustManager?): TestClient {
        val c = SSLContext.getInstance("TLS")
        c.init(null, if (trust == null) null else arrayOf(trust), null)
        val raw = Socket()
        raw.receiveBufferSize = 4096
        raw.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 3000)
        val s = c.socketFactory.createSocket(raw, "127.0.0.1", port, true) as SSLSocket
        s.soTimeout = 5000
        s.startHandshake()
        return TestClient(s)
    }

    private fun authenticatedServerSide(srv: RemoteServer): RemoteServer.Client? =
        srv.clientsSnapshot().firstOrNull { it.authenticated }

    private fun waitUntil(ms: Long, cond: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < end) {
            if (cond()) return true
            try {
                Thread.sleep(50)
            } catch (e: InterruptedException) {
                return cond()
            }
        }
        return cond()
    }

    private fun ip(a: Int, b: Int, c: Int, d: Int): InetAddress =
        InetAddress.getByAddress(byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte()))

    private fun testThreads(): List<String> =
        Thread.getAllStackTraces().keys.filter { it.isAlive && it.name.startsWith("WinRemote-test") }.map { it.name }

    fun selfTest(ctx: Context): List<RemoteAuth.Check> {
        val checks = ArrayList<RemoteAuth.Check>()
        val app = ctx.applicationContext
        RemoteAuth.init(app)

        var fpHolder: ByteArray? = null
        check(checks, "Chave e certificado do servidor") {
            val r = RemoteAuth.ensureKey()
            fpHolder = r.fingerprint
            r.algorithm + ", SHA-256 " + RemoteAuth.shortFingerprint(r.fingerprint) + "…"
        }
        val fp = fpHolder
        if (fp == null) {
            checks.add(RemoteAuth.Check("Demais testes", false, "não executados (sem chave/certificado)"))
            return checks
        }
        val pin = PinTrust(fp)

        // regra de endereços (sem rede)
        check(checks, "Regra de IPs: só rede local IPv4") {
            val ok = listOf(
                ip(192, 168, 1, 5), ip(10, 0, 0, 2), ip(172, 16, 0, 1), ip(172, 31, 255, 1), ip(169, 254, 1, 1)
            )
            val bad = listOf(
                ip(8, 8, 8, 8), ip(172, 15, 0, 1), ip(172, 32, 0, 1), ip(100, 64, 0, 1), ip(127, 0, 0, 1),
                ip(0, 0, 0, 0), ip(224, 0, 0, 1), ip(192, 169, 0, 1), InetAddress.getByName("::1")
            )
            for (a in ok) if (!RemoteServer.isAllowedAddress(a)) throw IllegalStateException("deveria aceitar ${a.hostAddress}")
            for (a in bad) if (RemoteServer.isAllowedAddress(a)) throw IllegalStateException("deveria recusar ${a.hostAddress}")
            if (!RemoteServer.isAllowedAddress(ip(127, 0, 0, 1), true)) throw IllegalStateException("loopback de teste deveria passar")
            "${ok.size} endereços aceitos e ${bad.size} recusados, como esperado"
        }

        val srv = RemoteServer(app, port = 0, allowLoopback = true, maxClients = RemoteServer.MAX_CLIENTS, tag = "test1", maxPerIp = 16)
        val srvNet = RemoteServer(app, port = 0, allowLoopback = false, tag = "test2", maxPerIp = 16)
        val srvIdle = RemoteServer(app, port = 0, allowLoopback = true, tag = "test3", idleMs = 1500L, pingMs = 400L, maxPerIp = 16)
        val authTest = 1200L
        val srvAuth = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 3, tag = "test4", authMs = authTest, maxPerIp = 16)
        // Etapa 2B: servidor com o limite REAL de 2 por IP (e 8 no total, para o limite por IP ser o que aparece)
        val srvIp = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 8, tag = "test5", authMs = 2500L)
        // Etapa 3: servidores para escrita travada (buffer de envio pequeno); um com prazo curto, outro com prazo longo
        val srvW = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 4, tag = "test6", writeMs = 1500L, sndBufBytes = 8192, maxPerIp = 16)
        val srvW2 = RemoteServer(app, port = 0, allowLoopback = true, maxClients = 4, tag = "test7", writeMs = 120_000L, sndBufBytes = 8192, maxPerIp = 16)
        val authHook: (RemoteServer.Client, RemoteProtocol.Message) -> Boolean = { cl, m ->
            if (m is RemoteProtocol.Message.Auth) {
                cl.authenticated = true
                true
            } else {
                false
            }
        }
        srvW.onMessage = authHook
        srvW2.onMessage = authHook
        // gancho de teste: um "auth" qualquer marca o cliente como autenticado (simula o RemoteBridge)
        srvAuth.onMessage = { cl, m ->
            if (m is RemoteProtocol.Message.Auth) {
                cl.authenticated = true
                true
            } else {
                false
            }
        }
        try {
            // 1) inicialização
            var port = 0
            check(checks, "Servidor liga (porta de teste)") {
                if (!srv.start()) throw IllegalStateException("não ligou: " + srv.lastError)
                if (srv.state != RemoteServer.State.RUNNING) throw IllegalStateException("estado ${srv.state}")
                port = srv.boundPort
                if (port !in 1..65535) throw IllegalStateException("porta inválida: $port")
                "porta efêmera $port (a porta real é ${RemoteProtocol.DEFAULT_PORT}); TLS habilitado: ${srv.protocols}"
            }
            if (port == 0) {
                checks.add(RemoteAuth.Check("Demais testes do servidor", false, "não executados (o servidor de teste não ligou)"))
                return checks
            }

            // 2) handshake TLS real
            check(checks, "Handshake TLS real (cliente fixando o hash do certificado)") {
                val c = connect(port, pin)
                try {
                    val sess = c.s.session
                    val peer = sess.peerCertificates.firstOrNull() as? X509Certificate
                        ?: throw IllegalStateException("sem certificado do servidor")
                    if (!MessageDigest.isEqual(RemoteAuth.fingerprint(peer), fp)) throw IllegalStateException("certificado diferente do esperado")
                    "negociado ${sess.protocol} com ${sess.cipherSuite}; certificado confere com o hash da Etapa 3A"
                } finally {
                    c.close()
                }
            }
            check(checks, "TLS 1.2 aceito") {
                val c = connect(port, pin, arrayOf("TLSv1.2"))
                try {
                    "negociado " + c.s.session.protocol
                } finally {
                    c.close()
                }
            }
            val supports13 = try {
                SSLContext.getDefault().supportedSSLParameters.protocols.contains("TLSv1.3")
            } catch (e: Exception) {
                false
            }
            if (supports13) {
                check(checks, "TLS 1.3 aceito", essential = false) {
                    val c = connect(port, pin, arrayOf("TLSv1.3"))
                    try {
                        "negociado " + c.s.session.protocol
                    } finally {
                        c.close()
                    }
                }
            } else {
                checks.add(RemoteAuth.Check("TLS 1.3 aceito", false, "este Android não oferece TLS 1.3 no cliente (normal abaixo do Android 10); só o TLS 1.2 foi testado", false))
            }
            check(checks, "Cliente que não confia no certificado é recusado no handshake", essential = false) {
                var refused = false
                try {
                    connect(port, PinTrust(ByteArray(32))).close()
                } catch (e: IOException) {
                    refused = true
                }
                if (!refused) throw IllegalStateException("handshake com hash errado foi aceito")
                var refused2 = false
                try {
                    connect(port, null).close()
                } catch (e: IOException) {
                    refused2 = true
                }
                if (!refused2) throw IllegalStateException("handshake com a confiança padrão do sistema foi aceito (certificado autoassinado!)")
                "hash errado e confiança padrão do sistema: ambos recusaram (esperado para certificado autoassinado)"
            }

            // 3) hello, ping/pong, não autenticado
            check(checks, "Mensagem hello") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    val h = expectHello(c)
                    if (h.version != RemoteProtocol.VERSION) throw IllegalStateException("versão ${h.version}")
                    "servidor respondeu hello (versão ${h.version}, nome \"${h.deviceName}\")"
                } finally {
                    c.close()
                }
            }
            check(checks, "Ping e pong") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.Ping)
                    val m = c.recv()
                    if (m != RemoteProtocol.Message.Pong) throw IllegalStateException("esperava pong, veio: $m")
                    "ping respondido com pong"
                } finally {
                    c.close()
                }
            }
            check(checks, "Cliente sem pareamento não executa comandos") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.CommandMsg(5L, RemoteProtocol.Command.NEXT))
                    expectError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                    c.send(RemoteProtocol.Message.Auth(CLIENT_ID, RemoteProtocol.b64(ByteArray(RemoteProtocol.TOKEN_BYTES) { 1 })))
                    expectError(c, RemoteProtocol.ErrorCode.NOT_PAIRED)
                    c.send(RemoteProtocol.Message.Ping)
                    if (c.recv() != RemoteProtocol.Message.Pong) throw IllegalStateException("conexão deveria continuar viva")
                    "command e auth recusados com not_paired; a conexão continua válida"
                } finally {
                    c.close()
                }
            }

            // 4) mensagens inválidas
            check(checks, "Rejeita mensagem fora de ordem, JSON inválido e versão errada") {
                var c = connect(port, pin)
                try {
                    c.send(RemoteProtocol.Message.Ping)
                    expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.sendRaw("{nao e json\n".toByteArray(Charsets.UTF_8))
                    expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                c = connect(port, pin)
                try {
                    c.sendRaw("{\"v\":99,\"t\":\"ping\"}\n".toByteArray(Charsets.UTF_8))
                    expectError(c, RemoteProtocol.ErrorCode.UNSUPPORTED_VERSION)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                c = connect(port, pin)
                try {
                    c.send(hello(role = "server"))
                    expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                    expectClosed(c)
                } finally {
                    c.close()
                }
                "ping antes do hello, JSON quebrado, versão 99 e role errado: todos com erro e conexão encerrada"
            }
            check(checks, "Rejeita mensagem maior que 16 KB") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    val big = ByteArray(RemoteProtocol.MAX_FRAME_BYTES + 10) { 'a'.code.toByte() }
                    c.sendRaw(big)
                    c.sendRaw(byteArrayOf('\n'.code.toByte()))
                    expectError(c, RemoteProtocol.ErrorCode.TOO_LARGE)
                    expectClosed(c)
                    "mensagem de ${big.size} bytes recusada com too_large e conexão encerrada"
                } finally {
                    c.close()
                }
            }

            // 5) limite de clientes
            check(checks, "Limite de ${RemoteServer.MAX_CLIENTS} clientes simultâneos") {
                if (!waitUntil(3000) { srv.clientCount() == 0 }) throw IllegalStateException("clientes anteriores não saíram (${srv.clientCount()})")
                val cs = ArrayList<TestClient>()
                try {
                    repeat(RemoteServer.MAX_CLIENTS) {
                        val c = connect(port, pin)
                        cs.add(c)
                        c.send(hello())
                        expectHello(c)
                    }
                    if (srv.clientCount() != RemoteServer.MAX_CLIENTS) throw IllegalStateException("contagem ${srv.clientCount()}")
                    var served = false
                    try {
                        val c5 = connect(port, pin)
                        try {
                            c5.send(hello())
                            served = c5.recv() is RemoteProtocol.Message.Hello
                        } finally {
                            c5.close()
                        }
                    } catch (e: IOException) {
                    } catch (e: RemoteProtocol.ProtocolException) {
                    }
                    if (served) throw IllegalStateException("o quinto cliente foi atendido")
                    cs.removeAt(0).close()
                    if (!waitUntil(3000) { srv.clientCount() < RemoteServer.MAX_CLIENTS }) {
                        throw IllegalStateException("vaga não foi liberada depois que um cliente saiu")
                    }
                    val again = connect(port, pin)
                    cs.add(again)
                    again.send(hello())
                    expectHello(again)
                    "4 clientes atendidos, o 5º recusado; depois de um sair, um novo entrou (recusados: ${srv.rejectedCount()})"
                } finally {
                    for (c in cs) c.close()
                }
            }

            // 6) cliente de IP não permitido
            check(checks, "Cliente de IP não permitido é recusado") {
                if (!srvNet.start()) throw IllegalStateException("servidor de teste não ligou: " + srvNet.lastError)
                var answered = false
                try {
                    val c = connect(srvNet.boundPort, pin)
                    try {
                        c.send(hello())
                        answered = c.recv() is RemoteProtocol.Message.Hello
                    } finally {
                        c.close()
                    }
                } catch (e: IOException) {
                } catch (e: RemoteProtocol.ProtocolException) {
                }
                if (answered) throw IllegalStateException("cliente de IP fora da regra foi atendido")
                if (!waitUntil(2000) { srvNet.rejectedCount() >= 1 }) throw IllegalStateException("o servidor não registrou a recusa")
                "conexão de 127.0.0.1 (fora da regra no servidor de teste sem loopback) fechada antes do hello; recusas: ${srvNet.rejectedCount()}"
            }

            // 7) ping do servidor e timeout de inatividade
            check(checks, "Ping do servidor mantém a conexão; silêncio é desconectado") {
                if (!srvIdle.start()) throw IllegalStateException("servidor de teste não ligou: " + srvIdle.lastError)
                val c = connect(srvIdle.boundPort, pin, null, 6000)
                try {
                    c.send(hello())
                    expectHello(c)
                    var pings = 0
                    val t0 = SystemClock.elapsedRealtime()
                    while (SystemClock.elapsedRealtime() - t0 < 3200L) {
                        val m = c.recv() ?: throw IllegalStateException("servidor fechou apesar dos pongs")
                        if (m == RemoteProtocol.Message.Ping) {
                            pings++
                            c.send(RemoteProtocol.Message.Pong)
                        }
                    }
                    if (pings < 2) throw IllegalStateException("poucos pings recebidos ($pings)")
                    // agora fica em silêncio: não responde mais
                    expectClosed(c)
                    "$pings pings recebidos e respondidos por mais que o limite de inatividade (1,5 s no teste); sem resposta, foi desconectado"
                } finally {
                    c.close()
                }
            }


            // 7b) Etapa 2A: prazo para autenticar/parear
            check(checks, "Prazo de autenticação: 15 s no servidor real") {
                if (RemoteServer.AUTH_TIMEOUT_MS != 15_000L) throw IllegalStateException("constante = ${RemoteServer.AUTH_TIMEOUT_MS}")
                if (srv.authTimeoutMs != 15_000L) throw IllegalStateException("o servidor usa ${srv.authTimeoutMs} ms por padrão")
                if (srvAuth.authTimeoutMs != authTest) throw IllegalStateException("o servidor de teste não usa o prazo curto")
                "padrão 15000 ms; servidor de teste com $authTest ms"
            }
            check(checks, "Prazo de 15 s real: cliente que só conectou e fez hello é desconectado entre 15 e ~17 s") {
                if (!srvAuth.start()) throw IllegalStateException("servidor de teste não ligou: " + srvAuth.lastError)
                val before = srv.authTimeoutCount()
                val c = connect(port, pin, null, 5000)
                try {
                    c.send(hello())
                    expectHello(c)
                    val t = timeToClose(c, 20_000L)
                    val r = requireWindow(t, RemoteServer.AUTH_TIMEOUT_MS, "prazo real")
                    if (srv.authTimeoutCount() != before + 1) throw IllegalStateException("authTimeoutCount não aumentou")
                    if (!waitUntil(2000) { srv.clientCount() == 0 }) throw IllegalStateException("a vaga não foi liberada (${srv.clientCount()})")
                    "desconectado depois de $r (prazo 15000 ms); vaga liberada"
                } finally {
                    c.close()
                }
            }
            check(checks, "Prazo (teste curto): cliente que conecta e não envia nada é desconectado e a vaga é liberada") {
                val before = srvAuth.authTimeoutCount()
                val c = connect(srvAuth.boundPort, pin, null, 5000)
                try {
                    if (srvAuth.clientCount() != 1) throw IllegalStateException("contagem ${srvAuth.clientCount()}")
                    val t = timeToClose(c, authTest + 4000L)
                    val r = requireWindow(t, authTest, "cliente mudo")
                    if (srvAuth.authTimeoutCount() != before + 1) throw IllegalStateException("authTimeoutCount não aumentou")
                    if (!waitUntil(2000) { srvAuth.clientCount() == 0 && srvAuth.clientsSnapshot().isEmpty() }) {
                        throw IllegalStateException("cliente continua na lista (${srvAuth.clientCount()})")
                    }
                    "desconectado depois de $r (prazo $authTest ms); contador e lista de clientes zerados"
                } finally {
                    c.close()
                }
            }
            check(checks, "Prazo: cliente ativo (hello, ping/pong) mas sem autenticar também é desconectado") {
                val c = connect(srvAuth.boundPort, pin, null, 5000)
                try {
                    c.send(hello())
                    expectHello(c)
                    val t = timeToClose(c, authTest + 4000L, keepAlive = true)
                    val r = requireWindow(t, authTest, "cliente ativo")
                    "mesmo trocando ping/pong, foi desconectado depois de $r (a atividade não estende o prazo)"
                } finally {
                    c.close()
                }
            }
            check(checks, "Prazo: conexão TCP que nunca inicia o handshake TLS é encerrada") {
                val raw = Socket()
                try {
                    raw.connect(InetSocketAddress(InetAddress.getByName("127.0.0.1"), srvAuth.boundPort), 3000)
                    if (!waitUntil(2000) { srvAuth.clientCount() == 1 }) throw IllegalStateException("o servidor não registrou a conexão")
                    val t0 = SystemClock.elapsedRealtime()
                    raw.soTimeout = (authTest + 4000L).toInt()
                    var closed = false
                    try {
                        // o servidor pode mandar um alerta TLS antes de fechar: lê até o fim da conexão
                        val inp = raw.getInputStream()
                        while (true) {
                            if (inp.read() < 0) {
                                closed = true
                                break
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    } catch (e: IOException) {
                        closed = true
                    }
                    if (!closed) throw IllegalStateException("a conexão parada não foi encerrada")
                    val r = requireWindow(SystemClock.elapsedRealtime() - t0, authTest, "handshake parado")
                    if (!waitUntil(2000) { srvAuth.clientCount() == 0 }) throw IllegalStateException("a vaga não foi liberada")
                    "conexão sem handshake encerrada depois de $r; vaga liberada"
                } finally {
                    try {
                        raw.close()
                    } catch (e: Exception) {
                    }
                }
            }
            check(checks, "Prazo: cliente autenticado não é desconectado (e um não autenticado ao lado é)") {
                val before = srvAuth.authTimeoutCount()
                val a = connect(srvAuth.boundPort, pin, null, 5000)
                val b = connect(srvAuth.boundPort, pin, null, 5000)
                try {
                    a.send(hello())
                    expectHello(a)
                    a.send(RemoteProtocol.Message.Auth(CLIENT_ID, RemoteProtocol.b64(ByteArray(RemoteProtocol.TOKEN_BYTES) { 1 })))
                    if (!waitUntil(2000) { srvAuth.clientsSnapshot().any { it.authenticated } }) {
                        throw IllegalStateException("o cliente de teste não ficou autenticado")
                    }
                    timeToClose(b, authTest + 4000L)
                    // já passou do prazo desde o accept do cliente autenticado: tem de continuar vivo e funcionando
                    a.send(RemoteProtocol.Message.Ping)
                    if (a.recv() != RemoteProtocol.Message.Pong) throw IllegalStateException("cliente autenticado não respondeu depois do prazo")
                    Thread.sleep(authTest + 600L)
                    a.send(RemoteProtocol.Message.Ping)
                    if (a.recv() != RemoteProtocol.Message.Pong) throw IllegalStateException("cliente autenticado foi derrubado")
                    // se o pareamento for revogado depois (authenticated=false), o prazo não reabre
                    for (cl in srvAuth.clientsSnapshot()) if (cl.authenticated) cl.authenticated = false
                    Thread.sleep(authTest + 600L)
                    a.send(RemoteProtocol.Message.Ping)
                    if (a.recv() != RemoteProtocol.Message.Pong) throw IllegalStateException("o prazo reabriu depois de authenticated=false")
                    if (srvAuth.authTimeoutCount() != before + 1) {
                        throw IllegalStateException("authTimeoutCount ${srvAuth.authTimeoutCount() - before} (esperado 1: só o cliente não autenticado)")
                    }
                    if (srvAuth.clientCount() != 1) throw IllegalStateException("contagem ${srvAuth.clientCount()} (esperado 1)")
                    "autenticado sobreviveu a mais de ${2 * authTest + 600L} ms; só o não autenticado foi desconectado (1 timeout)"
                } finally {
                    a.close()
                    b.close()
                }
            }
            check(checks, "Prazo: nenhuma conexão abandonada; vagas voltam e nenhuma thread de cliente sobra") {
                if (!waitUntil(3000) { srvAuth.clientCount() == 0 }) throw IllegalStateException("clientes restantes: ${srvAuth.clientCount()}")
                // 3 vagas ocupadas por clientes mudos, o 4º é recusado; depois do prazo as 3 vagas voltam
                val cs = ArrayList<TestClient>()
                try {
                    repeat(3) { cs.add(connect(srvAuth.boundPort, pin, null, 5000)) }
                    if (!waitUntil(2000) { srvAuth.clientCount() == 3 }) throw IllegalStateException("contagem ${srvAuth.clientCount()}")
                    var served = false
                    try {
                        val c4 = connect(srvAuth.boundPort, pin, null, 2000)
                        try {
                            c4.send(hello())
                            served = c4.recv() is RemoteProtocol.Message.Hello
                        } finally {
                            c4.close()
                        }
                    } catch (e: IOException) {
                    } catch (e: RemoteProtocol.ProtocolException) {
                    }
                    if (served) throw IllegalStateException("o 4º cliente foi atendido com as vagas cheias")
                    for (c in cs) timeToClose(c, authTest + 4000L)
                    if (!waitUntil(3000) { srvAuth.clientCount() == 0 && srvAuth.clientsSnapshot().isEmpty() }) {
                        throw IllegalStateException("vagas não voltaram (${srvAuth.clientCount()})")
                    }
                    val again = connect(srvAuth.boundPort, pin, null, 5000)
                    cs.add(again)
                    again.send(hello())
                    expectHello(again)
                    val clientThreads = Thread.getAllStackTraces().keys.count { it.isAlive && it.name.startsWith("WinRemote-test4-client") }
                    if (clientThreads > 1) throw IllegalStateException("$clientThreads threads de cliente vivas (esperado no máximo 1)")
                    // servidor em repouso: só aceitação + vigia (2 threads) além do cliente ainda aberto
                    if (srvAuth.liveThreads() > 3) throw IllegalStateException("threads do servidor: ${srvAuth.liveThreads()}")
                    "3 mudos desconectados, vagas devolvidas e reutilizadas; threads de cliente vivas: $clientThreads"
                } finally {
                    for (c in cs) c.close()
                }
            }


            // 7c) Etapa 2B: limite de 2 conexões simultâneas por IP
            val lo = "127.0.0.1"
            check(checks, "Limite por IP: constante é 2 e o servidor real usa 2") {
                if (RemoteServer.MAX_PER_IP != 2) throw IllegalStateException("constante = ${RemoteServer.MAX_PER_IP}")
                if (srvIp.maxConnectionsPerIp != 2) throw IllegalStateException("srvIp usa ${srvIp.maxConnectionsPerIp}")
                if (!srvIp.start()) throw IllegalStateException("servidor de teste não ligou: " + srvIp.lastError)
                "padrão 2 conexões por IP"
            }
            check(checks, "Limite por IP: 2 conexões do mesmo IP são aceitas; a 3ª é recusada sem derrubar as outras") {
                val a = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("1ª conexão recusada")
                val b = tryHello(srvIp.boundPort, pin)
                if (b == null) {
                    a.close()
                    throw IllegalStateException("2ª conexão recusada")
                }
                try {
                    if (srvIp.ipClientCount(lo) != 2) throw IllegalStateException("ocupadas: ${srvIp.ipClientCount(lo)}")
                    val before = srvIp.ipRejectedCount()
                    val third = tryHello(srvIp.boundPort, pin)
                    if (third != null) {
                        third.close()
                        throw IllegalStateException("a 3ª conexão do mesmo IP foi atendida")
                    }
                    if (!waitUntil(2000) { srvIp.ipRejectedCount() > before }) throw IllegalStateException("recusa por IP não contada")
                    if (!alive(a) || !alive(b)) throw IllegalStateException("a recusa da 3ª prejudicou um cliente já conectado")
                    if (srvIp.ipClientCount(lo) != 2) throw IllegalStateException("contador mudou para ${srvIp.ipClientCount(lo)}")
                    "2 aceitas, 3ª recusada (recusas por IP: ${srvIp.ipRejectedCount()}); as duas existentes continuaram respondendo ping/pong"
                } finally {
                    a.close()
                    b.close()
                }
            }
            check(checks, "Limite por IP: depois que um sai, uma nova conexão do mesmo IP entra") {
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 }) throw IllegalStateException("vagas não voltaram (${srvIp.ipClientCount(lo)})")
                val a = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("1ª recusada")
                val b = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("2ª recusada").also { a.close() }
                var c: TestClient? = null
                try {
                    if (tryHello(srvIp.boundPort, pin) != null) throw IllegalStateException("3ª deveria ser recusada")
                    a.close()
                    if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 1 }) throw IllegalStateException("a vaga não foi liberada (${srvIp.ipClientCount(lo)})")
                    c = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("nova conexão recusada depois de liberar a vaga")
                    if (!alive(b)) throw IllegalStateException("o cliente que ficou foi prejudicado")
                    "vaga liberada ao desconectar e reaproveitada"
                } finally {
                    a.close()
                    b.close()
                    c?.close()
                }
            }
            check(checks, "Limite por IP: outro IP continua conectando quando o primeiro está cheio", essential = false) {
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 }) throw IllegalStateException("vagas não voltaram")
                val a = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("1ª recusada")
                val b = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("2ª recusada").also { a.close() }
                var o1: TestClient? = null
                var o2: TestClient? = null
                try {
                    if (tryHello(srvIp.boundPort, pin) != null) throw IllegalStateException("3ª do IP cheio deveria ser recusada")
                    // 127.0.0.2 é outro IP de origem (loopback inteiro 127/8 funciona em Linux/Android)
                    o1 = tryHello(srvIp.boundPort, pin, "127.0.0.2")
                    if (o1 == null) throw IllegalStateException("não foi possível usar 127.0.0.2 como IP de origem neste aparelho (limitação do teste, não do servidor); coberto pelo teste do IpLimiter")
                    o2 = tryHello(srvIp.boundPort, pin, "127.0.0.2") ?: throw IllegalStateException("2ª do outro IP recusada")
                    if (srvIp.ipClientCount("127.0.0.2") != 2 || srvIp.ipClientCount(lo) != 2) throw IllegalStateException("contagens por IP erradas")
                    "127.0.0.1 cheio (2) e 127.0.0.2 com 2 conexões próprias: IPs independentes"
                } finally {
                    a.close()
                    b.close()
                    o1?.close()
                    o2?.close()
                }
            }
            check(checks, "Limite por IP: falhas liberam a vaga (TCP sem TLS, lixo no handshake, erro de protocolo, timeout de autenticação)") {
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 && srvIp.ipClientCount("127.0.0.2") == 0 }) throw IllegalStateException("vagas não voltaram")
                val port = srvIp.boundPort
                // mais rodadas que o limite: se alguma falha vazar vaga, a rodada seguinte é recusada
                repeat(4) { i ->
                    // a) conecta e fecha sem handshake
                    Socket().use { r ->
                        r.connect(InetSocketAddress(InetAddress.getByName(lo), port), 3000)
                    }
                    // b) bytes que não são TLS
                    Socket().use { r ->
                        r.connect(InetSocketAddress(InetAddress.getByName(lo), port), 3000)
                        r.getOutputStream().write("isto nao e TLS\r\n\r\n".toByteArray())
                        r.getOutputStream().flush()
                        r.soTimeout = 1500
                        try {
                            while (r.getInputStream().read() >= 0) {
                            }
                        } catch (e: IOException) {
                        }
                    }
                    // c) erro de protocolo (ping antes do hello): servidor responde erro e fecha
                    val c = connect(port, pin)
                    try {
                        c.send(RemoteProtocol.Message.Ping)
                        expectError(c, RemoteProtocol.ErrorCode.BAD_REQUEST)
                        expectClosed(c)
                    } finally {
                        c.close()
                    }
                    if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 }) {
                        throw IllegalStateException("rodada ${i + 1}: vaga presa (${srvIp.ipClientCount(lo)})")
                    }
                }
                // d) timeout de autenticação (cliente mudo, 2 de uma vez = IP cheio) libera as duas
                val m1 = connect(port, pin)
                val m2 = connect(port, pin)
                try {
                    timeToClose(m1, 2500L + 4000L)
                    timeToClose(m2, 2500L + 4000L)
                } finally {
                    m1.close()
                    m2.close()
                }
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 }) throw IllegalStateException("timeout não liberou a vaga (${srvIp.ipClientCount(lo)})")
                val ok1 = tryHello(port, pin) ?: throw IllegalStateException("conexão recusada depois das falhas (vaga vazou)")
                val ok2 = tryHello(port, pin)
                ok1.close()
                ok2?.close()
                if (ok2 == null) throw IllegalStateException("2ª conexão recusada depois das falhas (vaga vazou)")
                "4 rodadas de 3 falhas + timeout de autenticação: nenhuma vaga ficou presa"
            }
            check(checks, "Limite por IP: conexões simultâneas (corrida) nunca passam de 2") {
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 }) throw IllegalStateException("vagas não voltaram")
                val n = 16
                val ready = java.util.concurrent.CountDownLatch(n)
                val go = java.util.concurrent.CountDownLatch(1)
                val done = java.util.concurrent.CountDownLatch(n)
                val served = java.util.concurrent.CopyOnWriteArrayList<TestClient>()
                val hold = java.util.concurrent.CountDownLatch(1)
                var maxSeen = 0
                for (i in 0 until n) {
                    val t = Thread {
                        try {
                            ready.countDown()
                            go.await()
                            val c = tryHello(srvIp.boundPort, pin)
                            if (c != null) served.add(c)
                        } catch (e: Throwable) {
                        } finally {
                            done.countDown()
                        }
                    }
                    t.isDaemon = true
                    t.start()
                }
                try {
                    ready.await(5, java.util.concurrent.TimeUnit.SECONDS)
                    go.countDown()
                    val end = SystemClock.elapsedRealtime() + 8000L
                    while (done.count > 0L && SystemClock.elapsedRealtime() < end) {
                        maxSeen = maxOf(maxSeen, srvIp.ipClientCount(lo))
                        Thread.sleep(2)
                    }
                    if (done.count > 0L) throw IllegalStateException("conexões de teste não terminaram")
                    maxSeen = maxOf(maxSeen, srvIp.ipClientCount(lo))
                    if (served.size != 2) throw IllegalStateException("atendidas: ${served.size} (esperado exatamente 2)")
                    if (maxSeen > 2) throw IllegalStateException("o contador chegou a $maxSeen")
                    if (srvIp.clientCount() > 2) throw IllegalStateException("clientes no servidor: ${srvIp.clientCount()}")
                    "$n conexões ao mesmo tempo: exatamente ${served.size} atendidas, máximo observado do contador: $maxSeen"
                } finally {
                    hold.countDown()
                    for (c in served) c.close()
                }
            }
            check(checks, "Limite por IP: contador correto depois de muitas conexões e desconexões") {
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 }) throw IllegalStateException("vagas não voltaram")
                var ok = 0
                repeat(25) {
                    val a = tryHello(srvIp.boundPort, pin) ?: throw IllegalStateException("rodada ${it + 1}: 1ª recusada")
                    val b = tryHello(srvIp.boundPort, pin)
                    if (it % 2 == 0) {
                        a.close()
                        b?.close()
                    } else {
                        b?.close()
                        a.close()
                    }
                    if (b == null) throw IllegalStateException("rodada ${it + 1}: 2ª recusada")
                    ok += 2
                }
                if (!waitUntil(3000) { srvIp.ipClientCount(lo) == 0 && srvIp.clientCount() == 0 }) {
                    throw IllegalStateException("sobrou contagem: ip=${srvIp.ipClientCount(lo)} clientes=${srvIp.clientCount()}")
                }
                if (srvIp.trackedIpCount() != 0) throw IllegalStateException("registro de IP abandonado: ${srvIp.trackedIpCount()}")
                "$ok conexões em 25 rodadas; contador do IP 0, clientes 0, nenhum IP registrado"
            }
            check(checks, "Limite por IP: IpLimiter (corrida direta, liberação única, sem negativo, sem registro abandonado)") {
                val lim = IpLimiter(2)
                val threads = 64
                val acquired = java.util.concurrent.CopyOnWriteArrayList<IpLimiter.Slot>()
                val go = java.util.concurrent.CountDownLatch(1)
                val fin = java.util.concurrent.CountDownLatch(threads)
                repeat(threads) {
                    val t = Thread {
                        try {
                            go.await()
                            val s = lim.tryAcquire("10.0.0.1")
                            if (s != null) acquired.add(s)
                        } catch (e: Throwable) {
                        } finally {
                            fin.countDown()
                        }
                    }
                    t.isDaemon = true
                    t.start()
                }
                go.countDown()
                if (!fin.await(5, java.util.concurrent.TimeUnit.SECONDS)) throw IllegalStateException("threads não terminaram")
                if (acquired.size != 2) throw IllegalStateException("$threads threads em corrida obtiveram ${acquired.size} vagas (esperado 2)")
                if (lim.count("10.0.0.1") != 2) throw IllegalStateException("contador ${lim.count("10.0.0.1")}")
                val other = lim.tryAcquire("10.0.0.2") ?: throw IllegalStateException("outro IP deveria ter vaga")
                // liberar várias vezes a mesma vaga só conta uma vez
                val first = acquired[0]
                repeat(5) { first.release() }
                if (lim.count("10.0.0.1") != 1) throw IllegalStateException("liberação repetida mexeu no contador: ${lim.count("10.0.0.1")}")
                acquired[1].release()
                other.release()
                if (lim.count("10.0.0.1") != 0 || lim.total() != 0 || lim.trackedIps() != 0) throw IllegalStateException("sobrou registro: total=${lim.total()} ips=${lim.trackedIps()}")
                // vaga antiga liberada depois de reset() não mexe na contagem nova
                val old = lim.tryAcquire("10.0.0.3") ?: throw IllegalStateException("sem vaga")
                lim.reset()
                val fresh = lim.tryAcquire("10.0.0.3") ?: throw IllegalStateException("sem vaga depois do reset")
                old.release()
                if (lim.count("10.0.0.3") != 1) throw IllegalStateException("vaga antiga alterou a contagem nova (${lim.count("10.0.0.3")})")
                fresh.release()
                if (lim.trackedIps() != 0) throw IllegalStateException("registro abandonado")
                "64 threads: exatamente 2 vagas; 5 liberações da mesma vaga contam 1; sem negativo; sem IP abandonado; vaga de época antiga ignorada"
            }


            // 7d) Etapa 3: escritas travadas em sockets
            check(checks, "Escrita travada: prazo padrão de 10 s no servidor real") {
                if (RemoteServer.WRITE_TIMEOUT_MS != 10_000L) throw IllegalStateException("constante = ${RemoteServer.WRITE_TIMEOUT_MS}")
                if (srv.writeTimeoutMs != 10_000L) throw IllegalStateException("srv usa ${srv.writeTimeoutMs}")
                if (!srvW.start()) throw IllegalStateException("servidor de teste não ligou: " + srvW.lastError)
                if (!srvW2.start()) throw IllegalStateException("servidor de teste 2 não ligou: " + srvW2.lastError)
                "padrão 10000 ms; servidores de teste com 1500 ms e 120000 ms"
            }
            check(checks, "Escrita travada: cliente autenticado que para de ler é desconectado no prazo e a vaga é liberada") {
                val c = connectSmallBuffer(srvW.boundPort, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.Auth(CLIENT_ID, RemoteProtocol.b64(ByteArray(RemoteProtocol.TOKEN_BYTES) { 1 })))
                    if (!waitUntil(2000) { authenticatedServerSide(srvW) != null }) throw IllegalStateException("não ficou autenticado")
                    val sc = authenticatedServerSide(srvW)!!
                    val before = srvW.writeTimeoutCount()
                    val msg = bigMessage()
                    val sent = java.util.concurrent.atomic.AtomicInteger(0)
                    val lastOk = java.util.concurrent.atomic.AtomicLong(SystemClock.elapsedRealtime())
                    val endedAt = java.util.concurrent.atomic.AtomicLong(0L)
                    val flood = Thread {
                        try {
                            while (true) {
                                sc.send(msg)
                                sent.incrementAndGet()
                                lastOk.set(SystemClock.elapsedRealtime())
                            }
                        } catch (e: Throwable) {
                        } finally {
                            endedAt.set(SystemClock.elapsedRealtime())
                        }
                    }
                    flood.isDaemon = true
                    flood.start()
                    if (!waitUntil(20_000) { endedAt.get() != 0L }) throw IllegalStateException("a escrita travada nunca foi interrompida (${sent.get()} envios)")
                    val stall = endedAt.get() - lastOk.get()
                    if (sent.get() < 1) throw IllegalStateException("nenhum envio antes de travar")
                    if (stall < 1500L - 200L) throw IllegalStateException("derrubou cedo demais: parado só $stall ms (prazo 1500 ms)")
                    if (stall > 1500L + 3000L) throw IllegalStateException("derrubou tarde demais: $stall ms")
                    if (srvW.writeTimeoutCount() != before + 1) throw IllegalStateException("writeTimeoutCount ${srvW.writeTimeoutCount() - before} (esperado 1)")
                    if (!waitUntil(3000) { srvW.clientCount() == 0 && srvW.ipClientCount("127.0.0.1") == 0 }) {
                        throw IllegalStateException("vaga não liberada (clientes ${srvW.clientCount()}, ip ${srvW.ipClientCount("127.0.0.1")})")
                    }
                    "${sent.get()} envios até o buffer encher; parada de $stall ms (prazo 1500 ms) => desconectado; thread liberada e vaga devolvida"
                } finally {
                    c.close()
                }
            }
            check(checks, "Escrita travada: cliente lento mas que continua lendo NÃO é desconectado") {
                val c = connectSmallBuffer(srvW.boundPort, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.Auth(CLIENT_ID, RemoteProtocol.b64(ByteArray(RemoteProtocol.TOKEN_BYTES) { 1 })))
                    if (!waitUntil(2000) { authenticatedServerSide(srvW) != null }) throw IllegalStateException("não ficou autenticado")
                    val sc = authenticatedServerSide(srvW)!!
                    val before = srvW.writeTimeoutCount()
                    val total = 50
                    val failure = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
                    val sender = Thread {
                        try {
                            val msg = bigMessage()
                            repeat(total) { sc.send(msg) }
                        } catch (e: Throwable) {
                            failure.set(e)
                        }
                    }
                    sender.isDaemon = true
                    sender.start()
                    var got = 0
                    c.s.soTimeout = 5000
                    while (got < total) {
                        val m = c.recv() ?: throw IllegalStateException("servidor fechou depois de $got mensagens")
                        if (m is RemoteProtocol.Message.ArtChunk) got++
                        Thread.sleep(15)
                    }
                    sender.join(5000)
                    failure.get()?.let { throw IllegalStateException("o envio falhou: $it") }
                    if (srvW.writeTimeoutCount() != before) throw IllegalStateException("cliente lento foi derrubado por engano")
                    if (!alive(c)) throw IllegalStateException("a conexão deixou de responder")
                    "$total mensagens de ~12 KB recebidas com leitura lenta (15 ms cada); nenhum timeout de escrita"
                } finally {
                    c.close()
                }
            }
            check(checks, "Escrita travada: stop() com escrita presa não trava e libera a thread que escrevia") {
                val c = connectSmallBuffer(srvW2.boundPort, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    c.send(RemoteProtocol.Message.Auth(CLIENT_ID, RemoteProtocol.b64(ByteArray(RemoteProtocol.TOKEN_BYTES) { 1 })))
                    if (!waitUntil(2000) { authenticatedServerSide(srvW2) != null }) throw IllegalStateException("não ficou autenticado")
                    val sc = authenticatedServerSide(srvW2)!!
                    val msg = bigMessage()
                    val sent = java.util.concurrent.atomic.AtomicInteger(0)
                    val ended = java.util.concurrent.atomic.AtomicBoolean(false)
                    val flood = Thread {
                        try {
                            while (true) {
                                sc.send(msg)
                                sent.incrementAndGet()
                            }
                        } catch (e: Throwable) {
                        } finally {
                            ended.set(true)
                        }
                    }
                    flood.isDaemon = true
                    flood.start()
                    // espera o envio travar (contador parado por 600 ms)
                    var last = -1
                    var stableSince = SystemClock.elapsedRealtime()
                    val t0 = SystemClock.elapsedRealtime()
                    while (SystemClock.elapsedRealtime() - t0 < 15_000L) {
                        val n = sent.get()
                        if (n != last) {
                            last = n
                            stableSince = SystemClock.elapsedRealtime()
                        } else if (SystemClock.elapsedRealtime() - stableSince > 600L) {
                            break
                        }
                        Thread.sleep(20)
                    }
                    if (ended.get()) throw IllegalStateException("a escrita não travou (prazo longo de 120 s)")
                    val t1 = SystemClock.elapsedRealtime()
                    srvW2.stop()
                    val took = SystemClock.elapsedRealtime() - t1
                    if (took > 3500L) throw IllegalStateException("stop() demorou $took ms com a escrita presa")
                    if (!waitUntil(3000) { ended.get() }) throw IllegalStateException("a thread que escrevia continuou presa depois do stop()")
                    if (srvW2.liveThreads() != 0) throw IllegalStateException("${srvW2.liveThreads()} thread(s) vivas")
                    "escrita travada depois de ${sent.get()} envios; stop() levou $took ms e liberou a thread; nenhuma thread sobrou"
                } finally {
                    c.close()
                }
            }

            // 7b) Etapa 3, Bloco 2: desligar e religar rápido
            fun freePort(): Int = java.net.ServerSocket(0).use { it.localPort }
            fun canBind(p: Int): Boolean = try {
                java.net.ServerSocket().use { s ->
                    s.reuseAddress = true
                    s.bind(InetSocketAddress("0.0.0.0", p))
                }
                true
            } catch (e: IOException) {
                false
            }
            fun newSrv(p: Int, attempts: Int = RemoteServer.BIND_ATTEMPTS, retryMs: Long = RemoteServer.BIND_RETRY_MS) =
                RemoteServer(app, port = p, allowLoopback = true, tag = "test8", maxPerIp = 16, bindAttempts = attempts, bindRetryMs = retryMs)

            check(checks, "Religamento: o gate decide ligar/desligar que se cruzam (sequências)") {
                val g = RemoteLifecycleGate()
                val P = RemoteLifecycleGate.Phase.values()
                fun eq(a: Any?, b: Any?, m: String) {
                    if (a != b) throw IllegalStateException("$m: obtido $a, esperado $b")
                }
                eq(g.requestStart(), RemoteLifecycleGate.StartDecision.START_NOW, "ligar parado")
                eq(g.requestStart(), RemoteLifecycleGate.StartDecision.ALREADY_ACTIVE, "ligar de novo")
                eq(g.onStartIntent(), RemoteLifecycleGate.IntentDecision.LAUNCH, "pedido chega")
                eq(g.requestStop(), RemoteLifecycleGate.StopDecision.BEGIN_STOP, "desligar")
                eq(g.requestStop(), RemoteLifecycleGate.StopDecision.NOTHING, "desligar de novo")
                eq(g.requestStart(), RemoteLifecycleGate.StartDecision.RESTART_AFTER_STOP, "ligar durante o desligamento NÃO é ignorado")
                eq(g.restartPending(), true, "religamento pendente")
                eq(g.requestStop(), RemoteLifecycleGate.StopDecision.CANCEL_RESTART, "desligar cancela o religamento")
                eq(g.stopFinished(), RemoteLifecycleGate.FinishDecision.DONE, "fim sem religamento")
                eq(g.phase(), RemoteLifecycleGate.Phase.IDLE, "fase final")
                // religamento executado
                g.requestStart(); g.onStartIntent(); g.requestStop()
                g.requestStart()
                eq(g.stopFinished(), RemoteLifecycleGate.FinishDecision.RESTART, "fim com religamento")
                eq(g.phase(), RemoteLifecycleGate.Phase.ACTIVE, "religado")
                eq(g.restartPending(), false, "pendência consumida")
                // dois "ligar" durante o desligamento = um só religamento
                g.requestStop(); g.requestStart(); g.requestStart()
                eq(g.stopFinished(), RemoteLifecycleGate.FinishDecision.RESTART, "religamento único")
                eq(g.stopFinished(), RemoteLifecycleGate.FinishDecision.DONE, "sem segundo religamento")
                // "Ligar" em trânsito cancelado por "Desligar"
                g.reset()
                eq(g.requestStart(), RemoteLifecycleGate.StartDecision.START_NOW, "ligar")
                eq(g.inFlight(), 1, "em trânsito")
                eq(g.requestStop(), RemoteLifecycleGate.StopDecision.BEGIN_STOP, "desligar antes de o pedido chegar")
                g.stopFinished()
                eq(g.onStartIntent(), RemoteLifecycleGate.IntentDecision.DROP, "pedido cancelado é descartado")
                eq(g.inFlight(), 0, "nada em trânsito")
                eq(g.phase(), RemoteLifecycleGate.Phase.IDLE, "fase")
                eq(g.requestStart(), RemoteLifecycleGate.StartDecision.START_NOW, "novo ligar depois do descarte")
                eq(g.onStartIntent(), RemoteLifecycleGate.IntentDecision.LAUNCH, "novo pedido liga")
                // falha ao enviar o pedido
                g.reset()
                g.requestStart(); g.startSendFailed()
                eq(g.phase(), RemoteLifecycleGate.Phase.IDLE, "falha de envio volta a IDLE")
                // serviço destruído no meio do desligamento
                g.reset()
                g.requestStart(); g.onStartIntent(); g.requestStop(); g.requestStart(); g.forceIdle()
                eq(g.phase(), RemoteLifecycleGate.Phase.IDLE, "forceIdle")
                eq(g.restartPending(), false, "forceIdle descarta religamento")
                eq(g.requestStop(), RemoteLifecycleGate.StopDecision.NOTHING, "desligar parado")
                "${P.size} fases; ligar durante desligamento vira religamento único; desligar o cancela; pedido em trânsito é descartado"
            }

            check(checks, "Religamento: gate em corrida (8 threads, fase nunca fica presa em STOPPING)") {
                val g = RemoteLifecycleGate()
                val err = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
                val ths = (0 until 8).map { n ->
                    Thread {
                        try {
                            val r = java.util.Random(n.toLong())
                            repeat(20000) {
                                when (r.nextInt(3)) {
                                    0 -> if (g.requestStart() == RemoteLifecycleGate.StartDecision.START_NOW) g.onStartIntent()
                                    1 -> if (g.requestStop() == RemoteLifecycleGate.StopDecision.BEGIN_STOP) g.stopFinished()
                                    else -> g.phase()
                                }
                            }
                        } catch (e: Throwable) {
                            err.set(e)
                        }
                    }
                }
                ths.forEach { it.start() }
                ths.forEach { it.join(30000) }
                if (err.get() != null) throw IllegalStateException("exceção: " + err.get())
                if (ths.any { it.isAlive }) throw IllegalStateException("threads presas")
                if (g.phase() == RemoteLifecycleGate.Phase.STOPPING) throw IllegalStateException("fase presa em STOPPING")
                if (g.inFlight() < 0) throw IllegalStateException("em trânsito negativo")
                "160 mil operações concorrentes sem exceção; fase final ${g.phase()}"
            }

            check(checks, "Servidor órfão: stop() antes do start() cancela o início (nada escuta)") {
                val p = freePort()
                val s = newSrv(p)
                s.stop()
                if (!s.isCancelled) throw IllegalStateException("não ficou cancelado")
                if (s.start()) throw IllegalStateException("start() ligou depois do stop()")
                if (s.state != RemoteServer.State.STOPPED) throw IllegalStateException("estado ${s.state}")
                if (s.boundPort != 0 || s.liveThreads() != 0) throw IllegalStateException("sobrou porta/thread")
                if (!canBind(p)) throw IllegalStateException("a porta $p ficou ocupada (servidor órfão)")
                "start() depois de stop() devolveu false, estado STOPPED, porta $p livre"
            }

            check(checks, "Servidor órfão: stop() e start() concorrentes (40 rodadas) nunca deixam o servidor escutando") {
                var started = 0
                var cancelledRuns = 0
                for (round in 0 until 40) {
                    val p = freePort()
                    val s = newSrv(p)
                    val go = java.util.concurrent.CountDownLatch(1)
                    val a = Thread {
                        go.await()
                        s.start()
                    }
                    val b = Thread {
                        go.await()
                        // atrasos de 0 a 80 ms: ora o stop chega antes do start, ora no meio, ora depois de ligado
                        val d = (round % 6) * 16L
                        if (d > 0L) Thread.sleep(d)
                        s.stop()
                    }
                    a.start(); b.start()
                    go.countDown()
                    a.join(8000); b.join(8000)
                    if (a.isAlive || b.isAlive) throw IllegalStateException("rodada $round: thread presa")
                    // se o start ganhou a corrida, o stop() já desligou; se o stop ganhou, o start foi cancelado
                    if (s.state != RemoteServer.State.STOPPED) throw IllegalStateException("rodada $round: estado ${s.state}")
                    if (s.liveThreads() != 0) throw IllegalStateException("rodada $round: ${s.liveThreads()} thread(s) vivas")
                    if (!canBind(p)) throw IllegalStateException("rodada $round: servidor órfão escutando na porta $p")
                    if (s.isCancelled) cancelledRuns++ else started++
                    if (!s.isCancelled && s.recentLog().none { it.contains("servidor ligado") && !it.contains("antes") }) {
                        // start ganhou mas não houve registro de ligado: seria uma contradição
                        if (s.recentLog().none { it.contains("início cancelado") }) throw IllegalStateException("rodada $round: sem registro do início")
                    }
                }
                "40 rodadas sem órfão (stop ganhou ${cancelledRuns}x, start ganhou ${started}x)"
            }

            check(checks, "Porta ocupada: nova tentativa liga assim que a porta é liberada") {
                val p = freePort()
                val blocker = java.net.ServerSocket()
                blocker.reuseAddress = true
                blocker.bind(InetSocketAddress("0.0.0.0", p))
                val s = newSrv(p, attempts = 40, retryMs = 100L)
                try {
                    Thread {
                        Thread.sleep(700)
                        try {
                            blocker.close()
                        } catch (e: Exception) {
                        }
                    }.start()
                    val t0 = SystemClock.elapsedRealtime()
                    if (!s.start()) throw IllegalStateException("não ligou: " + s.lastError)
                    val took = SystemClock.elapsedRealtime() - t0
                    if (s.boundPort != p) throw IllegalStateException("porta ${s.boundPort} (esperada $p)")
                    if (took < 500L) throw IllegalStateException("ligou em $took ms, antes de a porta ser liberada?")
                    if (s.recentLog().none { it.contains("tentando de novo") }) throw IllegalStateException("sem registro de nova tentativa")
                    val c = connect(p, pin)
                    try {
                        c.send(hello())
                        expectHello(c)
                    } finally {
                        c.close()
                    }
                    "ligou na porta $p depois de $took ms de espera e aceitou um cliente"
                } finally {
                    try { blocker.close() } catch (e: Exception) {}
                    s.stop()
                }
            }

            check(checks, "Porta ocupada: sem liberar, termina em ERROR depois das tentativas e solta tudo") {
                val p = freePort()
                val blocker = java.net.ServerSocket()
                blocker.reuseAddress = true
                blocker.bind(InetSocketAddress("0.0.0.0", p))
                val s = newSrv(p, attempts = 3, retryMs = 80L)
                try {
                    val t0 = SystemClock.elapsedRealtime()
                    if (s.start()) throw IllegalStateException("ligou com a porta ocupada")
                    val took = SystemClock.elapsedRealtime() - t0
                    if (s.state != RemoteServer.State.ERROR) throw IllegalStateException("estado ${s.state}")
                    if (took < 150L) throw IllegalStateException("desistiu depois de só $took ms (sem tentar de novo)")
                    if (s.liveThreads() != 0 || s.boundPort != 0) throw IllegalStateException("sobrou thread/porta")
                    "ERROR depois de $took ms (3 tentativas): " + s.lastError
                } finally {
                    try { blocker.close() } catch (e: Exception) {}
                    s.stop()
                }
            }

            check(checks, "Porta ocupada: stop() durante a espera interrompe na hora (sem esperar as tentativas)") {
                val p = freePort()
                val blocker = java.net.ServerSocket()
                blocker.reuseAddress = true
                blocker.bind(InetSocketAddress("0.0.0.0", p))
                val s = newSrv(p, attempts = 200, retryMs = 200L)
                try {
                    val res = java.util.concurrent.atomic.AtomicReference<Boolean?>(null)
                    val th = Thread { res.set(s.start()) }
                    th.start()
                    if (!waitUntil(3000) { s.state == RemoteServer.State.STARTING }) throw IllegalStateException("não ficou em STARTING")
                    Thread.sleep(300)
                    val t0 = SystemClock.elapsedRealtime()
                    s.stop()
                    th.join(5000)
                    val took = SystemClock.elapsedRealtime() - t0
                    if (th.isAlive) throw IllegalStateException("start() continuou esperando a porta")
                    if (res.get() != false) throw IllegalStateException("start() devolveu ${res.get()}")
                    if (took > 1500L) throw IllegalStateException("stop() demorou $took ms")
                    if (s.state != RemoteServer.State.STOPPED) throw IllegalStateException("estado ${s.state}")
                    blocker.close()
                    if (!canBind(p)) throw IllegalStateException("porta $p ficou presa")
                    "stop() durante a espera terminou tudo em $took ms (estado STOPPED)"
                } finally {
                    try { blocker.close() } catch (e: Exception) {}
                    s.stop()
                }
            }

            check(checks, "Religar 20 vezes na mesma porta (servidor novo a cada ciclo, com cliente conectado)") {
                val p = freePort()
                val t0 = SystemClock.elapsedRealtime()
                for (i in 1..20) {
                    val s = newSrv(p)
                    if (!s.start()) throw IllegalStateException("ciclo $i: não ligou: " + s.lastError)
                    if (s.boundPort != p) throw IllegalStateException("ciclo $i: porta ${s.boundPort}")
                    val c = connect(p, pin)
                    try {
                        c.send(hello())
                        expectHello(c)
                        s.stop()
                        if (s.state != RemoteServer.State.STOPPED) throw IllegalStateException("ciclo $i: estado ${s.state}")
                        if (s.liveThreads() != 0) throw IllegalStateException("ciclo $i: ${s.liveThreads()} thread(s) vivas")
                        if (s.trackedIpCount() != 0) throw IllegalStateException("ciclo $i: IP abandonado")
                    } finally {
                        c.close()
                    }
                }
                if (!canBind(p)) throw IllegalStateException("porta $p presa no fim")
                "20 ciclos ligar/conectar/desligar na porta $p em ${SystemClock.elapsedRealtime() - t0} ms; nenhuma thread sobrou"
            }

            check(checks, "Religar 20 vezes na mesma porta (mesma instância, stop() e start() repetidos)") {
                val p = freePort()
                val s = newSrv(p)
                val t0 = SystemClock.elapsedRealtime()
                try {
                    for (i in 1..20) {
                        if (!s.start()) throw IllegalStateException("ciclo $i: não ligou: " + s.lastError)
                        if (s.boundPort != p) throw IllegalStateException("ciclo $i: porta ${s.boundPort}")
                        val c = connect(p, pin)
                        try {
                            c.send(hello())
                            expectHello(c)
                        } finally {
                            c.close()
                        }
                        s.stop()
                        if (s.state != RemoteServer.State.STOPPED) throw IllegalStateException("ciclo $i: estado ${s.state}")
                        if (s.liveThreads() != 0) throw IllegalStateException("ciclo $i: threads vivas")
                    }
                    "20 ciclos na mesma instância e na porta $p em ${SystemClock.elapsedRealtime() - t0} ms"
                } finally {
                    s.stop()
                }
            }

            // 8) desligamento
            check(checks, "Desligamento fecha sockets e threads") {
                val c = connect(port, pin)
                try {
                    c.send(hello())
                    expectHello(c)
                    srv.stop()
                    if (srv.state != RemoteServer.State.STOPPED) throw IllegalStateException("estado ${srv.state}")
                    expectClosed(c)
                } finally {
                    c.close()
                }
                var refused = false
                try {
                    connect(port, pin, null, 1500).close()
                } catch (e: IOException) {
                    refused = true
                }
                if (!refused) throw IllegalStateException("a porta continua aceitando conexões")
                srvNet.stop()
                srvIdle.stop()
                srvAuth.stop()
                srvIp.stop()
                srvW.stop()
                srvW2.stop()
                if (srvW.liveThreads() != 0 || srvW2.liveThreads() != 0) throw IllegalStateException("threads dos servidores de escrita ainda vivas")
                if (srvIp.liveThreads() != 0 || srvIp.trackedIpCount() != 0) {
                    throw IllegalStateException("servidor de limite por IP: threads=${srvIp.liveThreads()} ips=${srvIp.trackedIpCount()}")
                }
                if (srvAuth.liveThreads() != 0) throw IllegalStateException("${srvAuth.liveThreads()} thread(s) do servidor de prazo ainda vivas (inclui o vigia)")
                if (!waitUntil(2000) { testThreads().isEmpty() }) {
                    throw IllegalStateException("threads ainda vivas: " + testThreads().joinToString(", "))
                }
                if (srv.liveThreads() != 0) throw IllegalStateException("${srv.liveThreads()} thread(s) do servidor ainda vivas")
                "cliente conectado foi desconectado, a porta fechou e nenhuma thread \"WinRemote-test\" sobrou"
            }
        } finally {
            try {
                srv.stop()
            } catch (e: Throwable) {
            }
            try {
                srvNet.stop()
            } catch (e: Throwable) {
            }
            try {
                srvIdle.stop()
            } catch (e: Throwable) {
            }
            try {
                srvAuth.stop()
            } catch (e: Throwable) {
            }
            try {
                srvIp.stop()
            } catch (e: Throwable) {
            }
            try {
                srvW.stop()
            } catch (e: Throwable) {
            }
            try {
                srvW2.stop()
            } catch (e: Throwable) {
            }
        }
        return checks
    }
}
