package com.example.winlauncher

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Protocolo entre a WinLauncher (servidor) e o WinLauncher Remote (cliente).
 *
 * Etapa 3A: somente definição das mensagens, codificação/decodificação, validação e limites.
 * Nada aqui abre socket, usa rede ou mexe no MediaSessionHub (só lê os tipos dele para mapear resultados).
 *
 * Etapa 3B, Parte 2 (acréscimos, sem alterar nada que já existia): mensagem "art" (capa em blocos de até 9000 bytes,
 * com id, índice, total, tamanho e SHA-256 da imagem inteira), campo "artId" na mensagem "state" e [ArtAssembler]
 * (remonta e valida a capa; é o que o app Remote usará).
 *
 * Formato: uma mensagem JSON por linha (UTF-8, terminada em '\n'), sempre com "v" (versão) e "t" (tipo).
 * O JSON gerado pelo org.json nunca contém quebra de linha crua, então '\n' é um delimitador seguro.
 *
 * Esboço do fluxo (será implementado nas próximas etapas):
 *  - Pareamento (TLS já ativo, cliente ainda sem confiar no certificado):
 *      Remote -> hello, pair_request(deviceId, deviceName, clientNonce)
 *      Server -> pair_challenge(serverNonce, serverName)
 *      Os dois celulares calculam o mesmo número (RemoteAuth.pairingCode) e o usuário compara;
 *      toca "Permitir" na WinLauncher -> Server -> pair_ok(token)   (ou error PAIRING_DENIED)
 *  - Uso normal: Remote -> hello, auth(deviceId, token) -> Server: auth_ok; depois command/state.
 */
object RemoteProtocol {

    const val VERSION = 1

    /** Porta padrão (reservada; o servidor real é da Etapa 3B). */
    const val DEFAULT_PORT = 48655

    /** Tipo de serviço NSD (reservado para a divulgação na rede, etapa seguinte). */
    const val SERVICE_TYPE = "_winlauncher._tcp."

    /** Tamanho máximo de uma mensagem (bytes, sem contar o '\n'). */
    const val MAX_FRAME_BYTES = 16 * 1024

    const val MAX_NAME = 64
    const val MAX_TEXT = 256
    const val NONCE_BYTES = 16
    const val TOKEN_BYTES = 32

    /** Capa: bytes de imagem por bloco (antes do base64), máximo de blocos e de bytes da imagem inteira. */
    const val ART_CHUNK_BYTES = 9000
    const val MAX_ART_CHUNKS = 24
    const val MAX_ART_BYTES = 192 * 1024
    const val ART_ID_LEN = 16
    private const val ART_DATA_MAX = (ART_CHUNK_BYTES * 4 + 2) / 3

    private const val B64_FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private val ID_REGEX = Regex("^[A-Za-z0-9_-]{8,64}$")
    private val ART_ID_REGEX = Regex("^[0-9a-f]{16}$")
    private val SHA_REGEX = Regex("^[0-9a-f]{64}$")

    // ------------------------------------------------------------------ tipos

    object Types {
        const val HELLO = "hello"
        const val PAIR_REQUEST = "pair_request"
        const val PAIR_CHALLENGE = "pair_challenge"
        const val PAIR_OK = "pair_ok"
        const val AUTH = "auth"
        const val AUTH_OK = "auth_ok"
        const val COMMAND = "command"
        const val COMMAND_RESULT = "command_result"
        const val STATE = "state"
        const val ART = "art"
        const val ERROR = "error"
        const val PING = "ping"
        const val PONG = "pong"

        /** Mouse Flow (Etapa 1): ver o bloco "Mouse Flow" mais abaixo. */
        const val MOUSE_SUB = "mouse_sub"
        const val MOUSE_STATE = "mouse_state"
        const val MOUSE = "mouse"
    }

    enum class Command(val wire: String) {
        PLAY_PAUSE("play_pause"),
        NEXT("next"),
        PREVIOUS("previous");

        companion object {
            fun fromWire(s: String?): Command? = values().firstOrNull { it.wire == s }
        }
    }

    enum class ErrorCode(val wire: String) {
        BAD_REQUEST("bad_request"),
        UNSUPPORTED_VERSION("unsupported_version"),
        TOO_LARGE("too_large"),
        NOT_PAIRED("not_paired"),
        PAIRING_DENIED("pairing_denied"),
        PAIRING_BUSY("pairing_busy"),
        RATE_LIMITED("rate_limited"),
        NO_ACCESS("no_access"),
        NO_SESSION("no_session"),
        UNAVAILABLE("unavailable"),
        INTERNAL("internal");

        companion object {
            fun fromWire(s: String?): ErrorCode = values().firstOrNull { it.wire == s } ?: INTERNAL
        }
    }

    class ProtocolException(val code: ErrorCode, message: String) : Exception(message)

    sealed class Message(val type: String) {
        /**
         * role: "remote" ou "server". [caps] (Mouse Flow): capacidades opcionais; vazio = não vai no JSON, igual ao hello de antes.
         */
        data class Hello(
            val version: Int,
            val deviceId: String,
            val deviceName: String,
            val role: String,
            val caps: List<String> = emptyList()
        ) : Message(Types.HELLO)

        data class PairRequest(val deviceId: String, val deviceName: String, val clientNonce: String) :
            Message(Types.PAIR_REQUEST)

        data class PairChallenge(val serverNonce: String, val serverName: String) : Message(Types.PAIR_CHALLENGE)

        data class PairOk(val token: String, val serverName: String) : Message(Types.PAIR_OK)

        data class Auth(val deviceId: String, val token: String) : Message(Types.AUTH)

        data class AuthOk(val serverName: String, val version: Int) : Message(Types.AUTH_OK)

        data class CommandMsg(val id: Long, val command: Command) : Message(Types.COMMAND)

        data class CommandResult(val id: Long, val ok: Boolean, val error: ErrorCode?) : Message(Types.COMMAND_RESULT)

        data class StateMsg(
            val access: Boolean,
            val hasSession: Boolean,
            val playing: Boolean,
            val title: String,
            val artist: String,
            val album: String,
            val appLabel: String,
            val canPlayPause: Boolean,
            val canNext: Boolean,
            val canPrev: Boolean,
            val durationMs: Long,
            val positionMs: Long,
            /** Id da capa já enviada em blocos ("art"); "" = sem capa (ou ainda sendo preparada). */
            val artId: String = ""
        ) : Message(Types.STATE)

        /**
         * Um bloco da capa (JPEG). [sha256] é o hash (hex minúsculo) da imagem INTEIRA, [artId] são os 16 primeiros
         * caracteres dele, [size] o tamanho da imagem inteira e [data] os bytes do bloco em base64 URL-safe sem padding.
         * Todos os blocos, menos o último, têm exatamente [ART_CHUNK_BYTES] bytes.
         */
        data class ArtChunk(
            val artId: String,
            val index: Int,
            val total: Int,
            val size: Int,
            val sha256: String,
            val data: String
        ) : Message(Types.ART)

        /** Mouse Flow, cliente -> servidor: liga/desliga o recebimento do fluxo de mouse (só se o servidor anunciou "mouse"). */
        data class MouseSub(val on: Boolean) : Message(Types.MOUSE_SUB)

        /** Mouse Flow, servidor -> cliente: a captura do mouse no WinLauncher ficou ativa/inativa. */
        data class MouseState(val active: Boolean) : Message(Types.MOUSE_STATE)

        /** Mouse Flow, servidor -> cliente: movimento/rolagem acumulados e estado atual dos botões (ver o bloco "Mouse Flow"). */
        data class MouseEvent(
            val seq: Long,
            val dx: Int,
            val dy: Int,
            val wx: Int,
            val wy: Int,
            val buttons: Int
        ) : Message(Types.MOUSE)

        data class ErrorMsg(val code: ErrorCode, val message: String, val id: Long?) : Message(Types.ERROR)

        object Ping : Message(Types.PING)

        object Pong : Message(Types.PONG)
    }

    // ------------------------------------------------------------------ ligação com o MediaSessionHub

    /** Resultado de um comando do Hub -> código de erro do protocolo (null = sucesso). */
    fun errorFor(r: MediaSessionHub.Result): ErrorCode? = when (r) {
        MediaSessionHub.Result.OK -> null
        MediaSessionHub.Result.NO_ACCESS -> ErrorCode.NO_ACCESS
        MediaSessionHub.Result.NO_SESSION -> ErrorCode.NO_SESSION
        MediaSessionHub.Result.UNAVAILABLE -> ErrorCode.UNAVAILABLE
        MediaSessionHub.Result.ERROR -> ErrorCode.INTERNAL
    }

    /** Estado do Hub -> mensagem "state" (sem a capa: ela terá um canal próprio em etapa futura). */
    fun stateOf(s: MediaSessionHub.State): Message.StateMsg = Message.StateMsg(
        access = s.access,
        hasSession = s.hasSession,
        playing = s.playing,
        title = clip(s.title, MAX_TEXT),
        artist = clip(s.artist, MAX_TEXT),
        album = clip(s.album, MAX_TEXT),
        appLabel = clip(s.appLabel, MAX_NAME),
        canPlayPause = s.canPlayPause,
        canNext = s.canNext,
        canPrev = s.canPrev,
        durationMs = s.durationMs.coerceAtLeast(0L),
        positionMs = s.positionMs.coerceAtLeast(0L)
    )

    fun clip(s: String, max: Int): String = if (s.length <= max) s else s.substring(0, max)

    // ------------------------------------------------------------------ base64 (URL-safe, sem padding)

    fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, B64_FLAGS)

    /** Decodifica e só aceita a forma canônica (a mesma que b64() produziria). */
    fun unb64(s: String): ByteArray? {
        return try {
            val b = Base64.decode(s, B64_FLAGS)
            if (b64(b) == s) b else null
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    // ------------------------------------------------------------------ codificação

    fun toJson(m: Message): JSONObject {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("t", m.type)
        when (m) {
            is Message.Hello -> {
                o.put("version", m.version)
                o.put("deviceId", m.deviceId)
                o.put("deviceName", m.deviceName)
                o.put("role", m.role)
                if (m.caps.isNotEmpty()) o.put("caps", JSONArray(m.caps))
            }
            is Message.PairRequest -> {
                o.put("deviceId", m.deviceId)
                o.put("deviceName", m.deviceName)
                o.put("clientNonce", m.clientNonce)
            }
            is Message.PairChallenge -> {
                o.put("serverNonce", m.serverNonce)
                o.put("serverName", m.serverName)
            }
            is Message.PairOk -> {
                o.put("token", m.token)
                o.put("serverName", m.serverName)
            }
            is Message.Auth -> {
                o.put("deviceId", m.deviceId)
                o.put("token", m.token)
            }
            is Message.AuthOk -> {
                o.put("serverName", m.serverName)
                o.put("version", m.version)
            }
            is Message.CommandMsg -> {
                o.put("id", m.id)
                o.put("cmd", m.command.wire)
            }
            is Message.CommandResult -> {
                o.put("id", m.id)
                o.put("ok", m.ok)
                if (m.error != null) o.put("error", m.error.wire)
            }
            is Message.StateMsg -> {
                o.put("access", m.access)
                o.put("hasSession", m.hasSession)
                o.put("playing", m.playing)
                o.put("title", m.title)
                o.put("artist", m.artist)
                o.put("album", m.album)
                o.put("appLabel", m.appLabel)
                o.put("canPlayPause", m.canPlayPause)
                o.put("canNext", m.canNext)
                o.put("canPrev", m.canPrev)
                o.put("durationMs", m.durationMs)
                o.put("positionMs", m.positionMs)
                o.put("artId", m.artId)
            }
            is Message.ArtChunk -> {
                o.put("id", m.artId)
                o.put("index", m.index)
                o.put("total", m.total)
                o.put("size", m.size)
                o.put("sha", m.sha256)
                o.put("data", m.data)
            }
            is Message.ErrorMsg -> {
                o.put("code", m.code.wire)
                o.put("message", m.message)
                if (m.id != null) o.put("id", m.id)
            }
            is Message.MouseSub -> {
                o.put("on", m.on)
            }
            is Message.MouseState -> {
                o.put("active", m.active)
            }
            is Message.MouseEvent -> {
                o.put("seq", m.seq.coerceIn(0L, MOUSE_MAX_SEQ))
                o.put("dx", clampMouseDelta(m.dx))
                o.put("dy", clampMouseDelta(m.dy))
                o.put("wx", clampMouseScroll(m.wx))
                o.put("wy", clampMouseScroll(m.wy))
                o.put("b", m.buttons and MOUSE_BTN_MASK)
            }
            Message.Ping -> {
            }
            Message.Pong -> {
            }
        }
        return o
    }

    /** Uma mensagem como texto JSON (uma linha, sem '\n'). */
    fun encode(m: Message): String = toJson(m).toString()

    /** Mensagem pronta para enviar: JSON + '\n'. Lança se passar do limite. */
    fun encodeFrame(m: Message): ByteArray {
        val bytes = (encode(m) + "\n").toByteArray(Charsets.UTF_8)
        if (bytes.size - 1 > MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
        return bytes
    }

    // ------------------------------------------------------------------ decodificação (com validação)

    private fun bad(msg: String) = ProtocolException(ErrorCode.BAD_REQUEST, msg)

    private fun JSONObject.reqStr(key: String, max: Int): String {
        val v = opt(key)
        if (v !is String || v.isEmpty() || v.length > max) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.optStr(key: String, max: Int): String {
        if (!has(key)) return ""
        val v = opt(key)
        if (v !is String || v.length > max) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqLong(key: String): Long {
        val v = opt(key)
        if (v !is Number) throw bad("campo '$key' inválido")
        return v.toLong()
    }

    private fun JSONObject.reqBool(key: String): Boolean {
        val v = opt(key)
        if (v !is Boolean) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqId(key: String): String {
        val v = reqStr(key, 64)
        if (!ID_REGEX.matches(v)) throw bad("campo '$key' fora do formato")
        return v
    }

    private fun JSONObject.reqNonce(key: String): String {
        val v = reqStr(key, 64)
        val b = unb64(v)
        if (b == null || b.size != NONCE_BYTES) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqToken(key: String): String {
        val v = reqStr(key, 96)
        val b = unb64(v)
        if (b == null || b.size != TOKEN_BYTES) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqIntIn(key: String, min: Int, max: Int): Int {
        val v = opt(key)
        if (v !is Number) throw bad("campo '$key' inválido")
        val l = v.toLong()
        if (l < min || l > max) throw bad("campo '$key' fora do limite")
        return l.toInt()
    }

    private fun JSONObject.optArtId(key: String): String {
        val v = optStr(key, ART_ID_LEN)
        if (v.isNotEmpty() && !ART_ID_REGEX.matches(v)) throw bad("campo '$key' fora do formato")
        return v
    }

    fun decode(line: String): Message {
        if (line.length > MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
        val o = try {
            JSONObject(line)
        } catch (e: Exception) {
            throw bad("JSON inválido")
        }
        val v = o.opt("v")
        if (v !is Number || v.toInt() != VERSION) {
            throw ProtocolException(ErrorCode.UNSUPPORTED_VERSION, "versão de protocolo não suportada")
        }
        return when (o.opt("t")) {
            Types.HELLO -> Message.Hello(
                version = o.reqLong("version").toInt(),
                deviceId = o.reqId("deviceId"),
                deviceName = o.reqStr("deviceName", MAX_NAME),
                role = o.reqStr("role", 16),
                caps = o.optCaps("caps")
            )
            Types.PAIR_REQUEST -> Message.PairRequest(
                deviceId = o.reqId("deviceId"),
                deviceName = o.reqStr("deviceName", MAX_NAME),
                clientNonce = o.reqNonce("clientNonce")
            )
            Types.PAIR_CHALLENGE -> Message.PairChallenge(
                serverNonce = o.reqNonce("serverNonce"),
                serverName = o.reqStr("serverName", MAX_NAME)
            )
            Types.PAIR_OK -> Message.PairOk(
                token = o.reqToken("token"),
                serverName = o.reqStr("serverName", MAX_NAME)
            )
            Types.AUTH -> Message.Auth(
                deviceId = o.reqId("deviceId"),
                token = o.reqToken("token")
            )
            Types.AUTH_OK -> Message.AuthOk(
                serverName = o.reqStr("serverName", MAX_NAME),
                version = o.reqLong("version").toInt()
            )
            Types.COMMAND -> Message.CommandMsg(
                id = o.reqLong("id"),
                command = Command.fromWire(o.optString("cmd", "")) ?: throw bad("comando desconhecido")
            )
            Types.COMMAND_RESULT -> Message.CommandResult(
                id = o.reqLong("id"),
                ok = o.reqBool("ok"),
                error = if (o.has("error")) ErrorCode.fromWire(o.optString("error", "")) else null
            )
            Types.STATE -> Message.StateMsg(
                access = o.reqBool("access"),
                hasSession = o.reqBool("hasSession"),
                playing = o.reqBool("playing"),
                title = o.optStr("title", MAX_TEXT),
                artist = o.optStr("artist", MAX_TEXT),
                album = o.optStr("album", MAX_TEXT),
                appLabel = o.optStr("appLabel", MAX_NAME),
                canPlayPause = o.reqBool("canPlayPause"),
                canNext = o.reqBool("canNext"),
                canPrev = o.reqBool("canPrev"),
                durationMs = o.reqLong("durationMs"),
                positionMs = o.reqLong("positionMs"),
                artId = o.optArtId("artId")
            )
            Types.ART -> {
                val id = o.reqStr("id", ART_ID_LEN)
                if (!ART_ID_REGEX.matches(id)) throw bad("campo 'id' fora do formato")
                val total = o.reqIntIn("total", 1, MAX_ART_CHUNKS)
                val index = o.reqIntIn("index", 0, total - 1)
                val size = o.reqIntIn("size", 1, MAX_ART_BYTES)
                val sha = o.reqStr("sha", 64)
                if (!SHA_REGEX.matches(sha) || !sha.startsWith(id)) throw bad("campo 'sha' inválido")
                val data = o.reqStr("data", ART_DATA_MAX)
                if ((size + ART_CHUNK_BYTES - 1) / ART_CHUNK_BYTES != total) throw bad("total de blocos inconsistente")
                val raw = unb64(data) ?: throw bad("campo 'data' inválido")
                val expected = if (index < total - 1) ART_CHUNK_BYTES else size - (total - 1) * ART_CHUNK_BYTES
                if (raw.size != expected) throw bad("tamanho do bloco inconsistente")
                Message.ArtChunk(id, index, total, size, sha, data)
            }
            Types.ERROR -> Message.ErrorMsg(
                code = ErrorCode.fromWire(o.optString("code", "")),
                message = o.optStr("message", MAX_TEXT),
                id = if (o.has("id")) o.reqLong("id") else null
            )
            Types.MOUSE_SUB -> Message.MouseSub(on = o.reqBool("on"))
            Types.MOUSE_STATE -> Message.MouseState(active = o.reqBool("active"))
            Types.MOUSE -> Message.MouseEvent(
                seq = o.reqWhole("seq", 0L, MOUSE_MAX_SEQ),
                dx = o.reqWhole("dx", -MOUSE_MAX_DELTA.toLong(), MOUSE_MAX_DELTA.toLong()).toInt(),
                dy = o.reqWhole("dy", -MOUSE_MAX_DELTA.toLong(), MOUSE_MAX_DELTA.toLong()).toInt(),
                wx = o.reqWhole("wx", -MOUSE_MAX_SCROLL.toLong(), MOUSE_MAX_SCROLL.toLong()).toInt(),
                wy = o.reqWhole("wy", -MOUSE_MAX_SCROLL.toLong(), MOUSE_MAX_SCROLL.toLong()).toInt(),
                buttons = o.reqWhole("b", 0L, MOUSE_BTN_MASK.toLong()).toInt()
            )
            Types.PING -> Message.Ping
            Types.PONG -> Message.Pong
            else -> throw bad("tipo de mensagem desconhecido")
        }
    }

    // ------------------------------------------------------------------ capa em blocos

    fun sha256Hex(b: ByteArray): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(b)
        val sb = StringBuilder(d.size * 2)
        for (x in d) {
            sb.append(Character.forDigit((x.toInt() shr 4) and 0xf, 16))
            sb.append(Character.forDigit(x.toInt() and 0xf, 16))
        }
        return sb.toString()
    }

    /** Id da capa = primeiros 16 caracteres do SHA-256 (hex) da imagem. */
    fun artIdOf(sha256Hex: String): String = sha256Hex.substring(0, ART_ID_LEN)

    /** Divide a imagem em blocos prontos para enviar. Lança TOO_LARGE se vazia ou maior que [MAX_ART_BYTES]. */
    fun artChunks(bytes: ByteArray): List<Message.ArtChunk> {
        if (bytes.isEmpty() || bytes.size > MAX_ART_BYTES) {
            throw ProtocolException(ErrorCode.TOO_LARGE, "capa fora do limite")
        }
        val sha = sha256Hex(bytes)
        val id = artIdOf(sha)
        val total = (bytes.size + ART_CHUNK_BYTES - 1) / ART_CHUNK_BYTES
        val out = ArrayList<Message.ArtChunk>(total)
        for (i in 0 until total) {
            val from = i * ART_CHUNK_BYTES
            val to = minOf(bytes.size, from + ART_CHUNK_BYTES)
            out.add(Message.ArtChunk(id, i, total, bytes.size, sha, b64(bytes.copyOfRange(from, to))))
        }
        return out
    }

    /** Remonta a capa a partir dos blocos (em ordem) e confere tamanho e SHA-256. Uma instância por conexão. */
    class ArtAssembler {
        private var id = ""
        private var total = 0
        private var size = 0
        private var sha = ""
        private var next = 0
        private val buf = ByteArrayOutputStream()

        private fun reset() {
            id = ""
            total = 0
            size = 0
            sha = ""
            next = 0
            buf.reset()
        }

        /** Devolve a imagem quando o último bloco chega e confere; null enquanto faltam blocos. Lança ProtocolException se algo não bate. */
        fun add(m: Message.ArtChunk): ByteArray? {
            if (m.index == 0) {
                reset()
                id = m.artId
                total = m.total
                size = m.size
                sha = m.sha256
            } else if (m.artId != id || m.total != total || m.size != size || m.sha256 != sha || m.index != next) {
                reset()
                throw ProtocolException(ErrorCode.BAD_REQUEST, "bloco de capa fora de ordem")
            }
            val raw = unb64(m.data)
            if (raw == null) {
                reset()
                throw ProtocolException(ErrorCode.BAD_REQUEST, "bloco de capa inválido")
            }
            buf.write(raw)
            next = m.index + 1
            if (next < total) return null
            val all = buf.toByteArray()
            val wantSize = size
            val wantSha = sha
            reset()
            if (all.size != wantSize || sha256Hex(all) != wantSha) {
                throw ProtocolException(ErrorCode.BAD_REQUEST, "capa corrompida (tamanho ou hash não conferem)")
            }
            return all
        }
    }

    // ================================================================== Mouse Flow (Etapa 1: SÓ o protocolo)
    //
    // Acréscimo ADITIVO e compatível com o protocolo v1 (VERSION continua 1). Nada aqui muda hello/auth/command/state/art.
    //  - hello ganha o campo OPCIONAL "caps" (lista de capacidades). Quem não conhece o campo o ignora, e sem capacidades
    //    o campo nem é enviado (o hello fica igual ao de antes).
    //  - Capacidade "mouse": quem a anuncia entende os tipos abaixo. O servidor só pode mandar "mouse"/"mouse_state" a um
    //    cliente que pediu com "mouse_sub", e o cliente só pode mandar "mouse_sub" a um servidor que anunciou "mouse".
    //    Motivo: um programa antigo recusa tipos desconhecidos e encerra a conexão.
    //  - mouse_sub   (cliente -> servidor): {"on":true|false}
    //  - mouse_state (servidor -> cliente): {"active":true|false}  (captura do mouse ligada/desligada no WinLauncher)
    //  - mouse       (servidor -> cliente): {"seq","dx","dy","wx","wy","b"}
    //      dx, dy: deslocamento acumulado desde o quadro anterior, em pixels do aparelho do WinLauncher (+x direita, +y baixo)
    //      wx, wy: rolagem acumulada em centésimos de "clique" da roda, convenção do Android
    //              (wy > 0 = rolar para cima, wx > 0 = rolar para a direita)
    //      b: estado ATUAL dos botões (bits MOUSE_BTN_*), não o evento
    //      seq: contador crescente por conexão
    // Quem envia deve limitar os valores (clampMouseDelta/clampMouseScroll); toJson também limita, para nunca gerar um
    // quadro que o outro lado recusaria (uma recusa derruba a conexão).

    const val CAP_MOUSE = "mouse"
    const val MAX_CAPS = 8
    const val MAX_CAP_LEN = 16
    const val MOUSE_BTN_LEFT = 1
    const val MOUSE_BTN_RIGHT = 2
    const val MOUSE_BTN_MASK = 3
    const val MOUSE_MAX_DELTA = 32767
    const val MOUSE_MAX_SCROLL = 32767
    const val MOUSE_MAX_SEQ = 9007199254740991L

    private val CAP_REGEX = Regex("^[a-z0-9_]{1,16}$")

    fun clampMouseDelta(v: Int): Int = v.coerceIn(-MOUSE_MAX_DELTA, MOUSE_MAX_DELTA)

    fun clampMouseScroll(v: Int): Int = v.coerceIn(-MOUSE_MAX_SCROLL, MOUSE_MAX_SCROLL)

    /** Lista opcional de capacidades: ausente = vazia; presente tem de ser lista de até [MAX_CAPS] textos no formato certo. */
    private fun JSONObject.optCaps(key: String): List<String> {
        if (!has(key)) return emptyList()
        val a = opt(key)
        if (a !is JSONArray || a.length() > MAX_CAPS) throw bad("campo '$key' inválido")
        val out = ArrayList<String>(a.length())
        for (i in 0 until a.length()) {
            val s = a.opt(i)
            if (s !is String || !CAP_REGEX.matches(s)) throw bad("campo '$key' inválido")
            if (!out.contains(s)) out.add(s)
        }
        return out
    }

    /** Número INTEIRO (rejeita 1.5, 1e2, texto e booleano) dentro de [min, max]. */
    private fun JSONObject.reqWhole(key: String, min: Long, max: Long): Long {
        val v = opt(key)
        if (v !is Int && v !is Long) throw bad("campo '$key' inválido")
        val l = (v as Number).toLong()
        if (l < min || l > max) throw bad("campo '$key' fora do limite")
        return l
    }

    /** Autoteste do Mouse Flow (Etapa 1): ida e volta, rejeições, limites e compatibilidade com quadros no formato antigo. null = tudo certo. */
    fun selfTestMouse(): String? {
        return try {
            fun fail(msg: String): Nothing = throw IllegalStateException(msg)
            fun rejects(code: ErrorCode, what: String, text: String) {
                try {
                    decode(text)
                } catch (e: ProtocolException) {
                    if (e.code == code) return
                    fail("$what: erro ${e.code.wire} em vez de ${code.wire}")
                }
                fail("$what: deveria ser rejeitado")
            }

            val id = "AbCdEfGh12345678"
            val withoutCaps = Message.Hello(VERSION, id, "Sem capacidades", "remote")
            val samples = listOf<Message>(
                Message.Hello(VERSION, id, "Celular da Ana", "remote", listOf(CAP_MOUSE)),
                Message.Hello(VERSION, id, "WinLauncher", "server", listOf(CAP_MOUSE, "future_cap_2")),
                withoutCaps,
                Message.MouseSub(true),
                Message.MouseSub(false),
                Message.MouseState(true),
                Message.MouseState(false),
                Message.MouseEvent(0L, 0, 0, 0, 0, 0),
                Message.MouseEvent(1L, 12, -7, 0, 0, MOUSE_BTN_LEFT),
                Message.MouseEvent(
                    2L, -MOUSE_MAX_DELTA, MOUSE_MAX_DELTA, -MOUSE_MAX_SCROLL, MOUSE_MAX_SCROLL,
                    MOUSE_BTN_LEFT or MOUSE_BTN_RIGHT
                ),
                Message.MouseEvent(MOUSE_MAX_SEQ, 1, 1, 100, -100, MOUSE_BTN_RIGHT)
            )
            for (m in samples) {
                val text = encode(m)
                if (text.contains('\n')) fail("${m.type}: quebra de linha no JSON")
                if (decode(text) != m) fail("${m.type}: ida e volta diferente")
                val frame = encodeFrame(m)
                if (frame.last() != '\n'.code.toByte()) fail("${m.type}: quadro sem '\\n'")
                if (m is Message.MouseEvent && frame.size > 128) fail("mouse: quadro de ${frame.size} bytes (esperado até 128)")
            }
            if (encode(withoutCaps).contains("\"caps\"")) fail("hello sem capacidades não deve ter o campo caps")

            // quadros no formato ANTIGO (sem caps) continuam valendo; o que é de música não mudou
            val oldHello = decode("{\"v\":1,\"t\":\"hello\",\"version\":1,\"deviceId\":\"$id\",\"deviceName\":\"Celular\",\"role\":\"remote\"}")
            if (oldHello != Message.Hello(VERSION, id, "Celular", "remote", emptyList())) fail("hello antigo decodificado diferente")
            if (decode("{\"v\":1,\"t\":\"command\",\"id\":5,\"cmd\":\"play_pause\"}") != Message.CommandMsg(5L, Command.PLAY_PAUSE)) {
                fail("comando de música antigo mudou")
            }
            if (decode("{\"v\":1,\"t\":\"ping\"}") != Message.Ping) fail("ping antigo mudou")
            if (Command.values().map { it.wire } != listOf("play_pause", "next", "previous")) fail("a lista de comandos de música mudou")
            if (VERSION != 1) fail("a versão do protocolo mudou")

            // capacidade desconhecida é aceita (compatibilidade futura); repetida vira uma só
            val fut = decode("{\"v\":1,\"t\":\"hello\",\"version\":1,\"deviceId\":\"$id\",\"deviceName\":\"x\",\"role\":\"server\",\"caps\":[\"mouse\",\"coisa_futura\",\"mouse\"]}")
            if (fut !is Message.Hello || fut.caps != listOf("mouse", "coisa_futura")) fail("caps com desconhecida/repetida")

            // caps inválido
            fun helloWith(caps: String) =
                "{\"v\":1,\"t\":\"hello\",\"version\":1,\"deviceId\":\"$id\",\"deviceName\":\"x\",\"role\":\"remote\",\"caps\":$caps}"
            rejects(ErrorCode.BAD_REQUEST, "caps não é lista", helloWith("\"mouse\""))
            rejects(ErrorCode.BAD_REQUEST, "caps com número", helloWith("[1]"))
            rejects(ErrorCode.BAD_REQUEST, "caps com null", helloWith("[null]"))
            rejects(ErrorCode.BAD_REQUEST, "caps com maiúscula", helloWith("[\"Mouse\"]"))
            rejects(ErrorCode.BAD_REQUEST, "caps vazia", helloWith("[\"\"]"))
            rejects(ErrorCode.BAD_REQUEST, "caps longa demais", helloWith("[\"" + "a".repeat(MAX_CAP_LEN + 1) + "\"]"))
            rejects(ErrorCode.BAD_REQUEST, "caps demais", helloWith("[\"a\",\"b\",\"c\",\"d\",\"e\",\"f\",\"g\",\"h\",\"i\"]"))

            // mouse: valores
            fun mouseJson(seq: String, dx: String, dy: String, wx: String, wy: String, b: String) =
                "{\"v\":1,\"t\":\"mouse\",\"seq\":$seq,\"dx\":$dx,\"dy\":$dy,\"wx\":$wx,\"wy\":$wy,\"b\":$b}"
            if (decode(mouseJson("1", "1", "1", "0", "0", "1")) != Message.MouseEvent(1L, 1, 1, 0, 0, 1)) fail("mouse literal diferente")
            rejects(ErrorCode.BAD_REQUEST, "seq negativo", mouseJson("-1", "1", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "seq acima do limite", mouseJson("9007199254740992", "1", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx acima do limite", mouseJson("1", "32768", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx abaixo do limite", mouseJson("1", "-32768", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx fracionário", mouseJson("1", "1.5", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dy em notação científica", mouseJson("1", "1", "1e2", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx como texto", mouseJson("1", "\"1\"", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "wy acima do limite", mouseJson("1", "1", "1", "0", "40000", "1"))
            rejects(ErrorCode.BAD_REQUEST, "botões com bit desconhecido", mouseJson("1", "1", "1", "0", "0", "4"))
            rejects(ErrorCode.BAD_REQUEST, "botões negativos", mouseJson("1", "1", "1", "0", "0", "-1"))
            rejects(ErrorCode.BAD_REQUEST, "botões booleano", mouseJson("1", "1", "1", "0", "0", "true"))
            rejects(ErrorCode.BAD_REQUEST, "mouse sem campo wy", "{\"v\":1,\"t\":\"mouse\",\"seq\":1,\"dx\":1,\"dy\":1,\"wx\":0,\"b\":1}")
            rejects(ErrorCode.UNSUPPORTED_VERSION, "mouse com versão 2", mouseJson("1", "1", "1", "0", "0", "1").replace("\"v\":1", "\"v\":2"))
            rejects(ErrorCode.BAD_REQUEST, "mouse_sub sem on", "{\"v\":1,\"t\":\"mouse_sub\"}")
            rejects(ErrorCode.BAD_REQUEST, "mouse_sub com on texto", "{\"v\":1,\"t\":\"mouse_sub\",\"on\":\"yes\"}")
            rejects(ErrorCode.BAD_REQUEST, "mouse_sub com on número", "{\"v\":1,\"t\":\"mouse_sub\",\"on\":1}")
            rejects(ErrorCode.BAD_REQUEST, "mouse_state sem active", "{\"v\":1,\"t\":\"mouse_state\"}")
            rejects(ErrorCode.BAD_REQUEST, "tipo mouse desconhecido", "{\"v\":1,\"t\":\"mouse_xyz\"}")

            // toJson limita: nunca gera um quadro que o outro lado recusaria
            val over = decode(encode(Message.MouseEvent(5L, 100000, -100000, 100000, -100000, 7)))
            if (over !is Message.MouseEvent || over.dx != MOUSE_MAX_DELTA || over.dy != -MOUSE_MAX_DELTA ||
                over.wx != MOUSE_MAX_SCROLL || over.wy != -MOUSE_MAX_SCROLL || over.buttons != MOUSE_BTN_MASK
            ) {
                fail("valores fora do limite não foram limitados na codificação")
            }
            val neg = decode(encode(Message.MouseEvent(-9L, 0, 0, 0, 0, 0)))
            if (neg !is Message.MouseEvent || neg.seq != 0L) fail("seq negativo não foi limitado na codificação")

            // fluxo de quadros, na ordem, lidos por readFrame
            val sb = StringBuilder()
            for (i in 0 until 1000) {
                sb.append(encode(Message.MouseEvent(i.toLong(), i % 50 - 25, 3, 0, if (i % 100 == 0) -100 else 0, i % 4))).append('\n')
            }
            val ins = java.io.ByteArrayInputStream(sb.toString().toByteArray(Charsets.UTF_8))
            for (i in 0 until 1000) {
                val line = readFrame(ins) ?: fail("fluxo de mouse acabou no quadro $i")
                val e = decode(line)
                if (e !is Message.MouseEvent || e.seq != i.toLong()) fail("fluxo de mouse fora de ordem no quadro $i")
            }
            if (readFrame(ins) != null) fail("fim do fluxo de mouse deveria devolver null")
            null
        } catch (e: Throwable) {
            (e.message ?: e.javaClass.simpleName)
        }
    }

    // ------------------------------------------------------------------ leitura de uma linha

    /**
     * Lê uma mensagem (até '\n') do fluxo, no máximo MAX_FRAME_BYTES. Devolve null se o fluxo terminou
     * limpo (nenhum byte pendente). Use um BufferedInputStream por cima do socket (a leitura é byte a byte).
     */
    fun readFrame(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        while (true) {
            val b = input.read()
            if (b < 0) {
                if (buf.size() == 0) return null
                throw bad("conexão encerrada no meio de uma mensagem")
            }
            if (b == '\n'.code) return buf.toString("UTF-8")
            if (buf.size() >= MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
            buf.write(b)
        }
    }

    // ------------------------------------------------------------------ autoteste

    private fun expectFail(code: ErrorCode, what: String, block: () -> Unit) {
        try {
            block()
        } catch (e: ProtocolException) {
            if (e.code == code) return
            throw IllegalStateException("$what: erro ${e.code.wire} em vez de ${code.wire}")
        }
        throw IllegalStateException("$what: deveria ser rejeitado")
    }

    /** Testa codificação, decodificação, validações e leitura de linhas. null = tudo certo; senão, o motivo. */
    fun selfTest(): String? {
        return try {
            val id = "AbCdEfGh12345678"
            val nonceA = b64(ByteArray(NONCE_BYTES) { 0x22 })
            val nonceB = b64(ByteArray(NONCE_BYTES) { 0x33 })
            val token = b64(ByteArray(TOKEN_BYTES) { 0x44 })
            val samples = listOf<Message>(
                Message.Hello(VERSION, id, "Celular da Ana", "remote"),
                Message.PairRequest(id, "Celular da Ana", nonceA),
                Message.PairChallenge(nonceB, "WinLauncher"),
                Message.PairOk(token, "WinLauncher"),
                Message.Auth(id, token),
                Message.AuthOk("WinLauncher", VERSION),
                Message.CommandMsg(7L, Command.NEXT),
                Message.CommandResult(7L, true, null),
                Message.CommandResult(8L, false, ErrorCode.UNAVAILABLE),
                Message.StateMsg(
                    true, true, true, "Título \"com aspas\" e acentuação ãéç", "Artista\nem duas linhas", "Álbum",
                    "YouTube Music", true, true, false, 215000L, 12345L, "0123456789abcdef"
                ),
                Message.StateMsg(false, false, false, "", "", "", "", false, false, false, 0L, 0L),
                Message.ErrorMsg(ErrorCode.NOT_PAIRED, "não pareado", 9L),
                Message.ErrorMsg(ErrorCode.INTERNAL, "erro", null),
                Message.Ping,
                Message.Pong
            )
            for (m in samples) {
                val text = encode(m)
                if (text.contains('\n')) throw IllegalStateException("${m.type}: quebra de linha no JSON")
                val back = decode(text)
                if (back != m) throw IllegalStateException("${m.type}: ida e volta diferente")
                val frame = encodeFrame(m)
                if (frame.last() != '\n'.code.toByte()) throw IllegalStateException("${m.type}: quadro sem '\\n'")
            }

            // rejeições
            expectFail(ErrorCode.BAD_REQUEST, "JSON quebrado") { decode("{nao e json") }
            expectFail(ErrorCode.UNSUPPORTED_VERSION, "versão errada") { decode("{\"v\":99,\"t\":\"ping\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "tipo desconhecido") { decode("{\"v\":1,\"t\":\"xyz\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "comando desconhecido") { decode("{\"v\":1,\"t\":\"command\",\"id\":1,\"cmd\":\"format\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "nonce curto") {
                decode("{\"v\":1,\"t\":\"pair_request\",\"deviceId\":\"$id\",\"deviceName\":\"x\",\"clientNonce\":\"AAAA\"}")
            }
            expectFail(ErrorCode.BAD_REQUEST, "id fora do formato") {
                decode("{\"v\":1,\"t\":\"auth\",\"deviceId\":\"a b\",\"token\":\"$token\"}")
            }
            expectFail(ErrorCode.TOO_LARGE, "mensagem enorme") { decode("x".repeat(MAX_FRAME_BYTES + 1)) }
            expectFail(ErrorCode.BAD_REQUEST, "artId fora do formato") {
                decode("{\"v\":1,\"t\":\"state\",\"access\":true,\"hasSession\":true,\"playing\":true,\"canPlayPause\":true," +
                    "\"canNext\":true,\"canPrev\":true,\"durationMs\":1,\"positionMs\":1,\"artId\":\"ZZ\"}")
            }

            // capa em blocos
            for (n in listOf(1, 100, ART_CHUNK_BYTES, ART_CHUNK_BYTES + 1, 3 * ART_CHUNK_BYTES, 50000, MAX_ART_BYTES)) {
                val img = ByteArray(n) { i -> ((i * 31 + n) and 0xff).toByte() }
                val chunks = artChunks(img)
                if (chunks.size != (n + ART_CHUNK_BYTES - 1) / ART_CHUNK_BYTES) throw IllegalStateException("capa $n: número de blocos errado")
                val asm = ArtAssembler()
                var got: ByteArray? = null
                for (ch in chunks) {
                    val text = encode(ch)
                    if (text.length > MAX_FRAME_BYTES) throw IllegalStateException("capa $n: bloco maior que o limite da mensagem")
                    if (decode(text) != ch) throw IllegalStateException("capa $n: ida e volta do bloco diferente")
                    got = asm.add(decode(text) as Message.ArtChunk)
                }
                if (got == null || !got.contentEquals(img)) throw IllegalStateException("capa $n: remontagem diferente da original")
            }
            val big = ByteArray(MAX_ART_BYTES + 1)
            expectFail(ErrorCode.TOO_LARGE, "capa grande demais") { artChunks(big) }
            val artTwo = artChunks(ByteArray(ART_CHUNK_BYTES + 10) { 5 })
            val asmBad = ArtAssembler()
            asmBad.add(artTwo[0])
            val tampered = artTwo[1].copy(data = b64(ByteArray(10) { 6 }))
            expectFail(ErrorCode.BAD_REQUEST, "capa adulterada") { asmBad.add(tampered) }
            val asmOrder = ArtAssembler()
            expectFail(ErrorCode.BAD_REQUEST, "bloco fora de ordem") { asmOrder.add(artTwo[1]) }
            expectFail(ErrorCode.BAD_REQUEST, "índice fora do total") {
                decode(encode(artTwo[0]).replace("\"index\":0", "\"index\":2"))
            }
            expectFail(ErrorCode.BAD_REQUEST, "tamanho do bloco inconsistente") {
                decode(encode(artTwo[0]).replace("\"size\":${ART_CHUNK_BYTES + 10}", "\"size\":${ART_CHUNK_BYTES * 2 + 10}"))
            }

            // leitura de linhas
            val two = (encode(Message.Ping) + "\n" + encode(Message.Pong) + "\n").toByteArray(Charsets.UTF_8)
            val ins = ByteArrayInputStream(two)
            if (decode(readFrame(ins) ?: throw IllegalStateException("leitura 1 vazia")) != Message.Ping) {
                throw IllegalStateException("leitura 1 errada")
            }
            if (decode(readFrame(ins) ?: throw IllegalStateException("leitura 2 vazia")) != Message.Pong) {
                throw IllegalStateException("leitura 2 errada")
            }
            if (readFrame(ins) != null) throw IllegalStateException("fim do fluxo deveria devolver null")
            expectFail(ErrorCode.TOO_LARGE, "linha enorme") {
                readFrame(ByteArrayInputStream(ByteArray(MAX_FRAME_BYTES + 10) { 'a'.code.toByte() }))
            }
            expectFail(ErrorCode.BAD_REQUEST, "linha cortada") {
                readFrame(ByteArrayInputStream("{\"v\":1".toByteArray(Charsets.UTF_8)))
            }
            null
        } catch (e: Throwable) {
            (e.message ?: e.javaClass.simpleName)
        }
    }
}
