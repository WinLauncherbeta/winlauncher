# HANDOFF 16 — Mapeador de gamepad, ETAPA 5 (ESCRITA NO CÓDIGO): toque pelo Shizuku, sem o atraso do dispatchGesture (WinLauncher 2.11.0 / code 24)

NÃO compilado com Gradle e NÃO testado em aparelho. Só o injetor Java foi compilado e executado aqui, contra STUBS do Android escritos à mão
(`_verificacao_etapa5/run.sh`: 9 verificações OK: um dedo, dois dedos com POINTER_DOWN/UP, MOVE pendente, EOF solta os dedos, Q, entradas inválidas,
recusa do sistema, 10 dedos). Isso confere a lógica de dedos/ações, NÃO o InputManager real. Os arquivos Kotlin só passaram por checagem léxica
(Pygments), sem kotlinc. A latência real NÃO foi medida: a melhora esperada vem de tirar a espera de ~32 ms por pedaço do dispatchGesture, mas só o aparelho confirma.

## Como funciona
- `PadInjector.java` (Java, sem Kotlin nem classes do app): processo iniciado com a permissão do Shizuku (usuário shell) por
  `/system/bin/app_process -Djava.class.path=<base.apk> /system/bin --nice-name=winlauncher_pad com.example.winlauncher.PadInjector`.
  Lê comandos de texto na entrada padrão (`D slot x y`, `M slot x y`, `F`, `U slot`, `X`, `Q`) e injeta MotionEvents (SOURCE_TOUCHSCREEN, até 10 dedos)
  por `InputManagerGlobal` (Android 14+) ou `InputManager` (antes), `injectInputEvent(event, 0)` por reflexão; tenta também a versão com 3 argumentos.
  Responde `READY sdk`, `ERR motivo` (e sai) ou `LOG ...`. Fim da entrada (o app morreu) = solta todos os dedos e sai. 20 falhas seguidas = `ERR` e sai.
- `PadShizukuInput.kt` (app): inicia o injetor com `ShizukuBridge.spawn`, thread de escrita (a thread principal nunca trava no pipe), leitura do READY/ERR,
  stderr guardado em `status`, timeout de 8 s, nova tentativa a cada 10 s, geração (`gen`) para threads de processos antigos não mexerem no estado.
- `PadMapperService.kt`: cada toque novo escolhe UM motor (`padMode`) e o mantém até o planejador esvaziar. Injetor pronto + opção ligada = injeção direta
  (`tickDirect`, ciclo de 8 ms, tempo REAL entre ciclos em `planner.chunkMs` para a câmera andar na velocidade certa); senão, acessibilidade como antes (32 ms).
  Se o injetor cai no meio, `directLost` solta tudo e o próximo toque volta à acessibilidade (e o injetor tenta subir de novo).
- `TouchPlanner.chunkMs` virou `var` (só muda com o planejador vazio). O planejador, os modos (toque, segurar, turbo, joystick, câmera, gradual, macro) e os perfis NÃO mudaram.
- Painel: opção "Tocar pelo Shizuku (menos atraso)" (ligada por padrão), linha "Toque: Shizuku (injeção direta)" ou "Toque: acessibilidade [Shizuku: motivo]",
  botão "Testar injeção via Shizuku" (toca no centro da área de teste: se só esse contador subir, o Shizuku está tocando).
- `PadPrefs.direct`, `PadEngine.notifyChanged()`. Versão 2.11.0 / 24. Backups em `_backup_etapa5/`.

## Para conferir no build
1. Pasta `src/main/java` com um `.java` junto dos `.kt`: o plugin Kotlin do AGP compila os dois.
2. `val`/`var` com `synchronized` e `use { ... return ... }` em PadShizukuInput; `var slot = slotOf[sg.id]` com smart cast em PadMapperService.tickDirect.

## Para testar no aparelho (nesta ordem)
1. Shizuku ligado e autorizado ao WinLauncher. Abrir o painel: a linha "Toque:" deve ir de "iniciando..." para "Shizuku (injeção direta)" em ~1 s.
2. "Testar injeção via Shizuku": o contador da área de teste sobe. Se não subir, a linha mostra o motivo (stderr do app_process ou ERR do injetor).
3. Jogo real: botão de toque, segurar, turbo, joystick, câmera, macro. Comparar a sensação com o motor antigo (desligar a opção no painel).
4. Matar o Shizuku (ou o injetor) com um botão apertado: os dedos devem soltar e o próximo toque volta à acessibilidade.
5. Girar a tela, trocar de app e abrir o editor sobre o jogo continuam funcionando.

## Riscos conhecidos (onde provavelmente aparece o primeiro erro)
- API oculta: o caminho (InputManagerGlobal/InputManager + injectInputEvent) é o do scrcpy, mas muda entre versões do Android e de fabricantes. Se falhar, o painel mostra "ERR ..." e o app fica na acessibilidade.
- SELinux/caminho do APK: o shell precisa ler `applicationInfo.sourceDir`. Normal em apps que usam app_process pelo Shizuku, mas não foi visto no seu aparelho.
- Se o injetor for MORTO à força (kill -9) com um dedo na tela, ele não consegue soltar o dedo: o jogo pode ficar com um toque preso até o próximo toque real.
- O botão flutuante PAD continua sendo uma janela por cima: o toque injetado que cair sobre ele é recebido por ele (a guarda `planner.hasWork()` evita o desligamento acidental).
- Android 13 ou menor: o Shizuku também lê os analógicos (`getevent`); os dois usos são independentes.
