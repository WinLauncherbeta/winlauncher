# HANDOFF 11 — Alinhamento da barra de tarefas e bolha de música

Versão base: projeto completo com o parcial de alinhamento (No meio / À esquerda) já aplicado.

## O que mudou
- Barra de tarefas: alinhamento dos ícones = **No meio (0)** ou **À esquerda (1)** (`Prefs.tbAlign`).
  Menu: botão direito (ou toque longo) na barra > "Alinhamento dos ícones"; também em
  Personalizar > Barra de tarefas. Vale para a barra flutuante (TaskbarOverlayService).
- Janela de apps (Menu Iniciar): com ícones à esquerda, abre à esquerda também
  (`placePanels`: se `tbAlign == 1` e `stPos == 0`, usa a posição "Esquerda").
  "Centro da tela" e "Esquerda" escolhidos pelo usuário em Iniciar continuam valendo como estão.
- Bolha de música da barra (`TaskbarMusic`): nova opção `Prefs.tbMusicRight` (padrão: ligada).
  Com ícones à esquerda e a opção ligada, a bolha fica na direita, logo antes da seta "^" da bandeja,
  e o painel de música sobe pela direita. Opção em: botão direito/toque longo na bolha e em
  Personalizar > Barra de tarefas ("Bolha de música na direita (com ícones à esquerda)").
  Com ícones no meio, a bolha continua no canto esquerdo como antes.

## Arquivos modificados
MainActivity.kt, TaskbarMusic.kt, CustomizeUi.kt, Prefs.kt (+ TaskbarOverlayService.kt e os
ícones ic_tb_align*.xml já vindos do parcial anterior).

## Testes
Não compilado nem testado em aparelho (sem Android SDK no ambiente de edição).
Só houve conferência de chaves/parênteses e de símbolos existentes. Validar pelo APK do GitHub Actions.
