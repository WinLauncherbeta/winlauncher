# HANDOFF 7 — WinLauncher Remote, etapa 2 (MediaSessionHub + diagnóstico)

Contexto: preparar a WinLauncher para ser controlada por um app separado (WinLauncher Remote) pela rede Wi-Fi local.
Decisões do dono: Remote = projeto Android separado (APK independente); pareamento comparando um número nos dois
celulares + botão "Permitir" na WinLauncher; compilação pelo GitHub Actions; Android 8+ (minSdk 26).
v1: controlar SOMENTE o YouTube Music (com.google.android.apps.youtube.music): play/pause, próxima, anterior;
mais título, artista, capa e estado de reprodução. Sem player próprio, sem outros serviços de música.

## FEITO (NÃO COMPILADO: sem Android SDK no ambiente; compilar pelo GitHub Actions)
- MediaSessionHub.kt (novo): objeto único; enxerga só o pacote do YouTube Music (sem fallback para outros apps);
  usa o acesso às notificações e o LauncherNotificationListener já existentes; State (tocando, título, artista, álbum,
  capa por bitmap ou URI, ações anunciadas, posição/duração, ações extras); comandos togglePlayPause/next/previous(force)
  com resultado (OK, NO_ACCESS, NO_SESSION, UNAVAILABLE, ERROR); start()/stop() com contagem de usos; tudo na thread principal.
- CustomizeUi.kt: painel "ytdiag" (ytDiagPanel) — página de diagnóstico TEMPORÁRIA.
- SettingsWindow.kt: linha "Diagnóstico do YouTube Music" em Rede e Internet, que abre o painel.
- Nada mais foi alterado. TaskbarMusic/QuickMusicCard/MusicWidget/MusicSession/MusicPlayerWindow continuam como estavam.

## FALTA (testar no celular, Configurações > Rede e Internet > Diagnóstico do YouTube Music)
1. YouTube Music encontrado (✔ na linha correspondente).
2. Play/Pause funciona.
3. Próxima funciona.
4. Anterior funciona.
5. Título, artista e capa corretos.
Se algum botão disser "ação não anunciada", ligar "Forçar" e anotar se funciona mesmo assim.
NÃO remover a página de diagnóstico antes da confirmação do dono.

## Próximas etapas
3) protocolo mínimo + servidor de teste ligado ao Hub; 4) TLS/Keystore + pareamento com número e "Permitir";
5) NSD + serviço em primeiro plano + painel em Configurações; 6) app WinLauncher Remote; 7) testes Android 8+.
