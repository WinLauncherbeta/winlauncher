package com.example.winlauncher

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Mapeador de gamepad (Etapa 2) - editor SOBRE o jogo.
 *
 * Abre duas janelas de acessibilidade (TYPE_ACCESSIBILITY_OVERLAY, não pedem permissão extra) por cima do app que
 * estiver na frente:
 *  - a TELA: ocupa tudo, escurece um pouco o jogo e mostra um ponto por botão. Tocar num ponto o seleciona,
 *    arrastar o move, tocar em área vazia põe/move o ponto do botão selecionado;
 *  - a BARRA: janelinha com os botões do controle, modo (toque rápido / segurar), ajuste fino, teste e salvar.
 *
 * Modo TESTAR: a tela deixa de receber toques (o jogo recebe tudo) e o mapeamento volta a valer de verdade:
 * apertar um botão do controle injeta o toque no jogo e acende o ponto correspondente.
 *
 * As mudanças são feitas direto no [PadProfile] (assim o teste usa o que você acabou de arrastar) e só ficam no
 * disco em "Salvar e sair". "Descartar" devolve o perfil ao estado em que estava quando o editor abriu.
 * Só thread principal.
 */
class PadOverlayEditor(
    private val svc: PadMapperService,
    private val prof: PadProfile,
    private val onClosed: () -> Unit
) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    // estado de abertura (para "Descartar")
    private val snapshot: List<PadBinding> = prof.bindings.map { it.copy() }
    private val snapshotLandscape = prof.landscape

    private var selected: PadButton = PadButton.A
    private var testing = false
    private var collapsed = false
    private var barAtTop = true
    private var closed = false
    private var discardArmedAt = 0L

    private var canvas: EditorCanvas? = null
    private var bar: LinearLayout? = null
    private var body: LinearLayout? = null
    private var scroll: HorizontalScrollView? = null

    private var title: TextView? = null
    private var hint: TextView? = null
    private var testChip: TextView? = null
    private val modeChips = LinkedHashMap<BindMode, TextView>()
    private var orientChip: TextView? = null
    private var discardChip: TextView? = null
    private val btnChips = LinkedHashMap<PadButton, TextView>()

    private val engineListener: () -> Unit = {
        canvas?.invalidate()
        refreshHint()
        refreshChips()
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    // ------------------------------------------------------------ abrir / fechar

    /** Mostra o editor. Devolve false se o Android recusou as janelas (nada fica aberto). */
    fun show(): Boolean {
        return try {
            val cv = EditorCanvas(svc)
            canvas = cv
            wm.addView(cv, canvasParams(true))
            val b = buildBar()
            bar = b
            wm.addView(b, barParams())
            PadEngine.editHook = { btn ->
                selected = btn
                refreshChips()
                refreshHint()
                canvas?.invalidate()
                scrollToSelected()
            }
            PadEngine.addListener(engineListener)
            PadEngine.setEditing(true)
            refreshChips()
            refreshHint()
            true
        } catch (e: Exception) {
            cleanup()
            false
        }
    }

    fun close() {
        if (closed) return
        closed = true
        cleanup()
        onClosed()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        PadEngine.removeListener(engineListener)
        PadEngine.editHook = null
        PadEngine.setEditing(false)
        // saiu no meio de um teste: solta qualquer dedo que ainda esteja na tela
        PadEngine.releaseAll()
        bar?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        canvas?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bar = null
        canvas = null
    }

    private fun saveAndExit() {
        PadStore.save(svc)
        PadEngine.notifyProfileEdited()
        close()
    }

    private fun discardAndExit() {
        prof.bindings.clear()
        for (b in snapshot) prof.bindings.add(b.copy())
        prof.landscape = snapshotLandscape
        PadEngine.notifyProfileEdited()
        close()
    }

    // ------------------------------------------------------------ janelas

    private fun canvasParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.title = "WinLauncher gamepad - pontos"
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun barParams(): WindowManager.LayoutParams {
        val w = Math.min((svc.screenWidth() * 0.94f).toInt(), dp(560))
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val lp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (barAtTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.y = dp(if (barAtTop) 28 else 16)
        lp.title = "WinLauncher gamepad - barra"
        return lp
    }

    private fun relayoutBar() {
        val b = bar ?: return
        try {
            wm.updateViewLayout(b, barParams())
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ barra

    private fun box(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = box(if (on) "#19B4F0" else "#33FFFFFF", 6)
        c.setTextColor(Color.WHITE)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val c = TextView(svc)
        c.text = text
        c.textSize = 11.5f
        c.gravity = Gravity.CENTER
        c.setSingleLine(true)
        c.setPadding(dp(8), dp(6), dp(8), dp(6))
        c.isClickable = true
        c.setOnClickListener { onClick() }
        styleChip(c, false)
        return c
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(svc)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun addWeighted(parent: LinearLayout, v: View, weight: Float = 1f) {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        parent.addView(v, lp)
    }

    private fun buildBar(): LinearLayout {
        val col = LinearLayout(svc)
        col.orientation = LinearLayout.VERTICAL
        col.background = box("#EE0E1522", 12)
        col.setPadding(dp(8), dp(6), dp(8), dp(6))

        // ---- linha 1: título + testar / barra em cima-embaixo / recolher
        val r1 = row()
        val t = TextView(svc)
        t.text = "Editando: " + prof.name
        t.textSize = 12.5f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Color.WHITE)
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        title = t
        addWeighted(r1, t, 1f)
        val tc = chip("Testar") { toggleTest() }
        testChip = tc
        r1.addView(tc)
        val pc = chip("⇅") {
            barAtTop = !barAtTop
            relayoutBar()
        }
        r1.addView(pc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = dp(4) })
        val cc = chip("▾") { }
        cc.setOnClickListener {
            collapsed = !collapsed
            body?.visibility = if (collapsed) View.GONE else View.VISIBLE
            cc.text = if (collapsed) "▸" else "▾"
        }
        r1.addView(cc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = dp(4) })
        col.addView(r1)

        val bd = LinearLayout(svc)
        bd.orientation = LinearLayout.VERTICAL
        body = bd
        col.addView(bd)

        // ---- linha 2: botões do controle (rolagem horizontal)
        val sv = HorizontalScrollView(svc)
        sv.isHorizontalScrollBarEnabled = false
        scroll = sv
        val chipsRow = row()
        for (b in PadButton.values()) {
            val ch = chip(b.label) {
                selected = b
                refreshChips()
                refreshHint()
                canvas?.invalidate()
            }
            btnChips[b] = ch
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(2), dp(4), dp(2), dp(2))
            chipsRow.addView(ch, lp)
        }
        sv.addView(chipsRow)
        bd.addView(sv)

        // ---- linha 3: dica
        val h = TextView(svc)
        h.textSize = 11f
        h.setTextColor(Color.parseColor("#C6D0E0"))
        h.setPadding(dp(2), dp(2), dp(2), dp(2))
        hint = h
        bd.addView(h)

        // ---- linha 4: modo do botão selecionado
        val r4 = row()
        val rem = chip("Remover ponto") {
            prof.remove(selected)
            refreshChips()
            refreshHint()
            canvas?.invalidate()
        }
        for (m in listOf(BindMode.TAP, BindMode.HOLD, BindMode.TURBO, BindMode.JOYSTICK, BindMode.CAMERA)) {
            val mc = chip(m.label) { setMode(m) }
            modeChips[m] = mc
            addWeighted(r4, mc)
        }
        addWeighted(r4, rem)
        bd.addView(r4)

        // ---- linha 5: ajuste fino + orientação do perfil
        val r5 = row()
        addWeighted(r5, nudgeChip("◀", -1, 0), 0.7f)
        addWeighted(r5, nudgeChip("▶", 1, 0), 0.7f)
        addWeighted(r5, nudgeChip("▲", 0, -1), 0.7f)
        addWeighted(r5, nudgeChip("▼", 0, 1), 0.7f)
        val oc = chip("") {
            prof.landscape = currentLandscape()
            refreshHint()
            refreshChips()
        }
        orientChip = oc
        addWeighted(r5, oc, 2.6f)
        bd.addView(r5)

        // ---- linha 6: ações
        val r6 = row()
        val save = chip("Salvar e sair") { saveAndExit() }
        styleChip(save, true)
        val dis = chip("Descartar") { }
        dis.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - discardArmedAt < 3000L) {
                discardAndExit()
            } else {
                discardArmedAt = now
                dis.text = "Toque de novo"
                handler.postDelayed({ dis.text = "Descartar" }, 3000L)
            }
        }
        discardChip = dis
        val open = chip("Abrir jogo") { openGame() }
        addWeighted(r6, save, 1.3f)
        addWeighted(r6, dis, 1f)
        addWeighted(r6, open, 1f)
        bd.addView(r6)

        return col
    }

    /** Setinha de ajuste fino: um toque move 0,25% da tela; segurar repete. */
    private fun nudgeChip(text: String, dx: Int, dy: Int): TextView {
        val c = chip(text) { }
        var rep: Runnable? = null
        c.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    nudge(dx, dy)
                    val r = object : Runnable {
                        override fun run() {
                            nudge(dx, dy)
                            handler.postDelayed(this, 70L)
                        }
                    }
                    rep = r
                    handler.postDelayed(r, 380L)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    rep?.let { handler.removeCallbacks(it) }
                    rep = null
                }
            }
            true
        }
        return c
    }

    private fun nudge(dx: Int, dy: Int) {
        val cur = prof.bindingFor(selected) ?: return
        if (cur.mode == BindMode.OFF) return
        val step = 0.0025f
        cur.x = PadProfile.clamp01(cur.x + dx * step)
        cur.y = PadProfile.clamp01(cur.y + dy * step)
        canvas?.invalidate()
        refreshHint()
    }

    private fun setMode(m: BindMode) {
        val cur = prof.bindingFor(selected)
        if (cur == null) {
            // ponto novo no meio da tela: arraste para o lugar certo
            prof.set(selected, m, 0.5f, 0.5f).applyModeDefaults()
        } else {
            cur.mode = m
            cur.applyModeDefaults()
        }
        refreshChips()
        refreshHint()
        canvas?.invalidate()
    }

    private fun toggleTest() {
        testing = !testing
        // em teste o mapeamento volta a valer; fora dele os botões só selecionam o ponto
        PadEngine.setEditing(!testing)
        val cv = canvas
        if (cv != null) {
            try {
                wm.updateViewLayout(cv, canvasParams(!testing))
            } catch (e: Exception) {
            }
            cv.invalidate()
        }
        testChip?.text = if (testing) "Parar teste" else "Testar"
        refreshChips()
        refreshHint()
    }

    private fun openGame() {
        try {
            val li = svc.packageManager.getLaunchIntentForPackage(prof.pkg)
            if (li == null) {
                Toast.makeText(svc, "Não encontrei o jogo: abra-o você mesmo", Toast.LENGTH_SHORT).show()
                return
            }
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            svc.startActivity(li)
        } catch (e: Exception) {
            Toast.makeText(svc, "O Android não deixou abrir o jogo daqui: abra-o você mesmo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scrollToSelected() {
        val ch = btnChips[selected] ?: return
        val sv = scroll ?: return
        sv.post { sv.smoothScrollTo(Math.max(0, ch.left - dp(60)), 0) }
    }

    private fun currentLandscape(): Boolean = svc.screenWidth() > svc.screenHeight()

    private fun refreshChips() {
        for ((btn, ch) in btnChips) {
            val bd = prof.bindingFor(btn)
            ch.text = btn.label + (if (bd != null && bd.mode != BindMode.OFF) " •" else "")
            styleChip(ch, !testing && btn == selected)
        }
        val cur = prof.bindingFor(selected)
        val allowed = BindMode.forButton(selected)
        for ((m, mc) in modeChips) {
            mc.visibility = if (m in allowed) View.VISIBLE else View.GONE
            styleChip(mc, !testing && cur?.mode == m)
        }
        val land = currentLandscape()
        val nome = if (prof.landscape) "paisagem" else "retrato"
        orientChip?.text = if (land == prof.landscape) "Perfil: " + nome + " ✓" else "Perfil: " + nome + " ⚠ trocar"
    }

    private fun refreshHint() {
        val h = hint ?: return
        if (testing) {
            h.text = testStatus()
            return
        }
        val cur = prof.bindingFor(selected)
        h.text = if (cur == null || cur.mode == BindMode.OFF) {
            "Botão " + selected.label + ": toque na tela onde ele deve tocar. Ou aperte outro botão no controle para escolhê-lo."
        } else {
            "Botão " + selected.label + " (" + cur.mode.label + ") em X " + Math.round(cur.x * 100) + "%, Y " +
                Math.round(cur.y * 100) + "%. Arraste o ponto, toque noutro lugar ou use as setas."
        }
    }

    private fun testStatus(): String {
        if (!PadEngine.masterOn) return "Teste: o mapeamento está desligado (chave geral no painel)."
        if (!prof.enabled) return "Teste: este perfil está desativado."
        if (PadEngine.foregroundPkg != prof.pkg) return "Teste: o jogo ainda não está na frente. Abra o jogo."
        if (currentLandscape() != prof.landscape) return "Teste: gire a tela ou toque em \"Perfil\" para trocar a orientação do perfil."
        val hasStick = prof.bindings.any { it.mode == BindMode.JOYSTICK || it.mode == BindMode.CAMERA }
        if (hasStick && !PadEngine.axesSupported) return "Teste: analógicos só funcionam no Android 14 ou mais novo."
        return "Teste: aperte os botões do controle. O toque vai para o jogo e o ponto acende."
    }

    // ------------------------------------------------------------ tela com os pontos

    private inner class EditorCanvas(c: Context) : View(c) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val loc = IntArray(2)
        private var dragging: PadBinding? = null
        private var dragX = -1f
        private var dragY = -1f

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            // girou a tela: a barra precisa da largura nova e o aviso de orientação pode mudar
            post {
                relayoutBar()
                refreshChips()
                refreshHint()
            }
        }

        private fun sw(): Float = Math.max(1, svc.screenWidth() - 1).toFloat()
        private fun sh(): Float = Math.max(1, svc.screenHeight() - 1).toFloat()

        override fun onDraw(canvas: Canvas) {
            getLocationOnScreen(loc)
            val w = sw()
            val h = sh()
            if (!testing) canvas.drawColor(Color.argb(70, 0, 0, 0))
            val r = 20f * d
            paint.textAlign = Paint.Align.CENTER
            for (b in prof.bindings) {
                if (b.mode == BindMode.OFF) continue
                val cx = b.x * w - loc[0]
                val cy = b.y * h - loc[1]
                val sel = !testing && b.button == selected
                val hot = testing && PadEngine.isPressed(b.button)
                val base = if (b.mode == BindMode.TAP) Color.rgb(240, 138, 25) else Color.rgb(25, 180, 240)
                val alpha = if (testing && !hot) 110 else 175
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base))
                canvas.drawCircle(cx, cy, if (hot) r * 1.3f else r, paint)
                if (sel || hot) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.5f * d
                    paint.color = if (hot) Color.rgb(61, 220, 132) else Color.WHITE
                    canvas.drawCircle(cx, cy, r + 4f * d, paint)
                }
                // analógico: anel do raio (joystick: até onde o dedo anda; câmera: quando volta ao ponto)
                if (b.mode == BindMode.JOYSTICK || b.mode == BindMode.CAMERA) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 1.5f * d
                    paint.color = Color.argb(150, 255, 255, 255)
                    canvas.drawCircle(cx, cy, b.radius * Math.min(w, h), paint)
                }
                // ponto exato do toque
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                canvas.drawCircle(cx, cy, 2.2f * d, paint)
                // nome do botão, acima do círculo
                paint.textSize = 12f * d
                paint.typeface = Typeface.DEFAULT_BOLD
                paint.color = Color.WHITE
                paint.setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
                canvas.drawText(b.button.tag, cx, cy - r - 6f * d, paint)
                paint.clearShadowLayer()
            }
            // mira enquanto arrasta
            if (dragging != null && dragX >= 0f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f * d
                paint.color = Color.argb(170, 255, 255, 255)
                canvas.drawLine(dragX - loc[0], 0f, dragX - loc[0], height.toFloat(), paint)
                canvas.drawLine(0f, dragY - loc[1], width.toFloat(), dragY - loc[1], paint)
            }
        }

        private fun hit(rawX: Float, rawY: Float): PadBinding? {
            val w = sw()
            val h = sh()
            var best: PadBinding? = null
            var bestD = 32f * d
            for (b in prof.bindings) {
                if (b.mode == BindMode.OFF) continue
                val dx = b.x * w - rawX
                val dy = b.y * h - rawY
                val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                if (dist < bestD) {
                    bestD = dist
                    best = b
                }
            }
            return best
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (testing) return false
            val fx = PadProfile.clamp01(ev.rawX / sw())
            val fy = PadProfile.clamp01(ev.rawY / sh())
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val hitB = hit(ev.rawX, ev.rawY)
                    if (hitB != null) {
                        dragging = hitB
                        selected = hitB.button
                        scrollToSelected()
                    } else {
                        // área vazia: põe (ou move) o ponto do botão selecionado
                        val cur = prof.bindingFor(selected)
                        dragging = if (cur == null) {
                            prof.set(selected, BindMode.defaultFor(selected), fx, fy)
                        } else {
                            if (cur.mode == BindMode.OFF) cur.mode = BindMode.defaultFor(cur.button)
                            cur.x = fx
                            cur.y = fy
                            cur
                        }
                    }
                    dragX = ev.rawX
                    dragY = ev.rawY
                    refreshChips()
                    refreshHint()
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dr = dragging
                    if (dr != null) {
                        dr.x = fx
                        dr.y = fy
                        dragX = ev.rawX
                        dragY = ev.rawY
                        refreshHint()
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = null
                    dragX = -1f
                    dragY = -1f
                    refreshChips()
                    refreshHint()
                    invalidate()
                }
            }
            return true
        }
    }
}
