package com.example.winlauncher

import org.json.JSONArray
import org.json.JSONObject

/**
 * Mapeador de gamepad (Etapa 1) - modelo de dados. Sem nenhuma dependência de Android além do org.json,
 * para poder ser compilado e testado numa JVM comum.
 *
 * Um [PadProfile] pertence a UM app (pacote). Cada [PadBinding] liga um botão do controle a um ponto da tela
 * (posição em FRAÇÃO da tela, 0..1, para sobreviver a trocas de resolução) e a um modo de toque.
 */

/** Botões do controle que o mapeador reconhece. [key] é o KeyEvent.KEYCODE_* correspondente. */
enum class PadButton(val key: Int, val label: String, val tag: String = label) {
    A(96, "A"),
    B(97, "B"),
    X(99, "X"),
    Y(100, "Y"),
    L1(102, "L1"),
    R1(103, "R1"),
    L2(104, "L2"),
    R2(105, "R2"),
    THUMBL(106, "L3"),
    THUMBR(107, "R3"),
    START(108, "Start"),
    SELECT(109, "Select"),
    MODE(110, "Mode"),
    DPAD_UP(19, "Cima"),
    DPAD_DOWN(20, "Baixo"),
    DPAD_LEFT(21, "Esquerda"),
    DPAD_RIGHT(22, "Direita"),

    /** Etapa 3: analógicos. Não são teclas (códigos negativos de propósito: nunca casam com um KeyEvent). */
    LSTICK(-1, "Analógico E", "LS"),
    RSTICK(-2, "Analógico D", "RS");

    val isStick: Boolean get() = key < 0

    companion object {
        fun fromKey(code: Int): PadButton? = values().firstOrNull { it.key == code }

        /** Códigos de tecla que só existem em controles (BUTTON_A..BUTTON_MODE). */
        fun isPadOnlyKey(code: Int): Boolean = code in 96..110

        fun fromName(n: String?): PadButton? = values().firstOrNull { it.name == n }
    }
}

/** O que acontece na tela quando o botão é apertado. */
enum class BindMode(val label: String) {
    /** Sem ação: o botão passa para o app normalmente. */
    OFF("Sem ação"),

    /** Toque curto: encosta e solta sozinho, mesmo que o botão continue apertado. */
    TAP("Toque rápido"),

    /** Segurar: o dedo fica na tela enquanto o botão estiver apertado. */
    HOLD("Segurar"),

    /** Etapa 3: turbo. Enquanto o botão estiver apertado, toca de novo e de novo ([PadBinding.rate] por segundo). */
    TURBO("Turbo"),

    /** Etapa 3 (só analógicos): joystick virtual. O dedo nasce no ponto e anda para onde o analógico aponta. */
    JOYSTICK("Joystick"),

    /** Etapa 3 (só analógicos): câmera. O analógico vira um arrasto contínuo (o dedo volta ao ponto ao chegar no raio). */
    CAMERA("Câmera");

    companion object {
        fun fromName(n: String?): BindMode = values().firstOrNull { it.name == n } ?: OFF

        /** Modos que fazem sentido para o botão [b] (analógico: joystick/câmera; botão: toque/segurar/turbo). */
        /** Modo de um ponto recém-marcado: analógico = joystick, botão = segurar. */
        fun defaultFor(b: PadButton): BindMode = if (b.isStick) JOYSTICK else HOLD

        fun forButton(b: PadButton): List<BindMode> =
            if (b.isStick) listOf(OFF, JOYSTICK, CAMERA) else listOf(OFF, TAP, HOLD, TURBO)
    }
}

class PadBinding(val button: PadButton, var mode: BindMode, var x: Float, var y: Float) {
    /** Joystick/câmera: raio em fração do lado MENOR da tela (joystick: até onde o dedo anda; câmera: quando o dedo volta ao ponto). */
    var radius = 0.12f

    /** Câmera: multiplicador da velocidade (1 = uma altura de tela por segundo com o analógico no fundo). */
    var speed = 1f

    /** Analógico: zona morta (0..1). Abaixo disso o analógico é ignorado. */
    var dead = 0.12f

    /** Turbo: toques por segundo. */
    var rate = 8

    fun copy(): PadBinding {
        val c = PadBinding(button, mode, x, y)
        c.radius = radius
        c.speed = speed
        c.dead = dead
        c.rate = rate
        return c
    }

    /** Valores iniciais do modo (ao trocar de modo no editor): a câmera pede um raio maior que o joystick. */
    fun applyModeDefaults() {
        when (mode) {
            BindMode.CAMERA -> radius = 0.25f
            BindMode.JOYSTICK -> radius = 0.12f
            else -> {
            }
        }
    }

    fun clampParams() {
        radius = if (radius.isNaN()) 0.12f else Math.max(0.03f, Math.min(0.45f, radius))
        speed = if (speed.isNaN()) 1f else Math.max(0.2f, Math.min(4f, speed))
        dead = if (dead.isNaN()) 0.12f else Math.max(0.03f, Math.min(0.6f, dead))
        rate = Math.max(2, Math.min(10, rate))
    }
}

class PadProfile(
    var id: String,
    var pkg: String,
    var name: String,
    var enabled: Boolean = true,
    /** true = o perfil vale para o jogo em paisagem (largura > altura). */
    var landscape: Boolean = true,
    val bindings: MutableList<PadBinding> = ArrayList()
) {
    /**
     * Etapa 3: ler também o D-pad (quando o controle o manda como eixo) e os gatilhos analógicos como botões.
     * Só no Android 14+ e com um custo: enquanto o jogo está na frente, os eixos do controle não chegam a ele.
     */
    var axisKeys: Boolean = false

    fun bindingFor(b: PadButton): PadBinding? = bindings.firstOrNull { it.button == b }

    /** Cria ou atualiza a ligação do botão [b]. Posição sempre limitada a 0..1. */
    fun set(b: PadButton, mode: BindMode, x: Float, y: Float): PadBinding {
        val cx = clamp01(x)
        val cy = clamp01(y)
        val old = bindingFor(b)
        if (old != null) {
            old.mode = mode
            old.x = cx
            old.y = cy
            return old
        }
        val nb = PadBinding(b, mode, cx, cy)
        bindings.add(nb)
        return nb
    }

    fun remove(b: PadButton) {
        bindings.removeAll { it.button == b }
    }

    /** Quantos botões realmente fazem alguma coisa. */
    fun activeCount(): Int = bindings.count { it.mode != BindMode.OFF }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("pkg", pkg)
        o.put("name", name)
        o.put("enabled", enabled)
        o.put("landscape", landscape)
        o.put("axisKeys", axisKeys)
        val arr = JSONArray()
        for (b in bindings) {
            val j = JSONObject()
            j.put("b", b.button.name)
            j.put("m", b.mode.name)
            j.put("x", b.x.toDouble())
            j.put("y", b.y.toDouble())
            if (b.mode == BindMode.JOYSTICK || b.mode == BindMode.CAMERA) {
                j.put("r", b.radius.toDouble())
                j.put("s", b.speed.toDouble())
                j.put("dz", b.dead.toDouble())
            }
            if (b.mode == BindMode.TURBO) j.put("rt", b.rate)
            arr.put(j)
        }
        o.put("bindings", arr)
        return o
    }

    companion object {
        fun clamp01(v: Float): Float = if (v.isNaN()) 0.5f else if (v < 0f) 0f else if (v > 1f) 1f else v

        /** Lê um perfil; devolve null se faltar id ou pacote. Itens inválidos são ignorados, nunca derrubam a leitura. */
        fun fromJson(o: JSONObject): PadProfile? {
            val id = o.optString("id", "")
            val pkg = o.optString("pkg", "")
            if (id.isEmpty() || pkg.isEmpty()) return null
            val p = PadProfile(
                id, pkg, o.optString("name", pkg),
                o.optBoolean("enabled", true), o.optBoolean("landscape", true)
            )
            p.axisKeys = o.optBoolean("axisKeys", false)
            val arr = o.optJSONArray("bindings")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val j = arr.optJSONObject(i) ?: continue
                    val btn = PadButton.fromName(j.optString("b", "")) ?: continue
                    if (p.bindingFor(btn) != null) continue
                    val nb = p.set(
                        btn, BindMode.fromName(j.optString("m", "")),
                        j.optDouble("x", 0.5).toFloat(), j.optDouble("y", 0.5).toFloat()
                    )
                    nb.radius = j.optDouble("r", 0.12).toFloat()
                    nb.speed = j.optDouble("s", 1.0).toFloat()
                    nb.dead = j.optDouble("dz", 0.12).toFloat()
                    nb.rate = j.optInt("rt", 8)
                    nb.clampParams()
                }
            }
            return p
        }
    }
}

/** Arquivo inteiro de perfis (versão + chave geral + lista). */
object PadJson {
    const val VERSION = 2

    fun write(on: Boolean, profiles: List<PadProfile>): String {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("on", on)
        val arr = JSONArray()
        for (p in profiles) arr.put(p.toJson())
        o.put("profiles", arr)
        return o.toString()
    }

    class Parsed(val on: Boolean, val profiles: List<PadProfile>)

    /** Nunca lança: arquivo estragado vira "ligado, sem perfis". */
    fun read(text: String?): Parsed {
        if (text.isNullOrBlank()) return Parsed(true, emptyList())
        return try {
            val o = JSONObject(text)
            val list = ArrayList<PadProfile>()
            val arr = o.optJSONArray("profiles")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val j = arr.optJSONObject(i) ?: continue
                    val p = PadProfile.fromJson(j) ?: continue
                    if (list.none { it.id == p.id || it.pkg == p.pkg }) list.add(p)
                }
            }
            Parsed(o.optBoolean("on", true), list)
        } catch (e: Exception) {
            Parsed(true, emptyList())
        }
    }
}
