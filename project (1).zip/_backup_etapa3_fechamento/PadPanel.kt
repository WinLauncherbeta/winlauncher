package com.example.winlauncher

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/**
 * Mapeador de gamepad (Etapa 1) - painel dentro de Configurações > Jogos.
 * Telas: principal (estado, teste, perfis) -> escolher app -> editor do perfil (mini-tela com os pontos de toque).
 * Só thread principal.
 */
class PadPanel(private val a: MainActivity, private val dark: Boolean = true) {

    private val d = a.resources.displayMetrics.density
    private val ink = Color.parseColor(if (dark) "#F2F5FA" else "#1F1F1F")
    private val sub = Color.parseColor(if (dark) "#A9B3C6" else "#5C5C5C")
    private val accHex = if (dark) "#19B4F0" else "#0067C0"
    private val acc = Color.parseColor(accHex)
    private val chipOff = if (dark) "#24FFFFFF" else "#14000000"
    private val rowBg = if (dark) "#14FFFFFF" else "#0F000000"
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private val root = FrameLayout(a)

    // ---- ouvinte do motor da tela atual (sai da lista quando o painel sai da janela)
    private var screenListener: (() -> Unit)? = null

    private fun setScreenListener(l: (() -> Unit)?) {
        screenListener?.let { PadEngine.removeListener(it) }
        screenListener = l
        if (l != null && root.isAttachedToWindow) PadEngine.addListener(l)
    }

    fun build(): View {
        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                screenListener?.let { PadEngine.addListener(it) }
            }

            override fun onViewDetachedFromWindow(v: View) {
                PadEngine.setDiag(false)
                screenListener?.let { PadEngine.removeListener(it) }
            }
        })
        PadStore.load(a)
        showMain()
        return root
    }

    // ------------------------------------------------------------ pequenos componentes

    private fun column(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(a)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun box(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun heading(parent: LinearLayout, t: String) {
        val tv = label(t, 15f, ink, true)
        tv.setPadding(0, dp(14), 0, dp(6))
        parent.addView(tv)
    }

    private fun note(parent: LinearLayout, t: String) {
        val tv = label(t, 11.5f, sub)
        tv.setPadding(0, dp(6), 0, dp(2))
        parent.addView(tv)
    }

    private fun button(parent: LinearLayout, text: String, filled: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(a)
        b.text = text
        b.textSize = 12.5f
        b.setTextColor(if (filled) Color.WHITE else ink)
        b.gravity = Gravity.CENTER
        b.background = box(if (filled) accHex else chipOff, 6)
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
        return b
    }

    private fun chip(text: String, on: Boolean, onClick: () -> Unit): TextView {
        val c = TextView(a)
        c.text = text
        c.textSize = 12f
        c.gravity = Gravity.CENTER
        c.setPadding(dp(8), dp(8), dp(8), dp(8))
        c.isClickable = true
        styleChip(c, on)
        c.setOnClickListener { onClick() }
        return c
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = box(if (on) accHex else chipOff, 6)
        c.setTextColor(if (on) Color.WHITE else ink)
    }

    private fun switchRow(parent: LinearLayout, text: String, value: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(a)
        s.text = text
        s.setTextColor(ink)
        s.textSize = 12.5f
        s.isChecked = value
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(10)
        parent.addView(s, lp)
        return s
    }

    private fun show(c: View) {
        root.removeAllViews()
        root.addView(c, FrameLayout.LayoutParams(match, wrap))
    }

    private fun controllerNames(): List<String> {
        val out = ArrayList<String>()
        try {
            for (id in InputDevice.getDeviceIds()) {
                val dev = InputDevice.getDevice(id) ?: continue
                val s = dev.sources
                val pad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                    (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                if (pad && !dev.isVirtual) out.add(dev.name)
            }
        } catch (e: Exception) {
        }
        return out
    }

    // ------------------------------------------------------------ tela principal

    private fun showMain() {
        PadEngine.setDiag(true)
        val c = column()
        heading(c, "Mapeador de gamepad")
        note(c, "Use o controle em jogos que não têm suporte a controle: cada botão vira um toque na tela, nas posições que você escolher para cada jogo.")

        val svc = label("", 12.5f, ink)
        svc.setPadding(0, dp(10), 0, 0)
        c.addView(svc)
        button(c, "Abrir configurações de Acessibilidade", false) {
            try {
                a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir Acessibilidade")
            }
        }
        note(c, "Ative \"WinLauncher - mapeador de gamepad\" em Apps instalados. O serviço só lê os botões do controle e só toca a tela dos jogos que você configurar.")

        switchRow(c, "Mapeamento ligado", PadEngine.masterOn) { on -> PadStore.setMaster(a, on) }

        // ---- monitor ao vivo
        heading(c, "Teste do controle")
        val pads = label("", 12f, sub)
        val pressed = label("", 13f, ink, true)
        val lastLines = label("", 11.5f, sub)
        val axesLine = label("", 11.5f, sub)
        pressed.setPadding(0, dp(6), 0, 0)
        c.addView(pads)
        c.addView(pressed)
        c.addView(axesLine)
        c.addView(lastLines)
        note(c, "Aperte botões do controle: eles aparecem aqui (precisa do serviço ligado).")

        // ---- teste de injeção de toque
        var touches = 0
        val pad = TextView(a)
        pad.gravity = Gravity.CENTER
        pad.setTextColor(ink)
        pad.textSize = 12.5f
        pad.background = box(rowBg, 8)
        pad.text = "Área de teste: toques recebidos 0"
        pad.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                touches++
                pad.text = "Área de teste: toques recebidos " + touches
            }
            true
        }
        c.addView(pad, LinearLayout.LayoutParams(match, dp(64)).also { it.topMargin = dp(10) })
        button(c, "Testar injeção de toque") {
            val loc = IntArray(2)
            pad.getLocationOnScreen(loc)
            val ok = PadMapperService.testTap(loc[0] + pad.width / 2f, loc[1] + pad.height / 2f)
            if (!ok) a.toast("Ligue o serviço em Acessibilidade primeiro")
        }
        note(c, "O toque de teste cai no centro da área acima. Se o contador subir, o serviço consegue tocar a tela.")

        fun refresh() {
            svc.text = if (PadMapperService.running) "Serviço: ativado" else "Serviço: desativado"
            svc.setTextColor(if (PadMapperService.running) acc else sub)
            val names = controllerNames()
            pads.text = if (names.isEmpty()) "Controle: nenhum detectado" else "Controle: " + names.joinToString(", ")
            val p = PadEngine.pressedLabels()
            pressed.text = if (p.isEmpty()) "Nenhum botão apertado" else "Apertados: " + p.joinToString(" + ")
            lastLines.text = PadEngine.recentLog().take(4).joinToString("\n")
            val ax = PadEngine.lastAxes
            axesLine.text = when {
                !PadEngine.axesSupported -> "Analógicos: precisam do Android 14 ou mais novo"
                !PadMapperService.running -> ""
                ax == null -> "Analógicos: mexa neles (nenhum eixo recebido ainda)"
                else -> String.format(
                    java.util.Locale.US, "Eixos: E %.2f/%.2f  D %.2f/%.2f  L2 %.2f  R2 %.2f  D-pad %.0f/%.0f",
                    ax.lx, ax.ly, ax.rx, ax.ry, ax.lt, ax.rt, ax.hx, ax.hy
                )
            }
        }
        refresh()
        setScreenListener { refresh() }

        // ---- perfis
        heading(c, "Perfis por jogo")
        val list = column()
        c.addView(list)
        fun fillList() {
            list.removeAllViews()
            if (PadStore.profiles.isEmpty()) note(list, "Nenhum perfil ainda. Toque em \"Novo perfil\" e escolha o jogo.")
            for (p in ArrayList(PadStore.profiles)) list.addView(profileRow(p) { fillList() })
        }
        fillList()
        button(c, "Novo perfil (escolher o jogo)") { showPicker() }
        PadStore.lastError?.let { note(c, it) }
        show(c)
    }

    private fun profileRow(p: PadProfile, onChanged: () -> Unit): View {
        val row = column()
        row.background = box(rowBg, 8)
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        row.addView(label(p.name, 13.5f, ink, true))
        row.addView(label(p.pkg + "  -  " + p.activeCount() + " botão(ões) mapeado(s)", 11f, sub))
        val sw = Switch(a)
        sw.text = "Perfil ativo"
        sw.setTextColor(ink)
        sw.textSize = 12f
        sw.isChecked = p.enabled
        sw.setOnCheckedChangeListener { _, v ->
            p.enabled = v
            PadStore.save(a)
        }
        row.addView(sw)
        val btns = LinearLayout(a)
        btns.orientation = LinearLayout.HORIZONTAL
        var armed = 0L
        val edit = chip("Editar", true) { showEditor(p) }
        val del = chip("Excluir", false) { }
        del.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - armed < 4000) {
                PadStore.delete(a, p)
                onChanged()
            } else {
                armed = now
                del.text = "Toque de novo"
                del.postDelayed({ del.text = "Excluir" }, 4000)
            }
        }
        val lp1 = LinearLayout.LayoutParams(0, wrap, 1f)
        lp1.setMargins(0, dp(6), dp(4), 0)
        val lp2 = LinearLayout.LayoutParams(0, wrap, 1f)
        lp2.setMargins(dp(4), dp(6), 0, 0)
        btns.addView(edit, lp1)
        btns.addView(del, lp2)
        row.addView(btns)
        val outer = LinearLayout.LayoutParams(match, wrap)
        outer.topMargin = dp(6)
        row.layoutParams = outer
        return row
    }

    // ------------------------------------------------------------ escolher o jogo

    private class AppItem(val name: String, val pkg: String)

    private fun showPicker() {
        PadEngine.setDiag(false)
        setScreenListener(null)
        val c = column()
        button(c, "‹ Voltar", false) { showMain() }
        heading(c, "Escolha o jogo")
        val apps = ArrayList<AppItem>()
        try {
            val pm = a.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == a.packageName || apps.any { it.pkg == pkg }) continue
                apps.add(AppItem(ri.loadLabel(pm).toString(), pkg))
            }
        } catch (e: Exception) {
        }
        apps.sortBy { it.name.lowercase() }

        val search = EditText(a)
        search.hint = "Buscar app"
        search.setTextColor(ink)
        search.setHintTextColor(sub)
        search.textSize = 13f
        search.setSingleLine(true)
        c.addView(search, LinearLayout.LayoutParams(match, wrap))
        val list = column()
        c.addView(list)

        fun fill(filter: String) {
            list.removeAllViews()
            val f = filter.trim().lowercase()
            var shown = 0
            for (app in apps) {
                if (f.isNotEmpty() && !app.name.lowercase().contains(f)) continue
                if (shown >= 60) break
                shown++
                val r = column()
                r.background = box(rowBg, 8)
                r.setPadding(dp(10), dp(8), dp(10), dp(8))
                r.addView(label(app.name, 13f, ink, true))
                r.addView(label(app.pkg, 10.5f, sub))
                r.isClickable = true
                r.setOnClickListener { showEditor(PadStore.getOrCreate(a, app.pkg, app.name)) }
                val lp = LinearLayout.LayoutParams(match, wrap)
                lp.topMargin = dp(4)
                list.addView(r, lp)
            }
            if (shown == 0) note(list, "Nenhum app encontrado.")
        }
        fill("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c1: Int, a1: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c1: Int) {}
            override fun afterTextChanged(s: Editable?) {
                fill(s?.toString() ?: "")
            }
        })
        show(c)
    }

    // ------------------------------------------------------------ editor do perfil

    private fun showEditor(p: PadProfile) {
        PadEngine.setDiag(false)
        val c = column()
        button(c, "‹ Voltar", false) {
            PadStore.save(a)
            showMain()
        }
        heading(c, p.name)
        note(c, p.pkg)

        var sel: PadButton? = PadButton.A
        val chips = LinkedHashMap<PadButton, TextView>()
        val detail = column()
        val coords = label("", 11.5f, sub)

        val view = PadLayoutView(a, p, dark)

        // orientação do jogo
        val orient = LinearLayout(a)
        orient.orientation = LinearLayout.HORIZONTAL
        val cl = chip("Jogo em paisagem", p.landscape) { }
        val cp = chip("Jogo em retrato", !p.landscape) { }
        fun setOrient(land: Boolean) {
            p.landscape = land
            styleChip(cl, land)
            styleChip(cp, !land)
            view.requestLayout()
            view.invalidate()
            PadStore.save(a)
        }
        cl.setOnClickListener { setOrient(true) }
        cp.setOnClickListener { setOrient(false) }
        val l1 = LinearLayout.LayoutParams(0, wrap, 1f)
        l1.setMargins(0, dp(8), dp(4), dp(8))
        val l2 = LinearLayout.LayoutParams(0, wrap, 1f)
        l2.setMargins(dp(4), dp(8), 0, dp(8))
        orient.addView(cl, l1)
        orient.addView(cp, l2)
        c.addView(orient)

        switchRow(c, "Ler D-pad e gatilhos pelos eixos", p.axisKeys) { v ->
            p.axisKeys = v
            PadStore.save(a)
        }
        note(c, "Só no Android 14+. Use se o D-pad ou L2/R2 do seu controle não aparecem como botões. Enquanto o jogo está na frente, os eixos do controle não chegam a ele (só ao mapeador).")

        // Etapa 2: editar com os pontos por cima do jogo de verdade
        button(c, "Editar sobre o jogo") {
            PadStore.save(a)
            if (!PadMapperService.running) {
                a.toast("Ligue o serviço em Acessibilidade primeiro")
            } else if (!PadMapperService.openEditor(p)) {
                a.toast("Não foi possível abrir o editor sobre o jogo")
            } else {
                try {
                    val li = a.packageManager.getLaunchIntentForPackage(p.pkg)
                    if (li != null) {
                        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        a.startActivity(li)
                    } else {
                        a.toast("Não consegui abrir o jogo: abra-o você mesmo")
                    }
                } catch (e: Exception) {
                    a.toast("Não consegui abrir o jogo: abra-o você mesmo")
                }
            }
        }
        note(c, "Abre o jogo com os pontos por cima: arraste cada ponto para o lugar exato do botão na tela do jogo e teste com o controle ali mesmo.")

        c.addView(view, LinearLayout.LayoutParams(wrap, wrap))
        note(c, "Ou use o quadro abaixo: escolha um botão (ou aperte-o no controle) e toque no quadro para marcar onde ele toca na tela. Arraste um ponto para mover.")

        fun refreshDetail() {
            for ((b, ch) in chips) {
                val bd = p.bindingFor(b)
                ch.text = b.label + (if (bd != null && bd.mode != BindMode.OFF) " •" else "")
                styleChip(ch, b == sel)
            }
            view.selected = sel
            view.invalidate()
            detail.removeAllViews()
            val s = sel
            if (s == null) return
            val bd = p.bindingFor(s)
            detail.addView(label("Botão " + s.label, 13.5f, ink, true))
            val modes = LinearLayout(a)
            modes.orientation = LinearLayout.HORIZONTAL
            for (m in BindMode.forButton(s)) {
                val mc = chip(m.label, (bd?.mode ?: BindMode.OFF) == m) {
                    val cur = p.bindingFor(s)
                    if (m == BindMode.OFF) {
                        if (cur != null) cur.mode = BindMode.OFF
                    } else if (cur == null) {
                        p.set(s, m, 0.5f, 0.5f).applyModeDefaults()
                    } else {
                        cur.mode = m
                        cur.applyModeDefaults()
                    }
                    PadStore.save(a)
                    refreshDetail()
                }
                val lp = LinearLayout.LayoutParams(0, wrap, 1f)
                lp.setMargins(dp(2), dp(6), dp(2), dp(6))
                modes.addView(mc, lp)
            }
            detail.addView(modes)
            coords.text = if (bd == null || bd.mode == BindMode.OFF) "Sem ação: o botão funciona normalmente no jogo."
            else "Toca em X " + Math.round(bd.x * 100) + "%, Y " + Math.round(bd.y * 100) + "%"
            detail.addView(coords)
        }

        // grade de botões (6 por linha)
        val all = PadButton.values()
        var rowLayout: LinearLayout? = null
        for (i in all.indices) {
            if (i % 6 == 0) {
                rowLayout = LinearLayout(a)
                rowLayout.orientation = LinearLayout.HORIZONTAL
                c.addView(rowLayout)
            }
            val b = all[i]
            val ch = chip(b.label, false) {
                sel = b
                refreshDetail()
            }
            chips[b] = ch
            val lp = LinearLayout.LayoutParams(0, wrap, 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            rowLayout!!.addView(ch, lp)
        }
        c.addView(detail)

        view.onPick = { b ->
            sel = b
            refreshDetail()
        }
        view.onChange = {
            PadStore.save(a)
            refreshDetail()
        }

        // apertar um botão no controle seleciona a linha dele
        var seen = PadEngine.eventCount
        var seenEdit = PadEngine.editVersion
        setScreenListener {
            // o editor sobre o jogo salvou ou descartou: relê os pontos
            if (PadEngine.editVersion != seenEdit) {
                seenEdit = PadEngine.editVersion
                refreshDetail()
            }
            if (PadEngine.eventCount != seen) {
                seen = PadEngine.eventCount
                val lb = PadEngine.lastButton
                if (lb != null && PadEngine.pressedLabels().isNotEmpty()) {
                    sel = lb
                    refreshDetail()
                }
            }
        }
        refreshDetail()
        show(c)
    }
}

/**
 * Mini-tela: retângulo com a proporção real da tela e um ponto por botão mapeado.
 * Tocar em área vazia põe o ponto do botão selecionado ali; arrastar um ponto o move.
 */
class PadLayoutView(ctx: Context, private val prof: PadProfile, private val dark: Boolean) : View(ctx) {

    var selected: PadButton? = null
    var onPick: ((PadButton) -> Unit)? = null
    var onChange: (() -> Unit)? = null

    private val dens = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var dragging: PadBinding? = null

    private fun aspect(): Float {
        val dm = resources.displayMetrics
        val long = Math.max(dm.widthPixels, dm.heightPixels).toFloat()
        val short = Math.min(dm.widthPixels, dm.heightPixels).toFloat()
        return if (prof.landscape) long / short else short / long
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val avail = MeasureSpec.getSize(widthMeasureSpec).let { if (it <= 0) (300 * dens).toInt() else it }
        val maxH = (300 * dens).toInt()
        var w = avail
        var h = (w / aspect()).toInt()
        if (h > maxH) {
            h = maxH
            w = (h * aspect()).toInt()
        }
        setMeasuredDimension(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor(if (dark) "#101722" else "#E6EBF2")
        canvas.drawRoundRect(rect, 10 * dens, 10 * dens, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f * dens
        paint.color = Color.parseColor(if (dark) "#2A3A52" else "#B9C4D4")
        for (i in 1..3) {
            canvas.drawLine(w * i / 4f, 0f, w * i / 4f, h, paint)
            canvas.drawLine(0f, h * i / 4f, w, h * i / 4f, paint)
        }
        canvas.drawRoundRect(rect, 10 * dens, 10 * dens, paint)
        val r = 13 * dens
        for (b in prof.bindings) {
            val isSel = b.button == selected
            if (b.mode == BindMode.OFF && !isSel) continue
            val cx = b.x * w
            val cy = b.y * h
            paint.style = Paint.Style.FILL
            paint.color = when (b.mode) {
                BindMode.TAP -> Color.parseColor("#F08A19")
                BindMode.HOLD -> Color.parseColor("#19B4F0")
                BindMode.OFF -> Color.parseColor("#6B7686")
            }
            canvas.drawCircle(cx, cy, r, paint)
            if (isSel) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.5f * dens
                paint.color = Color.WHITE
                canvas.drawCircle(cx, cy, r + 3 * dens, paint)
            }
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            paint.textSize = 9.5f * dens
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText(b.button.tag, cx, cy + 3.4f * dens, paint)
        }
    }

    private fun hit(x: Float, y: Float): PadBinding? {
        var best: PadBinding? = null
        var bestD = 28 * dens
        for (b in prof.bindings) {
            if (b.mode == BindMode.OFF) continue
            val dx = b.x * width - x
            val dy = b.y * height - y
            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (dist < bestD) {
                bestD = dist
                best = b
            }
        }
        return best
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (width <= 0 || height <= 0) return true
        val fx = PadProfile.clamp01(ev.x / width)
        val fy = PadProfile.clamp01(ev.y / height)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val h = hit(ev.x, ev.y)
                if (h != null) {
                    dragging = h
                    onPick?.invoke(h.button)
                } else {
                    val s = selected ?: return true
                    val cur = prof.bindingFor(s)
                    dragging = if (cur == null) prof.set(s, BindMode.defaultFor(s), fx, fy)
                    else {
                        if (cur.mode == BindMode.OFF) cur.mode = BindMode.defaultFor(cur.button)
                        cur.x = fx
                        cur.y = fy
                        cur
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val dr = dragging
                if (dr != null) {
                    dr.x = fx
                    dr.y = fy
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging != null) {
                    dragging = null
                    onChange?.invoke()
                }
                invalidate()
            }
        }
        return true
    }
}
