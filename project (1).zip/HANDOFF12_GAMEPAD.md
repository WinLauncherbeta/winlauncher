# HANDOFF 12 — Mapeador de gamepad (WinLauncher 2.7.0 / code 19) — ETAPA 1 CONCLUÍDA NO CÓDIGO

NÃO compilado com Gradle/AGP e NÃO testado em aparelho. Verificação feita aqui:
- Lógica pura (PadModel, TouchPlanner, PadEngine): compilada com Kotlin 2.0.21 e 62 testes JVM, 0 falhas (tinha um erro real de assinatura JVM, corrigido).
- PadStore, PadMapperService e PadPanel: compilam contra stubs do Android escritos à mão (confere tipos e nomes, não o comportamento real).
- NÃO verificado por compilador: as duas linhas novas em CustomizeUi.kt e SettingsWindow.kt (só balanço de chaves).

## Plano em 4 etapas
1. Núcleo: serviço, captura de botões, injeção de toques, perfis, painel (ESTA etapa)
2. Editor visual em overlay sobre o jogo (arrastar pontos no jogo de verdade)
3. Analógicos (joystick virtual, câmera), gatilhos analógicos, turbo/macros, sensibilidade
4. Perfil automático ao abrir o jogo, botão flutuante liga/desliga, importar/exportar, polimento

## Arquivos
Novos (app/src/main/java/com/example/winlauncher): PadModel.kt, TouchPlanner.kt, PadEngine.kt, PadStore.kt, PadMapperService.kt, PadPanel.kt (inclui PadLayoutView); res/xml/pad_mapper_service.xml.
Modificados: AndroidManifest.xml (serviço), res/values/strings.xml (descrição), CustomizeUi.kt (rota "padmapper"), SettingsWindow.kt (linha em Jogos + ícone do tile não-xadrez), app/build.gradle.kts (2.7.0/19).
Não alterados: ShortcutService, Remote, MediaSessionHub, assinatura, package.

## Como usar
Configurações > Jogos > Mapeador de gamepad. Ativar "WinLauncher - mapeador de gamepad" em Acessibilidade. Novo perfil > escolher o jogo > escolher botão (ou apertá-lo no controle) > tocar na mini-tela para marcar o ponto; modo Toque rápido ou Segurar.

## Testar no aparelho (ordem)
1. Build do GitHub Actions compila (corrigir o que apontar).
2. Ativar o serviço; "Testar injeção de toque": o contador da área de teste deve subir. Se não subir, desligar e ligar o serviço (nova permissão de gestos).
3. Monitor: apertar botões do controle e ver os nomes aparecerem. Anotar botões que aparecem como "tecla N" (controle fora do padrão).
4. Perfil de um jogo real: o botão toca no ponto marcado? Segurar mantém o dedo? Dois botões ao mesmo tempo?
5. O botão do controle ainda chega ao jogo quando mapeado? (não deveria)
6. Voltar à launcher/trocar de app solta o toque?

## Limites conhecidos
- Analógicos e gatilhos analógicos não são teclas: Etapa 3. D-pad que o controle manda como eixo (hat) não chega: Etapa 3.
- O jogo da frente só é reconhecido na próxima troca de janela (abrir o jogo depois de ligar o serviço).
- Perfil de paisagem só vale com a tela em paisagem.
- Posicionamento é numa mini-tela (sem imagem do jogo): o overlay sobre o jogo é a Etapa 2.
- Um perfil por app. Toque rápido dura ~64 ms; toques novos esperam até 32 ms se outro dedo está na tela.
