package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.browse.MediaBrowser
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.media.MediaBrowserService

/**
 * Busca de músicas NO app que está tocando (YouTube Music, Spotify...), com lista de resultados (nome, artista e capa).
 *
 * Usa o serviço de navegação de mídia do próprio app ([MediaBrowser.search]). Cada app decide se deixa outro programa
 * usar esse serviço: alguns recusam (o Spotify, por exemplo, só libera apps conhecidos) e outros nem implementam busca.
 * Nesses casos o resultado é [Code.UNAVAILABLE] e o Remote cai na busca simples ("search" -> playFromSearch).
 *
 * Tudo roda na thread principal. [search] chama o retorno EXATAMENTE uma vez (também no tempo esgotado).
 */
object MediaSearch {

    enum class Code { OK, EMPTY, UNAVAILABLE, ERROR }

    /** Um resultado. [source] = origem da capa (iconBitmap ou iconUri), como na fila. */
    class Item(val mediaId: String, val title: String, val subtitle: String, val source: QueueArtSource?)

    class Outcome(val code: Code, val items: List<Item>)

    const val MAX_ITEMS = 10
    private const val MAX_MEDIA_ID = 128
    private const val TIMEOUT_MS = 8000L

    private val main = Handler(Looper.getMainLooper())
    private var current: Job? = null

    private class Job(val cb: (Outcome) -> Unit) {
        var browser: MediaBrowser? = null
        var done = false
        val timeout = Runnable { finish(this, Outcome(Code.ERROR, emptyList())) }
    }

    private fun finish(j: Job, o: Outcome) {
        if (j.done) return
        j.done = true
        main.removeCallbacks(j.timeout)
        try {
            j.browser?.disconnect()
        } catch (e: Throwable) {
        }
        if (current === j) current = null
        try {
            j.cb(o)
        } catch (e: Throwable) {
        }
    }

    fun search(ctx: Context, pkg: String, query: String, cb: (Outcome) -> Unit) {
        // uma busca por vez: a nova cancela a anterior (a anterior recebe ERROR e o chamador a ignora)
        current?.let { finish(it, Outcome(Code.ERROR, emptyList())) }
        val job = Job(cb)
        current = job
        val app = ctx.applicationContext
        val comp: ComponentName? = try {
            val i = Intent(MediaBrowserService.SERVICE_INTERFACE).setPackage(pkg)
            val ri = app.packageManager.queryIntentServices(i, 0).firstOrNull()
            ri?.serviceInfo?.let { ComponentName(it.packageName, it.name) }
        } catch (e: Throwable) {
            null
        }
        if (comp == null || pkg.isEmpty()) {
            finish(job, Outcome(Code.UNAVAILABLE, emptyList()))
            return
        }
        main.postDelayed(job.timeout, TIMEOUT_MS)
        try {
            val cbk = object : MediaBrowser.ConnectionCallback() {
                override fun onConnected() {
                    val b = job.browser
                    if (b == null || job.done) return
                    try {
                        b.search(query, Bundle(), object : MediaBrowser.SearchCallback() {
                            override fun onSearchResult(q: String, extras: Bundle?, items: MutableList<MediaBrowser.MediaItem>) {
                                finish(job, Outcome(if (items.isEmpty()) Code.EMPTY else Code.OK, convert(items)))
                            }

                            override fun onError(q: String, extras: Bundle?) {
                                // o app não implementa a busca (ou recusou)
                                finish(job, Outcome(Code.UNAVAILABLE, emptyList()))
                            }
                        })
                    } catch (e: Throwable) {
                        finish(job, Outcome(Code.ERROR, emptyList()))
                    }
                }

                override fun onConnectionFailed() = finish(job, Outcome(Code.UNAVAILABLE, emptyList()))
                override fun onConnectionSuspended() = finish(job, Outcome(Code.UNAVAILABLE, emptyList()))
            }
            val b = MediaBrowser(app, comp, cbk, null)
            job.browser = b
            b.connect()
        } catch (e: Throwable) {
            finish(job, Outcome(Code.UNAVAILABLE, emptyList()))
        }
    }

    private fun convert(items: List<MediaBrowser.MediaItem>): List<Item> {
        val out = ArrayList<Item>(minOf(items.size, MAX_ITEMS))
        for (mi in items) {
            if (out.size >= MAX_ITEMS) break
            val d = mi.description
            val id = d.mediaId ?: continue
            if (id.isEmpty() || id.length > MAX_MEDIA_ID) continue
            val title = d.title?.toString().orEmpty()
            if (title.isEmpty()) continue
            val bmp = try {
                d.iconBitmap
            } catch (e: Exception) {
                null
            }
            val uri = try {
                d.iconUri?.toString() ?: ""
            } catch (e: Exception) {
                ""
            }
            val usable = if (bmp != null && !bmp.isRecycled && bmp.width > 0 && bmp.height > 0) bmp else null
            val src = if (usable == null && uri.isEmpty()) {
                null
            } else {
                val key = if (usable != null) "b:" + id + "|" + title + "|" + usable.width + "x" + usable.height else "u:" + uri
                QueueArtSource(key, usable, if (usable != null) "" else uri)
            }
            out.add(Item(id, title, d.subtitle?.toString().orEmpty(), src))
        }
        return out
    }
}
