# HANDOFF 9 — busca com lista de resultados (WinLauncher 2.5.9)

Não compilado (sem Android SDK). Compilar pelo GitHub Actions.

- MediaSearch.kt (novo): conecta no MediaBrowserService do app que toca (MediaBrowser.search), devolve até 10 itens (id de mídia, título, subtítulo, origem da capa).
  Timeout 8 s. App que recusa a conexão ou não implementa busca = UNAVAILABLE (o Remote cai na busca simples).
- Manifesto: `<queries>` ganhou a intent android.media.browse.MediaBrowserService (necessário no Android 11+ para achar o serviço).
- RemoteProtocol: comandos `search_list` (query) e `play_result` (queueId = índice), mensagem `sres`, capacidade `search_list` em SERVER_CAPS, autotestes.
- RemoteBridge: startSearchList / publishSearchResults; capas dos resultados em um segundo QueueArtStore (`searchArt`), servidas por art_req/qart junto com as da fila.
- MediaSessionHub.playFromMediaId; MediaPort.playFromMediaId (padrão UNAVAILABLE).
- Só quem fez a busca consegue tocar os resultados dela (play_result); índice inexistente = unavailable.
