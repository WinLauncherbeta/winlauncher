package com.example.winlauncher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.util.DisplayMetrics
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Mapeador de gamepad (Etapa 1) - serviço de acessibilidade.
 *
 * Faz duas coisas, as duas só enquanto o usuário ligar "WinLauncher - mapeador de gamepad" em Acessibilidade:
 *  1. recebe as teclas do controle (o Android só entrega teclas ao app em primeiro plano; o filtro de teclas da
 *     acessibilidade é a única forma de ouvi-las em outro app) e repassa ao [PadEngine];
 *  2. injeta os toques na tela com dispatchGesture (ver [TouchPlanner] para o porquê dos "pedaços").
 *
 * É um serviço separado do [ShortcutService] de propósito: os atalhos de teclado já testados não são tocados.
 * Só teclas de CONTROLE são analisadas; teclado comum nunca é consumido nem registrado.
 */
class PadMapperService : AccessibilityService(), PadHost {

    companion object {
        /** true enquanto o serviço está ligado nas configurações do Android. */
        @Volatile
        var running = false

        @Volatile
        var instance: PadMapperService? = null

        /** Teclado, barra do sistema e o próprio app não contam como "o jogo que está na frente". */
        private val IGNORED_PKGS = setOf("android", "com.android.systemui", "com.android.permissioncontroller")

        /**
         * Toque de teste (painel): encosta em ([x],[y]) em pixels da tela. Devolve false se o serviço não está ligado.
         * Serve para provar, no aparelho, que a injeção de toques funciona.
         */
        fun testTap(x: Float, y: Float): Boolean {
            val s = instance ?: return false
            return s.injectTestTap(x, y)
        }

        /**
         * Etapa 2: abre o editor sobre o jogo para o perfil [p]. Devolve false se o serviço não está ligado ou se o
         * Android recusou as janelas.
         */
        fun openEditor(p: PadProfile): Boolean {
            val s = instance ?: return false
            return s.startEditor(p)
        }

        /** O editor sobre o jogo está aberto? */
        fun editorOpen(): Boolean = instance?.editor != null

        /**
         * Etapa 3: reavalia quem pode entregar os eixos (Android 14+: acessibilidade; abaixo: Shizuku autorizado).
         * O painel chama ao abrir, porque o usuário pode ter ligado o Shizuku depois.
         */
        fun refreshAxesSupport() {
            instance?.updateAxesSupport()
        }
    }

    // ---- estado da injeção (só thread principal)
    private val strokes = HashMap<Int, GestureDescription.StrokeDescription>()
    private var inFlight = false
    private var inFlightSince = 0L
    private var imePkgs: Set<String>? = null

    private val handler = Handler(Looper.getMainLooper())
    private val wake = Runnable { pump() }

    /** Editor sobre o jogo (Etapa 2); null = fechado. */
    private var editor: PadOverlayEditor? = null

    override fun onServiceConnected() {
        instance = this
        running = true
        PadStore.load(this)
        PadEngine.host = this
        updateAxesSupport()
        PadEngine.updateLauncherFront(VolumeButtonService.launcherForeground)
        PadEngine.onServiceState(true)
        PadEngine.refreshAxes()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun updateAxesSupport() {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                PadEngine.setAxesAvailability(true, "Acessibilidade")
            } else if (ShizukuBridge.state(this) == ShizukuBridge.State.GRANTED) {
                PadEngine.setAxesAvailability(true, "Shizuku")
            } else {
                PadAxisReader.stop()
                PadEngine.setAxesAvailability(false, null)
            }
        } catch (e: Exception) {
        }
    }

    private fun startEditor(p: PadProfile): Boolean {
        try {
            editor?.close()
        } catch (e: Exception) {
        }
        val e = PadOverlayEditor(this, p) { editor = null }
        editor = e
        val ok = e.show()
        if (!ok) editor = null
        return ok
    }

    private fun shutdown() {
        try {
            editor?.close()
        } catch (e: Exception) {
        }
        editor = null
        handler.removeCallbacks(wake)
        PadAxisReader.stop()
        running = false
        if (instance === this) instance = null
        strokes.clear()
        inFlight = false
        if (PadEngine.host === this) PadEngine.host = null
        PadEngine.onServiceState(false)
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------ entrada

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        try {
            PadEngine.updateLauncherFront(VolumeButtonService.launcherForeground)
            val pkg = event.packageName?.toString() ?: return
            // janelas do próprio WinLauncher (inclusive a barra flutuante) não mudam o "jogo da frente"
            if (pkg == packageName || pkg in IGNORED_PKGS || isKeyboardPkg(pkg)) return
            PadEngine.onForeground(pkg)
            // Android 13-: o Shizuku pode ter sido ligado/autorizado depois; confere a cada troca de app
            if (Build.VERSION.SDK_INT < 34) updateAxesSupport()
        } catch (e: Exception) {
        }
    }

    private fun isKeyboardPkg(pkg: String): Boolean {
        var set = imePkgs
        if (set == null) {
            set = try {
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.enabledInputMethodList.map { it.packageName }.toSet()
            } catch (e: Exception) {
                emptySet()
            }
            imePkgs = set
        }
        return pkg in set!!
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        return try {
            val code = event.keyCode
            val src = event.source
            val padSrc = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            // BUTTON_A.. só existem em controle; as setas só contam se vierem de um controle (não do teclado)
            val fromPad = PadButton.isPadOnlyKey(code) || padSrc
            if (!fromPad) return false
            PadEngine.updateLauncherFront(VolumeButtonService.launcherForeground)
            PadEngine.onKey(
                PadKey(
                    code, event.action == KeyEvent.ACTION_DOWN, event.repeatCount,
                    event.device?.name ?: "", true, SystemClock.uptimeMillis()
                )
            )
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------ eixos (Etapa 3, Android 14+)

    /** Eixos do controle. Só chegam depois de [setAxesWanted] (e só no Android 14+). */
    override fun onMotionEvent(event: MotionEvent) {
        try {
            if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return
            val z = event.getAxisValue(MotionEvent.AXIS_Z)
            val rz = event.getAxisValue(MotionEvent.AXIS_RZ)
            val rxa = event.getAxisValue(MotionEvent.AXIS_RX)
            val rya = event.getAxisValue(MotionEvent.AXIS_RY)
            // analógico direito: Z/RZ na maioria dos controles, RX/RY em alguns; vale o que estiver mais inclinado
            val useZ = (z * z + rz * rz) >= (rxa * rxa + rya * rya)
            PadEngine.onAxes(
                PadAxes(
                    event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
                    if (useZ) z else rxa, if (useZ) rz else rya,
                    Math.max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE)),
                    Math.max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS)),
                    event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y),
                    event.device?.name ?: "", SystemClock.uptimeMillis()
                )
            )
        } catch (e: Exception) {
        }
    }

    override fun setAxesWanted(on: Boolean) {
        if (Build.VERSION.SDK_INT < 34) {
            // Android 13 ou menor: lê o controle por getevent (Shizuku); desliga quando ninguém precisa
            if (on) PadAxisReader.start(this) else PadAxisReader.stop()
            return
        }
        try {
            val info = serviceInfo ?: return
            info.motionEventSources = if (on) InputDevice.SOURCE_JOYSTICK else 0
            serviceInfo = info
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ PadHost

    override fun screenWidth(): Int = realSize().first

    override fun screenHeight(): Int = realSize().second

    private fun realSize(): Pair<Int, Int> {
        return try {
            val dm = DisplayMetrics()
            val d = (getSystemService(android.content.Context.DISPLAY_SERVICE) as DisplayManager)
                .getDisplay(Display.DEFAULT_DISPLAY)
            @Suppress("DEPRECATION")
            d.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        } catch (e: Exception) {
            val m = resources.displayMetrics
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    // ------------------------------------------------------------ injeção

    /** Despacha o próximo pedaço, se nenhum estiver em andamento. */
    override fun pump() {
        try {
            val now = SystemClock.uptimeMillis()
            if (inFlight) {
                // trava de segurança: se o Android nunca devolveu o resultado, não deixa a entrada morrer para sempre
                if (now - inFlightSince < 1000L) return
                lost("sem resposta do Android")
            }
            val planner = PadEngine.planner
            if (!planner.hasWork()) return
            val segs = planner.nextChunk(now)
            if (segs.isEmpty()) {
                // turbo entre dois toques: volta a olhar quando for a hora do próximo
                handler.removeCallbacks(wake)
                val dl = planner.nextWakeDelay(now)
                if (dl >= 0L) handler.postDelayed(wake, dl)
                return
            }
            dispatch(segs, planner.chunkMs)
        } catch (e: Exception) {
            lost("erro ao injetar: " + e.javaClass.simpleName)
        }
    }

    private fun dispatch(segs: List<TouchPlanner.Seg>, chunkMs: Long) {
        val b = GestureDescription.Builder()
        for (s in segs) {
            val path = Path()
            path.moveTo(s.fromX, s.fromY)
            if (s.toX != s.fromX || s.toY != s.fromY) path.lineTo(s.toX, s.toY)
            val prev = strokes[s.id]
            val stroke = if (s.begin || prev == null) {
                GestureDescription.StrokeDescription(path, 0L, chunkMs, !s.end)
            } else {
                prev.continueStroke(path, 0L, chunkMs, !s.end)
            }
            if (s.end) strokes.remove(s.id) else strokes[s.id] = stroke
            b.addStroke(stroke)
        }
        inFlight = true
        inFlightSince = SystemClock.uptimeMillis()
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                inFlight = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                lost("gesto cancelado pelo Android")
            }
        }, null)
        if (!ok) lost("o Android recusou o gesto")
    }

    private fun lost(reason: String) {
        inFlight = false
        strokes.clear()
        PadEngine.onInjectionLost(reason)
    }

    /** Toque único de teste. Não passa pelo planejador (não mexe nos botões do controle). */
    private fun injectTestTap(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }
}
