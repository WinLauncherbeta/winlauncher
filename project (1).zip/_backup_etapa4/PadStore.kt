package com.example.winlauncher

import android.content.Context
import java.io.File

/**
 * Mapeador de gamepad (Etapa 1) - guarda os perfis em `pad_profiles.json` (pasta interna do app).
 * O serviço de acessibilidade e o painel rodam no mesmo processo e compartilham esta lista.
 * Só a thread principal mexe nela.
 */
object PadStore {
    private const val FILE = "pad_profiles.json"

    val profiles = ArrayList<PadProfile>()
    private var loaded = false

    /** Último erro de leitura/gravação (aparece no painel). */
    var lastError: String? = null
        private set

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, FILE)

    /** Lê o arquivo uma vez por processo. [force] = relê. */
    fun load(ctx: Context, force: Boolean = false) {
        if (loaded && !force) return
        try {
            val f = file(ctx)
            val text = if (f.exists()) f.readText(Charsets.UTF_8) else null
            val parsed = PadJson.read(text)
            profiles.clear()
            profiles.addAll(parsed.profiles)
            PadEngine.masterOn = parsed.on
            lastError = null
        } catch (e: Exception) {
            lastError = "Não foi possível ler os perfis: " + e.javaClass.simpleName
        }
        loaded = true
        PadEngine.profiles = profiles
        PadEngine.refreshAxes()
    }

    /** Grava (atomicamente: arquivo temporário + renomear) e avisa o motor. */
    fun save(ctx: Context) {
        PadEngine.profiles = profiles
        PadEngine.refreshAxes()
        try {
            val f = file(ctx)
            val tmp = File(f.parentFile, FILE + ".tmp")
            tmp.writeText(PadJson.write(PadEngine.masterOn, profiles), Charsets.UTF_8)
            if (!tmp.renameTo(f)) {
                f.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8)
                tmp.delete()
            }
            lastError = null
        } catch (e: Exception) {
            lastError = "Não foi possível salvar os perfis: " + e.javaClass.simpleName
        }
    }

    fun profileFor(pkg: String): PadProfile? = profiles.firstOrNull { it.pkg == pkg }

    /** Perfil existente do app ou um novo (já na lista, ainda sem botões). */
    fun getOrCreate(ctx: Context, pkg: String, name: String): PadProfile {
        profileFor(pkg)?.let { return it }
        val p = PadProfile(java.lang.Long.toString(System.currentTimeMillis(), 36), pkg, name)
        profiles.add(p)
        save(ctx)
        return p
    }

    fun delete(ctx: Context, p: PadProfile) {
        profiles.remove(p)
        save(ctx)
    }

    fun setMaster(ctx: Context, on: Boolean) {
        PadEngine.masterOn = on
        if (!on) PadEngine.releaseAll()
        save(ctx)
    }
}
