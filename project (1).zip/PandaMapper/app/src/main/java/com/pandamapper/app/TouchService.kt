package com.pandamapper.app

import android.os.Process
import kotlin.system.exitProcess

/**
 * UserService do Shizuku: esta classe é carregada pelo Shizuku em um processo separado
 * (uid shell = 2000 ou root = 0), onde é permitido injetar eventos de entrada.
 * Precisa ter construtor sem argumentos e NÃO usar Context do app.
 */
class TouchService : IPanda.Stub() {

    private val injector = TouchInjector()

    override fun destroy() {
        try {
            injector.releaseAll()
        } catch (t: Throwable) {
        }
        exitProcess(0)
    }

    override fun touchDown(id: Int, x: Float, y: Float) {
        try {
            injector.down(id, x, y)
        } catch (t: Throwable) {
        }
    }

    override fun touchMove(id: Int, x: Float, y: Float) {
        try {
            injector.move(id, x, y)
        } catch (t: Throwable) {
        }
    }

    override fun touchUp(id: Int) {
        try {
            injector.up(id)
        } catch (t: Throwable) {
        }
    }

    override fun touchMoveMany(ids: IntArray?, xs: FloatArray?, ys: FloatArray?) {
        if (ids == null || xs == null || ys == null) return
        try {
            injector.moveMany(ids, xs, ys)
        } catch (t: Throwable) {
        }
    }

    override fun releaseAll() {
        try {
            injector.releaseAll()
        } catch (t: Throwable) {
        }
    }

    override fun echo(v: Long): Long = v

    override fun info(): String {
        val sb = StringBuilder()
        sb.append("uid=").append(Process.myUid()).append(" pid=").append(Process.myPid())
        sb.append("\ninjeção: ").append(if (injector.ready()) "pronta via ${injector.strategy}" else "INDISPONÍVEL")
        sb.append("\neventos injetados: ").append(injector.injected)
        injector.lastError?.let { sb.append("\núltimo erro: ").append(it) }
        return sb.toString()
    }

    override fun benchInject(n: Int, x: Float, y: Float): Long = try {
        injector.bench(n.coerceIn(1, 2000), x, y)
    } catch (t: Throwable) {
        -1L
    }
}
