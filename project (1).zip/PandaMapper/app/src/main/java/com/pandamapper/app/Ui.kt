package com.pandamapper.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Auxiliares de interface (Views programáticas, sem XML de layout). */
object Ui {
    val BG = Color.parseColor("#0F1311")
    val CARD = Color.parseColor("#19201C")
    val ACCENT = Color.parseColor("#4ADE80")
    val TEXT = Color.parseColor("#ECF2EE")
    val MUTED = Color.parseColor("#93A39A")
    val WARN = Color.parseColor("#F5B94A")
    val BAD = Color.parseColor("#F26B6B")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun roundRect(color: Int, radiusDp: Int, c: Context): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun card(c: Context, parent: LinearLayout): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = roundRect(CARD, 16, c)
        val p = dp(c, 16)
        l.setPadding(p, p, p, p)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(c, 12)
        parent.addView(l, lp)
        return l
    }

    fun title(c: Context, parent: LinearLayout, text: String): TextView =
        text(c, parent, text, 16f, TEXT, bold = true)

    fun text(
        c: Context, parent: LinearLayout, text: String, sizeSp: Float = 14f,
        color: Int = TEXT, bold: Boolean = false, topDp: Int = 4
    ): TextView {
        val t = TextView(c)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(c, topDp)
        parent.addView(t, lp)
        return t
    }

    fun mono(c: Context, parent: LinearLayout): TextView {
        val t = text(c, parent, "", 12f, MUTED, topDp = 8)
        t.typeface = Typeface.MONOSPACE
        t.visibility = View.GONE
        return t
    }

    fun button(c: Context, parent: LinearLayout, label: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(if (primary) Color.parseColor("#06210F") else TEXT)
        b.background = roundRect(if (primary) ACCENT else Color.parseColor("#26322B"), 12, c)
        b.gravity = Gravity.CENTER
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 46))
        lp.topMargin = dp(c, 8)
        parent.addView(b, lp)
        return b
    }
}
