package com.pandamapper.app

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

/**
 * Motor de injeção: monta MotionEvent de multitoque e injeta no sistema.
 * Roda DENTRO do processo do Shizuku (uid shell/root), que tem a permissão INJECT_EVENTS.
 * Não pode depender de Context/Activity do app.
 */
class TouchInjector {

    private class P(val id: Int, var x: Float, var y: Float)

    private val pts = ArrayList<P>()
    private var downTime = 0L

    private var target: Any? = null
    private var method: Method? = null

    /** Qual caminho de injeção funcionou (diagnóstico). */
    var strategy: String = "nenhuma"
        private set

    @Volatile
    var lastError: String? = null
        private set

    @Volatile
    var injected: Long = 0
        private set

    private val props = Array(MAX) { MotionEvent.PointerProperties() }
    private val coords = Array(MAX) { MotionEvent.PointerCoords() }

    init {
        setup()
    }

    // ---------- API pública (thread-safe) ----------

    @Synchronized
    fun down(id: Int, x: Float, y: Float) {
        val ex = find(id)
        if (ex != null) {
            ex.x = x
            ex.y = y
            send(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis())
            return
        }
        if (pts.size >= MAX) return
        val now = SystemClock.uptimeMillis()
        val first = pts.isEmpty()
        if (first) downTime = now
        pts.add(P(id, x, y))
        val idx = pts.size - 1
        val action = if (first) MotionEvent.ACTION_DOWN
        else MotionEvent.ACTION_POINTER_DOWN or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        send(action, now)
    }

    @Synchronized
    fun move(id: Int, x: Float, y: Float) {
        val p = find(id) ?: return
        p.x = x
        p.y = y
        send(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis())
    }

    @Synchronized
    fun moveMany(ids: IntArray, xs: FloatArray, ys: FloatArray) {
        var changed = false
        val n = minOf(ids.size, xs.size, ys.size)
        for (i in 0 until n) {
            val p = find(ids[i]) ?: continue
            p.x = xs[i]
            p.y = ys[i]
            changed = true
        }
        if (changed) send(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis())
    }

    @Synchronized
    fun up(id: Int) {
        val idx = indexOf(id)
        if (idx < 0) return
        val now = SystemClock.uptimeMillis()
        val action = if (pts.size == 1) MotionEvent.ACTION_UP
        else MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        send(action, now)
        pts.removeAt(idx)
    }

    @Synchronized
    fun releaseAll() {
        while (pts.isNotEmpty()) up(pts[pts.size - 1].id)
    }

    @Synchronized
    fun bench(n: Int, x: Float, y: Float): Long {
        releaseAll()
        down(0, x, y)
        val t0 = System.nanoTime()
        for (i in 0 until n) move(0, x + (i and 1), y)
        val total = System.nanoTime() - t0
        up(0)
        return total
    }

    fun ready(): Boolean = method != null

    // ---------- Internos ----------

    private fun find(id: Int): P? {
        for (p in pts) if (p.id == id) return p
        return null
    }

    private fun indexOf(id: Int): Int {
        for (i in pts.indices) if (pts[i].id == id) return i
        return -1
    }

    private fun send(action: Int, now: Long) {
        val m = method
        val t = target
        if (m == null || t == null) return
        val n = pts.size
        for (i in 0 until n) {
            val p = pts[i]
            props[i].clear()
            props[i].id = p.id
            props[i].toolType = MotionEvent.TOOL_TYPE_FINGER
            coords[i].clear()
            coords[i].x = p.x
            coords[i].y = p.y
            coords[i].pressure = 1f
            coords[i].size = 1f
        }
        val ev = MotionEvent.obtain(
            downTime, now, action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            // modo 0 = assíncrono (não espera o sistema processar)
            val ok = m.invoke(t, ev, 0) as? Boolean
            if (ok == false) lastError = "O sistema recusou o evento"
            injected++
        } catch (e: Throwable) {
            lastError = describe(e)
        } finally {
            ev.recycle()
        }
    }

    private fun setup() {
        val errs = StringBuilder()
        val attempts: List<Pair<String, () -> Pair<Any, Method>>> = listOf(
            "InputManagerGlobal" to { viaGetInstance("android.hardware.input.InputManagerGlobal") },
            "InputManager" to { viaGetInstance("android.hardware.input.InputManager") },
            "IInputManager" to { viaBinder() }
        )
        for ((name, f) in attempts) {
            try {
                val (t, m) = f()
                target = t
                method = m
                strategy = name
                return
            } catch (e: Throwable) {
                errs.append(name).append(": ").append(describe(e)).append("; ")
            }
        }
        lastError = "Nenhum caminho de injeção funcionou ($errs)"
    }

    private fun viaGetInstance(className: String): Pair<Any, Method> {
        val cls = Class.forName(className)
        val gi = cls.getDeclaredMethod("getInstance")
        gi.isAccessible = true
        val inst = gi.invoke(null) ?: throw IllegalStateException("getInstance devolveu nulo")
        val m = cls.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType!!)
        m.isAccessible = true
        return Pair(inst, m)
    }

    private fun viaBinder(): Pair<Any, Method> {
        val sm = Class.forName("android.os.ServiceManager")
        val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as IBinder
        val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
        val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            ?: throw IllegalStateException("asInterface devolveu nulo")
        val iface = Class.forName("android.hardware.input.IInputManager")
        val m = iface.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType!!)
        m.isAccessible = true
        return Pair(svc, m)
    }

    private fun describe(t: Throwable): String {
        val c = (t as? InvocationTargetException)?.targetException ?: t
        return c.javaClass.simpleName + (c.message?.let { ": $it" } ?: "")
    }

    companion object {
        const val MAX = 10
    }
}
