package com.pandamapper.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.LinearLayout.LayoutParams
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.sin

/**
 * Etapa 1: base + Shizuku. Etapa 2: motor de toques (UserService) com testes de multitoque e latência.
 */
class MainActivity : Activity() {

    private lateinit var shizukuStatus: TextView
    private lateinit var shizukuHint: TextView
    private lateinit var testOut: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var engineStatus: TextView
    private lateinit var engineOut: TextView
    private lateinit var testView: TouchTestView
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        buildUi()
        ShizukuBridge.addListeners()
        ShizukuBridge.onChange = { runOnUiThread { refresh() } }
        TouchEngine.onChange = { runOnUiThread { refresh() } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        ShizukuBridge.onChange = null
        TouchEngine.onChange = null
        TouchEngine.releaseAll()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        val c = this
        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(c, 16)
        root.setPadding(pad, pad * 2, pad, pad)

        Ui.text(c, root, "Panda Mapper", 26f, Ui.TEXT, bold = true)
        Ui.text(c, root, "Etapa 2 de 7 · motor de toques", 13f, Ui.ACCENT, topDp = 2)
        Ui.text(c, root, "Mapeia teclado, mouse e controle em toques na tela, com o Shizuku para injetar os toques sem root.", 13f, Ui.MUTED, topDp = 6)
        Ui.text(c, root, "", 4f)

        // --- Shizuku ---
        val k = Ui.card(c, root)
        Ui.title(c, k, "Shizuku")
        shizukuStatus = Ui.text(c, k, "...", 14f, Ui.TEXT, topDp = 6)
        shizukuHint = Ui.text(c, k, "", 12f, Ui.MUTED, topDp = 4)
        Ui.button(c, k, "Solicitar autorização", primary = true) {
            if (!ShizukuBridge.request()) {
                toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → Panda Mapper.")
            }
            refresh()
        }
        Ui.button(c, k, "Abrir Shizuku") {
            if (!ShizukuBridge.open(this)) toast("Shizuku não encontrado")
        }
        Ui.button(c, k, "Atualizar estado") { refresh() }

        // --- Motor de toques (Etapa 2) ---
        val e = Ui.card(c, root)
        Ui.title(c, e, "Motor de toques")
        Ui.text(c, e, "Serviço que roda dentro do Shizuku e injeta toques com vários dedos ao mesmo tempo. É ele que as próximas etapas vão usar.", 12f, Ui.MUTED, topDp = 4)
        engineStatus = Ui.text(c, e, "...", 14f, Ui.TEXT, topDp = 8)
        Ui.button(c, e, "Conectar motor", primary = true) { TouchEngine.connect(this) }
        Ui.button(c, e, "Desconectar motor") { TouchEngine.disconnect() }
        Ui.button(c, e, "Info do motor") { engineInfo() }
        testView = TouchTestView(c)
        val tlp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 220))
        tlp.topMargin = Ui.dp(c, 12)
        e.addView(testView, tlp)
        Ui.button(c, e, "Teste: 2 dedos") { runFingers(2) }
        Ui.button(c, e, "Teste: 5 dedos") { runFingers(5) }
        Ui.button(c, e, "Medir latência") { measureLatency() }
        Ui.button(c, e, "Soltar todos os toques") {
            TouchEngine.releaseAll()
            toast("Toques soltos")
        }
        engineOut = Ui.mono(c, e)

        // --- Testes ---
        val t = Ui.card(c, root)
        Ui.title(c, t, "Diagnóstico (Etapa 1)")
        Ui.text(c, t, "Confirmam que o Shizuku deste aparelho consegue rodar comandos e enviar toques.  O motor de toques acima é o caminho rápido; estes ficam só para diagnóstico.", 12f, Ui.MUTED, topDp = 4)
        Ui.button(c, t, "Testar privilégio (comando id)") { testId() }
        Ui.button(c, t, "Testar toque no centro da tela") { testTap() }
        testOut = Ui.mono(c, t)

        // --- Permissão de sobreposição ---
        val o = Ui.card(c, root)
        Ui.title(c, o, "Sobreposição sobre outros apps")
        overlayStatus = Ui.text(c, o, "...", 14f, Ui.TEXT, topDp = 6)
        Ui.text(c, o, "Necessária a partir da Etapa 4, para mostrar os botões do mapeamento por cima do jogo.", 12f, Ui.MUTED, topDp = 4)
        Ui.button(c, o, "Abrir configuração de sobreposição") {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                toast("Não foi possível abrir a configuração")
            }
        }

        // --- Roadmap ---
        val r = Ui.card(c, root)
        Ui.title(c, r, "Roteiro das 7 etapas")
        for ((i, s) in ROADMAP.withIndex()) {
            val n = i + 1
            val done = n <= CURRENT_STAGE
            Ui.text(c, r, (if (done) "✔ " else "○ ") + "Etapa $n — " + s.first, 14f, if (done) Ui.ACCENT else Ui.TEXT, bold = true, topDp = 10)
            Ui.text(c, r, s.second, 12f, Ui.MUTED, topDp = 2)
        }

        val sv = ScrollView(c)
        sv.setBackgroundColor(Ui.BG)
        sv.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)
    }

    private fun refresh() {
        val st = ShizukuBridge.state(this)
        val who = when (ShizukuBridge.uid()) {
            0 -> " (root)"
            2000 -> " (ADB/shell)"
            else -> ""
        }
        shizukuStatus.text = "Estado: " + when (st) {
            ShizukuBridge.State.NOT_INSTALLED -> "não instalado"
            ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
            ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente$who"
            ShizukuBridge.State.GRANTED -> "conectado e autorizado$who"
            ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
        }
        shizukuStatus.setTextColor(
            when (st) {
                ShizukuBridge.State.GRANTED -> Ui.ACCENT
                ShizukuBridge.State.NEEDS_PERMISSION -> Ui.WARN
                else -> Ui.BAD
            }
        )
        shizukuHint.text = when (st) {
            ShizukuBridge.State.GRANTED -> "Tudo certo. Pode rodar os testes abaixo."
            ShizukuBridge.State.NEEDS_PERMISSION -> "Toque em \"Solicitar autorização\" e aceite o pedido do Shizuku."
            ShizukuBridge.State.NOT_RUNNING -> "Abra o Shizuku e toque em iniciar (Depuração sem fio ou ADB). Depois volte aqui."
            ShizukuBridge.State.NOT_INSTALLED -> "Instale e inicie o Shizuku para o app poder injetar toques."
            ShizukuBridge.State.UNSUPPORTED -> "Atualize o Shizuku para a versão mais recente."
        }
        engineStatus.text = "Motor: " + when (TouchEngine.state) {
            TouchEngine.State.OFF -> "desconectado"
            TouchEngine.State.CONNECTING -> "conectando..."
            TouchEngine.State.ON -> "conectado"
            TouchEngine.State.ERROR -> "com erro"
        } + (TouchEngine.error?.let { "\n$it" } ?: "")
        engineStatus.setTextColor(
            when (TouchEngine.state) {
                TouchEngine.State.ON -> Ui.ACCENT
                TouchEngine.State.CONNECTING -> Ui.WARN
                TouchEngine.State.ERROR -> Ui.BAD
                else -> Ui.MUTED
            }
        )
        overlayStatus.text = if (Settings.canDrawOverlays(this)) "Permitida" else "Ainda não permitida"
        overlayStatus.setTextColor(if (Settings.canDrawOverlays(this)) Ui.ACCENT else Ui.WARN)
    }

    private fun requireGranted(): Boolean {
        if (ShizukuBridge.state(this) == ShizukuBridge.State.GRANTED) return true
        toast("Primeiro autorize o Shizuku")
        return false
    }

    private fun showOut(s: String) {
        runOnUiThread {
            testOut.text = s
            testOut.visibility = android.view.View.VISIBLE
        }
    }

    private fun testId() {
        if (!requireGranted()) return
        showOut("Rodando...")
        io.execute {
            val out = ShizukuBridge.sh("id")
            showOut(out?.trim() ?: ("Falhou: " + (ShizukuBridge.lastError ?: "sem detalhes")))
        }
    }

    private fun testTap() {
        if (!requireGranted()) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2
        val y = dm.heightPixels / 2
        showOut("Enviando toque em ($x, $y)...")
        io.execute {
            val t0 = System.nanoTime()
            val out = ShizukuBridge.sh("input tap $x $y")
            val ms = (System.nanoTime() - t0) / 1_000_000
            showOut(
                if (out == null) "Falhou: " + (ShizukuBridge.lastError ?: "sem detalhes")
                else "Toque enviado em ($x, $y) · ${ms} ms" + (if (out.isNotBlank()) "\n" + out.trim() else "")
            )
        }
    }

    // ---------- Motor de toques ----------

    private fun requireEngine(): Boolean {
        if (TouchEngine.state == TouchEngine.State.ON && TouchEngine.service != null) return true
        toast("Conecte o motor primeiro")
        return false
    }

    private fun showEngineOut(s: String) {
        runOnUiThread {
            engineOut.text = s
            engineOut.visibility = android.view.View.VISIBLE
        }
    }

    private fun engineInfo() {
        if (!requireEngine()) return
        showEngineOut("Consultando...")
        io.execute {
            val s = try {
                TouchEngine.service?.info() ?: "sem serviço"
            } catch (t: Throwable) {
                "Falhou: " + t.javaClass.simpleName + (t.message?.let { ": $it" } ?: "")
            }
            showEngineOut(s)
        }
    }

    /** Move n dedos ao mesmo tempo dentro da área de teste e confere o que chegou. */
    private fun runFingers(n: Int) {
        if (!requireEngine()) return
        val loc = IntArray(2)
        testView.getLocationOnScreen(loc)
        val left = loc[0].toFloat()
        val top = loc[1].toFloat()
        val w = testView.width.toFloat()
        val h = testView.height.toFloat()
        testView.resetStats()
        showEngineOut("Enviando $n dedos...")
        io.execute {
            val ids = IntArray(n) { it }
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            for (i in 0 until n) {
                TouchEngine.down(i, left + w * (i + 1) / (n + 1), top + h * 0.2f)
                Thread.sleep(15)
            }
            val steps = 80
            for (s in 1..steps) {
                val t = s / steps.toFloat()
                for (i in 0 until n) {
                    val bx = left + w * (i + 1) / (n + 1)
                    xs[i] = bx + sin(t * 6.2832f) * w * 0.04f
                    ys[i] = top + h * (if (i % 2 == 0) 0.2f + 0.6f * t else 0.8f - 0.6f * t)
                }
                TouchEngine.moveMany(ids, xs, ys)
                Thread.sleep(10)
            }
            for (i in n - 1 downTo 0) {
                TouchEngine.up(i)
                Thread.sleep(15)
            }
            Thread.sleep(300)
            runOnUiThread {
                val ok = testView.maxPointers >= n
                showEngineOut(
                    (if (ok) "OK: chegaram $n dedos juntos.\n" else "ATENÇÃO: esperava $n dedos juntos, chegaram ${testView.maxPointers}.\n") +
                        testView.statsText()
                )
            }
        }
    }

    private fun measureLatency() {
        if (!requireEngine()) return
        val loc = IntArray(2)
        testView.getLocationOnScreen(loc)
        val cx = loc[0] + testView.width / 2f
        val cy = loc[1] + testView.height / 2f
        testView.resetStats()
        showEngineOut("Medindo...")
        io.execute {
            val svc = TouchEngine.service
            if (svc == null) {
                showEngineOut("Motor desconectado")
                return@execute
            }
            try {
                repeat(30) { svc.echo(0L) }
                val rtt = LongArray(300)
                for (i in rtt.indices) {
                    val t0 = System.nanoTime()
                    svc.echo(t0)
                    rtt[i] = System.nanoTime() - t0
                }
                rtt.sort()
                val med = rtt[rtt.size / 2] / 1000.0
                val p95 = rtt[rtt.size * 95 / 100] / 1000.0
                val total = svc.benchInject(200, cx, cy)
                Thread.sleep(300)
                runOnUiThread {
                    val inj = if (total < 0) "falhou" else "%.0f µs por evento".format(total / 200.0 / 1000.0)
                    showEngineOut(
                        "Ida e volta ao serviço: mediana %.0f µs · p95 %.0f µs\n".format(med, p95) +
                            "Custo de injetar (no serviço): $inj\n" +
                            testView.statsText()
                    )
                }
            } catch (t: Throwable) {
                showEngineOut("Falhou: " + t.javaClass.simpleName + (t.message?.let { ": $it" } ?: ""))
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    companion object {
        const val CURRENT_STAGE = 2

        val ROADMAP: List<Pair<String, String>> = listOf(
            "Base e Shizuku" to "Projeto, estado/autorização do Shizuku, testes de comando e de toque.",
            "Motor de toques" to "Serviço do Shizuku (UserService) injetando MotionEvent com multitoque e baixa latência.",
            "Captura de entrada" to "Ler teclado, mouse e controle físicos e entregar ao motor, sem atrapalhar o jogo.",
            "Editor de mapeamento" to "Botões sobre a tela: toque, segurar, joystick, câmera, deslize. Arrastar, redimensionar, salvar.",
            "Execução do mapeamento" to "Tecla → toque, WASD → joystick virtual, mouse → câmera, sensibilidade.",
            "Perfis por jogo" to "Troca automática pelo app em primeiro plano, importar/exportar, modelos prontos.",
            "Acabamento" to "Botão flutuante, notificação, tutorial, desempenho, build final e documentação."
        )
    }
}
