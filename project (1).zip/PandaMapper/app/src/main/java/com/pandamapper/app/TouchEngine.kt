package com.pandamapper.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import rikka.shizuku.Shizuku

/**
 * Lado do app do motor de toques: conecta ao TouchService (via Shizuku UserService)
 * e expõe down/move/up com id de dedo. As chamadas são "oneway": não bloqueiam.
 */
object TouchEngine {
    enum class State { OFF, CONNECTING, ON, ERROR }

    /** Aumente quando mudar o serviço: o Shizuku reinicia o processo se a versão mudar. */
    private const val SERVICE_VERSION = 2

    @Volatile
    var state: State = State.OFF
        private set

    @Volatile
    var error: String? = null
        private set

    @Volatile
    var service: IPanda? = null
        private set

    @Volatile
    var onChange: (() -> Unit)? = null

    private var args: Shizuku.UserServiceArgs? = null
    private val main = Handler(Looper.getMainLooper())

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                service = IPanda.Stub.asInterface(binder)
                state = State.ON
                error = null
            } else {
                service = null
                state = State.ERROR
                error = "O serviço devolveu uma conexão inválida"
            }
            onChange?.invoke()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            if (state == State.ON || state == State.CONNECTING) {
                state = State.OFF
                error = "Serviço desconectado (o Shizuku parou?)"
            }
            onChange?.invoke()
        }
    }

    fun connect(ctx: Context) {
        if (state == State.ON || state == State.CONNECTING) return
        if (ShizukuBridge.state(ctx) != ShizukuBridge.State.GRANTED) {
            state = State.ERROR
            error = "Autorize o Shizuku primeiro"
            onChange?.invoke()
            return
        }
        try {
            val a = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, TouchService::class.java.name))
                .daemon(false)
                .processNameSuffix("touch")
                .version(SERVICE_VERSION)
            args = a
            state = State.CONNECTING
            error = null
            Shizuku.bindUserService(a, conn)
            // se não conectar em 10 s, avisa
            main.postDelayed({
                if (state == State.CONNECTING) {
                    state = State.ERROR
                    error = "Tempo esgotado ao iniciar o serviço. Confira se o Shizuku está ativo e tente de novo."
                    onChange?.invoke()
                }
            }, 10_000)
        } catch (t: Throwable) {
            state = State.ERROR
            error = t.javaClass.simpleName + (t.message?.let { ": $it" } ?: "")
        }
        onChange?.invoke()
    }

    fun disconnect() {
        try {
            service?.releaseAll()
        } catch (t: Throwable) {
        }
        try {
            args?.let { Shizuku.unbindUserService(it, conn, true) }
        } catch (t: Throwable) {
        }
        service = null
        state = State.OFF
        error = null
        onChange?.invoke()
    }

    fun down(id: Int, x: Float, y: Float) = call { it.touchDown(id, x, y) }
    fun move(id: Int, x: Float, y: Float) = call { it.touchMove(id, x, y) }
    fun up(id: Int) = call { it.touchUp(id) }
    fun moveMany(ids: IntArray, xs: FloatArray, ys: FloatArray) = call { it.touchMoveMany(ids, xs, ys) }
    fun releaseAll() = call { it.releaseAll() }

    private inline fun call(block: (IPanda) -> Unit) {
        val s = service ?: return
        try {
            block(s)
        } catch (t: Throwable) {
            error = "Falha ao falar com o serviço: " + t.javaClass.simpleName
        }
    }
}
