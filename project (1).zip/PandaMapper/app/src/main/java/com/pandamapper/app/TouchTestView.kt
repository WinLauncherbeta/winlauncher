package com.pandamapper.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

/** Área de teste: desenha os dedos que chegam (injetados ou reais) e mede quantos/qual atraso. */
class TouchTestView(ctx: Context) : View(ctx) {

    private val active = LinkedHashMap<Int, PointF>()
    private val bg = Paint().apply { color = Color.parseColor("#0B0F0D") }
    private val border = Paint().apply {
        color = Color.parseColor("#26322B")
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(ctx, 2).toFloat()
    }
    private val dot = Paint().apply { isAntiAlias = true }
    private val label = Paint().apply {
        isAntiAlias = true
        color = Color.parseColor("#06210F")
        textSize = Ui.dp(ctx, 14).toFloat()
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val hint = Paint().apply {
        isAntiAlias = true
        color = Ui.MUTED
        textSize = Ui.dp(ctx, 13).toFloat()
        textAlign = Paint.Align.CENTER
    }
    private val colors = intArrayOf(
        Color.parseColor("#4ADE80"), Color.parseColor("#60A5FA"), Color.parseColor("#F5B94A"),
        Color.parseColor("#F472B6"), Color.parseColor("#A78BFA"), Color.parseColor("#F26B6B")
    )
    private val r = Ui.dp(ctx, 26).toFloat()

    var downs = 0
        private set
    var moves = 0
        private set
    var maxPointers = 0
        private set
    private var delaySum = 0L
    private var delayN = 0

    fun resetStats() {
        downs = 0
        moves = 0
        maxPointers = 0
        delaySum = 0
        delayN = 0
        active.clear()
        invalidate()
    }

    fun statsText(): String {
        val d = if (delayN > 0) "%.1f ms".format(delaySum.toDouble() / delayN) else "—"
        return "toques: $downs · movimentos: $moves · máx. dedos juntos: $maxPointers · atraso de entrega médio: $d"
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val a = e.actionMasked
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                downs++
                if (e.pointerCount > maxPointers) maxPointers = e.pointerCount
            }
            MotionEvent.ACTION_MOVE -> {
                moves++
                if (e.pointerCount > maxPointers) maxPointers = e.pointerCount
                delaySum += (SystemClock.uptimeMillis() - e.eventTime).coerceAtLeast(0)
                delayN++
            }
        }
        active.clear()
        if (a != MotionEvent.ACTION_UP && a != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (a == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                active[e.getPointerId(i)] = PointF(e.getX(i), e.getY(i))
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        val rr = Ui.dp(context, 12).toFloat()
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), rr, rr, bg)
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), rr, rr, border)
        if (active.isEmpty()) {
            c.drawText("Área de teste dos toques", width / 2f, height / 2f, hint)
        }
        for ((id, p) in active) {
            dot.color = colors[id % colors.size]
            c.drawCircle(p.x, p.y, r, dot)
            c.drawText(id.toString(), p.x, p.y + label.textSize / 3f, label)
        }
    }
}
