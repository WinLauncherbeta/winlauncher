package com.pandamapper.app;

// Interface do serviço de toques que roda dentro do processo do Shizuku (shell/root).
// Regra do AIDL: ou todos os métodos têm número explícito, ou nenhum. Aqui todos têm.
// destroy() = 16777114 é o número reservado pelo Shizuku.
interface IPanda {
    void destroy() = 16777114;

    // "oneway": o app não espera resposta, o que reduz a latência. A ordem das chamadas é mantida.
    oneway void touchDown(int id, float x, float y) = 1;
    oneway void touchMove(int id, float x, float y) = 2;
    oneway void touchUp(int id) = 3;
    // Move vários dedos num único evento (joystick + câmera ao mesmo tempo).
    oneway void touchMoveMany(in int[] ids, in float[] xs, in float[] ys) = 4;
    oneway void releaseAll() = 5;

    long echo(long v) = 6;
    String info() = 7;
    // Injeta n movimentos de um dedo em (x, y) e devolve o tempo total em nanossegundos.
    long benchInject(int n, float x, float y) = 8;
}
