plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pandamapper.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pandamapper.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }

    // Chave de debug fixa: mesma assinatura entre builds, o APK atualiza por cima sem perder dados.
    val fixedDebugKeystore = file("debug.keystore")
    if (fixedDebugKeystore.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = fixedDebugKeystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildFeatures {
        aidl = true   // IPanda.aidl (serviço de toques do Shizuku)
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Shizuku: injeção de toques sem root (UserService, Etapa 2)
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
