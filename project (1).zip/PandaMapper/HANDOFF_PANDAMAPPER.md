# HANDOFF_PANDAMAPPER — histórico e próximas etapas

Mapeador estilo "Panda Mouse Pro": transforma teclado, mouse e controle em toques na tela do Android.
Usa o **Shizuku** para injetar os toques sem root (opção de melhoria pedida pelo dono).
Atualizar SOMENTE este arquivo a cada etapa.

## Projeto (não mudar sem necessidade)
- Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, Java 17, compileSdk/targetSdk 34, minSdk 26.
- Package/applicationId/namespace: `com.pandamapper.app`.
- Assinatura fixa: `app/debug.keystore` (alias `androiddebugkey`, senha `android`).
- Interface programática (Views, sem XML de layout). Dependências: Shizuku api/provider 13.1.5.
- Build: GitHub Actions (`.github/workflows/build-debug.yml`), artefato `PandaMapper-debug-apk`.
- O ambiente onde o código é escrito NÃO tem Android SDK nem kotlinc: nada foi compilado aqui. Só o GitHub Actions compila.
  Cada etapa deve ser testada no aparelho; se o build falhar, mandar o log para corrigir antes da próxima etapa.
- Base reaproveitada do projeto WinLauncher enviado pelo dono: `ShizukuBridge` (detecção de Shizuku modificado,
  exec por reflexão), keystore e workflow.

## Versões
- 0.1.0 (versionCode 1): Etapa 1.
- 0.2.0 (versionCode 2): Etapa 2.

## Etapas
1. **Base e Shizuku — FEITA (0.1.0), não compilada, não testada no aparelho.**
   Arquivos: `MainActivity.kt` (tela com estado do Shizuku, testes e roadmap), `ShizukuBridge.kt`, `Ui.kt`, manifest, ícone.
2. **Motor de toques — FEITA (0.2.0), não compilada, não testada no aparelho.**
   - `IPanda.aidl` (app/src/main/aidl): touchDown/touchMove/touchUp/touchMoveMany/releaseAll (oneway), echo, info, benchInject, destroy=16777114.
     Todos os métodos têm número explícito (o AIDL não deixa misturar). `buildFeatures { aidl = true }`.
   - `TouchService.kt`: UserService (roda como shell/root dentro do Shizuku). Construtor sem argumentos, sem Context.
   - `TouchInjector.kt`: monta MotionEvent multitoque (DOWN, POINTER_DOWN, MOVE, POINTER_UP, UP) e injeta por reflexão.
     Tenta, em ordem: `InputManagerGlobal.getInstance()` (Android 14+), `InputManager.getInstance()`, `IInputManager` via ServiceManager.
     `info()` diz qual funcionou.
   - `TouchEngine.kt` (app): conecta/desconecta (`Shizuku.bindUserService`), API down/move/up/moveMany/releaseAll. Mudou o serviço? Aumente `SERVICE_VERSION`.
   - `TouchTestView.kt`: área de teste que desenha os dedos recebidos e mede atraso de entrega.
   - Tela: card "Motor de toques" (conectar, info, teste 2 dedos, teste 5 dedos, medir latência, soltar tudo). O teste antigo `input tap` virou "Diagnóstico".
   - Etapa 3 deve chamar `TouchEngine.down/move/up/moveMany` (ids de dedo livres de 0 a 9).
3. Captura de entrada — teclado/mouse/controle físicos (KeyEvent, GenericMotionEvent, ponteiro capturado) sem tirar o foco do jogo.
4. Editor de mapeamento — overlay com botões arrastáveis/redimensionáveis (toque, segurar, joystick, câmera, deslize); salvar em JSON.
5. Execução — tecla→toque, WASD→joystick, mouse→câmera, sensibilidade, modo jogo liga/desliga.
6. Perfis por jogo — detectar app em primeiro plano, trocar perfil, importar/exportar, modelos prontos.
7. Acabamento — botão flutuante, notificação, tutorial, otimização, build final, documentação.

## O que falta após a Etapa 1
Tudo das etapas 2 a 7. Pendências conhecidas da própria Etapa 1: compilar no GitHub Actions e testar no aparelho
(Shizuku autorizado → "Testar privilégio" deve mostrar `uid=2000(shell)` ou `uid=0(root)`; "Testar toque" deve tocar no centro da tela).
