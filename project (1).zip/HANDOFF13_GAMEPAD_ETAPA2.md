# HANDOFF 13 — Mapeador de gamepad, ETAPA 2: editor sobre o jogo (WinLauncher 2.8.0 / code 20)

NÃO compilado com Gradle/AGP e NÃO testado em aparelho (não havia compilador Kotlin neste ambiente; só conferido balanço de chaves/parênteses e leitura do código). A etapa 1 também continua sem teste no aparelho.

## O que é novo
Em Configurações > Jogos > Mapeador de gamepad > (perfil) > **Editar sobre o jogo**:
- liga o editor e abre o jogo; os pontos aparecem POR CIMA do jogo de verdade (duas janelas TYPE_ACCESSIBILITY_OVERLAY, sem permissão nova).
- Tela: toque num ponto = seleciona; arrastar = move (com mira); toque em área vazia = põe/move o ponto do botão selecionado.
- Controle: apertar um botão do controle seleciona esse botão no editor (o jogo não recebe a tecla enquanto edita).
- Barra: botões do controle (rolagem), Toque rápido / Segurar / Remover ponto, setas de ajuste fino (0,25% por toque, segurar repete), orientação do perfil (avisa se a tela está girada ao contrário), Testar, Salvar e sair, Descartar (2 toques), Abrir jogo, ⇅ (barra em cima/embaixo), ▾ (recolher).
- **Testar**: a tela deixa de pegar toques e o mapeamento volta a valer de verdade; apertar o botão do controle toca no jogo e o ponto acende (verde). A barra diz por que não funciona (chave geral desligada, perfil desativado, jogo fora da frente, orientação errada).
- Os pontos são editados direto no perfil (o teste usa o que foi arrastado) e só vão para o disco em "Salvar e sair". "Descartar" restaura o perfil como estava ao abrir.
- O painel da launcher relê o perfil quando o editor salva/descarta (PadEngine.editVersion).

## Arquivos
Novo: PadOverlayEditor.kt.
Modificados: PadEngine.kt (editing, editHook, editVersion, isPressed, setEditing, notifyProfileEdited; consome teclas de controle enquanto edita), PadMapperService.kt (openEditor/editorOpen, fecha o editor ao desligar), PadPanel.kt (botão "Editar sobre o jogo" + releitura), app/build.gradle.kts (2.8.0/20).
Não alterados: ShortcutService, Remote, MediaSessionHub, assinatura, package, TouchPlanner, PadModel, PadStore, manifest, XML do serviço.

## Testar no aparelho (ordem)
1. Build do GitHub Actions (corrigir o que o compilador apontar; pontos mais prováveis: PadOverlayEditor.kt, a lambda do botão em PadPanel.showEditor).
2. Editar sobre o jogo: as janelas aparecem? O jogo abre sozinho? (se o Android recusar, o botão "Abrir jogo" da barra tenta de novo; senão abra à mão).
3. Os pontos caem EXATAMENTE onde você os vê? (conta usa o tamanho real da tela: x*(largura-1)). Conferir em retrato e paisagem, com e sem entalhe/barra de navegação.
4. Controle seleciona o botão na barra? O jogo de baixo não reage enquanto edita?
5. Testar: o toque cai no ponto, Segurar mantém, dois botões juntos, o ponto acende.
6. Salvar e sair / Descartar / sair do jogo no meio da edição (o editor continua por cima de outros apps até você fechar).
7. Girar a tela com o editor aberto: barra se ajusta, aviso de orientação muda.

## Limites conhecidos
- O editor fica aberto até Salvar/Descartar ou desligar o serviço; trocar de app NÃO o fecha (de propósito).
- "Abrir jogo" de dentro do serviço pode ser bloqueado pelo Android (inicia atividade em segundo plano); o botão do painel da launcher abre sem problema.
- A lista de teclados (imePkgs) ainda é lida uma vez só (trocar de teclado exige ligar/desligar o serviço).
- Analógicos, gatilhos analógicos, D-pad como eixo: Etapa 3. Perfil automático, botão flutuante, importar/exportar: Etapa 4.
