package com.example.winlauncher

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max

/**
 * Espaçamento uniforme da área de trabalho. Kotlin puro (sem Android), tudo em dp.
 *
 * Modelo: cada app ocupa um retângulo (w x h). Dois apps só são válidos se estiverem
 * separados por pelo menos [gap] em X **ou** em Y (a mesma folga nos dois eixos).
 * A posição continua livre: nada é encaixado em grade; só se corrige o que viola
 * a folga mínima, a sobreposição ou as margens.
 *
 *  - [gapFor]        folga mínima adaptada ao tamanho da tela e ao número de apps.
 *  - [resolve]       aplica folga + margens. Os apps recém-movidos ([moved]) têm prioridade
 *                    e se movem juntos (rígido); quem violar vai para o ponto livre mais próximo.
 *  - [firstFreeSlot] posição inicial de um app novo (cima→baixo, esquerda→direita).
 *  - [placeBlock]    posição livre mais próxima para um bloco retangular (widget) entre os apps.
 *
 * Widgets: um retângulo reservado ([reserved] = x, y, w, h em dp) funciona como um obstáculo
 * a mais, com a mesma folga dos apps, em [resolve] e [firstFreeSlot].
 */
object DesktopSpacing {
    const val MARGIN = 8
    const val GAP_MIN = 8
    const val GAP_MAX = 24

    /** Folga de capacidade: a tela deve comportar ~1,5x os apps para sobrar espaço de manobra. */
    private const val FILL = 1.5
    private const val STEP = 2
    private const val BUDGET = 400_000
    private const val BLOCK_BUDGET = 150_000

    /** Maior folga (GAP_MAX..GAP_MIN) que ainda comporta os apps com sobra; reduz só se faltar espaço. */
    fun gapFor(areaW: Int, areaH: Int, w: Int, h: Int, n: Int, margin: Int = MARGIN): Int {
        val comfortable = ceil(n * FILL).toInt()
        for (g in GAP_MAX downTo GAP_MIN) if (capacity(areaW, areaH, w, h, g, margin) >= comfortable) return g
        for (g in GAP_MIN downTo 0) if (capacity(areaW, areaH, w, h, g, margin) >= n) return g
        return 0
    }

    private fun capacity(aw: Int, ah: Int, w: Int, h: Int, g: Int, m: Int): Int {
        val cols = (aw - 2 * m + g) / (w + g)
        val rows = (ah - 2 * m + g) / (h + g)
        return max(0, cols) * max(0, rows)
    }

    /**
     * @param desired posições desejadas (dp) por chave; só as chaves de [order] são tratadas
     * @param order   chaves dos apps visíveis (a ordem decide quem fica no lugar num conflito)
     * @param moved   chaves recém-movidas pelo usuário: têm prioridade e preservam a forma do grupo
     * @return posições finais válidas para todas as chaves de [order] (cópias novas)
     */
    fun resolve(
        desired: Map<String, IntArray>,
        order: List<String>,
        moved: Set<String>,
        areaW: Int,
        areaH: Int,
        w: Int,
        h: Int,
        reserved: IntArray? = null
    ): Map<String, IntArray> {
        val keys = order.filter { desired.containsKey(it) }
        if (areaW <= 0 || areaH <= 0 || keys.isEmpty()) return keys.associateWith { desired.getValue(it).copyOf() }
        var g = gapFor(areaW, areaH, w, h, keys.size)
        while (true) {
            val ctx = Ctx(areaW, areaH, w, h, g, MARGIN)
            ctx.reserved = reserved
            val r = solve(ctx, desired, keys, moved)
            if (r != null) return r
            if (g == 0) break
            g-- // sem espaço com esta folga: reduz a folga (igual para todos) e tenta de novo
        }
        val c = Ctx(areaW, areaH, w, h, 0, MARGIN)
        return keys.associateWith { intArrayOf(c.cx(desired.getValue(it)[0]), c.cy(desired.getValue(it)[1])) }
    }

    /** Primeiro espaço livre (colunas da esquerda p/ a direita, cima p/ baixo) respeitando margem e folga. */
    fun firstFreeSlot(
        placed: Collection<IntArray>,
        areaW: Int,
        areaH: Int,
        w: Int,
        h: Int,
        total: Int,
        reserved: IntArray? = null
    ): IntArray {
        val g = gapFor(areaW, areaH, w, h, total)
        val c = Ctx(areaW, areaH, w, h, g, MARGIN)
        c.reserved = reserved
        val obs = placed.toList()
        var x = c.minX
        while (x <= c.maxX) {
            var y = c.minY
            while (y <= c.maxY) {
                if (c.free(x, y, obs)) return intArrayOf(x, y)
                y += h + g
            }
            x += w + g
        }
        return ringSearch(c, c.minX, c.minY, c.minX, c.maxX, c.minY, c.maxY) { px, py -> c.free(px, py, obs) }
            ?.let { intArrayOf(it[0], it[1]) } ?: intArrayOf(c.minX, c.minY)
    }

    /**
     * Posição livre mais próxima de ([x0],[y0]) para um bloco de [bw] x [bh] (ex.: widget) entre os apps
     * em [icons] (cada um w x h, mesma folga e margens dos apps). Os apps não se movem.
     * Retorna null se o bloco não couber na área ou se não houver nenhum ponto livre.
     */
    fun placeBlock(
        x0: Int,
        y0: Int,
        bw: Int,
        bh: Int,
        icons: Collection<IntArray>,
        areaW: Int,
        areaH: Int,
        w: Int,
        h: Int,
        total: Int
    ): IntArray? {
        if (areaW <= 0 || areaH <= 0 || bw <= 0 || bh <= 0) return null
        if (bw > areaW - 2 * MARGIN || bh > areaH - 2 * MARGIN) return null
        val g = gapFor(areaW, areaH, w, h, total)
        val c = Ctx(areaW, areaH, bw, bh, g, MARGIN)
        c.cap = BLOCK_BUDGET
        val obs = icons.toList()
        return ringSearch(c, x0, y0, c.minX, c.maxX, c.minY, c.maxY) { x, y ->
            !overlapsGap(x, y, bw, bh, obs, w, h, g)
        }
    }

    // ------------------------------------------------------------------ interno

    /** Retângulos (x,y,bw,bh) e (ox,oy,ow,oh) a menos de [g] um do outro (ou sobrepostos) nos dois eixos. */
    private fun near(x: Int, y: Int, bw: Int, bh: Int, ox: Int, oy: Int, ow: Int, oh: Int, g: Int): Boolean =
        x < ox + ow + g && ox < x + bw + g && y < oy + oh + g && oy < y + bh + g

    private fun overlapsGap(x: Int, y: Int, bw: Int, bh: Int, obs: List<IntArray>, w: Int, h: Int, g: Int): Boolean {
        for (o in obs) if (near(x, y, bw, bh, o[0], o[1], w, h, g)) return true
        return false
    }

    private class Ctx(val aw: Int, val ah: Int, val w: Int, val h: Int, val g: Int, val m: Int) {
        val minX = m
        val maxX = max(m, aw - m - w)
        val minY = m
        val maxY = max(m, ah - m - h)
        var budget = BUDGET
        var cap = BUDGET

        /** Retângulo reservado (x, y, w, h em dp), por exemplo um widget; null = nenhum. */
        var reserved: IntArray? = null

        fun cx(x: Int) = x.coerceIn(minX, maxX)
        fun cy(y: Int) = y.coerceIn(minY, maxY)

        fun clash(ax: Int, ay: Int, bx: Int, by: Int) = abs(ax - bx) < w + g && abs(ay - by) < h + g

        fun free(x: Int, y: Int, obs: List<IntArray>): Boolean {
            val r = reserved
            if (r != null && near(x, y, w, h, r[0], r[1], r[2], r[3], g)) return false
            for (o in obs) if (clash(x, y, o[0], o[1])) return false
            return true
        }
    }

    private fun solve(c: Ctx, desired: Map<String, IntArray>, keys: List<String>, moved: Set<String>): Map<String, IntArray>? {
        val out = LinkedHashMap<String, IntArray>()
        val accepted = ArrayList<IntArray>()
        val grp = keys.filter { it in moved }
        val others = keys.filter { it !in moved }
        var grpDone = false

        if (grp.isNotEmpty()) {
            val gp = grp.map { desired.getValue(it) }
            val obs = others.map { intArrayOf(c.cx(desired.getValue(it)[0]), c.cy(desired.getValue(it)[1])) }
            val loX = c.minX - gp.minOf { it[0] }
            val hiX = c.maxX - gp.maxOf { it[0] }
            val loY = c.minY - gp.minOf { it[1] }
            val hiY = c.maxY - gp.maxOf { it[1] }
            if (loX <= hiX && loY <= hiY) {
                val t = ringSearch(c, 0, 0, loX, hiX, loY, hiY) { tx, ty ->
                    gp.all { p -> c.free(p[0] + tx, p[1] + ty, obs) }
                }
                if (t != null) {
                    for (i in grp.indices) {
                        val p = intArrayOf(gp[i][0] + t[0], gp[i][1] + t[1])
                        out[grp[i]] = p
                        accepted.add(p)
                    }
                    grpDone = true
                }
            }
        }

        val seq = if (grpDone) others else grp + others
        for (k in seq) {
            val p = desired.getValue(k)
            val s = ringSearch(c, c.cx(p[0]), c.cy(p[1]), c.minX, c.maxX, c.minY, c.maxY) { x, y -> c.free(x, y, accepted) }
                ?: return null
            out[k] = s
            accepted.add(s)
        }
        // devolve na ordem original de [keys]
        return keys.associateWith { out.getValue(it) }
    }

    /**
     * Procura o ponto válido mais próximo de (x0,y0) em anéis quadrados crescentes (passo STEP),
     * limitado à faixa de X (loX a hiX) e de Y (loY a hiY). Retorna null se não houver ou se estourar o orçamento.
     */
    private fun ringSearch(
        c: Ctx,
        x0: Int,
        y0: Int,
        loX: Int,
        hiX: Int,
        loY: Int,
        hiY: Int,
        valid: (Int, Int) -> Boolean
    ): IntArray? {
        c.budget = c.cap
        val sx = x0.coerceIn(loX, hiX)
        val sy = y0.coerceIn(loY, hiY)
        if (valid(sx, sy)) return intArrayOf(sx, sy)
        val maxR = max(hiX - loX, hiY - loY) + STEP
        var r = STEP
        while (r <= maxR) {
            var best: IntArray? = null
            var bestD = Long.MAX_VALUE
            var i = -r
            while (i <= r) {
                for (k in 0 until 4) {
                    val px = (if (k < 2) sx + i else if (k == 2) sx - r else sx + r).coerceIn(loX, hiX)
                    val py = (if (k == 0) sy - r else if (k == 1) sy + r else sy + i).coerceIn(loY, hiY)
                    if (--c.budget < 0) return null
                    if (valid(px, py)) {
                        val dx = (px - sx).toLong()
                        val dy = (py - sy).toLong()
                        val d = dx * dx + dy * dy
                        if (d < bestD) {
                            bestD = d
                            best = intArrayOf(px, py)
                        }
                    }
                }
                i += STEP
            }
            if (best != null) return best
            r += STEP
        }
        return null
    }
}
