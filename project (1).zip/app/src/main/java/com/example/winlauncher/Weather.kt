package com.example.winlauncher

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

data class DayForecast(val label: String, val code: Int, val max: Int, val min: Int, val rain: Int)

/** Resultado da busca de cidades (geocodificação do Open-Meteo). */
data class CityResult(val name: String, val detail: String, val lat: Double, val lon: Double)

data class WeatherData(
    val city: String,
    val temp: Int,
    val feels: Int,
    val humidity: Int,
    val wind: Int,
    val code: Int,
    val isDay: Boolean,
    val days: List<DayForecast>,
    val fetchedAt: Long
)

/**
 * Previsão do tempo via Open-Meteo (gratuito, sem chave).
 * Localização: última posição conhecida (permissão aproximada) ou, se não houver, pelo IP.
 */
object Weather {

    private class Place(val lat: Double, val lon: Double, val city: String?)

    fun emoji(code: Int, isDay: Boolean): String = when (code) {
        0, 1 -> if (isDay) (if (code == 0) "☀️" else "🌤️") else "🌙"
        2 -> if (isDay) "⛅" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 66, 67, 80, 81 -> "🌧️"
        65, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "🌨️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Céu limpo"
        1 -> "Predominantemente limpo"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Neblina"
        51, 53, 55 -> "Garoa"
        56, 57 -> "Garoa congelante"
        61 -> "Chuva fraca"
        63 -> "Chuva"
        65 -> "Chuva forte"
        66, 67 -> "Chuva congelante"
        71, 73, 75, 77 -> "Neve"
        80, 81 -> "Pancadas de chuva"
        82 -> "Chuva torrencial"
        85, 86 -> "Pancadas de neve"
        95 -> "Trovoada"
        96, 99 -> "Trovoada com granizo"
        else -> "Tempo variável"
    }

    // ------------------------------------------------------------- cache

    fun load(sp: SharedPreferences, key: String = "wxJson"): WeatherData? {
        val raw = sp.getString(key, null) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("days")
            val days = ArrayList<DayForecast>()
            for (i in 0 until arr.length()) {
                val d = arr.getJSONObject(i)
                days.add(
                    DayForecast(
                        d.getString("l"), d.getInt("c"), d.getInt("x"), d.getInt("n"), d.getInt("r")
                    )
                )
            }
            WeatherData(
                o.getString("city"), o.getInt("temp"), o.getInt("feels"), o.getInt("hum"),
                o.getInt("wind"), o.getInt("code"), o.getBoolean("day"), days, o.getLong("at")
            )
        } catch (e: Exception) {
            null
        }
    }

    fun save(sp: SharedPreferences, w: WeatherData, key: String = "wxJson") {
        val arr = JSONArray()
        for (d in w.days) {
            arr.put(
                JSONObject().put("l", d.label).put("c", d.code).put("x", d.max).put("n", d.min)
                    .put("r", d.rain)
            )
        }
        val o = JSONObject()
            .put("city", w.city).put("temp", w.temp).put("feels", w.feels).put("hum", w.humidity)
            .put("wind", w.wind).put("code", w.code).put("day", w.isDay).put("days", arr)
            .put("at", w.fetchedAt)
        sp.edit().putString(key, o.toString()).apply()
    }

    // ------------------------------------------------------------- tela de bloqueio (cidade escolhida)

    /** Previsão para coordenadas conhecidas (cidade escolhida manualmente). Rodar fora da thread principal. */
    fun fetchAt(lat: Double, lon: Double, city: String): WeatherData? = fetchForecast(lat, lon, city)

    /**
     * Busca cidades pelo nome (Open-Meteo Geocoding, dados reais).
     * Retorna null se não houver conexão/erro; lista vazia se nada foi encontrado. Rodar fora da thread principal.
     */
    fun searchCities(query: String): List<CityResult>? {
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        val raw = httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=6&language=pt&format=json")
            ?: return null
        return try {
            val arr = JSONObject(raw).optJSONArray("results") ?: return emptyList()
            val out = ArrayList<CityResult>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val detail = listOf(o.optString("admin1"), o.optString("country"))
                    .filter { it.isNotEmpty() }.joinToString(", ")
                out.add(CityResult(o.getString("name"), detail, o.getDouble("latitude"), o.getDouble("longitude")))
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------- busca (rodar fora da thread principal)

    fun fetchAuto(ctx: Context, sp: SharedPreferences): WeatherData? {
        var place: Place? = null

        val loc = lastLocation(ctx)
        if (loc != null) {
            place = Place(loc.latitude, loc.longitude, cityName(ctx, loc.latitude, loc.longitude))
        }
        if (place == null) place = ipLocation()
        if (place == null) {
            val la = sp.getString("wxLat", null)?.toDoubleOrNull()
            val lo = sp.getString("wxLon", null)?.toDoubleOrNull()
            if (la != null && lo != null) place = Place(la, lo, sp.getString("wxCity", null))
        }
        if (place == null) return null

        val city = place.city ?: sp.getString("wxCity", null) ?: "Local atual"
        val data = fetchForecast(place.lat, place.lon, city) ?: return null

        sp.edit()
            .putString("wxLat", place.lat.toString())
            .putString("wxLon", place.lon.toString())
            .putString("wxCity", city)
            .apply()
        save(sp, data)
        return data
    }

    private fun lastLocation(ctx: Context): Location? {
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED
        ) return null
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.getProviders(true)
                .mapNotNull {
                    try {
                        lm.getLastKnownLocation(it)
                    } catch (e: SecurityException) {
                        null
                    }
                }
                .maxByOrNull { it.time }
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun cityName(ctx: Context, lat: Double, lon: Double): String? {
        return try {
            if (!Geocoder.isPresent()) return null
            val list = Geocoder(ctx, Locale("pt", "BR")).getFromLocation(lat, lon, 1)
            val a = list?.firstOrNull() ?: return null
            a.locality ?: a.subAdminArea ?: a.adminArea
        } catch (e: Exception) {
            null
        }
    }

    private fun ipLocation(): Place? {
        val a = httpGet("https://ipwho.is/")
        if (a != null) {
            try {
                val o = JSONObject(a)
                if (o.optBoolean("success", true) && o.has("latitude")) {
                    return Place(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("city").ifEmpty { null })
                }
            } catch (e: Exception) {
            }
        }
        val b = httpGet("https://ipapi.co/json/")
        if (b != null) {
            try {
                val o = JSONObject(b)
                if (o.has("latitude")) {
                    return Place(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("city").ifEmpty { null })
                }
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun fetchForecast(lat: Double, lon: Double, city: String): WeatherData? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=5"
        val raw = httpGet(url) ?: return null
        return try {
            val o = JSONObject(raw)
            val cur = o.getJSONObject("current")
            val daily = o.getJSONObject("daily")
            val times = daily.getJSONArray("time")
            val codes = daily.getJSONArray("weather_code")
            val maxs = daily.getJSONArray("temperature_2m_max")
            val mins = daily.getJSONArray("temperature_2m_min")
            val rains = daily.getJSONArray("precipitation_probability_max")
            val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val fmt = SimpleDateFormat("EEE", Locale("pt", "BR"))
            val days = ArrayList<DayForecast>()
            for (i in 0 until times.length()) {
                val label = if (i == 0) {
                    "Hoje"
                } else {
                    val d = parse.parse(times.getString(i))
                    val s = if (d != null) fmt.format(d).trimEnd('.') else ""
                    s.replaceFirstChar { it.uppercase() }
                }
                days.add(
                    DayForecast(
                        label,
                        codes.getInt(i),
                        Math.round(maxs.getDouble(i)).toInt(),
                        Math.round(mins.getDouble(i)).toInt(),
                        if (rains.isNull(i)) 0 else rains.getInt(i)
                    )
                )
            }
            WeatherData(
                city,
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                Math.round(cur.getDouble("apparent_temperature")).toInt(),
                cur.getInt("relative_humidity_2m"),
                Math.round(cur.getDouble("wind_speed_10m")).toInt(),
                cur.getInt("weather_code"),
                cur.getInt("is_day") == 1,
                days,
                System.currentTimeMillis()
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun httpGet(u: String): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "WinLauncher")
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }
}
