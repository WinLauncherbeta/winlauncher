package com.example.winlauncher

import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

/**
 * Mapeador de gamepad (Etapa 4) - botão flutuante liga/desliga, por cima do jogo.
 *
 * É uma janela de acessibilidade ([WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY]) do [PadMapperService]: não precisa
 * da permissão "exibir sobre outros apps". O serviço mostra o botão só enquanto o app da frente tem perfil (ver
 * [PadEngine.candidateProfile]) e o esconde quando o editor está aberto.
 *
 * Toque = liga/desliga o mapeamento (a mesma chave do painel). Arrastar = muda de lugar (a posição é guardada por orientação).
 * Atenção: se um ponto mapeado cair EM CIMA do botão, o toque injetado cai no botão e não chega ao jogo. Por isso o botão
 * ignora toques enquanto há dedo injetado, e a dica é deixá-lo longe dos pontos.
 *
 * Só thread principal.
 */
class PadFloatingButton(private val svc: PadMapperService) {

    private val wm = svc.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val size = (46 * d + 0.5f).toInt()
    private val tv = TextView(svc)
    private val lp = WindowManager.LayoutParams(
        size, size,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private var added = false

    init {
        lp.gravity = Gravity.TOP or Gravity.START
        tv.gravity = Gravity.CENTER
        tv.textSize = 10f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(Color.WHITE)
        tv.includeFontPadding = false
        tv.isClickable = true

        val slop = 8 * d
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        var blocked = false

        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // há dedo injetado agora: esse toque veio do mapeamento, não do usuário
                    blocked = PadEngine.planner.hasWork()
                    dragging = false
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = lp.x
                    startY = lp.y
                    tv.alpha = 0.6f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!blocked) {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (!dragging && (dx * dx + dy * dy) > slop * slop) dragging = true
                        if (dragging) {
                            lp.x = clampX(startX + dx.toInt())
                            lp.y = clampY(startY + dy.toInt())
                            update()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    tv.alpha = 0.85f
                    if (!blocked) {
                        if (dragging) {
                            PadPrefs.setFloatPos(svc, landscape(), lp.x, lp.y)
                        } else {
                            toggle()
                        }
                    }
                    blocked = false
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    tv.alpha = 0.85f
                    blocked = false
                    true
                }
                else -> false
            }
        }
    }

    private fun screenW(): Int = svc.screenWidth()

    private fun screenH(): Int = svc.screenHeight()

    private fun landscape(): Boolean = screenW() > screenH()

    private fun clampX(x: Int): Int = Math.max(0, Math.min(x, Math.max(0, screenW() - size)))

    private fun clampY(y: Int): Int = Math.max(0, Math.min(y, Math.max(0, screenH() - size)))

    private fun toggle() {
        val on = !PadEngine.masterOn
        PadStore.setMaster(svc, on)
        refresh()
        MiniToast.info(svc, if (on) "Mapeamento do gamepad LIGADO" else "Mapeamento do gamepad DESLIGADO", true)
    }

    /** Cor e texto conforme o estado da chave geral. */
    fun refresh() {
        val on = PadEngine.masterOn
        tv.text = if (on) "PAD\nON" else "PAD\nOFF"
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(Color.parseColor(if (on) "#E62E9E5B" else "#E64A4F59"))
        g.setStroke(Math.max(1, d.toInt()), Color.argb(110, 255, 255, 255))
        tv.background = g
        tv.alpha = 0.85f
    }

    private fun update() {
        if (!added) return
        try {
            wm.updateViewLayout(tv, lp)
        } catch (e: Exception) {
        }
    }

    /** Mostra (ou reposiciona, se a tela girou). */
    fun show() {
        val w = screenW()
        val h = screenH()
        if (w <= 0 || h <= 0) return
        val saved = PadPrefs.floatPos(svc, w > h)
        lp.x = if (saved.first >= 0) clampX(saved.first) else clampX(w - size - (12 * d).toInt())
        lp.y = if (saved.second >= 0) clampY(saved.second) else clampY((h * 0.35f).toInt())
        refresh()
        if (added) {
            update()
            return
        }
        try {
            wm.addView(tv, lp)
            added = true
        } catch (e: Exception) {
            added = false
        }
    }

    fun hide() {
        if (!added) return
        try {
            wm.removeView(tv)
        } catch (e: Exception) {
        }
        added = false
    }
}
