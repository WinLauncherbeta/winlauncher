package com.example.winlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Botão de volume flutuante DENTRO do launcher (parte da própria janela do launcher).
 * Aparece sempre que o launcher está na tela, inclusive no monitor HDMI, sem criar janelas em outras telas.
 * Arraste com o mouse ou o dedo; clique abre o painel de volume; botão direito abre o menu (opacidade/tamanho/ocultar).
 * Opacidade e tamanho são compartilhados com o botão que aparece sobre outros apps (VolumeButtonService).
 */
class FloatingVolumeButton(
    private val ctx: Context,
    private val root: FrameLayout,
    private val sp: SharedPreferences,
    private val isRight: (MotionEvent) -> Boolean,
    private val onClick: () -> Unit,
    private val onRight: (Int, Int) -> Unit
) {
    companion object {
        const val MIN_SIZE_DP = 20
        const val MAX_SIZE_DP = 120
        const val DEF_SIZE_DP = 48

        /** Padding interno do ícone: 1/5 do tamanho (ícone ocupa 60% do círculo). */
        fun iconPad(sizePx: Int): Int = sizePx / 5

        /**
         * Posição ÚNICA em pixels ABSOLUTOS DA TELA (canto superior esquerdo do botão), compartilhada
         * entre o botão do launcher e o que fica sobre outros apps. Só é gravada quando o usuário arrasta:
         * trocar de app, mudar o tamanho ou recriar a janela nunca altera o valor salvo.
         */
        fun hasPos(sp: SharedPreferences): Boolean = sp.contains("vb_sx") && sp.contains("vb_sy")

        fun readPos(sp: SharedPreferences, screenW: Int, screenH: Int, sizePx: Int, density: Float): Pair<Int, Int> {
            val x = if (sp.contains("vb_sx")) sp.getInt("vb_sx", 0) else screenW - sizePx - (16 * density).toInt()
            val y = if (sp.contains("vb_sy")) sp.getInt("vb_sy", 0) else (screenH * 0.4f).toInt()
            return x to y
        }

        fun savePos(sp: SharedPreferences, screenX: Int, screenY: Int) {
            sp.edit().putInt("vb_sx", screenX).putInt("vb_sy", screenY).apply()
        }
    }

    private val d = ctx.resources.displayMetrics.density
    val view = ImageView(ctx)
    private val lp = FrameLayout.LayoutParams(0, 0, Gravity.TOP or Gravity.START)

    fun sizeDp(): Int = sp.getInt("vb_size", DEF_SIZE_DP).coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)
    fun alphaPct(): Int = sp.getInt("vb_alpha", 100).coerceIn(20, 100)
    private fun px(): Int = (sizeDp() * d + 0.5f).toInt()
    private fun baseAlpha() = alphaPct() / 100f

    /** Posição do canto superior esquerdo do root na tela (para converter tela <-> root). */
    private fun origin(): IntArray {
        val o = IntArray(2)
        try {
            root.getLocationOnScreen(o)
        } catch (e: Exception) {
        }
        return o
    }

    private fun rootW(): Int = if (root.width > 0) root.width else ctx.resources.displayMetrics.widthPixels
    private fun rootH(): Int = if (root.height > 0) root.height else ctx.resources.displayMetrics.heightPixels

    init {
        view.setImageResource(R.drawable.ic_volume)
        view.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(210, 30, 30, 30))
            setStroke(d.toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        view.isClickable = true
        view.elevation = 10 * d
        view.visibility = View.GONE
        applyStyle()
        root.addView(view, lp)

        val slop = 8 * d
        var downX = 0f
        var downY = 0f
        var startL = 0
        var startT = 0
        var dragging = false
        var rightHandled = false

        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    if (isRight(ev)) {
                        rightHandled = true
                        onRight(ev.rawX.toInt(), ev.rawY.toInt())
                    } else {
                        rightHandled = false
                        downX = ev.rawX
                        downY = ev.rawY
                        startL = lp.leftMargin
                        startT = lp.topMargin
                        v.alpha = baseAlpha() * 0.7f
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!rightHandled) {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (!dragging && (dx * dx + dy * dy) > slop * slop) dragging = true
                        if (dragging) {
                            lp.leftMargin = (startL + dx).toInt().coerceIn(0, (rootW() - lp.width).coerceAtLeast(0))
                            lp.topMargin = (startT + dy).toInt().coerceIn(0, (rootH() - lp.height).coerceAtLeast(0))
                            v.layoutParams = lp
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.alpha = baseAlpha()
                    if (rightHandled) {
                        rightHandled = false
                    } else if (dragging) {
                        val o = origin()
                        savePos(sp, lp.leftMargin + o[0], lp.topMargin + o[1])
                    } else {
                        onClick()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    rightHandled = false
                    v.alpha = baseAlpha()
                    true
                }
                else -> false
            }
        }
    }

    /** Tamanho, opacidade e posição (limitada à tela). */
    fun applyStyle() {
        val s = px()
        lp.width = s
        lp.height = s
        val p = iconPad(s)
        view.setPadding(p, p, p, p)
        view.alpha = baseAlpha()
        // sempre relê a posição compartilhada (pode ter sido movida pelo botão sobre outros apps)
        val o = origin()
        val (sx, sy) = readPos(sp, rootW() + o[0], rootH() + o[1], s, d)
        // só limita para exibir (se a tela mudou); o valor salvo não é alterado
        lp.leftMargin = (sx - o[0]).coerceIn(0, (rootW() - s).coerceAtLeast(0))
        lp.topMargin = (sy - o[1]).coerceIn(0, (rootH() - s).coerceAtLeast(0))
        view.layoutParams = lp
    }

    fun setSize(dp: Int) {
        sp.edit().putInt("vb_size", dp.coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)).apply()
        applyStyle()
    }

    fun setAlpha(pct: Int) {
        sp.edit().putInt("vb_alpha", pct.coerceIn(20, 100)).apply()
        view.alpha = baseAlpha()
    }

    /** Mostra ou esconde conforme a opção "Botão de volume flutuante". */
    fun applyVisibility() {
        val on = sp.getBoolean("ui_vol_btn", false)
        view.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            root.post {
                applyStyle()
                view.bringToFront()
            }
        }
    }
}
