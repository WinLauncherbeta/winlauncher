package com.example.winlauncher

/**
 * Etapa 3B - leitura de eixos por `getevent` (Android 13 ou menor, via Shizuku). Parte PURA (sem Android), testada na JVM.
 *
 * Fluxo: `getevent -lp` lista os dispositivos e a faixa de cada eixo -> [parseDevices]; depois, para o controle escolhido,
 * `getevent -lq /dev/input/eventN` manda uma linha por evento -> [Reader.feed] devolve um [PadAxes] a cada SYN_REPORT.
 *
 * Os eixos do evdev variam por controle (Xbox: Z/RZ = gatilhos, RX/RY = analógico direito; PlayStation: Z/RZ = analógico
 * direito, RX/RY = gatilhos). Para não depender de nome de controle, cada eixo é classificado pelo valor em repouso que
 * o `-lp` mostra: no meio da faixa = analógico; no mínimo = gatilho.
 */
object GetEventParser {

    class AxisInfo(val name: String, val value: Int, val min: Int, val max: Int) {
        val mid: Float get() = (min + max) / 2f
        val half: Float get() = Math.max(1f, (max - min) / 2f)
        val range: Float get() = Math.max(1f, (max - min).toFloat())

        /** Em repouso no meio da faixa (analógico) e não no mínimo (gatilho). */
        val centered: Boolean get() = Math.abs(value - mid) <= 0.2f * range
    }

    class Device(val path: String, val name: String, val isPad: Boolean, val axes: Map<String, AxisInfo>) {
        fun axis(n: String): AxisInfo? = axes[n]
    }

    private val ADD = Regex("""add device \d+:\s*(\S+)""")
    private val NAME = Regex("""name:\s*"(.*)"""")
    private val AXIS = Regex("""(ABS_\w+)\s*:\s*value\s+(-?\d+),\s*min\s+(-?\d+),\s*max\s+(-?\d+)""")

    /** Lê a saída de `getevent -lp`. Só devolve dispositivos que têm botões de controle e o eixo X. */
    fun parseDevices(text: String): List<Device> {
        val out = ArrayList<Device>()
        var path = ""
        var name = ""
        var pad = false
        var axes = LinkedHashMap<String, AxisInfo>()
        fun flush() {
            if (path.isNotEmpty() && pad && axes.containsKey("ABS_X")) out.add(Device(path, name, pad, axes))
            path = ""
            name = ""
            pad = false
            axes = LinkedHashMap()
        }
        for (line in text.lines()) {
            val m = ADD.find(line)
            if (m != null) {
                flush()
                path = m.groupValues[1]
                continue
            }
            val n = NAME.find(line)
            if (n != null && path.isNotEmpty() && name.isEmpty()) {
                name = n.groupValues[1]
                continue
            }
            if (line.contains("BTN_GAMEPAD") || line.contains("BTN_SOUTH") || line.contains("BTN_A ") || line.endsWith("BTN_A")) pad = true
            val a = AXIS.find(line)
            if (a != null) {
                val v = a.groupValues
                axes[v[1]] = AxisInfo(v[1], v[2].toInt(), v[3].toInt(), v[4].toInt())
            }
        }
        flush()
        return out
    }

    /** Qual eixo é o quê, decidido uma vez por dispositivo. */
    class Layout(
        val lsX: AxisInfo, val lsY: AxisInfo?,
        val rsX: AxisInfo?, val rsY: AxisInfo?,
        val lt: AxisInfo?, val rt: AxisInfo?,
        val hatX: AxisInfo?, val hatY: AxisInfo?
    )

    fun layoutFor(d: Device): Layout? {
        val x = d.axis("ABS_X") ?: return null
        val y = d.axis("ABS_Y")
        // pares candidatos ao analógico direito, em ordem de preferência (RX/RY primeiro: é o caso do Xbox e do Android genérico)
        var rsX: AxisInfo? = null
        var rsY: AxisInfo? = null
        val pairs = listOf(Pair("ABS_RX", "ABS_RY"), Pair("ABS_Z", "ABS_RZ"))
        for (p in pairs) {
            val a = d.axis(p.first)
            val b = d.axis(p.second)
            if (a != null && b != null && a.centered && b.centered) {
                rsX = a
                rsY = b
                break
            }
        }
        // o que sobrou em repouso no mínimo são os gatilhos (o de menor código é o esquerdo)
        val trig = ArrayList<AxisInfo>()
        for (n in listOf("ABS_Z", "ABS_RX", "ABS_BRAKE", "ABS_RZ", "ABS_RY", "ABS_GAS")) {
            val a = d.axis(n) ?: continue
            if (a === rsX || a === rsY) continue
            if (!a.centered) trig.add(a)
        }
        // ABS_BRAKE/ABS_GAS sempre são gatilhos (esquerdo/direito), na frente dos outros
        val brake = d.axis("ABS_BRAKE")
        val gas = d.axis("ABS_GAS")
        var lt: AxisInfo? = brake
        var rt: AxisInfo? = gas
        if (lt == null || rt == null) {
            val rest = trig.filter { it !== brake && it !== gas }
            if (lt == null) lt = rest.getOrNull(0)
            if (rt == null) rt = rest.getOrNull(if (brake == null) 1 else 0)
        }
        return Layout(x, y, rsX, rsY, lt, rt, d.axis("ABS_HAT0X"), d.axis("ABS_HAT0Y"))
    }

    /** Lê as linhas de `getevent -lq` de UM dispositivo e junta os eixos num [PadAxes] a cada SYN_REPORT. */
    class Reader(private val layout: Layout, private val deviceName: String) {
        private val values = HashMap<String, Int>()
        private var dirty = false

        init {
            for (a in listOf(layout.lsX, layout.lsY, layout.rsX, layout.rsY, layout.lt, layout.rt, layout.hatX, layout.hatY)) {
                if (a != null) values[a.name] = a.value
            }
        }

        /** Devolve os eixos quando a linha fecha um quadro (SYN_REPORT) e algo mudou; senão null. */
        fun feed(line: String, now: Long): PadAxes? {
            val t = line.trim().split(Regex("""\s+""")).filter { it.isNotEmpty() }
            // com vários dispositivos a linha começa por "/dev/input/eventN:"
            val i = if (t.isNotEmpty() && t[0].startsWith("/dev/")) 1 else 0
            if (t.size < i + 3) return null
            val type = t[i]
            val code = t[i + 1]
            if (type == "EV_ABS") {
                val raw = parseHex(t[i + 2]) ?: return null
                if (values.containsKey(code) && values[code] != raw) {
                    values[code] = raw
                    dirty = true
                }
                return null
            }
            if (type == "EV_SYN" && code == "SYN_REPORT" && dirty) {
                dirty = false
                return snapshot(now)
            }
            return null
        }

        private fun parseHex(s: String): Int? = try {
            java.lang.Long.parseLong(s, 16).toInt()
        } catch (e: Exception) {
            null
        }

        private fun stick(a: AxisInfo?): Float {
            if (a == null) return 0f
            val v = values[a.name] ?: a.value
            return Math.max(-1f, Math.min(1f, (v - a.mid) / a.half))
        }

        private fun trigger(a: AxisInfo?): Float {
            if (a == null) return 0f
            val v = values[a.name] ?: a.value
            return Math.max(0f, Math.min(1f, (v - a.min) / a.range))
        }

        private fun hat(a: AxisInfo?): Float {
            if (a == null) return 0f
            val v = values[a.name] ?: 0
            return if (v > 0) 1f else if (v < 0) -1f else 0f
        }

        private fun snapshot(now: Long) = PadAxes(
            stick(layout.lsX), stick(layout.lsY), stick(layout.rsX), stick(layout.rsY),
            trigger(layout.lt), trigger(layout.rt), hat(layout.hatX), hat(layout.hatY),
            deviceName, now
        )
    }
}
