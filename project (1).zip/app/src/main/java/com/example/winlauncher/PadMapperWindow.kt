package com.example.winlauncher

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import kotlin.math.min

/**
 * App nativo "Mapeador de gamepad": janela própria (barra de título, arrastar, redimensionar, minimizar, maximizar),
 * com ícone na janela de aplicativos e na barra de tarefas (ver MainActivity) e as mesmas opções de ícone dos outros
 * apps nativos.
 *
 * Aqui o usuário só ADICIONA os jogos (lista). Mapear os botões só é possível dentro do jogo: com o jogo na frente,
 * ALT + M abre o editor sobre o jogo ([PadMapperService.openEditor]). Dentro do launcher, ALT + M abre/fecha esta janela.
 *
 * Os perfis são os mesmos de Configurações > Jogos > Mapeador de gamepad ([PadStore]); "Mais opções" mostra esse painel
 * completo (Shizuku, ajustes, backup) dentro desta janela. Só thread principal.
 */
class PadMapperWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    private val light: () -> Boolean
) {
    companion object {
        private const val MODE_WINDOW = 0
        private const val MODE_MAX = 1
    }

    val layer = FrameLayout(act)
    private val win = FrameLayout(act)

    private var open = false
    private var minimized = false
    val isOpen: Boolean get() = open
    val isMinimized: Boolean get() = minimized
    var onStateChange: (() -> Unit)? = null

    private var lastSnap: Bitmap? = null
    private var mode = MODE_WINDOW
    private var placed = false
    private var normX = 0
    private var normY = 0
    private var normW = 0
    private var normH = 0
    private var stackAbove: View? = null

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private val titleBar = LinearLayout(act)
    private val appIcon = ImageView(act)
    private val appName = TextView(act)
    private val minBtn = ImageView(act)
    private val maxBtn = ImageView(act)
    private val closeX = ImageView(act)
    private val host = FrameLayout(act)
    private val grip: View

    private var dragSx = 0f
    private var dragSy = 0f
    private var dragX0 = 0f
    private var dragY0 = 0f

    private val accent = Color.parseColor("#19B4F0")

    /** Página mostrada: 0 = lista de jogos, 1 = adicionar jogo, 2 = mais opções (painel completo). */
    private var page = 0
    private var infoLine = ""

    /** Resumo do que a lista mostra: a tela só é refeita quando isso muda (não a cada tecla do controle). */
    private var lastSig = ""

    private fun signature(): String {
        val sb = StringBuilder()
        sb.append(PadMapperService.running).append('|').append(PadEngine.masterOn)
        for (p in PadStore.profiles) {
            sb.append('|').append(p.pkg).append(':').append(p.name).append(':').append(p.enabled).append(':').append(p.activeCount())
        }
        return sb.toString()
    }

    private val refreshRun = Runnable {
        if (open && !minimized && page == 0 && signature() != lastSig) showGames()
    }
    private val engineListener: () -> Unit = {
        ui.removeCallbacks(refreshRun)
        ui.postDelayed(refreshRun, 300L)
    }
    private var listening = false

    init {
        layer.visibility = View.GONE
        layer.setOnTouchListener { _, _ -> false }
        win.isClickable = true
        layer.addView(win, FrameLayout.LayoutParams(dp(520), dp(560)))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(match, match))

        // ---- barra de título
        titleBar.orientation = LinearLayout.HORIZONTAL
        titleBar.gravity = Gravity.CENTER_VERTICAL
        appIcon.setImageDrawable(act.padMapIcon())
        titleBar.addView(appIcon, LinearLayout.LayoutParams(dp(20), dp(20)).apply { leftMargin = dp(16) })
        appName.text = AppCustom.label(act, AppCustom.PADMAP, "Mapeador de gamepad")
        appName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        appName.maxLines = 1
        titleBar.addView(appName, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(14) })
        minBtn.setImageResource(R.drawable.ic_minimize)
        minBtn.setPadding(dp(14), dp(12), dp(14), dp(12))
        minBtn.isClickable = true
        minBtn.setOnClickListener { minimize() }
        titleBar.addView(minBtn, LinearLayout.LayoutParams(dp(46), dp(44)))
        maxBtn.setImageResource(R.drawable.ic_maximize)
        maxBtn.setPadding(dp(14), dp(12), dp(14), dp(12))
        maxBtn.isClickable = true
        maxBtn.setOnClickListener { setMode(if (mode == MODE_MAX) MODE_WINDOW else MODE_MAX) }
        titleBar.addView(maxBtn, LinearLayout.LayoutParams(dp(46), dp(44)))
        closeX.setImageResource(R.drawable.ic_close)
        closeX.setPadding(dp(14), dp(12), dp(14), dp(12))
        closeX.isClickable = true
        closeX.setOnClickListener { close() }
        titleBar.addView(closeX, LinearLayout.LayoutParams(dp(46), dp(44)))

        // arrastar pela barra de título; botão direito abre o menu da janela
        titleBar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if ((ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                        showWindowMenu(ev.rawX.toInt(), ev.rawY.toInt())
                    } else {
                        dragSx = ev.rawX
                        dragSy = ev.rawY
                        dragX0 = win.translationX
                        dragY0 = win.translationY
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (mode == MODE_WINDOW) {
                        val sw = act.resources.displayMetrics.widthPixels
                        val sh = act.resources.displayMetrics.heightPixels
                        val maxX = (sw / 2f) - dp(120)
                        val maxY = (sh / 2f) - dp(40)
                        win.translationX = (dragX0 + (ev.rawX - dragSx)).coerceIn(-maxX, maxX)
                        win.translationY = (dragY0 + (ev.rawY - dragSy)).coerceIn(-maxY, maxY)
                    }
                }
            }
            true
        }
        col.addView(titleBar, LinearLayout.LayoutParams(match, dp(44)))
        col.addView(host, LinearLayout.LayoutParams(match, 0, 1f))

        // canto inferior direito: redimensionar (só no modo janela)
        grip = View(act)
        grip.visibility = View.GONE
        win.addView(grip, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))
        var gx = 0f
        var gy = 0f
        var gw0 = 0
        var gh0 = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gx = ev.rawX
                    gy = ev.rawY
                    gw0 = win.width
                    gh0 = win.height
                }
                MotionEvent.ACTION_MOVE -> {
                    val sw = screenW()
                    val sh = screenH()
                    normW = (gw0 + (ev.rawX - gx)).toInt().coerceIn(dp(320), maxOf(dp(320), sw - normX))
                    normH = (gh0 + (ev.rawY - gy)).toInt().coerceIn(dp(360), maxOf(dp(360), sh - normY))
                    sizeWindow()
                }
            }
            true
        }
    }

    private fun screenW(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun screenH(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    // ------------------------------------------------------------ cores

    private fun cText(): Int = if (light()) Color.parseColor("#1F1F1F") else Color.WHITE
    private fun cSub(): Int = if (light()) Color.parseColor("#99000000") else Color.parseColor("#B3FFFFFF")
    private fun cWin(): Int = if (light()) Color.parseColor("#F7F7F7") else Color.parseColor("#232323")
    private fun cNav(): Int = if (light()) Color.parseColor("#EAEAEA") else Color.parseColor("#1C1C1C")
    private fun cLine(): Int = if (light()) Color.parseColor("#D6D6D6") else Color.parseColor("#2E2E2E")
    private fun cRow(): Int = if (light()) Color.parseColor("#0F000000") else Color.parseColor("#14FFFFFF")
    private fun cChip(): Int = if (light()) Color.parseColor("#14000000") else Color.parseColor("#24FFFFFF")

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
        }

    private fun applyTheme() {
        applyWindowStyle()
        titleBar.setBackgroundColor(cNav())
        appName.setTextColor(cText())
        for (iv in listOf(minBtn, maxBtn, closeX)) iv.setColorFilter(cText())
    }

    // ------------------------------------------------------------ componentes de interface

    private fun column(): LinearLayout {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(act)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun heading(parent: LinearLayout, t: String) {
        val tv = label(t, 15f, cText(), true)
        tv.setPadding(0, dp(14), 0, dp(6))
        parent.addView(tv)
    }

    private fun note(parent: LinearLayout, t: String) {
        val tv = label(t, 11.5f, cSub())
        tv.setPadding(0, dp(6), 0, dp(2))
        parent.addView(tv)
    }

    private fun button(parent: LinearLayout, text: String, filled: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(act)
        b.text = text
        b.textSize = 12.5f
        b.setTextColor(if (filled) Color.WHITE else cText())
        b.gravity = Gravity.CENTER
        b.background = rounded(if (filled) accent else cChip(), 6)
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
        return b
    }

    private fun smallButton(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val b = TextView(act)
        b.text = text
        b.textSize = 12f
        b.setTextColor(if (filled) Color.WHITE else cText())
        b.gravity = Gravity.CENTER
        b.background = rounded(if (filled) accent else cChip(), 6)
        b.setPadding(dp(12), dp(7), dp(12), dp(7))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        return b
    }

    private fun switchRow(parent: LinearLayout, text: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val s = Switch(act)
        s.text = text
        s.setTextColor(cText())
        s.textSize = 12.5f
        s.isChecked = value
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(10)
        parent.addView(s, lp)
    }

    /** Mostra [c] dentro de uma rolagem, no corpo da janela. */
    private fun setContent(c: View) {
        host.removeAllViews()
        val sv = ScrollView(act)
        c.setPadding(dp(16), dp(4), dp(16), dp(24))
        sv.addView(c, FrameLayout.LayoutParams(match, wrap))
        host.addView(sv, FrameLayout.LayoutParams(match, match))
    }

    // ------------------------------------------------------------ página: meus jogos

    private fun showGames() {
        page = 0
        PadMapperService.refreshAxesSupport()
        PadStore.load(act)
        lastSig = signature()
        val c = column()

        heading(c, "Mapeador de gamepad")
        note(c, "Use o controle em jogos sem suporte a controle: cada botão vira um toque na tela, nas posições que você escolher.")

        val svc = label(
            if (PadMapperService.running) "Serviço de acessibilidade: ativado" else "Serviço de acessibilidade: desativado",
            12.5f, if (PadMapperService.running) accent else cSub(), true
        )
        svc.setPadding(0, dp(10), 0, 0)
        c.addView(svc)
        if (!PadMapperService.running) {
            note(c, "Ative \"WinLauncher - mapeador de gamepad\" em Acessibilidade. Sem ele não dá para ler o controle, tocar a tela nem usar o ALT + M dentro do jogo.")
            button(c, "Abrir configurações de Acessibilidade", true) {
                try {
                    act.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    act.toast("Não foi possível abrir Acessibilidade")
                }
            }
        }
        switchRow(c, "Mapeamento ligado", PadEngine.masterOn) { on -> PadStore.setMaster(act, on) }

        // como usar
        val how = column()
        how.background = rounded(cRow(), 8)
        how.setPadding(dp(12), dp(10), dp(12), dp(10))
        how.addView(label("Como mapear um jogo", 13f, cText(), true))
        how.addView(label("1. Toque em \"Adicionar jogo\" e escolha o app.\n2. Abra o jogo (o botão \"Abrir jogo\" ajuda).\n3. Com o jogo na frente, aperte ALT + M: o editor aparece sobre o jogo e você posiciona cada botão.\n4. Aperte ALT + M de novo (ou \"Salvar e sair\") para guardar.", 11.5f, cSub()).also { it.setPadding(0, dp(4), 0, 0) })
        c.addView(how, LinearLayout.LayoutParams(match, wrap).also { it.topMargin = dp(12) })

        if (infoLine.isNotEmpty()) {
            val il = label(infoLine, 12f, accent, true)
            il.setPadding(0, dp(10), 0, 0)
            c.addView(il)
        }

        heading(c, "Meus jogos")
        val profiles = ArrayList(PadStore.profiles)
        if (profiles.isEmpty()) note(c, "Nenhum jogo ainda. Toque em \"Adicionar jogo\".")
        for (p in profiles) c.addView(gameRow(p), LinearLayout.LayoutParams(match, wrap).also { it.topMargin = dp(6) })
        button(c, "Adicionar jogo", true) { showPicker() }
        button(c, "Mais opções (Shizuku, ajustes, backup)", false) { showMore() }
        setContent(c)
    }

    private fun gameRow(p: PadProfile): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = rounded(cRow(), 8)
        row.setPadding(dp(10), dp(8), dp(10), dp(8))

        val iv = ImageView(act)
        try {
            iv.setImageDrawable(act.packageManager.getApplicationIcon(p.pkg))
        } catch (e: Exception) {
            iv.setImageDrawable(act.padMapIcon())
        }
        row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))

        val mid = column()
        mid.addView(label(p.name, 13.5f, cText(), true))
        val n = p.activeCount()
        val status = when {
            !p.enabled -> "Desativado"
            n == 0 -> "Ainda não mapeado: abra o jogo e aperte ALT + M"
            else -> n.toString() + (if (n == 1) " botão mapeado" else " botões mapeados")
        }
        mid.addView(label(status, 11f, cSub()))
        row.addView(mid, LinearLayout.LayoutParams(0, wrap, 1f).also { it.leftMargin = dp(10) })

        val sw = Switch(act)
        sw.isChecked = p.enabled
        sw.setOnCheckedChangeListener { _, v ->
            p.enabled = v
            PadStore.save(act)
            PadEngine.notifyProfileEdited()
            ui.removeCallbacks(refreshRun)
            ui.postDelayed(refreshRun, 150L)
        }
        row.addView(sw, LinearLayout.LayoutParams(wrap, wrap).also { it.leftMargin = dp(6) })

        val openBtn = smallButton("Abrir jogo", true) { openGame(p) }
        row.addView(openBtn, LinearLayout.LayoutParams(wrap, wrap).also { it.leftMargin = dp(8) })

        val del = smallButton("Remover", false) { }
        var armedAt = 0L
        del.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - armedAt < 3000L) {
                PadStore.delete(act, p)
                PadEngine.notifyProfileEdited()
                infoLine = "\"" + p.name + "\" saiu da lista."
                showGames()
            } else {
                armedAt = now
                del.text = "Tem certeza?"
                ui.postDelayed({ del.text = "Remover" }, 3000L)
            }
        }
        row.addView(del, LinearLayout.LayoutParams(wrap, wrap).also { it.leftMargin = dp(6) })
        return row
    }

    private fun openGame(p: PadProfile) {
        val i = act.packageManager.getLaunchIntentForPackage(p.pkg)
        if (i == null) {
            act.toast("Não foi possível abrir " + p.name + " (app removido?)")
            return
        }
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
            if (PadMapperService.running && p.activeCount() == 0) {
                MiniToast.info(act, "Com o jogo aberto, aperte ALT + M para mapear.", false)
            }
        } catch (e: Exception) {
            act.toast("Não foi possível abrir " + p.name)
        }
    }

    // ------------------------------------------------------------ página: adicionar jogo

    private class AppRow(val name: String, val pkg: String)

    private fun showPicker() {
        page = 1
        val c = column()
        button(c, "‹ Voltar", false) {
            showGames()
        }
        heading(c, "Adicionar jogo")
        note(c, "Escolha o app do jogo. Ele entra na lista; para mapear, abra o jogo e aperte ALT + M.")

        val apps = ArrayList<AppRow>()
        try {
            val pm = act.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == act.packageName || apps.any { it.pkg == pkg }) continue
                if (PadStore.profileFor(pkg) != null) continue
                apps.add(AppRow(ri.loadLabel(pm).toString(), pkg))
            }
        } catch (e: Exception) {
        }
        apps.sortBy { it.name.lowercase() }

        val search = EditText(act)
        search.hint = "Buscar app"
        search.setTextColor(cText())
        search.setHintTextColor(cSub())
        search.textSize = 13f
        search.setSingleLine(true)
        c.addView(search, LinearLayout.LayoutParams(match, wrap))
        val list = column()
        c.addView(list)

        fun fill(filter: String) {
            list.removeAllViews()
            val f = filter.trim().lowercase()
            var shown = 0
            for (app in apps) {
                if (f.isNotEmpty() && !app.name.lowercase().contains(f)) continue
                if (shown >= 80) break
                shown++
                val r = LinearLayout(act)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.background = rounded(cRow(), 8)
                r.setPadding(dp(10), dp(8), dp(10), dp(8))
                val iv = ImageView(act)
                try {
                    iv.setImageDrawable(act.packageManager.getApplicationIcon(app.pkg))
                } catch (e: Exception) {
                }
                r.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)))
                val mid = column()
                mid.addView(label(app.name, 13f, cText(), true))
                mid.addView(label(app.pkg, 10.5f, cSub()))
                r.addView(mid, LinearLayout.LayoutParams(0, wrap, 1f).also { it.leftMargin = dp(10) })
                r.isClickable = true
                r.setOnClickListener {
                    PadStore.getOrCreate(act, app.pkg, app.name)
                    PadEngine.notifyProfileEdited()
                    infoLine = "\"" + app.name + "\" foi adicionado. Abra o jogo e aperte ALT + M para mapear."
                    showGames()
                }
                list.addView(r, LinearLayout.LayoutParams(match, wrap).also { it.topMargin = dp(4) })
            }
            if (shown == 0) note(list, "Nenhum app encontrado.")
        }
        fill("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c1: Int, a1: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c1: Int) {}
            override fun afterTextChanged(s: Editable?) {
                fill(s?.toString() ?: "")
            }
        })
        setContent(c)
    }

    // ------------------------------------------------------------ página: mais opções (painel completo)

    private fun showMore() {
        page = 2
        host.removeAllViews()
        val col = column()
        val bar = column()
        bar.setPadding(dp(16), dp(4), dp(16), dp(0))
        button(bar, "‹ Voltar para meus jogos", false) { showGames() }
        col.addView(bar, LinearLayout.LayoutParams(match, wrap))
        val sv = ScrollView(act)
        sv.addView(PadPanel(act, !light()).build(), FrameLayout.LayoutParams(match, wrap))
        sv.setPadding(dp(16), 0, dp(16), dp(24))
        sv.clipToPadding = false
        col.addView(sv, LinearLayout.LayoutParams(match, 0, 1f))
        host.addView(col, FrameLayout.LayoutParams(match, match))
    }

    // ------------------------------------------------------------ ciclo de vida da janela

    /** Atualiza o ícone e o nome da barra de título (depois de trocar o ícone do app). */
    fun refreshIcon() {
        appIcon.setImageDrawable(act.padMapIcon())
        appName.text = AppCustom.label(act, AppCustom.PADMAP, "Mapeador de gamepad")
    }

    /** Miniatura da janela para a barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap

    /** Botão voltar do Android: volta de uma subpágina ou fecha a janela. */
    fun handleBack(): Boolean {
        if (!open || minimized) return false
        if (page != 0) {
            showGames()
            return true
        }
        close()
        return true
    }

    /** Coloca a janela na pilha das janelas, logo abaixo do menu (mesma regra das outras janelas). */
    fun attachBelow(menuLayer: View) {
        stackAbove = menuLayer
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(match, match))
    }

    fun show() {
        applyTheme()
        if (open && !minimized) {
            WindowStack.raise(root, layer, stackAbove)
            return
        }
        val wasClosed = !open
        open = true
        minimized = false
        sizeWindow()
        WindowStack.raise(root, layer, stackAbove)
        layer.visibility = View.VISIBLE
        layer.animate().cancel()
        layer.alpha = 0f
        layer.animate().alpha(1f).setDuration(160L).start()
        if (wasClosed) infoLine = ""
        if (!listening) {
            listening = true
            PadEngine.addListener(engineListener)
        }
        if (wasClosed || page == 0) showGames()
        onStateChange?.invoke()
    }

    fun minimize() {
        if (!open || minimized) return
        lastSnap = snapView(win, 480)
        minimized = true
        layer.animate().cancel()
        layer.animate().alpha(0f).setDuration(120L).withEndAction {
            if (minimized) layer.visibility = View.GONE
        }.start()
        onStateChange?.invoke()
    }

    fun restore() {
        if (!open || !minimized) return
        show()
    }

    /** Clique no ícone da barra de tarefas: restaura se minimizada, minimiza se estiver à frente. */
    fun toggleFromTaskbar() {
        when {
            minimized -> restore()
            !WindowStack.isTop(root, layer, stackAbove) -> WindowStack.raise(root, layer, stackAbove)
            else -> minimize()
        }
    }

    /** ALT + M com o launcher na frente: abre; se já estiver aberta e à frente, fecha. */
    fun toggleFromShortcut() {
        if (open && !minimized) close() else show()
    }

    fun close() {
        if (!open) return
        open = false
        minimized = false
        lastSnap = null
        mode = MODE_WINDOW
        placed = false
        normW = 0
        normH = 0
        page = 0
        win.translationX = 0f
        win.translationY = 0f
        ui.removeCallbacks(refreshRun)
        if (listening) {
            listening = false
            PadEngine.removeListener(engineListener)
        }
        host.removeAllViews()
        layer.animate().cancel()
        layer.animate().alpha(0f).setDuration(120L).withEndAction {
            if (!open) layer.visibility = View.GONE
        }.start()
        onStateChange?.invoke()
    }

    private fun setMode(m: Int) {
        if (m == mode) return
        mode = m
        sizeWindow()
    }

    private fun showWindowMenu(x: Int, y: Int) {
        val items = arrayListOf(
            MenuItem("Minimizar", R.drawable.ic_minimize, action = { minimize() }),
            MenuItem(
                if (mode == MODE_MAX) "Restaurar" else "Maximizar",
                if (mode == MODE_MAX) R.drawable.ic_restore else R.drawable.ic_maximize,
                action = { setMode(if (mode == MODE_MAX) MODE_WINDOW else MODE_MAX) }
            ),
            MenuItem("Fechar", R.drawable.ic_close, action = { close() })
        )
        act.menu.show(items, x, y)
    }

    // ------------------------------------------------------------ tamanho

    private fun sizeWindow() {
        val sw = screenW()
        val sh = screenH()
        val ins = act.taskbarInsetsPx()
        val availH = sh - ins.first - ins.second
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.TOP or Gravity.START
        if (mode == MODE_MAX) {
            lp.width = sw
            lp.height = availH
            lp.leftMargin = 0
            lp.topMargin = ins.first
            win.translationX = 0f
            win.translationY = 0f
        } else {
            if (normW == 0) normW = min(dp(560), sw - dp(24))
            if (normH == 0) normH = min(dp(600), availH - dp(24))
            val w = normW.coerceIn(min(dp(320), sw), sw)
            val h = normH.coerceIn(min(dp(360), availH), availH)
            if (!placed) {
                normX = (sw - w) / 2
                normY = ins.first + (availH - h) / 2
                placed = true
            }
            lp.width = w
            lp.height = h
            lp.leftMargin = normX.coerceIn(0, maxOf(0, sw - w))
            lp.topMargin = normY.coerceIn(0, maxOf(0, sh - h))
        }
        win.layoutParams = lp
        applyWindowStyle()
    }

    private fun applyWindowStyle() {
        val r = if (mode == MODE_WINDOW) 10 else 0
        val bg = GradientDrawable()
        bg.setColor(cWin())
        bg.cornerRadius = dp(r).toFloat()
        bg.setStroke(if (mode == MODE_WINDOW) dp(1) else 0, cLine())
        win.background = bg
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
            }
        }
        win.clipToOutline = true
        win.invalidateOutline()
        maxBtn.setImageResource(if (mode == MODE_MAX) R.drawable.ic_restore else R.drawable.ic_maximize)
        grip.visibility = if (mode == MODE_WINDOW) View.VISIBLE else View.GONE
    }
}
