package com.example.winlauncher

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Navegador embutido do WinLauncher. Janela autônoma no mesmo estilo das demais (arrasta pela barra de
 * título, minimiza para a barra de tarefas), com três modos:
 *  - janela: tamanho livre (arraste o canto inferior direito para redimensionar);
 *  - maximizada: ocupa a tela inteira mas deixa a barra de tarefas visível;
 *  - tela cheia: ocupa a tela toda, inclusive por cima da barra de tarefas.
 *
 * Usa o WebView do sistema (sem bibliotecas extras) e abre sites no modo computador por padrão
 * (o user-agent de PC pode ser desligado no menu ⋮). Tem abas, barra de endereço, voltar/avançar/recarregar,
 * downloads, envio de arquivos e vídeo em tela cheia.
 */
class BrowserWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    /** Espaço ocupado pela barra de tarefas em px: (topo, base). Usado no modo maximizado. */
    private val taskbarInsets: () -> Pair<Int, Int>
) {

    companion object {
        const val REQ_FILE = 19
        val LEVELS = listOf(50, 75, 90, 100, 110, 125, 150, 175, 200, 250, 300)
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val HOME = "https://www.google.com"
        private const val SEARCH = "https://www.google.com/search?q="
        private const val MODE_WINDOW = 0
        private const val MODE_MAX = 1
        private const val MODE_FULL = 2
    }

    private class Tab(val web: WebView) {
        var title = "Nova aba"
        var url = ""
        var icon: Bitmap? = null
        var progress = 100
        var loading = false
    }

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    /** Avisado quando abre, minimiza, restaura ou fecha (a barra de tarefas se redesenha). */
    var onStateChange: (() -> Unit)? = null

    val isOpen: Boolean get() = open
    val isMinimized: Boolean get() = minimized

    /** Última foto da janela (usada na janelinha da barra de tarefas quando ela está minimizada). */
    private var lastSnap: Bitmap? = null

    /** Miniatura da janela para a janelinha da barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val store = act.getSharedPreferences("win", Context.MODE_PRIVATE)

    private val ink = Color.parseColor("#F2F5FA")
    private val sub = Color.parseColor("#A9B3C6")
    private val accent = Color.parseColor("#3D9DFF")
    private val cBgTop = Color.parseColor("#111A33")
    private val cBgBot = Color.parseColor("#0A0F1F")
    private val cLine = Color.parseColor("#26FFFFFF")

    private var open = false
    private var minimized = false
    private var placed = false
    private var mode = MODE_WINDOW
    private var modeBeforeFull = MODE_WINDOW
    // padrão: modo celular (layout igual ao do Chrome do Android); chave nova para ignorar o valor antigo
    private var desktopMode = store.getBoolean("browserDesktop2", false)
    // zoom do texto (%) e escala da página (%), valem para todas as abas e ficam salvos
    private var titleIcon: ImageView? = null

    /** Atualiza o ícone da barra de título (depois de trocar o ícone do navegador). */
    fun refreshIcon() {
        titleIcon?.setImageDrawable(act.browserIcon())
    }

    private var zoomPct = store.getInt("browserZoom", 100)
    private var scalePct = store.getInt("browserScale", 100)

    // tamanho/posição da janela livre (px); 0 = ainda não calculado
    private var normW = 0
    private var normH = 0
    private var normX = 0f
    private var normY = 0f

    private val tabs = ArrayList<Tab>()
    private var cur = -1

    private lateinit var win: FrameLayout
    private lateinit var titleBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var maxBtn: ImageView
    private lateinit var fullBtn: ImageView
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var tabRow: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var backBtn: ImageView
    private lateinit var fwdBtn: ImageView
    private lateinit var reloadBtn: ImageView
    private lateinit var addr: EditText
    private lateinit var progress: ProgressLine
    private lateinit var webHost: FrameLayout
    private lateinit var grip: View
    private lateinit var fsBar: LinearLayout

    // vídeo em tela cheia (botão de tela cheia do player do site)
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val customHolder = FrameLayout(act)

    // envio de arquivos (<input type="file">)
    private var fileCb: ValueCallback<Array<Uri>>? = null

    init {
        build()
        root.addOnLayoutChangeListener { _, l, t, r, b, oL, oT, oR, oB ->
            if (open && !minimized && mode != MODE_WINDOW && (r - l != oR - oL || b - t != oB - oT)) {
                win.post { sizeWindow() }
            }
        }
    }

    // ================================================================== API pública

    /** Abre o navegador (ou restaura se minimizado). Com [url], abre o endereço numa nova aba. */
    fun show(url: String? = null) {
        if (open) {
            if (minimized) restore()
            if (url != null) newTab(normalize(url), true)
            return
        }
        open = true
        minimized = false
        win.animate().cancel()
        if (tabs.isEmpty()) newTab(normalize(url ?: HOME), true)
        sizeWindow()
        showAnimated()
        onStateChange?.invoke()
    }

    fun minimize() {
        if (!open || minimized) return
        lastSnap = snapView(win, 480)
        minimized = true
        hideKeyboard()
        hideAnimated()
        onStateChange?.invoke()
    }

    fun restore() {
        if (!open || !minimized) return
        minimized = false
        sizeWindow()
        showAnimated()
        onStateChange?.invoke()
    }

    /** Clique no ícone da barra de tarefas: restaura se minimizada, minimiza se estiver à frente. */
    fun toggleFromTaskbar() {
        if (minimized) restore() else minimize()
    }

    /** Fecha a janela e libera todas as abas. */
    fun close() {
        if (!open) return
        hideCustomView()
        hideKeyboard()
        lastSnap = null
        open = false
        minimized = false
        mode = MODE_WINDOW
        for (t in tabs) destroyWeb(t.web)
        tabs.clear()
        cur = -1
        webHost.removeAllViews()
        placed = false
        normW = 0
        normH = 0
        hideAnimated()
        onStateChange?.invoke()
    }

    /** Botão voltar do Android: sai do vídeo/tela cheia ou volta uma página. Retorna true se consumiu. */
    fun handleBack(): Boolean {
        if (!open || minimized) return false
        if (customView != null) {
            hideCustomView()
            return true
        }
        if (mode == MODE_FULL) {
            setMode(modeBeforeFull)
            return true
        }
        val t = tabs.getOrNull(cur) ?: return false
        if (t.web.canGoBack()) {
            t.web.goBack()
            return true
        }
        return false
    }

    /** Resultado do seletor de arquivos aberto por uma página. */
    fun onFileChosen(resultCode: Int, data: Intent?) {
        val cb = fileCb ?: return
        fileCb = null
        val res = if (resultCode == android.app.Activity.RESULT_OK) {
            WebChromeClient.FileChooserParams.parseResult(resultCode, data)
        } else {
            null
        }
        cb.onReceiveValue(res)
    }

    /** Insere a janela logo abaixo da camada do menu de contexto (o menu continua por cima). */
    fun attachBelow(menuLayer: View) {
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ================================================================== animações

    private fun showAnimated() {
        win.animate().cancel()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open || minimized) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    private fun hideAnimated() {
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (!open || minimized) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    // ================================================================== modos / tamanho / posição

    private fun screenW(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun screenH(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    private fun setMode(m: Int) {
        if (m == mode) return
        if (m == MODE_FULL) modeBeforeFull = if (mode == MODE_FULL) MODE_WINDOW else mode
        if (mode == MODE_WINDOW) {
            normX = win.x
            normY = win.y
        }
        mode = m
        sizeWindow()
        place()
    }

    private fun toggleMax() {
        setMode(if (mode == MODE_MAX) MODE_WINDOW else MODE_MAX)
    }

    private fun toggleFull() {
        setMode(if (mode == MODE_FULL) modeBeforeFull else MODE_FULL)
    }

    private fun sizeWindow() {
        val sw = screenW()
        val sh = screenH()
        val ins = taskbarInsets()
        if (normW == 0) {
            normW = minOf(sw - dp(24), dp(980))
            normH = minOf(sh - ins.first - ins.second - dp(40), dp(640))
        }
        val w: Int
        val h: Int
        when (mode) {
            MODE_MAX -> {
                w = sw
                h = sh - ins.first - ins.second
            }
            MODE_FULL -> {
                w = sw
                h = sh
            }
            else -> {
                w = normW.coerceIn(minOf(dp(300), sw), sw)
                h = normH.coerceIn(minOf(dp(260), sh), sh)
            }
        }
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        lp.height = h
        win.layoutParams = lp
        applyModeStyle()
    }

    private fun applyModeStyle() {
        val full = mode == MODE_FULL
        val r = if (mode == MODE_WINDOW) 10 else 0
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cBgTop, cBgBot))
        bg.cornerRadius = dp(r).toFloat()
        bg.setStroke(if (mode == MODE_WINDOW) dp(1) else 0, cLine)
        win.background = bg
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
                outline.alpha = 0.6f
            }
        }
        win.invalidateOutline()
        titleBar.visibility = if (full) View.GONE else View.VISIBLE
        tabScroll.visibility = if (full) View.GONE else View.VISIBLE
        toolbar.visibility = if (full) View.GONE else View.VISIBLE
        progress.visibility = if (full) View.GONE else View.VISIBLE
        fsBar.visibility = if (full) View.VISIBLE else View.GONE
        grip.visibility = if (mode == MODE_WINDOW) View.VISIBLE else View.GONE
        maxBtn.setImageResource(if (mode == MODE_MAX) R.drawable.ic_restore else R.drawable.ic_maximize)
        fullBtn.setImageResource(R.drawable.ic_fullscreen)
    }

    private fun place() {
        when (mode) {
            MODE_MAX -> {
                win.x = 0f
                win.y = taskbarInsets().first.toFloat()
            }
            MODE_FULL -> {
                win.x = 0f
                win.y = 0f
            }
            else -> {
                if (!placed) {
                    normX = ((screenW() - win.width) / 2f).coerceAtLeast(dp(8).toFloat())
                    normY = ((screenH() - win.height) / 2f - dp(16)).coerceAtLeast(dp(8).toFloat())
                    placed = true
                }
                moveTo(normX, normY)
            }
        }
    }

    private fun moveTo(nx: Float, ny: Float) {
        if (mode != MODE_WINDOW) return
        val minX = -(win.width - dp(96)).toFloat()
        val maxX = (screenW() - dp(96)).toFloat()
        val maxY = (screenH() - dp(48)).toFloat().coerceAtLeast(0f)
        win.x = nx.coerceIn(minX, maxOf(minX, maxX))
        win.y = ny.coerceIn(0f, maxY)
        normX = win.x
        normY = win.y
    }

    // ================================================================== construção da interface

    private fun rr(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun build() {
        layer.tag = CursorController.NOHAND

        win = FrameLayout(act)
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.elevation = dp(16).toFloat()
        win.clipToOutline = true

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        titleBar = buildTitleBar()
        col.addView(titleBar, LinearLayout.LayoutParams(MATCH, dp(40)))

        tabScroll = HorizontalScrollView(act)
        tabScroll.isHorizontalScrollBarEnabled = false
        tabScroll.overScrollMode = View.OVER_SCROLL_NEVER
        tabRow = LinearLayout(act)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.gravity = Gravity.CENTER_VERTICAL
        tabRow.setPadding(dp(8), 0, dp(8), 0)
        tabScroll.addView(tabRow, FrameLayout.LayoutParams(WRAP, MATCH))
        col.addView(tabScroll, LinearLayout.LayoutParams(MATCH, dp(34)))

        toolbar = buildToolbar()
        col.addView(toolbar, LinearLayout.LayoutParams(MATCH, dp(42)))

        progress = ProgressLine(act)
        col.addView(progress, LinearLayout.LayoutParams(MATCH, dp(2)))

        webHost = FrameLayout(act)
        webHost.setBackgroundColor(Color.WHITE)
        col.addView(webHost, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // canto inferior direito: redimensionar (só no modo janela)
        grip = GripView(act)
        grip.visibility = View.GONE
        win.addView(grip, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))
        var sx = 0f
        var sy = 0f
        var sw0 = 0
        var sh0 = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX
                    sy = ev.rawY
                    sw0 = win.width
                    sh0 = win.height
                }
                MotionEvent.ACTION_MOVE -> {
                    normW = (sw0 + (ev.rawX - sx)).toInt().coerceIn(dp(300), maxOf(dp(300), screenW() - win.x.toInt()))
                    normH = (sh0 + (ev.rawY - sy)).toInt().coerceIn(dp(260), maxOf(dp(260), screenH() - win.y.toInt()))
                    sizeWindow()
                }
            }
            true
        }

        // tela cheia: só dois botões discretos no canto superior direito (voltar para janela e fechar)
        fsBar = LinearLayout(act)
        fsBar.orientation = LinearLayout.HORIZONTAL
        fsBar.background = rr(Color.parseColor("#8C000000"), 10)
        fsBar.alpha = 0.7f
        fsBar.visibility = View.GONE
        fsBar.addView(titleButton(R.drawable.ic_restore, false) { setMode(MODE_WINDOW) }, LinearLayout.LayoutParams(dp(34), dp(30)))
        fsBar.addView(titleButton(R.drawable.ic_close, true) { close() }, LinearLayout.LayoutParams(dp(34), dp(30)))
        win.addView(fsBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4)
            rightMargin = dp(4)
        })

        layer.addView(win, FrameLayout.LayoutParams(dp(900), dp(600), Gravity.TOP or Gravity.START))

        customHolder.setBackgroundColor(Color.BLACK)
        customHolder.visibility = View.GONE
        customHolder.isClickable = true
        layer.addView(customHolder, FrameLayout.LayoutParams(MATCH, MATCH))

        applyModeStyle()
    }

    private fun buildTitleBar(): LinearLayout {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(10), 0, dp(4), 0)

        val ic = ImageView(act)
        ic.setImageDrawable(act.browserIcon())
        titleIcon = ic
        bar.addView(ic, LinearLayout.LayoutParams(dp(20), dp(20)))

        titleText = TextView(act)
        titleText.text = "Navegador"
        titleText.setTextColor(ink)
        titleText.textSize = 13f
        titleText.maxLines = 1
        titleText.ellipsize = TextUtils.TruncateAt.END
        titleText.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        bar.addView(titleText, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(10) })

        bar.addView(titleButton(R.drawable.ic_minimize, false) { minimize() }, LinearLayout.LayoutParams(dp(36), dp(34)))
        maxBtn = titleButton(R.drawable.ic_maximize, false) { toggleMax() }
        bar.addView(maxBtn, LinearLayout.LayoutParams(dp(36), dp(34)))
        fullBtn = titleButton(R.drawable.ic_fullscreen, false) { toggleFull() }
        bar.addView(fullBtn, LinearLayout.LayoutParams(dp(36), dp(34)))
        bar.addView(titleButton(R.drawable.ic_close, true) { close() }, LinearLayout.LayoutParams(dp(36), dp(34)))

        var offX = 0f
        var offY = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                }
                MotionEvent.ACTION_MOVE -> moveTo(ev.rawX + offX, ev.rawY + offY)
            }
            true
        }
        return bar
    }

    private fun buildToolbar(): LinearLayout {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), dp(3), dp(4), dp(3))

        backBtn = titleButton(R.drawable.ic_arrow_left, false) { tabs.getOrNull(cur)?.web?.let { if (it.canGoBack()) it.goBack() } }
        fwdBtn = titleButton(R.drawable.ic_arrow_right, false) { tabs.getOrNull(cur)?.web?.let { if (it.canGoForward()) it.goForward() } }
        reloadBtn = titleButton(R.drawable.ic_refresh, false) {
            val t = tabs.getOrNull(cur)
            if (t != null) {
                if (t.loading) t.web.stopLoading() else t.web.reload()
            }
        }
        bar.addView(backBtn, LinearLayout.LayoutParams(dp(36), dp(36)))
        bar.addView(fwdBtn, LinearLayout.LayoutParams(dp(36), dp(36)))
        bar.addView(reloadBtn, LinearLayout.LayoutParams(dp(36), dp(36)))

        addr = EditText(act)
        addr.hint = "Pesquise ou digite um endereço"
        addr.setHintTextColor(sub)
        addr.setTextColor(ink)
        addr.textSize = 13.5f
        addr.setSingleLine(true)
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        addr.imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        addr.setSelectAllOnFocus(true)
        addr.setPadding(dp(14), 0, dp(14), 0)
        addr.background = rr(Color.parseColor("#1AFFFFFF"), 18)
        addr.setOnEditorActionListener { _, _, _ ->
            val t = tabs.getOrNull(cur)
            if (t != null) {
                t.web.loadUrl(normalize(addr.text.toString()))
                hideKeyboard()
                addr.clearFocus()
                t.web.requestFocus()
            }
            true
        }
        bar.addView(addr, LinearLayout.LayoutParams(0, MATCH, 1f).apply {
            leftMargin = dp(4)
            rightMargin = dp(4)
        })

        val more = titleButton(R.drawable.ic_more, false) { }
        more.setOnClickListener { v ->
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            act.menu.show(moreItems(), loc[0], loc[1] + v.height)
        }
        bar.addView(more, LinearLayout.LayoutParams(dp(36), dp(36)))
        return bar
    }

    private fun moreItems(): List<MenuItem> = listOf(
        MenuItem("Nova aba", R.drawable.ic_plus, action = { newTab(HOME, true) }),
        MenuItem("Página inicial", R.drawable.ic_start, action = { tabs.getOrNull(cur)?.web?.loadUrl(HOME) }),
        MenuItem("Abrir no navegador do Android", R.drawable.ic_open, action = {
            val u = tabs.getOrNull(cur)?.url ?: ""
            if (u.startsWith("http")) {
                try {
                    act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }
        }),
        MenuItem("Configurações", R.drawable.ic_settings, children = settingsItems())
    )

    /** Submenu "Configurações" do ⋮ (igual ao do Chrome): modo, zoom, escala, ícone e dados. */
    private fun settingsItems(): List<MenuItem> = listOf(
        MenuItem("Modo celular", checked = !desktopMode, action = { if (desktopMode) setDesktopMode(false) }),
        MenuItem("Modo computador", checked = desktopMode, action = { if (!desktopMode) setDesktopMode(true) }),
        MenuItem("Zoom (" + zoomPct + "%)", children = LEVELS.map { v ->
            MenuItem(v.toString() + "%", checked = v == zoomPct, action = { setZoom(v) })
        }),
        MenuItem("Escala (" + scalePct + "%)", children = LEVELS.map { v ->
            MenuItem(v.toString() + "%", checked = v == scalePct, action = { setScale(v) })
        }),
        MenuItem("Trocar ícone do navegador", R.drawable.ic_image, action = { act.changeBrowserIcon() }),
        MenuItem("Limpar dados de navegação", R.drawable.ic_delete, action = { clearData() })
    )

    private fun titleButton(res: Int, danger: Boolean, onClick: () -> Unit): ImageView {
        val b = ImageView(act)
        b.setImageResource(res)
        b.setColorFilter(ink)
        b.setPadding(dp(9), dp(9), dp(9), dp(9))
        b.isClickable = true
        b.background = btnBg(false, danger)
        b.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = btnBg(true, danger)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = btnBg(false, danger)
            }
            false
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun btnBg(hover: Boolean, danger: Boolean): GradientDrawable =
        rr(
            when {
                !hover -> Color.TRANSPARENT
                danger -> Color.parseColor("#40E5484D")
                else -> Color.parseColor("#26FFFFFF")
            },
            8
        )

    // ================================================================== abas

    private fun newTab(url: String, foreground: Boolean): Tab {
        val t = Tab(createWeb())
        t.url = url
        tabs.add(t)
        if (foreground || cur < 0) switchTab(tabs.size - 1) else renderTabs()
        t.web.loadUrl(url)
        return t
    }

    private fun switchTab(i: Int) {
        if (i < 0 || i >= tabs.size) return
        webHost.removeAllViews()
        cur = i
        val t = tabs[i]
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        webHost.addView(t.web, FrameLayout.LayoutParams(MATCH, MATCH))
        t.web.onResume()
        refreshChrome()
        renderTabs()
    }

    private fun closeTab(i: Int) {
        if (i < 0 || i >= tabs.size) return
        val t = tabs.removeAt(i)
        destroyWeb(t.web)
        if (tabs.isEmpty()) {
            cur = -1
            close()
            return
        }
        val next = when {
            i < cur -> cur - 1
            i == cur -> minOf(i, tabs.size - 1)
            else -> cur
        }
        webHost.removeAllViews()
        switchTab(next)
    }

    private fun renderTabs() {
        tabRow.removeAllViews()
        for (i in tabs.indices) {
            val t = tabs[i]
            val chip = LinearLayout(act)
            chip.orientation = LinearLayout.HORIZONTAL
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(8), 0, dp(2), 0)
            chip.background = rr(Color.parseColor(if (i == cur) "#2CFFFFFF" else "#0FFFFFFF"), 8)
            chip.isClickable = true
            chip.setOnClickListener { switchTab(i) }

            val fav = ImageView(act)
            val ic = t.icon
            if (ic != null) fav.setImageBitmap(ic) else fav.setImageResource(R.drawable.ic_browser)
            chip.addView(fav, LinearLayout.LayoutParams(dp(14), dp(14)))

            val tt = TextView(act)
            tt.text = t.title
            tt.setTextColor(if (i == cur) ink else sub)
            tt.textSize = 12f
            tt.maxLines = 1
            tt.ellipsize = TextUtils.TruncateAt.END
            tt.maxWidth = dp(130)
            chip.addView(tt, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) })

            val x = ImageView(act)
            x.setImageResource(R.drawable.ic_close)
            x.setColorFilter(sub)
            x.setPadding(dp(6), dp(6), dp(6), dp(6))
            x.isClickable = true
            x.setOnClickListener { closeTab(i) }
            chip.addView(x, LinearLayout.LayoutParams(dp(26), dp(26)))

            tabRow.addView(chip, LinearLayout.LayoutParams(WRAP, dp(28)).apply { rightMargin = dp(4) })
        }
        val plus = titleButton(R.drawable.ic_plus, false) { newTab(HOME, true) }
        plus.setPadding(dp(6), dp(6), dp(6), dp(6))
        tabRow.addView(plus, LinearLayout.LayoutParams(dp(28), dp(28)))
    }

    /** Atualiza título, endereço, progresso e botões conforme a aba ativa. */
    private fun refreshChrome() {
        val t = tabs.getOrNull(cur) ?: return
        titleText.text = if (t.title.isBlank()) "Navegador" else t.title
        if (!addr.hasFocus()) addr.setText(if (t.url == "about:blank") "" else t.url)
        progress.fraction = if (t.loading) t.progress / 100f else 0f
        reloadBtn.setImageResource(if (t.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        backBtn.alpha = if (t.web.canGoBack()) 1f else 0.35f
        fwdBtn.alpha = if (t.web.canGoForward()) 1f else 0.35f
    }

    private fun tabOf(web: WebView): Tab? = tabs.firstOrNull { it.web === web }

    // ================================================================== WebView

    private fun createWeb(): WebView {
        val w = WebView(act)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.mediaPlaybackRequiresUserGesture = true
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(true)
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setGeolocationEnabled(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = WebSettings.LOAD_DEFAULT
        applyUa(w)
        w.settings.textZoom = zoomPct
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.setBackgroundColor(Color.WHITE)
        w.isFocusable = true
        w.isFocusableInTouchMode = true

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                val sc = request.url.scheme ?: ""
                if (sc == "http" || sc == "https" || sc == "about" || sc == "data" || sc == "blob") return false
                openExternal(u)
                return true
            }

            /** Bloqueia o pop-up automático "Fazer login com o Google" (One Tap). O login manual continua funcionando. */
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                val host = u.host ?: ""
                val path = u.path ?: ""
                if (host == "accounts.google.com" && (path.startsWith("/gsi/") || path.startsWith("/o/oauth2/iframe"))) {
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                hideLoginPrompts(view)
                if (scalePct != 100) applyScale(view)
                val t = tabOf(view) ?: return
                t.url = url ?: t.url
                t.loading = true
                t.progress = 5
                if (favicon != null) t.icon = favicon
                if (tabs.getOrNull(cur) === t) refreshChrome()
                renderTabs()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                hideLoginPrompts(view)
                if (scalePct != 100) applyScale(view)
                val t = tabOf(view) ?: return
                t.url = url ?: t.url
                t.loading = false
                t.progress = 100
                if (!view.title.isNullOrBlank()) t.title = view.title!!
                if (tabs.getOrNull(cur) === t) refreshChrome()
                renderTabs()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                val t = tabOf(view) ?: return
                if (url != null) t.url = url
                if (tabs.getOrNull(cur) === t) refreshChrome()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                val u = request.url.toString()
                val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                    "<body style='margin:0;background:#0A0F1F;color:#F2F5FA;font-family:sans-serif;" +
                    "display:flex;align-items:center;justify-content:center;height:100vh;text-align:center'>" +
                    "<div style='padding:24px'><h2 style='margin:0 0 8px'>Não foi possível abrir a página</h2>" +
                    "<p style='color:#A9B3C6;margin:0 0 6px;word-break:break-all'>" + android.text.TextUtils.htmlEncode(u) + "</p>" +
                    "<p style='color:#A9B3C6;margin:0'>" + android.text.TextUtils.htmlEncode(error.description?.toString() ?: "") + "</p>" +
                    "</div></body></html>"
                view.loadDataWithBaseURL(u, html, "text/html", "utf-8", u)
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                val t = tabOf(view) ?: return
                t.progress = newProgress
                if (tabs.getOrNull(cur) === t) progress.fraction = if (t.loading) newProgress / 100f else 0f
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                val t = tabOf(view) ?: return
                if (!title.isNullOrBlank()) t.title = title
                if (tabs.getOrNull(cur) === t) refreshChrome()
                renderTabs()
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                val t = tabOf(view) ?: return
                t.icon = icon
                renderTabs()
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val nt = Tab(createWeb())
                tabs.add(nt)
                switchTab(tabs.size - 1)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = nt.web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val i = tabs.indexOfFirst { it.web === window }
                if (i >= 0) closeTab(i)
            }

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                return try {
                    act.startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    callback.onReceiveValue(null)
                    false
                }
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCb = callback
                customHolder.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
                customHolder.visibility = View.VISIBLE
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            // câmera, microfone e localização ficam bloqueados (navegador leve)
            override fun onPermissionRequest(request: PermissionRequest) {
                request.deny()
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, false, false)
            }
        }

        w.setDownloadListener { url, ua, cd, mime, _ -> download(url, ua, cd, mime) }
        return w
    }

    private fun hideCustomView() {
        val v = customView ?: return
        customHolder.removeView(v)
        customHolder.visibility = View.GONE
        customView = null
        try {
            customCb?.onCustomViewHidden()
        } catch (e: Exception) {
        }
        customCb = null
    }

    private fun destroyWeb(w: WebView) {
        try {
            w.stopLoading()
            w.webChromeClient = null
            (w.parent as? ViewGroup)?.removeView(w)
            w.destroy()
        } catch (e: Exception) {
        }
    }

    // ---- user-agent de computador

    private fun desktopUa(): String {
        val def = WebSettings.getDefaultUserAgent(act)
        val major = Regex("Chrome/(\\d+)").find(def)?.groupValues?.get(1) ?: "124"
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/$major.0.0.0 Safari/537.36"
    }

    private fun applyUa(w: WebView) {
        w.settings.userAgentString = if (desktopMode) desktopUa() else null
    }

    // ---- zoom (tamanho do texto) e escala (tamanho de toda a página)

    /** Esconde os avisos/pop-ups de "entrar com o Google" que ficam aparecendo nas páginas. */
    private fun hideLoginPrompts(w: WebView) {
        val js = "(function(){var id='__nologin';if(document.getElementById(id))return;" +
            "var st=document.createElement('style');st.id=id;" +
            "st.textContent='#credential_picker_container,#credential_picker_iframe," +
            "iframe[src*=\\\"accounts.google.com/gsi\\\"],iframe[src*=\\\"accounts.google.com/o/oauth2/iframe\\\"]," +
            "g-one-tap,#google-one-tap-popup-container{display:none!important}';" +
            "(document.head||document.documentElement).appendChild(st);})()"
        w.evaluateJavascript(js, null)
    }

    private fun applyScale(w: WebView) {
        val f = scalePct / 100.0
        w.evaluateJavascript("(function(){document.documentElement.style.zoom='" + f + "';})()", null)
    }

    private fun setZoom(v: Int) {
        zoomPct = v
        store.edit().putInt("browserZoom", v).apply()
        for (t in tabs) t.web.settings.textZoom = v
        Toast.makeText(act, "Zoom $v%", Toast.LENGTH_SHORT).show()
    }

    private fun setScale(v: Int) {
        scalePct = v
        store.edit().putInt("browserScale", v).apply()
        for (t in tabs) applyScale(t.web)
        Toast.makeText(act, "Escala $v%", Toast.LENGTH_SHORT).show()
    }

    private fun setDesktopMode(on: Boolean) {
        desktopMode = on
        store.edit().putBoolean("browserDesktop2", on).apply()
        for (t in tabs) applyUa(t.web)
        tabs.getOrNull(cur)?.web?.reload()
        Toast.makeText(act, if (on) "Modo computador ligado" else "Modo celular ligado", Toast.LENGTH_SHORT).show()
    }

    // ---- navegação

    private fun normalize(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return HOME
        if (!t.contains(' ') && (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(t) || t.startsWith("about:") || t.startsWith("data:"))) return t
        val local = t.startsWith("localhost") || Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(t)
        if (!t.contains(' ') && local) return "http://$t"
        if (!t.contains(' ') && t.contains('.')) return "https://$t"
        return SEARCH + Uri.encode(t)
    }

    private fun openExternal(u: String) {
        try {
            val i = if (u.startsWith("intent:")) Intent.parseUri(u, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, Uri.parse(u))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.component = null
            i.selector = null
            act.startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(act, "Nenhum app para abrir este link", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
            if (!mime.isNullOrBlank()) req.setMimeType(mime)
            if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setTitle(name)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(act, "Baixando $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // sem permissão de gravação ou link especial: deixa o Android resolver
            openExternal(url)
        }
    }

    private fun clearData() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            for (t in tabs) {
                t.web.clearCache(true)
                t.web.clearHistory()
                t.web.clearFormData()
            }
            refreshChrome()
            Toast.makeText(act, "Dados de navegação apagados", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    private fun hideKeyboard() {
        try {
            val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(addr.windowToken, 0)
        } catch (e: Exception) {
        }
    }

    // ================================================================== views auxiliares

    /** Linha fina de progresso de carregamento. */
    private inner class ProgressLine(ctx: Context) : View(ctx) {
        var fraction = 0f
            set(v) {
                field = v.coerceIn(0f, 1f)
                invalidate()
            }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            if (fraction <= 0f || fraction >= 1f) return
            p.color = accent
            c.drawRect(0f, 0f, width * fraction, height.toFloat(), p)
        }
    }

    /** Alça de redimensionar: três tracinhos na diagonal. */
    private inner class GripView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            p.color = Color.parseColor("#80FFFFFF")
            p.strokeWidth = dp(1).toFloat()
            p.strokeCap = Paint.Cap.ROUND
            val w = width.toFloat()
            val h = height.toFloat()
            val m = dp(5).toFloat()
            for (i in 0..2) {
                val o = dp(5) * i.toFloat()
                c.drawLine(w - m, h - m - o - dp(4), w - m - o - dp(4), h - m, p)
            }
        }
    }
}
