package com.example.winlauncher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.util.DisplayMetrics
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Mapeador de gamepad (Etapa 1) - serviço de acessibilidade.
 *
 * Faz duas coisas, as duas só enquanto o usuário ligar "WinLauncher - mapeador de gamepad" em Acessibilidade:
 *  1. recebe as teclas do controle (o Android só entrega teclas ao app em primeiro plano; o filtro de teclas da
 *     acessibilidade é a única forma de ouvi-las em outro app) e repassa ao [PadEngine];
 *  2. injeta os toques na tela com dispatchGesture (ver [TouchPlanner] para o porquê dos "pedaços").
 *
 * É um serviço separado do [ShortcutService] de propósito: os atalhos de teclado já testados não são tocados.
 * Só teclas de CONTROLE são analisadas; teclado comum nunca é consumido nem registrado.
 */
class PadMapperService : AccessibilityService(), PadHost {

    companion object {
        /** true enquanto o serviço está ligado nas configurações do Android. */
        @Volatile
        var running = false

        @Volatile
        var instance: PadMapperService? = null

        /** Teclado, barra do sistema e o próprio app não contam como "o jogo que está na frente". */
        private val IGNORED_PKGS = setOf("android", "com.android.systemui", "com.android.permissioncontroller")

        /**
         * Toque de teste (painel): encosta em ([x],[y]) em pixels da tela. Devolve false se o serviço não está ligado.
         * Serve para provar, no aparelho, que a injeção de toques funciona.
         */
        fun testTap(x: Float, y: Float): Boolean {
            val s = instance ?: return false
            return s.injectTestTap(x, y)
        }

        /**
         * Etapa 2: abre o editor sobre o jogo para o perfil [p]. Devolve false se o serviço não está ligado ou se o
         * Android recusou as janelas.
         */
        fun openEditor(p: PadProfile): Boolean {
            val s = instance ?: return false
            return s.startEditor(p)
        }

        /** O editor sobre o jogo está aberto? */
        fun editorOpen(): Boolean = instance?.editor != null

        /**
         * Etapa 3: reavalia quem pode entregar os eixos (Android 14+: acessibilidade; abaixo: Shizuku autorizado).
         * O painel chama ao abrir, porque o usuário pode ter ligado o Shizuku depois.
         */
        fun refreshAxesSupport() {
            instance?.updateAxesSupport()
            instance?.ensureDirect(false)
        }

        /** Etapa 5: o painel ligou/desligou "tocar pelo Shizuku": liga o injetor (já) ou desliga. */
        fun refreshDirect() {
            instance?.ensureDirect(true)
        }

        /** Etapa 4: o painel mudou "botão flutuante" ou "avisar": reavalia o botão agora. */
        fun refreshOverlay() {
            instance?.syncOverlay()
        }
    }

    // ---- estado da injeção (só thread principal)
    private val strokes = HashMap<Int, GestureDescription.StrokeDescription>()
    private var inFlight = false
    private var inFlightSince = 0L
    private var imePkgs: Set<String>? = null

    private val handler = Handler(Looper.getMainLooper())
    private val wake = Runnable { pump() }

    /** Editor sobre o jogo (Etapa 2); null = fechado. */
    private var editor: PadOverlayEditor? = null

    // ---- Etapa 5: motor de toque. Cada toque novo escolhe UM motor e o mantém até o planejador esvaziar.
    private val MODE_IDLE = 0
    private val MODE_GESTURE = 1
    private val MODE_DIRECT = 2
    private var padMode = MODE_IDLE

    /** Injeção direta (Shizuku): ciclo próprio, sem esperar resposta do Android. */
    private var directTickPosted = false
    private var directLast = 0L
    private val directTick = Runnable {
        directTickPosted = false
        tickDirect()
    }

    /** Dedo do planejador (id do botão) -> dedo do injetor (0..9). */
    private val slotOf = HashMap<Int, Int>()

    // ---- Etapa 4: botão flutuante e aviso de perfil
    private var fab: PadFloatingButton? = null

    /** Id do perfil que já foi anunciado (evita repetir o aviso a cada evento). */
    private var announcedId: String? = null
    private val overlayListener: () -> Unit = { syncOverlay() }

    /** true entre o início do desligamento e a próxima conexão: nada de botão/aviso novo nesse intervalo. */
    private var closing = false

    override fun onServiceConnected() {
        closing = false
        instance = this
        running = true
        PadStore.load(this)
        PadEngine.host = this
        updateAxesSupport()
        PadEngine.updateLauncherFront(VolumeButtonService.launcherForeground)
        PadEngine.onServiceState(true)
        PadEngine.refreshAxes()
        PadEngine.addListener(overlayListener)
        PadShizukuInput.onDead = { reason ->
            if (padMode == MODE_DIRECT) directLost("injetor Shizuku: " + reason)
        }
        ensureDirect(false)
        syncOverlay()
    }

    /** Etapa 5: liga o injetor do Shizuku se a opção está ligada (e o Shizuku autorizado); desliga se a opção foi desligada. */
    private fun ensureDirect(force: Boolean) {
        try {
            if (PadPrefs.direct(this)) PadShizukuInput.ensureStarted(this, force) else PadShizukuInput.stop()
        } catch (e: Exception) {
        }
    }

    /** Etapa 4: a tela girou ou mudou de tamanho: perfil de paisagem/retrato pode ter trocado, e o botão precisa de nova posição. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            PadEngine.onScreenChanged()
            syncOverlay()
        } catch (e: Exception) {
        }
    }

    /**
     * Etapa 4: mantém o botão flutuante e o aviso de "perfil ativo" em dia. Chamado pelo motor a cada mudança de estado
     * (por isso só faz trabalho quando algo de fato mudou).
     */
    private fun syncOverlay() {
        if (closing) return
        try {
            val cand = PadEngine.candidateProfile()
            val id = cand?.id
            if (id != announcedId) {
                announcedId = id
                if (cand != null && PadEngine.masterOn && PadPrefs.announce(this)) {
                    val n = cand.activeCount()
                    MiniToast.info(this, "Gamepad: perfil de " + cand.name + " ativo (" + n + (if (n == 1) " botão)" else " botões)"), true)
                }
            }
            // o botão fica visível enquanto o jogo da frente tem perfil, mesmo com o mapeamento desligado
            val want = cand != null && editor == null && PadPrefs.floating(this)
            if (want) {
                val f = fab ?: PadFloatingButton(this).also { fab = it }
                f.show()
            } else {
                fab?.hide()
            }
        } catch (e: Exception) {
        }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun updateAxesSupport() {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                PadEngine.setAxesAvailability(true, "Acessibilidade")
            } else if (ShizukuBridge.state(this) == ShizukuBridge.State.GRANTED) {
                PadEngine.setAxesAvailability(true, "Shizuku")
            } else {
                PadAxisReader.stop()
                PadEngine.setAxesAvailability(false, null)
            }
        } catch (e: Exception) {
        }
    }

    private fun startEditor(p: PadProfile): Boolean {
        try {
            editor?.close()
        } catch (e: Exception) {
        }
        val e = PadOverlayEditor(this, p) {
            editor = null
            syncOverlay()
        }
        editor = e
        val ok = e.show()
        if (!ok) editor = null
        syncOverlay()
        return ok
    }

    private fun shutdown() {
        handler.removeCallbacks(directTick)
        directTickPosted = false
        padMode = MODE_IDLE
        slotOf.clear()
        PadShizukuInput.onDead = null
        PadShizukuInput.stop()
        closing = true
        PadEngine.removeListener(overlayListener)
        try {
            fab?.hide()
        } catch (e: Exception) {
        }
        fab = null
        announcedId = null
        try {
            editor?.close()
        } catch (e: Exception) {
        }
        editor = null
        handler.removeCallbacks(wake)
        PadAxisReader.stop()
        running = false
        if (instance === this) instance = null
        strokes.clear()
        inFlight = false
        if (PadEngine.host === this) PadEngine.host = null
        PadEngine.onServiceState(false)
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------ entrada

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        try {
            PadEngine.updateLauncherFront(VolumeButtonService.launcherForeground)
            ensureDirect(false)
            val pkg = event.packageName?.toString() ?: return
            // janelas do próprio WinLauncher (inclusive a barra flutuante) não mudam o "jogo da frente"
            if (pkg == packageName || pkg in IGNORED_PKGS || isKeyboardPkg(pkg)) return
            PadEngine.onForeground(pkg)
            // Android 13-: o Shizuku pode ter sido ligado/autorizado depois; confere a cada troca de app
            if (Build.VERSION.SDK_INT < 34) updateAxesSupport()
        } catch (e: Exception) {
        }
    }

    private fun isKeyboardPkg(pkg: String): Boolean {
        var set = imePkgs
        if (set == null) {
            set = try {
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.enabledInputMethodList.map { it.packageName }.toSet()
            } catch (e: Exception) {
                emptySet()
            }
            imePkgs = set
        }
        return pkg in set!!
    }

    /** Alt acompanhado por conta própria: em alguns teclados o modificador do evento da tecla M vem vazio dentro de outros apps. */
    private var altDown = false

    /**
     * ALT + M (teclado físico) com um jogo na frente: abre o editor de mapeamento sobre o jogo; com o editor aberto,
     * salva e fecha. Com o launcher na frente quem trata é a MainActivity (abre/fecha a janela do Mapeador).
     */
    private fun handleMapperShortcut(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_ALT_LEFT || code == KeyEvent.KEYCODE_ALT_RIGHT) {
            altDown = event.action == KeyEvent.ACTION_DOWN
            return false
        }
        if (code != KeyEvent.KEYCODE_M) return false
        val alt = altDown || event.isAltPressed
        if (!alt || event.isCtrlPressed || event.isMetaPressed || event.isShiftPressed) return false
        if (!event.isFromSource(InputDevice.SOURCE_KEYBOARD)) return false
        if (VolumeButtonService.launcherForeground) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) openMapperFromShortcut()
        return true
    }

    private fun openMapperFromShortcut() {
        val ed = editor
        if (ed != null) {
            ed.saveAndExit()
            MiniToast.info(this, "Mapeamento salvo.", true)
            return
        }
        val pkg = PadEngine.foregroundPkg
        if (pkg.isEmpty()) {
            MiniToast.info(this, "O jogo ainda não foi reconhecido. Saia e volte ao jogo, depois aperte ALT + M.", true)
            return
        }
        val p = PadStore.profileFor(pkg)
        if (p == null) {
            MiniToast.info(this, "Este app não está na lista do Mapeador. Abra o Mapeador no WinLauncher e toque em Adicionar jogo.", true)
            return
        }
        if (p.bindings.isEmpty()) {
            // perfil novo: já nasce na orientação em que o jogo está agora
            p.landscape = screenWidth() > screenHeight()
            PadStore.save(this)
        }
        if (!startEditor(p)) MiniToast.error(this, "O Android recusou abrir o editor sobre o jogo.", true)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        return try {
            if (handleMapperShortcut(event)) return true
            val code = event.keyCode
            val src = event.source
            val padSrc = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            // BUTTON_A.. só existem em controle; as setas só contam se vierem de um controle (não do teclado)
            val fromPad = PadButton.isPadOnlyKey(code) || padSrc
            if (!fromPad) return false
            PadEngine.updateLauncherFront(VolumeButtonService.launcherForeground)
            PadEngine.onKey(
                PadKey(
                    code, event.action == KeyEvent.ACTION_DOWN, event.repeatCount,
                    event.device?.name ?: "", true, SystemClock.uptimeMillis()
                )
            )
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------ eixos (Etapa 3, Android 14+)

    /** Eixos do controle. Só chegam depois de [setAxesWanted] (e só no Android 14+). */
    override fun onMotionEvent(event: MotionEvent) {
        try {
            if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return
            val z = event.getAxisValue(MotionEvent.AXIS_Z)
            val rz = event.getAxisValue(MotionEvent.AXIS_RZ)
            val rxa = event.getAxisValue(MotionEvent.AXIS_RX)
            val rya = event.getAxisValue(MotionEvent.AXIS_RY)
            // analógico direito: Z/RZ na maioria dos controles, RX/RY em alguns; vale o que estiver mais inclinado
            val useZ = (z * z + rz * rz) >= (rxa * rxa + rya * rya)
            PadEngine.onAxes(
                PadAxes(
                    event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
                    if (useZ) z else rxa, if (useZ) rz else rya,
                    Math.max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE)),
                    Math.max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS)),
                    event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y),
                    event.device?.name ?: "", SystemClock.uptimeMillis()
                )
            )
        } catch (e: Exception) {
        }
    }

    override fun setAxesWanted(on: Boolean) {
        if (Build.VERSION.SDK_INT < 34) {
            // Android 13 ou menor: lê o controle por getevent (Shizuku); desliga quando ninguém precisa
            if (on) PadAxisReader.start(this) else PadAxisReader.stop()
            return
        }
        try {
            val info = serviceInfo ?: return
            info.motionEventSources = if (on) InputDevice.SOURCE_JOYSTICK else 0
            serviceInfo = info
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ PadHost

    override fun screenWidth(): Int = realSize().first

    override fun screenHeight(): Int = realSize().second

    private fun realSize(): Pair<Int, Int> {
        return try {
            val dm = DisplayMetrics()
            val d = (getSystemService(android.content.Context.DISPLAY_SERVICE) as DisplayManager)
                .getDisplay(Display.DEFAULT_DISPLAY)
            @Suppress("DEPRECATION")
            d.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        } catch (e: Exception) {
            val m = resources.displayMetrics
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    // ------------------------------------------------------------ injeção

    /** Despacha o próximo pedaço, se nenhum estiver em andamento. */
    override fun pump() {
        if (padMode == MODE_IDLE) {
            if (!PadEngine.planner.hasWork()) return
            val direct = PadPrefs.direct(this) && PadShizukuInput.isReady()
            padMode = if (direct) MODE_DIRECT else MODE_GESTURE
            PadEngine.planner.chunkMs = if (direct) 8L else 32L
        }
        if (padMode == MODE_DIRECT) {
            if (!directTickPosted) tickDirect()
            return
        }
        pumpGesture()
    }

    /** Etapa 5: um ciclo da injeção direta: pede o próximo pedaço ao planejador e manda os dedos ao injetor. */
    private fun tickDirect() {
        handler.removeCallbacks(directTick)
        directTickPosted = false
        try {
            if (!PadShizukuInput.isReady()) {
                directLost("o injetor do Shizuku não está pronto")
                return
            }
            val planner = PadEngine.planner
            if (!planner.hasWork()) {
                padMode = MODE_IDLE
                directLast = 0L
                slotOf.clear()
                return
            }
            val now = SystemClock.uptimeMillis()
            // o planejador integra a velocidade da câmera por pedaço: usa o tempo REAL desde o ciclo anterior
            val dt = if (directLast == 0L) 8L else Math.max(4L, Math.min(50L, now - directLast))
            directLast = now
            planner.chunkMs = dt
            val segs = planner.nextChunk(now)
            var moved = false
            for (sg in segs) {
                var slot = slotOf[sg.id]
                if (slot == null) {
                    var n = 0
                    while (n < 9 && slotOf.containsValue(n)) n++
                    slot = n
                    slotOf[sg.id] = n
                }
                if (sg.begin) PadShizukuInput.down(slot, sg.fromX, sg.fromY)
                if (sg.toX != sg.fromX || sg.toY != sg.fromY) {
                    PadShizukuInput.move(slot, sg.toX, sg.toY)
                    moved = true
                }
                if (sg.end) {
                    PadShizukuInput.up(slot)
                    slotOf.remove(sg.id)
                }
            }
            if (moved) PadShizukuInput.frame()
            PadShizukuInput.flush()
            if (planner.hasWork()) {
                directTickPosted = true
                handler.postDelayed(directTick, 8L)
            } else {
                padMode = MODE_IDLE
                directLast = 0L
                slotOf.clear()
            }
        } catch (e: Exception) {
            directLost("erro ao injetar: " + e.javaClass.simpleName)
        }
    }

    /** A injeção direta falhou: solta tudo e o próximo toque volta para a acessibilidade (ou tenta o injetor de novo). */
    private fun directLost(reason: String) {
        handler.removeCallbacks(directTick)
        directTickPosted = false
        directLast = 0L
        padMode = MODE_IDLE
        slotOf.clear()
        PadShizukuInput.releaseAllNow()
        PadEngine.onInjectionLost(reason)
    }

    /** Motor de acessibilidade (dispatchGesture), como nas etapas 1 a 4. */
    private fun pumpGesture() {
        try {
            val now = SystemClock.uptimeMillis()
            if (inFlight) {
                // trava de segurança: se o Android nunca devolveu o resultado, não deixa a entrada morrer para sempre
                if (now - inFlightSince < 1000L) return
                lost("sem resposta do Android")
            }
            val planner = PadEngine.planner
            if (!planner.hasWork()) {
                padMode = MODE_IDLE
                return
            }
            val segs = planner.nextChunk(now)
            if (segs.isEmpty()) {
                // turbo entre dois toques: volta a olhar quando for a hora do próximo
                handler.removeCallbacks(wake)
                val dl = planner.nextWakeDelay(now)
                if (dl >= 0L) handler.postDelayed(wake, dl)
                return
            }
            dispatch(segs, planner.chunkMs)
        } catch (e: Exception) {
            lost("erro ao injetar: " + e.javaClass.simpleName)
        }
    }

    private fun dispatch(segs: List<TouchPlanner.Seg>, chunkMs: Long) {
        val b = GestureDescription.Builder()
        for (s in segs) {
            val path = Path()
            path.moveTo(s.fromX, s.fromY)
            if (s.toX != s.fromX || s.toY != s.fromY) path.lineTo(s.toX, s.toY)
            val prev = strokes[s.id]
            val stroke = if (s.begin || prev == null) {
                GestureDescription.StrokeDescription(path, 0L, chunkMs, !s.end)
            } else {
                prev.continueStroke(path, 0L, chunkMs, !s.end)
            }
            if (s.end) strokes.remove(s.id) else strokes[s.id] = stroke
            b.addStroke(stroke)
        }
        inFlight = true
        inFlightSince = SystemClock.uptimeMillis()
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                inFlight = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                lost("gesto cancelado pelo Android")
            }
        }, null)
        if (!ok) lost("o Android recusou o gesto")
    }

    private fun lost(reason: String) {
        inFlight = false
        padMode = MODE_IDLE
        strokes.clear()
        PadEngine.onInjectionLost(reason)
    }

    /** Toque único de teste. Não passa pelo planejador (não mexe nos botões do controle). */
    private fun injectTestTap(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }
}
