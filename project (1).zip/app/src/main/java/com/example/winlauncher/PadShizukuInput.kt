package com.example.winlauncher

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.LinkedBlockingQueue

/**
 * Mapeador de gamepad (Etapa 5) - lado do app do injetor de toques via Shizuku.
 *
 * Inicia o [PadInjector] como processo do shell (app_process, pelo [ShizukuBridge.spawn]) e manda comandos de texto para a entrada
 * dele ("D slot x y", "M", "F", "U", "X", "Q"; ver [PadInjector]). Um thread escreve no pipe, para a thread principal nunca travar.
 * Com o injetor pronto, o [PadMapperService] toca a tela por aqui (sem o ciclo de gestos da acessibilidade); se ele não está pronto
 * ou cai, o serviço volta sozinho para a acessibilidade.
 *
 * Os métodos down/move/up/frame/flush/releaseAllNow só podem ser chamados da thread principal.
 */
object PadShizukuInput {
    private const val CLASS = "com.example.winlauncher.PadInjector"
    private const val START_TIMEOUT_MS = 8000L
    private const val RETRY_MS = 10000L

    /** Texto para o painel: o que está acontecendo com o injetor. */
    @Volatile
    var status: String = ""
        private set

    @Volatile
    private var ready = false

    @Volatile
    private var starting = false

    private var lastTry = 0L
    private var proc: Process? = null
    private var queue: LinkedBlockingQueue<String>? = null

    /** Geração do processo atual: threads de um processo antigo não mexem no estado do novo. */
    private var gen = 0
    private val main = Handler(Looper.getMainLooper())
    private val sb = StringBuilder()

    /** O injetor caiu depois de ter ficado pronto (o serviço solta os dedos e volta para a acessibilidade). Roda na thread principal. */
    var onDead: ((String) -> Unit)? = null

    fun isReady(): Boolean = ready

    fun isStarting(): Boolean = starting

    // ------------------------------------------------------------ ciclo de vida

    /**
     * Liga o injetor se o Shizuku está autorizado e ele ainda não está de pé. Não faz nada se já está pronto/iniciando, e espera
     * [RETRY_MS] entre tentativas (a menos que [force]). Só thread principal.
     */
    fun ensureStarted(ctx: Context, force: Boolean = false) {
        if (ready || starting) return
        val now = SystemClock.uptimeMillis()
        if (!force && lastTry != 0L && now - lastTry < RETRY_MS) return
        if (ShizukuBridge.state(ctx) != ShizukuBridge.State.GRANTED) {
            status = "Shizuku sem autorização"
            return
        }
        lastTry = now
        starting = true
        status = "iniciando..."
        val apk = ctx.applicationInfo.sourceDir
        var myGen = 0
        synchronized(this) {
            gen++
            myGen = gen
        }
        val thisGen = myGen
        val t = Thread({ launch(thisGen, apk) }, "pad-injector-launch")
        t.isDaemon = true
        t.start()
        main.postDelayed({
            if (starting && gen == thisGen) fail(thisGen, "o injetor não respondeu em " + (START_TIMEOUT_MS / 1000) + " s")
        }, START_TIMEOUT_MS)
    }

    /** Desliga o injetor (solta qualquer dedo preso antes). */
    fun stop() {
        var p: Process? = null
        var q: LinkedBlockingQueue<String>? = null
        synchronized(this) {
            gen++
            p = proc
            q = queue
            proc = null
            queue = null
            ready = false
            starting = false
        }
        sb.setLength(0)
        status = ""
        q?.offer("X\nQ\n")
        val dying = p
        if (dying != null) {
            val th = Thread({
                try {
                    Thread.sleep(300)
                } catch (e: Exception) {
                }
                try {
                    dying.destroy()
                } catch (e: Throwable) {
                }
            }, "pad-injector-stop")
            th.isDaemon = true
            th.start()
        }
    }

    private fun launch(myGen: Int, apk: String) {
        val p = ShizukuBridge.spawn(
            arrayOf(
                "/system/bin/app_process", "-Djava.class.path=" + apk, "/system/bin",
                "--nice-name=winlauncher_pad", CLASS
            )
        )
        if (p == null) {
            fail(myGen, "não consegui iniciar: " + (ShizukuBridge.lastError ?: "?"))
            return
        }
        val q = LinkedBlockingQueue<String>()
        var stale = false
        synchronized(this) {
            if (myGen != gen) {
                stale = true
            } else {
                proc = p
                queue = q
            }
        }
        if (stale) {
            try {
                p.destroy()
            } catch (e: Throwable) {
            }
            return
        }
        val te = Thread({ drainErrors(myGen, p) }, "pad-injector-err")
        te.isDaemon = true
        te.start()
        val tw = Thread({ writeLoop(myGen, p, q) }, "pad-injector-out")
        tw.isDaemon = true
        tw.start()
        readLoop(myGen, p)
    }

    private fun readLoop(myGen: Int, p: Process) {
        try {
            p.inputStream.bufferedReader().use { br ->
                while (true) {
                    val line = br.readLine() ?: break
                    if (line.startsWith("READY")) {
                        var ok = false
                        synchronized(this) {
                            if (myGen == gen) {
                                ready = true
                                starting = false
                                status = "pronto (" + line + ")"
                                ok = true
                            }
                        }
                        if (ok) main.post { PadEngine.notifyChanged() }
                    } else if (line.startsWith("ERR")) {
                        fail(myGen, line.substring(3).trim())
                        return
                    }
                }
            }
        } catch (t: Throwable) {
        }
        fail(myGen, "o injetor parou")
    }

    private fun writeLoop(myGen: Int, p: Process, q: LinkedBlockingQueue<String>) {
        try {
            val out = p.outputStream
            while (true) {
                val s = q.take()
                out.write(s.toByteArray(Charsets.US_ASCII))
                out.flush()
                if (s.endsWith("Q\n")) break
            }
        } catch (t: Throwable) {
            fail(myGen, "falha ao enviar ao injetor: " + t.javaClass.simpleName)
        }
    }

    /** Guarda a última linha de erro do processo (traz o motivo quando o app_process não sobe). */
    private fun drainErrors(myGen: Int, p: Process) {
        try {
            p.errorStream.bufferedReader().use { br ->
                while (true) {
                    val line = br.readLine() ?: break
                    if (line.isNotBlank() && !ready && myGen == gen) status = "erro: " + line.take(120)
                }
            }
        } catch (t: Throwable) {
        }
    }

    private fun fail(myGen: Int, msg: String) {
        var p: Process? = null
        synchronized(this) {
            if (myGen != gen) return
            gen++
            p = proc
            proc = null
            queue = null
            ready = false
            starting = false
            // um erro mais específico já gravado pelo stderr vale mais que "parou"
            if (!(msg == "o injetor parou" && status.startsWith("erro:"))) status = msg
        }
        try {
            p?.destroy()
        } catch (t: Throwable) {
        }
        main.post {
            try {
                onDead?.invoke(msg)
            } catch (e: Exception) {
            }
            PadEngine.notifyChanged()
        }
    }

    // ------------------------------------------------------------ comandos (thread principal)

    fun down(slot: Int, x: Float, y: Float) {
        sb.append("D ").append(slot).append(' ').append(Math.round(x)).append(' ').append(Math.round(y)).append('\n')
    }

    fun move(slot: Int, x: Float, y: Float) {
        sb.append("M ").append(slot).append(' ').append(Math.round(x)).append(' ').append(Math.round(y)).append('\n')
    }

    fun up(slot: Int) {
        sb.append("U ").append(slot).append('\n')
    }

    /** Manda um único MOVE com todos os dedos que andaram. */
    fun frame() {
        sb.append("F\n")
    }

    /** Envia o que foi acumulado (uma vez por ciclo). */
    fun flush() {
        if (sb.isEmpty()) return
        val s = sb.toString()
        sb.setLength(0)
        queue?.offer(s)
    }

    /** Solta tudo agora, sem esperar o planejador. */
    fun releaseAllNow() {
        sb.setLength(0)
        queue?.offer("X\n")
    }

    /** Toque de teste (painel): encosta em ([x],[y]) por ~70 ms usando o dedo 9. Devolve false se o injetor não está pronto. */
    fun testTap(x: Float, y: Float): Boolean {
        if (!ready) return false
        down(9, x, y)
        flush()
        main.postDelayed({
            up(9)
            flush()
        }, 70L)
        return true
    }
}
