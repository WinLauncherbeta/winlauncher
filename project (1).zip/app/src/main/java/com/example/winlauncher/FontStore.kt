package com.example.winlauncher

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.nio.charset.Charset

/**
 * Fontes TTF/OTF importadas pelo usuário para o widget de relógio.
 *
 * Ficam somente no armazenamento privado do app (filesDir/fonts): não exige permissões, não usa root
 * e não altera as fontes do Android nem de outros aplicativos. Cada arquivo é validado antes de ser aceito.
 */
object FontStore {

    class Entry(val file: String, val name: String)

    class Result(val entry: Entry?, val error: String?)

    private const val MAX_BYTES = 20L * 1024 * 1024
    // a importação roda em segundo plano enquanto a tela lê: mapas seguros para vários threads
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Typeface>()
    private val names = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "fonts")
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** Fontes importadas, em ordem alfabética. */
    fun list(ctx: Context): List<Entry> {
        val files = dir(ctx).listFiles() ?: return emptyList()
        val out = ArrayList<Entry>()
        for (f in files) {
            val ext = f.extension.lowercase()
            if (!f.isFile || (ext != "ttf" && ext != "otf")) continue
            var name = names[f.name]
            if (name == null) {
                val bytes = try {
                    f.readBytes()
                } catch (e: Exception) {
                    continue
                }
                name = (sfntName(bytes) ?: "").ifBlank { f.nameWithoutExtension }
                names[f.name] = name
            }
            out.add(Entry(f.name, name))
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /** Typeface da fonte importada, ou null se o arquivo não existir mais ou não puder ser lido. */
    fun typeface(ctx: Context, file: String): Typeface? {
        if (file.isEmpty()) return null
        cache[file]?.let { return it }
        val f = File(dir(ctx), file)
        if (!f.isFile) return null
        return try {
            val tf = Typeface.createFromFile(f)
            if (tf == null || tf === Typeface.DEFAULT) {
                null
            } else {
                cache[file] = tf
                tf
            }
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context, file: String) {
        cache.remove(file)
        names.remove(file)
        try {
            File(dir(ctx), file).delete()
        } catch (e: Exception) {
        }
    }

    /** Copia a fonte escolhida para o armazenamento privado, validando extensão, tamanho e estrutura. */
    fun import(ctx: Context, uri: Uri): Result {
        var display = ""
        var size = -1L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) display = c.getString(ni) ?: ""
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
        }
        if (display.isEmpty()) display = uri.lastPathSegment ?: ""
        val ext = display.substringAfterLast('.', "").lowercase()
        if (ext != "ttf" && ext != "otf") return Result(null, "Escolha um arquivo de fonte .ttf ou .otf")
        if (size > MAX_BYTES) return Result(null, "Arquivo de fonte muito grande")

        val bytes: ByteArray = try {
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                val buf = java.io.ByteArrayOutputStream()
                val chunk = ByteArray(16 * 1024)
                while (true) {
                    val n = ins.read(chunk)
                    if (n < 0) break
                    buf.write(chunk, 0, n)
                    if (buf.size() > MAX_BYTES) return Result(null, "Arquivo de fonte muito grande")
                }
                buf.toByteArray()
            } ?: return Result(null, "Não foi possível abrir o arquivo")
        } catch (e: Exception) {
            return Result(null, "Não foi possível abrir o arquivo")
        }

        val name = (sfntName(bytes) ?: return Result(null, "Fonte inválida ou incompatível"))
            .ifBlank { display.substringBeforeLast('.') }

        // já importada (mesmo nome e mesmo tamanho)? reaproveita
        for (e in list(ctx)) {
            if (e.name == name && File(dir(ctx), e.file).length() == bytes.size.toLong()) return Result(e, null)
        }

        val outName = "f" + System.currentTimeMillis() + "_" + (bytes.size and 0xFFFF) + "." + ext
        val out = File(dir(ctx), outName)
        try {
            out.writeBytes(bytes)
            // o Android aceita o arquivo? (em versões novas uma fonte quebrada vira a padrão sem avisar)
            val tf = Typeface.createFromFile(out)
            if (tf == null || tf === Typeface.DEFAULT) {
                out.delete()
                return Result(null, "Fonte inválida ou incompatível")
            }
            cache[outName] = tf
            names[outName] = name
        } catch (e: Exception) {
            out.delete()
            return Result(null, "Fonte inválida ou incompatível")
        }
        return Result(Entry(outName, name), null)
    }

    // ------------------------------------------------------------------ validação do arquivo

    private fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun u32(b: ByteArray, o: Int): Long =
        (u16(b, o).toLong() shl 16) or u16(b, o + 2).toLong()

    private fun tag(b: ByteArray, o: Int): String = String(b, o, 4, Charsets.ISO_8859_1)

    /**
     * Valida a estrutura sfnt (TTF/OTF) e devolve o nome da fonte ("" se for válida mas sem nome legível);
     * null se o arquivo não for uma fonte utilizável. Coleções (.ttc) não são aceitas.
     */
    private fun sfntName(b: ByteArray): String? = try {
        parseSfnt(b)
    } catch (e: Exception) {
        null
    }

    private fun parseSfnt(b: ByteArray): String? {
        if (b.size < 12 + 16) return null
        val ver = u32(b, 0)
        val isTrueType = ver == 0x00010000L || tag(b, 0) == "true"
        val isOpenType = tag(b, 0) == "OTTO"
        if (!isTrueType && !isOpenType) return null
        val n = u16(b, 4)
        if (n < 4 || n > 80 || 12 + 16 * n > b.size) return null
        val tables = HashMap<String, LongArray>()
        for (i in 0 until n) {
            val e = 12 + 16 * i
            val off = u32(b, e + 8)
            val len = u32(b, e + 12)
            if (off + len > b.size) return null
            tables[tag(b, e)] = longArrayOf(off, len)
        }
        for (req in listOf("cmap", "head", "hhea", "hmtx", "maxp", "name")) {
            if (!tables.containsKey(req)) return null
        }
        val hasOutlines = (tables.containsKey("glyf") && tables.containsKey("loca")) ||
            tables.containsKey("CFF ") || tables.containsKey("CFF2")
        if (!hasOutlines) return null
        val nt = tables.getValue("name")
        return readName(b, nt[0].toInt(), nt[1].toInt()) ?: ""
    }

    /** Nome completo (ID 4) ou família (ID 1) da tabela 'name'. */
    private fun readName(b: ByteArray, base: Int, len: Int): String? {
        if (len < 6) return null
        val count = u16(b, base + 2)
        val strOff = u16(b, base + 4)
        var best: String? = null
        var bestRank = Int.MAX_VALUE
        for (i in 0 until count) {
            val r = base + 6 + 12 * i
            if (r + 12 > base + len) break
            val platform = u16(b, r)
            val lang = u16(b, r + 4)
            val id = u16(b, r + 6)
            val l = u16(b, r + 8)
            val o = u16(b, r + 10)
            if (id != 4 && id != 1) continue
            val s = base + strOff + o
            if (l <= 0 || s < 0 || s + l > b.size) continue
            val text: String = when (platform) {
                3, 0 -> String(b, s, l, Charset.forName("UTF-16BE"))
                1 -> String(b, s, l, Charsets.ISO_8859_1)
                else -> continue
            }.trim()
            if (text.isEmpty()) continue
            // prefere: nome completo > família; Windows inglês (0x409) > outros
            val rank = (if (id == 4) 0 else 10) + (if (platform == 3 && lang == 0x409) 0 else 1)
            if (rank < bestRank) {
                bestRank = rank
                best = text
            }
        }
        return best?.take(48)
    }
}
