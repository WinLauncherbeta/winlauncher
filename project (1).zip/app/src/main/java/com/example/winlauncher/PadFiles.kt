package com.example.winlauncher

import android.app.Activity
import android.content.Intent

/**
 * Mapeador de gamepad (Etapa 4) - exportar e importar perfis por arquivo (seletor de arquivos do Android).
 * O [MainActivity] repassa o resultado para [onResult]. A lógica de ler/juntar os perfis está em [PadJson] / [PadStore].
 */
object PadFiles {
    const val REQ_EXPORT = 24
    const val REQ_IMPORT = 25

    /** Limite de tamanho do arquivo importado (perfis são pequenos; isso só protege de escolher um arquivo errado). */
    private const val MAX_BYTES = 2_000_000

    private var pendingReplace = false

    /** O painel registra aqui o que fazer quando terminar (redesenhar a lista). Pode ser null. */
    var onDone: (() -> Unit)? = null

    fun startExport(a: MainActivity) {
        PadStore.load(a)
        if (PadStore.profiles.isEmpty()) {
            a.toast("Não há perfis para exportar")
            return
        }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "winlauncher_gamepad_perfis.json")
        try {
            a.startActivityForResult(i, REQ_EXPORT)
        } catch (e: Exception) {
            a.toast("Nenhum seletor de arquivos encontrado")
        }
    }

    /** [replace] = true troca o perfil dos apps que já têm um; false mantém o que já existe. */
    fun startImport(a: MainActivity, replace: Boolean) {
        pendingReplace = replace
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "application/octet-stream"))
        try {
            a.startActivityForResult(i, REQ_IMPORT)
        } catch (e: Exception) {
            a.toast("Nenhum seletor de arquivos encontrado")
        }
    }

    /** Devolve true se o resultado era nosso (o MainActivity não precisa olhar mais). */
    fun onResult(a: MainActivity, requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQ_EXPORT && requestCode != REQ_IMPORT) return false
        val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
        if (uri == null) return true
        try {
            if (requestCode == REQ_EXPORT) {
                val text = PadStore.exportText(a)
                val out = a.contentResolver.openOutputStream(uri, "wt")
                if (out == null) {
                    a.toast("Não foi possível gravar o arquivo")
                    return true
                }
                out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                a.toast("Perfis exportados (" + PadStore.profiles.size + ")")
            } else {
                val text = readCapped(a, uri)
                if (text == null) {
                    a.toast("Não foi possível ler o arquivo (ilegível ou grande demais)")
                    return true
                }
                a.toast(PadStore.importText(a, text, pendingReplace))
            }
        } catch (e: Exception) {
            a.toast("Falha no arquivo: " + e.javaClass.simpleName)
        }
        try {
            onDone?.invoke()
        } catch (e: Exception) {
        }
        return true
    }

    private fun readCapped(a: MainActivity, uri: android.net.Uri): String? {
        val ins = a.contentResolver.openInputStream(uri) ?: return null
        return ins.use { s ->
            val bos = java.io.ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            var tooBig = false
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_BYTES) {
                    tooBig = true
                    break
                }
                bos.write(buf, 0, n)
            }
            if (tooBig) null else String(bos.toByteArray(), Charsets.UTF_8)
        }
    }
}
