package com.example.winlauncher

import org.json.JSONArray
import org.json.JSONObject

/**
 * Mapeador de gamepad (Etapa 1) - modelo de dados. Sem nenhuma dependência de Android além do org.json,
 * para poder ser compilado e testado numa JVM comum.
 *
 * Um [PadProfile] pertence a UM app (pacote). Cada [PadBinding] liga um botão do controle a um ponto da tela
 * (posição em FRAÇÃO da tela, 0..1, para sobreviver a trocas de resolução) e a um modo de toque.
 */

/** Botões do controle que o mapeador reconhece. [key] é o KeyEvent.KEYCODE_* correspondente. */
enum class PadButton(val key: Int, val label: String, val tag: String = label) {
    A(96, "A"),
    B(97, "B"),
    X(99, "X"),
    Y(100, "Y"),
    L1(102, "L1"),
    R1(103, "R1"),
    L2(104, "L2"),
    R2(105, "R2"),
    THUMBL(106, "L3"),
    THUMBR(107, "R3"),
    START(108, "Start"),
    SELECT(109, "Select"),
    MODE(110, "Mode"),
    DPAD_UP(19, "Cima"),
    DPAD_DOWN(20, "Baixo"),
    DPAD_LEFT(21, "Esquerda"),
    DPAD_RIGHT(22, "Direita"),

    /** Etapa 3: analógicos. Não são teclas (códigos negativos de propósito: nunca casam com um KeyEvent). */
    LSTICK(-1, "Analógico E", "LS"),
    RSTICK(-2, "Analógico D", "RS");

    val isStick: Boolean get() = key < 0

    /** L2/R2: também podem ser lidos como eixo (pressão gradual). */
    val isTrigger: Boolean get() = this == L2 || this == R2

    companion object {
        fun fromKey(code: Int): PadButton? = values().firstOrNull { it.key == code }

        /** Códigos de tecla que só existem em controles (BUTTON_A..BUTTON_MODE). */
        fun isPadOnlyKey(code: Int): Boolean = code in 96..110

        fun fromName(n: String?): PadButton? = values().firstOrNull { it.name == n }
    }
}

/** O que acontece na tela quando o botão é apertado. */
enum class BindMode(val label: String) {
    /** Sem ação: o botão passa para o app normalmente. */
    OFF("Sem ação"),

    /** Toque curto: encosta e solta sozinho, mesmo que o botão continue apertado. */
    TAP("Toque rápido"),

    /** Segurar: o dedo fica na tela enquanto o botão estiver apertado. */
    HOLD("Segurar"),

    /** Etapa 3: turbo. Enquanto o botão estiver apertado, toca de novo e de novo ([PadBinding.rate] por segundo). */
    TURBO("Turbo"),

    /** Etapa 3 (só analógicos): joystick virtual. O dedo nasce no ponto e anda para onde o analógico aponta. */
    JOYSTICK("Joystick"),

    /** Etapa 3 (só analógicos): câmera. O analógico vira um arrasto contínuo (o dedo volta ao ponto ao chegar no raio). */
    CAMERA("Câmera"),

    /** Etapa 3 (só L2/R2): pressão gradual. O dedo anda numa direção [PadBinding.dir] na proporção de quanto o gatilho foi apertado. */
    SLIDE("Gradual"),

    /** Etapa 3 (botões comuns e L2/R2): macro. Sequência de toques em pontos diferentes, cada um com tempo e espera. */
    MACRO("Macro");

    companion object {
        fun fromName(n: String?): BindMode = values().firstOrNull { it.name == n } ?: OFF

        /** Modos que fazem sentido para o botão [b] (analógico: joystick/câmera; botão: toque/segurar/turbo). */
        /** Modo de um ponto recém-marcado: analógico = joystick, botão = segurar. */
        fun defaultFor(b: PadButton): BindMode = if (b.isStick) JOYSTICK else HOLD

        fun forButton(b: PadButton): List<BindMode> = when {
            b.isStick -> listOf(OFF, JOYSTICK, CAMERA)
            b.isTrigger -> listOf(OFF, TAP, HOLD, TURBO, SLIDE, MACRO)
            else -> listOf(OFF, TAP, HOLD, TURBO, MACRO)
        }
    }
}

/** Um passo de macro: toca em ([x],[y]) (fração da tela) por [hold] ms e espera [wait] ms antes do próximo. */
class MacroStep(var x: Float, var y: Float, var hold: Int = 60, var wait: Int = 150) {
    fun copy() = MacroStep(x, y, hold, wait)
}

class PadBinding(val button: PadButton, var mode: BindMode, var x: Float, var y: Float) {
    /** Joystick/câmera: raio em fração do lado MENOR da tela (joystick: até onde o dedo anda; câmera: quando o dedo volta ao ponto). */
    var radius = 0.12f

    /** Câmera: multiplicador da velocidade (1 = uma altura de tela por segundo com o analógico no fundo). */
    var speed = 1f

    /** Analógico: zona morta (0..1). Abaixo disso o analógico é ignorado. */
    var dead = 0.12f

    /** Turbo: toques por segundo. */
    var rate = 8

    /** Gradual (L2/R2): direção em que o dedo anda. 0 = cima, 1 = baixo, 2 = esquerda, 3 = direita. */
    var dir = 0

    /** Macro: os passos (a posição do primeiro é sempre a do ponto do botão: [x],[y]). */
    val steps: MutableList<MacroStep> = ArrayList()

    /** Macro: true = repete enquanto o botão estiver apertado; false = roda uma vez inteira a cada aperto. */
    var loop = false

    fun copy(): PadBinding {
        val c = PadBinding(button, mode, x, y)
        c.radius = radius
        c.speed = speed
        c.dead = dead
        c.rate = rate
        c.dir = dir
        c.loop = loop
        for (st in steps) c.steps.add(st.copy())
        return c
    }

    // ---- macro

    /** Garante pelo menos o passo 1 (no ponto do botão). */
    fun ensureMacro() {
        if (steps.isEmpty()) steps.add(MacroStep(x, y))
    }

    /** O ponto do botão acompanha o passo 1 (o editor e o teste de toque usam x,y). */
    fun syncAnchor() {
        if (steps.isNotEmpty()) {
            x = steps[0].x
            y = steps[0].y
        }
    }

    /** Põe um passo no fim. Devolve o índice, ou -1 se já está no limite. */
    fun addStep(fx: Float, fy: Float): Int {
        if (steps.size >= MAX_STEPS) return -1
        steps.add(MacroStep(PadProfile.clamp01(fx), PadProfile.clamp01(fy)))
        syncAnchor()
        return steps.size - 1
    }

    /** Tira o passo [i]. Devolve o novo índice selecionado (-1 se não sobrou nenhum). O passo 1 não pode sumir se for o único. */
    fun removeStep(i: Int): Int {
        if (i < 0 || i >= steps.size || steps.size <= 1) return Math.min(i, steps.size - 1)
        steps.removeAt(i)
        syncAnchor()
        return Math.min(i, steps.size - 1)
    }

    fun moveStep(i: Int, fx: Float, fy: Float) {
        val st = steps.getOrNull(i) ?: return
        st.x = PadProfile.clamp01(fx)
        st.y = PadProfile.clamp01(fy)
        syncAnchor()
    }

    /** Índice do passo mais perto de (px,py) dentro de [tolPx] (mesma unidade de [w] x [h]), ou -1. */
    fun nearestStep(px: Float, py: Float, w: Float, h: Float, tolPx: Float): Int {
        var best = -1
        var bestD = tolPx
        for (i in steps.indices) {
            val dx = steps[i].x * w - px
            val dy = steps[i].y * h - py
            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (dist < bestD) {
                bestD = dist
                best = i
            }
        }
        return best
    }

    /** Duração de uma volta da macro em ms (toques + esperas). */
    fun macroLengthMs(): Int = steps.sumOf { it.hold + it.wait }

    /** Valores iniciais do modo (ao trocar de modo no editor): a câmera pede um raio maior que o joystick. */
    fun applyModeDefaults() {
        when (mode) {
            BindMode.CAMERA -> radius = 0.25f
            BindMode.JOYSTICK -> radius = 0.12f
            BindMode.SLIDE -> {
                radius = 0.2f
                dead = 0.05f
            }
            BindMode.MACRO -> ensureMacro()
            else -> {
            }
        }
        // saiu do gradual: a zona morta volta ao padrão dos analógicos
        if (mode != BindMode.SLIDE && dead < 0.06f && mode != BindMode.OFF) dead = 0.12f
    }

    fun clampParams() {
        radius = if (radius.isNaN()) 0.12f else Math.max(0.03f, Math.min(0.45f, radius))
        speed = if (speed.isNaN()) 1f else Math.max(0.2f, Math.min(4f, speed))
        dead = if (dead.isNaN()) 0.12f else Math.max(0.03f, Math.min(0.6f, dead))
        rate = Math.max(2, Math.min(10, rate))
        dir = Math.max(0, Math.min(3, dir))
        while (steps.size > MAX_STEPS) steps.removeAt(steps.size - 1)
        for (st in steps) {
            st.x = PadProfile.clamp01(st.x)
            st.y = PadProfile.clamp01(st.y)
            st.hold = Math.max(MIN_HOLD, Math.min(MAX_HOLD, st.hold))
            st.wait = Math.max(0, Math.min(MAX_WAIT, st.wait))
        }
    }

    companion object {
        const val MAX_STEPS = 24
        const val MIN_HOLD = 30
        const val MAX_HOLD = 2000
        const val MAX_WAIT = 5000
    }
}

class PadProfile(
    var id: String,
    var pkg: String,
    var name: String,
    var enabled: Boolean = true,
    /** true = o perfil vale para o jogo em paisagem (largura > altura). */
    var landscape: Boolean = true,
    val bindings: MutableList<PadBinding> = ArrayList()
) {
    /**
     * Etapa 3: ler também o D-pad (quando o controle o manda como eixo) e os gatilhos analógicos como botões.
     * Só no Android 14+ e com um custo: enquanto o jogo está na frente, os eixos do controle não chegam a ele.
     */
    var axisKeys: Boolean = false

    fun bindingFor(b: PadButton): PadBinding? = bindings.firstOrNull { it.button == b }

    /** Cria ou atualiza a ligação do botão [b]. Posição sempre limitada a 0..1. */
    fun set(b: PadButton, mode: BindMode, x: Float, y: Float): PadBinding {
        val cx = clamp01(x)
        val cy = clamp01(y)
        val old = bindingFor(b)
        if (old != null) {
            old.mode = mode
            old.x = cx
            old.y = cy
            return old
        }
        val nb = PadBinding(b, mode, cx, cy)
        bindings.add(nb)
        return nb
    }

    fun remove(b: PadButton) {
        bindings.removeAll { it.button == b }
    }

    /** Quantos botões realmente fazem alguma coisa. */
    fun activeCount(): Int = bindings.count { it.mode != BindMode.OFF }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("pkg", pkg)
        o.put("name", name)
        o.put("enabled", enabled)
        o.put("landscape", landscape)
        o.put("axisKeys", axisKeys)
        val arr = JSONArray()
        for (b in bindings) {
            val j = JSONObject()
            j.put("b", b.button.name)
            j.put("m", b.mode.name)
            j.put("x", b.x.toDouble())
            j.put("y", b.y.toDouble())
            if (b.mode == BindMode.JOYSTICK || b.mode == BindMode.CAMERA || b.mode == BindMode.SLIDE) {
                j.put("r", b.radius.toDouble())
                j.put("s", b.speed.toDouble())
                j.put("dz", b.dead.toDouble())
            }
            if (b.mode == BindMode.SLIDE) j.put("dir", b.dir)
            if (b.mode == BindMode.TURBO) j.put("rt", b.rate)
            if (b.mode == BindMode.MACRO) {
                j.put("lp", b.loop)
                val ms = JSONArray()
                for (st in b.steps) {
                    val sj = JSONObject()
                    sj.put("x", st.x.toDouble())
                    sj.put("y", st.y.toDouble())
                    sj.put("h", st.hold)
                    sj.put("w", st.wait)
                    ms.put(sj)
                }
                j.put("ms", ms)
            }
            arr.put(j)
        }
        o.put("bindings", arr)
        return o
    }

    companion object {
        fun clamp01(v: Float): Float = if (v.isNaN()) 0.5f else if (v < 0f) 0f else if (v > 1f) 1f else v

        /** Lê um perfil; devolve null se faltar id ou pacote. Itens inválidos são ignorados, nunca derrubam a leitura. */
        fun fromJson(o: JSONObject): PadProfile? {
            val id = o.optString("id", "")
            val pkg = o.optString("pkg", "")
            if (id.isEmpty() || pkg.isEmpty()) return null
            val p = PadProfile(
                id, pkg, o.optString("name", pkg),
                o.optBoolean("enabled", true), o.optBoolean("landscape", true)
            )
            p.axisKeys = o.optBoolean("axisKeys", false)
            val arr = o.optJSONArray("bindings")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val j = arr.optJSONObject(i) ?: continue
                    val btn = PadButton.fromName(j.optString("b", "")) ?: continue
                    if (p.bindingFor(btn) != null) continue
                    val nb = p.set(
                        btn, BindMode.fromName(j.optString("m", "")),
                        j.optDouble("x", 0.5).toFloat(), j.optDouble("y", 0.5).toFloat()
                    )
                    nb.radius = j.optDouble("r", 0.12).toFloat()
                    nb.speed = j.optDouble("s", 1.0).toFloat()
                    nb.dead = j.optDouble("dz", 0.12).toFloat()
                    nb.rate = j.optInt("rt", 8)
                    nb.dir = j.optInt("dir", 0)
                    nb.loop = j.optBoolean("lp", false)
                    val ms = j.optJSONArray("ms")
                    if (ms != null) {
                        for (k in 0 until ms.length()) {
                            val sj = ms.optJSONObject(k) ?: continue
                            nb.steps.add(
                                MacroStep(
                                    sj.optDouble("x", 0.5).toFloat(), sj.optDouble("y", 0.5).toFloat(),
                                    sj.optInt("h", 60), sj.optInt("w", 150)
                                )
                            )
                        }
                    }
                    nb.clampParams()
                    if (nb.mode == BindMode.MACRO) {
                        nb.ensureMacro()
                        nb.syncAnchor()
                    }
                }
            }
            return p
        }
    }
}

/** Arquivo inteiro de perfis (versão + chave geral + lista). */
object PadJson {
    const val VERSION = 3

    fun write(on: Boolean, profiles: List<PadProfile>): String {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("on", on)
        val arr = JSONArray()
        for (p in profiles) arr.put(p.toJson())
        o.put("profiles", arr)
        return o.toString()
    }

    class Parsed(val on: Boolean, val profiles: List<PadProfile>)

    // ---- Etapa 4: exportar / importar

    /** Marca do arquivo exportado (o arquivo interno pad_profiles.json, sem a marca, também é aceito na importação). */
    const val APP_TAG = "WinLauncherPad"

    /** Texto do arquivo de backup: só os perfis (a chave geral "Mapeamento ligado" não viaja). */
    fun export(profiles: List<PadProfile>): String {
        val o = JSONObject()
        o.put("app", APP_TAG)
        o.put("v", VERSION)
        val arr = JSONArray()
        for (p in profiles) arr.put(p.toJson())
        o.put("profiles", arr)
        return o.toString(2)
    }

    /** Resultado da leitura de um arquivo importado: [error] != null = nada foi lido. [skipped] = itens inválidos ou repetidos. */
    class ImportResult(val profiles: List<PadProfile>, val skipped: Int, val error: String?)

    /** Nunca lança. Aceita o arquivo exportado e também o pad_profiles.json interno. */
    fun parseImport(text: String?): ImportResult {
        if (text.isNullOrBlank()) return ImportResult(emptyList(), 0, "O arquivo está vazio")
        try {
            val o = JSONObject(text)
            val app = o.optString("app", "")
            if (app.isNotEmpty() && app != APP_TAG) {
                return ImportResult(emptyList(), 0, "Este arquivo não é de perfis do mapeador de gamepad")
            }
            val arr = o.optJSONArray("profiles")
                ?: return ImportResult(emptyList(), 0, "Este arquivo não tem perfis do mapeador de gamepad")
            val list = ArrayList<PadProfile>()
            var skipped = 0
            for (i in 0 until arr.length()) {
                val j = arr.optJSONObject(i)
                val p = if (j == null) null else PadProfile.fromJson(j)
                if (p == null || list.any { it.pkg == p.pkg }) {
                    skipped++
                    continue
                }
                list.add(p)
            }
            if (list.isEmpty()) return ImportResult(list, skipped, "Nenhum perfil válido no arquivo")
            return ImportResult(list, skipped, null)
        } catch (e: Exception) {
            return ImportResult(emptyList(), 0, "Arquivo inválido (não é um JSON do mapeador)")
        }
    }

    /** [added] = apps novos; [replaced] = apps que já tinham perfil e foram trocados; [kept] = apps que já tinham perfil e foram mantidos. */
    class MergeResult(val added: Int, val replaced: Int, val kept: Int)

    /**
     * Junta [incoming] em [existing] (muda a lista). Um perfil por app: se o app já tem perfil, [replace] decide entre trocar
     * (o perfil novo herda o id e a posição do antigo) ou manter o antigo. Id repetido de OUTRO app ganha um id novo.
     */
    fun merge(existing: MutableList<PadProfile>, incoming: List<PadProfile>, replace: Boolean): MergeResult {
        var added = 0
        var replaced = 0
        var kept = 0
        for (p in incoming) {
            val idx = existing.indexOfFirst { it.pkg == p.pkg }
            if (idx >= 0) {
                if (replace) {
                    p.id = existing[idx].id
                    existing[idx] = p
                    replaced++
                } else {
                    kept++
                }
            } else {
                if (existing.any { it.id == p.id }) p.id = freshId(existing)
                existing.add(p)
                added++
            }
        }
        return MergeResult(added, replaced, kept)
    }

    private fun freshId(existing: List<PadProfile>): String {
        var n = System.currentTimeMillis()
        var id = java.lang.Long.toString(n, 36)
        while (existing.any { it.id == id }) {
            n++
            id = java.lang.Long.toString(n, 36)
        }
        return id
    }

    /** Nunca lança: arquivo estragado vira "ligado, sem perfis". */
    fun read(text: String?): Parsed {
        if (text.isNullOrBlank()) return Parsed(true, emptyList())
        return try {
            val o = JSONObject(text)
            val list = ArrayList<PadProfile>()
            val arr = o.optJSONArray("profiles")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val j = arr.optJSONObject(i) ?: continue
                    val p = PadProfile.fromJson(j) ?: continue
                    if (list.none { it.id == p.id || it.pkg == p.pkg }) list.add(p)
                }
            }
            Parsed(o.optBoolean("on", true), list)
        } catch (e: Exception) {
            Parsed(true, emptyList())
        }
    }
}

/**
 * Etapa 3 - ajustes por botão, descritos como dados para que o editor sobre o jogo e o painel desenhem os mesmos
 * controles (−/+) sem repetir regra. Sem Android: testado na JVM.
 *
 * [change] recebe +1 (mais) ou -1 (menos) e já respeita os limites. [scope]: "bind" = vale para o botão todo;
 * "step" = vale para o passo da macro escolhido (o índice vai em [PadTuning.paramsFor]).
 */
class TuneParam(
    val key: String,
    val label: String,
    /** true = um botão só que gira entre as opções (direção, repetir); false = par −/+. */
    val cycle: Boolean,
    val text: (PadBinding) -> String,
    val change: (PadBinding, Int) -> Unit
)

object PadTuning {

    private fun pct(v: Float) = Math.round(v * 100f).toString() + "%"

    private fun clampF(v: Float, lo: Float, hi: Float) = Math.max(lo, Math.min(hi, v))

    /** Arredonda para 2 casas para os passos de 0,01 não acumularem erro de ponto flutuante. */
    private fun r2(v: Float) = Math.round(v * 100f) / 100f

    val DIR_NAMES = arrayOf("Cima", "Baixo", "Esquerda", "Direita")
    val DIR_ARROWS = arrayOf("↑", "↓", "←", "→")

    private val radius = TuneParam("r", "Raio", false, { pct(it.radius) }) { b, d ->
        b.radius = r2(clampF(b.radius + d * 0.01f, 0.03f, 0.45f))
    }
    private val speed = TuneParam("s", "Velocidade", false, { String.format(java.util.Locale.US, "%.1fx", it.speed) }) { b, d ->
        b.speed = r2(clampF(b.speed + d * 0.1f, 0.2f, 4f))
    }
    private val dead = TuneParam("dz", "Zona morta", false, { pct(it.dead) }) { b, d ->
        b.dead = r2(clampF(b.dead + d * 0.01f, 0.03f, 0.6f))
    }
    private val rate = TuneParam("rt", "Toques/s", false, { it.rate.toString() }) { b, d ->
        b.rate = Math.max(2, Math.min(10, b.rate + d))
    }
    private val dir = TuneParam("dir", "Direção", true, { PadTuning.DIR_ARROWS[it.dir] + " " + PadTuning.DIR_NAMES[it.dir] }) { b, d ->
        b.dir = ((b.dir + d) % 4 + 4) % 4
    }
    private val loopP = TuneParam("lp", "Repetir", true, { if (it.loop) "Sim" else "Uma vez" }) { b, _ ->
        b.loop = !b.loop
    }

    private fun stepHold(i: Int) = TuneParam("h", "Toque", false, { b -> (b.steps.getOrNull(i)?.hold ?: 0).toString() + " ms" }) { b, d ->
        val st = b.steps.getOrNull(i) ?: return@TuneParam
        val step = if (st.hold >= 500) 50 else 10
        st.hold = Math.max(PadBinding.MIN_HOLD, Math.min(PadBinding.MAX_HOLD, st.hold + d * step))
    }

    private fun stepWait(i: Int) = TuneParam("w", "Espera", false, { b -> (b.steps.getOrNull(i)?.wait ?: 0).toString() + " ms" }) { b, d ->
        val st = b.steps.getOrNull(i) ?: return@TuneParam
        val step = if (st.wait >= 1000) 100 else 25
        st.wait = Math.max(0, Math.min(PadBinding.MAX_WAIT, st.wait + d * step))
    }

    /** Os ajustes que existem para o modo atual de [b]. [step] = passo da macro escolhido. */
    fun paramsFor(b: PadBinding, step: Int = 0): List<TuneParam> = when (b.mode) {
        BindMode.JOYSTICK -> listOf(radius, dead)
        BindMode.CAMERA -> listOf(radius, speed, dead)
        BindMode.SLIDE -> listOf(radius, dir, dead)
        BindMode.TURBO -> listOf(rate)
        BindMode.MACRO -> listOf(stepHold(step), stepWait(step), loopP)
        else -> emptyList()
    }
}
