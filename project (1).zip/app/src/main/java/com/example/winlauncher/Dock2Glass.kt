package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import kotlin.math.roundToInt

/**
 * Vidro da Dock 2 e das janelas abertas por ela. Usa o mesmo instantâneo borrado do wallpaper
 * ([Glass.bitmap]) que o resto do launcher; só acrescenta o controle de intensidade do desfoque.
 *
 * Intensidade 0..100:
 *  - 0        : sem desfoque (só a película de cor sobre o wallpaper nítido)
 *  - 1..34    : mistura entre o wallpaper nítido e o vidro padrão
 *  - 35       : vidro padrão do launcher (idêntico ao GlassDrawable existente)
 *  - 36..100  : desfoque extra, cada vez mais forte
 */
const val DOCK_BLUR_DEFAULT = 35

/** Cache dos instantâneos com desfoque extra (recalculado só quando o wallpaper ou o nível mudam). */
internal object DockGlassCache {
    private var src: Bitmap? = null
    private val map = HashMap<Int, Bitmap>()

    fun get(source: Bitmap, extra: Int): Bitmap {
        if (extra <= 0) return source
        if (src !== source) {
            src = source
            map.clear()
        }
        return map.getOrPut(extra) { boxBlur(source, extra, 2) }
    }

    private fun boxBlur(bmp: Bitmap, radius: Int, passes: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        var a = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        var b = IntArray(w * h)
        val n = radius * 2 + 1
        for (p in 0 until passes) {
            for (y in 0 until h) {
                for (x in 0 until w) {
                    var sa = 0; var sr = 0; var sg = 0; var sb = 0
                    for (k in -radius..radius) {
                        val c = a[y * w + (x + k).coerceIn(0, w - 1)]
                        sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                    }
                    b[y * w + x] = ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                }
            }
            for (y in 0 until h) {
                for (x in 0 until w) {
                    var sa = 0; var sr = 0; var sg = 0; var sb = 0
                    for (k in -radius..radius) {
                        val c = b[(y + k).coerceIn(0, h - 1) * w + x]
                        sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                    }
                    a[y * w + x] = ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                }
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }
}

class DockGlassDrawable(
    private val host: View,
    private val tint: Int,
    private val radius: Float,
    private val blur: Int
) : Drawable() {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val dst = Rect()
    private val loc = IntArray(2)
    private val rloc = IntArray(2)

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        val outer = canvas.save()
        canvas.clipPath(path)
        val bmp = Glass.bitmap
        val r = Glass.root
        val level = blur.coerceIn(0, 100)
        if (level > 0 && bmp != null && r != null && !bmp.isRecycled && r.width > 0 && r.height > 0) {
            val extra = if (level > DOCK_BLUR_DEFAULT) ((level - DOCK_BLUR_DEFAULT) * 6f / (100 - DOCK_BLUR_DEFAULT)).roundToInt() else 0
            val use = DockGlassCache.get(bmp, extra)
            paint.alpha = if (level >= DOCK_BLUR_DEFAULT) 255 else (255 * level / DOCK_BLUR_DEFAULT.toFloat()).toInt()
            host.getLocationOnScreen(loc)
            r.getLocationOnScreen(rloc)
            val inner = canvas.save()
            canvas.translate((rloc[0] - loc[0]).toFloat(), (rloc[1] - loc[1]).toFloat())
            dst.set(0, 0, r.width, r.height)
            canvas.drawBitmap(use, null, dst, paint)
            canvas.restoreToCount(inner)
        }
        canvas.drawColor(tint)
        canvas.restoreToCount(outer)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * Fundo padrão de todas as janelas da Dock 2 (Dock, painel rápido, seletor de apps):
 * vidro com desfoque ajustável ou cor translúcida, sempre com os mesmos cantos.
 */
internal fun dockBackground(
    host: View,
    base: Int,
    alphaPct: Int,
    radiusPx: Float,
    glass: Boolean,
    blur: Int
): Drawable {
    val al = alphaPct * 255 / 100
    return if (glass) {
        DockGlassDrawable(host, (((al * 0.6f).toInt().coerceIn(0, 255)) shl 24) or (base and 0xFFFFFF), radiusPx, blur)
    } else {
        GradientDrawable().apply {
            setColor((al.coerceIn(0, 255) shl 24) or (base and 0xFFFFFF))
            cornerRadius = radiusPx
        }
    }
}

/** Borda suave com a espessura/cor/opacidade da Dock 2. */
internal fun dockBorder(radiusPx: Float, widthPx: Int, color: Int): Drawable =
    GradientDrawable().apply {
        setColor(0)
        cornerRadius = radiusPx
        if (widthPx > 0) setStroke(widthPx, color)
    }

internal fun withAlpha(color: Int, pct: Int): Int =
    ((((color ushr 24) * pct.coerceIn(0, 100)) / 100) shl 24) or (color and 0xFFFFFF)
