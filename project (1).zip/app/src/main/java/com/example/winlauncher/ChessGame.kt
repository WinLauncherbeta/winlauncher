package com.example.winlauncher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * Xadrez básico para a página "Jogos" das Configurações: tabuleiro, regras, bot (fácil/médio/difícil)
 * ou 2 jogadores no mesmo aparelho, desfazer e botão de tela cheia (o dono da tela decide o que
 * cada modo significa e é avisado por [onFullscreen]).
 */
class ChessPanel(private val ctx: Context, private val onFullscreen: () -> Unit) : LinearLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val handler = Handler(Looper.getMainLooper())

    private val cText = Color.WHITE
    private val cSub = Color.parseColor("#9AA5B8")
    private val cAcc = Color.parseColor("#19B4F0")

    // ---- estado do jogo
    private var pos = ChessEngine.start()
    private val history = ArrayList<ChessEngine.Pos>()
    private var lastFrom = -1
    private var lastTo = -1
    private var selected = -1
    private var targets: List<ChessEngine.Move> = emptyList()
    private var vsBot = true
    private var level = 1 // 0 fácil, 1 médio, 2 difícil
    private var thinking = false
    private var generation = 0
    private var over = false
    private var result = ""

    private val statusView = TextView(ctx)
    private val board = BoardView(ctx)
    private lateinit var fsBtn: TextView
    private lateinit var modeBtn: TextView
    private lateinit var levelBtn: TextView

    private val levelNames = arrayOf("Fácil", "Médio", "Difícil")

    /** 0 = janela, 1 = tela cheia com barra de tarefas, 2 = tela cheia total. */
    fun setFullscreenMode(m: Int) {
        fsBtn.text = when (m) {
            0 -> "⛶  Tela cheia"
            1 -> "⛶  Tela cheia total"
            else -> "⮌  Sair da tela cheia"
        }
    }

    init {
        orientation = VERTICAL
        statusView.textSize = 14f
        statusView.setTextColor(cText)
        statusView.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        statusView.setPadding(dp(4), dp(2), dp(4), dp(8))
        addView(statusView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val chips = LinearLayout(ctx)
        chips.orientation = HORIZONTAL
        chips.addView(chip("Novo jogo") { newGame() })
        chips.addView(chip("Desfazer") { undo() })
        modeBtn = chip("") { vsBot = !vsBot; newGame() }
        chips.addView(modeBtn)
        levelBtn = chip("") { level = (level + 1) % 3; refreshChips(); if (vsBot) newGame() }
        chips.addView(levelBtn)
        fsBtn = chip("⛶  Tela cheia") { onFullscreen() }
        chips.addView(fsBtn)
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        addView(hs, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })

        addView(board, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        refreshChips()
        updateStatus()
    }

    private fun chip(text: String, click: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 12.5f
        t.setTextColor(cText)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#1FFFFFFF"))
        bg.cornerRadius = dp(6).toFloat()
        t.background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), bg, null)
        t.isClickable = true
        t.setOnClickListener { click() }
        t.layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }
        return t
    }

    private fun refreshChips() {
        modeBtn.text = if (vsBot) "Modo: contra o bot" else "Modo: 2 jogadores"
        levelBtn.text = "Nível: " + levelNames[level]
        levelBtn.alpha = if (vsBot) 1f else 0.4f
    }

    // ------------------------------------------------------------------ jogo

    private fun newGame() {
        generation++
        thinking = false
        pos = ChessEngine.start()
        history.clear()
        lastFrom = -1
        lastTo = -1
        selected = -1
        targets = emptyList()
        over = false
        result = ""
        refreshChips()
        updateStatus()
        board.invalidate()
    }

    private fun undo() {
        if (history.isEmpty()) return
        generation++ // cancela o bot, se estiver pensando
        thinking = false
        // contra o bot volta até a vez das brancas (a sua)
        do {
            pos = history.removeAt(history.lastIndex)
        } while (vsBot && !pos.white && history.isNotEmpty())
        lastFrom = -1
        lastTo = -1
        selected = -1
        targets = emptyList()
        over = false
        result = ""
        updateStatus()
        board.invalidate()
    }

    private fun onCell(sq: Int) {
        if (over || thinking) return
        if (vsBot && !pos.white) return
        val p = pos.b[sq]
        if (selected != -1) {
            val m = targets.firstOrNull { it.to == sq }
            if (m != null) {
                play(m)
                return
            }
        }
        if (p != 0 && (p > 0) == pos.white) {
            selected = sq
            targets = ChessEngine.legalFrom(pos, sq)
        } else {
            selected = -1
            targets = emptyList()
        }
        board.invalidate()
    }

    private fun play(m: ChessEngine.Move) {
        history.add(pos)
        pos = ChessEngine.apply(pos, m)
        lastFrom = m.from
        lastTo = m.to
        selected = -1
        targets = emptyList()
        when (ChessEngine.status(pos)) {
            ChessEngine.CHECKMATE -> {
                over = true
                val whiteWon = !pos.white
                result = if (vsBot) (if (whiteWon) "Xeque-mate! Você ganhou 🎉" else "Xeque-mate! O bot ganhou")
                else (if (whiteWon) "Xeque-mate! Brancas vencem" else "Xeque-mate! Pretas vencem")
            }
            ChessEngine.STALEMATE -> {
                over = true
                result = "Empate por afogamento"
            }
        }
        updateStatus()
        board.invalidate()
        if (!over && vsBot && !pos.white) botMove()
    }

    private fun botMove() {
        thinking = true
        val gen = ++generation
        val snapshot = pos
        val lv = level
        updateStatus()
        Thread {
            val start = System.currentTimeMillis()
            val m = try {
                ChessEngine.bestMove(snapshot, lv)
            } catch (t: Throwable) {
                null
            }
            val wait = 350L - (System.currentTimeMillis() - start)
            if (wait > 0) try { Thread.sleep(wait) } catch (e: InterruptedException) { }
            handler.post {
                if (gen != generation) return@post
                thinking = false
                if (m != null) play(m) else updateStatus()
            }
        }.start()
    }

    private fun updateStatus() {
        val inCheck = !over && ChessEngine.inCheck(pos.b, pos.white)
        statusView.text = when {
            over -> result
            thinking -> "Bot pensando…"
            vsBot -> if (inCheck) "Xeque! Sua vez (brancas)" else "Sua vez (brancas)"
            else -> (if (pos.white) "Vez das brancas" else "Vez das pretas") + (if (inCheck) " — xeque!" else "")
        }
    }

    // ------------------------------------------------------------------ tabuleiro

    private inner class BoardView(c: Context) : View(c) {
        private val light = Color.parseColor("#DCE6F5")
        private val dark = Color.parseColor("#5B7DB1")
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pieceFill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pieceStroke = Paint(Paint.ANTI_ALIAS_FLAG)
        private val label = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glyphs = arrayOf("", "\u265F\uFE0E", "\u265E", "\u265D", "\u265C", "\u265B", "\u265A")
        private var cell = 0f
        private var ox = 0f
        private var oy = 0f

        init {
            val tf = try {
                Typeface.createFromAsset(c.assets, "fonts/chess_pieces.ttf")
            } catch (t: Throwable) {
                Typeface.DEFAULT
            }
            pieceFill.typeface = tf
            pieceStroke.typeface = tf
            pieceFill.textAlign = Paint.Align.CENTER
            pieceStroke.textAlign = Paint.Align.CENTER
            pieceStroke.style = Paint.Style.STROKE
            label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

        override fun onDraw(canvas: Canvas) {
            val side = min(width, height).toFloat()
            cell = side / 8f
            ox = (width - side) / 2f
            oy = (height - side) / 2f
            val kingSq = kingSquare()
            val checked = ChessEngine.inCheck(pos.b, pos.white)

            for (sq in 0 until 64) {
                val r = sq / 8
                val c = sq % 8
                val x = ox + c * cell
                val y = oy + r * cell
                paint.style = Paint.Style.FILL
                paint.color = if ((r + c) % 2 == 0) light else dark
                canvas.drawRect(x, y, x + cell, y + cell, paint)
                if (sq == lastFrom || sq == lastTo) {
                    paint.color = Color.parseColor("#55FFE066")
                    canvas.drawRect(x, y, x + cell, y + cell, paint)
                }
                if (sq == selected) {
                    paint.color = Color.parseColor("#8819B4F0")
                    canvas.drawRect(x, y, x + cell, y + cell, paint)
                }
                if (checked && sq == kingSq) {
                    paint.color = Color.parseColor("#88FF3B30")
                    canvas.drawRect(x, y, x + cell, y + cell, paint)
                }
                // coordenadas
                label.textSize = cell * 0.17f
                label.color = if ((r + c) % 2 == 0) dark else light
                if (c == 0) {
                    label.textAlign = Paint.Align.LEFT
                    canvas.drawText((8 - r).toString(), x + cell * 0.06f, y + cell * 0.2f, label)
                }
                if (r == 7) {
                    label.textAlign = Paint.Align.RIGHT
                    canvas.drawText(('a' + c).toString(), x + cell * 0.94f, y + cell * 0.95f, label)
                }
            }

            // peças
            val size = cell * 0.82f
            pieceFill.textSize = size
            pieceStroke.textSize = size
            pieceStroke.strokeWidth = cell * 0.025f
            val fm = pieceFill.fontMetrics
            val dy = -(fm.ascent + fm.descent) / 2f
            for (sq in 0 until 64) {
                val p = pos.b[sq]
                if (p == 0) continue
                val cx = ox + (sq % 8) * cell + cell / 2f
                val cy = oy + (sq / 8) * cell + cell / 2f
                val white = p > 0
                pieceFill.color = if (white) Color.WHITE else Color.parseColor("#1A1A22")
                pieceStroke.color = if (white) Color.parseColor("#1A1A22") else Color.parseColor("#C8D3E6")
                val g = glyphs[abs(p)]
                canvas.drawText(g, cx, cy + dy, pieceFill)
                canvas.drawText(g, cx, cy + dy, pieceStroke)
            }

            // destinos possíveis
            for (m in targets) {
                val cx = ox + (m.to % 8) * cell + cell / 2f
                val cy = oy + (m.to / 8) * cell + cell / 2f
                if (pos.b[m.to] != 0) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = cell * 0.08f
                    paint.color = Color.parseColor("#CCFF6B5E")
                    canvas.drawCircle(cx, cy, cell * 0.44f, paint)
                } else {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#AA19B4F0")
                    canvas.drawCircle(cx, cy, cell * 0.14f, paint)
                }
            }
        }

        private fun kingSquare(): Int {
            val k = if (pos.white) 6 else -6
            for (i in 0 until 64) if (pos.b[i] == k) return i
            return -1
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> return true
                MotionEvent.ACTION_UP -> {
                    val c = ((e.x - ox) / cell).toInt()
                    val r = ((e.y - oy) / cell).toInt()
                    if (e.x >= ox && e.y >= oy && c in 0..7 && r in 0..7) {
                        onCell(r * 8 + c)
                        performClick()
                    }
                    return true
                }
            }
            return super.onTouchEvent(e)
        }

        override fun performClick(): Boolean = super.performClick()
    }
}
