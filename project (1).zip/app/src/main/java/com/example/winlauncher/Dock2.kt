package com.example.winlauncher

import android.content.ComponentName
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Dock 2: segunda dock flutuante, totalmente independente da barra de tarefas.
 * Tem lista de apps própria (chave "dk2"), preferências próprias ("ui_d2_*") e painel próprio
 * em "Personalizar WinLauncher > Dock 2". Não toca em nenhuma view da barra principal.
 */
class SecondDock(
    private val act: MainActivity,
    private val root: FrameLayout,
    private val cfg: Prefs,
    private val prefs: SharedPreferences,
    private val apps: () -> List<AppItem>,
    private val iconOf: (AppItem) -> Drawable,
    private val launch: (ComponentName) -> Unit,
    private val rightClickRecent: () -> Boolean,
    private val isLight: () -> Boolean,
    private val accent: () -> Int,
    private val ripple: () -> Int,
    /** Espaço ocupado pela barra principal em px: [topo, base]. */
    private val taskbarInset: () -> IntArray,
    private val panelsOpen: () -> Boolean,
    private val tiles: () -> List<Tile>
) {
    companion object {
        const val KEY = "dk2"
        const val INIT = "dk2_init"
    }

    private val dm = act.resources.displayMetrics
    private fun dp(v: Int): Int = (v * dm.density + 0.5f).toInt()
    private fun argb(a: Int, rgb: Int): Int = (a.coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)

    val view = LinearLayout(act)
    private val pins = ArrayList<Pair<View, String>>()
    private var picker: FrameLayout? = null
    private var arrow: ImageView? = null

    /** Painel de configurações rápidas aberto pela seta da Dock 2. */
    val quick = DockQuickPanel(
        act, root, cfg, tiles, { effLight() }, { baseRgb() }, accent, ripple,
        windowBg = { host, r -> windowBackground(host, r) },
        dockView = { view },
        onOpenChange = { updateArrow() }
    )
    private var downRaw = 0f
    private var dragging = false

    init {
        view.clipChildren = false
        view.clipToPadding = false
        view.gravity = Gravity.CENTER
        view.elevation = dp(6).toFloat()
        // a janela acompanha a Dock se ela mudar de tamanho/posição
        view.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> quick.reposition() }
    }

    /** Insere catcher, Dock e janela rápida na ordem correta (acima da área de trabalho, abaixo da tela de bloqueio). */
    fun attachTo(index: Int) {
        root.addView(quick.catcher, index, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(view, index + 1, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(quick.popup, index + 2, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        // responsiva: se a tela mudar de tamanho (rotação, janela), a Dock e o painel se reorganizam
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) view.post { apply() }
        }
    }

    /** Fecha o que estiver aberto por cima da Dock (seletor de apps ou painel rápido). */
    fun closeTransient(): Boolean = closePicker() || quick.close()

    private fun updateArrow() {
        val a = arrow ?: return
        val base = when (cfg.d2Pos) { 0 -> 0f; 1 -> 180f; 2 -> 90f; else -> -90f }
        val target = base + (if (quick.isOpen) 180f else 0f)
        if (cfg.anim) a.animate().rotation(target).setDuration(140).start() else a.rotation = target
    }

    // ------------------------------------------------------------ dados

    fun list(): List<String> =
        (prefs.getString(KEY, "") ?: "").split("|").filter { it.isNotEmpty() }

    private fun setList(l: List<String>) {
        prefs.edit().putString(KEY, l.joinToString("|")).apply()
    }

    fun contains(key: String): Boolean = key in list()

    fun toggle(key: String) {
        val l = list().toMutableList()
        if (!l.remove(key)) l.add(key)
        setList(l)
        rebuild()
    }

    /** Na primeira vez, a Dock 2 começa com uma cópia (independente) dos apps da barra principal. */
    private fun seed() {
        if (prefs.getBoolean(INIT, false) || apps().isEmpty()) return
        val tb = (prefs.getString("tb", "") ?: "").split("|").filter { it.isNotEmpty() }
        val valid = tb.filter { k -> apps().any { it.cn.flattenToString() == k } }.take(6)
        setList(valid)
        prefs.edit().putBoolean(INIT, true).apply()
    }

    private fun appFor(key: String): AppItem? = apps().firstOrNull { it.cn.flattenToString() == key }

    // ------------------------------------------------------------ aparência

    /** Tema efetivo da Dock 2 (a tonalidade escolhida pode diferir do tema do launcher). */
    private fun effLight(): Boolean = when (cfg.d2Tint) {
        1 -> false
        2 -> true
        else -> isLight()
    }

    private fun baseRgb(): Int = when (cfg.d2Tint) {
        1 -> 0x1C1C1C
        2 -> 0xF3F3F3
        3 -> accent() and 0xFFFFFF
        else -> if (isLight()) 0xF3F3F3 else 0x1C1C1C
    }

    private fun fg(): Int = if (effLight() && cfg.d2Bg != 2) Color.parseColor("#1F1F1F") else Color.WHITE

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun rip(r: Int): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(ripple()), rounded(Color.TRANSPARENT, r), rounded(Color.WHITE, r))

    private fun applyStyle() {
        val r = dp(cfg.d2Radius).toFloat()
        val bg: Drawable = if (cfg.d2Bg == 2) {
            ColorDrawable(Color.TRANSPARENT)
        } else {
            dockBackground(view, baseRgb(), cfg.d2Alpha, r, cfg.d2Bg == 1, cfg.d2Blur)
        }
        view.background = LayerDrawable(arrayOf(bg, dockBorder(r, dp(cfg.d2Border), borderColor())))
        val pad = dp(cfg.d2Pad)
        view.setPadding(pad, pad, pad, pad)
        view.elevation = if (cfg.d2Bg == 2) 0f else dp(6).toFloat()
        // largura/altura mínimas (0 = automático), sempre dentro da tela
        val sw = dm.widthPixels - 2 * dp(cfg.d2Margin)
        val sh = dm.heightPixels - 2 * dp(cfg.d2Margin) - taskbarInset().let { it[0] + it[1] }
        view.minimumWidth = min(dp(cfg.d2W), max(0, sw))
        view.minimumHeight = min(dp(cfg.d2H), max(0, sh))
    }

    /** Cor da borda com a opacidade escolhida. */
    private fun borderColor(): Int {
        val c = if (cfg.d2BorderColor == 1) accent() or (0xFF shl 24)
        else if (effLight()) Color.BLACK else Color.WHITE
        return withAlpha(c, cfg.d2BorderOpacity)
    }

    /** Cor/estilo compartilhados com as janelas abertas pela Dock (painel rápido e seletor). */
    internal fun windowBackground(host: View, radiusDp: Int): Drawable {
        val r = dp(radiusDp).toFloat()
        val bg = dockBackground(host, baseRgb(), cfg.d2qAlpha, r, cfg.d2qBg == 1, cfg.d2qBlur)
        return LayerDrawable(arrayOf(bg, dockBorder(r, dp(cfg.d2Border), borderColor())))
    }

    private fun place() {
        val m = dp(cfg.d2Margin)
        val vertical = cfg.d2Pos >= 2
        val side = when (cfg.d2Pos) {
            0 -> Gravity.BOTTOM
            1 -> Gravity.TOP
            2 -> Gravity.START
            else -> Gravity.END
        }
        val align = if (vertical) {
            when (cfg.d2Align) { 0 -> Gravity.TOP; 2 -> Gravity.BOTTOM; else -> Gravity.CENTER_VERTICAL }
        } else {
            when (cfg.d2Align) { 0 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
        }
        val inset = taskbarInset()
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, side or align)
        lp.leftMargin = m
        lp.rightMargin = m
        lp.topMargin = m + inset[0]
        lp.bottomMargin = m + inset[1]
        view.layoutParams = lp
    }

    /** Mostra/esconde conforme a opção e enquanto algum painel do launcher está aberto. */
    fun syncVisibility() {
        val v = when {
            !cfg.d2On -> View.GONE
            panelsOpen() -> View.INVISIBLE
            else -> View.VISIBLE
        }
        if (v != View.VISIBLE) quick.close()
        if (view.visibility != v) view.visibility = v
    }

    fun apply() {
        applyStyle()
        place()
        rebuild()
        syncVisibility()
        quick.applyStyle()
        quick.reposition()
    }

    fun invalidateGlass() {
        view.invalidate()
        quick.popup.invalidate()
        picker?.invalidate()
    }

    /** Itens da Dock 2 como (chave, nome) para a tela de remoção; inclui apps hoje indisponíveis. */
    fun items(): List<Pair<String, String>> = list().map { k ->
        val label = appFor(k)?.label
            ?: ((ComponentName.unflattenFromString(k)?.packageName ?: k) + " (indisponível)")
        Pair(k, label)
    }

    /** Remove só da Dock 2; o app continua instalado e nas outras áreas do launcher. */
    fun removeKey(key: String) {
        val l = list().toMutableList()
        if (l.remove(key)) {
            setList(l)
            rebuild()
        }
    }

    fun resetLook() {
        cfg.d2Pos = 0; cfg.d2Align = 1; cfg.d2Bg = 1; cfg.d2Alpha = 70; cfg.d2Icon = 44
        cfg.d2Space = 6; cfg.d2Pad = 8; cfg.d2Radius = 18; cfg.d2Border = 1
        cfg.d2BorderColor = 0; cfg.d2Margin = 10
        cfg.d2Blur = DOCK_BLUR_DEFAULT; cfg.d2qBlur = DOCK_BLUR_DEFAULT; cfg.d2Tint = 0
        cfg.d2W = 0; cfg.d2H = 0; cfg.d2BorderOpacity = -1
        cfg.d2qOn = true; cfg.d2qW = 300; cfg.d2qCols = 3; cfg.d2qTile = 64
        cfg.d2qAlpha = 75; cfg.d2qBg = 1; cfg.d2qRadius = 16
        apply()
    }

    // ------------------------------------------------------------ montagem

    fun rebuild() {
        seed()
        view.removeAllViews()
        pins.clear()
        arrow = null
        quick.anchor = null
        if (!cfg.d2On) {
            quick.close()
            syncVisibility()
            return
        }
        val vertical = cfg.d2Pos >= 2
        view.orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        val slot = dp(cfg.d2Icon)
        val gap = dp(cfg.d2Space)
        val pad = dp(cfg.d2Pad)
        val m = dp(cfg.d2Margin)
        val inset = taskbarInset()
        val avail = if (vertical) {
            dm.heightPixels - inset[0] - inset[1] - 2 * m - 2 * pad
        } else {
            dm.widthPixels - 2 * m - 2 * pad
        }
        val maxN = max(1, (avail + gap) / (slot + gap) - (if (cfg.d2qOn) 1 else 0))
        val items = list().mapNotNull { appFor(it) }.take(maxN)
        val padA = (slot * 8f / 44f).toInt()

        if (items.isEmpty()) {
            val plus = TextView(act)
            plus.text = "+"
            plus.textSize = 22f
            plus.gravity = Gravity.CENTER
            plus.setTextColor(fg())
            plus.typeface = Typeface.DEFAULT_BOLD
            plus.background = rip(10)
            plus.isClickable = true
            plus.setOnClickListener { openPicker() }
            view.addView(plus, LinearLayout.LayoutParams(slot, slot))
        }
        for ((i, a) in items.withIndex()) {
            val key = a.cn.flattenToString()
            val iv = ImageView(act)
            iv.setImageDrawable(iconOf(a))
            iv.setPadding(padA, padA, padA, padA)
            iv.background = rip(10)
            iv.isClickable = true
            iv.setOnClickListener {
                if (!rightClickRecent()) {
                    quick.close()
                    launch(a.cn)
                }
            }
            attachTouch(iv, key, a)
            pins.add(Pair(iv, key))
            val lp = LinearLayout.LayoutParams(slot, slot)
            if (i > 0) {
                if (vertical) lp.topMargin = gap else lp.leftMargin = gap
            }
            view.addView(iv, lp)
        }
        if (cfg.d2qOn) {
            val ar = ImageView(act)
            ar.setImageResource(R.drawable.ic_chevron_up)
            ar.setColorFilter(fg())
            val ap = (slot * 0.28f).toInt()
            ar.setPadding(ap, ap, ap, ap)
            ar.background = rip(10)
            ar.isClickable = true
            ar.setOnClickListener {
                if (!rightClickRecent()) quick.toggle()
            }
            val alp = LinearLayout.LayoutParams(slot, slot)
            if (view.childCount > 0) {
                if (vertical) alp.topMargin = gap else alp.leftMargin = gap
            }
            view.addView(ar, alp)
            arrow = ar
            quick.anchor = ar
            updateArrow()
        } else {
            quick.close()
        }
        syncVisibility()
    }

    // ------------------------------------------------------------ interação

    private fun isRight(ev: MotionEvent): Boolean =
        ev.actionMasked == MotionEvent.ACTION_DOWN &&
            ev.isFromSource(InputDevice.SOURCE_MOUSE) &&
            (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0

    private fun attachTouch(v: View, key: String, app: AppItem) {
        v.setOnTouchListener { _, ev ->
            if (isRight(ev)) {
                appMenu(app, key, ev.rawX.toInt(), ev.rawY.toInt())
                return@setOnTouchListener true
            }
            val vertical = cfg.d2Pos >= 2
            val cur = if (vertical) ev.rawY else ev.rawX
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRaw = cur
                    dragging = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && abs(cur - downRaw) > dp(10)) {
                        dragging = true
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL
                        v.onTouchEvent(c)
                        c.recycle()
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        v.elevation = dp(8).toFloat()
                        v.alpha = 0.85f
                    }
                    if (dragging) {
                        if (vertical) v.translationY = cur - downRaw else v.translationX = cur - downRaw
                        true
                    } else false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        finishDrag(v, key)
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun finishDrag(v: View, key: String) {
        val vertical = cfg.d2Pos >= 2
        val center = if (vertical) v.top + v.height / 2f + v.translationY
        else v.left + v.width / 2f + v.translationX
        val others = pins.filter { it.second != key }
        var newIdx = 0
        for (o in others) {
            val oc = if (vertical) o.first.top + o.first.height / 2f else o.first.left + o.first.width / 2f
            if (oc < center) newIdx++
        }
        val l = list().toMutableList()
        if (others.isNotEmpty() && key in l) {
            l.remove(key)
            val dest = if (newIdx < others.size) l.indexOf(others[newIdx].second)
            else l.indexOf(others.last().second) + 1
            l.add(dest.coerceIn(0, l.size), key)
            setList(l)
        }
        rebuild()
    }

    private fun move(key: String, dir: Int) {
        val idx = pins.indexOfFirst { it.second == key }
        val nIdx = idx + dir
        if (idx < 0 || nIdx !in pins.indices) return
        val l = list().toMutableList()
        val a = l.indexOf(key)
        val b = l.indexOf(pins[nIdx].second)
        if (a < 0 || b < 0) return
        val t = l[a]
        l[a] = l[b]
        l[b] = t
        setList(l)
        rebuild()
    }

    private fun appMenu(app: AppItem, key: String, x: Int, y: Int) {
        val vertical = cfg.d2Pos >= 2
        val idx = pins.indexOfFirst { it.second == key }
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Abrir", R.drawable.ic_open, action = { launch(app.cn) }))
        items.add(
            MenuItem(
                if (vertical) "Mover para cima" else "Mover para a esquerda",
                R.drawable.ic_chevron_up,
                enabled = idx > 0,
                action = { move(key, -1) }
            )
        )
        items.add(
            MenuItem(
                if (vertical) "Mover para baixo" else "Mover para a direita",
                R.drawable.ic_chevron_down,
                enabled = idx in 0 until pins.size - 1,
                action = { move(key, 1) }
            )
        )
        items.add(MenuItem("Remover da Dock 2", R.drawable.ic_close, action = { toggle(key) }))
        items.add(MenuItem("Adicionar / remover aplicativos", R.drawable.ic_pin, action = { openPicker() }))
        act.menu.show(items, x, y)
    }

    // ------------------------------------------------------------ seletor de apps

    fun closePicker(): Boolean {
        val p = picker ?: return false
        root.removeView(p)
        picker = null
        return true
    }

    fun openPicker() {
        if (picker != null) return
        val light = effLight()
        val ink = if (light) Color.parseColor("#1F1F1F") else Color.WHITE
        val sub = if (light) Color.parseColor("#5C5C5C") else Color.parseColor("#B3FFFFFF")

        val layer = FrameLayout(act)
        layer.setBackgroundColor(Color.parseColor("#66000000"))
        layer.isClickable = true
        layer.setOnClickListener { closePicker() }

        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = windowBackground(card, 14)
        card.setPadding(dp(14), dp(14), dp(14), dp(12))
        card.isClickable = true
        card.elevation = dp(12).toFloat()

        val title = TextView(act)
        title.text = "Aplicativos da Dock 2"
        title.setTextColor(ink)
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        card.addView(title)

        val count = TextView(act)
        count.setTextColor(sub)
        count.textSize = 12f
        count.setPadding(0, dp(2), 0, dp(8))
        card.addView(count)

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(act)
        sv.addView(col)
        card.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fun refreshCount() {
            count.text = list().count { appFor(it) != null }.toString() + " app(s) na Dock 2 · toque para adicionar ou remover"
        }
        refreshCount()

        for (a in apps()) {
            val key = a.cn.flattenToString()
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(6), dp(4), dp(6), dp(4))
            row.background = rip(8)
            row.isClickable = true
            val ic = ImageView(act)
            ic.setImageDrawable(iconOf(a))
            row.addView(ic, LinearLayout.LayoutParams(dp(32), dp(32)))
            val tv = TextView(act)
            tv.text = a.label
            tv.setTextColor(ink)
            tv.textSize = 14f
            tv.setSingleLine(true)
            val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            tlp.leftMargin = dp(10)
            row.addView(tv, tlp)
            val ck = TextView(act)
            ck.gravity = Gravity.CENTER
            ck.textSize = 14f
            fun style() {
                val on = contains(key)
                ck.text = if (on) "✓" else ""
                ck.setTextColor(Color.WHITE)
                ck.background = if (on) rounded(accent(), 6) else GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    cornerRadius = dp(6).toFloat()
                    setStroke(dp(1), sub)
                }
            }
            style()
            row.addView(ck, LinearLayout.LayoutParams(dp(24), dp(24)))
            row.setOnClickListener {
                toggle(key)
                style()
                refreshCount()
            }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        val done = TextView(act)
        done.text = "Concluído"
        done.setTextColor(Color.WHITE)
        done.textSize = 13f
        done.gravity = Gravity.CENTER
        done.background = rounded(Color.parseColor("#0067C0"), 6)
        done.setPadding(dp(10), dp(9), dp(10), dp(9))
        done.isClickable = true
        done.setOnClickListener { closePicker() }
        val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = dp(10)
        card.addView(done, dlp)

        val w = min(dp(360), dm.widthPixels - dp(32))
        val h = min(dp(540), (dm.heightPixels * 0.82f).toInt())
        layer.addView(card, FrameLayout.LayoutParams(w, h, Gravity.CENTER))
        root.addView(layer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        picker = layer
    }
}
