package com.example.winlauncher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/**
 * Tela de boas-vindas (estilo Windows) entre o desbloqueio e a tela inicial.
 *
 * Mostra a foto de perfil redonda, o nome e um carregamento FAKE de ~3 s (puramente visual).
 * A foto e o nome são lidos na hora de tocar, então qualquer troca feita no menu Iniciar
 * aparece aqui automaticamente.
 *
 * Linha do tempo:
 *  - fade-in (~380 ms) por cima da tela de bloqueio  -> [onCovered]: o bloqueio já pode sumir
 *  - segura até completar [TOTAL_MS]
 *  - fade-out (~450 ms) revelando o desktop          -> [onDone] é chamado no início do fade-out
 */
class WelcomeScreen(ctx: Context) : FrameLayout(ctx) {

    companion object {
        const val TOTAL_MS = 3000L
        private const val FADE_IN_MS = 380L
        private const val FADE_OUT_MS = 450L
    }

    var running = false
        private set

    private val handler = Handler(Looper.getMainLooper())
    private val ease = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val d = resources.displayMetrics.density

    /** Evita que o fim de uma animação cancelada mexa na reprodução seguinte. */
    private var gen = 0

    private val content = LinearLayout(ctx)
    private val avatarBox = FrameLayout(ctx)
    private val photo = ImageView(ctx)
    private val initial = TextView(ctx)
    private val nameView = TextView(ctx)
    private val spinner = DotsSpinner(ctx)

    private fun dp(v: Int) = (v * d + 0.5f).toInt()

    init {
        visibility = View.GONE
        alpha = 0f
        isClickable = true // engole toques: nada vaza para o que está por baixo
        tag = CursorController.NOHAND

        val compact = resources.displayMetrics.heightPixels / d < 520f
        val size = dp(if (compact) 96 else 136)

        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL

        // avatar redondo (foto por cima da inicial)
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(Color.parseColor("#3A4A63"))
        avatarBox.background = oval
        avatarBox.outlineProvider = ViewOutlineProvider.BACKGROUND
        avatarBox.clipToOutline = true
        avatarBox.elevation = dp(6).toFloat()

        initial.setTextColor(Color.WHITE)
        initial.textSize = if (compact) 38f else 54f
        initial.gravity = Gravity.CENTER
        avatarBox.addView(initial, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        photo.scaleType = ImageView.ScaleType.CENTER_CROP
        photo.visibility = View.GONE
        avatarBox.addView(photo, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        content.addView(avatarBox, LinearLayout.LayoutParams(size, size))

        nameView.setTextColor(Color.WHITE)
        nameView.textSize = if (compact) 20f else 26f
        nameView.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        nameView.maxLines = 1
        nameView.gravity = Gravity.CENTER
        val nlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        nlp.topMargin = dp(if (compact) 14 else 22)
        content.addView(nameView, nlp)

        val slp = LinearLayout.LayoutParams(dp(44), dp(44))
        slp.topMargin = dp(if (compact) 22 else 36)
        content.addView(spinner, slp)

        addView(
            content,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )
    }

    private fun loadPhoto(f: File?): Bitmap? {
        if (f == null || !f.exists()) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
            BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    private fun bind(name: String, photoFile: File?) {
        nameView.text = name
        initial.text = name.take(1).uppercase()
        val bmp = loadPhoto(photoFile)
        if (bmp != null) {
            photo.setImageBitmap(bmp)
            photo.visibility = View.VISIBLE
        } else {
            photo.setImageDrawable(null)
            photo.visibility = View.GONE
        }
        // fundo: papel de parede borrado + película escura (igual ao vidro do resto do launcher)
        background = if (Glass.bitmap != null) {
            GlassDrawable(this, Color.argb(0x99, 0x08, 0x0C, 0x14), 0f)
        } else {
            GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0E1827"), Color.parseColor("#1D3250"))
            )
        }
    }

    /**
     * Toca a sequência. [onCovered] roda quando a tela já cobre tudo (a tela de bloqueio pode sumir);
     * [onDone] roda quando o carregamento fake acaba (o desktop pode aparecer).
     */
    fun play(name: String, photoFile: File?, onCovered: () -> Unit, onDone: () -> Unit) {
        cancel()
        val g = ++gen
        running = true
        bind(name, photoFile)

        visibility = View.VISIBLE
        alpha = 0f
        content.scaleX = 0.94f
        content.scaleY = 0.94f
        setLayerType(LAYER_TYPE_HARDWARE, null)
        animate().alpha(1f).setDuration(FADE_IN_MS).setInterpolator(ease)
            .withEndAction {
                if (g != gen) return@withEndAction
                setLayerType(LAYER_TYPE_NONE, null)
                onCovered()
            }
            .start()
        content.animate().scaleX(1f).scaleY(1f).setDuration(700L).setInterpolator(ease).start()
        spinner.start()

        handler.postDelayed({
            if (g != gen) return@postDelayed
            onDone() // o desktop começa a voltar junto com o fade-out
            setLayerType(LAYER_TYPE_HARDWARE, null)
            animate().alpha(0f).setDuration(FADE_OUT_MS).setInterpolator(ease)
                .withEndAction {
                    if (g != gen) return@withEndAction
                    reset()
                }
                .start()
        }, TOTAL_MS)
    }

    /** Termina na hora, sem chamar nenhum callback (usado quando a tela de bloqueio reabre ou o app sai da frente). */
    fun cancel() {
        gen++
        handler.removeCallbacksAndMessages(null)
        animate().cancel()
        content.animate().cancel()
        reset()
    }

    private fun reset() {
        spinner.stop()
        setLayerType(LAYER_TYPE_NONE, null)
        visibility = View.GONE
        alpha = 0f
        content.scaleX = 1f
        content.scaleY = 1f
        photo.setImageDrawable(null)
        running = false
    }

    override fun onDetachedFromWindow() {
        spinner.stop()
        super.onDetachedFromWindow()
    }

    /**
     * Indicador circular no estilo do Windows: 5 bolinhas que correm em volta do círculo,
     * uma atrás da outra, aceleram no meio da volta e desaceleram no topo.
     */
    private class DotsSpinner(ctx: Context) : View(ctx) {
        private val dots = 5
        private val stagger = 0.075f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val curve = PathInterpolator(0.35f, 0.1f, 0.35f, 0.9f)
        private var t = 0f
        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
        }

        fun start() {
            if (!anim.isStarted) anim.start()
        }

        fun stop() {
            anim.cancel()
            t = 0f
        }

        override fun onDraw(canvas: Canvas) {
            val dotR = 3f * resources.displayMetrics.density
            val cx = width / 2f
            val cy = height / 2f
            val r = minOf(width, height) / 2f - dotR
            val span = 1f - (dots - 1) * stagger
            for (i in 0 until dots) {
                val local = (t - i * stagger) / span
                if (local <= 0f || local >= 1f) continue
                val a = Math.toRadians(-90.0 + 360.0 * curve.getInterpolation(local))
                canvas.drawCircle(cx + r * Math.cos(a).toFloat(), cy + r * Math.sin(a).toFloat(), dotR, paint)
            }
        }
    }
}
