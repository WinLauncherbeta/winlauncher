package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.ColorFilter
import android.graphics.drawable.Drawable
import android.view.View

/**
 * Efeito de vidro fosco: usa um instantâneo borrado do wallpaper (calculado uma vez)
 * desenhado atrás do componente, com uma película de cor por cima.
 * Para wallpapers animados o desfoque é baseado no primeiro quadro.
 */
object Glass {
    @Volatile
    var bitmap: Bitmap? = null
    var root: View? = null

    /** Recorta o centro da imagem para a proporção da tela, reduz e borra. */
    fun makeBlur(src: Bitmap, w: Int, h: Int): Bitmap {
        val sw = maxOf(8, w / 8)
        val sh = maxOf(8, h / 8)
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val s = maxOf(sw.toFloat() / src.width, sh.toFloat() / src.height)
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate((sw - src.width * s) / 2f, (sh - src.height * s) / 2f)
        c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return boxBlur(out, 3, 2)
    }

    private fun boxBlur(bmp: Bitmap, radius: Int, passes: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        var a = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        var b = IntArray(w * h)
        val n = radius * 2 + 1
        for (p in 0 until passes) {
            // horizontal
            for (y in 0 until h) {
                for (x in 0 until w) {
                    var sa = 0
                    var sr = 0
                    var sg = 0
                    var sb = 0
                    for (k in -radius..radius) {
                        val xx = (x + k).coerceIn(0, w - 1)
                        val c = a[y * w + xx]
                        sa += c ushr 24
                        sr += (c shr 16) and 255
                        sg += (c shr 8) and 255
                        sb += c and 255
                    }
                    b[y * w + x] = ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                }
            }
            // vertical
            for (y in 0 until h) {
                for (x in 0 until w) {
                    var sa = 0
                    var sr = 0
                    var sg = 0
                    var sb = 0
                    for (k in -radius..radius) {
                        val yy = (y + k).coerceIn(0, h - 1)
                        val c = b[yy * w + x]
                        sa += c ushr 24
                        sr += (c shr 16) and 255
                        sg += (c shr 8) and 255
                        sb += c and 255
                    }
                    a[y * w + x] = ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                }
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }
}

class GlassDrawable(
    private val host: View,
    private val tint: Int,
    private val radius: Float
) : Drawable() {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val dst = Rect()
    private val loc = IntArray(2)
    private val rloc = IntArray(2)

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        val outer = canvas.save()
        canvas.clipPath(path)
        val bmp = Glass.bitmap
        val r = Glass.root
        if (bmp != null && r != null && !bmp.isRecycled && r.width > 0 && r.height > 0) {
            host.getLocationOnScreen(loc)
            r.getLocationOnScreen(rloc)
            val inner = canvas.save()
            canvas.translate((rloc[0] - loc[0]).toFloat(), (rloc[1] - loc[1]).toFloat())
            dst.set(0, 0, r.width, r.height)
            canvas.drawBitmap(bmp, null, dst, paint)
            canvas.restoreToCount(inner)
        }
        canvas.drawColor(tint)
        canvas.restoreToCount(outer)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
