package com.example.winlauncher

import android.graphics.Bitmap
import android.animation.ValueAnimator
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInfo
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Janela "Instalador de aplicativos" (estilo assistente do Windows) para instalar arquivos .apk.
 *
 * Fluxo: escolher o .apk -> ler o pacote (nome, versão, ícone) -> Instalar -> barra verde de progresso -> Concluir/Abrir.
 * A instalação usa o [PackageInstaller] do Android; o próprio Android ainda mostra a tela de confirmação dele
 * (e na primeira vez pede para permitir "instalar apps desconhecidos" para o WinLauncher).
 *
 * É uma janela autônoma, igual à [PcInfoWindow]: arrasta pela barra de título e fecha no X.
 */
@Suppress("DEPRECATION")
class ApkInstallerWindow(private val act: Activity, private val root: FrameLayout) {

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val ACTION_STATUS = "com.example.winlauncher.APK_INSTALL_STATUS"
    }

    private enum class St { PICK, READING, READY, INSTALLING, DONE, ERROR }

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    private val d = act.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private var worker: ExecutorService? = null

    /** Incrementa a cada operação nova / ao fechar; resultados de operações antigas são descartados. */
    private var gen = 0

    private val ink = Color.parseColor("#2B313B")
    private val sub = Color.parseColor("#5E6776")
    private val accent = Color.parseColor("#3D9DFF")
    private val green = Color.parseColor("#0E9F2E")
    private val red = Color.parseColor("#D8283A")

    private lateinit var win: FrameLayout
    private lateinit var content: LinearLayout

    val isOpen: Boolean get() = open

    /** Avisado quando abre ou fecha (a barra de tarefas se redesenha). */
    var onStateChange: (() -> Unit)? = null

    /** Última foto da janela (usada na janelinha da barra de tarefas quando ela está minimizada). */
    private var lastSnap: Bitmap? = null

    /** Miniatura da janela para a janelinha da barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap
    private var open = false
    private var placed = false
    private var st = St.PICK

    // ---- pacote carregado
    private var apkFile: File? = null
    private var pkgName = ""
    private var appLabel = ""
    private var appIcon: Drawable? = null
    private var verName = ""
    private var verCode = 0L
    private var oldVerName: String? = null
    private var oldVerCode = 0L
    private var fileName = ""
    private var fileSize = 0L

    // ---- instalação
    private var progress = 0f
    private var indeterminate = false
    private var phase = ""
    private var errorMsg = ""

    @Volatile
    private var sessionId = -1
    private var committed = false
    private var rxRegistered = false

    // ---- views que mudam durante o progresso (sem recriar a tela)
    private var bar: WinProgressBar? = null
    private var pctText: TextView? = null
    private var phaseText: TextView? = null

    init {
        build()
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    private fun bg(task: () -> Unit) {
        val w = worker ?: Executors.newSingleThreadExecutor().also { worker = it }
        try {
            w.execute { task() }
        } catch (t: Throwable) {
        }
    }

    /** Executa [block] na thread principal, só se a operação [g] ainda for a atual e a janela estiver aberta. */
    private fun post(g: Int, block: () -> Unit) {
        win.post { if (open && g == gen) block() }
    }

    // ================================================================== API pública

    /** Abre a janela na primeira etapa (escolher o arquivo). */
    fun show() {
        if (open) return
        open = true
        onStateChange?.invoke()
        st = St.PICK
        render()
        win.animate().cancel()
        sizeWindow()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    /** Abre a janela já com um APK (toque no arquivo .apk no gerenciador de arquivos / botão Procurar). */
    fun openWith(uri: Uri) {
        if (st == St.INSTALLING || st == St.READING) {
            if (open) {
                toast("Aguarde o fim da instalação atual")
                return
            }
        }
        if (!open) show()
        loadUri(uri)
    }

    /** Resultado do seletor de arquivos (chamado pela MainActivity). */
    fun onPicked(uri: Uri?) {
        if (!open) return
        if (uri != null) loadUri(uri)
    }

    fun close() {
        if (!open) return
        open = false
        lastSnap = null
        onStateChange?.invoke()
        gen++
        handler.removeCallbacks(creep)
        unregisterRx()
        if (st == St.INSTALLING && !committed) abandonSession()
        worker?.shutdownNow()
        worker = null
        cleanupFile()
        st = St.PICK
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (!open) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    /** Insere a janela logo abaixo da camada do menu de contexto (o menu continua por cima). */
    fun attachBelow(menuLayer: View) {
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ================================================================== escolher / ler o APK

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            act.startActivityForResult(i, MainActivity.REQ_APK)
        } catch (e: Exception) {
            toast("Não foi possível abrir o seletor de arquivos")
        }
    }

    private fun loadUri(uri: Uri) {
        cleanupFile()
        val g = ++gen
        st = St.READING
        progress = 0f
        indeterminate = true
        phase = ""
        fileName = nameOf(uri)
        render()
        bg {
            try {
                val dir = File(act.cacheDir, "apk_install")
                dir.mkdirs()
                val f = File(dir, "pacote.apk")
                val total = sizeOf(uri)
                var done = 0L
                val ins = act.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")
                ins.use { input ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(256 * 1024)
                        var lastUi = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = SystemClock.uptimeMillis()
                            if (total > 0 && now - lastUi > 80) {
                                lastUi = now
                                val fr = (done.toFloat() / total).coerceIn(0f, 1f) * 0.95f
                                post(g) { setProgress(fr) }
                            }
                        }
                    }
                }

                val pm = act.packageManager
                val info = pm.getPackageArchiveInfo(f.path, 0) ?: throw IOException("O arquivo não é um APK válido")
                val ai = info.applicationInfo ?: throw IOException("O APK não tem informações do aplicativo")
                ai.sourceDir = f.path
                ai.publicSourceDir = f.path
                val label = ai.loadLabel(pm).toString()
                val icon = try {
                    ai.loadIcon(pm)
                } catch (t: Throwable) {
                    null
                }
                val old: PackageInfo? = try {
                    pm.getPackageInfo(info.packageName, 0)
                } catch (e: PackageManager.NameNotFoundException) {
                    null
                } catch (e: Exception) {
                    null
                }
                post(g) {
                    apkFile = f
                    fileSize = f.length()
                    pkgName = info.packageName
                    appLabel = label
                    appIcon = icon
                    verName = info.versionName ?: ""
                    verCode = codeOf(info)
                    oldVerName = old?.versionName ?: if (old != null) "" else null
                    oldVerCode = if (old != null) codeOf(old) else 0L
                    st = St.READY
                    render()
                }
            } catch (t: Throwable) {
                post(g) {
                    cleanupFile()
                    fail(t.message ?: "Não foi possível ler o arquivo")
                }
            }
        }
    }

    private fun codeOf(i: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else i.versionCode.toLong()

    private fun nameOf(uri: Uri): String {
        try {
            act.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrEmpty()) return n
                }
            }
        } catch (t: Throwable) {
        }
        return uri.lastPathSegment ?: "aplicativo.apk"
    }

    private fun sizeOf(uri: Uri): Long {
        try {
            act.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        } catch (t: Throwable) {
        }
        return -1L
    }

    private fun cleanupFile() {
        try {
            File(act.cacheDir, "apk_install").listFiles()?.forEach { it.delete() }
        } catch (t: Throwable) {
        }
        apkFile = null
    }

    // ================================================================== instalar

    private fun startInstall() {
        val f = apkFile ?: return
        if (!act.packageManager.canRequestPackageInstalls()) {
            toast("Ative \"Permitir desta fonte\" para o WinLauncher e volte aqui")
            try {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))
                )
            } catch (e: Exception) {
            }
            return
        }
        val g = ++gen
        st = St.INSTALLING
        progress = 0f
        indeterminate = false
        phase = "Copiando arquivos…"
        committed = false
        sessionId = -1
        render()
        registerRx()
        bg {
            try {
                val pi = act.packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                params.setAppPackageName(pkgName)
                params.setSize(f.length())
                val id = pi.createSession(params)
                sessionId = id
                val total = f.length().coerceAtLeast(1L)
                pi.openSession(id).use { s ->
                    f.inputStream().use { input ->
                        s.openWrite("base.apk", 0, total).use { out ->
                            val buf = ByteArray(256 * 1024)
                            var done = 0L
                            var lastUi = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                val now = SystemClock.uptimeMillis()
                                if (now - lastUi > 80) {
                                    lastUi = now
                                    val fr = (done.toFloat() / total).coerceIn(0f, 1f)
                                    s.setStagingProgress(fr)
                                    post(g) { setProgress(fr * 0.8f) }
                                }
                            }
                            s.fsync(out)
                        }
                    }
                    post(g) {
                        phase = "Instalando…"
                        setProgress(0.8f)
                        handler.removeCallbacks(creep)
                        handler.postDelayed(creep, 200)
                    }
                    val statusIntent = Intent(ACTION_STATUS).setPackage(act.packageName)
                    var flags = PendingIntent.FLAG_UPDATE_CURRENT
                    if (Build.VERSION.SDK_INT >= 31) flags = flags or PendingIntent.FLAG_MUTABLE
                    val pending = PendingIntent.getBroadcast(act, id, statusIntent, flags)
                    committed = true
                    s.commit(pending.intentSender)
                }
            } catch (t: Throwable) {
                post(g) {
                    abandonSession()
                    fail(t.message ?: "Falha ao copiar o arquivo")
                }
            }
        }
    }

    /** Enquanto o Android instala, a barra avança devagar até ~97% (o Android não informa o andamento real). */
    private val creep = object : Runnable {
        override fun run() {
            if (!open || st != St.INSTALLING) return
            if (!indeterminate) setProgress(progress + (0.97f - progress) * 0.04f)
            handler.postDelayed(this, 200)
        }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i == null || !open) return
            val id = i.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1)
            if (sessionId != -1 && id != -1 && id != sessionId) return
            when (val status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    val conf: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                        i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                    } else {
                        i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                    }
                    if (conf != null) {
                        phase = "Aguardando a confirmação do Android…"
                        indeterminate = true
                        refreshProgressViews()
                        conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            act.startActivity(conf)
                        } catch (e: Exception) {
                            fail("Não foi possível abrir a confirmação de instalação")
                        }
                    }
                }
                PackageInstaller.STATUS_SUCCESS -> success()
                else -> fail(messageFor(status, i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)))
            }
        }
    }

    private fun registerRx() {
        if (rxRegistered) return
        val f = IntentFilter(ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            act.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            act.registerReceiver(rx, f)
        }
        rxRegistered = true
    }

    private fun unregisterRx() {
        if (!rxRegistered) return
        try {
            act.unregisterReceiver(rx)
        } catch (e: Exception) {
        }
        rxRegistered = false
    }

    private fun abandonSession() {
        val id = sessionId
        if (id == -1) return
        try {
            act.packageManager.packageInstaller.abandonSession(id)
        } catch (t: Throwable) {
        }
        sessionId = -1
    }

    private fun messageFor(status: Int, msg: String?): String = when (status) {
        PackageInstaller.STATUS_FAILURE_ABORTED -> "A instalação foi cancelada."
        PackageInstaller.STATUS_FAILURE_BLOCKED -> "A instalação foi bloqueada pelo aparelho."
        PackageInstaller.STATUS_FAILURE_CONFLICT ->
            "Conflito com o app já instalado (assinatura diferente). Desinstale a versão atual e tente de novo."
        PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "Este app não é compatível com o aparelho."
        PackageInstaller.STATUS_FAILURE_INVALID -> "O arquivo APK está inválido ou corrompido."
        PackageInstaller.STATUS_FAILURE_STORAGE -> "Sem espaço de armazenamento suficiente."
        else -> if (!msg.isNullOrBlank()) msg else "Falha na instalação."
    }

    private fun success() {
        handler.removeCallbacks(creep)
        unregisterRx()
        sessionId = -1
        committed = false
        cleanupFile()
        progress = 1f
        indeterminate = false
        st = St.DONE
        render()
    }

    private fun fail(msg: String) {
        handler.removeCallbacks(creep)
        unregisterRx()
        sessionId = -1
        committed = false
        errorMsg = msg
        indeterminate = false
        st = St.ERROR
        render()
    }

    private fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        indeterminate = false
        refreshProgressViews()
    }

    private fun refreshProgressViews() {
        bar?.let {
            it.indeterminate = indeterminate
            it.target = progress
        }
        pctText?.text = if (indeterminate) "" else String.format(Locale.getDefault(), "%d%%", (progress * 100).toInt())
        phaseText?.text = phase
    }

    // ================================================================== posição / tamanho

    private fun sizeWindow() {
        val rw = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = minOf(dp(520), rw - dp(24))
        win.layoutParams = lp
    }

    private fun place() {
        if (!placed) {
            val rw = root.width.toFloat()
            val rh = root.height.toFloat()
            win.x = ((rw - win.width) / 2f).coerceAtLeast(dp(8).toFloat())
            win.y = ((rh - win.height) / 2f - dp(16)).coerceAtLeast(dp(8).toFloat())
            placed = true
        } else {
            moveTo(win.x, win.y)
        }
        win.invalidate()
    }

    private fun moveTo(nx: Float, ny: Float) {
        val minX = -(win.width - dp(96)).toFloat()
        val maxX = (root.width - dp(96)).toFloat()
        val maxY = (root.height - dp(48)).toFloat().coerceAtLeast(0f)
        win.x = nx.coerceIn(minX, maxOf(minX, maxX))
        win.y = ny.coerceIn(0f, maxY)
        win.invalidate() // o vidro depende da posição na tela
    }

    // ================================================================== construção da interface

    private fun build() {
        layer.tag = CursorController.NOHAND

        win = FrameLayout(act)
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.elevation = dp(16).toFloat()
        win.background = GlassDrawable(win, Color.parseColor("#C8EDEFF3"), dp(20).toFloat())
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(20).toFloat())
                outline.alpha = 0.55f
            }
        }

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(6), dp(14), dp(16))
        win.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(buildTitleBar(), LinearLayout.LayoutParams(MATCH, dp(44)))

        content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(8), dp(4), dp(8), 0)
        col.addView(content, LinearLayout.LayoutParams(MATCH, WRAP))

        layer.addView(win, FrameLayout.LayoutParams(dp(520), WRAP, Gravity.TOP or Gravity.START))
    }

    private fun buildTitleBar(): View {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), 0, dp(2), 0)

        val ic = ImageView(act)
        ic.setImageResource(R.drawable.ic_install)
        ic.setColorFilter(ink)
        bar.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))

        val t = TextView(act)
        t.text = "Instalador de aplicativos"
        t.setTextColor(ink)
        t.textSize = 15f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })

        val x = ImageView(act)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(ink)
        x.setPadding(dp(9), dp(9), dp(9), dp(9))
        x.isClickable = true
        x.background = closeBg(false)
        x.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = closeBg(true)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = closeBg(false)
            }
            false
        }
        x.setOnClickListener { close() }
        bar.addView(x, LinearLayout.LayoutParams(dp(36), dp(36)))

        var offX = 0f
        var offY = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                }
                MotionEvent.ACTION_MOVE -> moveTo(ev.rawX + offX, ev.rawY + offY)
            }
            true
        }
        return bar
    }

    private fun closeBg(hover: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(if (hover) Color.parseColor("#40E5484D") else Color.TRANSPARENT)
        g.cornerRadius = dp(8).toFloat()
        return g
    }

    // ---- peças reutilizáveis

    private fun text(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(act)
        tv.text = t
        tv.textSize = sp
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return tv
    }

    private fun button(t: String, primary: Boolean, onClick: () -> Unit): TextView {
        val b = text(t, 13.5f, if (primary) Color.WHITE else ink, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(20), dp(10), dp(20), dp(10))
        val g = GradientDrawable()
        g.setColor(if (primary) accent else Color.parseColor("#26000000"))
        g.cornerRadius = dp(8).toFloat()
        b.background = g
        b.isClickable = true
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buttonRow(vararg btns: View): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.END
        for ((i, b) in btns.withIndex()) {
            r.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply { if (i > 0) leftMargin = dp(10) })
        }
        return r
    }

    private fun fmtSize(b: Long): String =
        if (b >= 1024L * 1024L) String.format(Locale.getDefault(), "%.1f MB", b / 1048576.0)
        else String.format(Locale.getDefault(), "%d KB", maxOf(1L, b / 1024L))

    private fun lp(w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).apply { topMargin = top }

    /** Linha com a barra verde, o texto da etapa e a porcentagem. */
    private fun progressBlock(error: Boolean = false): View {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL

        val b = WinProgressBar(act, d)
        b.error = error
        b.indeterminate = indeterminate
        b.target = progress
        bar = b
        box.addView(b, lp(MATCH, dp(18)))

        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        val ph = text(phase, 12.5f, sub)
        phaseText = ph
        row.addView(ph, LinearLayout.LayoutParams(0, WRAP, 1f))
        val pc = text("", 12.5f, ink, true)
        pctText = pc
        row.addView(pc, lp(WRAP, WRAP))
        box.addView(row, lp(MATCH, WRAP, dp(8)))
        refreshProgressViews()
        return box
    }

    // ================================================================== telas

    private fun render() {
        content.removeAllViews()
        bar = null
        pctText = null
        phaseText = null
        when (st) {
            St.PICK -> renderPick()
            St.READING -> renderReading()
            St.READY -> renderReady()
            St.INSTALLING -> renderInstalling()
            St.DONE -> renderDone()
            St.ERROR -> renderError()
        }
    }

    private fun renderPick() {
        val ic = ImageView(act)
        ic.setImageResource(R.drawable.ic_install)
        ic.setColorFilter(accent)
        content.addView(ic, LinearLayout.LayoutParams(dp(56), dp(56)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(6)
        })
        val t = text("Instalar um aplicativo", 20f, ink, true)
        t.gravity = Gravity.CENTER
        content.addView(t, lp(MATCH, WRAP, dp(10)))
        val s = text("Escolha um arquivo .apk para instalar neste aparelho.", 13.5f, sub)
        s.gravity = Gravity.CENTER
        content.addView(s, lp(MATCH, WRAP, dp(6)))
        val b = button("Procurar arquivo…", true) { pick() }
        content.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(18)
        })
        val tip = text("Dica: no gerenciador de arquivos, toque em um .apk e escolha o WinLauncher.", 11.5f, sub)
        tip.gravity = Gravity.CENTER
        content.addView(tip, lp(MATCH, WRAP, dp(16)))
    }

    private fun renderReading() {
        content.addView(text("Lendo o pacote…", 18f, ink, true), lp(MATCH, WRAP, dp(4)))
        val n = text(fileName, 12.5f, sub)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        content.addView(n, lp(MATCH, WRAP, dp(4)))
        content.addView(progressBlock(), lp(MATCH, WRAP, dp(18)))
    }

    private fun renderReady() {
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(act)
        iv.setImageDrawable(appIcon ?: act.packageManager.defaultActivityIcon)
        head.addView(iv, LinearLayout.LayoutParams(dp(56), dp(56)))
        val info = LinearLayout(act)
        info.orientation = LinearLayout.VERTICAL
        val name = text(appLabel, 18f, ink, true)
        name.maxLines = 1
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        info.addView(name, lp(MATCH, WRAP))
        info.addView(text(if (verName.isEmpty()) "Versão desconhecida" else "Versão $verName", 13f, sub), lp(MATCH, WRAP, dp(2)))
        val pk = text(pkgName, 11.5f, sub)
        pk.maxLines = 1
        pk.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        info.addView(pk, lp(MATCH, WRAP, dp(2)))
        head.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
        content.addView(head, lp(MATCH, WRAP, dp(4)))

        val status: String
        val color: Int
        val old = oldVerName
        if (old == null) {
            status = "Novo aplicativo • ${fmtSize(fileSize)}"
            color = green
        } else if (verCode > oldVerCode) {
            status = "Atualização: ${old.ifEmpty { "?" }} → ${verName.ifEmpty { "?" }} • ${fmtSize(fileSize)}"
            color = accent
        } else if (verCode == oldVerCode) {
            status = "Já instalado nesta versão (reinstalar) • ${fmtSize(fileSize)}"
            color = sub
        } else {
            status = "Versão mais antiga que a instalada (${old.ifEmpty { "?" }}). O Android pode recusar. • ${fmtSize(fileSize)}"
            color = red
        }
        content.addView(text(status, 12.5f, color, true), lp(MATCH, WRAP, dp(16)))
        content.addView(text("O Android vai pedir a confirmação final antes de instalar.", 11.5f, sub), lp(MATCH, WRAP, dp(6)))

        content.addView(
            buttonRow(button("Cancelar", false) { cleanupFile(); st = St.PICK; render() }, button("Instalar", true) { startInstall() }),
            lp(MATCH, WRAP, dp(20))
        )
    }

    private fun renderInstalling() {
        content.addView(text("Instalando $appLabel", 18f, ink, true), lp(MATCH, WRAP, dp(4)))
        content.addView(text("Aguarde enquanto o aplicativo é instalado.", 12.5f, sub), lp(MATCH, WRAP, dp(4)))
        content.addView(progressBlock(), lp(MATCH, WRAP, dp(18)))
    }

    private fun renderDone() {
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ck = text("✓", 22f, Color.WHITE, true)
        ck.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(green)
        ck.background = g
        head.addView(ck, LinearLayout.LayoutParams(dp(40), dp(40)))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text("Instalação concluída", 18f, ink, true), lp(MATCH, WRAP))
        col.addView(text("$appLabel foi instalado.", 12.5f, sub), lp(MATCH, WRAP, dp(2)))
        head.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
        content.addView(head, lp(MATCH, WRAP, dp(4)))

        phase = ""
        content.addView(progressBlock(), lp(MATCH, WRAP, dp(18)))

        val launch = act.packageManager.getLaunchIntentForPackage(pkgName)
        val btns = ArrayList<View>()
        btns.add(button("Concluir", launch == null) { close() })
        if (launch != null) {
            btns.add(button("Abrir", true) {
                try {
                    act.startActivity(launch)
                } catch (e: Exception) {
                    toast("Não foi possível abrir o aplicativo")
                }
                close()
            })
        }
        content.addView(buttonRow(*btns.toTypedArray()), lp(MATCH, WRAP, dp(20)))
    }

    private fun renderError() {
        content.addView(text("Não foi possível instalar", 18f, red, true), lp(MATCH, WRAP, dp(4)))
        content.addView(text(errorMsg, 13f, ink), lp(MATCH, WRAP, dp(8)))
        phase = ""
        content.addView(progressBlock(true), lp(MATCH, WRAP, dp(16)))
        val btns = ArrayList<View>()
        btns.add(button("Fechar", false) { close() })
        if (apkFile != null) {
            btns.add(button("Tentar novamente", true) { st = St.READY; render() })
        } else {
            btns.add(button("Escolher outro arquivo", true) { st = St.PICK; render() })
        }
        content.addView(buttonRow(*btns.toTypedArray()), lp(MATCH, WRAP, dp(20)))
    }

    // ================================================================== barra de progresso verde (estilo Windows)

    /**
     * Barra verde brilhante do instalador do Windows: trilho cinza com borda, preenchimento verde com brilho
     * na metade de cima e uma faixa de luz que passa por cima. Sem porcentagem conhecida ([indeterminate]),
     * um bloco verde corre de um lado ao outro (marquee). Vermelha quando [error].
     */
    private class WinProgressBar(ctx: Context, private val d: Float) : View(ctx) {
        var target = 0f
            set(v) {
                field = v.coerceIn(0f, 1f)
                invalidate()
            }
        var indeterminate = false
            set(v) {
                field = v
                invalidate()
            }
        var error = false
            set(v) {
                field = v
                invalidate()
            }

        private var shown = 0f
        private var phase = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val clip = Path()

        private val track = Color.parseColor("#E3E6EA")
        private val border = Color.parseColor("#9AA0A8")
        private val gGreen = intArrayOf(Color.parseColor("#6BE57F"), Color.parseColor("#06B025"), Color.parseColor("#049A1F"))
        private val gRed = intArrayOf(Color.parseColor("#FF7A85"), Color.parseColor("#E81123"), Color.parseColor("#B80F1D"))
        private val stops = floatArrayOf(0f, 0.5f, 1f)
        private val shineCols = intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF)

        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                shown += (target - shown) * 0.18f
                if (Math.abs(target - shown) < 0.001f) shown = target
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            anim.start()
        }

        override fun onDetachedFromWindow() {
            anim.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val r = 4f * d

            p.style = Paint.Style.FILL
            p.shader = null
            p.color = track
            rect.set(0f, 0f, w, h)
            c.drawRoundRect(rect, r, r, p)

            val x0: Float
            val x1: Float
            if (indeterminate) {
                val bw = w * 0.32f
                x0 = -bw + (w + bw) * phase
                x1 = x0 + bw
            } else {
                x0 = 0f
                x1 = w * shown
            }
            if (x1 > x0) {
                val inset = 1.5f * d
                clip.reset()
                rect.set(inset, inset, w - inset, h - inset)
                clip.addRoundRect(rect, r - d, r - d, Path.Direction.CW)
                val save = c.save()
                c.clipPath(clip)
                c.clipRect(x0, 0f, x1, h)

                p.shader = LinearGradient(0f, 0f, 0f, h, if (error) gRed else gGreen, stops, Shader.TileMode.CLAMP)
                rect.set(x0, 0f, x1, h)
                c.drawRect(rect, p)

                p.shader = null
                p.color = 0x33FFFFFF
                rect.set(x0, 0f, x1, h * 0.45f)
                c.drawRect(rect, p)

                if (!indeterminate && !error) {
                    val bandW = maxOf(48f * d, (x1 - x0) * 0.25f)
                    val bx = x0 - bandW + ((x1 - x0) + bandW) * phase
                    p.shader = LinearGradient(bx, 0f, bx + bandW, 0f, shineCols, null, Shader.TileMode.CLAMP)
                    rect.set(bx, 0f, bx + bandW, h)
                    c.drawRect(rect, p)
                    p.shader = null
                }
                c.restoreToCount(save)
            }

            p.style = Paint.Style.STROKE
            p.strokeWidth = d
            p.color = border
            rect.set(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d)
            c.drawRoundRect(rect, r, r, p)
            p.style = Paint.Style.FILL
        }
    }
}
