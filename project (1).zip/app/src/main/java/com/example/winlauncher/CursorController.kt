package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar

/**
 * Ponteiro estilo Windows 11 (seta branca com contorno escuro, mão e anel de ocupado).
 * Funciona apenas sobre as telas do WinLauncher (PointerIcon só vale na janela do próprio app).
 */
class CursorController(private val ctx: Context, private val prefs: Prefs) {

    companion object {
        const val NOHAND = "nohand"
        private const val FRAMES = 12
    }

    private val density = ctx.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    var arrowBitmap: Bitmap? = null
        private set
    var handBitmap: Bitmap? = null
        private set
    var busyBitmap: Bitmap? = null
        private set

    var arrow: PointerIcon? = null
        private set
    var hand: PointerIcon? = null
        private set
    private var busyIcons: List<PointerIcon> = emptyList()

    var busy = false
        private set
    private var busyIdx = 0
    var onFrame: (() -> Unit)? = null

    val enabled: Boolean get() = prefs.cursorOn && arrow != null

    private val spin = object : Runnable {
        override fun run() {
            if (!busy) return
            busyIdx = (busyIdx + 1) % FRAMES
            onFrame?.invoke()
            handler.postDelayed(this, 90)
        }
    }

    fun rebuild() {
        try {
            val s = (prefs.cursorSize * density).toInt().coerceAtLeast(16)
            val a = drawArrow(s)
            val h = drawHand(s)
            arrowBitmap = a
            handBitmap = h
            val pad = s * 0.06f
            arrow = PointerIcon.create(a, pad, pad)
            val kh = (s - 2 * pad) / 18f
            hand = PointerIcon.create(h, pad + (9.75f - 3.5f) * kh, pad)
            val frames = ArrayList<PointerIcon>()
            for (i in 0 until FRAMES) {
                val b = drawBusy(s, i * (360f / FRAMES))
                if (i == 0) busyBitmap = b
                frames.add(PointerIcon.create(b, s / 2f, s / 2f))
            }
            busyIcons = frames
        } catch (e: Exception) {
            arrow = null
            hand = null
            busyIcons = emptyList()
        }
    }

    fun busyIcon(): PointerIcon? = busyIcons.getOrNull(busyIdx)

    /** Mostra o anel de ocupado por [ms] milissegundos (ex.: ao abrir um app). */
    fun setBusy(ms: Long) {
        if (busyIcons.isEmpty()) return
        busy = true
        handler.removeCallbacks(spin)
        handler.postDelayed(spin, 90)
        handler.removeCallbacks(stop)
        handler.postDelayed(stop, ms)
    }

    private val stop = Runnable { clearBusy() }

    fun clearBusy() {
        if (!busy) return
        busy = false
        handler.removeCallbacks(spin)
        handler.removeCallbacks(stop)
        onFrame?.invoke()
    }

    // ------------------------------------------------------------ desenho

    private fun dark(): Int = Color.parseColor("#141414")

    private fun drawArrow(s: Int): Bitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pad = s * 0.06f
        val k = (s - 2 * pad) / 19f
        val pts = floatArrayOf(0f, 0f, 0f, 16f, 4f, 12f, 7f, 19f, 9f, 18f, 6f, 11f, 11f, 11f)
        val path = Path()
        var i = 0
        while (i < pts.size) {
            val x = pad + pts[i] * k
            val y = pad + pts[i + 1] * k
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            i += 2
        }
        path.close()
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.style = Paint.Style.FILL
        fill.color = Color.WHITE
        c.drawPath(path, fill)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = maxOf(1.2f, s * 0.06f)
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.color = dark()
        c.drawPath(path, stroke)
        return bmp
    }

    private fun drawHand(s: Int): Bitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pad = s * 0.06f
        val k = (s - 2 * pad) / 18f
        fun px(ux: Float) = pad + (ux - 3.5f) * k
        fun py(uy: Float) = pad + (uy - 2f) * k
        val shapes = listOf(
            floatArrayOf(8f, 2f, 11.5f, 13f, 1.7f),
            floatArrayOf(11.5f, 7f, 14.5f, 14f, 1.5f),
            floatArrayOf(14.5f, 8f, 17.5f, 15f, 1.5f),
            floatArrayOf(17.5f, 9.5f, 20.5f, 16f, 1.5f),
            floatArrayOf(6.5f, 10.5f, 20.5f, 20f, 3f),
            floatArrayOf(3.5f, 10f, 8f, 16f, 2f)
        )
        val path = Path()
        for (sh in shapes) {
            val p = Path()
            val r = sh[4] * k
            p.addRoundRect(RectF(px(sh[0]), py(sh[1]), px(sh[2]), py(sh[3])), r, r, Path.Direction.CW)
            if (path.isEmpty) path.set(p) else path.op(p, Path.Op.UNION)
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.style = Paint.Style.FILL
        fill.color = Color.WHITE
        c.drawPath(path, fill)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = maxOf(1.2f, s * 0.06f)
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.color = dark()
        c.drawPath(path, stroke)
        return bmp
    }

    private fun drawBusy(s: Int, startAngle: Float): Bitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val w = s * 0.14f
        val inset = w + s * 0.06f
        val oval = RectF(inset, inset, s - inset, s - inset)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w + s * 0.08f
        p.color = dark()
        c.drawArc(oval, 0f, 360f, false, p)
        p.strokeWidth = w
        p.color = Color.parseColor("#E6E6E6")
        c.drawArc(oval, 0f, 360f, false, p)
        p.color = Color.parseColor("#0078D4")
        c.drawArc(oval, startAngle, 110f, false, p)
        return bmp
    }
}

/** Raiz da interface: decide qual ponteiro mostrar conforme o que está sob o mouse. */
class PointerRoot(ctx: Context, private val cursor: CursorController) : FrameLayout(ctx) {

    override fun onResolvePointerIcon(event: MotionEvent, pointerIndex: Int): PointerIcon? {
        if (!cursor.enabled) return super.onResolvePointerIcon(event, pointerIndex)
        if (cursor.busy) {
            val b = cursor.busyIcon()
            if (b != null) return b
        }
        val v = hit(this, event.getX(pointerIndex), event.getY(pointerIndex))
        return when {
            v is EditText -> PointerIcon.getSystemIcon(context, PointerIcon.TYPE_TEXT)
            v != null -> cursor.hand
            else -> cursor.arrow
        }
    }

    private fun hit(v: View, x: Float, y: Float): View? {
        if (v.visibility != View.VISIBLE) return null
        if (x < 0 || y < 0 || x > v.width || y > v.height) return null
        if (v is SeekBar) return null
        if (v is AbsListView) {
            return if (v.pointToPosition(x.toInt(), y.toInt()) >= 0) v else null
        }
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                val c = v.getChildAt(i)
                val r = hit(
                    c,
                    x + v.scrollX - c.left - c.translationX,
                    y + v.scrollY - c.top - c.translationY
                )
                if (r != null) return r
            }
        }
        if (v.tag == CursorController.NOHAND) return null
        return if (v.isClickable || v.isLongClickable) v else null
    }
}
