package com.example.winlauncher

import android.graphics.Bitmap
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import java.text.Normalizer

/**
 * Janela "Configurações" no estilo do Windows 11 escuro: barra lateral à esquerda (Sistema, Bluetooth e
 * dispositivos, Rede & Internet, Personalização, Aplicativos, Contas, Hora e idioma, Jogos, Acessibilidade,
 * Privacidade e segurança, Windows Update) e o conteúdo da categoria à direita.
 *
 * Reaproveita os painéis que já existem em "Personalizar WinLauncher" ([CustomizeUi], versão escura) e abre
 * as telas do Android para o que o launcher não controla sozinho. Janela autônoma: arrasta pela barra de
 * título e fecha no X. Em telas estreitas a barra lateral vira só ícones.
 */
class SettingsWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    private val prefs: Prefs,
    private val startPreview: (Boolean) -> Unit,
    /** Espaço ocupado pela barra de tarefas em px: (topo, base). Usado ao maximizar. */
    private val taskbarInsets: () -> Pair<Int, Int>,
    private val openPc: () -> Unit,
    private val editProfile: () -> Unit,
    private val userName: () -> String,
    private val lockNow: () -> Unit,
    private val checkUpdates: () -> Unit
) {

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val CAT_ACCOUNTS = 5
    }

    /** Linha de configuração: abre uma sub-página [page], executa [action] ou ambos ficam nulos (só informativa). */
    private class Row(
        val title: String,
        val sub: String,
        val icon: Int,
        val action: (() -> Unit)? = null,
        val page: (() -> View)? = null
    )

    private class Cat(
        val name: String,
        val icon: Int,
        val header: (() -> View?)? = null,
        val rows: () -> List<Row>
    )

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    /** Camada do jogo em tela cheia (fica acima da janela, dentro de [layer]). */
    private val gameLayer = FrameLayout(act)

    /** 0 = jogo dentro da janela, 1 = tela cheia com a barra de tarefas visível, 2 = tela cheia total. */
    private var gameFs = 0
    private val chess: ChessPanel by lazy { ChessPanel(act) { cycleGameFullscreen() } }

    val isOpen: Boolean get() = open

    /** Janela aberta mas recolhida para a barra de tarefas. */
    val isMinimized: Boolean get() = minimized
    private var minimized = false

    /** Avisado quando abre ou fecha (a barra de tarefas se redesenha). */
    var onStateChange: (() -> Unit)? = null

    /** Última foto da janela (usada na janelinha da barra de tarefas quando ela está minimizada). */
    private var lastSnap: Bitmap? = null

    /** Miniatura da janela para a janelinha da barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private val store = act.getSharedPreferences("win", Context.MODE_PRIVATE)
    private val ui = CustomizeUi(act, prefs, dark = true)
    private var maximized = false
    private var previewing = false
    private lateinit var maxBtn: ImageView
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val undim = Runnable { setDim(false) }

    // cores copiadas da tela de Configurações do Windows 11 (tema escuro)
    private val cBgTop = Color.parseColor("#111A33")
    private val cBgBot = Color.parseColor("#0A0F1F")
    private val cText = Color.parseColor("#FFFFFF")
    private val cSoft = Color.parseColor("#E4E9F2")
    private val cSub = Color.parseColor("#9AA5B8")
    private val cAcc = Color.parseColor("#19B4F0")
    private val cCard = Color.parseColor("#12FFFFFF")
    private val cSel = Color.parseColor("#1CFFFFFF")
    private val cLine = Color.parseColor("#26FFFFFF")

    private var open = false
    private var compact = false
    private var sel = 0
    private var query = ""
    private var ignoreWatch = false
    private val subStack = ArrayList<Pair<String, () -> View>>()

    private lateinit var win: FrameLayout
    private lateinit var backBtn: TextView
    private lateinit var side: LinearLayout
    private lateinit var profileBox: LinearLayout
    private lateinit var searchBox: LinearLayout
    private lateinit var search: EditText
    private lateinit var itemsCol: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var contentCol: LinearLayout

    private val cats: List<Cat> by lazy { buildCats() }

    init {
        build()
        ui.onDrag = { dragging ->
            handler.removeCallbacks(undim)
            setDim(dragging)
        }
        ui.onTap = {
            handler.removeCallbacks(undim)
            setDim(true)
            handler.postDelayed(undim, 1400)
        }
    }

    /** Enquanto edita o Menu Iniciar, a janela fica quase transparente para mostrar a prévia atrás dela. */
    private fun setDim(on: Boolean) {
        if (!open || !previewing) {
            win.animate().alpha(1f).setDuration(120).start()
            return
        }
        win.animate().alpha(if (on) 0.18f else 1f).setDuration(120).start()
    }

    private fun updatePreview() {
        val want = open && !minimized && query.isBlank() && subStack.isNotEmpty() && subStack.last().first == "Menu Iniciar"
        if (want == previewing) return
        previewing = want
        startPreview(want)
        if (!want) {
            handler.removeCallbacks(undim)
            win.animate().alpha(1f).setDuration(120).start()
        }
    }

    // ================================================================== API pública

    fun show() {
        WindowStack.raise(root, layer, stackAbove)
        if (open) {
            if (minimized) restore()
            return
        }
        open = true
        minimized = false
        onStateChange?.invoke()
        sel = 0
        query = ""
        subStack.clear()
        maximized = prefs.settingsMax
        ignoreWatch = true
        search.setText("")
        ignoreWatch = false
        win.animate().cancel()
        sizeWindow()
        renderProfile()
        render()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    /** Recolhe a janela para a barra de tarefas (ela continua aberta, com a página atual). */
    fun minimize() {
        if (!open || minimized) return
        lastSnap = snapView(win, 480)
        minimized = true
        search.clearFocus()
        updatePreview()
        handler.removeCallbacks(undim)
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (open && minimized) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
        onStateChange?.invoke()
    }

    /** Traz de volta a janela minimizada, na mesma posição e página. */
    fun restore() {
        if (!open || !minimized) return
        minimized = false
        WindowStack.raise(root, layer, stackAbove)
        win.animate().cancel()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.VISIBLE
        win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        updatePreview()
        onStateChange?.invoke()
    }

    /** Clique no ícone da barra de tarefas: restaura se minimizada, minimiza se estiver à frente. */
    fun toggleFromTaskbar() {
        when {
            minimized -> restore()
            !WindowStack.isTop(root, layer, stackAbove) -> WindowStack.raise(root, layer, stackAbove)
            else -> minimize()
        }
    }

    fun close() {
        if (!open) return
        open = false
        minimized = false
        lastSnap = null
        onStateChange?.invoke()
        leaveGameFullscreen()
        updatePreview()
        handler.removeCallbacks(undim)
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (!open) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    /** Chamado quando nome/foto do perfil mudam. */
    fun refresh() {
        if (!open) return
        renderProfile()
        renderContent()
    }

    private var stackAbove: View? = null

    fun attachBelow(menuLayer: View) {
        stackAbove = menuLayer
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ================================================================== categorias

    private fun buildCats(): List<Cat> = listOf(
        Cat("Sistema", R.drawable.ic_pc, header = { volumeCard() }) {
            listOf(
                Row("Configuração do PC", "Processador, memória e armazenamento", R.drawable.ic_pc, action = { openPc() }),
                Row("Tela e navegação", "Modo imersivo e ícones da área de trabalho", R.drawable.ic_brightness,
                    page = { ui.panel("screen")!! }),
                Row("Exibição", "Brilho, rotação e tela do Android", R.drawable.ic_view,
                    action = { act.openDisplaySettings() }),
                Row("Botões de volume", "Bloquear os botões físicos de volume", R.drawable.ic_volume,
                    page = { ui.panel("volkeys")!! }),
                Row("Atalhos de teclado em outros apps", "Alt + V, Alt + R e Cmd + G (ativar em Acessibilidade)", R.drawable.ic_keyboard,
                    page = { ui.panel("volkeys")!! }),
                Row("Contador de FPS", "FPS real ou falso sobre os apps", R.drawable.ic_speed,
                    page = { ui.panel("fps")!! }),
                Row("Monitor de desempenho", "FPS, CPU, GPU e RAM sobre os apps", R.drawable.ic_cpu,
                    page = { ui.panel("perf")!! }),
                Row("Teclado", "Bloquear o teclado na tela em todos os apps", R.drawable.ic_keyboard,
                    page = { ui.panel("keyboard")!! }),
                Row("Som", "Toques, mídia e alarmes do Android", R.drawable.ic_music_note,
                    action = { openAndroid(Settings.ACTION_SOUND_SETTINGS) }),
                Row("Bateria", "Economia de bateria", R.drawable.ic_battery,
                    action = { openAndroid(Settings.ACTION_BATTERY_SAVER_SETTINGS) }),
                Row("Armazenamento", "Espaço usado e livre", R.drawable.ic_storage,
                    action = { openAndroid(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }),
                Row("Notificações", "Acesso do WinLauncher às notificações", R.drawable.ic_bell,
                    action = { openAndroid(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) })
            )
        },
        Cat("Bluetooth e dispositivos", R.drawable.ic_bluetooth) {
            listOf(
                Row("Bluetooth", "Parear e gerenciar dispositivos", R.drawable.ic_bluetooth,
                    action = { openAndroid(Settings.ACTION_BLUETOOTH_SETTINGS) }),
                Row("Mouse e interação", "Cursor, tamanho e comportamento", R.drawable.ic_mouse,
                    page = { ui.panel("mouse")!! })
            )
        },
        Cat("Rede e Internet", R.drawable.ic_wifi) {
            listOf(
                Row("Wi-Fi", "Redes sem fio disponíveis", R.drawable.ic_wifi,
                    action = { openAndroid(Settings.ACTION_WIFI_SETTINGS) }),
                Row("Modo avião", "Desligar todas as conexões sem fio", R.drawable.ic_airplane,
                    action = { openAndroid(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }),
                Row("Hotspot e mais redes", "Compartilhar internet e redes móveis", R.drawable.ic_hotspot,
                    action = { openAndroid(Settings.ACTION_WIRELESS_SETTINGS) }),
                // temporário (WinLauncher Remote, etapa 2): sai depois da confirmação dos testes
                Row("Diagnóstico do YouTube Music", "Testar leitura e controle do YouTube Music", R.drawable.ic_music_note,
                    page = { ui.panel("ytdiag")!! }),
                // temporário (WinLauncher Remote, etapa 3A): sai depois da confirmação dos testes
                Row("Diagnóstico do Remote (chave e certificado)", "Testar Keystore, assinatura e hash do certificado", R.drawable.ic_lock,
                    page = { ui.panel("remotediag")!! }),
                // WinLauncher Remote, etapa 3B (parte 1): servidor TLS local
                Row("Servidor do WinLauncher Remote", "Ligar o servidor local seguro e ver o estado", R.drawable.ic_pc,
                    page = { ui.panel("remoteserver")!! })
            )
        },
        Cat("Personalização", R.drawable.ic_palette) {
            listOf(
                Row("Wallpaper", "Imagem, GIF ou vídeo de fundo", R.drawable.ic_image,
                    page = { ui.panel("wallpaper")!! }),
                Row("Aparência", "Tema, cor de destaque e vidro", R.drawable.ic_palette,
                    page = { ui.panel("appearance")!! }),
                Row("Barra de tarefas", "Tamanho, posição e bandeja", R.drawable.ic_view,
                    page = { ui.panel("taskbar")!! }),
                Row("Menu Iniciar", "Tamanho, posição e colunas", R.drawable.ic_start,
                    page = { ui.panel("start")!! }),
                Row("Widgets", "Relógio, clima, música e fontes", R.drawable.ic_widgets,
                    page = { ui.panel("widgets")!! })
            )
        },
        Cat("Aplicativos", R.drawable.ic_widgets) {
            val rows = ArrayList<Row>()
            rows.add(Row("Aplicativos instalados", "Ver, abrir e desinstalar apps", R.drawable.ic_widgets,
                action = { openAndroid(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS) }))
            rows.add(Row("Aplicativos padrão", "Definir o app padrão de cada app nativo", R.drawable.ic_open,
                action = { act.openDefaultAppsPanel() }))
            rows.add(Row("Apps padrão do Android", "Escolher qual app abre cada tipo de arquivo", R.drawable.ic_open,
                action = { openAndroid(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS) }))
            rows.add(Row("Exibir sobre outros apps", "Barra de tarefas e botão de volume flutuantes", R.drawable.ic_pin,
                action = { openAndroid(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, withPackage = true) }))
            // some depois que a pessoa autoriza (mesma regra do menu da área de trabalho)
            if (!act.packageManager.canRequestPackageInstalls()) {
                rows.add(Row("Instalar aplicativo (APK)", "Permitir que o WinLauncher instale apps", R.drawable.ic_install,
                    action = { openAndroid(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, withPackage = true) }))
            }
            rows
        },
        Cat("Contas", R.drawable.ic_info, header = { profileCard() }) {
            listOf(
                Row("Editar perfil", "Nome e foto", R.drawable.ic_pin, action = { editProfile() })
            )
        },
        Cat("Hora e idioma", R.drawable.ic_moon) {
            listOf(
                Row("Data e hora", "Fuso horário e formato", R.drawable.ic_moon,
                    action = { openAndroid(Settings.ACTION_DATE_SETTINGS) }),
                Row("Idioma e região", "Idioma do Android", R.drawable.ic_location,
                    action = { openAndroid(Settings.ACTION_LOCALE_SETTINGS) }),
                Row("Teclado", "Métodos de entrada", R.drawable.ic_open,
                    action = { openAndroid(Settings.ACTION_INPUT_METHOD_SETTINGS) })
            )
        },
        Cat("Jogos", R.drawable.ic_chess) {
            listOf(
                Row("Xadrez", "Jogue contra o bot ou com um amigo", R.drawable.ic_chess,
                    page = { chessPage() })
            )
        },
        Cat("Acessibilidade", R.drawable.ic_eye) {
            listOf(
                Row("Acessibilidade do Android", "Leitor de tela, legendas e ampliação", R.drawable.ic_eye,
                    action = { openAndroid(Settings.ACTION_ACCESSIBILITY_SETTINGS) }),
                Row("Tamanho da fonte e da tela", "Exibição do Android", R.drawable.ic_view,
                    action = { act.openDisplaySettings() })
            )
        },
        Cat("Privacidade e segurança", R.drawable.ic_eye_off) {
            listOf(
                Row("Bloquear agora", "Abrir a tela de bloqueio do WinLauncher", R.drawable.ic_moon,
                    action = { close(); lockNow() }),
                Row("Senha de bloqueio", "Criar, alterar ou remover a senha do WinLauncher", R.drawable.ic_lock,
                    action = { close(); act.openPasswordPanel() }),
                Row("Segurança do Android", "Bloqueio de tela e proteção do aparelho", R.drawable.ic_eye_off,
                    action = { openAndroid(Settings.ACTION_SECURITY_SETTINGS) }),
                Row("Privacidade", "Permissões e dados", R.drawable.ic_eye,
                    action = { openAndroid(Settings.ACTION_PRIVACY_SETTINGS) }),
                Row("Localização", "Acesso do WinLauncher e dos apps à localização", R.drawable.ic_location,
                    action = { openAndroid(Settings.ACTION_LOCATION_SOURCE_SETTINGS) })
            )
        },
        Cat("Windows Update", R.drawable.ic_refresh, header = { updateCard() }) { emptyList() }
    )

    // ================================================================== montagem da janela

    private fun build() {
        layer.tag = CursorController.NOHAND

        win = FrameLayout(act)
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.elevation = dp(16).toFloat()
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cBgTop, cBgBot))
        bg.cornerRadius = dp(10).toFloat()
        bg.setStroke(dp(1), cLine)
        win.background = bg
        win.clipToOutline = true
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                outline.alpha = 0.6f
            }
        }

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildTitleBar(), LinearLayout.LayoutParams(MATCH, dp(40)))

        val body = LinearLayout(act)
        body.orientation = LinearLayout.HORIZONTAL
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // ---- barra lateral
        side = LinearLayout(act)
        side.orientation = LinearLayout.VERTICAL
        side.setPadding(dp(8), dp(4), dp(8), dp(8))
        body.addView(side, LinearLayout.LayoutParams(dp(220), MATCH))

        profileBox = LinearLayout(act)
        profileBox.orientation = LinearLayout.HORIZONTAL
        profileBox.gravity = Gravity.CENTER_VERTICAL
        profileBox.setPadding(dp(6), dp(4), dp(6), dp(10))
        side.addView(profileBox, LinearLayout.LayoutParams(MATCH, WRAP))

        searchBox = LinearLayout(act)
        searchBox.orientation = LinearLayout.HORIZONTAL
        searchBox.gravity = Gravity.CENTER_VERTICAL
        searchBox.background = rr(Color.parseColor("#1AFFFFFF"), 6, cLine)
        searchBox.setPadding(dp(10), 0, dp(10), 0)
        search = EditText(act)
        search.hint = "Localizar uma configuração"
        search.setHintTextColor(cSub)
        search.setTextColor(cText)
        search.textSize = 12.5f
        search.background = null
        search.setSingleLine(true)
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_DONE
        search.setPadding(0, dp(9), 0, dp(9))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (ignoreWatch) return
                query = s?.toString() ?: ""
                renderSidebar()
                renderContent()
            }
        })
        searchBox.addView(search, LinearLayout.LayoutParams(0, WRAP, 1f))
        val mag = ImageView(act)
        mag.setImageResource(R.drawable.ic_search)
        mag.setColorFilter(cSub)
        searchBox.addView(mag, LinearLayout.LayoutParams(dp(16), dp(16)))
        side.addView(searchBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })

        val sideScroll = ScrollView(act)
        sideScroll.isVerticalScrollBarEnabled = false
        itemsCol = LinearLayout(act)
        itemsCol.orientation = LinearLayout.VERTICAL
        sideScroll.addView(itemsCol, FrameLayout.LayoutParams(MATCH, WRAP))
        side.addView(sideScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // ---- conteúdo
        scroll = ScrollView(act)
        scroll.isVerticalScrollBarEnabled = false
        contentCol = LinearLayout(act)
        contentCol.orientation = LinearLayout.VERTICAL
        contentCol.setPadding(dp(14), dp(8), dp(18), dp(18))
        scroll.addView(contentCol, FrameLayout.LayoutParams(MATCH, WRAP))
        body.addView(scroll, LinearLayout.LayoutParams(0, MATCH, 1f))

        layer.addView(win, FrameLayout.LayoutParams(dp(880), dp(560), Gravity.TOP or Gravity.START))

        gameLayer.visibility = View.GONE
        gameLayer.tag = CursorController.NOHAND
        gameLayer.isClickable = true
        gameLayer.elevation = dp(24).toFloat()
        gameLayer.setBackgroundColor(cBgBot)
        gameLayer.setPadding(dp(12), dp(12), dp(12), dp(12))
        layer.addView(gameLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ================================================================== jogo (xadrez)

    /** Página do xadrez dentro das Configurações. O mesmo tabuleiro é reaproveitado para não perder a partida. */
    private fun chessPage(): View {
        val slot = FrameLayout(act)
        if (gameFs != 0) {
            val t = tv("Jogo em tela cheia", 13f, cSub)
            t.gravity = Gravity.CENTER
            slot.addView(t, FrameLayout.LayoutParams(MATCH, dp(120)))
            return slot
        }
        (chess.parent as? ViewGroup)?.removeView(chess)
        val h = if (win.height > 0) maxOf(dp(380), minOf(dp(560), win.height - dp(150))) else dp(440)
        slot.addView(chess, FrameLayout.LayoutParams(MATCH, h))
        return slot
    }

    /** Cada toque no botão avança: janela → tela cheia (com barra de tarefas) → tela cheia total → janela. */
    private fun cycleGameFullscreen() {
        gameFs = (gameFs + 1) % 3
        if (gameFs == 0) {
            leaveGameFullscreen()
            if (open && subStack.isNotEmpty() && subStack.last().first == "Xadrez") renderContent()
            return
        }
        val ins = if (gameFs == 1) taskbarInsets() else Pair(0, 0)
        (chess.parent as? ViewGroup)?.removeView(chess)
        if (chess.parent == null) gameLayer.removeAllViews()
        gameLayer.addView(chess, FrameLayout.LayoutParams(MATCH, MATCH))
        val lp = gameLayer.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = ins.first
        lp.bottomMargin = ins.second
        gameLayer.layoutParams = lp
        gameLayer.visibility = View.VISIBLE
        chess.setFullscreenMode(gameFs)
    }

    private fun leaveGameFullscreen() {
        if (gameFs == 0 && gameLayer.childCount == 0) return
        gameFs = 0
        gameLayer.removeAllViews()
        gameLayer.visibility = View.GONE
        chess.setFullscreenMode(0)
    }

    private fun buildTitleBar(): View {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(6), 0, dp(4), 0)

        backBtn = TextView(act)
        backBtn.text = "←"
        backBtn.textSize = 18f
        backBtn.setTextColor(cSoft)
        backBtn.gravity = Gravity.CENTER
        backBtn.isClickable = true
        backBtn.setOnClickListener { goBack() }
        bar.addView(backBtn, LinearLayout.LayoutParams(dp(36), dp(32)))

        val t = tv("Configurações", 12.5f, cSoft)
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })

        val minBtn = ImageView(act)
        minBtn.setImageResource(R.drawable.ic_minimize)
        minBtn.setColorFilter(cSoft)
        minBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        minBtn.isClickable = true
        minBtn.background = closeBg(false)
        minBtn.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = rr(Color.parseColor("#26FFFFFF"), 8)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = closeBg(false)
            }
            false
        }
        minBtn.setOnClickListener { minimize() }
        bar.addView(minBtn, LinearLayout.LayoutParams(dp(38), dp(36)))

        maxBtn = ImageView(act)
        maxBtn.setImageResource(R.drawable.ic_maximize)
        maxBtn.setColorFilter(cSoft)
        maxBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        maxBtn.isClickable = true
        maxBtn.background = closeBg(false)
        maxBtn.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = rr(Color.parseColor("#26FFFFFF"), 8)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = closeBg(false)
            }
            false
        }
        maxBtn.setOnClickListener { toggleMaximize() }
        bar.addView(maxBtn, LinearLayout.LayoutParams(dp(38), dp(36)))

        val x = ImageView(act)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(cSoft)
        x.setPadding(dp(10), dp(10), dp(10), dp(10))
        x.isClickable = true
        x.background = closeBg(false)
        x.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = closeBg(true)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = closeBg(false)
            }
            false
        }
        x.setOnClickListener { close() }
        bar.addView(x, LinearLayout.LayoutParams(dp(38), dp(36)))

        var offX = 0f
        var offY = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                }
                MotionEvent.ACTION_MOVE -> if (!maximized) moveTo(ev.rawX + offX, ev.rawY + offY)
            }
            true
        }
        return bar
    }

    private fun closeBg(hover: Boolean): GradientDrawable =
        rr(if (hover) Color.parseColor("#66E5484D") else Color.TRANSPARENT, 8)

    // ================================================================== posição e tamanho

    private fun screenW(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun screenH(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    private fun sizeWindow() {
        val ins = taskbarInsets()
        val w: Int
        val h: Int
        if (maximized) {
            w = screenW()
            h = screenH() - ins.first - ins.second
        } else {
            w = minOf(screenW() - dp(16), dp(880))
            h = minOf(screenH() - dp(80), dp(560))
        }
        compact = w < dp(560)
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        lp.height = h
        win.layoutParams = lp
        val sp = side.layoutParams as LinearLayout.LayoutParams
        sp.width = if (compact) dp(60) else dp(220)
        side.layoutParams = sp
        searchBox.visibility = if (compact) View.GONE else View.VISIBLE
        applyMaxStyle()
    }

    /** Cantos retos e ícone diferente quando maximizada. */
    private fun applyMaxStyle() {
        val r = if (maximized) 0 else 10
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cBgTop, cBgBot))
        bg.cornerRadius = dp(r).toFloat()
        bg.setStroke(dp(1), cLine)
        win.background = bg
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
                outline.alpha = 0.6f
            }
        }
        win.invalidateOutline()
        maxBtn.setImageResource(if (maximized) R.drawable.ic_restore else R.drawable.ic_maximize)
    }

    private fun toggleMaximize() {
        maximized = !maximized
        prefs.settingsMax = maximized
        sizeWindow()
        render()
        win.post { place() }
    }

    private fun place() {
        if (maximized) {
            win.x = 0f
            win.y = taskbarInsets().first.toFloat()
            return
        }
        val w = win.width.toFloat()
        val h = win.height.toFloat()
        moveTo((screenW() - w) / 2f, maxOf(dp(8).toFloat(), (screenH() - h) / 2f - dp(24)))
    }

    private fun moveTo(x: Float, y: Float) {
        val maxX = maxOf(0f, screenW() - win.width.toFloat())
        val maxY = maxOf(0f, screenH() - dp(48).toFloat())
        win.x = x.coerceIn(0f, maxX)
        win.y = y.coerceIn(0f, maxY)
    }

    // ================================================================== renderização

    private fun render() {
        renderSidebar()
        renderContent()
    }

    private fun renderProfile() {
        profileBox.removeAllViews()
        profileBox.addView(avatar(if (compact) 34 else 48), LinearLayout.LayoutParams(dp(if (compact) 34 else 48), dp(if (compact) 34 else 48)))
        if (!compact) {
            val col = LinearLayout(act)
            col.orientation = LinearLayout.VERTICAL
            col.addView(tv(userName(), 13.5f, cText, true))
            col.addView(tv("Conta local", 11f, cSub))
            profileBox.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        }
        profileBox.setOnClickListener { selectCat(CAT_ACCOUNTS) }
    }

    private fun renderSidebar() {
        itemsCol.removeAllViews()
        for (i in cats.indices) itemsCol.addView(sideItem(i, cats[i]), LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun sideItem(i: Int, c: Cat): View {
        val selected = i == sel && query.isBlank()
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = if (compact) Gravity.CENTER else Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(9), dp(6), dp(9))
        row.background = ripple(rr(if (selected) cSel else Color.TRANSPARENT, 6))
        row.isClickable = true

        if (!compact) {
            val bar = View(act)
            bar.background = rr(cAcc, 2)
            bar.visibility = if (selected) View.VISIBLE else View.INVISIBLE
            row.addView(bar, LinearLayout.LayoutParams(dp(3), dp(16)).apply { rightMargin = dp(8) })
        }
        val ic = ImageView(act)
        ic.setImageResource(c.icon)
        ic.setColorFilter(if (selected) cAcc else cSoft)
        row.addView(ic, LinearLayout.LayoutParams(dp(20), dp(20)))
        if (!compact) {
            row.addView(tv(c.name, 13f, cText), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        }
        row.setOnClickListener { selectCat(i) }
        return row
    }

    private fun selectCat(i: Int) {
        sel = i
        subStack.clear()
        query = ""
        ignoreWatch = true
        search.setText("")
        ignoreWatch = false
        render()
    }

    private fun renderContent() {
        contentCol.removeAllViews()
        updateBack()
        if (query.isNotBlank()) {
            contentCol.addView(breadcrumb(listOf("Resultados da pesquisa")))
            renderSearch()
            scroll.scrollTo(0, 0)
            updatePreview()
            return
        }
        val cat = cats[sel]
        contentCol.addView(breadcrumb(listOf(cat.name) + subStack.map { it.first }))
        if (subStack.isEmpty()) {
            cat.header?.invoke()?.let { contentCol.addView(it, cardLp()) }
            val rows = cat.rows()
            if (cat.name == "Jogos") contentCol.addView(gamesCover(rows), cardLp())
            else for (r in rows) contentCol.addView(rowView(r, null), cardLp())
            if (rows.isEmpty() && cat.header == null) {
                contentCol.addView(tv("Ainda não há opções aqui.", 13f, cSub))
            }
        } else {
            val page = subStack.last().second()
            val card = LinearLayout(act)
            card.orientation = LinearLayout.VERTICAL
            card.background = rr(cCard, 8)
            card.setPadding(dp(16), dp(14), dp(16), dp(16))
            card.addView(page, LinearLayout.LayoutParams(MATCH, WRAP))
            contentCol.addView(card, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        scroll.scrollTo(0, 0)
        updatePreview()
    }

    private fun renderSearch() {
        val q = norm(query.trim())
        var found = 0
        for (i in cats.indices) {
            val cat = cats[i]
            for (r in cat.rows()) {
                if (norm(r.title).contains(q) || norm(r.sub).contains(q)) {
                    found++
                    contentCol.addView(rowView(r, cat.name, i), cardLp())
                }
            }
        }
        if (found == 0) contentCol.addView(tv("Nada encontrado para \"${query.trim()}\".", 13f, cSub))
    }

    /** Capa da página Jogos: um ícone de xadrez grande e o nome do jogo embaixo (toque para abrir). */
    private fun gamesCover(rows: List<Row>): View {
        val wrap = LinearLayout(act)
        wrap.orientation = LinearLayout.HORIZONTAL
        wrap.setPadding(dp(6), dp(10), dp(6), dp(6))
        val chessFont = try {
            Typeface.createFromAsset(act.assets, "fonts/chess_pieces.ttf")
        } catch (t: Throwable) {
            Typeface.DEFAULT
        }
        for (r in rows) {
            val tile = LinearLayout(act)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.setPadding(dp(8), dp(8), dp(8), dp(8))
            tile.background = ripple(rr(Color.TRANSPARENT, 14))
            tile.isClickable = true

            val icon = TextView(act)
            icon.text = "\u265E"
            icon.typeface = chessFont
            icon.textSize = 54f
            icon.setTextColor(Color.WHITE)
            icon.gravity = Gravity.CENTER
            icon.includeFontPadding = false
            val bg = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#3C6FD1"), Color.parseColor("#0E1A3A"))
            )
            bg.cornerRadius = dp(22).toFloat()
            bg.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            icon.background = bg
            tile.addView(icon, LinearLayout.LayoutParams(dp(104), dp(104)))

            val name = tv(r.title, 14f, cText, bold = true)
            name.gravity = Gravity.CENTER
            tile.addView(name, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })

            tile.setOnClickListener { r.page?.let { pg -> push(r.title, pg) } ?: r.action?.invoke() }
            wrap.addView(tile, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        return wrap
    }

    private fun updateBack() {
        val canBack = query.isNotBlank() || subStack.isNotEmpty()
        backBtn.alpha = if (canBack) 1f else 0.35f
    }

    private fun goBack() {
        if (query.isNotBlank()) {
            query = ""
            ignoreWatch = true
            search.setText("")
            ignoreWatch = false
            render()
        } else if (subStack.isNotEmpty()) {
            subStack.removeAt(subStack.lastIndex)
            renderContent()
        }
    }

    private fun push(title: String, page: () -> View) {
        subStack.add(title to page)
        renderContent()
    }

    // ================================================================== peças

    private fun cardLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) }

    private fun breadcrumb(parts: List<String>): TextView {
        val ssb = SpannableStringBuilder()
        parts.forEachIndexed { i, p ->
            if (i > 0) {
                val s = ssb.length
                ssb.append("  ›  ")
                ssb.setSpan(ForegroundColorSpan(cSub), s, ssb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            val s = ssb.length
            ssb.append(p)
            ssb.setSpan(
                ForegroundColorSpan(if (i == parts.lastIndex) cText else cSub),
                s, ssb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        val t = TextView(act)
        t.text = ssb
        t.textSize = 19f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dp(2), dp(4), 0, dp(14))
        return t
    }

    /** Linha clicável. [catName] só aparece nos resultados de pesquisa. */
    private fun rowView(r: Row, catName: String?, catIndex: Int = -1): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(13), dp(14), dp(13))
        row.background = ripple(rr(cCard, 6))
        row.isClickable = true

        val ic = ImageView(act)
        ic.setImageResource(r.icon)
        ic.setColorFilter(cSoft)
        row.addView(ic, LinearLayout.LayoutParams(dp(20), dp(20)))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(r.title, 13.5f, cText))
        val subText = if (catName != null) "$catName  ›  ${r.sub}" else r.sub
        if (subText.isNotEmpty()) col.addView(tv(subText, 11.5f, cSub))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })

        if (r.page != null || r.action != null) {
            row.addView(tv("›", 18f, cSub))
        }
        row.setOnClickListener {
            if (catName != null && catIndex >= 0) {
                // veio da pesquisa: abre a categoria certa antes
                sel = catIndex
                subStack.clear()
                query = ""
                ignoreWatch = true
                search.setText("")
                ignoreWatch = false
                renderSidebar()
                if (r.page != null) push(r.title, r.page) else {
                    renderContent()
                    r.action?.invoke()
                }
            } else if (r.page != null) {
                push(r.title, r.page)
            } else {
                r.action?.invoke()
            }
        }
        return row
    }

    private fun avatar(sizeDp: Int): View {
        val box = FrameLayout(act)
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        box.clipToOutline = true
        var bmp: android.graphics.Bitmap? = null
        try {
            val f = File(act.filesDir, "avatar.png")
            if (store.getBoolean("userHasPhoto", false) && f.exists()) bmp = BitmapFactory.decodeFile(f.absolutePath)
        } catch (t: Throwable) {
            bmp = null
        }
        if (bmp != null) {
            val iv = ImageView(act)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
            box.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(Color.parseColor("#2A3552"))
            box.background = g
            val letter = tv(userName().take(1).uppercase(), (sizeDp * 0.42f), cText, true)
            letter.gravity = Gravity.CENTER
            box.addView(letter, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        return box
    }

    private fun profileCard(): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = rr(cCard, 8)
        row.setPadding(dp(18), dp(16), dp(18), dp(16))
        row.addView(avatar(64), LinearLayout.LayoutParams(dp(64), dp(64)))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(userName(), 18f, cText, true))
        col.addView(tv("Conta local", 12f, cSub))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(16) })
        return row
    }

    private fun volumeCard(): View {
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = maxOf(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)

        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = rr(cCard, 6)
        row.setPadding(dp(16), dp(10), dp(16), dp(10))

        val ic = ImageView(act)
        ic.setImageResource(R.drawable.ic_volume)
        ic.setColorFilter(cSoft)
        row.addView(ic, LinearLayout.LayoutParams(dp(20), dp(20)))
        row.addView(tv("Volume", 13.5f, cText), LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(14) })

        val value = tv((cur * 100 / max).toString(), 12.5f, cSoft)
        val sb = SeekBar(act)
        sb.max = max
        sb.progress = cur
        sb.progressTintList = ColorStateList.valueOf(cAcc)
        sb.thumbTintList = ColorStateList.valueOf(cAcc)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                value.text = (v * 100 / max).toString()
                if (fromUser) {
                    try {
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                    } catch (t: Throwable) {
                    }
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(10); rightMargin = dp(10) })
        row.addView(value, LinearLayout.LayoutParams(dp(30), WRAP))
        return row
    }

    private fun updateCard(): View {
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.background = rr(cCard, 8)
        col.setPadding(dp(18), dp(16), dp(18), dp(18))
        val ver = try {
            act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "?"
        } catch (t: Throwable) {
            "?"
        }
        col.addView(tv("WinLauncher", 17f, cText, true))
        col.addView(tv("Versão instalada: $ver", 12.5f, cSub), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) })
        val b = tv("Verificar atualizações", 13f, Color.parseColor("#06121C"), true)
        b.gravity = Gravity.CENTER
        b.background = ripple(rr(cAcc, 6))
        b.setPadding(dp(18), dp(10), dp(18), dp(10))
        b.isClickable = true
        b.setOnClickListener { checkUpdates() }
        col.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(14) })
        return col
    }

    // ================================================================== utilidades

    private fun openAndroid(action: String, withPackage: Boolean = false) {
        try {
            val i = Intent(action)
            if (withPackage) i.data = Uri.parse("package:" + act.packageName)
            act.startActivity(i)
        } catch (e: Exception) {
            act.toast("Não foi possível abrir esta configuração")
        }
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return v
    }

    private fun rr(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun ripple(base: GradientDrawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#26FFFFFF")), base, null)
}
