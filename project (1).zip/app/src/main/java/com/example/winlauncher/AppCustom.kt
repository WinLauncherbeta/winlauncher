package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import java.io.File

/**
 * Personalização por app: nome e ícone (capa) escolhidos pelo usuário.
 * Nome fica no SharedPreferences("win") com a chave "alias_<componente>";
 * o ícone fica em filesDir/app_icons/<componente>.png.
 */
object AppCustom {
    /** Componente "virtual" do navegador nativo do launcher (para guardar o ícone escolhido). */
    val BROWSER = ComponentName("com.example.winlauncher", "native.Browser")

    /** Componente "virtual" do gerenciador de arquivos nativo (para guardar o ícone escolhido). */
    val FILES = ComponentName("com.example.winlauncher", "native.Files")

    /** Componente "virtual" da galeria de fotos nativa (para guardar o ícone escolhido). */
    val GALLERY = ComponentName("com.example.winlauncher", "native.Gallery")

    /** Componente \"virtual\" do monitor de desempenho (para guardar o ícone escolhido). */
    val PERF = ComponentName("com.example.winlauncher", "native.PerfMonitor")
    val MUSIC = ComponentName("com.example.winlauncher", "native.Music")

    /** Componente "virtual" do Mapeador de gamepad (para guardar nome e ícone escolhidos). */
    val PADMAP = ComponentName("com.example.winlauncher", "native.PadMapper")

    private fun safe(cn: ComponentName): String =
        cn.flattenToString().replace(Regex("[^A-Za-z0-9._]"), "_")

    private fun iconFile(ctx: Context, cn: ComponentName): File =
        File(File(ctx.filesDir, "app_icons").also { it.mkdirs() }, safe(cn) + ".png")

    private fun sp(ctx: Context) = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)

    fun label(ctx: Context, cn: ComponentName, default: String): String =
        sp(ctx).getString("alias_" + cn.flattenToString(), null)?.takeIf { it.isNotBlank() } ?: default

    fun hasLabel(ctx: Context, cn: ComponentName): Boolean =
        !sp(ctx).getString("alias_" + cn.flattenToString(), null).isNullOrBlank()

    fun setLabel(ctx: Context, cn: ComponentName, name: String) {
        val e = sp(ctx).edit()
        if (name.isBlank()) e.remove("alias_" + cn.flattenToString())
        else e.putString("alias_" + cn.flattenToString(), name.trim())
        e.apply()
    }

    fun icon(ctx: Context, cn: ComponentName): Drawable? {
        val f = iconFile(ctx, cn)
        if (!f.exists()) return null
        val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath) ?: return null
        return BitmapDrawable(ctx.resources, bmp)
    }

    fun hasIcon(ctx: Context, cn: ComponentName): Boolean = iconFile(ctx, cn).exists()

    fun setIcon(ctx: Context, cn: ComponentName, bmp: Bitmap) {
        iconFile(ctx, cn).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun resetIcon(ctx: Context, cn: ComponentName) {
        iconFile(ctx, cn).delete()
    }

    fun resetAll(ctx: Context, cn: ComponentName) {
        setLabel(ctx, cn, "")
        resetIcon(ctx, cn)
    }
}
