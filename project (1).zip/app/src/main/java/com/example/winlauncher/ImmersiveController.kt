package com.example.winlauncher

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController

/**
 * Esconde barra de status e de navegação. Deslizar a partir da borda mostra as barras
 * temporariamente e elas voltam sozinhas (comportamento "transient bars").
 */
object ImmersiveController {
    @Suppress("DEPRECATION")
    fun apply(a: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val c = a.window.insetsController
                if (c != null) {
                    c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    c.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                }
            } else {
                val d = a.window.decorView
                d.systemUiVisibility = d.systemUiVisibility or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            }
        } catch (e: Exception) {
        }
    }
}
