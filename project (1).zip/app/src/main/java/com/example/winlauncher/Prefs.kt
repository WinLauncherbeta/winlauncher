package com.example.winlauncher

import android.content.SharedPreferences

/**
 * Preferências de personalização. Usa o mesmo SharedPreferences("win") já existente;
 * as chaves antigas (tb, st, dk, wp, wpVideo, init) continuam sendo lidas pelo MainActivity.
 * Todas as chaves novas começam com "ui_" e os padrões reproduzem o visual anterior.
 */
class Prefs(private val sp: SharedPreferences) {

    fun int(k: String, d: Int): Int = sp.getInt(k, d)
    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun putInt(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    fun putBool(k: String, v: Boolean) {
        sp.edit().putBoolean(k, v).apply()
    }

    fun float(k: String, d: Float): Float = sp.getFloat(k, d)
    fun putFloat(k: String, v: Float) {
        sp.edit().putFloat(k, v).apply()
    }

    fun str(k: String, d: String): String = sp.getString(k, d) ?: d
    fun putStr(k: String, v: String) {
        sp.edit().putString(k, v).apply()
    }

    // ---- barra de tarefas
    var tbScale: Int
        get() = int("ui_tb_scale", 100)
        set(v) = putInt("ui_tb_scale", v)
    var tbHeight: Int
        get() = int("ui_tb_height", 48)
        set(v) = putInt("ui_tb_height", v)
    var tbIcon: Int
        get() = int("ui_tb_icon", 44)
        set(v) = putInt("ui_tb_icon", v)
    var tbClock: Int
        get() = int("ui_tb_clock", 11)
        set(v) = putInt("ui_tb_clock", v)
    var tbTray: Int
        get() = int("ui_tb_tray", 20)
        set(v) = putInt("ui_tb_tray", v)
    var tbSpace: Int
        get() = int("ui_tb_space", 0)
        set(v) = putInt("ui_tb_space", v)

    /** 0 = embaixo, 1 = em cima */
    var tbPos: Int
        get() = int("ui_tb_pos", 0)
        set(v) = putInt("ui_tb_pos", v)

    /** 0 = transparência ajustável, 1 = vidro fosco, 2 = invisível */
    var tbBg: Int
        get() = int("ui_tb_bg", 0)
        set(v) = putInt("ui_tb_bg", v)
    var tbAlpha: Int
        get() = int("ui_tb_alpha", 90)
        set(v) = putInt("ui_tb_alpha", v)

    /** Bloqueia as barras do Android (status e navegação): somem de novo assim que tentam aparecer ao deslizar. */
    var lockBars: Boolean
        get() = bool("ui_lock_bars", false)
        set(v) = putBool("ui_lock_bars", v)

    /** Barra de tarefas removida (some tudo: barra, bandeja e barra flutuante). Dá para mostrar de novo. */
    var tbHidden: Boolean
        get() = bool("ui_tb_hidden", false)
        set(v) = putBool("ui_tb_hidden", v)

    /** Barra de tarefas flutuante sobre outros apps (mouse na borda da tela). */
    var tbOverlay: Boolean
        get() = bool("ui_tb_overlay", false)
        set(v) = putBool("ui_tb_overlay", v)

    /** Botão de volume flutuante (arrastável) sobre outros apps. */
    var volBtn: Boolean
        get() = bool("ui_vol_btn", false)
        set(v) = putBool("ui_vol_btn", v)

    /** Bloqueia os botões físicos de volume (aumentar/diminuir/mudo) enquanto o WinLauncher está em primeiro plano. */
    var blockVolKeys: Boolean
        get() = bool("ui_block_vol_keys", false)
        set(v) = putBool("ui_block_vol_keys", v)

    // ---- menu Iniciar
    var stW: Int
        get() = int("ui_st_w", 360)
        set(v) = putInt("ui_st_w", v)

    /** 0 = automático (comportamento original) */
    var stH: Int
        get() = int("ui_st_h", 0)
        set(v) = putInt("ui_st_h", v)

    /** 0 = centro inferior, 1 = centro da tela, 2 = esquerda */
    var stPos: Int
        get() = int("ui_st_pos", 0)
        set(v) = putInt("ui_st_pos", v)
    var stAlpha: Int
        get() = int("ui_st_alpha", 95)
        set(v) = putInt("ui_st_alpha", v)
    var stRadius: Int
        get() = int("ui_st_radius", 12)
        set(v) = putInt("ui_st_radius", v)
    var stCols: Int
        get() = int("ui_st_cols", 4)
        set(v) = putInt("ui_st_cols", v)
    var stGlass: Boolean
        get() = bool("ui_st_glass", false)
        set(v) = putBool("ui_st_glass", v)

    // ---- aparência
    /** 0 = escuro, 1 = claro */
    var theme: Int
        get() = int("ui_theme", 0)
        set(v) = putInt("ui_theme", v)
    var accent: Int
        get() = int("ui_accent", 0xFF4CC2FF.toInt())
        set(v) = putInt("ui_accent", v)
    var pnAlpha: Int
        get() = int("ui_pn_alpha", 95)
        set(v) = putInt("ui_pn_alpha", v)
    var pnGlass: Boolean
        get() = bool("ui_pn_glass", false)
        set(v) = putBool("ui_pn_glass", v)
    var anim: Boolean
        get() = bool("ui_anim", true)
        set(v) = putBool("ui_anim", v)

    // ---- área de trabalho
    var dkIcon: Int
        get() = int("ui_dk_icon", 44)
        set(v) = putInt("ui_dk_icon", v)
    var dkShow: Boolean
        get() = bool("ui_dk_show", true)
        set(v) = putBool("ui_dk_show", v)

    // ---- widgets: relógio e calendário
    var wgOn: Boolean
        get() = bool("ui_wg_on", false)
        set(v) = putBool("ui_wg_on", v)

    /** Permite arrastar o widget pela área de trabalho. */
    var wgMove: Boolean
        get() = bool("ui_wg_move", true)
        set(v) = putBool("ui_wg_move", v)

    /** Tamanho em porcentagem (100 = padrão). */
    var wgScale: Int
        get() = int("ui_wg_scale", 100)
        set(v) = putInt("ui_wg_scale", v)

    /** Centro do widget como fração (0..1) da área de trabalho; 0,5 / 0,5 = centro (primeira ativação). */
    var wgCx: Float
        get() = float("ui_wg_cx", 0.5f)
        set(v) = putFloat("ui_wg_cx", v)
    var wgCy: Float
        get() = float("ui_wg_cy", 0.5f)
        set(v) = putFloat("ui_wg_cy", v)

    /** Arquivo da fonte importada usada em cada texto; vazio = fonte padrão. */
    var wgFontDay: String
        get() = str("ui_wg_font_day", "")
        set(v) = putStr("ui_wg_font_day", v)
    var wgFontDate: String
        get() = str("ui_wg_font_date", "")
        set(v) = putStr("ui_wg_font_date", v)
    var wgFontTime: String
        get() = str("ui_wg_font_time", "")
        set(v) = putStr("ui_wg_font_time", v)

    // ---- mouse
    var cursorOn: Boolean
        get() = bool("ui_cursor_on", true)
        set(v) = putBool("ui_cursor_on", v)
    var cursorSize: Int
        get() = int("ui_cursor_size", 24)
        set(v) = putInt("ui_cursor_size", v)
    var menuHover: Boolean
        get() = bool("ui_menu_hover", true)
        set(v) = putBool("ui_menu_hover", v)
}
