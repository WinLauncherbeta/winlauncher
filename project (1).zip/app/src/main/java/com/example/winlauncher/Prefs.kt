package com.example.winlauncher

import android.content.SharedPreferences

/**
 * Preferências de personalização. Usa o mesmo SharedPreferences("win") já existente;
 * as chaves antigas (tb, st, dk, wp, wpVideo, init) continuam sendo lidas pelo MainActivity.
 * Todas as chaves novas começam com "ui_" e os padrões reproduzem o visual anterior.
 */
class Prefs(private val sp: SharedPreferences) {

    fun int(k: String, d: Int): Int = sp.getInt(k, d)
    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun putInt(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    fun putBool(k: String, v: Boolean) {
        sp.edit().putBoolean(k, v).apply()
    }

    // ---- barra de tarefas
    var tbScale: Int
        get() = int("ui_tb_scale", 100)
        set(v) = putInt("ui_tb_scale", v)
    var tbHeight: Int
        get() = int("ui_tb_height", 48)
        set(v) = putInt("ui_tb_height", v)
    var tbIcon: Int
        get() = int("ui_tb_icon", 44)
        set(v) = putInt("ui_tb_icon", v)
    var tbClock: Int
        get() = int("ui_tb_clock", 11)
        set(v) = putInt("ui_tb_clock", v)
    var tbTray: Int
        get() = int("ui_tb_tray", 20)
        set(v) = putInt("ui_tb_tray", v)
    var tbSpace: Int
        get() = int("ui_tb_space", 0)
        set(v) = putInt("ui_tb_space", v)

    /** 0 = embaixo, 1 = em cima */
    var tbPos: Int
        get() = int("ui_tb_pos", 0)
        set(v) = putInt("ui_tb_pos", v)

    /** 0 = transparência ajustável, 1 = vidro fosco, 2 = invisível */
    var tbBg: Int
        get() = int("ui_tb_bg", 0)
        set(v) = putInt("ui_tb_bg", v)
    var tbAlpha: Int
        get() = int("ui_tb_alpha", 90)
        set(v) = putInt("ui_tb_alpha", v)

    // ---- menu Iniciar
    var stW: Int
        get() = int("ui_st_w", 360)
        set(v) = putInt("ui_st_w", v)

    /** 0 = automático (comportamento original) */
    var stH: Int
        get() = int("ui_st_h", 0)
        set(v) = putInt("ui_st_h", v)

    /** 0 = centro inferior, 1 = centro da tela, 2 = esquerda */
    var stPos: Int
        get() = int("ui_st_pos", 0)
        set(v) = putInt("ui_st_pos", v)
    var stAlpha: Int
        get() = int("ui_st_alpha", 95)
        set(v) = putInt("ui_st_alpha", v)
    var stRadius: Int
        get() = int("ui_st_radius", 12)
        set(v) = putInt("ui_st_radius", v)
    var stCols: Int
        get() = int("ui_st_cols", 4)
        set(v) = putInt("ui_st_cols", v)
    var stGlass: Boolean
        get() = bool("ui_st_glass", false)
        set(v) = putBool("ui_st_glass", v)

    // ---- aparência
    /** 0 = escuro, 1 = claro */
    var theme: Int
        get() = int("ui_theme", 0)
        set(v) = putInt("ui_theme", v)
    var accent: Int
        get() = int("ui_accent", 0xFF4CC2FF.toInt())
        set(v) = putInt("ui_accent", v)
    var pnAlpha: Int
        get() = int("ui_pn_alpha", 95)
        set(v) = putInt("ui_pn_alpha", v)
    var pnGlass: Boolean
        get() = bool("ui_pn_glass", false)
        set(v) = putBool("ui_pn_glass", v)
    var anim: Boolean
        get() = bool("ui_anim", true)
        set(v) = putBool("ui_anim", v)

    // ---- área de trabalho
    var dkIcon: Int
        get() = int("ui_dk_icon", 44)
        set(v) = putInt("ui_dk_icon", v)
    var dkShow: Boolean
        get() = bool("ui_dk_show", true)
        set(v) = putBool("ui_dk_show", v)

    // ---- mouse
    var cursorOn: Boolean
        get() = bool("ui_cursor_on", true)
        set(v) = putBool("ui_cursor_on", v)
    var cursorSize: Int
        get() = int("ui_cursor_size", 24)
        set(v) = putInt("ui_cursor_size", v)
    var menuHover: Boolean
        get() = bool("ui_menu_hover", true)
        set(v) = putBool("ui_menu_hover", v)
}
