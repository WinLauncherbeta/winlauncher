package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View

/**
 * Vidro fosco das janelas flutuantes da tela de bloqueio (clima e personalização).
 * O desfoque é real: o conteúdo da tela de bloqueio é capturado antes de a janela abrir e borrado com o
 * [Glass.makeBlur] já usado pelos outros painéis.
 */

/** Captura a tela de bloqueio ([host]) em 1/4 da resolução e borra. Null se a captura falhar. */
internal fun captureBlurredBackdrop(host: View): Bitmap? = try {
    val w = host.width
    val h = host.height
    val sw = maxOf(8, w / 4)
    val sh = maxOf(8, h / 4)
    val snap = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
    val c = Canvas(snap)
    c.scale(sw / w.toFloat(), sh / h.toFloat())
    host.draw(c)
    val out = Glass.makeBlur(snap, w, h)
    snap.recycle()
    out
} catch (t: Throwable) {
    null
}

/** Fundo borrado (na posição certa atrás de [view]) + película escura + brilho no topo + borda fina. */
internal class BackdropGlass(
    private val view: View,
    private val host: View,
    private var blur: Bitmap?,
    private val radius: Float,
    density: Float
) : Drawable() {
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density
        color = Color.parseColor("#4DFFFFFF")
    }
    private val clip = Path()
    private val rect = RectF()
    private val dst = Rect()

    init {
        // sem captura (falha rara) a película fica mais opaca para o texto continuar legível
        tintPaint.color = if (blur != null) Color.parseColor("#80101B2E") else Color.parseColor("#E6162338")
    }

    fun release() {
        blur = null
    }

    override fun onBoundsChange(b: Rect) {
        sheen.shader = LinearGradient(
            0f, 0f, 0f, b.height().toFloat(),
            Color.parseColor("#2EFFFFFF"), Color.parseColor("#05FFFFFF"), Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        val save = canvas.save()
        canvas.clipPath(clip)
        val bmp = blur
        if (bmp != null && !bmp.isRecycled) {
            // o instantâneo cobre a tela de bloqueio inteira; desloca para a posição atual da janela
            val s2 = canvas.save()
            canvas.translate(-(view.left + view.translationX), -(view.top + view.translationY))
            dst.set(0, 0, host.width, host.height)
            canvas.drawBitmap(bmp, null, dst, bmpPaint)
            canvas.restoreToCount(s2)
        }
        canvas.drawPaint(tintPaint)
        canvas.drawPaint(sheen)
        canvas.restoreToCount(save)
        val inset = border.strokeWidth / 2f
        rect.inset(inset, inset)
        canvas.drawRoundRect(rect, radius - inset, radius - inset, border)
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, radius)
        outline.alpha = 0.6f
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Fundo de item das janelas de vidro: [base], com realce ao passar o mouse e ao pressionar. */
internal fun glassItemBg(density: Float, radiusDp: Int, base: Int = Color.TRANSPARENT, stroke: Int = 0): Drawable {
    fun shape(c: Int) = android.graphics.drawable.GradientDrawable().apply {
        cornerRadius = radiusDp * density
        setColor(c)
        if (stroke != 0) setStroke((density + 0.5f).toInt(), stroke)
    }
    return android.graphics.drawable.StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), shape(Color.parseColor("#33FFFFFF")))
        addState(intArrayOf(android.R.attr.state_hovered), shape(Color.parseColor("#26FFFFFF")))
        addState(intArrayOf(), shape(base))
    }
}
