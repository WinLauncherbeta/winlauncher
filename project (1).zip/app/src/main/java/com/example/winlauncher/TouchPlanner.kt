package com.example.winlauncher

/**
 * Mapeador de gamepad (Etapa 1) - planejador de toques. Lógica pura (sem Android), testada numa JVM.
 *
 * Por que existe: o serviço de acessibilidade só consegue tocar a tela com dispatchGesture(). Um gesto que
 * começa NÃO pode ser alterado; para "segurar" um dedo, o toque é dividido em pedaços curtos ([chunkMs]) e cada
 * pedaço continua o anterior (stroke com willContinue). Além disso, um novo gesto cancela os dedos do gesto
 * anterior que não forem continuados, então TODO pedaço precisa trazer TODOS os dedos que ainda estão na tela.
 *
 * O planejador só decide QUAIS dedos entram em cada pedaço e se cada um começa, continua ou termina ali.
 * Quem converte em GestureDescription é o serviço. Tudo roda na thread principal (sem sincronização).
 *
 * Etapas seguintes usam a mesma estrutura: [Seg.fromX]/[Seg.toX] diferentes = dedo que se move no pedaço
 * (analógico virtual, câmera).
 */
class TouchPlanner(
    /** Duração de cada pedaço em ms (= atraso máximo para um toque novo entrar enquanto outro dedo está na tela). */
    /**
     * Etapa 5: é "var" porque o motor Shizuku (injeção direta) usa pedaços curtos e do tamanho real do intervalo entre ciclos.
     * Só mude com o planejador vazio (o serviço troca ao começar um toque novo).
     */
    var chunkMs: Long = 32L,
    /** Tempo mínimo que um dedo fica na tela, para o jogo perceber o toque. */
    val minTouchMs: Long = 45L,
    /** O Android aceita no máximo 10 dedos num gesto (GestureDescription.getMaxStrokeCount()). */
    val maxPointers: Int = 10
) {

    /** Um dedo dentro de um pedaço. [begin] = primeiro pedaço do toque; [end] = último (o dedo sai da tela no fim). */
    class Seg(
        val id: Int,
        val fromX: Float,
        val fromY: Float,
        val toX: Float,
        val toY: Float,
        val begin: Boolean,
        val end: Boolean
    )

    companion object {
        const val K_NORMAL = 0
        const val K_JOY = 1
        const val K_CAM = 2
        const val K_TURBO = 3
        const val K_MACRO = 4
    }

    /** Passo de macro já em pixels: toca em ([x],[y]) por [hold] ms e espera [wait] ms. */
    class MStep(val x: Float, val y: Float, val hold: Long, val wait: Long)

    private class Ptr(val id: Int, val kind: Int, val ox: Float, val oy: Float, val tap: Boolean, var downAt: Long) {
        /** Posição no FIM do último pedaço despachado (o próximo pedaço do mesmo dedo começa exatamente aqui). */
        var x = ox
        var y = oy

        /** Joystick: para onde o dedo deve ir no próximo pedaço. */
        var tx = ox
        var ty = oy

        /** Câmera: velocidade do dedo em px/s e raio (px) em que ele volta ao ponto de origem. */
        var vx = 0f
        var vy = 0f
        var rad = 0f

        /** Turbo: ciclo (ms) e hora do próximo toque. [waiting] = dedo fora da tela entre dois toques. */
        var period = 0L
        var nextDownAt = 0L
        var waiting = false

        var released = false
        var began = false

        /** Macro: passos, passo atual, se repete e se foi cancelada (app saiu da frente). */
        var steps: List<MStep> = emptyList()
        var idx = 0
        var loop = false
        var abort = false
    }

    // LinkedHashMap: a ordem de entrada dos dedos fica estável de um pedaço para o outro
    private val ptrs = LinkedHashMap<Int, Ptr>()

    /** Há algum dedo para colocar/manter na tela? */
    fun hasWork(): Boolean = ptrs.isNotEmpty()

    fun activeCount(): Int = ptrs.size

    fun isDown(id: Int): Boolean = ptrs.containsKey(id)

    /**
     * Aperta o botão [id] (qualquer número único por botão). [tap] = toque curto independente de soltar.
     * Devolve false se não coube (limite de dedos). Apertar de novo um botão que ainda está na tela só vale
     * para "segurar" que foi solto há pouco: ele volta a ficar apertado (o jogo nem chega a ver a soltura).
     */
    fun press(id: Int, x: Float, y: Float, tap: Boolean, now: Long): Boolean {
        val old = ptrs[id]
        if (old != null) {
            if (old.kind == K_NORMAL && !old.tap && old.released) {
                old.released = false
                return true
            }
            return false
        }
        if (ptrs.size >= maxPointers) return false
        ptrs[id] = Ptr(id, K_NORMAL, x, y, tap, now)
        return true
    }

    /** Etapa 3: joystick virtual. O dedo nasce em ([ox],[oy]) e anda até ([tx],[ty]); use [moveTo] para mover o alvo. */
    fun pressJoystick(id: Int, ox: Float, oy: Float, tx: Float, ty: Float, now: Long): Boolean {
        val old = ptrs[id]
        if (old != null) {
            if (old.kind == K_JOY && old.released) {
                old.released = false
                old.tx = tx
                old.ty = ty
                return true
            }
            return false
        }
        if (ptrs.size >= maxPointers) return false
        val p = Ptr(id, K_JOY, ox, oy, false, now)
        p.tx = tx
        p.ty = ty
        ptrs[id] = p
        return true
    }

    /** Etapa 3: câmera. O dedo só aparece quando há velocidade ([setVelocity]); ao passar de [radPx] ele volta à origem. */
    fun pressCamera(id: Int, ox: Float, oy: Float, radPx: Float, now: Long): Boolean {
        val old = ptrs[id]
        if (old != null) {
            if (old.kind == K_CAM && old.released) {
                old.released = false
                return true
            }
            return false
        }
        if (ptrs.size >= maxPointers) return false
        val p = Ptr(id, K_CAM, ox, oy, false, now)
        p.rad = radPx
        ptrs[id] = p
        return true
    }

    /** Etapa 3: turbo. Toca em ([x],[y]) de novo a cada [periodMs] enquanto não for solto. */
    fun pressTurbo(id: Int, x: Float, y: Float, periodMs: Long, now: Long): Boolean {
        val old = ptrs[id]
        if (old != null) {
            if (old.kind == K_TURBO && old.released) {
                old.released = false
                return true
            }
            return false
        }
        if (ptrs.size >= maxPointers) return false
        val p = Ptr(id, K_TURBO, x, y, false, now)
        p.period = periodMs
        ptrs[id] = p
        return true
    }

    /**
     * Etapa 3: macro. Toca os [steps] em ordem. [loop] = recomeça enquanto o botão estiver apertado; sem [loop] a
     * macro roda inteira uma vez, mesmo que o botão seja solto no meio.
     */
    fun pressMacro(id: Int, steps: List<MStep>, loop: Boolean, now: Long): Boolean {
        if (steps.isEmpty()) return false
        val old = ptrs[id]
        if (old != null) {
            if (old.kind == K_MACRO && old.released && old.loop && loop) {
                old.released = false
                return true
            }
            return false
        }
        if (ptrs.size >= maxPointers) return false
        val p = Ptr(id, K_MACRO, steps[0].x, steps[0].y, false, now)
        p.steps = steps
        p.loop = loop
        ptrs[id] = p
        return true
    }

    /** Joystick: novo alvo do dedo (a posição é lida no próximo pedaço). */
    fun moveTo(id: Int, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        p.tx = x
        p.ty = y
    }

    /** Câmera: velocidade do dedo em px/s (0,0 = parado: o dedo não fica na tela). */
    fun setVelocity(id: Int, vx: Float, vy: Float) {
        val p = ptrs[id] ?: return
        p.vx = vx
        p.vy = vy
    }

    /** Solta o botão [id]. O dedo sai da tela no fim do pedaço em que o tempo mínimo estiver cumprido. */
    fun release(id: Int) {
        ptrs[id]?.released = true
    }

    /** Solta tudo (app saiu da frente, serviço desligado...). Os dedos ainda saem de forma limpa, no próximo pedaço. */
    fun releaseAll() {
        for (p in ptrs.values) {
            p.released = true
            p.abort = true
            p.vx = 0f
            p.vy = 0f
        }
    }

    /** Esquece tudo sem mandar nada (gesto cancelado pelo Android: os dedos já não existem). */
    fun clear() {
        ptrs.clear()
    }

    /**
     * Em quantos ms vale tentar de novo quando [nextChunk] não trouxe nada mas ainda há trabalho (turbo entre dois
     * toques). -1 = não precisa acordar: o próximo pedaço vem da conclusão do gesto ou de um novo evento.
     */
    fun nextWakeDelay(now: Long): Long {
        var best = -1L
        for (p in ptrs.values) {
            if ((p.kind == K_TURBO || p.kind == K_MACRO) && p.waiting) {
                val dl = Math.max(1L, p.nextDownAt - now)
                if (best < 0L || dl < best) best = dl
            }
        }
        return best
    }

    /**
     * Monta o próximo pedaço, que começa em [now] e dura [chunkMs]. Quem chama DEVE despachar exatamente isso.
     * Devolve vazio se não há nada a fazer.
     */
    fun nextChunk(now: Long): List<Seg> {
        if (ptrs.isEmpty()) return emptyList()
        val out = ArrayList<Seg>(ptrs.size)
        val chunkEnd = now + chunkMs
        val dt = chunkMs / 1000f
        val it = ptrs.values.iterator()
        while (it.hasNext()) {
            val p = it.next()
            when (p.kind) {
                K_JOY -> {
                    val begin = !p.began
                    p.began = true
                    val end = p.released && (chunkEnd - p.downAt) >= minTouchMs
                    val toX = if (end) p.x else p.tx
                    val toY = if (end) p.y else p.ty
                    out.add(Seg(p.id, p.x, p.y, toX, toY, begin, end))
                    p.x = toX
                    p.y = toY
                    if (end) it.remove()
                }
                K_CAM -> {
                    if (p.released && !p.began) {
                        it.remove()
                        continue
                    }
                    var begin = false
                    if (!p.began) {
                        // sem dedo na tela: só nasce um novo quando há velocidade
                        if (p.vx == 0f && p.vy == 0f) continue
                        p.x = p.ox
                        p.y = p.oy
                        p.began = true
                        p.downAt = now
                        begin = true
                    }
                    val nx = p.x + p.vx * dt
                    val ny = p.y + p.vy * dt
                    val ddx = nx - p.ox
                    val ddy = ny - p.oy
                    val dist = Math.sqrt((ddx * ddx + ddy * ddy).toDouble()).toFloat()
                    val atEdge = p.rad > 0f && dist > p.rad
                    var toX = nx
                    var toY = ny
                    if (atEdge) {
                        val k = p.rad / dist
                        toX = p.ox + ddx * k
                        toY = p.oy + ddy * k
                    }
                    val durOk = (chunkEnd - p.downAt) >= minTouchMs
                    val end = (atEdge || p.released) && durOk
                    out.add(Seg(p.id, p.x, p.y, toX, toY, begin, end))
                    p.x = toX
                    p.y = toY
                    if (end) {
                        // o próximo pedaço (se ainda houver velocidade) recomeça na origem
                        p.began = false
                        if (p.released) it.remove()
                    }
                }
                K_TURBO -> {
                    if (p.waiting) {
                        if (p.released) {
                            it.remove()
                            continue
                        }
                        if (now < p.nextDownAt) continue
                        p.waiting = false
                        p.began = false
                        p.downAt = now
                    }
                    val begin = !p.began
                    p.began = true
                    val end = (chunkEnd - p.downAt) >= minTouchMs
                    out.add(Seg(p.id, p.x, p.y, p.x, p.y, begin, end))
                    if (end) {
                        if (p.released) {
                            it.remove()
                        } else {
                            p.waiting = true
                            p.nextDownAt = p.downAt + p.period
                        }
                    }
                }
                K_MACRO -> {
                    if (p.waiting) {
                        if (p.abort || (p.released && p.loop)) {
                            it.remove()
                            continue
                        }
                        if (now < p.nextDownAt) continue
                        p.waiting = false
                        p.began = false
                    }
                    if (!p.began && p.abort) {
                        it.remove()
                        continue
                    }
                    val st = p.steps[p.idx]
                    if (!p.began) {
                        p.x = st.x
                        p.y = st.y
                        p.downAt = now
                    }
                    val begin = !p.began
                    p.began = true
                    val end = (chunkEnd - p.downAt) >= Math.max(minTouchMs, st.hold)
                    out.add(Seg(p.id, p.x, p.y, p.x, p.y, begin, end))
                    if (end) {
                        val last = p.idx >= p.steps.size - 1
                        if (last && !(p.loop && !p.released && !p.abort)) {
                            it.remove()
                        } else {
                            p.idx = if (last) 0 else p.idx + 1
                            p.waiting = true
                            p.nextDownAt = chunkEnd + st.wait
                        }
                    }
                }
                else -> {
                    val begin = !p.began
                    p.began = true
                    val wantsEnd = p.tap || p.released
                    val end = wantsEnd && (chunkEnd - p.downAt) >= minTouchMs
                    out.add(Seg(p.id, p.x, p.y, p.x, p.y, begin, end))
                    if (end) it.remove()
                }
            }
        }
        return out
    }
}
