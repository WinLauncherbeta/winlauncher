package com.example.winlauncher

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import java.util.Random
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Janela flutuante "Configuração do PC": processador em destaque, RAM e armazenamento embaixo.
 * Todos os dados vêm de [HwInfo] (leitura real do aparelho) e são atualizados enquanto a janela
 * está visível e não minimizada.
 *
 * O launcher não possuía sistema de janelas (só painéis fixos), então esta janela é autônoma:
 * arrasta pela barra de título, minimiza (recolhe para a barra de título) e fecha.
 * Usa o [GlassDrawable] existente para o efeito de vidro.
 */
class PcInfoWindow(private val act: Activity, private val root: FrameLayout) {

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val NA = "Não disponível"
        private const val REFRESH_MS = 1500L
    }

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    private val d = act.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    /** Thread de leitura de hardware: só existe enquanto a janela está aberta. */
    private var worker: ExecutorService? = null

    /** Incrementa ao fechar; resultados de leituras antigas são descartados. */
    private var gen = 0

    private fun bg(task: () -> Unit) {
        val w = worker ?: Executors.newSingleThreadExecutor().also { worker = it }
        try {
            w.execute { task() }
        } catch (t: Throwable) {
        }
    }

    /** Avisado quando abre, minimiza, restaura ou fecha (a barra de tarefas se redesenha). */
    var onStateChange: (() -> Unit)? = null

    /** Janela existe (visível ou minimizada). Some da barra de tarefas só ao fechar. */
    val isOpen: Boolean get() = open

    val isMinimized: Boolean get() = minimized

    /** Última foto da janela (usada na janelinha da barra de tarefas quando ela está minimizada). */
    private var lastSnap: Bitmap? = null

    /** Miniatura da janela para a janelinha da barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap

    private var open = false

    private val ink = Color.parseColor("#F2F5FA")
    private val sub = Color.parseColor("#A9B3C6")
    private val accent = Color.parseColor("#3D9DFF")
    private val green = Color.parseColor("#14B88F")

    private lateinit var win: WindowView
    private lateinit var scroll: CappedScroll
    private lateinit var bottomRow: LinearLayout
    private lateinit var cpuBadge: View
    private lateinit var minBtn: ImageView
    private lateinit var cpuTitle: TextView
    private lateinit var cpuCode: TextView
    private lateinit var vVendor: TextView
    private lateinit var vCores: TextView
    private lateinit var vCur: TextView
    private lateinit var vMax: TextView
    private lateinit var chipArt: ChipArtView
    private lateinit var ramViews: UsageViews
    private lateinit var stoViews: UsageViews

    private var cpu: CpuStatic? = null
    private var cpuLoading = false
    private var minimized = false
    private var placed = false
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val g = gen
            bg {
                val live = HwInfo.cpuLive()
                val ram = HwInfo.ram(act)
                val sto = HwInfo.storage(act)
                win.post {
                    if (running && g == gen) {
                        applyLive(live)
                        applyUsage(ramViews, ram, false)
                        applyUsage(stoViews, sto, true)
                    }
                }
            }
            handler.postDelayed(this, REFRESH_MS)
        }
    }

    init {
        build()
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    // ================================================================== API pública

    /** Abre a janela; se já estiver aberta e minimizada, restaura. */
    fun show() {
        WindowStack.raise(root, layer, stackAbove)
        if (open) {
            if (minimized) restore()
            return
        }
        open = true
        minimized = false
        win.animate().cancel()
        sizeWindow()
        ensureStatic()
        startRefresh()
        showAnimated(true)
        onStateChange?.invoke()
    }

    /** Minimizar: oculta a janela por completo (nada fica na área de trabalho); estado preservado. */
    fun minimize() {
        if (!open || minimized) return
        lastSnap = snapView(win, 480)
        minimized = true
        stopRefresh()
        hideAnimated()
        onStateChange?.invoke()
    }

    /** Restaura a janela minimizada na posição e tamanho anteriores. */
    fun restore() {
        if (!open || !minimized) return
        minimized = false
        ensureStatic()
        startRefresh()
        showAnimated(false)
        onStateChange?.invoke()
    }

    /** Clique no ícone da barra de tarefas: restaura se minimizada, minimiza se estiver à frente. */
    fun toggleFromTaskbar() {
        when {
            minimized -> restore()
            !WindowStack.isTop(root, layer, stackAbove) -> WindowStack.raise(root, layer, stackAbove)
            else -> minimize()
        }
    }

    /** Fechar: encerra a janela e libera threads, callbacks, imagem e dados em cache. */
    fun close() {
        if (!open) return
        lastSnap = null
        open = false
        minimized = false
        stopRefresh()
        gen++
        worker?.shutdownNow()
        worker = null
        cpu = null
        cpuLoading = false
        placed = false
        hideAnimated()
        chipArt.setArt(null, "CPU", null, accent)
        resetViews()
        onStateChange?.invoke()
    }

    private fun showAnimated(first: Boolean) {
        WindowStack.raise(root, layer, stackAbove)
        win.animate().cancel()
        minBtn.background = btnBg(false, false)
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open || minimized) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    private fun hideAnimated() {
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            // só esconde se continuar minimizada/fechada (pode ter sido reaberta no meio da animação)
            if (!open || minimized) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    private fun resetViews() {
        cpuTitle.text = "Carregando…"
        cpuCode.visibility = View.GONE
        vVendor.text = "…"
        vCores.text = "…"
        vCur.text = "…"
        vMax.text = "…"
        for (v in listOf(ramViews, stoViews)) {
            v.value.text = valueText("…", "")
            v.bar.fraction = 0f
            v.total.text = "…"
            v.used.text = "…"
            v.free.text = "…"
        }
    }

    // ================================================================== atualização

    private fun startRefresh() {
        if (running) return
        running = true
        handler.post(tick)
    }

    private fun stopRefresh() {
        running = false
        handler.removeCallbacks(tick)
    }

    private fun ensureStatic() {
        if (cpu != null || cpuLoading) return
        cpuLoading = true
        val g = gen
        bg {
            val c = HwInfo.loadCpu()
            win.post {
                if (g != gen || !open) return@post
                cpu = c
                cpuLoading = false
                applyStatic(c)
            }
        }
    }

    private fun applyStatic(c: CpuStatic) {
        cpuTitle.text = c.title ?: NA
        cpuCode.text = c.code ?: ""
        cpuCode.visibility = if (c.code != null) View.VISIBLE else View.GONE
        vVendor.text = c.vendor ?: NA
        vCores.text = c.cores?.toString() ?: NA
        val b = brandOf(c.vendor)
        chipArt.setArt(findChipBitmap(c.vendor, c.model), b.label, c.model, b.color)
    }

    private fun applyLive(l: CpuLive) {
        vCur.text = l.curKHz?.let { HwInfo.fmtGhz(it) } ?: NA
        vMax.text = l.maxKHz?.let { HwInfo.fmtGhz(it) } ?: NA
    }

    private fun applyUsage(v: UsageViews, u: Usage?, decimal: Boolean) {
        if (u == null) {
            v.value.text = valueText(NA, "")
            v.bar.fraction = 0f
            v.total.text = NA
            v.used.text = NA
            v.free.text = NA
            return
        }
        val f: (Long) -> String = { b -> if (decimal) HwInfo.fmtDec(b) else HwInfo.fmtBin(b) }
        v.value.text = valueText(f(u.used), " / " + f(u.total) + " (" + u.pct + "%)")
        v.bar.fraction = u.pct / 100f
        v.total.text = f(u.total)
        v.used.text = f(u.used)
        v.free.text = f(u.avail)
    }

    private fun valueText(main: String, rest: String): CharSequence {
        val sb = SpannableStringBuilder()
        sb.append(main)
        sb.setSpan(AbsoluteSizeSpan(22, true), 0, main.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(ink), 0, main.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rest.isNotEmpty()) {
            val s = sb.length
            sb.append(rest)
            sb.setSpan(AbsoluteSizeSpan(13, true), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(sub), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    // ================================================================== imagem do chip

    private class Brand(val label: String, val color: Int)

    private fun brandOf(vendor: String?): Brand = when (vendor) {
        "Qualcomm" -> Brand("Snapdragon", Color.parseColor("#3253DC"))
        "MediaTek" -> Brand("MediaTek", Color.parseColor("#F2A900"))
        "Samsung" -> Brand("Exynos", Color.parseColor("#1E5BFF"))
        "Google" -> Brand("Tensor", Color.parseColor("#4285F4"))
        "HiSilicon" -> Brand("Kirin", Color.parseColor("#D0021B"))
        "UNISOC" -> Brand("UNISOC", Color.parseColor("#FF5A36"))
        null -> Brand("CPU", accent)
        else -> Brand(vendor, accent)
    }

    /**
     * Se existir um PNG em res/drawable-nodpi chamado chip_<modelo> (ex.: chip_sm6225) ou
     * chip_<fabricante> (ex.: chip_qualcomm), ele é usado. Caso contrário a janela desenha
     * uma ilustração de chip própria do fabricante detectado (ou genérica).
     */
    private fun findChipBitmap(vendor: String?, model: String?): Bitmap? {
        val keys = ArrayList<String>()
        model?.let { keys.add("chip_" + slug(it)) }
        vendor?.let { keys.add("chip_" + slug(it)) }
        for (k in keys) {
            val id = act.resources.getIdentifier(k, "drawable", act.packageName)
            if (id != 0) {
                try {
                    val bmp = BitmapFactory.decodeResource(act.resources, id)
                    if (bmp != null) return bmp
                } catch (t: Throwable) {
                }
            }
        }
        return null
    }

    private fun slug(s: String): String =
        s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_')

    // ================================================================== posição / tamanho

    private fun sizeWindow() {
        val rw = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
        val rh = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels
        val w = minOf(dp(860), rw - dp(24))
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        win.layoutParams = lp
        scroll.maxH = maxOf(dp(160), rh - dp(90))

        val narrow = w < dp(520)
        cpuBadge.visibility = if (narrow) View.GONE else View.VISIBLE
        chipArt.visibility = if (w < dp(420)) View.GONE else View.VISIBLE
        bottomRow.orientation = if (narrow) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        for (i in 0 until bottomRow.childCount) {
            val c = bottomRow.getChildAt(i)
            val clp = LinearLayout.LayoutParams(if (narrow) MATCH else 0, WRAP, if (narrow) 0f else 1f)
            clp.leftMargin = if (!narrow && i > 0) dp(10) else 0
            clp.topMargin = if (narrow && i > 0) dp(10) else 0
            c.layoutParams = clp
        }
    }

    private fun place() {
        if (!placed) {
            val rw = root.width.toFloat()
            val rh = root.height.toFloat()
            win.x = ((rw - win.width) / 2f).coerceAtLeast(dp(8).toFloat())
            win.y = ((rh - win.height) / 2f - dp(16)).coerceAtLeast(dp(8).toFloat())
            placed = true
        } else {
            moveTo(win.x, win.y)
        }
        win.invalidate()
    }

    private fun moveTo(nx: Float, ny: Float) {
        val minX = -(win.width - dp(96)).toFloat()
        val maxX = (root.width - dp(96)).toFloat()
        val maxY = (root.height - dp(48)).toFloat().coerceAtLeast(0f)
        win.x = nx.coerceIn(minX, maxOf(minX, maxX))
        win.y = ny.coerceIn(0f, maxY)
        // o vidro depende da posição na tela: força redesenho do fundo
        win.invalidate()
    }

    // ================================================================== construção da interface

    private fun cardBg(): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#12FFFFFF"))
        g.cornerRadius = dp(10).toFloat()
        g.setStroke(dp(1), Color.parseColor("#26FFFFFF"))
        return g
    }

    private fun build() {
        layer.tag = CursorController.NOHAND

        win = WindowView(act)
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.elevation = dp(16).toFloat()
        val winBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#111A33"), Color.parseColor("#0A0F1F"))
        )
        winBg.cornerRadius = dp(10).toFloat()
        winBg.setStroke(dp(1), Color.parseColor("#26FFFFFF"))
        win.background = winBg
        win.clipToOutline = true
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                outline.alpha = 0.6f
            }
        }

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(6), dp(14), dp(14))
        win.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        col.addView(buildTitleBar(), LinearLayout.LayoutParams(MATCH, dp(44)))

        val body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.addView(buildCpuCard(), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        bottomRow = LinearLayout(act)
        bottomRow.orientation = LinearLayout.HORIZONTAL
        val ram = buildUsageCard(R.drawable.ic_ram, "Memória RAM", accent)
        ramViews = ram.second
        val sto = buildUsageCard(R.drawable.ic_storage, "Armazenamento interno", green)
        stoViews = sto.second
        bottomRow.addView(ram.first, LinearLayout.LayoutParams(0, WRAP, 1f))
        bottomRow.addView(sto.first, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(10) })
        body.addView(bottomRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        val footer = LinearLayout(act)
        footer.orientation = LinearLayout.HORIZONTAL
        footer.gravity = Gravity.CENTER
        val fi = ImageView(act)
        fi.setImageResource(R.drawable.ic_refresh)
        fi.setColorFilter(sub)
        footer.addView(fi, LinearLayout.LayoutParams(dp(14), dp(14)))
        val ft = TextView(act)
        ft.text = "Informações atualizadas em tempo real"
        ft.setTextColor(sub)
        ft.textSize = 12f
        footer.addView(ft, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        body.addView(footer, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        scroll = CappedScroll(act)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP))

        layer.addView(win, FrameLayout.LayoutParams(dp(860), WRAP, Gravity.TOP or Gravity.START))
    }

    /** Insere a janela logo abaixo da camada do menu de contexto (o menu continua por cima). */
    private var stackAbove: View? = null

    fun attachBelow(menuLayer: View) {
        stackAbove = menuLayer
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildTitleBar(): View {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), 0, dp(2), 0)

        val ic = ImageView(act)
        ic.setImageResource(R.drawable.ic_pc)
        ic.setColorFilter(ink)
        bar.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))

        val t = TextView(act)
        t.text = "Configuração do PC"
        t.setTextColor(ink)
        t.textSize = 15f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })

        minBtn = titleButton(R.drawable.ic_minimize, false) { minimize() }
        bar.addView(minBtn, LinearLayout.LayoutParams(dp(36), dp(36)))
        bar.addView(titleButton(R.drawable.ic_close, true) { close() }, LinearLayout.LayoutParams(dp(36), dp(36)))

        var offX = 0f
        var offY = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                }
                MotionEvent.ACTION_MOVE -> moveTo(ev.rawX + offX, ev.rawY + offY)
            }
            true
        }
        return bar
    }

    private fun titleButton(res: Int, danger: Boolean, onClick: () -> Unit): ImageView {
        val b = ImageView(act)
        b.setImageResource(res)
        b.setColorFilter(ink)
        b.setPadding(dp(9), dp(9), dp(9), dp(9))
        b.isClickable = true
        b.background = btnBg(false, danger)
        b.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = btnBg(true, danger)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = btnBg(false, danger)
            }
            false
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun btnBg(hover: Boolean, danger: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(
            when {
                !hover -> Color.TRANSPARENT
                danger -> Color.parseColor("#40E5484D")
                else -> Color.parseColor("#26FFFFFF")
            }
        )
        g.cornerRadius = dp(8).toFloat()
        return g
    }

    private fun buildCpuCard(): View {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = cardBg()
        card.setPadding(dp(22), dp(20), dp(14), dp(20))
        card.minimumHeight = dp(200)

        val badge = FrameLayout(act)
        val bg = GradientDrawable()
        bg.setColor(withAlpha(accent, 34))
        bg.cornerRadius = dp(22).toFloat()
        bg.setStroke(dp(2), withAlpha(accent, 170))
        badge.background = bg
        val bi = ImageView(act)
        bi.setImageResource(R.drawable.ic_cpu)
        bi.setColorFilter(accent)
        badge.addView(bi, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        cpuBadge = badge
        card.addView(badge, LinearLayout.LayoutParams(dp(84), dp(84)).apply { rightMargin = dp(18) })

        val info = LinearLayout(act)
        info.orientation = LinearLayout.VERTICAL

        val label = TextView(act)
        label.text = "Processador"
        label.setTextColor(sub)
        label.textSize = 13f
        info.addView(label)

        cpuTitle = TextView(act)
        cpuTitle.text = "Carregando…"
        cpuTitle.setTextColor(ink)
        cpuTitle.textSize = 26f
        cpuTitle.typeface = Typeface.DEFAULT_BOLD
        cpuTitle.maxLines = 2
        info.addView(cpuTitle)

        cpuCode = TextView(act)
        cpuCode.setTextColor(sub)
        cpuCode.textSize = 12f
        cpuCode.visibility = View.GONE
        info.addView(cpuCode)

        vVendor = infoRow(info, R.drawable.ic_cpu, "Fabricante")
        vCores = infoRow(info, R.drawable.ic_cores, "Núcleos")
        vCur = infoRow(info, R.drawable.ic_speed, "Frequência atual")
        vMax = infoRow(info, R.drawable.ic_bolt, "Frequência máxima")

        card.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))

        chipArt = ChipArtView(act, d)
        card.addView(chipArt, LinearLayout.LayoutParams(dp(240), dp(190)))
        return card
    }

    private fun infoRow(parent: LinearLayout, icon: Int, label: String): TextView {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(act)
        iv.setImageResource(icon)
        iv.setColorFilter(sub)
        r.addView(iv, LinearLayout.LayoutParams(dp(18), dp(18)))
        val l = TextView(act)
        l.text = label
        l.setTextColor(sub)
        l.textSize = 13f
        l.maxLines = 1
        r.addView(l, LinearLayout.LayoutParams(dp(128), WRAP).apply { leftMargin = dp(10) })
        val v = TextView(act)
        v.text = NA
        v.setTextColor(ink)
        v.textSize = 14f
        v.maxLines = 1
        r.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        parent.addView(r, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(9) })
        return v
    }

    private class UsageViews(
        val value: TextView,
        val bar: UsageBar,
        val total: TextView,
        val used: TextView,
        val free: TextView
    )

    private fun buildUsageCard(icon: Int, title: String, color: Int): Pair<View, UsageViews> {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg()
        card.setPadding(dp(20), dp(20), dp(20), dp(18))

        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val box = FrameLayout(act)
        val bg = GradientDrawable()
        bg.setColor(withAlpha(color, 40))
        bg.cornerRadius = dp(14).toFloat()
        box.background = bg
        val iv = ImageView(act)
        iv.setImageResource(icon)
        iv.setColorFilter(color)
        box.addView(iv, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        top.addView(box, LinearLayout.LayoutParams(dp(46), dp(46)))

        val txt = LinearLayout(act)
        txt.orientation = LinearLayout.VERTICAL
        val tt = TextView(act)
        tt.text = title
        tt.setTextColor(ink)
        tt.textSize = 15f
        tt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tt.maxLines = 1
        txt.addView(tt)
        val value = TextView(act)
        value.text = valueText("…", "")
        txt.addView(value)
        top.addView(txt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        card.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val bar = UsageBar(act, color, d)
        card.addView(bar, LinearLayout.LayoutParams(MATCH, dp(10)).apply { topMargin = dp(14) })

        val stats = LinearLayout(act)
        stats.orientation = LinearLayout.HORIZONTAL
        val total = statCol(stats, "Total", false)
        val used = statCol(stats, "Utilizada", true)
        val free = statCol(stats, "Disponível", true)
        card.addView(stats, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        return Pair(card as View, UsageViews(value, bar, total, used, free))
    }

    private fun statCol(parent: LinearLayout, label: String, divider: Boolean): TextView {
        if (divider) {
            val dv = View(act)
            dv.setBackgroundColor(Color.parseColor("#26FFFFFF"))
            parent.addView(dv, LinearLayout.LayoutParams(dp(1), dp(30)).apply {
                leftMargin = dp(8)
                rightMargin = dp(8)
                gravity = Gravity.CENTER_VERTICAL
            })
        }
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        val l = TextView(act)
        l.text = label
        l.setTextColor(sub)
        l.textSize = 12f
        l.maxLines = 1
        c.addView(l)
        val v = TextView(act)
        v.text = NA
        v.setTextColor(ink)
        v.textSize = 15f
        v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        v.maxLines = 1
        c.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(3) })
        parent.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        return v
    }

    // ================================================================== views auxiliares

    private fun withAlpha(c: Int, a: Int): Int = (c and 0xFFFFFF) or (a.coerceIn(0, 255) shl 24)

    /** Janela: pausa a atualização quando o app sai da tela e retoma ao voltar. */
    private inner class WindowView(ctx: Context) : FrameLayout(ctx) {
        override fun onWindowVisibilityChanged(visibility: Int) {
            super.onWindowVisibilityChanged(visibility)
            if (visibility == View.VISIBLE) {
                if (open && !minimized) startRefresh()
            } else {
                stopRefresh()
            }
        }
    }

    /** ScrollView que respeita uma altura máxima (telas baixas). */
    private class CappedScroll(ctx: Context) : ScrollView(ctx) {
        var maxH = 100000

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }
    }

    private class UsageBar(ctx: Context, private val color: Int, private val d: Float) : View(ctx) {
        var fraction = 0f
            set(v) {
                field = v.coerceIn(0f, 1f)
                invalidate()
            }

        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        private fun mix(c: Int, t: Float): Int {
            val rr = Color.red(c) + ((255 - Color.red(c)) * t).toInt()
            val gg = Color.green(c) + ((255 - Color.green(c)) * t).toInt()
            val bb = Color.blue(c) + ((255 - Color.blue(c)) * t).toInt()
            return Color.rgb(rr, gg, bb)
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val rad = h / 2f
            p.shader = null
            p.color = Color.parseColor("#33FFFFFF")
            r.set(0f, 0f, w, h)
            c.drawRoundRect(r, rad, rad, p)
            if (fraction > 0f) {
                val fw = maxOf(w * fraction, h)
                p.shader = LinearGradient(0f, 0f, fw, 0f, mix(color, 0.35f), color, Shader.TileMode.CLAMP)
                r.set(0f, 0f, fw, h)
                c.drawRoundRect(r, rad, rad, p)
                p.shader = null
            }
        }
    }

    /**
     * Ilustração do processador. Desenha um chip com o fabricante/modelo detectados
     * (ou um chip genérico "CPU"), ou usa uma imagem fornecida em res/drawable.
     * As bordas esmaecem para integrar a arte ao cartão.
     */
    private class ChipArtView(ctx: Context, private val d: Float) : View(ctx) {
        private var bitmap: Bitmap? = null
        private var brand = "CPU"
        private var model: String? = null
        private var color = Color.parseColor("#3D9DFF")

        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val fade = PorterDuffXfermode(PorterDuff.Mode.DST_IN)

        fun setArt(bmp: Bitmap?, brand: String, model: String?, color: Int) {
            this.bitmap = bmp
            this.brand = brand
            this.model = model
            this.color = color
            invalidate()
        }

        private fun al(c: Int, a: Int): Int = (c and 0xFFFFFF) or (a.coerceIn(0, 255) shl 24)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val layer = c.saveLayer(0f, 0f, w, h, null)
            val b = bitmap
            if (b != null) drawBitmap(c, b, w, h) else drawChip(c, w, h)

            p.reset()
            p.isAntiAlias = true
            p.shader = RadialGradient(
                w / 2f, h / 2f, maxOf(w, h) * 0.62f,
                intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
                floatArrayOf(0f, 0.6f, 1f),
                Shader.TileMode.CLAMP
            )
            p.xfermode = fade
            c.drawRect(0f, 0f, w, h, p)
            p.xfermode = null
            p.shader = null
            c.restoreToCount(layer)
        }

        private fun drawBitmap(c: Canvas, b: Bitmap, w: Float, h: Float) {
            val sc = minOf(w / b.width, h / b.height) * 0.92f
            val bw = b.width * sc
            val bh = b.height * sc
            rect.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
            p.reset()
            p.isAntiAlias = true
            p.isFilterBitmap = true
            c.drawBitmap(b, null, rect, p)
        }

        private fun drawChip(c: Canvas, w: Float, h: Float) {
            val cx = w / 2f
            val cy = h / 2f
            val s = minOf(w, h) * 0.58f

            // trilhas de circuito ao fundo
            val rnd = Random(brand.hashCode().toLong())
            p.reset()
            p.isAntiAlias = true
            p.strokeWidth = d * 1.2f
            for (i in 0 until 14) {
                val y = h * (0.08f + 0.84f * i / 13f)
                val x0 = if (rnd.nextBoolean()) 0f else w * 0.12f
                val x1 = x0 + w * (0.22f + rnd.nextFloat() * 0.3f)
                p.style = Paint.Style.STROKE
                p.color = al(color, 70)
                c.drawLine(x0, y, x1, y, p)
                p.style = Paint.Style.FILL
                c.drawCircle(x1, y, d * 2f, p)
            }

            c.save()
            c.rotate(-16f, cx, cy)

            // brilho
            p.style = Paint.Style.STROKE
            for (i in 5 downTo 1) {
                p.strokeWidth = d * 2f * i
                p.color = al(color, 20)
                val g = i * d * 1.5f
                rect.set(cx - s / 2f - g, cy - s / 2f - g, cx + s / 2f + g, cy + s / 2f + g)
                c.drawRoundRect(rect, s * 0.1f + g, s * 0.1f + g, p)
            }

            // pinos
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#D3DCEA")
            val pins = 9
            val pw = s * 0.035f
            val pl = s * 0.07f
            val gap = s * 0.8f / (pins - 1)
            val l = cx - s / 2f
            val t = cy - s / 2f
            for (i in 0 until pins) {
                val x = cx - s * 0.4f + i * gap
                val y = cy - s * 0.4f + i * gap
                c.drawRect(x - pw / 2f, t - pl, x + pw / 2f, t + pl, p)
                c.drawRect(x - pw / 2f, t + s - pl, x + pw / 2f, t + s + pl, p)
                c.drawRect(l - pl, y - pw / 2f, l + pl, y + pw / 2f, p)
                c.drawRect(l + s - pl, y - pw / 2f, l + s + pl, y + pw / 2f, p)
            }

            // corpo
            rect.set(l, t, l + s, t + s)
            p.shader = LinearGradient(l, t, l + s, t + s, Color.parseColor("#3A4560"), Color.parseColor("#151B2B"), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, s * 0.08f, s * 0.08f, p)
            p.shader = null

            // die
            val ins = s * 0.14f
            rect.set(l + ins, t + ins, l + s - ins, t + s - ins)
            p.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, Color.parseColor("#4B5A7C"), Color.parseColor("#222B42"), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, s * 0.05f, s * 0.05f, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = d * 1.5f
            p.color = al(color, 210)
            c.drawRoundRect(rect, s * 0.05f, s * 0.05f, p)

            // textos
            val innerW = rect.width() * 0.88f
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = Color.WHITE
            p.textSize = s * 0.15f
            val bw = p.measureText(brand)
            if (bw > innerW) p.textSize = p.textSize * innerW / bw
            val m = model
            val brandY = if (m != null) cy - s * 0.01f else cy + p.textSize * 0.35f
            c.drawText(brand, cx, brandY, p)
            if (m != null) {
                p.typeface = Typeface.DEFAULT
                p.color = Color.parseColor("#C8D6F0")
                p.textSize = s * 0.085f
                val mw = p.measureText(m)
                if (mw > innerW) p.textSize = p.textSize * innerW / mw
                c.drawText(m, cx, cy + s * 0.14f, p)
            }
            c.restore()
        }
    }
}
