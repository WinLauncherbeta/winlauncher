package com.example.winlauncher

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.LruCache
import android.view.GestureDetector
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Galeria de fotos nativa do WinLauncher, no estilo do app Fotos do Windows 11.
 *
 * Janela autônoma igual às outras apps nativas (arrasta pela barra de título, minimiza para a barra de tarefas) com
 * três modos, como o navegador e o gerenciador de arquivos: janela (redimensiona pelo canto), maximizada (deixa a
 * barra de tarefas visível) e tela cheia.
 *
 * Duas telas:
 *  - grade de miniaturas (as fotos da pasta aberta, ou DCIM/Pictures quando aberta sem foto);
 *  - visualizador: zoom por pinça / roda do mouse / duplo toque, arrastar, passar para a próxima/anterior (setas,
 *    deslizar, setas do teclado), girar, compartilhar, abrir com outro app e excluir.
 *
 * O gerenciador de arquivos abre as fotos aqui ([openImage]) em vez de chamar o app de fotos do Android.
 */
@Suppress("DEPRECATION")
class GalleryWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    /** Espaço ocupado pela barra de tarefas em px: (topo, base). Usado no modo maximizado. */
    private val taskbarInsets: () -> Pair<Int, Int>
) {

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MODE_WINDOW = 0
        private const val MODE_MAX = 1
        private const val MODE_FULL = 2

        /** Lado maior (px) a partir do qual a foto é reduzida ao abrir no visualizador. */
        private const val FULL_DIM = 1920

        /** Lado maior (px) das miniaturas da grade. */
        private const val THUMB_DIM = 320
    }

    private class Loaded(val bmp: Bitmap, val w: Int, val h: Int)

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    /** Avisado quando abre, minimiza, restaura ou fecha (a barra de tarefas se redesenha). */
    var onStateChange: (() -> Unit)? = null

    val isOpen: Boolean get() = open
    val isMinimized: Boolean get() = minimized

    private var lastSnap: Bitmap? = null

    /** Miniatura da janela para a janelinha da barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val handler = Handler(Looper.getMainLooper())

    private val ink = Color.parseColor("#F2F2F2")
    private val sub = Color.parseColor("#A0A0A0")
    private val accent = Color.parseColor("#4CC2FF")
    private val cWin = Color.parseColor("#1C1C1C")
    private val cBar = Color.parseColor("#202020")
    private val cField = Color.parseColor("#2D2D2D")
    private val cView = Color.parseColor("#111111")
    private val cLine = Color.parseColor("#26FFFFFF")

    // ---- estado da janela
    private var open = false
    private var minimized = false
    private var placed = false
    private var mode = MODE_WINDOW
    private var modeBeforeFull = MODE_WINDOW
    private var normW = 0
    private var normH = 0
    private var normX = 0f
    private var normY = 0f
    private var active = false
    private var lastTitleTap = 0L

    // ---- estado da galeria
    private var images: List<File> = emptyList()
    private var index = 0
    private var viewing = false
    private var loadGen = 0

    @Volatile
    private var scanGen = 0
    private var scanning = false
    private var srcBmp: Bitmap? = null
    private var curBmp: Bitmap? = null
    private var rot = 0
    private var origW = 0
    private var origH = 0
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var dlgOk: (() -> Unit)? = null

    // ---- execução em segundo plano
    private var ioExec: ExecutorService? = null
    private var thumbExec: ExecutorService? = null
    private val thumbPending = HashSet<String>()
    private val thumbFail = HashSet<String>()
    private val thumbs = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun io(task: () -> Unit) {
        val e = ioExec ?: Executors.newFixedThreadPool(2).also { ioExec = it }
        try {
            e.execute { task() }
        } catch (t: Throwable) {
        }
    }

    // ---- views
    private lateinit var win: FrameLayout
    private lateinit var titleBar: LinearLayout
    private lateinit var titleText: TextView
    private var titleIcon: ImageView? = null
    private lateinit var maxBtn: ImageView
    private lateinit var fullBtn: ImageView
    private lateinit var toolbar: FrameLayout
    private lateinit var gridLabel: TextView
    private lateinit var viewTools: HorizontalScrollView
    private lateinit var zoomPct: TextView
    private lateinit var content: FrameLayout
    private lateinit var grid: GridView
    private lateinit var zoom: ZoomView
    private lateinit var prevBtn: ImageView
    private lateinit var nextBtn: ImageView
    private lateinit var msgBox: LinearLayout
    private lateinit var msgText: TextView
    private lateinit var msgBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var grip: View
    private lateinit var fsBar: LinearLayout
    private lateinit var dlgLayer: FrameLayout
    private val adapter = GridAdapter()

    init {
        build()
        setupDrop()
        root.addOnLayoutChangeListener { _, l, t, r, b, oL, oT, oR, oB ->
            if (open && !minimized && mode != MODE_WINDOW && (r - l != oR - oL || b - t != oB - oT)) {
                win.post { sizeWindow() }
            }
        }
    }

    // ================================================================== API pública

    /** Abre a galeria (ou restaura se minimizada). Sem foto específica, mostra as fotos de DCIM e Pictures. */
    fun show() {
        if (open) {
            if (minimized) restore()
            return
        }
        images = emptyList()
        openWindow()
        showGrid()
        scanDefault()
    }

    /** Abre o visualizador direto em [file]; [siblings] são as fotos ao redor (na ordem em que devem passar). */
    fun openImage(file: File, siblings: List<File>) {
        val list = ArrayList<File>()
        for (f in siblings) if (f.isFile) list.add(f)
        var i = list.indexOfFirst { it.absolutePath == file.absolutePath }
        if (i < 0) {
            list.add(0, file)
            i = 0
        }
        ++scanGen
        scanning = false
        images = list
        openWindow()
        adapter.notifyDataSetChanged()
        showViewer(i)
    }

    private fun openWindow() {
        if (open) {
            if (minimized) restore()
            return
        }
        open = true
        minimized = false
        win.animate().cancel()
        sizeWindow()
        showAnimated()
        onStateChange?.invoke()
    }

    fun minimize() {
        if (!open || minimized) return
        lastSnap = snapView(win, 480)
        minimized = true
        hideAnimated()
        onStateChange?.invoke()
    }

    fun restore() {
        if (!open || !minimized) return
        minimized = false
        sizeWindow()
        showAnimated()
        onStateChange?.invoke()
    }

    /** Clique no ícone da barra de tarefas: restaura se minimizada, minimiza se estiver à frente. */
    fun toggleFromTaskbar() {
        if (minimized) restore() else minimize()
    }

    /** Fecha a janela e libera threads, miniaturas e fotos. */
    fun close() {
        if (!open) return
        closeDialog()
        lastSnap = null
        open = false
        minimized = false
        mode = MODE_WINDOW
        active = false
        viewing = false
        ++loadGen
        ++scanGen
        scanning = false
        ioExec?.shutdownNow()
        ioExec = null
        thumbExec?.shutdownNow()
        thumbExec = null
        thumbPending.clear()
        thumbFail.clear()
        thumbs.evictAll()
        zoom.setBitmap(null)
        srcBmp = null
        curBmp = null
        images = emptyList()
        adapter.notifyDataSetChanged()
        placed = false
        normW = 0
        normH = 0
        hideAnimated()
        onStateChange?.invoke()
    }

    /** Botão voltar do Android: fecha diálogo, sai da tela cheia, volta do visualizador para a grade ou fecha. */
    fun handleBack(): Boolean {
        if (!open || minimized) return false
        if (dlgLayer.visibility == View.VISIBLE) {
            closeDialog()
            return true
        }
        if (mode == MODE_FULL) {
            setMode(modeBeforeFull)
            return true
        }
        if (viewing && images.size > 1) {
            showGrid()
            return true
        }
        close()
        return true
    }

    /** Atualiza o ícone da barra de título (depois de trocar o ícone da galeria). */
    fun refreshIcon() {
        titleIcon?.setImageDrawable(act.galleryIcon())
    }

    /** Insere a janela logo abaixo da camada do menu de contexto (o menu continua por cima). */
    fun attachBelow(menuLayer: View) {
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Atalhos do teclado físico (setas, +, -, 0, R, Delete, Esc, F11). Retorna true se consumiu. */
    fun handleKey(ev: KeyEvent): Boolean {
        if (!open || minimized || !active || ev.action != KeyEvent.ACTION_DOWN) return false
        if (dlgLayer.visibility == View.VISIBLE) {
            if (ev.keyCode == KeyEvent.KEYCODE_ESCAPE) {
                closeDialog()
                return true
            }
            if (ev.keyCode == KeyEvent.KEYCODE_ENTER || ev.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                val ok = dlgOk
                closeDialog()
                ok?.invoke()
                return true
            }
            return false
        }
        if (ev.keyCode == KeyEvent.KEYCODE_F11) {
            toggleFull()
            return true
        }
        if (ev.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (mode == MODE_FULL) setMode(modeBeforeFull) else if (viewing && images.size > 1) showGrid()
            return true
        }
        if (!viewing) return false
        when (ev.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_PAGE_UP -> {
                prev()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_SPACE -> {
                next()
                return true
            }
            KeyEvent.KEYCODE_MOVE_HOME -> {
                if (index > 0) showViewer(0)
                return true
            }
            KeyEvent.KEYCODE_MOVE_END -> {
                if (index < images.size - 1) showViewer(images.size - 1)
                return true
            }
            KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS, KeyEvent.KEYCODE_NUMPAD_ADD -> {
                zoom.zoomIn()
                return true
            }
            KeyEvent.KEYCODE_MINUS, KeyEvent.KEYCODE_NUMPAD_SUBTRACT -> {
                zoom.zoomOut()
                return true
            }
            KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> {
                zoom.fit()
                return true
            }
            KeyEvent.KEYCODE_R -> {
                rotate()
                return true
            }
            KeyEvent.KEYCODE_FORWARD_DEL, KeyEvent.KEYCODE_DEL -> {
                askDelete(index)
                return true
            }
        }
        return false
    }

    // ================================================================== animações

    private fun showAnimated() {
        win.animate().cancel()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open || minimized) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    private fun hideAnimated() {
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (!open || minimized) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    // ================================================================== modos / tamanho / posição

    private fun screenW(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun screenH(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    private fun setMode(m: Int) {
        if (m == mode) return
        if (m == MODE_FULL) modeBeforeFull = if (mode == MODE_FULL) MODE_WINDOW else mode
        if (mode == MODE_WINDOW) {
            normX = win.x
            normY = win.y
        }
        mode = m
        sizeWindow()
        place()
    }

    private fun toggleMax() {
        setMode(if (mode == MODE_MAX) MODE_WINDOW else MODE_MAX)
    }

    private fun toggleFull() {
        setMode(if (mode == MODE_FULL) modeBeforeFull else MODE_FULL)
    }

    private fun sizeWindow() {
        val sw = screenW()
        val sh = screenH()
        val ins = taskbarInsets()
        if (normW == 0) {
            normW = minOf(sw - dp(24), dp(900))
            normH = minOf(sh - ins.first - ins.second - dp(40), dp(600))
        }
        val w: Int
        val h: Int
        when (mode) {
            MODE_MAX -> {
                w = sw
                h = sh - ins.first - ins.second
            }
            MODE_FULL -> {
                w = sw
                h = sh
            }
            else -> {
                w = normW.coerceIn(minOf(dp(320), sw), sw)
                h = normH.coerceIn(minOf(dp(280), sh), sh)
            }
        }
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        lp.height = h
        win.layoutParams = lp
        applyModeStyle()
        win.post { onResized() }
    }

    private fun applyModeStyle() {
        val full = mode == MODE_FULL
        val r = if (mode == MODE_WINDOW) 10 else 0
        val bg = GradientDrawable()
        bg.setColor(cWin)
        bg.cornerRadius = dp(r).toFloat()
        bg.setStroke(if (mode == MODE_WINDOW) dp(1) else 0, cLine)
        win.background = bg
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
                outline.alpha = 0.6f
            }
        }
        win.invalidateOutline()
        // tela cheia: some só a barra de título; os dois botões flutuantes (restaurar e fechar) aparecem no canto
        titleBar.visibility = if (full) View.GONE else View.VISIBLE
        toolbar.setPadding(dp(6), 0, if (full) dp(84) else dp(6), 0)
        fsBar.visibility = if (full) View.VISIBLE else View.GONE
        grip.visibility = if (mode == MODE_WINDOW) View.VISIBLE else View.GONE
        maxBtn.setImageResource(if (mode == MODE_MAX) R.drawable.ic_restore else R.drawable.ic_maximize)
        fullBtn.setImageResource(R.drawable.ic_fullscreen)
    }

    private fun place() {
        when (mode) {
            MODE_MAX -> {
                win.x = 0f
                win.y = taskbarInsets().first.toFloat()
            }
            MODE_FULL -> {
                win.x = 0f
                win.y = 0f
            }
            else -> {
                if (!placed) {
                    normX = ((screenW() - win.width) / 2f).coerceAtLeast(dp(8).toFloat())
                    normY = ((screenH() - win.height) / 2f - dp(16)).coerceAtLeast(dp(8).toFloat())
                    placed = true
                }
                moveTo(normX, normY)
            }
        }
    }

    private fun moveTo(nx: Float, ny: Float) {
        if (mode != MODE_WINDOW) return
        val minX = -(win.width - dp(96)).toFloat()
        val maxX = (screenW() - dp(96)).toFloat()
        val maxY = (screenH() - dp(48)).toFloat().coerceAtLeast(0f)
        win.x = nx.coerceIn(minX, maxOf(minX, maxX))
        win.y = ny.coerceIn(0f, maxY)
        normX = win.x
        normY = win.y
    }

    /** A janela mudou de tamanho: a grade refaz as colunas. */
    private fun onResized() {
        if (!open) return
        val cols = (win.width / dp(130)).coerceAtLeast(2)
        if (grid.numColumns != cols) grid.numColumns = cols
        adapter.notifyDataSetChanged()
    }

    private fun toast(s: String) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    }

    private fun rr(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)

    // ================================================================== construção da janela

    private fun build() {
        layer.tag = CursorController.NOHAND
        layer.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) active = false
            false
        }

        // dispatchTouchEvent (e não um listener comum): o listener não dispara quando um filho consome o toque
        win = object : FrameLayout(act) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) active = true
                return super.dispatchTouchEvent(ev)
            }
        }
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.isFocusableInTouchMode = true
        win.elevation = dp(16).toFloat()
        win.clipToOutline = true

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        titleBar = buildTitleBar()
        col.addView(titleBar, lp(MATCH, dp(40)))
        toolbar = buildToolbar()
        col.addView(toolbar, lp(MATCH, dp(44)))
        val line = View(act)
        line.setBackgroundColor(cLine)
        col.addView(line, lp(MATCH, dp(1)))

        // ---- conteúdo: grade de miniaturas, visualizador e mensagens
        content = FrameLayout(act)
        content.setBackgroundColor(cView)
        col.addView(content, lp(MATCH, 0, 1f))

        grid = GridView(act)
        grid.numColumns = 4
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.horizontalSpacing = 0
        grid.verticalSpacing = 0
        grid.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        grid.cacheColorHint = Color.TRANSPARENT
        grid.overScrollMode = View.OVER_SCROLL_NEVER
        grid.setPadding(dp(4), dp(4), dp(4), dp(4))
        grid.clipToPadding = false
        grid.adapter = adapter
        content.addView(grid, FrameLayout.LayoutParams(MATCH, MATCH))

        zoom = ZoomView(act)
        zoom.visibility = View.GONE
        zoom.onScaleChanged = { updatePct() }
        content.addView(zoom, FrameLayout.LayoutParams(MATCH, MATCH))

        prevBtn = navButton(R.drawable.ic_arrow_left) { prev() }
        content.addView(prevBtn, FrameLayout.LayoutParams(dp(40), dp(64), Gravity.START or Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(6)
        })
        nextBtn = navButton(R.drawable.ic_arrow_right) { next() }
        content.addView(nextBtn, FrameLayout.LayoutParams(dp(40), dp(64), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(6)
        })

        msgBox = LinearLayout(act)
        msgBox.orientation = LinearLayout.VERTICAL
        msgBox.gravity = Gravity.CENTER
        msgBox.setPadding(dp(24), dp(24), dp(24), dp(24))
        msgBox.visibility = View.GONE
        msgText = TextView(act)
        msgText.setTextColor(sub)
        msgText.textSize = 14f
        msgText.gravity = Gravity.CENTER
        msgBox.addView(msgText, lp(WRAP, WRAP))
        msgBtn = TextView(act)
        msgBtn.setTextColor(Color.parseColor("#0B0B0B"))
        msgBtn.textSize = 13f
        msgBtn.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        msgBtn.setPadding(dp(18), dp(9), dp(18), dp(9))
        msgBtn.background = rr(accent, 6)
        msgBtn.isClickable = true
        msgBtn.visibility = View.GONE
        msgBox.addView(msgBtn, lp(WRAP, WRAP).apply { topMargin = dp(14) })
        content.addView(msgBox, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---- barra de status
        val line2 = View(act)
        line2.setBackgroundColor(cLine)
        col.addView(line2, lp(MATCH, dp(1)))
        val status = LinearLayout(act)
        status.orientation = LinearLayout.HORIZONTAL
        status.gravity = Gravity.CENTER_VERTICAL
        status.setBackgroundColor(cBar)
        status.setPadding(dp(12), 0, dp(32), 0)
        statusText = TextView(act)
        statusText.setTextColor(sub)
        statusText.textSize = 12f
        statusText.maxLines = 1
        statusText.ellipsize = TextUtils.TruncateAt.END
        status.addView(statusText, lp(0, WRAP, 1f))
        col.addView(status, lp(MATCH, dp(28)))

        // canto inferior direito: redimensionar (só no modo janela)
        grip = GripView(act)
        grip.visibility = View.GONE
        win.addView(grip, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))
        var sx = 0f
        var sy = 0f
        var sw0 = 0
        var sh0 = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX
                    sy = ev.rawY
                    sw0 = win.width
                    sh0 = win.height
                }
                MotionEvent.ACTION_MOVE -> {
                    normW = (sw0 + (ev.rawX - sx)).toInt().coerceIn(dp(320), maxOf(dp(320), screenW() - win.x.toInt()))
                    normH = (sh0 + (ev.rawY - sy)).toInt().coerceIn(dp(280), maxOf(dp(280), screenH() - win.y.toInt()))
                    sizeWindow()
                }
            }
            true
        }

        // tela cheia: só dois botões discretos no canto superior direito (voltar para janela e fechar)
        fsBar = LinearLayout(act)
        fsBar.orientation = LinearLayout.HORIZONTAL
        fsBar.background = rr(Color.parseColor("#8C000000"), 10)
        fsBar.alpha = 0.7f
        fsBar.visibility = View.GONE
        fsBar.addView(titleButton(R.drawable.ic_maximize, false) { setMode(MODE_MAX) }, lp(dp(34), dp(30)))
        fsBar.addView(titleButton(R.drawable.ic_close, true) { close() }, lp(dp(34), dp(30)))
        win.addView(fsBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4)
            rightMargin = dp(4)
        })

        // diálogo de confirmação (por cima de tudo, dentro da janela)
        dlgLayer = FrameLayout(act)
        dlgLayer.setBackgroundColor(Color.parseColor("#80000000"))
        dlgLayer.visibility = View.GONE
        dlgLayer.isClickable = true
        dlgLayer.setOnClickListener { closeDialog() }
        win.addView(dlgLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        layer.addView(win, FrameLayout.LayoutParams(dp(900), dp(600), Gravity.TOP or Gravity.START))

        applyModeStyle()
        updateNav()
    }

    private fun buildTitleBar(): LinearLayout {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(cBar)
        bar.setPadding(dp(10), 0, dp(4), 0)

        val ic = ImageView(act)
        ic.setImageDrawable(act.galleryIcon())
        titleIcon = ic
        bar.addView(ic, lp(dp(20), dp(20)))

        titleText = TextView(act)
        titleText.text = "Fotos"
        titleText.setTextColor(ink)
        titleText.textSize = 13f
        titleText.maxLines = 1
        titleText.ellipsize = TextUtils.TruncateAt.END
        titleText.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        bar.addView(titleText, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })

        bar.addView(titleButton(R.drawable.ic_minimize, false) { minimize() }, lp(dp(36), dp(34)))
        maxBtn = titleButton(R.drawable.ic_maximize, false) { toggleMax() }
        bar.addView(maxBtn, lp(dp(36), dp(34)))
        fullBtn = titleButton(R.drawable.ic_fullscreen, false) { toggleFull() }
        bar.addView(fullBtn, lp(dp(36), dp(34)))
        bar.addView(titleButton(R.drawable.ic_close, true) { close() }, lp(dp(36), dp(34)))

        var offX = 0f
        var offY = 0f
        var downX = 0f
        var downY = 0f
        var moved = false
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                    downX = ev.rawX
                    downY = ev.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(ev.rawX - downX) > dp(4) || Math.abs(ev.rawY - downY) > dp(4)) moved = true
                    moveTo(ev.rawX + offX, ev.rawY + offY)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastTitleTap < 350L) {
                            lastTitleTap = 0L
                            toggleMax()
                        } else {
                            lastTitleTap = now
                        }
                    }
                }
            }
            true
        }
        return bar
    }

    /** Barra de ferramentas: na grade mostra só o rótulo; no visualizador mostra os botões. */
    private fun buildToolbar(): FrameLayout {
        val bar = FrameLayout(act)
        bar.setBackgroundColor(cBar)
        bar.setPadding(dp(6), 0, dp(6), 0)

        gridLabel = TextView(act)
        gridLabel.setTextColor(ink)
        gridLabel.textSize = 14f
        gridLabel.gravity = Gravity.CENTER_VERTICAL
        gridLabel.setPadding(dp(8), 0, dp(8), 0)
        gridLabel.maxLines = 1
        gridLabel.ellipsize = TextUtils.TruncateAt.END
        gridLabel.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        bar.addView(gridLabel, FrameLayout.LayoutParams(MATCH, MATCH))

        viewTools = HorizontalScrollView(act)
        viewTools.isHorizontalScrollBarEnabled = false
        viewTools.overScrollMode = View.OVER_SCROLL_NEVER
        viewTools.visibility = View.GONE
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        viewTools.addView(row, FrameLayout.LayoutParams(WRAP, MATCH))

        row.addView(titleButton(R.drawable.ic_view, false, 8) { showGrid() }, lp(dp(38), dp(36)))
        row.addView(sep(), lp(dp(1), dp(20)).apply { leftMargin = dp(4); rightMargin = dp(4) })
        row.addView(titleButton(R.drawable.ic_arrow_left, false, 8) { prev() }, lp(dp(38), dp(36)))
        row.addView(titleButton(R.drawable.ic_arrow_right, false, 8) { next() }, lp(dp(38), dp(36)))
        row.addView(sep(), lp(dp(1), dp(20)).apply { leftMargin = dp(4); rightMargin = dp(4) })
        row.addView(titleButton(R.drawable.ic_minus, false, 9) { zoom.zoomOut() }, lp(dp(38), dp(36)))
        zoomPct = TextView(act)
        zoomPct.setTextColor(ink)
        zoomPct.textSize = 12.5f
        zoomPct.gravity = Gravity.CENTER
        zoomPct.minWidth = dp(54)
        zoomPct.isClickable = true
        zoomPct.background = rr(Color.TRANSPARENT, 8)
        zoomPct.setOnClickListener { zoom.fit() }
        row.addView(zoomPct, lp(WRAP, dp(36)))
        row.addView(titleButton(R.drawable.ic_plus, false, 9) { zoom.zoomIn() }, lp(dp(38), dp(36)))
        row.addView(sep(), lp(dp(1), dp(20)).apply { leftMargin = dp(4); rightMargin = dp(4) })
        row.addView(titleButton(R.drawable.ic_rotate, false, 9) { rotate() }, lp(dp(38), dp(36)))
        row.addView(titleButton(R.drawable.ic_fm_share, false, 9) { images.getOrNull(index)?.let { share(it) } }, lp(dp(38), dp(36)))
        row.addView(titleButton(R.drawable.ic_open, false, 9) { images.getOrNull(index)?.let { openWith(it) } }, lp(dp(38), dp(36)))
        row.addView(titleButton(R.drawable.ic_delete, false, 9) { askDelete(index) }, lp(dp(38), dp(36)))
        bar.addView(viewTools, FrameLayout.LayoutParams(MATCH, MATCH))
        return bar
    }

    private fun sep(): View {
        val v = View(act)
        v.setBackgroundColor(cLine)
        return v
    }

    private fun titleButton(res: Int, danger: Boolean, pad: Int = 9, onClick: () -> Unit): ImageView {
        val b = ImageView(act)
        b.setImageResource(res)
        b.setColorFilter(ink)
        b.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        b.isClickable = true
        b.background = btnBg(false, danger)
        b.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = btnBg(true, danger)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = btnBg(false, danger)
            }
            false
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun btnBg(hover: Boolean, danger: Boolean): GradientDrawable =
        rr(
            when {
                !hover -> Color.TRANSPARENT
                danger -> Color.parseColor("#40E5484D")
                else -> Color.parseColor("#26FFFFFF")
            },
            8
        )

    /** Setas grandes nas laterais do visualizador (mouse e toque). */
    private fun navButton(res: Int, onClick: () -> Unit): ImageView {
        val b = ImageView(act)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.setPadding(dp(10), dp(18), dp(10), dp(18))
        b.background = rr(Color.parseColor("#80000000"), 10)
        b.alpha = 0.8f
        b.isClickable = true
        b.visibility = View.GONE
        b.setOnClickListener { onClick() }
        return b
    }

    /** Alça de redimensionar: três tracinhos na diagonal. */
    private inner class GripView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            p.color = Color.parseColor("#80FFFFFF")
            p.strokeWidth = dp(1).toFloat()
            val w = width.toFloat()
            val h = height.toFloat()
            for (i in 1..3) {
                val o = dp(4 * i).toFloat()
                c.drawLine(w - o, h - dp(3), w - dp(3), h - o, p)
            }
        }
    }

    // ================================================================== telas: grade e visualizador

    private fun showGrid() {
        viewing = false
        ++loadGen
        closeDialog()
        zoom.setBitmap(null)
        srcBmp = null
        curBmp = null
        zoom.visibility = View.GONE
        grid.visibility = View.VISIBLE
        viewTools.visibility = View.GONE
        gridLabel.visibility = View.VISIBLE
        msgBox.visibility = View.GONE
        titleText.text = "Fotos"
        updateNav()
        updateGridInfo()
        adapter.notifyDataSetChanged()
        if (index in images.indices) grid.post { grid.setSelection(index) }
    }

    private fun updateGridInfo() {
        val n = images.size
        val folder = images.firstOrNull()?.parentFile?.name
        gridLabel.text = if (n == 0) "Galeria" else if (folder != null && !scanning && sameFolder()) folder else "Galeria"
        statusText.text = when {
            scanning -> "Procurando fotos…"
            n == 0 -> "Nenhuma foto"
            n == 1 -> "1 foto"
            else -> "$n fotos"
        }
        if (!viewing) {
            if (n == 0) {
                msgText.text = if (scanning) "Procurando fotos…" else "Nenhuma foto encontrada."
                msgBtn.visibility = View.GONE
                msgBox.visibility = View.VISIBLE
            } else {
                msgBox.visibility = View.GONE
            }
        }
    }

    private fun sameFolder(): Boolean {
        val p = images.firstOrNull()?.parentFile?.absolutePath ?: return false
        return images.all { it.parentFile?.absolutePath == p }
    }

    private fun showViewer(i: Int) {
        if (i !in images.indices) return
        index = i
        viewing = true
        rot = 0
        srcBmp = null
        curBmp = null
        origW = 0
        origH = 0
        zoom.setBitmap(null)
        grid.visibility = View.GONE
        zoom.visibility = View.VISIBLE
        gridLabel.visibility = View.GONE
        viewTools.visibility = View.VISIBLE
        msgBox.visibility = View.GONE
        titleText.text = images[i].name
        statusText.text = "Carregando…"
        zoomPct.text = ""
        updateNav()
        loadCurrent()
    }

    private fun prev() {
        if (viewing && index > 0) showViewer(index - 1)
    }

    private fun next() {
        if (viewing && index < images.size - 1) showViewer(index + 1)
    }

    private fun updateNav() {
        val show = viewing && images.size > 1
        prevBtn.visibility = if (show && index > 0) View.VISIBLE else View.GONE
        nextBtn.visibility = if (show && index < images.size - 1) View.VISIBLE else View.GONE
    }

    private fun loadCurrent() {
        val f = images[index]
        val g = ++loadGen
        io {
            val res = decodeFull(f)
            handler.post {
                if (g != loadGen || !open || !viewing) return@post
                if (res == null) {
                    showLoadError(f)
                } else {
                    srcBmp = res.bmp
                    origW = res.w
                    origH = res.h
                    applyRotation()
                }
            }
        }
    }

    private fun showLoadError(f: File) {
        zoom.setBitmap(null)
        msgText.text = if (f.exists()) "Não foi possível exibir esta imagem." else "Este arquivo não existe mais."
        if (f.exists()) {
            msgBtn.text = "Abrir com outro app"
            msgBtn.setOnClickListener { openWith(f) }
            msgBtn.visibility = View.VISIBLE
        } else {
            msgBtn.visibility = View.GONE
        }
        msgBox.visibility = View.VISIBLE
        statusText.text = "${index + 1} de ${images.size}"
        zoomPct.text = ""
    }

    private fun rotate() {
        if (srcBmp == null) return
        rot = (rot + 1) % 4
        applyRotation()
    }

    private fun applyRotation() {
        val s = srcBmp ?: return
        curBmp = if (rot == 0) s else try {
            val mx = Matrix()
            mx.postRotate(rot * 90f)
            Bitmap.createBitmap(s, 0, 0, s.width, s.height, mx, true)
        } catch (e: Throwable) {
            s
        }
        zoom.setBitmap(curBmp)
        updateInfo()
        updatePct()
    }

    private fun updateInfo() {
        val f = images.getOrNull(index) ?: return
        val parts = ArrayList<String>()
        parts.add("${index + 1} de ${images.size}")
        if (origW > 0 && origH > 0) parts.add(if (rot % 2 == 0) "$origW × $origH" else "$origH × $origW")
        parts.add(FileOps.fmtSize(f.length()))
        parts.add(FileOps.fmtDate(f.lastModified()))
        statusText.text = parts.joinToString("   •   ")
        titleText.text = f.name
    }

    private fun updatePct() {
        val b = curBmp
        if (!viewing || b == null) {
            zoomPct.text = ""
            return
        }
        val ow = if (rot % 2 == 0) origW else origH
        val ratio = if (ow > 0) b.width.toFloat() / ow else 1f
        zoomPct.text = "${Math.round(zoom.currentScale() * ratio * 100f)}%"
    }

    // ================================================================== leitura das fotos

    private fun exifOrientation(f: File): Int = try {
        ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } catch (e: Throwable) {
        ExifInterface.ORIENTATION_NORMAL
    }

    private fun applyExif(b: Bitmap, o: Int): Bitmap {
        val mx = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> mx.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> mx.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> mx.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> mx.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> mx.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                mx.postRotate(90f)
                mx.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                mx.postRotate(270f)
                mx.postScale(-1f, 1f)
            }
            else -> return b
        }
        return try {
            val nb = Bitmap.createBitmap(b, 0, 0, b.width, b.height, mx, true)
            if (nb != b) b.recycle()
            nb
        } catch (e: Throwable) {
            b
        }
    }

    /** Lê a foto reduzida (lado maior entre [target] e 2×[target]) já com a rotação do EXIF aplicada. */
    private fun decode(f: File, target: Int): Loaded? {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var s = 1
            val big = maxOf(o.outWidth, o.outHeight)
            while (big / (s * 2) >= target) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val b = BitmapFactory.decodeFile(f.absolutePath, o2) ?: return null
            val ori = exifOrientation(f)
            val swap = ori == ExifInterface.ORIENTATION_ROTATE_90 || ori == ExifInterface.ORIENTATION_ROTATE_270 ||
                ori == ExifInterface.ORIENTATION_TRANSPOSE || ori == ExifInterface.ORIENTATION_TRANSVERSE
            val ow = if (swap) o.outHeight else o.outWidth
            val oh = if (swap) o.outWidth else o.outHeight
            return Loaded(applyExif(b, ori), ow, oh)
        } catch (e: Throwable) {
            return null
        }
    }

    private fun decodeFull(f: File): Loaded? = decode(f, FULL_DIM)

    private fun requestThumb(f: File) {
        val key = f.absolutePath
        if (key in thumbFail || !thumbPending.add(key)) return
        val e = thumbExec ?: Executors.newFixedThreadPool(3).also { thumbExec = it }
        try {
            e.execute {
                val r = decode(f, THUMB_DIM)
                handler.post {
                    thumbPending.remove(key)
                    if (!open) return@post
                    if (r == null) {
                        thumbFail.add(key)
                        return@post
                    }
                    thumbs.put(key, r.bmp)
                    for (i in 0 until grid.childCount) {
                        val c = grid.getChildAt(i) as? Cell ?: continue
                        if (c.path == key) c.iv.setImageBitmap(r.bmp)
                    }
                }
            }
        } catch (t: Throwable) {
            thumbPending.remove(key)
        }
    }

    // ---- arrastar e soltar

    private fun setupDrop() {
        DragDrop.register(act, root, DragDrop.Target(
            layer = layer,
            win = win,
            accepts = { true },
            drop = { p, _, _ -> onDropped(p) }
        ))
    }

    private fun beginDrag(pos: Int, x: Float, y: Float, menuOnTap: Boolean): Boolean {
        val f = images.getOrNull(pos) ?: return false
        return DragDrop.start(act, layer, listOf(DragDrop.Item(f.name, file = f)), this, x, y) { dropped, moved ->
            if (menuOnTap && !dropped && !moved && open) itemMenu(pos, x.toInt(), y.toInt())
        }
    }

    /** Recebe fotos do gerenciador, do navegador (imagens) ou de outros apps e guarda em Pictures. */
    private fun onDropped(p: DragDrop.Payload): Boolean {
        if (p.source === this) return false
        val list = p.items.filter { it.url != null || FKind.of(it.name, false) == FKind.IMAGE }
        if (list.isEmpty()) {
            toast("Só dá para soltar fotos aqui.")
            return false
        }
        val dir = try {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        } catch (t: Throwable) {
            File(Environment.getExternalStorageDirectory(), "Pictures")
        }
        toast("Salvando em Imagens…")
        DragDrop.saveAll(act, list, dir) { saved, errors ->
            // endereço da web que não era imagem: descarta
            val imgs = ArrayList<File>()
            var bad = errors
            for (f in saved) {
                if (FKind.of(f.name, false) == FKind.IMAGE) imgs.add(f) else {
                    f.delete()
                    bad++
                }
            }
            if (open && imgs.isNotEmpty() && !viewing) {
                images = imgs + images
                adapter.notifyDataSetChanged()
                updateGridInfo()
            }
            toast(
                when {
                    imgs.isEmpty() -> "Não foi possível salvar."
                    bad == 0 -> imgs.size.toString() + " foto(s) salva(s)."
                    else -> imgs.size.toString() + " salva(s), " + bad + " com erro."
                }
            )
        }
        return true
    }

    // ---- fotos de DCIM e Pictures (quando a galeria abre sem uma foto específica)

    private fun scanDefault() {
        val g = ++scanGen
        scanning = true
        updateGridInfo()
        io {
            val out = ArrayList<File>()
            val roots = ArrayList<File>()
            try {
                roots.add(File(Environment.getExternalStorageDirectory(), "DCIM"))
                roots.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES))
            } catch (e: Throwable) {
            }
            for (r in roots) walk(r, 0, out, g)
            out.sortByDescending { it.lastModified() }
            handler.post {
                if (g != scanGen || !open) return@post
                scanning = false
                images = out
                adapter.notifyDataSetChanged()
                if (!viewing) updateGridInfo()
            }
        }
    }

    private fun walk(dir: File, depth: Int, out: ArrayList<File>, g: Int) {
        if (depth > 4 || out.size >= 5000 || g != scanGen) return
        val l = dir.listFiles() ?: return
        for (f in l) {
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) walk(f, depth + 1, out, g)
            else if (FKind.of(f.name, false) == FKind.IMAGE) out.add(f)
        }
    }

    // ================================================================== ações

    private fun share(f: File) {
        try {
            val u = FileShareProvider.uriFor(act, f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = FKind.mime(f.name)
            i.putExtra(Intent.EXTRA_STREAM, u)
            i.clipData = ClipData.newRawUri("", u)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(i, "Compartilhar"))
        } catch (e: ActivityNotFoundException) {
            toast("Nenhum app encontrado para compartilhar.")
        } catch (e: Exception) {
            toast("Não foi possível compartilhar.")
        }
    }

    private fun openWith(f: File) {
        try {
            val u = FileShareProvider.uriFor(act, f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(u, FKind.mime(f.name))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i.clipData = ClipData.newRawUri("", u)
            act.startActivity(Intent.createChooser(i, "Abrir com"))
        } catch (e: ActivityNotFoundException) {
            toast("Nenhum app encontrado para abrir este arquivo.")
        } catch (e: Exception) {
            toast("Não foi possível abrir o arquivo.")
        }
    }

    private fun askDelete(i: Int) {
        val f = images.getOrNull(i) ?: return
        confirm("Excluir foto", "“${f.name}” será excluída permanentemente.", "Excluir") {
            val ok = try {
                f.delete()
            } catch (e: Exception) {
                false
            }
            if (!ok) {
                toast("Não foi possível excluir.")
                return@confirm
            }
            thumbs.remove(f.absolutePath)
            val l = ArrayList<File>(images)
            l.removeAt(i)
            images = l
            adapter.notifyDataSetChanged()
            act.filesRefresh()
            when {
                images.isEmpty() -> showGrid()
                viewing -> showViewer(minOf(i, images.size - 1))
                else -> updateGridInfo()
            }
        }
    }

    private fun itemMenu(i: Int, x: Int, y: Int) {
        val f = images.getOrNull(i) ?: return
        val items = ArrayList<MenuItem>()
        if (!viewing) items.add(MenuItem("Abrir", R.drawable.ic_open, action = { showViewer(i) }))
        items.add(MenuItem("Compartilhar", R.drawable.ic_fm_share, action = { share(f) }))
        items.add(MenuItem("Abrir com…", R.drawable.ic_open, action = { openWith(f) }))
        if (viewing) {
            items.add(MenuItem("Girar", R.drawable.ic_rotate, action = { rotate() }))
            items.add(MenuItem("Ajustar à janela", R.drawable.ic_fullscreen, action = { zoom.fit() }))
        }
        items.add(MenuItem("Excluir", R.drawable.ic_delete, action = { askDelete(i) }))
        act.menu.show(items, x, y)
    }

    // ---- diálogo simples de confirmação

    private fun confirm(title: String, body: String, okLabel: String, onOk: () -> Unit) {
        dlgLayer.removeAllViews()
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = rr(cBar, 10)
        card.setPadding(dp(20), dp(18), dp(20), dp(16))
        card.isClickable = true
        val t = TextView(act)
        t.text = title
        t.setTextColor(ink)
        t.textSize = 15f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        card.addView(t, lp(MATCH, WRAP))
        val b = TextView(act)
        b.text = body
        b.setTextColor(sub)
        b.textSize = 13.5f
        card.addView(b, lp(MATCH, WRAP).apply { topMargin = dp(8) })
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        row.addView(dlgButton("Cancelar", false) { closeDialog() }, lp(WRAP, WRAP))
        row.addView(dlgButton(okLabel, true) {
            closeDialog()
            onOk()
        }, lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        card.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(18) })
        dlgLayer.addView(card, FrameLayout.LayoutParams(minOf(dp(340), maxOf(dp(200), win.width - dp(32))), WRAP, Gravity.CENTER))
        dlgOk = onOk
        dlgLayer.visibility = View.VISIBLE
    }

    private fun dlgButton(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val v = TextView(act)
        v.text = text
        v.textSize = 13.5f
        v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        v.setTextColor(if (primary) Color.parseColor("#0B0B0B") else ink)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(18), dp(9), dp(18), dp(9))
        v.background = rr(if (primary) accent else cField, 6)
        v.isClickable = true
        v.setOnClickListener { onClick() }
        return v
    }

    private fun closeDialog() {
        if (!::dlgLayer.isInitialized) return
        dlgLayer.visibility = View.GONE
        dlgLayer.removeAllViews()
        dlgOk = null
    }

    // ================================================================== grade de miniaturas

    private inner class GridAdapter : BaseAdapter() {
        override fun getCount(): Int = images.size
        override fun getItem(position: Int): Any = images[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cell = (convertView as? Cell) ?: Cell(act)
            cell.bind(position)
            return cell
        }
    }

    /** Célula quadrada da grade. */
    private inner class Cell(ctx: Context) : FrameLayout(ctx) {
        val iv = ImageView(ctx)
        var pos = -1
        var path: String? = null
        private var dragged = false
        private var downX = 0f
        private var downY = 0f

        init {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.background = rr(cField, 4)
            addView(iv, FrameLayout.LayoutParams(MATCH, MATCH).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            })
            isClickable = true
            setOnClickListener { if (pos >= 0) showViewer(pos) }
            setOnLongClickListener {
                if (pos >= 0) {
                    if (!beginDrag(pos, lastRawX, lastRawY, true)) itemMenu(pos, lastRawX.toInt(), lastRawY.toInt())
                    true
                } else {
                    false
                }
            }
            setOnTouchListener { _, ev ->
                lastRawX = ev.rawX
                lastRawY = ev.rawY
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                    dragged = false
                    downX = ev.rawX
                    downY = ev.rawY
                } else if (ev.actionMasked == MotionEvent.ACTION_MOVE && !dragged && pos >= 0 &&
                    ev.isFromSource(InputDevice.SOURCE_MOUSE) && (ev.buttonState and MotionEvent.BUTTON_PRIMARY) != 0
                ) {
                    val slop = android.view.ViewConfiguration.get(ctx).scaledTouchSlop
                    if (Math.abs(ev.rawX - downX) > slop || Math.abs(ev.rawY - downY) > slop) {
                        dragged = true
                        beginDrag(pos, ev.rawX, ev.rawY, false)
                    }
                }
                if (ev.actionMasked == MotionEvent.ACTION_DOWN && pos >= 0 &&
                    ev.isFromSource(InputDevice.SOURCE_MOUSE) && (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
                ) {
                    itemMenu(pos, ev.rawX.toInt(), ev.rawY.toInt())
                    true
                } else {
                    false
                }
            }
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            super.onMeasure(widthMeasureSpec, widthMeasureSpec)
        }

        fun bind(p: Int) {
            pos = p
            val f = images.getOrNull(p)
            if (f == null) {
                path = null
                iv.setImageDrawable(null)
                return
            }
            path = f.absolutePath
            val b = thumbs.get(f.absolutePath)
            if (b != null) {
                iv.setImageBitmap(b)
            } else {
                iv.setImageDrawable(null)
                requestThumb(f)
            }
        }
    }

    // ================================================================== visualizador com zoom

    private inner class ZoomView(ctx: Context) : View(ctx) {
        private val m = Matrix()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val vals = FloatArray(9)
        private val rect = RectF()
        private var bmp: Bitmap? = null
        private var fitScale = 1f
        private var ignoreGesture = false

        var onScaleChanged: (() -> Unit)? = null

        private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoomBy(detector.scaleFactor, detector.focusX, detector.focusY)
                return true
            }
        })

        private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaler.isInProgress) return false
                if (zoomed()) {
                    m.postTranslate(-distanceX, -distanceY)
                    clamp()
                    invalidate()
                }
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (!zoomed() && Math.abs(velocityX) > Math.abs(velocityY) * 1.5f && Math.abs(velocityX) > dp(500)) {
                    if (velocityX < 0) next() else prev()
                    return true
                }
                return false
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleZoom(e.x, e.y)
                return true
            }
        })

        fun setBitmap(b: Bitmap?) {
            bmp = b
            fit()
        }

        fun currentScale(): Float {
            m.getValues(vals)
            return vals[Matrix.MSCALE_X]
        }

        private fun zoomed(): Boolean = currentScale() > fitScale * 1.02f

        private fun maxScale(): Float = maxOf(fitScale * 8f, 4f)

        /** Ajusta a foto inteira dentro da janela. */
        fun fit() {
            val b = bmp
            m.reset()
            if (b != null && width > 0 && height > 0) {
                fitScale = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
                m.postScale(fitScale, fitScale)
                m.postTranslate((width - b.width * fitScale) / 2f, (height - b.height * fitScale) / 2f)
            }
            invalidate()
            onScaleChanged?.invoke()
        }

        fun zoomIn() = zoomBy(1.25f, width / 2f, height / 2f)

        fun zoomOut() = zoomBy(0.8f, width / 2f, height / 2f)

        private fun zoomBy(factor: Float, fx: Float, fy: Float) {
            if (bmp == null) return
            val cur = currentScale()
            val target = (cur * factor).coerceIn(fitScale, maxScale())
            val f = target / cur
            if (f == 1f) return
            m.postScale(f, f, fx, fy)
            clamp()
            invalidate()
            onScaleChanged?.invoke()
        }

        private fun toggleZoom(x: Float, y: Float) {
            if (bmp == null) return
            if (zoomed()) {
                fit()
            } else {
                val target = maxOf(fitScale * 2.5f, 1f).coerceAtMost(maxScale())
                zoomBy(target / currentScale(), x, y)
            }
        }

        /** Mantém a foto dentro da janela (centralizada quando menor que ela). */
        private fun clamp() {
            val b = bmp ?: return
            rect.set(0f, 0f, b.width.toFloat(), b.height.toFloat())
            m.mapRect(rect)
            var dx = 0f
            var dy = 0f
            if (rect.width() <= width) {
                dx = (width - rect.width()) / 2f - rect.left
            } else if (rect.left > 0) {
                dx = -rect.left
            } else if (rect.right < width) {
                dx = width - rect.right
            }
            if (rect.height() <= height) {
                dy = (height - rect.height()) / 2f - rect.top
            } else if (rect.top > 0) {
                dy = -rect.top
            } else if (rect.bottom < height) {
                dy = height - rect.bottom
            }
            m.postTranslate(dx, dy)
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            fit()
        }

        override fun onDraw(c: Canvas) {
            val b = bmp ?: return
            c.drawBitmap(b, m, paint)
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                ignoreGesture = false
                if (ev.isFromSource(InputDevice.SOURCE_MOUSE) && (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                    ignoreGesture = true
                    itemMenu(index, ev.rawX.toInt(), ev.rawY.toInt())
                    return true
                }
            }
            if (ignoreGesture || bmp == null) return true
            scaler.onTouchEvent(ev)
            detector.onTouchEvent(ev)
            return true
        }

        // roda do mouse = zoom no ponto do cursor
        override fun onGenericMotionEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_SCROLL && bmp != null) {
                val v = ev.getAxisValue(MotionEvent.AXIS_VSCROLL)
                zoomBy(Math.pow(1.18, v.toDouble()).toFloat(), ev.x, ev.y)
                return true
            }
            return super.onGenericMotionEvent(ev)
        }
    }
}
