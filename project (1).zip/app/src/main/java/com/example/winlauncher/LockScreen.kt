package com.example.winlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.format.DateFormat
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.os.SystemClock
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tela de bloqueio INTERNA do WinLauncher (não substitui a segurança do Android).
 *
 * Fica por cima de toda a tela (no root), cobrindo também a barra de tarefas.
 * Nesta etapa é só a estrutura: os "slots" abaixo existem vazios, prontos para receber
 * relógio, data, previsão do tempo e papel de parede nas próximas partes.
 *
 * Animações (~400 ms, curva suave, sem tela preta):
 *  - abrir:  desktop some (fade) + bloqueio entra com fade-in e leve zoom (1.04 -> 1.0)
 *  - fechar: bloqueio sai com fade-out e leve zoom (1.0 -> 1.04) + desktop volta (fade, 0.98 -> 1.0)
 * Usa ViewPropertyAnimator: não bloqueia a UI e pode ser interrompida a qualquer momento.
 */
class LockScreen(
    ctx: Context,
    private val prefs: SharedPreferences,
    private val desktopViews: () -> List<View>,
    /** Pede a permissão de localização aproximada (a MainActivity decide se ainda precisa perguntar). */
    private val onNeedLocation: () -> Unit,
    /** Pede ao Android o seletor de arquivos para importar imagem/GIF/vídeo para a galeria desta tela de bloqueio. */
    private val onPickWallpaperFile: () -> Unit,
    /** Botão direito em área vazia: a MainActivity mostra o menu de contexto nessas coordenadas de tela. */
    private val onContextMenu: (Int, Int) -> Unit
) : FrameLayout(ctx) {

    companion object {
        const val DURATION_MS = 400L
        private const val ZOOM_LOCK = 1.04f
        private const val ZOOM_DESKTOP = 0.98f

        private val PT_BR = Locale("pt", "BR")
        private const val LOCK_WX_KEY = "lockWxJson"
        private const val WX_STALE_MS = 60 * 60 * 1000L // acima de 1 h: marcado como desatualizado
        private const val WX_OK_RETRY_MS = 15 * 60 * 1000L
        private const val WX_FAIL_RETRY_MS = 2 * 60 * 1000L
        private const val WHITE = Color.WHITE
    }

    /** Papel de parede da tela de bloqueio. Fica atrás de todo o resto. */
    val wallpaperSlot = FrameLayout(ctx)

    /** Escolha salva + arquivos importados da galeria (tudo no espaço privado do app, nada no sistema Android). */
    private val wallpaperStore = LockWallpaperStore(ctx, prefs)

    /** Desenha o papel de parede escolhido (estático, animado ou vídeo em loop) dentro de [wallpaperSlot]. */
    private val wallpaperView = LockWallpaperView(ctx, wallpaperStore)

    /** Relógio e data (Parte futura). */
    val clockSlot = FrameLayout(ctx)
    val dateSlot = FrameLayout(ctx)

    /** Previsão do tempo (Parte futura). */
    val weatherSlot = FrameLayout(ctx)

    /** Player de música (capa, nome, voltar/pausar/avançar). Começa fora da tela; o usuário adiciona pela personalização. */
    val musicWidget = MusicWidget(ctx)

    /** Aberta (ou abrindo). Fica false assim que o fechamento começa. */
    var isOpen = false
        private set

    private val ease = PathInterpolator(0.2f, 0f, 0f, 1f) // desacelera suave no fim

    init {
        visibility = View.GONE
        alpha = 0f
        isClickable = true // engole toques/cliques para não chegarem ao desktop por baixo
        isFocusable = false
        tag = CursorController.NOHAND

        // Fundo padrão (nunca preto): degradê azul-petróleo; aparece quando nenhum papel de parede foi escolhido.
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#1B2B45"), Color.parseColor("#34506E"))
        )

        val mp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        addView(wallpaperSlot, mp)
        wallpaperSlot.addView(
            wallpaperView,
            FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        )

        val d = resources.displayMetrics.density
        val compact = resources.displayMetrics.heightPixels / d < 520f // telas baixas: tudo um pouco menor

        // relógio e data empilhados no canto superior esquerdo (sem sobreposição)
        val topCol = LinearLayout(ctx)
        topCol.orientation = LinearLayout.VERTICAL
        topCol.addView(clockSlot, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        topCol.addView(dateSlot, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        addView(
            topCol,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
                .apply { setMargins((48 * d).toInt(), ((if (compact) 32 else 64) * d).toInt(), 0, 0) }
        )
        // clima: canto inferior esquerdo
        addView(
            weatherSlot,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
                .apply { setMargins((48 * d).toInt(), 0, 0, ((if (compact) 24 else 48) * d).toInt()) }
        )

        // player de música: embaixo, no centro (se bater em outro elemento, a personalização o acomoda no espaço livre)
        addView(
            musicWidget,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { setMargins(0, 0, 0, ((if (compact) 24 else 48) * d).toInt()) }
        )

        buildClockAndDate(compact)
        buildWeatherCard(compact)
    }

    // ------------------------------------------------------------------ relógio e data

    private lateinit var timeView: TextView
    private lateinit var weekdayView: TextView
    private lateinit var dateView: TextView

    private fun dpf(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun styled(t: TextView, size: Float, light: Boolean = false, alpha: Float = 1f): TextView {
        t.setTextColor(WHITE)
        t.alpha = alpha
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        t.typeface = Typeface.create(if (light) "sans-serif-light" else "sans-serif", Typeface.NORMAL)
        t.setShadowLayer(dpf(6).toFloat(), 0f, dpf(1).toFloat(), 0x66000000)
        t.includeFontPadding = false
        return t
    }

    private fun buildClockAndDate(compact: Boolean) {
        timeView = styled(TextView(context), if (compact) 68f else 96f, light = true)
        clockSlot.addView(timeView)
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        weekdayView = styled(TextView(context), if (compact) 20f else 26f)
        dateView = styled(TextView(context), if (compact) 15f else 18f, alpha = 0.85f)
        col.addView(weekdayView)
        col.addView(dateView)
        col.setPadding(dpf(4), dpf(4), 0, 0)
        dateSlot.addView(col)
    }

    /** Hora no formato do aparelho (12 h / 24 h); data sempre em português do Brasil. */
    private fun updateTime() {
        if (!::timeView.isInitialized) return
        val now = Date()
        if (DateFormat.is24HourFormat(context)) {
            timeView.text = SimpleDateFormat("HH:mm", PT_BR).format(now)
        } else {
            val h = SimpleDateFormat("h:mm", PT_BR).format(now)
            val ap = SimpleDateFormat("a", PT_BR).format(now).uppercase(PT_BR)
            val sp = SpannableString("$h $ap")
            sp.setSpan(RelativeSizeSpan(0.3f), h.length, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            timeView.text = sp
        }
        weekdayView.text = SimpleDateFormat("EEEE", PT_BR).format(now)
            .replaceFirstChar { it.uppercase(PT_BR) }
        dateView.text = SimpleDateFormat("d 'de' MMMM 'de' yyyy", PT_BR).format(now)
    }

    private val tick = object : Runnable {
        override fun run() {
            updateTime()
            // próxima atualização exatamente na virada do minuto
            postDelayed(this, 60_000L - System.currentTimeMillis() % 60_000L + 50L)
        }
    }

    private fun startTicking() {
        removeCallbacks(tick)
        tick.run()
    }

    private fun stopTicking() {
        removeCallbacks(tick)
    }

    // ------------------------------------------------------------------ previsão do tempo

    private lateinit var wxIcon: TextView
    private lateinit var wxTemp: TextView
    private lateinit var wxCond: TextView
    private lateinit var wxFeels: TextView
    private lateinit var wxCity: TextView
    private lateinit var wxStatus: TextView

    private var wxData: WeatherData? = null
    private var wxFailed = false
    private var wxLoading = false
    private var wxGen = 0

    private fun isManual() = prefs.getString("lockWxMode", "auto") == "manual"

    private fun buildWeatherCard(compact: Boolean) {
        val card = LinearLayout(context)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dpf(20), dpf(14), dpf(24), dpf(14))
        card.background = GradientDrawable().apply {
            cornerRadius = dpf(16).toFloat()
            setColor(Color.parseColor("#33000000"))
            setStroke(dpf(1), Color.parseColor("#33FFFFFF"))
        }
        card.isClickable = true
        var secondaryDown = false
        card.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                secondaryDown =
                    (ev.buttonState and (MotionEvent.BUTTON_SECONDARY or MotionEvent.BUTTON_TERTIARY)) != 0
            }
            false // só observa; o clique continua sendo tratado normalmente
        }
        card.setOnClickListener { if (!secondaryDown) cityWindow.show(card) }

        wxIcon = TextView(context)
        wxIcon.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (compact) 34f else 44f)
        wxIcon.includeFontPadding = false
        card.addView(wxIcon, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            rightMargin = dpf(16)
        })

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        wxTemp = styled(TextView(context), if (compact) 26f else 32f)
        wxCond = styled(TextView(context), 15f)
        wxFeels = styled(TextView(context), 13f, alpha = 0.85f)
        wxCity = styled(TextView(context), 13f, alpha = 0.85f)
        wxStatus = styled(TextView(context), 12f, alpha = 0.7f)
        for (t in listOf(wxTemp, wxCond, wxFeels, wxCity, wxStatus)) {
            t.maxWidth = dpf(280)
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        }
        wxStatus.setPadding(0, dpf(4), 0, 0)
        card.addView(col, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        weatherSlot.addView(card)
    }

    private fun hhmm(t: Long, withDate: Boolean): String {
        val f = if (withDate) "dd/MM HH:mm" else (if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm a")
        return SimpleDateFormat(f, PT_BR).format(Date(t))
    }

    private fun renderWeather() {
        if (!::wxIcon.isInitialized) return
        cityWindow.refresh()
        val w = wxData
        if (w == null) {
            wxIcon.text = "🌡️"
            wxTemp.text = "--°C"
            wxCond.text = if (wxLoading) "Carregando previsão…" else "Previsão indisponível"
            wxFeels.visibility = View.GONE
            wxCity.text = (if (isManual()) prefs.getString("lockWxName", null) else null)
                ?.let { "📍 $it  ›" } ?: "📍 Escolher cidade  ›"
            wxStatus.text = when {
                wxLoading -> "Buscando dados…"
                wxFailed -> "Sem conexão ou localização indisponível"
                else -> "Toque para escolher a cidade"
            }
            return
        }
        val age = System.currentTimeMillis() - w.fetchedAt
        val stale = wxFailed || age > WX_STALE_MS
        wxIcon.text = Weather.emoji(w.code, w.isDay)
        wxTemp.text = "${w.temp}°C"
        wxCond.text = Weather.describe(w.code)
        wxFeels.text = "Sensação térmica ${w.feels}°C"
        wxFeels.visibility = View.VISIBLE
        wxCity.text = "📍 ${w.city}  ›"
        val sameDay = SimpleDateFormat("yyyyMMdd", PT_BR).let { it.format(Date(w.fetchedAt)) == it.format(Date()) }
        wxStatus.text =
            if (stale) "⚠ Desatualizado · última atualização ${hhmm(w.fetchedAt, !sameDay)}"
            else "Atualizado às ${hhmm(w.fetchedAt, false)}"
        wxStatus.alpha = if (stale) 1f else 0.7f
    }

    private val wxRefresh = Runnable { refreshWeather(false) }

    /** Busca dados reais (Open-Meteo). Sem internet, mantém os últimos dados guardados e marca como desatualizados. */
    fun refreshWeather(force: Boolean) {
        if (wxLoading && !force) return
        val gen = ++wxGen
        wxLoading = true
        if (wxData == null) renderWeather()

        val app = context.applicationContext
        val manual = isManual()
        val lat = prefs.getString("lockWxLat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lockWxLon", null)?.toDoubleOrNull()
        val name = prefs.getString("lockWxName", null) ?: "Cidade escolhida"
        Thread {
            val data = try {
                if (manual && lat != null && lon != null) Weather.fetchAt(lat, lon, name)
                else Weather.fetchAuto(app, prefs)
            } catch (e: Exception) {
                null
            }
            if (data != null) Weather.save(prefs, data, LOCK_WX_KEY)
            post {
                if (gen != wxGen) return@post // uma busca mais nova (ex.: outra cidade) já assumiu
                wxLoading = false
                if (data != null) {
                    wxData = data
                    wxFailed = false
                } else {
                    wxFailed = true
                }
                renderWeather()
                if (isOpen) scheduleWeather(data != null)
            }
        }.start()
    }

    private fun scheduleWeather(ok: Boolean) {
        removeCallbacks(wxRefresh)
        postDelayed(wxRefresh, if (ok) WX_OK_RETRY_MS else WX_FAIL_RETRY_MS)
    }

    private fun stopWeather() {
        removeCallbacks(wxRefresh)
    }

    private fun startWeather() {
        if (!isManual()) onNeedLocation()
        val w = wxData
        val recent = w != null && !wxFailed && System.currentTimeMillis() - w.fetchedAt < 10 * 60 * 1000L
        if (recent) scheduleWeather(true) else refreshWeather(false)
    }

    private fun resetWeatherFor(manual: Boolean, lat: Double? = null, lon: Double? = null, name: String? = null) {
        prefs.edit().apply {
            putString("lockWxMode", if (manual) "manual" else "auto")
            if (manual) {
                putString("lockWxLat", lat.toString())
                putString("lockWxLon", lon.toString())
                putString("lockWxName", name)
            }
            remove(LOCK_WX_KEY) // não mostra dados de outra cidade como se fossem desta
        }.apply()
        wxData = null
        wxFailed = false
        renderWeather()
        if (!manual) {
            // escolha explícita do usuário: se a permissão ainda não foi dada, pergunta de novo
            if (!hasLocationPermission()) prefs.edit().putBoolean("wxAsked", false).apply()
            onNeedLocation()
        }
        refreshWeather(true)
    }

    // ------------------------------------------------------------------ escolha da cidade (janela flutuante)

    private fun hasLocationPermission() =
        context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private lateinit var cityWindow: WeatherCityWindow
    private lateinit var customizer: LockCustomizer

    // as duas janelas se referenciam: por isso lateinit + tipos explícitos, criadas aqui em ordem
    init {
        cityWindow = WeatherCityWindow(
            parent = this,
            isAuto = { !isManual() },
            chosenCity = { if (isManual()) prefs.getString("lockWxName", null) else null },
            hasLocationPermission = { hasLocationPermission() },
            onPickAuto = { pickAutoLocation() },
            onPickCity = { r -> resetWeatherFor(true, r.lat, r.lon, r.name) },
            onMoveWeather = { cityWindow.dismiss(); customizer.show(LockCustomizer.Target.WEATHER) },
            onMoreOptions = { cityWindow.dismiss(); customizer.show() }
        )

        /**
         * Painel de personalização (relógio e previsão: adicionar, mover, fonte). Independente dos elementos:
         * só controla visibilidade/posição dos contêineres [clockSlot].parent e [weatherSlot] e a fonte do relógio.
         */
        customizer = LockCustomizer(
            lock = this,
            prefs = prefs,
            clockBlock = clockSlot.parent as View, // coluna relógio + data
            weatherBlock = weatherSlot,
            musicBlock = musicWidget,
            applyClockFont = { tf -> applyClockTypeface(tf) },
            openCityWindow = { weatherSlot.getChildAt(0)?.let { cityWindow.show(it) } },
            store = wallpaperStore,
            wallpaperView = wallpaperView,
            onImportWallpaper = { onPickWallpaperFile() }
        )
    }

    // arrastar o player segurando: o painel de personalização cuida dos limites e de não sobrepor os outros elementos
    init {
        musicWidget.drag = object : MusicWidget.DragCb {
            override fun onStart() = customizer.dragStart(LockCustomizer.Target.MUSIC)
            override fun onMove(dx: Float, dy: Float) = customizer.dragMove(LockCustomizer.Target.MUSIC, dx, dy)
            override fun onEnd() = customizer.dragEnd(LockCustomizer.Target.MUSIC)
        }
    }

    /** Abre o painel de personalização (opção do menu de botão direito). */
    fun openCustomizer() {
        if (!isOpen) return
        cityWindow.dismiss()
        customizer.show()
    }

    /** Abre o painel de personalização já na galeria de papéis de parede. */
    fun openWallpaperGallery() {
        if (!isOpen) return
        cityWindow.dismiss()
        customizer.show(wallpaper = true)
    }

    /**
     * Importa o arquivo escolhido (imagem, GIF ou vídeo) para a galeria, aplica como fundo desta tela de bloqueio
     * e reabre a galeria. A cópia é feita em segundo plano.
     */
    fun importWallpaper(uri: Uri) {
        Thread {
            val r = wallpaperStore.import(uri)
            post {
                val e = r.entry
                if (e == null) {
                    Toast.makeText(context, r.error ?: "Não foi possível importar", Toast.LENGTH_SHORT).show()
                } else {
                    val sel = WpSel.Imported(e)
                    wallpaperStore.select(sel)
                    wallpaperView.setWallpaper(sel, true)
                    musicWidget.requestBackdropRefresh(this, force = true, delayMs = 520L)
                }
                if (isOpen) openWallpaperGallery()
            }
        }.start()
    }

    /** ESC / Voltar: fecha a janela mais de cima (cidade, depois personalização). Retorna true se algo foi fechado. */
    fun closeOverlays(): Boolean = cityWindow.dismiss() || customizer.dismiss()

    private fun applyClockTypeface(tf: Typeface?) {
        if (!::timeView.isInitialized) return
        timeView.typeface = tf ?: Typeface.create("sans-serif-light", Typeface.NORMAL)
        weekdayView.typeface = tf ?: Typeface.create("sans-serif", Typeface.NORMAL)
        dateView.typeface = tf ?: Typeface.create("sans-serif", Typeface.NORMAL)
        requestLayout()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        customizer.applyPositions() // mantém relógio/previsão nas posições salvas e dentro da tela
    }

    private fun pickAutoLocation() {
        if (isManual()) {
            resetWeatherFor(false)
        } else {
            // já estava automático: não apaga o que está na tela; só tenta de novo a permissão e atualiza
            if (!hasLocationPermission()) {
                prefs.edit().putBoolean("wxAsked", false).apply()
                onNeedLocation()
            }
            refreshWeather(true)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pivotX = w / 2f
        pivotY = h / 2f
    }

    fun show() {
        if (isOpen) return
        isOpen = true
        inputLockedUntil = SystemClock.uptimeMillis() + DURATION_MS // sem cliques acidentais durante a abertura
        val desk = desktopViews()

        cancelAll(desk)
        visibility = View.VISIBLE
        if (alpha == 0f) scaleX = ZOOM_LOCK.also { scaleY = it }

        setLayerType(LAYER_TYPE_HARDWARE, null)
        animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(DURATION_MS).setInterpolator(ease)
            .withEndAction { setLayerType(LAYER_TYPE_NONE, null) }
            .start()

        startTicking()
        startWeather()
        wallpaperView.setActive(true)
        musicWidget.requestBackdropRefresh(this, force = true, delayMs = 150L)

        // o desktop sai de cena enquanto o bloqueio entra (o papel de parede do desktop continua atrás: sem preto)
        for (v in desk) {
            v.animate().alpha(0f).scaleX(ZOOM_DESKTOP).scaleY(ZOOM_DESKTOP)
                .setDuration(DURATION_MS).setInterpolator(ease)
                .start()
        }
    }

    fun hide() {
        if (!isOpen) return
        isOpen = false
        cityWindow.dismiss()
        customizer.dismiss()
        inputLockedUntil = SystemClock.uptimeMillis() + DURATION_MS
        val desk = desktopViews()

        cancelAll(desk)
        setLayerType(LAYER_TYPE_HARDWARE, null)
        animate().alpha(0f).scaleX(ZOOM_LOCK).scaleY(ZOOM_LOCK)
            .setDuration(DURATION_MS).setInterpolator(ease)
            .withEndAction {
                setLayerType(LAYER_TYPE_NONE, null)
                if (!isOpen) {
                    visibility = View.GONE
                    scaleX = 1f
                    scaleY = 1f
                    stopTicking()
                    stopWeather()
                    wallpaperView.setActive(false) // fechada: para vídeo e animações (economiza bateria)
                }
            }
            .start()

        for (v in desk) {
            v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(DURATION_MS).setInterpolator(ease)
                .start()
        }
    }

    /** Termina na hora qualquer animação em curso, no estado final (usado ao sair do app). */
    fun settle() {
        cityWindow.dismiss()
        customizer.dismiss()
        val desk = desktopViews()
        cancelAll(desk)
        setLayerType(LAYER_TYPE_NONE, null)
        if (isOpen) {
            visibility = View.VISIBLE
            alpha = 1f
            scaleX = 1f
            scaleY = 1f
            for (v in desk) { v.alpha = 0f; v.scaleX = ZOOM_DESKTOP; v.scaleY = ZOOM_DESKTOP }
        } else {
            visibility = View.GONE
            alpha = 0f
            scaleX = 1f
            scaleY = 1f
            for (v in desk) { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f }
        }
        stopTicking()
        stopWeather()
        wallpaperView.setActive(false) // app saiu da frente: libera o player de vídeo e para as animações
    }

    /** O app voltou ao primeiro plano: se a tela estiver aberta, retoma relógio e clima (hora/formato podem ter mudado). */
    fun onHostResume() {
        if (!isOpen) return
        startTicking()
        startWeather()
        wallpaperView.setActive(true)
    }

    // ------------------------------------------------------------------ saída por clique em área vazia

    private var inputLockedUntil = 0L
    private var downEmpty = false
    private var downX = 0f
    private var downY = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private fun inputLocked() = SystemClock.uptimeMillis() < inputLockedUntil

    /**
     * Só chega aqui o que nenhum filho consumiu (o cartão do clima, por exemplo, é clicável e trata o próprio clique).
     * Mesmo assim o ponto é conferido contra a área de cada elemento visível antes de sair:
     * relógio, data, textos, imagens e qualquer elemento interativo contam como "ocupado".
     * Sai no ACTION_UP (clique completo), sem arrasto, com o botão esquerdo do mouse ou um toque.
     */
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val otherButton =
                    (ev.buttonState and (MotionEvent.BUTTON_SECONDARY or MotionEvent.BUTTON_TERTIARY)) != 0
                downEmpty = isOpen && !inputLocked() && !otherButton && !occupiedAt(ev.x, ev.y)
                // botão direito do mouse em área vazia: menu de contexto (o clique vazio comum continua saindo da tela)
                if ((ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0 && isOpen && !inputLocked() &&
                    !occupiedAt(ev.x, ev.y)
                ) onContextMenu(ev.rawX.toInt(), ev.rawY.toInt())
                downX = ev.x
                downY = ev.y
            }
            MotionEvent.ACTION_MOVE ->
                if (downEmpty && (Math.abs(ev.x - downX) > slop || Math.abs(ev.y - downY) > slop)) downEmpty = false
            MotionEvent.ACTION_UP -> {
                val exit = downEmpty && isOpen && !inputLocked() && !occupiedAt(ev.x, ev.y)
                downEmpty = false
                if (exit) hide() // hide() ignora chamadas repetidas: nunca fecha duas vezes
            }
            MotionEvent.ACTION_CANCEL -> downEmpty = false
        }
        return true // continua engolindo o toque: nada vaza para o desktop por baixo
    }

    /** O ponto (coordenadas da tela de bloqueio) está sobre algum elemento visível? O papel de parede é fundo, não conta. */
    private fun occupiedAt(x: Float, y: Float): Boolean = occupiedIn(this, x, y)

    private fun occupiedIn(parent: ViewGroup, x: Float, y: Float): Boolean {
        for (i in parent.childCount - 1 downTo 0) {
            val c = parent.getChildAt(i)
            if (c === wallpaperSlot) continue
            if (c.visibility != View.VISIBLE || c.alpha <= 0.01f) continue
            val cx = x + parent.scrollX - c.left - c.translationX
            val cy = y + parent.scrollY - c.top - c.translationY
            if (cx < 0f || cy < 0f || cx >= c.width || cy >= c.height) continue
            if (c is ViewGroup) {
                // contêiner só conta se for interativo ou desenhar algo (fundo); senão olha os filhos
                if (c.isClickable || c.isLongClickable || c.background != null) return true
                if (occupiedIn(c, cx, cy)) return true
            } else if (isContent(c)) {
                return true
            }
        }
        return false
    }

    private fun isContent(v: View): Boolean = when {
        v.isClickable || v.isLongClickable -> true
        v is TextView -> v.text.isNotEmpty()
        v is ImageView -> v.drawable != null
        else -> v.background != null
    }

    private fun cancelAll(desk: List<View>) {
        animate().cancel()
        for (v in desk) v.animate().cancel()
    }

    // Fica por último de propósito: as propriedades acima (wxData etc.) já foram inicializadas.
    init {
        // dados guardados aparecem na hora, marcados como desatualizados se for o caso
        wxData = Weather.load(prefs, LOCK_WX_KEY) ?: if (!isManual()) Weather.load(prefs) else null
        renderWeather()
        updateTime()
        wallpaperView.setWallpaper(wallpaperStore.selection(), false) // escolha salva volta ao reabrir o app
        customizer.applyAll() // visibilidade, fonte e posições salvas da personalização
    }
}
