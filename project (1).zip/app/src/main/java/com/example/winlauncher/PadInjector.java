package com.example.winlauncher;

import android.os.Build;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * Mapeador de gamepad (Etapa 5) - injetor de toques que roda FORA do app, com a permissão do Shizuku (usuário shell).
 *
 * Quem inicia é o {@link PadShizukuInput}: {@code app_process -Djava.class.path=<apk> /system/bin ... PadInjector}. Esta classe lê
 * comandos de texto na entrada padrão e injeta MotionEvents de tela de toque pelo InputManager do sistema (o mesmo caminho do
 * "adb shell input" e do scrcpy), sem o ciclo de gestos da acessibilidade. NÃO usa nada do app (nem Kotlin): só a plataforma.
 *
 * Protocolo (uma linha por comando, números inteiros em pixels):
 *   D slot x y   dedo desce        M slot x y   dedo anda (só atualiza)      F   manda o MOVE pendente (um evento para todos)
 *   U slot       dedo sobe         X            solta todos                  Q   solta todos e sai
 * Respostas na saída padrão: "READY sdk" quando pronto, "ERR motivo" se não deu (e o processo sai), "LOG texto" avisos.
 * Fim da entrada (o app morreu) = solta todos e sai, para não deixar dedo preso na tela.
 */
public final class PadInjector {

    private static final int MAX = 10;

    private static Object im;
    private static Method inject;
    private static boolean inject3;

    private final ArrayList<Integer> order = new ArrayList<Integer>();
    private final float[] xs = new float[MAX];
    private final float[] ys = new float[MAX];
    private final MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[MAX];
    private final MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[MAX];
    private long downTime;
    private boolean pendingMove;
    private int failedRow;

    private PadInjector() {
        for (int i = 0; i < MAX; i++) {
            props[i] = new MotionEvent.PointerProperties();
            coords[i] = new MotionEvent.PointerCoords();
        }
    }

    /** Acha o InputManager (Android 14+: InputManagerGlobal; antes: InputManager). Devolve null se deu certo, senão o motivo. */
    static String init() {
        try {
            Class<?> cls;
            try {
                cls = Class.forName("android.hardware.input.InputManagerGlobal");
            } catch (ClassNotFoundException e) {
                cls = Class.forName("android.hardware.input.InputManager");
            }
            Method gi = cls.getDeclaredMethod("getInstance");
            gi.setAccessible(true);
            im = gi.invoke(null);
            try {
                inject = cls.getMethod("injectInputEvent", InputEvent.class, int.class);
                inject3 = false;
            } catch (NoSuchMethodException e) {
                inject = cls.getMethod("injectInputEvent", InputEvent.class, int.class, int.class);
                inject3 = true;
            }
            inject.setAccessible(true);
            return null;
        } catch (Throwable t) {
            Throwable c = t;
            if (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) c = t.getCause();
            return c.getClass().getSimpleName() + ": " + c.getMessage();
        }
    }

    public static void main(String[] args) {
        String err = init();
        if (err != null) {
            System.out.println("ERR " + err);
            System.out.flush();
            System.exit(1);
            return;
        }
        System.out.println("READY " + Build.VERSION.SDK_INT);
        System.out.flush();
        run(System.in);
        System.exit(0);
    }

    /** Laço de comandos (separado do main para poder ser testado). */
    static void run(java.io.InputStream in) {
        PadInjector pi = new PadInjector();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "US-ASCII"));
            String line;
            while ((line = br.readLine()) != null) {
                if (!pi.handle(line)) break;
            }
        } catch (Throwable t) {
            System.out.println("LOG leitura: " + t.getClass().getSimpleName());
        }
        try {
            pi.releaseAll();
        } catch (Throwable t) {
        }
    }

    /** Devolve false para sair. */
    boolean handle(String line) {
        if (line.length() == 0) return true;
        char c = line.charAt(0);
        try {
            if (c == 'D' || c == 'M') {
                String[] p = line.split(" ");
                if (p.length < 4) return true;
                int s = Integer.parseInt(p[1]);
                float x = Float.parseFloat(p[2]);
                float y = Float.parseFloat(p[3]);
                if (c == 'D') down(s, x, y);
                else move(s, x, y);
            } else if (c == 'U') {
                String[] p = line.split(" ");
                if (p.length < 2) return true;
                up(Integer.parseInt(p[1]));
            } else if (c == 'F') {
                flushMove();
            } else if (c == 'X') {
                releaseAll();
            } else if (c == 'Q') {
                return false;
            }
        } catch (NumberFormatException e) {
            // linha estragada: ignora
        }
        return true;
    }

    void down(int slot, float x, float y) {
        if (slot < 0 || slot >= MAX) return;
        flushMove();
        xs[slot] = x;
        ys[slot] = y;
        if (order.contains(slot)) {
            pendingMove = true;
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (order.isEmpty()) downTime = now;
        order.add(slot);
        int idx = order.size() - 1;
        int action = idx == 0
            ? MotionEvent.ACTION_DOWN
            : (MotionEvent.ACTION_POINTER_DOWN | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
        inject(action, now);
    }

    void move(int slot, float x, float y) {
        if (slot < 0 || slot >= MAX || !order.contains(slot)) return;
        xs[slot] = x;
        ys[slot] = y;
        pendingMove = true;
    }

    void up(int slot) {
        flushMove();
        int idx = order.indexOf(slot);
        if (idx < 0) return;
        int action = order.size() == 1
            ? MotionEvent.ACTION_UP
            : (MotionEvent.ACTION_POINTER_UP | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
        inject(action, SystemClock.uptimeMillis());
        order.remove(idx);
    }

    void releaseAll() {
        flushMove();
        while (!order.isEmpty()) up(order.get(0));
    }

    private void flushMove() {
        if (!pendingMove) return;
        pendingMove = false;
        if (order.isEmpty()) return;
        inject(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis());
    }

    private void inject(int action, long when) {
        int n = order.size();
        for (int i = 0; i < n; i++) {
            int s = order.get(i);
            props[i].clear();
            props[i].id = s;
            props[i].toolType = MotionEvent.TOOL_TYPE_FINGER;
            coords[i].clear();
            coords[i].x = xs[s];
            coords[i].y = ys[s];
            coords[i].pressure = 1f;
            coords[i].size = 1f;
        }
        MotionEvent ev = MotionEvent.obtain(downTime, when, action, n, props, coords, 0, 0, 1f, 1f, 0, 0,
            InputDevice.SOURCE_TOUCHSCREEN, 0);
        try {
            Object r = inject3 ? inject.invoke(im, ev, 0, -1) : inject.invoke(im, ev, 0);
            if (r instanceof Boolean && !((Boolean) r).booleanValue()) fail("recusado pelo sistema");
            else failedRow = 0;
        } catch (Throwable t) {
            Throwable c = t;
            if (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) c = t.getCause();
            fail(c.getClass().getSimpleName() + ": " + c.getMessage());
        } finally {
            ev.recycle();
        }
    }

    /** Muitas falhas seguidas = não adianta continuar: avisa e sai (o app volta para o motor de acessibilidade). */
    private void fail(String why) {
        failedRow++;
        if (failedRow == 1) System.out.println("LOG injeção falhou: " + why);
        if (failedRow >= 20) {
            System.out.println("ERR injeção falhou 20 vezes seguidas: " + why);
            System.out.flush();
            System.exit(2);
        }
    }
}
