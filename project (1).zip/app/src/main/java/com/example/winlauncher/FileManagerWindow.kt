package com.example.winlauncher

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Calendar
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Gerenciador de arquivos do WinLauncher, no estilo do Explorador de Arquivos do Windows 11.
 * Janela autônoma igual às outras apps nativas (arrasta pela barra de título, minimiza para a barra de tarefas) com
 * três modos, como o navegador:
 *  - janela: tamanho livre (arraste o canto inferior direito para redimensionar);
 *  - maximizada: ocupa a tela toda mas deixa a barra de tarefas visível (com o X de fechar na barra de título);
 *  - tela cheia: ocupa a tela toda, inclusive por cima da barra de tarefas (botões de restaurar e fechar no canto).
 *
 * Funções: Este PC com unidades, barra lateral, caminho clicável/editável, voltar/avançar/subir, pesquisa (no filtro
 * e recursiva), ícones grandes/médios/lista/detalhes, ordenação, agrupamento por data, miniaturas, seleção (mouse com
 * Ctrl/Shift, toque, selecionar tudo), recortar/copiar/colar com progresso e conflitos, renomear, excluir, nova pasta e
 * novo documento, compactar/extrair ZIP, abrir, abrir com, compartilhar, instalar APK, propriedades e atalhos de teclado.
 */
class FileManagerWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    /** Espaço ocupado pela barra de tarefas em px: (topo, base). Usado no modo maximizado. */
    private val taskbarInsets: () -> Pair<Int, Int>
) {

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MODE_WINDOW = 0
        private const val MODE_MAX = 1
        private const val MODE_FULL = 2
        const val VIEW_LARGE = 0
        const val VIEW_MEDIUM = 1
        const val VIEW_LIST = 2
        const val VIEW_DETAILS = 3
        const val SORT_NAME = 0
        const val SORT_DATE = 1
        const val SORT_TYPE = 2
        const val SORT_SIZE = 3
        const val REQ_STORAGE = 31
        private const val ERR_ACCESS = "\u0000acesso"
    }

    private class FItem(val file: File, val name: String, val isDir: Boolean, val size: Long, val mod: Long) {
        val kind = FKind.of(name, isDir)
        val ext = FKind.ext(name)
        val path: String get() = file.absolutePath
    }

    private class Row(val header: String?, val start: Int, val count: Int)

    private class Drive(val label: String, val dir: File)

    private class Btn(val text: String, val primary: Boolean = false, val auto: Boolean = true, val onClick: () -> Unit)

    /** Camada tela cheia que contém a janela; fica logo abaixo do menu de contexto. */
    val layer = FrameLayout(act)

    /** Avisado quando abre, minimiza, restaura ou fecha (a barra de tarefas se redesenha). */
    var onStateChange: (() -> Unit)? = null

    val isOpen: Boolean get() = open
    val isMinimized: Boolean get() = minimized

    private var lastSnap: Bitmap? = null

    /** Miniatura da janela para a janelinha da barra de tarefas. */
    fun snapshot(maxW: Int): Bitmap? = snapView(win, maxW) ?: lastSnap

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val store = act.getSharedPreferences("win", Context.MODE_PRIVATE)

    private val ink = Color.parseColor("#F2F2F2")
    private val sub = Color.parseColor("#A0A0A0")
    private val accent = Color.parseColor("#4CC2FF")
    private val cWin = Color.parseColor("#1C1C1C")
    private val cBar = Color.parseColor("#202020")
    private val cSide = Color.parseColor("#1F1F1F")
    private val cField = Color.parseColor("#2D2D2D")
    private val cLine = Color.parseColor("#26FFFFFF")
    private val cSel = Color.parseColor("#3A4CC2FF")
    private val cHover = Color.parseColor("#16FFFFFF")

    // ---- estado da janela
    private var open = false
    private var minimized = false
    private var placed = false
    private var mode = MODE_WINDOW
    private var modeBeforeFull = MODE_WINDOW
    private var normW = 0
    private var normH = 0
    private var normX = 0f
    private var normY = 0f
    private var active = false

    // ---- estado do navegador de arquivos
    private var curDir: File? = null
    private val back = ArrayList<String>()
    private val fwd = ArrayList<String>()
    private var allItems: List<FItem> = emptyList()
    private var shown: List<FItem> = emptyList()
    private val rows = ArrayList<Row>()
    private val selected = LinkedHashSet<String>()
    private var selectMode = false
    private var anchor = -1
    private var clip: List<File> = emptyList()
    private var clipCut = false
    private var query = ""
    private var searching = false
    private var searchGen = 0
    private var loadGen = 0
    private var loadError: String? = null
    private var loading = false
    private var pendingSelect: String? = null
    private var perRow = 1
    private var lastClickPath: String? = null
    private var lastClickT = 0L
    private var suppressSearch = false
    private var searchTick: Runnable? = null
    private var opTitle = ""
    private var dlgOnClose: (() -> Unit)? = null
    private val clipSet = HashSet<String>()
    private var lastMouse = false
    private var lastCtrl = false
    private var lastShift = false
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var progBar: ProgressBar? = null
    private var progText: TextView? = null
    private var progShown = false
    private var opStart = 0L
    private var lastTitleTap = 0L
    private val thumbFail = HashSet<String>()
    private var driveCache: List<Drive> = emptyList()
    private var dlgModal = false
    private var searchDone = true

    private var viewMode = store.getInt("fm_view", VIEW_LARGE)
    private var sortKey = store.getInt("fm_sort", SORT_NAME)
    private var sortAsc = store.getBoolean("fm_asc", true)
    private var showHidden = store.getBoolean("fm_hidden", true)

    // ---- execução em segundo plano
    private var ioExec: ExecutorService? = null
    private var opExec: ExecutorService? = null
    private var thumbExec: ExecutorService? = null
    private var curCtl: OpCtl? = null
    private var ticker: Runnable? = null
    private val thumbs = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun io(task: () -> Unit) {
        val e = ioExec ?: Executors.newFixedThreadPool(2).also { ioExec = it }
        try {
            e.execute { task() }
        } catch (t: Throwable) {
        }
    }

    // ---- views
    private lateinit var win: FrameLayout
    private lateinit var titleBar: LinearLayout
    private lateinit var titleText: TextView
    private var titleIcon: ImageView? = null
    private lateinit var maxBtn: ImageView
    private lateinit var fullBtn: ImageView
    private lateinit var navBar: LinearLayout
    private lateinit var backBtn: ImageView
    private lateinit var fwdBtn: ImageView
    private lateinit var upBtn: ImageView
    private lateinit var crumbScroll: HorizontalScrollView
    private lateinit var crumbRow: LinearLayout
    private lateinit var addrEdit: EditText
    private lateinit var searchBox: EditText
    private lateinit var cmdBar: HorizontalScrollView
    private lateinit var cmdRow: LinearLayout
    private val cmdViews = HashMap<String, View>()
    private lateinit var sidebar: ScrollView
    private lateinit var sideCol: LinearLayout
    private lateinit var sideDivider: View
    private val sideEntries = ArrayList<Pair<View, String>>()
    private var pcExpanded = true
    private lateinit var content: FrameLayout
    private lateinit var listCol: LinearLayout
    private lateinit var detailsHeader: LinearLayout
    private lateinit var listView: ListView
    private lateinit var homeScroll: ScrollView
    private lateinit var homeCol: LinearLayout
    private lateinit var msgBox: LinearLayout
    private lateinit var msgText: TextView
    private lateinit var msgBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var grip: View
    private lateinit var fsBar: LinearLayout
    private lateinit var dlgLayer: FrameLayout
    private var dlgOk: (() -> Unit)? = null
    private var adapter = RowAdapter()

    init {
        build()
        root.addOnLayoutChangeListener { _, l, t, r, b, oL, oT, oR, oB ->
            if (open && !minimized && mode != MODE_WINDOW && (r - l != oR - oL || b - t != oB - oT)) {
                win.post { sizeWindow() }
            }
        }
    }

    // ================================================================== API pública

    /** Abre o gerenciador (ou restaura se minimizado). Com [path], abre direto nessa pasta. */
    fun show(path: String? = null) {
        if (open) {
            if (minimized) restore()
            if (path != null) navigate(path)
            return
        }
        open = true
        minimized = false
        win.animate().cancel()
        sizeWindow()
        showAnimated()
        navigate(path, false)
        onStateChange?.invoke()
    }

    fun minimize() {
        if (!open || minimized) return
        lastSnap = snapView(win, 480)
        minimized = true
        hideKeyboard()
        hideAnimated()
        onStateChange?.invoke()
    }

    fun restore() {
        if (!open || !minimized) return
        minimized = false
        sizeWindow()
        showAnimated()
        reload()
        onStateChange?.invoke()
    }

    /** Clique no ícone da barra de tarefas: restaura se minimizada, minimiza se estiver à frente. */
    fun toggleFromTaskbar() {
        if (minimized) restore() else minimize()
    }

    /** Fecha a janela e libera threads, miniaturas e listas. */
    fun close() {
        if (!open) return
        hideKeyboard()
        closeDialog()
        curCtl?.cancel = true
        stopTicker()
        lastSnap = null
        open = false
        minimized = false
        mode = MODE_WINDOW
        active = false
        ++loadGen
        ++searchGen
        ioExec?.shutdownNow()
        ioExec = null
        opExec?.shutdownNow()
        opExec = null
        thumbExec?.shutdownNow()
        thumbExec = null
        thumbs.evictAll()
        allItems = emptyList()
        shown = emptyList()
        rows.clear()
        selected.clear()
        back.clear()
        fwd.clear()
        curDir = null
        query = ""
        searching = false
        placed = false
        normW = 0
        normH = 0
        hideAnimated()
        onStateChange?.invoke()
    }

    /** Botão voltar do Android: fecha diálogo, sai da tela cheia, limpa pesquisa/seleção ou volta uma pasta. */
    fun handleBack(): Boolean {
        if (!open || minimized) return false
        if (dlgLayer.visibility == View.VISIBLE) {
            closeDialog()
            return true
        }
        if (addrEdit.visibility == View.VISIBLE) {
            stopAddrEdit()
            return true
        }
        if (mode == MODE_FULL) {
            setMode(modeBeforeFull)
            return true
        }
        if (selected.isNotEmpty() || selectMode) {
            clearSelection()
            return true
        }
        if (query.isNotEmpty() || searching) {
            searchBox.setText("")
            return true
        }
        if (back.isNotEmpty()) {
            goBack()
            return true
        }
        return false
    }

    /** Chamado quando o launcher volta para a frente (por exemplo, depois de conceder acesso aos arquivos). */
    fun onHostResume() {
        if (open && !minimized) {
            rebuildSidebar()
            reload()
        }
    }

    /** Recarrega a pasta atual (chamado quando a galeria de fotos exclui um arquivo). */
    fun refreshList() {
        if (open && !minimized) reload()
    }

    /** Atualiza o ícone da barra de título (depois de trocar o ícone do gerenciador). */
    fun refreshIcon() {
        titleIcon?.setImageDrawable(act.filesIcon())
    }

    /** Insere a janela logo abaixo da camada do menu de contexto (o menu continua por cima). */
    fun attachBelow(menuLayer: View) {
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Atalhos do teclado físico (Ctrl+C/X/V/A, Delete, F2, F5, Enter, Backspace...). Retorna true se consumiu. */
    fun handleKey(ev: KeyEvent): Boolean {
        if (!open || minimized || !active || ev.action != KeyEvent.ACTION_DOWN) return false
        if (dlgLayer.visibility == View.VISIBLE) {
            if (ev.keyCode == KeyEvent.KEYCODE_ESCAPE) {
                closeDialog()
                return true
            }
            if ((ev.keyCode == KeyEvent.KEYCODE_ENTER || ev.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) &&
                act.currentFocus !is EditText
            ) {
                dlgOk?.invoke()
                return true
            }
            return false
        }
        if (act.currentFocus is EditText) {
            if (ev.keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (addrEdit.visibility == View.VISIBLE) stopAddrEdit() else searchBox.setText("")
                (act.currentFocus)?.clearFocus()
                hideKeyboard()
                return true
            }
            return false
        }
        val ctrl = ev.isCtrlPressed
        val shift = ev.isShiftPressed
        when (ev.keyCode) {
            KeyEvent.KEYCODE_C -> if (ctrl) { copySel(false); return true }
            KeyEvent.KEYCODE_X -> if (ctrl) { copySel(true); return true }
            KeyEvent.KEYCODE_V -> if (ctrl) { paste(); return true }
            KeyEvent.KEYCODE_A -> if (ctrl) { selectAll(); return true }
            KeyEvent.KEYCODE_F -> if (ctrl) { searchBox.requestFocus(); return true }
            KeyEvent.KEYCODE_L -> if (ctrl) { startAddrEdit(); return true }
            KeyEvent.KEYCODE_N -> if (ctrl && shift) { newFolder(); return true }
            KeyEvent.KEYCODE_DEL -> if (!ctrl) { goUp(); return true }
            KeyEvent.KEYCODE_FORWARD_DEL -> { deleteSel(); return true }
            KeyEvent.KEYCODE_F2 -> { renameSel(); return true }
            KeyEvent.KEYCODE_F5 -> { reload(); return true }
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                val s = selectedItems()
                if (s.size == 1) openItem(s[0]) else s.firstOrNull { it.isDir }?.let { navigate(it.path) }
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (ev.isAltPressed) { goBack(); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (ev.isAltPressed) { goForward(); return true }
            KeyEvent.KEYCODE_DPAD_UP -> if (ev.isAltPressed) { goUp(); return true }
            KeyEvent.KEYCODE_ESCAPE -> {
                if (selected.isNotEmpty()) {
                    clearSelection()
                    return true
                }
            }
        }
        return false
    }

    // ================================================================== animações

    private fun showAnimated() {
        win.animate().cancel()
        win.alpha = 0f
        win.scaleX = 0.96f
        win.scaleY = 0.96f
        win.visibility = View.INVISIBLE
        win.post {
            if (!open || minimized) return@post
            place()
            win.visibility = View.VISIBLE
            win.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        }
    }

    private fun hideAnimated() {
        win.animate().cancel()
        win.animate().alpha(0f).setDuration(110).withEndAction {
            if (!open || minimized) {
                win.visibility = View.GONE
                win.alpha = 1f
                win.scaleX = 1f
                win.scaleY = 1f
            }
        }.start()
    }

    // ================================================================== modos / tamanho / posição

    private fun screenW(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun screenH(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    private fun setMode(m: Int) {
        if (m == mode) return
        if (m == MODE_FULL) modeBeforeFull = if (mode == MODE_FULL) MODE_WINDOW else mode
        if (mode == MODE_WINDOW) {
            normX = win.x
            normY = win.y
        }
        mode = m
        sizeWindow()
        place()
    }

    private fun toggleMax() {
        setMode(if (mode == MODE_MAX) MODE_WINDOW else MODE_MAX)
    }

    private fun toggleFull() {
        setMode(if (mode == MODE_FULL) modeBeforeFull else MODE_FULL)
    }

    private fun sizeWindow() {
        val sw = screenW()
        val sh = screenH()
        val ins = taskbarInsets()
        if (normW == 0) {
            normW = minOf(sw - dp(24), dp(980))
            normH = minOf(sh - ins.first - ins.second - dp(40), dp(620))
        }
        val w: Int
        val h: Int
        when (mode) {
            MODE_MAX -> {
                w = sw
                h = sh - ins.first - ins.second
            }
            MODE_FULL -> {
                w = sw
                h = sh
            }
            else -> {
                w = normW.coerceIn(minOf(dp(320), sw), sw)
                h = normH.coerceIn(minOf(dp(280), sh), sh)
            }
        }
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        lp.height = h
        win.layoutParams = lp
        applyModeStyle()
        win.post { onResized() }
    }

    private fun applyModeStyle() {
        val full = mode == MODE_FULL
        val r = if (mode == MODE_WINDOW) 10 else 0
        val bg = GradientDrawable()
        bg.setColor(cWin)
        bg.cornerRadius = dp(r).toFloat()
        bg.setStroke(if (mode == MODE_WINDOW) dp(1) else 0, cLine)
        win.background = bg
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
                outline.alpha = 0.6f
            }
        }
        win.invalidateOutline()
        // tela cheia: some só a barra de título; os dois botões flutuantes (restaurar e fechar) aparecem no canto
        titleBar.visibility = if (full) View.GONE else View.VISIBLE
        navBar.setPadding(dp(6), 0, if (full) dp(84) else dp(6), 0)
        fsBar.visibility = if (full) View.VISIBLE else View.GONE
        grip.visibility = if (mode == MODE_WINDOW) View.VISIBLE else View.GONE
        maxBtn.setImageResource(if (mode == MODE_MAX) R.drawable.ic_restore else R.drawable.ic_maximize)
        fullBtn.setImageResource(R.drawable.ic_fullscreen)
    }

    private fun place() {
        when (mode) {
            MODE_MAX -> {
                win.x = 0f
                win.y = taskbarInsets().first.toFloat()
            }
            MODE_FULL -> {
                win.x = 0f
                win.y = 0f
            }
            else -> {
                if (!placed) {
                    normX = ((screenW() - win.width) / 2f).coerceAtLeast(dp(8).toFloat())
                    normY = ((screenH() - win.height) / 2f - dp(16)).coerceAtLeast(dp(8).toFloat())
                    placed = true
                }
                moveTo(normX, normY)
            }
        }
    }

    private fun moveTo(nx: Float, ny: Float) {
        if (mode != MODE_WINDOW) return
        val minX = -(win.width - dp(96)).toFloat()
        val maxX = (screenW() - dp(96)).toFloat()
        val maxY = (screenH() - dp(48)).toFloat().coerceAtLeast(0f)
        win.x = nx.coerceIn(minX, maxOf(minX, maxX))
        win.y = ny.coerceIn(0f, maxY)
        normX = win.x
        normY = win.y
    }

    /** A janela mudou de tamanho: barra lateral some em janelas estreitas e a grade refaz as colunas. */
    private fun onResized() {
        if (!open) return
        val narrow = win.width < dp(560)
        sidebar.visibility = if (narrow) View.GONE else View.VISIBLE
        sideDivider.visibility = sidebar.visibility
        val np = computePerRow()
        if (np != perRow) {
            perRow = np
            buildRows()
        }
        if (curDir == null) buildHome()
        updateDetailsHeader()
        adapter.notifyDataSetChanged()
    }

    private fun hideKeyboard() {
        try {
            val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(win.windowToken, 0)
        } catch (e: Exception) {
        }
    }

    private fun toast(s: String) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    }

    private fun rr(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)

    // ================================================================== construção da janela

    private fun build() {
        layer.tag = CursorController.NOHAND
        layer.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) active = false
            false
        }

        // dispatchTouchEvent (e não um listener comum): o listener não dispara quando um filho consome o toque
        win = object : FrameLayout(act) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) active = true
                return super.dispatchTouchEvent(ev)
            }
        }
        win.visibility = View.GONE
        win.tag = CursorController.NOHAND
        win.isClickable = true
        win.isFocusableInTouchMode = true
        win.elevation = dp(16).toFloat()
        win.clipToOutline = true

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        titleBar = buildTitleBar()
        col.addView(titleBar, lp(MATCH, dp(40)))
        navBar = buildNavBar()
        col.addView(navBar, lp(MATCH, dp(46)))
        cmdBar = buildCmdBar()
        col.addView(cmdBar, lp(MATCH, dp(44)))
        val line = View(act)
        line.setBackgroundColor(cLine)
        col.addView(line, lp(MATCH, dp(1)))

        val body = LinearLayout(act)
        body.orientation = LinearLayout.HORIZONTAL
        col.addView(body, lp(MATCH, 0, 1f))

        // ---- barra lateral
        sidebar = WheelScrollView(act, dp(40))
        sidebar.setBackgroundColor(cSide)
        sidebar.isVerticalScrollBarEnabled = false
        sidebar.overScrollMode = View.OVER_SCROLL_NEVER
        sideCol = LinearLayout(act)
        sideCol.orientation = LinearLayout.VERTICAL
        sideCol.setPadding(dp(6), dp(8), dp(6), dp(8))
        sidebar.addView(sideCol, FrameLayout.LayoutParams(MATCH, WRAP))
        body.addView(sidebar, lp(dp(190), MATCH))
        sideDivider = View(act)
        sideDivider.setBackgroundColor(cLine)
        body.addView(sideDivider, lp(dp(1), MATCH))

        // ---- conteúdo
        content = FrameLayout(act)
        content.setBackgroundColor(cWin)
        body.addView(content, lp(0, MATCH, 1f))

        listCol = LinearLayout(act)
        listCol.orientation = LinearLayout.VERTICAL
        detailsHeader = LinearLayout(act)
        detailsHeader.orientation = LinearLayout.HORIZONTAL
        detailsHeader.gravity = Gravity.CENTER_VERTICAL
        detailsHeader.setPadding(dp(4), 0, dp(4), 0)
        detailsHeader.visibility = View.GONE
        listCol.addView(detailsHeader, lp(MATCH, dp(30)))
        listView = ListView(act)
        listView.divider = null
        listView.dividerHeight = 0
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.cacheColorHint = Color.TRANSPARENT
        listView.overScrollMode = View.OVER_SCROLL_NEVER
        listView.clipToPadding = false
        listView.setPadding(dp(4), dp(2), dp(4), dp(8))
        listView.adapter = adapter
        var bgTrack = false
        var bgX = 0f
        var bgY = 0f
        // só recebe toques que NÃO caíram em um item: botão direito = menu da pasta; clique simples = limpa a seleção
        listView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val mouse = ev.isFromSource(InputDevice.SOURCE_MOUSE)
                    if (mouse && (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                        bgTrack = false
                        showBgMenu(ev.rawX.toInt(), ev.rawY.toInt())
                        return@setOnTouchListener true
                    }
                    bgTrack = true
                    bgX = ev.rawX
                    bgY = ev.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    val slop = ViewConfiguration.get(act).scaledTouchSlop
                    if (bgTrack && (Math.abs(ev.rawX - bgX) > slop || Math.abs(ev.rawY - bgY) > slop)) bgTrack = false
                }
                MotionEvent.ACTION_UP -> {
                    if (bgTrack && (ev.metaState and KeyEvent.META_CTRL_ON) == 0) clearSelection()
                    bgTrack = false
                }
                MotionEvent.ACTION_CANCEL -> bgTrack = false
            }
            false
        }
        listCol.addView(listView, lp(MATCH, 0, 1f))
        content.addView(listCol, FrameLayout.LayoutParams(MATCH, MATCH))

        homeScroll = WheelScrollView(act, dp(48))
        homeScroll.visibility = View.GONE
        homeScroll.overScrollMode = View.OVER_SCROLL_NEVER
        homeCol = LinearLayout(act)
        homeCol.orientation = LinearLayout.VERTICAL
        homeCol.setPadding(dp(16), dp(8), dp(16), dp(16))
        homeScroll.addView(homeCol, FrameLayout.LayoutParams(MATCH, WRAP))
        content.addView(homeScroll, FrameLayout.LayoutParams(MATCH, MATCH))

        msgBox = LinearLayout(act)
        msgBox.orientation = LinearLayout.VERTICAL
        msgBox.gravity = Gravity.CENTER
        msgBox.setPadding(dp(24), dp(24), dp(24), dp(24))
        msgBox.visibility = View.GONE
        msgText = TextView(act)
        msgText.setTextColor(sub)
        msgText.textSize = 14f
        msgText.gravity = Gravity.CENTER
        msgBox.addView(msgText, lp(WRAP, WRAP))
        msgBtn = TextView(act)
        msgBtn.setTextColor(Color.parseColor("#0B0B0B"))
        msgBtn.textSize = 13f
        msgBtn.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        msgBtn.setPadding(dp(18), dp(9), dp(18), dp(9))
        msgBtn.background = rr(accent, 6)
        msgBtn.isClickable = true
        msgBox.addView(msgBtn, lp(WRAP, WRAP).apply { topMargin = dp(14) })
        content.addView(msgBox, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---- barra de status
        val line2 = View(act)
        line2.setBackgroundColor(cLine)
        col.addView(line2, lp(MATCH, dp(1)))
        val status = LinearLayout(act)
        status.orientation = LinearLayout.HORIZONTAL
        status.gravity = Gravity.CENTER_VERTICAL
        status.setBackgroundColor(cBar)
        status.setPadding(dp(12), 0, dp(6), 0)
        statusText = TextView(act)
        statusText.setTextColor(sub)
        statusText.textSize = 12f
        statusText.maxLines = 1
        statusText.ellipsize = TextUtils.TruncateAt.END
        status.addView(statusText, lp(0, WRAP, 1f))
        status.addView(titleButton(R.drawable.ic_fm_details, false, 6) { setView(VIEW_DETAILS) }, lp(dp(30), dp(24)))
        status.addView(titleButton(R.drawable.ic_view, false, 6) { setView(VIEW_LARGE) }, lp(dp(30), dp(24)))
        col.addView(status, lp(MATCH, dp(28)))

        // canto inferior direito: redimensionar (só no modo janela)
        grip = GripView(act)
        grip.visibility = View.GONE
        win.addView(grip, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))
        var sx = 0f
        var sy = 0f
        var sw0 = 0
        var sh0 = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX
                    sy = ev.rawY
                    sw0 = win.width
                    sh0 = win.height
                }
                MotionEvent.ACTION_MOVE -> {
                    normW = (sw0 + (ev.rawX - sx)).toInt().coerceIn(dp(320), maxOf(dp(320), screenW() - win.x.toInt()))
                    normH = (sh0 + (ev.rawY - sy)).toInt().coerceIn(dp(280), maxOf(dp(280), screenH() - win.y.toInt()))
                    sizeWindow()
                }
            }
            true
        }

        // tela cheia: só dois botões discretos no canto superior direito (voltar para janela e fechar)
        fsBar = LinearLayout(act)
        fsBar.orientation = LinearLayout.HORIZONTAL
        fsBar.background = rr(Color.parseColor("#8C000000"), 10)
        fsBar.alpha = 0.7f
        fsBar.visibility = View.GONE
        fsBar.addView(titleButton(R.drawable.ic_maximize, false) { setMode(MODE_MAX) }, lp(dp(34), dp(30)))
        fsBar.addView(titleButton(R.drawable.ic_close, true) { close() }, lp(dp(34), dp(30)))
        win.addView(fsBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4)
            rightMargin = dp(4)
        })

        // diálogos (por cima de tudo, dentro da janela)
        dlgLayer = FrameLayout(act)
        dlgLayer.setBackgroundColor(Color.parseColor("#80000000"))
        dlgLayer.visibility = View.GONE
        dlgLayer.isClickable = true
        dlgLayer.setOnClickListener { if (!dlgModal) closeDialog() }
        win.addView(dlgLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        layer.addView(win, FrameLayout.LayoutParams(dp(900), dp(600), Gravity.TOP or Gravity.START))

        applyModeStyle()
        rebuildSidebar()
        updateDetailsHeader()
    }

    private fun buildTitleBar(): LinearLayout {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(cBar)
        bar.setPadding(dp(10), 0, dp(4), 0)

        val ic = ImageView(act)
        ic.setImageDrawable(act.filesIcon())
        titleIcon = ic
        bar.addView(ic, lp(dp(20), dp(20)))

        titleText = TextView(act)
        titleText.text = "Este PC"
        titleText.setTextColor(ink)
        titleText.textSize = 13f
        titleText.maxLines = 1
        titleText.ellipsize = TextUtils.TruncateAt.END
        titleText.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        bar.addView(titleText, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })

        bar.addView(titleButton(R.drawable.ic_minimize, false) { minimize() }, lp(dp(36), dp(34)))
        maxBtn = titleButton(R.drawable.ic_maximize, false) { toggleMax() }
        bar.addView(maxBtn, lp(dp(36), dp(34)))
        fullBtn = titleButton(R.drawable.ic_fullscreen, false) { toggleFull() }
        bar.addView(fullBtn, lp(dp(36), dp(34)))
        bar.addView(titleButton(R.drawable.ic_close, true) { close() }, lp(dp(36), dp(34)))

        var offX = 0f
        var offY = 0f
        var downX = 0f
        var downY = 0f
        var moved = false
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = win.x - ev.rawX
                    offY = win.y - ev.rawY
                    downX = ev.rawX
                    downY = ev.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(ev.rawX - downX) > dp(4) || Math.abs(ev.rawY - downY) > dp(4)) moved = true
                    moveTo(ev.rawX + offX, ev.rawY + offY)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastTitleTap < 350L) {
                            lastTitleTap = 0L
                            toggleMax()
                        } else {
                            lastTitleTap = now
                        }
                    }
                }
            }
            true
        }
        return bar
    }

    private fun buildNavBar(): LinearLayout {
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(cBar)
        bar.setPadding(dp(6), 0, dp(6), 0)

        backBtn = titleButton(R.drawable.ic_arrow_left, false) { goBack() }
        fwdBtn = titleButton(R.drawable.ic_arrow_right, false) { goForward() }
        upBtn = titleButton(R.drawable.ic_fm_up, false) { goUp() }
        val refresh = titleButton(R.drawable.ic_refresh, false) { reload() }
        bar.addView(backBtn, lp(dp(34), dp(34)))
        bar.addView(fwdBtn, lp(dp(34), dp(34)))
        bar.addView(upBtn, lp(dp(34), dp(34)))
        bar.addView(refresh, lp(dp(34), dp(34)))

        // caixa de caminho: breadcrumbs clicáveis; tocar na parte vazia (ou Ctrl+L) vira campo de texto
        val addrBox = FrameLayout(act)
        addrBox.background = rr(cField, 8)
        crumbScroll = HorizontalScrollView(act)
        crumbScroll.isHorizontalScrollBarEnabled = false
        crumbScroll.overScrollMode = View.OVER_SCROLL_NEVER
        crumbScroll.isFillViewport = true
        crumbRow = LinearLayout(act)
        crumbRow.orientation = LinearLayout.HORIZONTAL
        crumbRow.gravity = Gravity.CENTER_VERTICAL
        crumbRow.setPadding(dp(4), 0, dp(4), 0)
        crumbScroll.addView(crumbRow, FrameLayout.LayoutParams(WRAP, MATCH))
        addrBox.addView(crumbScroll, FrameLayout.LayoutParams(MATCH, MATCH))
        var cx = 0f
        var cy = 0f
        crumbScroll.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    cx = ev.x
                    cy = ev.y
                }
                MotionEvent.ACTION_UP -> {
                    val slop = ViewConfiguration.get(act).scaledTouchSlop
                    if (Math.abs(ev.x - cx) < slop && Math.abs(ev.y - cy) < slop) startAddrEdit()
                }
            }
            false
        }

        addrEdit = EditText(act)
        addrEdit.setTextColor(ink)
        addrEdit.setHintTextColor(sub)
        addrEdit.hint = "Digite um caminho"
        addrEdit.textSize = 13.5f
        addrEdit.setSingleLine(true)
        addrEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        addrEdit.imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        addrEdit.setSelectAllOnFocus(true)
        addrEdit.setPadding(dp(12), 0, dp(12), 0)
        addrEdit.background = rr(Color.TRANSPARENT, 8)
        addrEdit.visibility = View.GONE
        addrEdit.setOnEditorActionListener { _, _, _ ->
            commitAddrEdit()
            true
        }
        addrEdit.setOnFocusChangeListener { _, has ->
            if (!has && addrEdit.visibility == View.VISIBLE) stopAddrEdit()
        }
        addrBox.addView(addrEdit, FrameLayout.LayoutParams(MATCH, MATCH))
        bar.addView(addrBox, lp(0, dp(34), 1f).apply {
            leftMargin = dp(4)
            rightMargin = dp(6)
        })

        searchBox = EditText(act)
        searchBox.setTextColor(ink)
        searchBox.setHintTextColor(sub)
        searchBox.hint = "Pesquisar"
        searchBox.textSize = 13.5f
        searchBox.setSingleLine(true)
        searchBox.inputType = InputType.TYPE_CLASS_TEXT
        searchBox.imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        searchBox.setPadding(dp(10), 0, dp(10), 0)
        searchBox.background = rr(cField, 8)
        val si = act.getDrawable(R.drawable.ic_search)?.mutate()
        if (si != null) {
            si.setTint(sub)
            si.setBounds(0, 0, dp(16), dp(16))
            searchBox.setCompoundDrawablesRelative(si, null, null, null)
            searchBox.compoundDrawablePadding = dp(8)
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onSearchTyped(s?.toString() ?: "")
            }
        })
        searchBox.setOnEditorActionListener { _, _, _ ->
            val q = searchBox.text.toString().trim()
            if (q.isNotEmpty()) runSearch(q)
            hideKeyboard()
            releaseFocus()
            true
        }
        bar.addView(searchBox, lp(dp(170), dp(34)))
        return bar
    }

    // ---- barra de comandos

    private fun buildCmdBar(): HorizontalScrollView {
        val sv = HorizontalScrollView(act)
        sv.setBackgroundColor(cBar)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        cmdRow = LinearLayout(act)
        cmdRow.orientation = LinearLayout.HORIZONTAL
        cmdRow.gravity = Gravity.CENTER_VERTICAL
        cmdRow.setPadding(dp(8), dp(4), dp(8), dp(4))
        sv.addView(cmdRow, FrameLayout.LayoutParams(WRAP, MATCH))

        cmdRow.addView(cmdBtn("new", R.drawable.ic_plus, "Novo") { v -> showMenuUnder(v, newItems()) }, lp(WRAP, MATCH))
        cmdSep()
        cmdRow.addView(cmdBtn("cut", R.drawable.ic_fm_cut, null) { copySel(true) }, lp(dp(36), MATCH))
        cmdRow.addView(cmdBtn("copy", R.drawable.ic_fm_copy, null) { copySel(false) }, lp(dp(36), MATCH))
        cmdRow.addView(cmdBtn("paste", R.drawable.ic_fm_paste, null) { paste() }, lp(dp(36), MATCH))
        cmdRow.addView(cmdBtn("rename", R.drawable.ic_fm_rename, null) { renameSel() }, lp(dp(36), MATCH))
        cmdRow.addView(cmdBtn("share", R.drawable.ic_fm_share, null) { shareSel() }, lp(dp(36), MATCH))
        cmdRow.addView(cmdBtn("delete", R.drawable.ic_delete, null) { deleteSel() }, lp(dp(36), MATCH))
        cmdSep()
        cmdRow.addView(cmdBtn("zip", R.drawable.ic_fm_zip, "Compactar") { zipSel() }, lp(WRAP, MATCH))
        cmdSep()
        cmdRow.addView(cmdBtn("sort", R.drawable.ic_fm_sort, "Classificar") { v -> showMenuUnder(v, sortItems()) }, lp(WRAP, MATCH))
        cmdRow.addView(cmdBtn("view", R.drawable.ic_view, "Exibir") { v -> showMenuUnder(v, viewItems()) }, lp(WRAP, MATCH))
        cmdRow.addView(cmdBtn("more", R.drawable.ic_more, null) { v -> showMenuUnder(v, moreItems()) }, lp(dp(36), MATCH))
        return sv
    }

    private fun cmdSep() {
        val v = View(act)
        v.setBackgroundColor(cLine)
        cmdRow.addView(v, lp(dp(1), dp(20)).apply {
            leftMargin = dp(6)
            rightMargin = dp(6)
        })
    }

    private fun cmdBtn(key: String, res: Int, label: String?, onClick: (View) -> Unit): View {
        val b = LinearLayout(act)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER
        b.setPadding(dp(9), 0, dp(if (label != null) 12 else 9), 0)
        val iv = ImageView(act)
        iv.setImageResource(res)
        iv.setColorFilter(ink)
        b.addView(iv, lp(dp(18), dp(18)))
        if (label != null) {
            val t = TextView(act)
            t.text = label
            t.setTextColor(ink)
            t.textSize = 12.5f
            t.maxLines = 1
            b.addView(t, lp(WRAP, WRAP).apply { leftMargin = dp(7) })
        }
        b.isClickable = true
        b.background = btnBg(false, false)
        b.setOnHoverListener { v, ev ->
            if (v.isEnabled) {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_HOVER_ENTER -> v.background = btnBg(true, false)
                    MotionEvent.ACTION_HOVER_EXIT -> v.background = btnBg(false, false)
                }
            }
            false
        }
        b.setOnClickListener { v -> if (v.isEnabled) onClick(v) }
        cmdViews[key] = b
        return b
    }

    private fun setCmd(key: String, enabled: Boolean) {
        val v = cmdViews[key] ?: return
        v.isEnabled = enabled
        v.alpha = if (enabled) 1f else 0.38f
    }

    private fun showMenuUnder(v: View, items: List<MenuItem>) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        act.menu.show(items, loc[0], loc[1] + v.height)
    }

    // ---- botões e views auxiliares

    private fun titleButton(res: Int, danger: Boolean, pad: Int = 9, onClick: () -> Unit): ImageView {
        val b = ImageView(act)
        b.setImageResource(res)
        b.setColorFilter(ink)
        b.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        b.isClickable = true
        b.background = btnBg(false, danger)
        b.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> v.background = btnBg(true, danger)
                MotionEvent.ACTION_HOVER_EXIT -> v.background = btnBg(false, danger)
            }
            false
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun btnBg(hover: Boolean, danger: Boolean): GradientDrawable =
        rr(
            when {
                !hover -> Color.TRANSPARENT
                danger -> Color.parseColor("#40E5484D")
                else -> Color.parseColor("#26FFFFFF")
            },
            8
        )

    /** Tira o foco dos campos de texto sem deixar o Android passar o foco para a caixa de pesquisa. */
    private fun releaseFocus() {
        act.currentFocus?.clearFocus()
        win.requestFocus()
    }

    /** Alça de redimensionar: três tracinhos na diagonal. */
    private inner class GripView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            p.color = Color.parseColor("#80FFFFFF")
            p.strokeWidth = dp(1).toFloat()
            p.strokeCap = Paint.Cap.ROUND
            val w = width.toFloat()
            val h = height.toFloat()
            val m = dp(5).toFloat()
            for (i in 0..2) {
                val o = dp(5) * i.toFloat()
                c.drawLine(w - m, h - m - o - dp(4), w - m - o - dp(4), h - m, p)
            }
        }
    }

    // ================================================================== navegação

    private fun curPath(): String = curDir?.absolutePath ?: ""

    /** [path] null ou vazio = tela "Este PC". */
    private fun navigate(path: String?, push: Boolean = true) {
        val dest = path ?: ""
        if (push && open) {
            val cur = curPath()
            if (dest != cur) {
                back.add(cur)
                if (back.size > 100) back.removeAt(0)
                fwd.clear()
            }
        }
        setCurrent(dest)
        listView.setSelection(0)
    }

    private fun goBack() {
        if (back.isEmpty()) return
        val p = back.removeAt(back.size - 1)
        fwd.add(curPath())
        setCurrent(p)
        listView.setSelection(0)
    }

    private fun goForward() {
        if (fwd.isEmpty()) return
        val p = fwd.removeAt(fwd.size - 1)
        back.add(curPath())
        setCurrent(p)
        listView.setSelection(0)
    }

    private fun goUp() {
        val dir = curDir ?: return
        if (isRootDir(dir)) {
            navigate(null)
            return
        }
        val parent = dir.parentFile
        if (parent == null) navigate(null) else navigate(parent.absolutePath)
    }

    private fun reload() {
        if (curDir == null) {
            buildHome()
            rebuildSidebar()
            updateChrome()
        } else if (searching) {
            runSearch(query)
        } else {
            loadDir()
        }
    }

    private fun setCurrent(dest: String) {
        stopSearchTick()
        searching = false
        ++searchGen
        ++loadGen
        selected.clear()
        selectMode = false
        anchor = -1
        loadError = null
        loading = false
        allItems = emptyList()
        shown = emptyList()
        rows.clear()
        if (query.isNotEmpty() || searchBox.text.isNotEmpty()) {
            suppressSearch = true
            searchBox.setText("")
            suppressSearch = false
            query = ""
        }
        if (addrEdit.visibility == View.VISIBLE) stopAddrEdit()
        if (dest.isEmpty()) {
            curDir = null
            buildCrumbs()
            buildHome()
            adapter.notifyDataSetChanged()
            updateContentState()
            highlightSidebar()
            updateChrome()
        } else {
            curDir = File(dest)
            buildCrumbs()
            highlightSidebar()
            loadDir()
        }
    }

    // ================================================================== acesso aos arquivos

    private fun hasAccess(): Boolean = try {
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            act.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                act.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    } catch (t: Throwable) {
        true
    }

    private fun requestAccess() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + act.packageName))
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    act.startActivity(i)
                } catch (e: Exception) {
                    val i = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    act.startActivity(i)
                }
            } else {
                act.requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    REQ_STORAGE
                )
            }
        } catch (e: Exception) {
            toast("Não foi possível abrir as configurações de acesso aos arquivos.")
        }
    }

    private fun primaryRoot(): File = Environment.getExternalStorageDirectory()

    /** Está no armazenamento compartilhado (o que precisa da permissão de acesso aos arquivos)? */
    private fun isShared(f: File): Boolean {
        val p = f.absolutePath
        return p.startsWith(primaryRoot().absolutePath) || p.startsWith("/storage/") || p.startsWith("/sdcard")
    }

    /** Raiz de um armazenamento (ou do sistema): não pode ser excluída, movida nem renomeada. */
    private fun isRootDir(f: File): Boolean {
        val p = f.absolutePath
        if (p == "/" || p == "/storage" || p == primaryRoot().absolutePath) return true
        for (dr in driveCache) if (dr.dir.absolutePath == p) return true
        return false
    }

    // ================================================================== carregar a pasta

    private fun loadDir() {
        val dir = curDir ?: return
        val gen = ++loadGen
        loadError = null
        if (!hasAccess() && isShared(dir)) {
            loading = false
            loadError = ERR_ACCESS
            allItems = emptyList()
            applySortFilter()
            buildRows()
            return
        }
        loading = true
        updateContentState()
        updateChrome()
        io {
            val list = ArrayList<FItem>()
            var err: String? = null
            try {
                val kids = dir.listFiles()
                if (kids == null) {
                    err = if (!dir.exists()) "Esta pasta não existe mais." else "Não foi possível abrir esta pasta."
                } else {
                    for (k in kids) {
                        val isD = k.isDirectory
                        list.add(FItem(k, k.name, isD, if (isD) 0L else k.length(), k.lastModified()))
                    }
                }
            } catch (t: Throwable) {
                err = "Não foi possível abrir esta pasta."
            }
            handler.post {
                if (gen != loadGen || !open || curDir == null) return@post
                loading = false
                loadError = err
                allItems = list
                if (selected.isNotEmpty()) {
                    val exists = HashSet<String>()
                    for (i in list) exists.add(i.path)
                    selected.retainAll(exists)
                    if (selected.isEmpty()) selectMode = false
                }
                applySortFilter()
                buildRows()
                applyPending()
            }
        }
    }

    /** Depois de criar/renomear: seleciona o item novo e rola até ele. */
    private fun applyPending() {
        val p = pendingSelect ?: return
        pendingSelect = null
        val idx = shown.indexOfFirst { it.path == p }
        if (idx < 0) return
        selected.clear()
        selected.add(p)
        anchor = idx
        selectMode = false
        adapter.notifyDataSetChanged()
        updateChrome()
        val r = rows.indexOfFirst { it.header == null && idx >= it.start && idx < it.start + it.count }
        if (r >= 0) listView.post { listView.setSelectionFromTop(r, dp(40)) }
    }

    // ================================================================== ordenar, filtrar, agrupar

    private fun comparator(): Comparator<FItem> {
        val dir = if (sortAsc) 1 else -1
        return Comparator { a, b ->
            if (sortKey != SORT_DATE && a.isDir != b.isDir) return@Comparator if (a.isDir) -1 else 1
            var r = when (sortKey) {
                SORT_DATE -> a.mod.compareTo(b.mod)
                SORT_TYPE -> FKind.typeName(a.name, a.isDir).compareTo(FKind.typeName(b.name, b.isDir), true)
                SORT_SIZE -> a.size.compareTo(b.size)
                else -> 0
            }
            if (r == 0) r = FileOps.natural.compare(a.name, b.name)
            r * dir
        }
    }

    private fun applySortFilter() {
        var l: List<FItem> = allItems
        if (!showHidden) l = l.filter { !it.name.startsWith(".") }
        if (query.isNotEmpty() && !searching) l = l.filter { it.name.contains(query, ignoreCase = true) }
        shown = l.sortedWith(comparator())
        if (anchor >= shown.size) anchor = -1
    }

    private class DateRef {
        val today: Long
        val yesterday: Long
        val week: Long
        val lastWeek: Long
        val month: Long
        val lastMonth: Long
        val year: Long

        init {
            val c = Calendar.getInstance()
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            today = c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, -1)
            yesterday = c.timeInMillis
            c.timeInMillis = today
            c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            if (c.timeInMillis > today) c.add(Calendar.DAY_OF_YEAR, -7)
            week = c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, -7)
            lastWeek = c.timeInMillis
            c.timeInMillis = today
            c.set(Calendar.DAY_OF_MONTH, 1)
            month = c.timeInMillis
            c.add(Calendar.MONTH, -1)
            lastMonth = c.timeInMillis
            c.timeInMillis = today
            c.set(Calendar.DAY_OF_YEAR, 1)
            year = c.timeInMillis
        }

        fun bucket(m: Long): String = when {
            m >= today -> "Hoje"
            m >= yesterday -> "Ontem"
            m >= week -> "Esta semana"
            m >= lastWeek -> "Semana passada"
            m >= month -> "Este mês"
            m >= lastMonth -> "Mês passado"
            m >= year -> "No início deste ano"
            else -> "Há muito tempo"
        }
    }

    /** Largura da área da lista, calculada pela janela (não depende de a tela já ter sido medida). */
    private fun contentWidth(): Int {
        var w = win.width
        if (w <= 0) w = (win.layoutParams?.width ?: 0)
        if (w <= 0) w = minOf(screenW() - dp(24), dp(980))
        val side = if (sidebar.visibility == View.VISIBLE) dp(191) else 0
        return maxOf(dp(200), w - side)
    }

    private fun computePerRow(): Int {
        val w = contentWidth() - dp(14)
        return when (viewMode) {
            VIEW_LARGE -> maxOf(1, w / dp(104))
            VIEW_MEDIUM -> maxOf(1, w / dp(88))
            VIEW_LIST -> maxOf(1, w / dp(220))
            else -> 1
        }
    }

    private fun buildRows() {
        rows.clear()
        perRow = computePerRow()
        val n = shown.size
        if (n > 0) {
            val group = sortKey == SORT_DATE
            val ref = DateRef()
            var i = 0
            var last: String? = null
            while (i < n) {
                var end = i + 1
                if (group) {
                    val b = ref.bucket(shown[i].mod)
                    if (b != last) {
                        rows.add(Row(b, 0, 0))
                        last = b
                    }
                    while (end < n && end - i < perRow && ref.bucket(shown[end].mod) == b) end++
                } else {
                    while (end < n && end - i < perRow) end++
                }
                rows.add(Row(null, i, end - i))
                i = end
            }
        }
        adapter.notifyDataSetChanged()
        updateDetailsHeader()
        updateContentState()
        updateChrome()
    }

    private fun setView(m: Int) {
        viewMode = m
        store.edit().putInt("fm_view", m).apply()
        if (curDir != null) buildRows()
        else updateDetailsHeader()
    }

    private fun setSort(key: Int) {
        if (sortKey == key) {
            sortAsc = !sortAsc
        } else {
            sortKey = key
            sortAsc = key == SORT_NAME || key == SORT_TYPE
        }
        store.edit().putInt("fm_sort", sortKey).putBoolean("fm_asc", sortAsc).apply()
        applySortFilter()
        buildRows()
    }

    private fun setSortDir(asc: Boolean) {
        sortAsc = asc
        store.edit().putBoolean("fm_asc", sortAsc).apply()
        applySortFilter()
        buildRows()
    }

    private fun setShowHidden(v: Boolean) {
        showHidden = v
        store.edit().putBoolean("fm_hidden", v).apply()
        applySortFilter()
        buildRows()
    }

    // ================================================================== pesquisa

    private fun onSearchTyped(text: String) {
        if (suppressSearch) return
        val q = text.trim()
        if (q == query) return
        query = q
        if (searching) {
            // editou o texto durante uma pesquisa recursiva: volta para a pasta e filtra por ela
            searching = false
            ++searchGen
            stopSearchTick()
            if (curDir != null) loadDir()
            return
        }
        if (curDir == null) return
        applySortFilter()
        buildRows()
    }

    private fun stopSearchTick() {
        searchTick?.let { handler.removeCallbacks(it) }
        searchTick = null
    }

    /** Pesquisa recursiva a partir da pasta atual (ou do armazenamento interno, em "Este PC"). */
    private fun runSearch(q: String) {
        val text = q.trim()
        if (text.isEmpty()) return
        if (!hasAccess()) {
            requestAccess()
            return
        }
        val base = curDir ?: primaryRoot()
        if (curDir == null) {
            curDir = base
            buildCrumbs()
            highlightSidebar()
        }
        stopSearchTick()
        val gen = ++searchGen
        ++loadGen
        searching = true
        searchDone = false
        query = text
        selected.clear()
        selectMode = false
        anchor = -1
        loadError = null
        loading = false
        allItems = emptyList()
        applySortFilter()
        buildRows()

        val found = ArrayList<FItem>()
        val finished = java.util.concurrent.atomic.AtomicBoolean(false)
        val needle = text.lowercase()
        val hidden = showHidden
        io {
            val stack = ArrayList<File>()
            stack.add(base)
            while (stack.isNotEmpty() && gen == searchGen) {
                val d = stack.removeAt(stack.size - 1)
                val kids: Array<File>? = try {
                    d.listFiles()
                } catch (t: Throwable) {
                    null
                }
                if (kids == null) continue
                for (k in kids) {
                    if (gen != searchGen) break
                    val nm = k.name
                    if (!hidden && nm.startsWith(".")) continue
                    val isD = k.isDirectory
                    if (nm.lowercase().contains(needle)) {
                        val item = FItem(k, nm, isD, if (isD) 0L else k.length(), k.lastModified())
                        synchronized(found) { found.add(item) }
                        if (found.size >= 3000) {
                            stack.clear()
                            break
                        }
                    }
                    if (isD) {
                        val link = try {
                            java.nio.file.Files.isSymbolicLink(k.toPath())
                        } catch (t: Throwable) {
                            false
                        }
                        if (!link) stack.add(k)
                    }
                }
            }
            finished.set(true)
        }
        val tick = object : Runnable {
            override fun run() {
                if (gen != searchGen || !open) return
                val snap = synchronized(found) { ArrayList(found) }
                val done = finished.get()
                allItems = snap
                searchDone = done
                if (done) searchTick = null
                applySortFilter()
                buildRows()
                if (!done) handler.postDelayed(this, 500)
            }
        }
        searchTick = tick
        handler.postDelayed(tick, 400)
    }

    /** "Abrir local do arquivo": sai da pesquisa e seleciona o item na pasta dele. */
    private fun revealItem(f: FItem) {
        val parent = f.file.parentFile ?: return
        pendingSelect = f.path
        navigate(parent.absolutePath)
    }

    // ================================================================== caminho (breadcrumbs / digitar)

    private fun buildCrumbs() {
        crumbRow.removeAllViews()
        val dir = curDir
        if (dir == null) {
            crumbRow.addView(crumb("Este PC", null), lp(WRAP, MATCH))
            return
        }
        crumbRow.addView(crumb("Início", ""), lp(WRAP, MATCH))
        var acc = ""
        for (seg in dir.absolutePath.split('/')) {
            if (seg.isEmpty()) continue
            acc = "$acc/$seg"
            val sep = TextView(act)
            sep.text = "›"
            sep.setTextColor(sub)
            sep.textSize = 14f
            sep.gravity = Gravity.CENTER
            crumbRow.addView(sep, lp(dp(14), MATCH))
            crumbRow.addView(crumb(seg, acc), lp(WRAP, MATCH))
        }
        crumbScroll.post { crumbScroll.fullScroll(View.FOCUS_RIGHT) }
    }

    /** [target]: null = rótulo sem clique; "" = Este PC; senão caminho. */
    private fun crumb(label: String, target: String?): TextView {
        val t = TextView(act)
        t.text = label
        t.setTextColor(ink)
        t.textSize = 13f
        t.maxLines = 1
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), 0, dp(8), 0)
        if (target != null) {
            t.isClickable = true
            t.setOnClickListener { navigate(target) }
            t.setOnHoverListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_HOVER_ENTER -> v.background = rr(Color.parseColor("#22FFFFFF"), 6)
                    MotionEvent.ACTION_HOVER_EXIT -> v.background = null
                }
                false
            }
        }
        return t
    }

    private fun startAddrEdit() {
        if (addrEdit.visibility == View.VISIBLE) return
        crumbScroll.visibility = View.GONE
        addrEdit.visibility = View.VISIBLE
        addrEdit.setText(curDir?.absolutePath ?: "")
        addrEdit.requestFocus()
        addrEdit.selectAll()
        try {
            val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(addrEdit, InputMethodManager.SHOW_IMPLICIT)
        } catch (e: Exception) {
        }
    }

    private fun stopAddrEdit() {
        addrEdit.visibility = View.GONE
        crumbScroll.visibility = View.VISIBLE
        hideKeyboard()
        releaseFocus()
    }

    private fun commitAddrEdit() {
        val t = addrEdit.text.toString().trim()
        stopAddrEdit()
        if (t.isEmpty() || t.equals("Este PC", ignoreCase = true) || t.equals("Início", ignoreCase = true)) {
            navigate(null)
            return
        }
        val f = File(t)
        when {
            f.isDirectory -> navigate(f.absolutePath)
            f.exists() -> {
                pendingSelect = f.absolutePath
                navigate(f.parentFile?.absolutePath ?: "")
            }
            else -> toast("Caminho não encontrado.")
        }
    }

    // ================================================================== lista, linhas e células

    private fun colFlags(): Int {
        val w = contentWidth()
        var f = 0
        if (w >= dp(300)) f = f or 4 // tamanho
        if (w >= dp(440)) f = f or 1 // data
        if (w >= dp(580)) f = f or 2 // tipo
        return f
    }

    private fun adapterKey(): Int = viewMode * 10000 + perRow * 10 + (if (viewMode == VIEW_DETAILS) colFlags() else 0)

    private fun rowHeightDp(): Int = when (viewMode) {
        VIEW_LARGE -> 108
        VIEW_MEDIUM -> 88
        VIEW_LIST -> 30
        else -> 32
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size

        override fun getItem(position: Int): Any = rows[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getViewTypeCount(): Int = 2

        override fun getItemViewType(position: Int): Int = if (rows[position].header != null) 0 else 1

        override fun areAllItemsEnabled(): Boolean = false

        override fun isEnabled(position: Int): Boolean = false

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = rows[position]
            if (r.header != null) {
                val tv = (convertView as? TextView) ?: TextView(act).also {
                    it.setTextColor(ink)
                    it.textSize = 13f
                    it.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    it.setPadding(dp(10), dp(12), dp(10), dp(4))
                    it.layoutParams = AbsListView.LayoutParams(MATCH, WRAP)
                }
                tv.text = r.header
                return tv
            }
            val key = adapterKey()
            val existing = convertView as? RowView
            val rv = if (existing != null && existing.key == key) existing else RowView(key)
            rv.bind(r)
            return rv
        }
    }

    private inner class RowView(val key: Int) : LinearLayout(act) {
        private val cells = ArrayList<Cell>()

        init {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = AbsListView.LayoutParams(MATCH, dp(rowHeightDp()))
            val n = if (viewMode == VIEW_DETAILS) 1 else maxOf(1, perRow)
            for (i in 0 until n) {
                val c = Cell()
                cells.add(c)
                addView(c, LinearLayout.LayoutParams(0, MATCH, 1f))
            }
        }

        fun bind(r: Row) {
            for (i in cells.indices) {
                val idx = r.start + i
                if (i < r.count && idx < shown.size) {
                    cells[i].visibility = View.VISIBLE
                    cells[i].bind(shown[idx], idx)
                } else {
                    cells[i].visibility = View.INVISIBLE
                }
            }
        }
    }

    private inner class Cell : FrameLayout(act) {
        private val vm = viewMode
        private val flags = colFlags()
        private val body = LinearLayout(act)
        private val icon = ImageView(act)
        private val name = TextView(act)
        private val chk = ImageView(act)
        private var dateT: TextView? = null
        private var typeT: TextView? = null
        private var sizeT: TextView? = null
        private var item: FItem? = null
        private var idx = -1
        private var hover = false
        private var rightDown = false

        private fun addCol(wDp: Int, endAlign: Boolean): TextView {
            val t = TextView(act)
            t.setTextColor(sub)
            t.textSize = 12.5f
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = (if (endAlign) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
            t.setPadding(dp(6), 0, dp(6), 0)
            body.addView(t, LinearLayout.LayoutParams(dp(wDp), MATCH))
            return t
        }

        init {
            isClickable = true
            isLongClickable = true
            val big = vm == VIEW_LARGE || vm == VIEW_MEDIUM
            name.setTextColor(ink)
            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            if (big) {
                body.orientation = LinearLayout.VERTICAL
                body.gravity = Gravity.CENTER_HORIZONTAL
                body.setPadding(dp(4), dp(6), dp(4), dp(4))
                val isz = dp(if (vm == VIEW_LARGE) 56 else 40)
                body.addView(icon, LinearLayout.LayoutParams(isz, isz))
                name.textSize = 12f
                name.maxLines = 2
                name.gravity = Gravity.CENTER_HORIZONTAL
                name.ellipsize = TextUtils.TruncateAt.END
                body.addView(name, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
            } else {
                body.orientation = LinearLayout.HORIZONTAL
                body.gravity = Gravity.CENTER_VERTICAL
                body.setPadding(dp(22), 0, dp(8), 0)
                body.addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
                name.textSize = 13f
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.END
                body.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })
                if (vm == VIEW_DETAILS) {
                    if ((flags and 1) != 0) dateT = addCol(130, false)
                    if ((flags and 2) != 0) typeT = addCol(110, false)
                    if ((flags and 4) != 0) sizeT = addCol(80, true)
                }
            }
            addView(body, FrameLayout.LayoutParams(MATCH, MATCH))

            chk.setImageResource(R.drawable.ic_fm_check)
            chk.setColorFilter(accent)
            chk.visibility = View.GONE
            val g = if (big) (Gravity.TOP or Gravity.START) else (Gravity.CENTER_VERTICAL or Gravity.START)
            addView(chk, FrameLayout.LayoutParams(dp(16), dp(16), g).apply {
                leftMargin = dp(4)
                if (big) topMargin = dp(4)
            })

            setOnClickListener { item?.let { onItemClick(it, idx) } }
            setOnLongClickListener {
                val fi = item
                if (fi == null || lastMouse) {
                    false
                } else {
                    onItemLongPress(fi, idx)
                    true
                }
            }
            setOnHoverListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_HOVER_ENTER -> {
                        hover = true
                        paintBg()
                    }
                    MotionEvent.ACTION_HOVER_EXIT -> {
                        hover = false
                        paintBg()
                    }
                }
                false
            }
            setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                    lastMouse = ev.isFromSource(InputDevice.SOURCE_MOUSE)
                    lastCtrl = (ev.metaState and KeyEvent.META_CTRL_ON) != 0
                    lastShift = (ev.metaState and KeyEvent.META_SHIFT_ON) != 0
                    lastRawX = ev.rawX
                    lastRawY = ev.rawY
                    rightDown = lastMouse && (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
                    if (rightDown) item?.let { onItemRightClick(it, idx, ev.rawX.toInt(), ev.rawY.toInt()) }
                }
                rightDown
            }
        }

        private fun paintBg() {
            val sel = item?.let { selected.contains(it.path) } == true
            background = when {
                sel -> rr(cSel, 6)
                hover -> rr(cHover, 6)
                else -> null
            }
        }

        fun bind(fi: FItem, index: Int) {
            item = fi
            idx = index
            name.text = fi.name
            val sel = selected.contains(fi.path)
            chk.visibility = if (selectMode && sel) View.VISIBLE else View.GONE
            body.alpha = if (clipCut && clipSet.contains(fi.path)) 0.5f else 1f
            icon.tag = null
            icon.setImageDrawable(KindDrawable(fi.kind, fi.ext))
            if (vm == VIEW_LARGE) requestThumb(fi, icon, dp(96)) else if (vm == VIEW_MEDIUM) requestThumb(fi, icon, dp(72))
            dateT?.text = FileOps.fmtDate(fi.mod)
            typeT?.text = FKind.typeName(fi.name, fi.isDir)
            sizeT?.text = if (fi.isDir) "" else FileOps.fmtSize(fi.size)
            hover = false
            paintBg()
        }
    }

    // ---- miniaturas

    private fun requestThumb(fi: FItem, iv: ImageView, sz: Int) {
        if (fi.kind != FKind.IMAGE && fi.kind != FKind.VIDEO && fi.kind != FKind.APK) return
        val key = fi.path + "|" + fi.mod + "|" + sz
        iv.tag = key
        val cached = thumbs.get(key)
        if (cached != null) {
            iv.setImageBitmap(cached)
            return
        }
        if (thumbFail.contains(key)) return
        val e = thumbExec ?: Executors.newFixedThreadPool(2).also { thumbExec = it }
        try {
            e.execute {
                if (iv.tag != key) return@execute // a linha foi reaproveitada: não decodifica
                val bmp = try {
                    loadThumb(fi, sz)
                } catch (t: Throwable) {
                    null
                }
                handler.post {
                    if (!open) return@post
                    if (bmp != null) {
                        thumbs.put(key, bmp)
                        if (iv.tag == key) iv.setImageBitmap(bmp)
                    } else {
                        thumbFail.add(key)
                    }
                }
            }
        } catch (t: Throwable) {
        }
    }

    private fun fitBitmap(b: Bitmap, sz: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= sz) return b
        val s = sz.toFloat() / m
        val out = Bitmap.createScaledBitmap(b, maxOf(1, (b.width * s).toInt()), maxOf(1, (b.height * s).toInt()), true)
        if (out !== b) b.recycle()
        return out
    }

    private fun loadThumb(fi: FItem, sz: Int): Bitmap? {
        when (fi.kind) {
            FKind.IMAGE -> {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(fi.path, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) return null
                var s = 1
                while (o.outWidth / (s * 2) >= sz && o.outHeight / (s * 2) >= sz) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                val b = BitmapFactory.decodeFile(fi.path, o2) ?: return null
                return fitBitmap(b, sz)
            }
            FKind.VIDEO -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(fi.path)
                    val f = r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
                    return fitBitmap(f, sz)
                } finally {
                    try {
                        r.release()
                    } catch (t: Throwable) {
                    }
                }
            }
            FKind.APK -> {
                val pm = act.packageManager
                val pi = pm.getPackageArchiveInfo(fi.path, 0) ?: return null
                val ai = pi.applicationInfo ?: return null
                ai.sourceDir = fi.path
                ai.publicSourceDir = fi.path
                val dr = ai.loadIcon(pm) ?: return null
                val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
                dr.setBounds(0, 0, sz, sz)
                dr.draw(Canvas(b))
                return b
            }
        }
        return null
    }

    // ---- cabeçalho do modo detalhes

    private fun hdr(label: String, key: Int, wDp: Int, end: Boolean): TextView {
        val t = TextView(act)
        t.text = if (sortKey == key) label + (if (sortAsc) "  ↑" else "  ↓") else label
        t.setTextColor(if (sortKey == key) accent else sub)
        t.textSize = 12f
        t.maxLines = 1
        t.gravity = (if (end) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        t.setPadding(if (wDp == 0) dp(50) else dp(6), 0, dp(6), 0)
        t.isClickable = true
        t.setOnClickListener { setSort(key) }
        return t
    }

    private fun updateDetailsHeader() {
        detailsHeader.removeAllViews()
        val show = viewMode == VIEW_DETAILS && curDir != null && shown.isNotEmpty()
        detailsHeader.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        val f = colFlags()
        detailsHeader.addView(hdr("Nome", SORT_NAME, 0, false), lp(0, MATCH, 1f))
        if ((f and 1) != 0) detailsHeader.addView(hdr("Data de modificação", SORT_DATE, 130, false), lp(dp(130), MATCH))
        if ((f and 2) != 0) detailsHeader.addView(hdr("Tipo", SORT_TYPE, 110, false), lp(dp(110), MATCH))
        if ((f and 4) != 0) detailsHeader.addView(hdr("Tamanho", SORT_SIZE, 80, true), lp(dp(80), MATCH))
    }

    // ================================================================== estado do conteúdo e da janela

    private fun updateContentState() {
        val home = curDir == null
        homeScroll.visibility = if (home) View.VISIBLE else View.GONE
        if (home) {
            listCol.visibility = View.GONE
            msgBox.visibility = View.GONE
            return
        }
        val err = loadError
        var text: String? = null
        var btn: String? = null
        when {
            err == ERR_ACCESS -> {
                text = "Para ver e gerenciar seus arquivos, o WinLauncher precisa de acesso a todos os arquivos deste aparelho."
                btn = "Conceder acesso"
            }
            err != null -> text = err
            loading -> {
            }
            shown.isEmpty() -> text = when {
                searching && !searchDone -> "Pesquisando…"
                searching -> "Nenhum resultado encontrado."
                query.isNotEmpty() -> "Nenhum item corresponde à pesquisa."
                allItems.isNotEmpty() -> "Não há nada para mostrar (os arquivos ocultos estão escondidos)."
                else -> "Esta pasta está vazia."
            }
        }
        if (text == null) {
            msgBox.visibility = View.GONE
            listCol.visibility = View.VISIBLE
            return
        }
        msgText.text = text
        if (btn != null) {
            msgBtn.text = btn
            msgBtn.setOnClickListener { requestAccess() }
            msgBtn.visibility = View.VISIBLE
        } else {
            msgBtn.visibility = View.GONE
        }
        msgBox.visibility = View.VISIBLE
        listCol.visibility = if (err != null) View.GONE else View.VISIBLE
    }

    private fun enable(v: View, on: Boolean) {
        v.isEnabled = on
        v.alpha = if (on) 1f else 0.38f
    }

    private fun updateChrome() {
        val dir = curDir
        titleText.text = when {
            dir == null -> "Este PC"
            dir.absolutePath == primaryRoot().absolutePath -> "Armazenamento interno"
            else -> dir.name.ifEmpty { "/" }
        }
        enable(backBtn, back.isNotEmpty())
        enable(fwdBtn, fwd.isNotEmpty())
        enable(upBtn, dir != null)

        val sel = selectedItems()
        statusText.text = when {
            dir == null -> "${specialFolders().size + driveCache.size} itens"
            loading -> "Carregando…"
            sel.isNotEmpty() -> {
                var bytes = 0L
                var files = 0
                for (i in sel) if (!i.isDir) {
                    bytes += i.size
                    files++
                }
                (if (sel.size == 1) "1 item selecionado" else "${sel.size} itens selecionados") +
                    (if (files > 0) "   " + FileOps.fmtSize(bytes) else "")
            }
            searching -> "${shown.size} " + (if (shown.size == 1) "resultado" else "resultados") + (if (searchDone) "" else " (pesquisando…)")
            else -> "${shown.size} " + (if (shown.size == 1) "item" else "itens")
        }

        val hasDir = dir != null
        val edit = hasDir && !searching
        setCmd("new", edit)
        setCmd("cut", sel.isNotEmpty())
        setCmd("copy", sel.isNotEmpty())
        setCmd("paste", edit && clip.isNotEmpty())
        setCmd("rename", sel.size == 1)
        setCmd("share", sel.any { !it.isDir })
        setCmd("delete", sel.isNotEmpty())
        setCmd("zip", sel.isNotEmpty())
        setCmd("sort", hasDir)
        setCmd("view", true)
        setCmd("more", true)
    }

    // ================================================================== Este PC

    private class Special(val label: String, val kind: Int, val dir: File)

    @Suppress("DEPRECATION")
    private fun specialFolders(): List<Special> = listOf(
        Special("Downloads", FKind.S_DOWNLOADS, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)),
        Special("Documentos", FKind.S_DOCUMENTS, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)),
        Special("Imagens", FKind.S_PICTURES, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)),
        Special("Músicas", FKind.S_MUSIC, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)),
        Special("Vídeos", FKind.S_VIDEOS, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES))
    )

    private fun volumeLabel(f: File): String {
        val removable = try {
            Environment.isExternalStorageRemovable(f)
        } catch (t: Throwable) {
            true
        }
        return (if (removable) "Disco removível" else "Armazenamento") + " (" + f.name + ")"
    }

    private fun drives(): List<Drive> {
        val out = ArrayList<Drive>()
        val seen = HashSet<String>()
        val prim = primaryRoot()
        out.add(Drive("Armazenamento interno", prim))
        seen.add(prim.absolutePath)
        try {
            for (f in act.getExternalFilesDirs(null)) {
                if (f == null) continue
                val p = f.absolutePath
                val i = p.indexOf("/Android/")
                if (i <= 0) continue
                val r = File(p.substring(0, i))
                if (seen.add(r.absolutePath)) out.add(Drive(volumeLabel(r), r))
            }
        } catch (t: Throwable) {
        }
        try {
            val kids = File("/storage").listFiles()
            if (kids != null) {
                for (f in kids) {
                    if (!f.isDirectory || f.name == "emulated" || f.name == "self") continue
                    if (f.canRead() && seen.add(f.absolutePath)) out.add(Drive(volumeLabel(f), f))
                }
            }
        } catch (t: Throwable) {
        }
        out.add(Drive("Sistema (/)", File("/")))
        return out
    }

    private fun fmtGb(b: Long): String {
        val pt = java.util.Locale("pt", "BR")
        val gb = b / 1073741824.0
        return if (gb >= 1.0) String.format(pt, "%.1f GB", gb) else String.format(pt, "%.0f MB", b / 1048576.0)
    }

    private fun homeTitle(text: String): TextView {
        val t = TextView(act)
        t.text = text
        t.setTextColor(ink)
        t.textSize = 13f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dp(2), dp(10), 0, dp(8))
        return t
    }

    private fun tileStyle(v: View, base: Int, onClick: () -> Unit) {
        v.isClickable = true
        v.background = rr(base, 8)
        v.setOnHoverListener { x, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> x.background = rr(Color.parseColor("#26FFFFFF"), 8)
                MotionEvent.ACTION_HOVER_EXIT -> x.background = rr(base, 8)
            }
            false
        }
        v.setOnClickListener { onClick() }
    }

    private fun tileGrid(tiles: List<View>, avail: Int, minW: Int): LinearLayout {
        val per = maxOf(1, avail / minW)
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until per) {
                val k = i + j
                if (k < tiles.size) {
                    row.addView(tiles[k], lp(0, WRAP, 1f).apply {
                        rightMargin = dp(6)
                        bottomMargin = dp(6)
                    })
                } else {
                    row.addView(View(act), lp(0, 1, 1f).apply { rightMargin = dp(6) })
                }
            }
            col.addView(row, lp(MATCH, WRAP))
            i += per
        }
        return col
    }

    private fun folderTile(s: Special): View {
        val t = LinearLayout(act)
        t.orientation = LinearLayout.HORIZONTAL
        t.gravity = Gravity.CENTER_VERTICAL
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        val iv = ImageView(act)
        iv.setImageDrawable(KindDrawable(s.kind))
        t.addView(iv, lp(dp(32), dp(32)))
        val tx = TextView(act)
        tx.text = s.label
        tx.setTextColor(ink)
        tx.textSize = 13f
        tx.maxLines = 1
        tx.ellipsize = TextUtils.TruncateAt.END
        t.addView(tx, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        tileStyle(t, Color.TRANSPARENT) { navigate(s.dir.absolutePath) }
        return t
    }

    private fun driveTile(dr: Drive): View {
        var total = 0L
        var free = 0L
        try {
            val sf = StatFs(dr.dir.absolutePath)
            total = sf.totalBytes
            free = sf.availableBytes
        } catch (t: Throwable) {
        }
        val t = LinearLayout(act)
        t.orientation = LinearLayout.HORIZONTAL
        t.gravity = Gravity.CENTER_VERTICAL
        t.setPadding(dp(12), dp(12), dp(12), dp(12))
        val iv = ImageView(act)
        iv.setImageDrawable(KindDrawable(FKind.DRIVE))
        t.addView(iv, lp(dp(48), dp(48)))
        val info = LinearLayout(act)
        info.orientation = LinearLayout.VERTICAL
        val nm = TextView(act)
        nm.text = dr.label
        nm.setTextColor(ink)
        nm.textSize = 13f
        nm.maxLines = 1
        nm.ellipsize = TextUtils.TruncateAt.END
        info.addView(nm, lp(MATCH, WRAP))
        if (total > 0) {
            val frac = ((total - free).toDouble() / total).coerceIn(0.0, 1.0)
            val bar = LinearLayout(act)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.background = rr(Color.parseColor("#3A3A3A"), 3)
            val used = maxOf(1, (frac * 1000).toInt())
            val fill = View(act)
            fill.background = rr(if (frac > 0.9) Color.parseColor("#E5484D") else accent, 3)
            bar.addView(fill, LinearLayout.LayoutParams(0, MATCH, used.toFloat()))
            if (used < 1000) bar.addView(View(act), LinearLayout.LayoutParams(0, MATCH, (1000 - used).toFloat()))
            info.addView(bar, lp(MATCH, dp(6)).apply { topMargin = dp(6) })
        }
        val tx = TextView(act)
        tx.text = if (total > 0) fmtGb(free) + " livres de " + fmtGb(total) else dr.dir.absolutePath
        tx.setTextColor(sub)
        tx.textSize = 11.5f
        tx.maxLines = 1
        tx.ellipsize = TextUtils.TruncateAt.END
        info.addView(tx, lp(MATCH, WRAP).apply { topMargin = dp(5) })
        t.addView(info, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
        tileStyle(t, Color.parseColor("#252525")) { navigate(dr.dir.absolutePath) }
        return t
    }

    private fun buildHome() {
        homeCol.removeAllViews()
        val list = drives()
        driveCache = list
        val sp = specialFolders()
        val avail = maxOf(dp(180), contentWidth() - dp(32))
        homeCol.addView(homeTitle("Pastas (${sp.size})"), lp(MATCH, WRAP))
        homeCol.addView(tileGrid(sp.map { folderTile(it) }, avail, dp(190)), lp(MATCH, WRAP))
        homeCol.addView(homeTitle("Dispositivos e unidades (${list.size})"), lp(MATCH, WRAP).apply { topMargin = dp(14) })
        homeCol.addView(tileGrid(list.map { driveTile(it) }, avail, dp(270)), lp(MATCH, WRAP))
    }

    // ================================================================== barra lateral

    private fun sideRow(kind: Int, label: String, path: String, indentDp: Int, chevron: Boolean): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4 + indentDp), 0, dp(6), 0)
        if (chevron) {
            val ch = ImageView(act)
            ch.setImageResource(if (pcExpanded) R.drawable.ic_chevron_down else R.drawable.ic_arrow_right)
            ch.setColorFilter(sub)
            ch.setPadding(dp(5), dp(5), dp(5), dp(5))
            ch.isClickable = true
            ch.setOnClickListener {
                pcExpanded = !pcExpanded
                rebuildSidebar()
            }
            row.addView(ch, lp(dp(22), dp(22)))
        } else {
            row.addView(View(act), lp(dp(22), dp(22)))
        }
        val iv = ImageView(act)
        iv.setImageDrawable(KindDrawable(kind))
        row.addView(iv, lp(dp(18), dp(18)).apply { leftMargin = dp(2) })
        val tx = TextView(act)
        tx.text = label
        tx.setTextColor(ink)
        tx.textSize = 13f
        tx.maxLines = 1
        tx.ellipsize = TextUtils.TruncateAt.END
        row.addView(tx, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
        row.isClickable = true
        row.setOnClickListener { navigate(path) }
        row.setOnHoverListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_HOVER_ENTER && v.background == null) v.background = rr(cHover, 6)
            if (ev.actionMasked == MotionEvent.ACTION_HOVER_EXIT) highlightSidebar()
            false
        }
        sideEntries.add(Pair(row, path))
        return row
    }

    private fun rebuildSidebar() {
        sideCol.removeAllViews()
        sideEntries.clear()
        val list = drives()
        driveCache = list
        sideCol.addView(sideRow(FKind.PC, "Este PC", "", 0, true), lp(MATCH, dp(34)))
        if (pcExpanded) {
            for (s in specialFolders()) sideCol.addView(sideRow(s.kind, s.label, s.dir.absolutePath, 14, false), lp(MATCH, dp(34)))
            for (dr in list) sideCol.addView(sideRow(FKind.DRIVE, dr.label, dr.dir.absolutePath, 14, false), lp(MATCH, dp(34)))
        }
        highlightSidebar()
    }

    private fun highlightSidebar() {
        val cur = curPath()
        var best: String? = null
        for ((_, p) in sideEntries) {
            val ok = if (cur.isEmpty()) {
                p.isEmpty()
            } else {
                p.isNotEmpty() && (cur == p || cur.startsWith(if (p.endsWith("/")) p else "$p/"))
            }
            if (ok && (best == null || p.length > best.length)) best = p
        }
        for ((v, p) in sideEntries) v.background = if (p == best) rr(Color.parseColor("#26FFFFFF"), 6) else null
    }

    // ================================================================== seleção

    private fun selectedItems(): List<FItem> {
        if (selected.isEmpty()) return emptyList()
        val out = ArrayList<FItem>()
        for (i in shown) if (selected.contains(i.path)) out.add(i)
        return out
    }

    private fun refreshSelection() {
        adapter.notifyDataSetChanged()
        updateChrome()
    }

    private fun selectAll() {
        if (shown.isEmpty()) return
        selected.clear()
        for (i in shown) selected.add(i.path)
        selectMode = true
        anchor = 0
        refreshSelection()
    }

    private fun clearSelection() {
        if (selected.isEmpty() && !selectMode) return
        selected.clear()
        selectMode = false
        refreshSelection()
    }

    private fun selectRange(a: Int, b: Int) {
        selected.clear()
        val lo = minOf(a, b).coerceAtLeast(0)
        val hi = maxOf(a, b).coerceAtMost(shown.size - 1)
        for (i in lo..hi) selected.add(shown[i].path)
    }

    private fun toggleSel(path: String) {
        if (!selected.remove(path)) selected.add(path)
    }

    private fun onItemClick(fi: FItem, idx: Int) {
        if (lastMouse) {
            when {
                lastShift && anchor >= 0 -> selectRange(anchor, idx)
                lastCtrl -> {
                    toggleSel(fi.path)
                    anchor = idx
                }
                else -> {
                    val now = SystemClock.uptimeMillis()
                    if (lastClickPath == fi.path && now - lastClickT < 450L) {
                        lastClickPath = null
                        openItem(fi)
                        return
                    }
                    selected.clear()
                    selected.add(fi.path)
                    anchor = idx
                    lastClickPath = fi.path
                    lastClickT = now
                }
            }
        } else if (selectMode) {
            toggleSel(fi.path)
            anchor = idx
            if (selected.isEmpty()) selectMode = false
        } else {
            openItem(fi)
            return
        }
        refreshSelection()
    }

    private fun onItemRightClick(fi: FItem, idx: Int, x: Int, y: Int) {
        if (!selected.contains(fi.path)) {
            selected.clear()
            selected.add(fi.path)
            anchor = idx
        }
        refreshSelection()
        showSelectionMenu(x, y)
    }

    private fun onItemLongPress(fi: FItem, idx: Int) {
        if (!selected.contains(fi.path)) {
            if (!selectMode) selected.clear()
            selected.add(fi.path)
            anchor = idx
        }
        selectMode = true
        refreshSelection()
        showSelectionMenu(lastRawX.toInt(), lastRawY.toInt())
    }

    // ================================================================== menus

    private fun newItems(): List<MenuItem> {
        val ok = curDir != null && !searching
        return listOf(
            MenuItem("Pasta", R.drawable.ic_fm_newfolder, enabled = ok, action = { newFolder() }),
            MenuItem("Documento de texto", R.drawable.ic_fm_details, enabled = ok, action = { newTextFile() })
        )
    }

    private fun sortItems(): List<MenuItem> = listOf(
        MenuItem("Nome", checked = sortKey == SORT_NAME, action = { if (sortKey != SORT_NAME) setSort(SORT_NAME) }),
        MenuItem("Data de modificação", checked = sortKey == SORT_DATE, action = { if (sortKey != SORT_DATE) setSort(SORT_DATE) }),
        MenuItem("Tipo", checked = sortKey == SORT_TYPE, action = { if (sortKey != SORT_TYPE) setSort(SORT_TYPE) }),
        MenuItem("Tamanho", checked = sortKey == SORT_SIZE, action = { if (sortKey != SORT_SIZE) setSort(SORT_SIZE) }),
        MenuItem("Crescente", checked = sortAsc, action = { setSortDir(true) }),
        MenuItem("Decrescente", checked = !sortAsc, action = { setSortDir(false) })
    )

    private fun viewItems(): List<MenuItem> = listOf(
        MenuItem("Ícones grandes", checked = viewMode == VIEW_LARGE, action = { setView(VIEW_LARGE) }),
        MenuItem("Ícones médios", checked = viewMode == VIEW_MEDIUM, action = { setView(VIEW_MEDIUM) }),
        MenuItem("Lista", checked = viewMode == VIEW_LIST, action = { setView(VIEW_LIST) }),
        MenuItem("Detalhes", checked = viewMode == VIEW_DETAILS, action = { setView(VIEW_DETAILS) })
    )

    private fun moreItems(): List<MenuItem> = listOf(
        MenuItem("Selecionar tudo", enabled = shown.isNotEmpty(), action = { selectAll() }),
        MenuItem("Selecionar vários", checked = selectMode, enabled = curDir != null, action = {
            if (selectMode) {
                selected.clear()
                selectMode = false
            } else {
                selectMode = true
            }
            refreshSelection()
        }),
        MenuItem("Limpar seleção", enabled = selected.isNotEmpty(), action = { clearSelection() }),
        MenuItem("Mostrar arquivos ocultos", checked = showHidden, action = { setShowHidden(!showHidden) }),
        MenuItem("Copiar caminho", enabled = curDir != null, action = { copyPath() }),
        MenuItem("Atualizar", R.drawable.ic_refresh, action = { reload() }),
        MenuItem("Propriedades", R.drawable.ic_info, enabled = curDir != null, action = { properties() })
    )

    private fun showSelectionMenu(x: Int, y: Int) {
        val s = selectedItems()
        if (s.isEmpty()) {
            showBgMenu(x, y)
            return
        }
        val one = if (s.size == 1) s[0] else null
        val items = ArrayList<MenuItem>()
        if (one != null) {
            val label = if (!one.isDir && one.ext == "apk") "Instalar" else "Abrir"
            items.add(MenuItem(label, R.drawable.ic_open, action = { openItem(one) }))
            if (!one.isDir) items.add(MenuItem("Abrir com…", R.drawable.ic_open, action = { openExternal(one.file, true) }))
            if (searching) items.add(MenuItem("Abrir local do arquivo", R.drawable.ic_fm_up, action = { revealItem(one) }))
        }
        items.add(MenuItem("Recortar", R.drawable.ic_fm_cut, action = { copySel(true) }))
        items.add(MenuItem("Copiar", R.drawable.ic_fm_copy, action = { copySel(false) }))
        if (one != null && one.isDir && clip.isNotEmpty()) {
            items.add(MenuItem("Colar na pasta", R.drawable.ic_fm_paste, action = { paste(one.file) }))
        }
        if (one != null) {
            items.add(MenuItem("Renomear", R.drawable.ic_fm_rename, enabled = !isRootDir(one.file), action = { renameSel() }))
        }
        items.add(MenuItem("Excluir", R.drawable.ic_delete, action = { deleteSel() }))
        if (s.any { !it.isDir }) items.add(MenuItem("Compartilhar", R.drawable.ic_fm_share, action = { shareSel() }))
        items.add(MenuItem("Compactar em ZIP", R.drawable.ic_fm_zip, action = { zipSel() }))
        if (one != null && !one.isDir && one.ext == "zip") {
            items.add(MenuItem("Extrair aqui", R.drawable.ic_fm_zip, action = { unzip(one) }))
        }
        items.add(MenuItem("Copiar caminho", R.drawable.ic_fm_copy, action = { copyPath() }))
        items.add(MenuItem("Propriedades", R.drawable.ic_info, action = { properties() }))
        act.menu.show(items, x, y)
    }

    private fun showBgMenu(x: Int, y: Int) {
        clearSelection()
        val dir = curDir
        val edit = dir != null && !searching
        val items = listOf(
            MenuItem("Novo", R.drawable.ic_plus, enabled = edit, children = newItems()),
            MenuItem("Classificar por", R.drawable.ic_fm_sort, enabled = dir != null, children = sortItems()),
            MenuItem("Exibir", R.drawable.ic_view, children = viewItems()),
            MenuItem("Colar", R.drawable.ic_fm_paste, enabled = edit && clip.isNotEmpty(), action = { paste() }),
            MenuItem("Selecionar tudo", enabled = shown.isNotEmpty(), action = { selectAll() }),
            MenuItem("Atualizar", R.drawable.ic_refresh, action = { reload() }),
            MenuItem("Propriedades", R.drawable.ic_info, enabled = dir != null, action = { properties() })
        )
        act.menu.show(items, x, y)
    }

    // ================================================================== abrir

    private fun openItem(fi: FItem) {
        when {
            fi.isDir -> navigate(fi.path)
            fi.ext == "apk" -> {
                if (!fi.file.canRead()) {
                    toast("Não foi possível ler este arquivo.")
                    return
                }
                act.openApk(FileShareProvider.uriFor(act, fi.file))
            }
            fi.kind == FKind.IMAGE -> {
                if (!fi.file.canRead()) {
                    toast("Não foi possível ler este arquivo.")
                    return
                }
                // fotos abrem na galeria nativa do launcher (com as outras fotos da lista para passar)
                val imgs = ArrayList<File>()
                for (x in shown) if (!x.isDir && x.kind == FKind.IMAGE) imgs.add(x.file)
                act.openGallery(fi.file, imgs)
            }
            fi.ext == "zip" -> confirm("Extrair", "Extrair “${fi.name}” em uma pasta com o mesmo nome?", "Extrair") { unzip(fi) }
            else -> openExternal(fi.file, false)
        }
    }

    private fun openExternal(f: File, chooser: Boolean) {
        try {
            val uri = FileShareProvider.uriFor(act, f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, FKind.mime(f.name))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i.clipData = ClipData.newRawUri("", uri)
            act.startActivity(if (chooser) Intent.createChooser(i, "Abrir com") else i)
        } catch (e: ActivityNotFoundException) {
            toast("Nenhum app encontrado para abrir este arquivo.")
        } catch (e: Exception) {
            toast("Não foi possível abrir o arquivo.")
        }
    }

    private fun shareSel() {
        val files = selectedItems().filter { !it.isDir }.map { it.file }
        if (files.isEmpty()) {
            toast("Selecione arquivos para compartilhar.")
            return
        }
        try {
            val i: Intent
            if (files.size == 1) {
                val u = FileShareProvider.uriFor(act, files[0])
                i = Intent(Intent.ACTION_SEND)
                i.type = FKind.mime(files[0].name)
                i.putExtra(Intent.EXTRA_STREAM, u)
                i.clipData = ClipData.newRawUri("", u)
            } else {
                val uris = ArrayList<Uri>()
                for (f in files) uris.add(FileShareProvider.uriFor(act, f))
                i = Intent(Intent.ACTION_SEND_MULTIPLE)
                i.type = "*/*"
                i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                val cd = ClipData.newRawUri("", uris[0])
                for (k in 1 until uris.size) cd.addItem(ClipData.Item(uris[k]))
                i.clipData = cd
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(i, "Compartilhar"))
        } catch (e: ActivityNotFoundException) {
            toast("Nenhum app encontrado para compartilhar.")
        } catch (e: Exception) {
            toast("Não foi possível compartilhar.")
        }
    }

    private fun copyPath() {
        val s = selectedItems()
        val text = if (s.isNotEmpty()) s.joinToString("\n") { it.path } else (curDir?.absolutePath ?: "")
        if (text.isEmpty()) return
        try {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("caminho", text))
            toast("Caminho copiado.")
        } catch (e: Exception) {
            toast("Não foi possível copiar o caminho.")
        }
    }

    // ================================================================== copiar / recortar / colar

    private fun copySel(cut: Boolean) {
        val s = selectedItems()
        if (s.isEmpty()) return
        if (cut && s.any { isRootDir(it.file) }) {
            toast("Não é possível mover a raiz do armazenamento.")
            return
        }
        clip = s.map { it.file }
        clipCut = cut
        clipSet.clear()
        for (f in clip) clipSet.add(f.absolutePath)
        toast(
            (if (cut) "Recortado: " else "Copiado: ") +
                (if (clip.size == 1) "1 item" else "${clip.size} itens")
        )
        refreshSelection()
    }

    private fun pruneClip() {
        clip = clip.filter { it.exists() }
        clipSet.clear()
        for (f in clip) clipSet.add(f.absolutePath)
    }

    private fun paste(target: File? = curDir) {
        val dir = target
        if (dir == null || (searching && target === curDir)) {
            toast("Abra uma pasta para colar.")
            return
        }
        if (clip.isEmpty()) {
            toast("Nada para colar.")
            return
        }
        if (!hasAccess() && isShared(dir)) {
            requestAccess()
            return
        }
        val items = ArrayList(clip)
        val cut = clipCut
        try {
            val dc = dir.canonicalPath + File.separator
            for (f in items) {
                if (f.isDirectory && dc.startsWith(f.canonicalPath + File.separator)) {
                    toast("Não é possível " + (if (cut) "mover" else "copiar") + " uma pasta para dentro dela mesma.")
                    return
                }
            }
        } catch (t: Throwable) {
        }
        runOp(if (cut) "Movendo" else "Copiando", { ctl ->
            var total = 0
            for (f in items) total += FileOps.count(f, ctl)
            ctl.total = total
            var all = -1
            loop@ for (src in items) {
                if (ctl.cancel) throw FileOps.Cancelled()
                if (!src.exists()) {
                    ctl.errors++
                    ctl.lastError = "“${src.name}” não existe mais."
                    continue@loop
                }
                try {
                    var dst = File(dir, src.name)
                    var merge = false
                    val same = src.parentFile?.canonicalPath == dir.canonicalPath
                    if (same) {
                        if (cut) {
                            ctl.done += FileOps.count(src)
                            continue@loop
                        }
                        dst = FileOps.copyName(dir, src.name)
                    } else if (dst.exists()) {
                        val r = if (all >= 0) all else askConflict(src, dst)
                        if ((r and 16) != 0) all = r
                        when (r and 15) {
                            FileOps.CANCEL -> throw FileOps.Cancelled()
                            FileOps.SKIP -> {
                                ctl.done += FileOps.count(src)
                                continue@loop
                            }
                            FileOps.KEEP_BOTH -> dst = FileOps.uniqueFile(dir, src.name)
                            else -> {
                                if (src.isDirectory && dst.isDirectory) merge = true
                                else FileOps.deleteTree(dst, OpCtl())
                            }
                        }
                    }
                    if (cut) {
                        if (merge) {
                            FileOps.copy(src, dst, ctl)
                            FileOps.deleteTree(src, OpCtl())
                        } else {
                            FileOps.move(src, dst, ctl)
                        }
                    } else {
                        FileOps.copy(src, dst, ctl)
                    }
                } catch (c: FileOps.Cancelled) {
                    throw c
                } catch (t: Throwable) {
                    ctl.errors++
                    ctl.lastError = t.message ?: ("Erro ao copiar “" + src.name + "”.")
                }
            }
        }) { _, _ ->
            if (cut) {
                clip = emptyList()
                clipSet.clear()
            }
            reload()
        }
    }

    /** Chamado na thread da operação: mostra o diálogo de conflito e espera a resposta. */
    private fun askConflict(src: File, dst: File): Int {
        val q = ArrayBlockingQueue<Int>(1)
        handler.post {
            if (!open) q.offer(FileOps.CANCEL) else showConflict(src, dst) { q.offer(it) }
        }
        return try {
            q.take()
        } catch (e: InterruptedException) {
            FileOps.CANCEL
        }
    }

    private fun showConflict(src: File, dst: File, onResult: (Int) -> Unit) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        val msg = TextView(act)
        msg.text = "Já existe um item chamado “${dst.name}” nesta pasta."
        msg.setTextColor(ink)
        msg.textSize = 13.5f
        box.addView(msg, lp(MATCH, WRAP))
        val info = TextView(act)
        fun describe(f: File): String =
            (if (f.isDirectory) "Pasta" else FileOps.fmtSize(f.length())) + " • " + FileOps.fmtDate(f.lastModified())
        info.text = "Origem: " + describe(src) + "\nDestino: " + describe(dst)
        info.setTextColor(sub)
        info.textSize = 12f
        box.addView(info, lp(MATCH, WRAP).apply { topMargin = dp(8) })
        val all = CheckBox(act)
        all.text = "Fazer isto para os próximos conflitos"
        all.setTextColor(ink)
        all.textSize = 12.5f
        all.buttonTintList = android.content.res.ColorStateList.valueOf(accent)
        box.addView(all, lp(MATCH, WRAP).apply { topMargin = dp(10) })
        fun res(code: Int): () -> Unit = {
            dlgOnClose = null
            closeDialog()
            onResult(code or (if (all.isChecked) 16 else 0))
        }
        dialog(
            "Arquivo já existe", box,
            listOf(
                Btn("Substituir", primary = true, auto = false, onClick = res(FileOps.REPLACE)),
                Btn("Manter os dois", auto = false, onClick = res(FileOps.KEEP_BOTH)),
                Btn("Ignorar", auto = false, onClick = res(FileOps.SKIP)),
                Btn("Cancelar", auto = false, onClick = res(FileOps.CANCEL))
            ),
            modal = true
        )
        dlgOnClose = { onResult(FileOps.CANCEL) }
    }

    // ================================================================== excluir, renomear, criar

    private fun nameError(dir: File, n: String, current: String? = null): String? = when {
        !FileOps.validName(n) -> "Esse nome não é válido."
        n != current && File(dir, n).exists() -> "Já existe um item com esse nome."
        else -> null
    }

    private fun deleteSel() {
        val s = selectedItems()
        if (s.isEmpty()) return
        if (s.any { isRootDir(it.file) }) {
            toast("Não é possível excluir a raiz do armazenamento.")
            return
        }
        if (!hasAccess() && s.any { isShared(it.file) }) {
            requestAccess()
            return
        }
        val files = s.map { it.file }
        val msg = if (files.size == 1) {
            "Excluir “${s[0].name}” permanentemente? Esta ação não pode ser desfeita."
        } else {
            "Excluir ${files.size} itens permanentemente? Esta ação não pode ser desfeita."
        }
        confirm("Excluir", msg, "Excluir") {
            runOp("Excluindo", { ctl ->
                var total = 0
                for (f in files) total += FileOps.count(f, ctl)
                ctl.total = total
                for (f in files) {
                    try {
                        FileOps.deleteTree(f, ctl)
                    } catch (c: FileOps.Cancelled) {
                        throw c
                    } catch (t: Throwable) {
                        ctl.errors++
                        ctl.lastError = t.message
                    }
                }
            }) { _, _ ->
                pruneClip()
                reload()
            }
        }
    }

    private fun renameSel() {
        val s = selectedItems()
        if (s.size != 1) return
        val fi = s[0]
        if (isRootDir(fi.file)) {
            toast("Não é possível renomear a raiz do armazenamento.")
            return
        }
        if (!hasAccess() && isShared(fi.file)) {
            requestAccess()
            return
        }
        val parent = fi.file.parentFile ?: return
        promptText("Renomear", fi.name, "Renomear", !fi.isDir, { n -> nameError(parent, n, fi.name) }) { n ->
            if (n != fi.name) {
                val dst = File(parent, n)
                if (fi.file.renameTo(dst)) {
                    pendingSelect = dst.absolutePath
                    pruneClip()
                    reload()
                } else {
                    toast("Não foi possível renomear.")
                }
            }
        }
    }

    private fun newFolder() {
        val dir = curDir ?: return
        if (searching) return
        if (!hasAccess() && isShared(dir)) {
            requestAccess()
            return
        }
        promptText("Nova pasta", FileOps.uniqueFile(dir, "Nova pasta").name, "Criar", false, { n -> nameError(dir, n) }) { n ->
            val f = File(dir, n)
            if (f.mkdir()) {
                pendingSelect = f.absolutePath
                reload()
            } else {
                toast("Não foi possível criar a pasta.")
            }
        }
    }

    private fun newTextFile() {
        val dir = curDir ?: return
        if (searching) return
        if (!hasAccess() && isShared(dir)) {
            requestAccess()
            return
        }
        promptText(
            "Novo documento de texto", FileOps.uniqueFile(dir, "Novo documento de texto.txt").name, "Criar", true,
            { n -> nameError(dir, n) }
        ) { n ->
            val f = File(dir, n)
            val ok = try {
                f.createNewFile()
            } catch (e: Exception) {
                false
            }
            if (ok) {
                pendingSelect = f.absolutePath
                reload()
            } else {
                toast("Não foi possível criar o arquivo.")
            }
        }
    }

    // ================================================================== zip

    private fun zipSel() {
        val s = selectedItems()
        if (s.isEmpty()) return
        val files = s.map { it.file }
        val parent = files[0].parentFile ?: curDir ?: return
        if (!hasAccess() && isShared(parent)) {
            requestAccess()
            return
        }
        val base = if (files.size == 1) {
            val n = files[0].name
            val d = n.lastIndexOf('.')
            if (d > 0 && !files[0].isDirectory) n.substring(0, d) else n
        } else {
            "Arquivos"
        }
        val out = FileOps.uniqueFile(parent, "$base.zip")
        runOp("Compactando", { ctl ->
            ctl.total = FileOps.zipCount(files)
            try {
                FileOps.zip(files, out, ctl)
            } catch (t: Throwable) {
                out.delete()
                throw t
            }
        }) { _, cancelled ->
            if (!cancelled) pendingSelect = out.absolutePath
            reload()
        }
    }

    private fun unzip(fi: FItem) {
        val parent = fi.file.parentFile ?: return
        if (!hasAccess() && isShared(parent)) {
            requestAccess()
            return
        }
        val base = if (fi.name.lowercase().endsWith(".zip")) fi.name.dropLast(4) else fi.name
        val out = FileOps.uniqueFile(parent, base.ifEmpty { "Extraído" })
        runOp("Extraindo", { ctl ->
            out.mkdirs()
            try {
                FileOps.unzip(fi.file, out, ctl)
            } catch (c: FileOps.Cancelled) {
                FileOps.deleteTree(out, OpCtl())
                throw c
            }
        }) { _, cancelled ->
            if (!cancelled) pendingSelect = out.absolutePath
            reload()
        }
    }

    // ================================================================== propriedades

    private fun properties() {
        val sel = selectedItems()
        val files: List<File> = if (sel.isNotEmpty()) sel.map { it.file } else listOfNotNull(curDir)
        if (files.isEmpty()) {
            toast("Selecione um item ou abra uma pasta.")
            return
        }
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        fun line(label: String, value: String): TextView {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            val l = TextView(act)
            l.text = label
            l.setTextColor(sub)
            l.textSize = 12.5f
            row.addView(l, lp(dp(92), WRAP))
            val v = TextView(act)
            v.text = value
            v.setTextColor(ink)
            v.textSize = 12.5f
            v.setTextIsSelectable(true)
            row.addView(v, lp(0, WRAP, 1f))
            box.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(6) })
            return v
        }
        val first = files[0]
        if (files.size == 1) {
            line("Nome", first.name.ifEmpty { "/" })
            line("Tipo", FKind.typeName(first.name, first.isDirectory))
            line("Local", first.parentFile?.absolutePath ?: "/")
        } else {
            line("Itens", "${files.size} itens")
            val parents = files.map { it.parentFile?.absolutePath ?: "/" }.toSet()
            line("Local", if (parents.size == 1) parents.first() else "Vários locais")
        }
        val sizeTv = line("Tamanho", "Calculando…")
        val hasDir = files.any { it.isDirectory }
        val contentTv = if (hasDir) line("Conteúdo", "Calculando…") else null
        if (files.size == 1) line("Modificado", FileOps.fmtDate(first.lastModified()))

        val ctl = OpCtl()
        val t = Thread {
            var bytes = 0L
            var nFiles = 0L
            var nDirs = 0L
            for (f in files) {
                val m = FileOps.measure(f, ctl)
                bytes += m[0]
                nFiles += m[1]
                nDirs += m[2]
            }
            handler.post {
                if (ctl.cancel) return@post
                val pt = java.util.Locale("pt", "BR")
                sizeTv.text = if (bytes < 1024) "$bytes bytes" else FileOps.fmtSize(bytes) + " (" + String.format(pt, "%,d", bytes) + " bytes)"
                contentTv?.text = "$nFiles arquivos, $nDirs pastas"
            }
        }
        t.isDaemon = true
        t.start()
        dialog("Propriedades", box, listOf(Btn("Fechar", primary = true) { ctl.cancel = true }), widthDp = 380)
        dlgOnClose = { ctl.cancel = true }
    }

    // ================================================================== execução das operações

    /** Executa [work] em segundo plano com progresso (aparece depois de 350 ms) e botão Cancelar. */
    private fun runOp(title: String, work: (OpCtl) -> Unit, after: (OpCtl, Boolean) -> Unit) {
        if (curCtl != null) {
            toast("Aguarde a operação em andamento terminar.")
            return
        }
        val ctl = OpCtl()
        curCtl = ctl
        opTitle = title
        opStart = SystemClock.uptimeMillis()
        startTicker()
        val e = opExec ?: Executors.newSingleThreadExecutor().also { opExec = it }
        try {
            e.execute {
                var cancelled = false
                try {
                    work(ctl)
                } catch (c: FileOps.Cancelled) {
                    cancelled = true
                } catch (t: Throwable) {
                    ctl.errors++
                    ctl.lastError = t.message ?: t.javaClass.simpleName
                }
                handler.post {
                    if (curCtl !== ctl) return@post
                    curCtl = null
                    stopTicker()
                    if (progShown) {
                        dlgOnClose = null
                        closeDialog()
                    }
                    if (!open) return@post
                    after(ctl, cancelled)
                    if (ctl.errors > 0) {
                        val why = ctl.lastError
                        toast((if (ctl.errors == 1) "1 item com erro" else "${ctl.errors} itens com erro") + (if (why != null) ": $why" else ""))
                    } else if (cancelled) {
                        toast("Operação cancelada.")
                    }
                }
            }
        } catch (t: Throwable) {
            curCtl = null
            stopTicker()
        }
    }

    private fun startTicker() {
        stopTicker()
        val t = object : Runnable {
            override fun run() {
                val c = curCtl ?: return
                if (!open) return
                val elapsed = SystemClock.uptimeMillis() - opStart
                if (!progShown && dlgLayer.visibility != View.VISIBLE && elapsed >= 350L) showProgress(c)
                if (progShown) updateProgress(c)
                handler.postDelayed(this, 120)
            }
        }
        ticker = t
        handler.postDelayed(t, 120)
    }

    private fun stopTicker() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
    }

    private fun showProgress(c: OpCtl) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        val tx = TextView(act)
        tx.setTextColor(sub)
        tx.textSize = 12.5f
        tx.maxLines = 1
        tx.ellipsize = TextUtils.TruncateAt.MIDDLE
        tx.text = "Preparando…"
        box.addView(tx, lp(MATCH, WRAP))
        val pb = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 1000
        pb.progressTintList = android.content.res.ColorStateList.valueOf(accent)
        pb.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#3A3A3A"))
        box.addView(pb, lp(MATCH, dp(8)).apply { topMargin = dp(10) })
        dialog(opTitle + "…", box, listOf(Btn("Cancelar", auto = false) {
            c.cancel = true
            progText?.text = "Cancelando…"
        }), modal = true)
        dlgOnClose = { c.cancel = true }
        progText = tx
        progBar = pb
        progShown = true
        updateProgress(c)
    }

    private fun updateProgress(c: OpCtl) {
        val total = c.total
        val pb = progBar
        if (pb != null) {
            if (total <= 0) {
                pb.isIndeterminate = true
            } else {
                pb.isIndeterminate = false
                pb.progress = (c.done.toLong() * 1000L / total).toInt().coerceIn(0, 1000)
            }
        }
        if (!c.cancel) {
            val cur = c.current
            progText?.text = if (total > 0) {
                (if (cur.isNotEmpty()) cur + "  " else "") + "(" + minOf(c.done, total) + " de " + total + ")"
            } else {
                if (cur.isNotEmpty()) cur else "Preparando…"
            }
        }
    }

    // ================================================================== diálogos

    private fun pressBtn(b: Btn) {
        if (b.auto) {
            dlgOnClose = null
            closeDialog()
        }
        b.onClick()
    }

    private fun dlgButton(b: Btn, stacked: Boolean): TextView {
        val t = TextView(act)
        t.text = b.text
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dp(16), 0, dp(16), 0)
        t.setTextColor(if (b.primary) Color.parseColor("#0B0B0B") else ink)
        t.background = rr(if (b.primary) accent else Color.parseColor("#3A3A3A"), 6)
        t.isClickable = true
        t.setOnClickListener { pressBtn(b) }
        if (stacked) t.minHeight = dp(34)
        return t
    }

    private fun dialog(title: String, body: View?, buttons: List<Btn>, widthDp: Int = 340, modal: Boolean = false) {
        dlgOnClose = null
        dlgOk = null
        progBar = null
        progText = null
        progShown = false
        dlgModal = modal
        dlgLayer.removeAllViews()
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(20), dp(18), dp(20), dp(14))
        val bg = rr(Color.parseColor("#2B2B2B"), 12)
        bg.setStroke(dp(1), cLine)
        card.background = bg
        card.isClickable = true
        card.elevation = dp(12).toFloat()
        val tt = TextView(act)
        tt.text = title
        tt.setTextColor(ink)
        tt.textSize = 16f
        tt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        card.addView(tt, lp(MATCH, WRAP))
        if (body != null) card.addView(body, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        val stacked = buttons.size > 3
        val row = LinearLayout(act)
        row.orientation = if (stacked) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        for (b in buttons) {
            val bv = dlgButton(b, stacked)
            if (stacked) row.addView(bv, lp(MATCH, dp(34)).apply { topMargin = dp(6) })
            else row.addView(bv, lp(WRAP, dp(34)).apply { leftMargin = dp(8) })
        }
        card.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(16) })
        val w = minOf(dp(widthDp), maxOf(dp(240), win.width - dp(32)))
        dlgLayer.addView(card, FrameLayout.LayoutParams(w, WRAP, Gravity.CENTER))
        dlgLayer.visibility = View.VISIBLE
        val prim = buttons.firstOrNull { it.primary }
        if (prim != null) dlgOk = { pressBtn(prim) }
    }

    private fun confirm(title: String, message: String, ok: String, onOk: () -> Unit) {
        val tv = TextView(act)
        tv.text = message
        tv.setTextColor(ink)
        tv.textSize = 13.5f
        dialog(title, tv, listOf(Btn("Cancelar") {}, Btn(ok, primary = true) { onOk() }))
    }

    private fun promptText(
        title: String,
        initial: String,
        ok: String,
        selectBase: Boolean,
        validate: (String) -> String?,
        onOk: (String) -> Unit
    ) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        val et = EditText(act)
        et.setText(initial)
        et.setTextColor(ink)
        et.textSize = 14f
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        et.setPadding(dp(10), 0, dp(10), 0)
        et.background = rr(cField, 6)
        val err = TextView(act)
        err.setTextColor(Color.parseColor("#FF6B6B"))
        err.textSize = 12f
        err.visibility = View.GONE
        box.addView(et, lp(MATCH, dp(38)))
        box.addView(err, lp(MATCH, WRAP).apply { topMargin = dp(6) })
        val commit: () -> Unit = {
            val t = et.text.toString().trim()
            val e = validate(t)
            if (e != null) {
                err.text = e
                err.visibility = View.VISIBLE
            } else {
                closeDialog()
                onOk(t)
            }
        }
        et.setOnEditorActionListener { _, _, _ ->
            commit()
            true
        }
        dialog(title, box, listOf(Btn("Cancelar") {}, Btn(ok, primary = true, auto = false) { commit() }))
        et.requestFocus()
        if (selectBase) {
            val dot = initial.lastIndexOf('.')
            et.setSelection(0, if (dot > 0) dot else initial.length)
        } else {
            et.selectAll()
        }
        et.postDelayed({
            try {
                val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {
            }
        }, 120)
    }

    /** Fecha o diálogo atual. [dlgOnClose] é chamado uma única vez (ex.: cancelar a operação em andamento). */
    private fun closeDialog() {
        val cb = dlgOnClose
        dlgOnClose = null
        dlgOk = null
        progBar = null
        progText = null
        progShown = false
        dlgModal = false
        dlgLayer.removeAllViews()
        dlgLayer.visibility = View.GONE
        hideKeyboard()
        releaseFocus()
        cb?.invoke()
    }
}
