package com.example.winlauncher

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * Contador de FPS flutuante: barra preta com "FPS" e o valor.
 *  - fpsMode 0 (real): mede o app em primeiro plano lendo "dumpsys gfxinfo <pacote> framestats"
 *    via Shizuku. Sem Shizuku ativo/permitido, mostra "--".
 *  - fpsMode 1 (falso): alterna valores entre 190 e 255 a cada 500 ms.
 * Ativado/desativado por [sync], que é chamado pela tela principal.
 */
class FpsCounterService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var label: TextView
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var attached = false
    private var lastSizeSp = -1

    @Volatile
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val p = Prefs(getSharedPreferences("win", Context.MODE_PRIVATE))
            applySize(p.fpsSize)
            if (p.fpsMode == 1) {
                setText(Random.nextInt(190, 256).toString())
                main.postDelayed(this, 500L)
            } else {
                bg.execute {
                    val v = readRealFps()
                    main.post { if (running) setText(v?.toString() ?: "--") }
                }
                main.postDelayed(this, 1000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        label = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable().apply { setColor(Color.BLACK) }
            text = "FPS --"
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            show()
            main.post(tick)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        main.removeCallbacks(tick)
        hide()
        bg.shutdownNow()
        super.onDestroy()
    }

    private fun show() {
        if (attached) return
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(4)
            y = dp(4)
        }
        wm.addView(label, lp)
        attached = true
    }

    private fun hide() {
        if (!attached) return
        try {
            wm.removeView(label)
        } catch (_: Exception) {
        }
        attached = false
    }

    private fun setText(value: String) {
        label.text = "FPS $value"
    }

    private fun applySize(sp: Int) {
        val s = sp.coerceIn(8, 60)
        if (s == lastSizeSp) return
        lastSizeSp = s
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, s.toFloat())
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Lê FPS do app em primeiro plano. Retorna null se não for possível medir. */
    private fun readRealFps(): Int? {
        val pkg = foregroundPackage() ?: return null
        val out = shizukuShell("dumpsys gfxinfo $pkg framestats") ?: return null
        val now = System.nanoTime()
        var count = 0
        for (line in out.lineSequence()) {
            val cols = line.split(',')
            if (cols.size < 3) continue
            // coluna 1 = IntendedVsync (ns, mesma base do System.nanoTime)
            val vsync = cols[1].trim().toLongOrNull() ?: continue
            if (vsync > 0 && now - vsync in 0..1_000_000_000L) count++
        }
        return count
    }

    private fun foregroundPackage(): String? {
        val out = shizukuShell("dumpsys activity activities") ?: return null
        val re = Regex("""(?:topResumedActivity|mResumedActivity)[=:] ?ActivityRecord\{\S+ \S+ ([\w.]+)/""")
        return re.find(out)?.groupValues?.get(1)
    }

    /**
     * Executa um comando de shell com privilégio do Shizuku, chamando a API por reflexão
     * para não exigir a dependência em tempo de compilação. Retorna null se indisponível.
     * ATENÇÃO: não testado em aparelho; a assinatura de newProcess pode variar entre versões do Shizuku.
     */
    private fun shizukuShell(cmd: String): String? {
        return try {
            val cls = Class.forName("rikka.shizuku.Shizuku")
            val granted = (cls.getMethod("checkSelfPermission").invoke(null) as Int) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) return null
            val m = cls.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val proc = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val text = proc.inputStream.bufferedReader().use { it.readText() }
            proc.waitFor()
            text
        } catch (_: Throwable) {
            null
        }
    }

    companion object {
        /** Liga ou desliga o contador conforme as preferências. Chamar ao abrir a tela e ao mudar a opção. */
        fun sync(ctx: Context) {
            val p = Prefs(ctx.getSharedPreferences("win", Context.MODE_PRIVATE))
            val want = p.fpsOn && Settings.canDrawOverlays(ctx)
            val i = Intent(ctx, FpsCounterService::class.java)
            if (want) ctx.startService(i) else ctx.stopService(i)
        }
    }
}
