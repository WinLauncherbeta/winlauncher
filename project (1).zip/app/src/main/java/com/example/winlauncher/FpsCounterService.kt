package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

/**
 * Contador de FPS flutuante: uma barrinha totalmente preta com "FPS" e o número.
 * Aparece sobre qualquer app e também sobre o próprio launcher. Dá para arrastar.
 *
 * Modos (opção "Contador de FPS" nas configurações da launcher):
 *  - REAL: mede quantos quadros por segundo o Android está entregando na tela (Choreographer),
 *          ou seja, a taxa de atualização real da tela naquele momento (60, 90, 120 Hz...).
 *  - FAKE: número falso que fica alternando entre 190 e 255.
 *
 * Preferências: ui_fps_on (liga/desliga), ui_fps_mode (0 = real, 1 = falso), fps_x / fps_y (posição).
 */
class FpsCounterService : Service() {

    companion object {
        private const val CHANNEL = "fps_counter"
        private const val NOTIF_ID = 4713
        const val MODE_REAL = 0
        const val MODE_FAKE = 1
        const val FAKE_MIN = 190
        const val FAKE_MAX = 255

        @Volatile
        var instance: FpsCounterService? = null

        fun isRunning(): Boolean = instance != null

        /** Liga, desliga ou atualiza o contador conforme as preferências. Chamar sempre que algo mudar. */
        fun sync(ctx: Context) {
            val sp = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)
            val on = sp.getBoolean("ui_fps_on", false) && Settings.canDrawOverlays(ctx)
            val inst = instance
            if (on) {
                if (inst == null) {
                    try {
                        ctx.startForegroundService(Intent(ctx, FpsCounterService::class.java))
                    } catch (e: Exception) {
                    }
                } else {
                    inst.handler.post { inst.onModeChanged() }
                }
            } else if (inst != null) {
                inst.handler.post {
                    inst.removeBar()
                    inst.stopSelf()
                }
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val sp get() = getSharedPreferences("win", MODE_PRIVATE)

    private var wm: WindowManager? = null
    private var bar: LinearLayout? = null
    private var valueView: TextView? = null
    private var titleView: TextView? = null
    private var lp: WindowManager.LayoutParams? = null

    // ---- FPS real
    private var frames = 0
    private var windowStartNs = 0L
    private var measuring = false
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!measuring) return
            if (windowStartNs == 0L) windowStartNs = frameTimeNanos
            frames++
            val elapsed = frameTimeNanos - windowStartNs
            if (elapsed >= 500_000_000L) {
                val fps = (frames * 1_000_000_000.0 / elapsed).toInt()
                setValue(fps)
                frames = 0
                windowStartNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // ---- FPS real do app aberto (via Shizuku + SurfaceFlinger)
    @Volatile
    private var usingShizuku = false
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var topPkg = ""
    private var layers: List<String> = emptyList()
    private var tickN = 0
    private var layersAge = 0

    private val recheck = object : Runnable {
        override fun run() {
            if (sp.getInt("ui_fps_mode", MODE_REAL) != MODE_REAL || usingShizuku) return
            if (ShizukuBridge.state(this@FpsCounterService) == ShizukuBridge.State.GRANTED) {
                onModeChanged()
            } else {
                handler.postDelayed(this, 3000)
            }
        }
    }

    private val shizukuTick = object : Runnable {
        override fun run() {
            if (!usingShizuku) return
            if (ShizukuBridge.state(this@FpsCounterService) != ShizukuBridge.State.GRANTED) {
                handler.post { if (usingShizuku) onModeChanged() }
                return
            }
            val fps = measureForeground()
            handler.post { if (usingShizuku) setValue(fps) }
            workerHandler?.postDelayed(this, 500)
        }
    }

    private fun startShizuku() {
        usingShizuku = true
        topPkg = ""
        layers = emptyList()
        tickN = 0
        layersAge = 0
        if (worker == null) {
            worker = HandlerThread("fps-shizuku").also { it.start() }
            workerHandler = Handler(worker!!.looper)
        }
        setValue(0)
        workerHandler?.post(shizukuTick)
    }

    private fun startChoreographer() {
        setValue(0)
        frames = 0
        windowStartNs = 0L
        measuring = true
        Choreographer.getInstance().postFrameCallback(frameCb)
        handler.postDelayed(recheck, 3000) // se o Shizuku for autorizado depois, troca sozinho
    }

    /** FPS do app que está na frente: quadros apresentados na última 1 s, lidos do SurfaceFlinger. */
    private fun measureForeground(): Int {
        // app em primeiro plano (confere a cada ~1 s)
        if (topPkg.isEmpty() || tickN++ % 2 == 0) {
            val top = ShizukuBridge.exec(
                arrayOf(
                    "sh", "-c",
                    "dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|ResumedActivity'"
                )
            ) ?: return 0
            val pkg = Regex(" u\\d+ ([A-Za-z0-9_.]+)/").find(top)?.groupValues?.get(1) ?: return 0
            if (pkg != topPkg) {
                topPkg = pkg
                layers = emptyList()
            }
        }
        // camadas (janelas) desse app; os nomes mudam quando o app recria a janela
        if (layers.isEmpty() || layersAge++ >= 6) {
            layersAge = 0
            val list = ShizukuBridge.exec(
                arrayOf("sh", "-c", "dumpsys SurfaceFlinger --list 2>/dev/null | grep -F \"$1\"", "sh", topPkg)
            ) ?: return 0
            layers = list.lines()
                .map { it.trim() }
                .filter {
                    it.isNotEmpty() && it.contains(topPkg) &&
                        !it.startsWith("Background") && !it.startsWith("Task") &&
                        !it.startsWith("Bounds") && !it.startsWith("Dim")
                }
                .distinct()
                .take(6)
        }
        if (layers.isEmpty()) return 0
        val args = ArrayList<String>()
        args.add("sh")
        args.add("-c")
        args.add("for l in \"$@\"; do echo '@@L'; dumpsys SurfaceFlinger --latency \"\$l\" 2>/dev/null; done")
        args.add("sh")
        args.addAll(layers)
        val out = ShizukuBridge.exec(args.toTypedArray()) ?: return 0
        val now = System.nanoTime()
        var best = 0
        for (block in out.split("@@L")) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.size < 2) continue
            val ts = ArrayList<Long>()
            for (ln in lines.drop(1)) {
                val parts = ln.split(Regex("\\s+"))
                if (parts.size < 3) continue
                val t = parts[1].toLongOrNull() ?: continue
                if (t <= 0L || t == Long.MAX_VALUE) continue
                ts.add(t)
            }
            if (ts.isEmpty()) continue
            val latest = ts.maxOrNull() ?: continue
            // se o relógio bate com o do SurfaceFlinger, conta quadros dos últimos 1 s até agora
            val ref = if (now - latest in -100_000_000L..30_000_000_000L) now else latest
            val n = ts.count { it > ref - 1_000_000_000L && it <= ref }
            if (n > best) best = n
        }
        return best
    }

    // ---- FPS falso
    private var fake = FAKE_MAX - 20
    private val fakeTick = object : Runnable {
        override fun run() {
            // passeio aleatório suave, com saltos ocasionais, sempre entre 190 e 255
            fake += Random.nextInt(-9, 10)
            if (Random.nextInt(8) == 0) fake = Random.nextInt(FAKE_MIN, FAKE_MAX + 1)
            fake = fake.coerceIn(FAKE_MIN, FAKE_MAX)
            setValue(fake)
            handler.postDelayed(this, Random.nextLong(250, 700))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Contador de FPS", NotificationManager.IMPORTANCE_MIN)
            )
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_speed)
                .setContentTitle("WinLauncher")
                .setContentText("Contador de FPS ativo")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.post {
            if (bar == null) addBar()
            onModeChanged()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopCounting()
        worker?.quitSafely()
        worker = null
        workerHandler = null
        removeBar()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ contagem

    private fun onModeChanged() {
        stopCounting()
        if (bar == null) return
        if (sp.getInt("ui_fps_mode", MODE_REAL) == MODE_FAKE) {
            handler.post(fakeTick)
        } else {
            if (ShizukuBridge.state(this) == ShizukuBridge.State.GRANTED) startShizuku() else startChoreographer()
        }
    }

    private fun stopCounting() {
        usingShizuku = false
        workerHandler?.removeCallbacksAndMessages(null)
        handler.removeCallbacks(recheck)
        measuring = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        handler.removeCallbacks(fakeTick)
    }

    private fun setValue(v: Int) {
        valueView?.text = v.toString()
    }

    // ------------------------------------------------------------------ barra

    private fun overlayContext(): Context {
        return try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
            val d = dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
            val dc = createDisplayContext(d)
            if (Build.VERSION.SDK_INT >= 30) {
                dc.createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
            } else dc
        } catch (e: Exception) {
            this
        }
    }

    private fun addBar() {
        var c = overlayContext()
        try {
            buildBar(c)
        } catch (e: Exception) {
            // plano B: contexto do próprio serviço (tela padrão)
            try {
                c = this
                buildBar(c)
            } catch (e2: Exception) {
            }
        }
    }

    /** Tamanho REAL da tela (inclui a área da barra/taskbar); displayMetrics corta essa área e o contador não chegava na borda. */
    private fun realScreenSize(c: Context, w: WindowManager): IntArray {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = w.maximumWindowMetrics.bounds
                if (b.width() > 0 && b.height() > 0) return intArrayOf(b.width(), b.height())
            }
        } catch (e: Exception) {
        }
        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
            val d = dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
            val p = Point()
            @Suppress("DEPRECATION")
            d.getRealSize(p)
            if (p.x > 0 && p.y > 0) return intArrayOf(p.x, p.y)
        } catch (e: Exception) {
        }
        val m = c.resources.displayMetrics
        return intArrayOf(m.widthPixels, m.heightPixels)
    }

    private fun buildBar(c: Context) {
        val w = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = c.resources.displayMetrics
        val d = m.density
        fun dp(v: Int) = (v * d + 0.5f).toInt()

        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = GradientDrawable().apply {
            setColor(Color.BLACK) // totalmente preta
            cornerRadius = dp(3).toFloat()
        }

        val title = TextView(c)
        title.text = "FPS"
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        row.addView(title)

        val num = TextView(c)
        num.text = "0"
        num.setTextColor(Color.WHITE)
        num.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        num.gravity = Gravity.END
        row.addView(num, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        val scr0 = realScreenSize(c, w)
        p.x = sp.getInt("fps_x", dp(12)).coerceIn(0, (scr0[0] - dp(40)).coerceAtLeast(0))
        p.y = sp.getInt("fps_y", dp(12)).coerceIn(0, (scr0[1] - dp(20)).coerceAtLeast(0))

        // arrastar com o dedo ou o mouse
        val slop = 6 * d
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        row.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = p.x
                    startY = p.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!dragging && (dx * dx + dy * dy) > slop * slop) dragging = true
                    if (dragging) {
                        val scr = realScreenSize(c, w)
                        p.x = (startX + dx).toInt().coerceIn(0, (scr[0] - row.width).coerceAtLeast(0))
                        p.y = (startY + dy).toInt().coerceIn(0, (scr[1] - row.height).coerceAtLeast(0))
                        try {
                            w.updateViewLayout(row, p)
                        } catch (e: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) sp.edit().putInt("fps_x", p.x).putInt("fps_y", p.y).apply()
                    true
                }
                else -> false
            }
        }

        w.addView(row, p) // se falhar, nada foi adicionado
        wm = w
        bar = row
        valueView = num
        titleView = title
        lp = p
        applyStyle()
    }

    /** Tamanho do contador (ui_fps_size, em sp): texto, margens e largura crescem juntos. */
    fun applyStyle() {
        val row = bar ?: return
        val title = titleView ?: return
        val num = valueView ?: return
        val d = row.resources.displayMetrics.density
        val size = sp.getInt("ui_fps_size", 13).coerceIn(8, 60)
        title.textSize = size.toFloat()
        num.textSize = size.toFloat()
        num.minWidth = (size * 2.1f * d).toInt()
        (num.layoutParams as? LinearLayout.LayoutParams)?.leftMargin = (size * 1.0f * d).toInt()
        row.setPadding((size * 0.6f * d).toInt(), (size * 0.25f * d).toInt(), (size * 0.6f * d).toInt(), (size * 0.25f * d).toInt())
        (row.background as? GradientDrawable)?.cornerRadius = size * 0.25f * d
        num.requestLayout()
        try {
            val p = lp
            if (p != null) wm?.updateViewLayout(row, p)
        } catch (e: Exception) {
        }
    }

    private fun removeBar() {
        val b = bar ?: return
        try {
            wm?.removeView(b)
        } catch (e: Exception) {
        }
        bar = null
        titleView = null
        valueView = null
        wm = null
        lp = null
    }
}
