package com.example.winlauncher

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/**
 * Activity invisível usada pelo atalho de teclado (ALT + R) quando o launcher não está na frente.
 * Não mostra a janelinha de opções: usa a última configuração salva. O Android sempre mostra o aviso
 * de captura de tela (isso não dá para pular); depois dele a gravação começa.
 */
class RecordStartActivity : Activity() {

    companion object {
        private const val REQ_AUDIO = 1
        private const val REQ_CAPTURE = 2

        /** true quando a tela foi realmente aberta (o ShortcutService confere isso). */
        @Volatile
        var launched = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launched = true
        val sp = getSharedPreferences("win", MODE_PRIVATE)
        val wantAudio = sp.getBoolean("rec_mic", true) || sp.getBoolean("rec_int", true)
        if (wantAudio && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
        } else {
            capture()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO) capture() // negada: grava só o vídeo
    }

    private fun capture() {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        } catch (e: Exception) {
            MiniToast.error(applicationContext, "Falha ao iniciar a captura de tela (" + e.javaClass.simpleName + ")")
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            try {
                ScreenRecordService.start(applicationContext, resultCode, data)
            } catch (e: Exception) {
                MiniToast.error(applicationContext, "Falha ao iniciar a gravação (" + e.javaClass.simpleName + ")")
            }
        } else {
            if (requestCode == REQ_CAPTURE) MiniToast.info(applicationContext, "Gravação cancelada")
        }
        finish()
    }
}
