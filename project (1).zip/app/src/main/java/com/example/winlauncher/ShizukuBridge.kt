package com.example.winlauncher

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Integração mínima e segura com o Shizuku: apenas estado e autorização.
 * Tudo é protegido por try/catch; sem o Shizuku o launcher funciona normalmente.
 */
object ShizukuBridge {
    const val PKG = "moe.shizuku.privileged.api"
    const val REQ = 4242

    enum class State { NOT_INSTALLED, NOT_RUNNING, NEEDS_PERMISSION, GRANTED, UNSUPPORTED }

    @Volatile
    var onChange: (() -> Unit)? = null

    private var listenersAdded = false

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun state(ctx: Context): State = try {
        when {
            !installed(ctx) -> State.NOT_INSTALLED
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.GRANTED
            else -> State.NEEDS_PERMISSION
        }
    } catch (t: Throwable) {
        State.UNSUPPORTED
    }

    /** Retorna false quando o Shizuku já bloqueou novos pedidos (usuário precisa liberar no app). */
    fun request(): Boolean = try {
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            false
        } else {
            Shizuku.requestPermission(REQ)
            true
        }
    } catch (t: Throwable) {
        false
    }

    fun open(act: Activity): Boolean = try {
        val i = act.packageManager.getLaunchIntentForPackage(PKG)
        if (i != null) {
            act.startActivity(i)
            true
        } else {
            false
        }
    } catch (t: Throwable) {
        false
    }

    fun addListeners() {
        if (listenersAdded) return
        try {
            Shizuku.addBinderReceivedListener { onChange?.invoke() }
            Shizuku.addBinderDeadListener { onChange?.invoke() }
            Shizuku.addRequestPermissionResultListener { _, _ -> onChange?.invoke() }
            listenersAdded = true
        } catch (t: Throwable) {
        }
    }
}
