package com.example.winlauncher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Painel de configurações rápidas da Dock 2: janela flutuante com vidro que abre diretamente
 * junto da seta da Dock 2. É uma interface própria do launcher (não usa o painel do Android
 * nem o painel da barra principal); só reaproveita as mesmas ações dos atalhos.
 */
class DockQuickPanel(
    private val act: MainActivity,
    private val root: FrameLayout,
    private val cfg: Prefs,
    private val tiles: () -> List<Tile>,
    private val isLight: () -> Boolean,
    private val baseRgb: () -> Int,
    private val accent: () -> Int,
    private val ripple: () -> Int,
    private val windowBg: (View, Int) -> Drawable,
    private val dockView: () -> View,
    private val onOpenChange: (Boolean) -> Unit
) {
    private val dm = act.resources.displayMetrics
    private fun dp(v: Int): Int = (v * dm.density + 0.5f).toInt()
    private fun argb(a: Int, rgb: Int): Int = (a.coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)

    /** Seta da Dock 2 que serve de âncora. */
    var anchor: View? = null

    /** Toque fora do painel fecha. */
    val catcher = View(act)
    val popup = ScrollView(act)

    var isOpen = false
        private set

    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            if (!isOpen) return
            refresh()
            handler.postDelayed(this, 1500)
        }
    }

    private val tileViews = ArrayList<Triple<LinearLayout, ImageView, TextView>>()
    private var brightSeek: SeekBar? = null
    private var volSeek: SeekBar? = null
    private var batText: TextView? = null

    init {
        catcher.visibility = View.GONE
        catcher.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) close()
            true
        }
        popup.visibility = View.GONE
        popup.isClickable = true
        popup.tag = CursorController.NOHAND
        popup.isVerticalScrollBarEnabled = false
        popup.clipToPadding = false
        popup.elevation = dp(10).toFloat()
    }

    // ------------------------------------------------------------ abrir / fechar

    fun toggle() {
        if (isOpen) close() else open()
    }

    fun open() {
        if (isOpen || anchor == null) return
        applyStyle()
        isOpen = true
        catcher.visibility = View.VISIBLE
        popup.visibility = View.VISIBLE
        refresh()
        reposition()
        if (cfg.anim) {
            val d = dp(18).toFloat()
            popup.alpha = 0f
            when (cfg.d2Pos) {
                0 -> popup.translationY = d
                1 -> popup.translationY = -d
                2 -> popup.translationX = -d
                else -> popup.translationX = d
            }
            popup.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(140).start()
        } else {
            popup.alpha = 1f
            popup.translationX = 0f
            popup.translationY = 0f
        }
        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 1500)
        onOpenChange(true)
    }

    /** Fecha o painel; retorna true se ele estava aberto. */
    fun close(): Boolean {
        if (!isOpen) return false
        isOpen = false
        handler.removeCallbacks(loop)
        popup.animate().cancel()
        popup.visibility = View.GONE
        catcher.visibility = View.GONE
        onOpenChange(false)
        return true
    }

    // ------------------------------------------------------------ posição

    /** Mantém a janela alinhada com a seta/Dock, onde quer que a Dock esteja. */
    fun reposition() {
        if (!isOpen) return
        val a = anchor ?: return
        if (!a.isAttachedToWindow || a.width == 0) return
        val dock = dockView()
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val edge = dp(8)
        val gap = dp(10)
        val w = min(dp(cfg.d2qW), sw - 2 * edge)
        popup.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = min(popup.measuredHeight, sh - 2 * edge)

        val al = IntArray(2)
        val dl = IntArray(2)
        val rl = IntArray(2)
        a.getLocationOnScreen(al)
        dock.getLocationOnScreen(dl)
        root.getLocationOnScreen(rl)
        val cx = al[0] - rl[0] + a.width / 2
        val cy = al[1] - rl[1] + a.height / 2
        val dockL = dl[0] - rl[0]
        val dockT = dl[1] - rl[1]
        var left: Int
        var top: Int
        when (cfg.d2Pos) {
            0 -> { left = cx - w / 2; top = dockT - gap - h }
            1 -> { left = cx - w / 2; top = dockT + dock.height + gap }
            2 -> { left = dockL + dock.width + gap; top = cy - h / 2 }
            else -> { left = dockL - gap - w; top = cy - h / 2 }
        }
        left = left.coerceIn(edge, max(edge, sw - w - edge))
        top = top.coerceIn(edge, max(edge, sh - h - edge))

        val old = popup.layoutParams as? FrameLayout.LayoutParams
        if (old == null || old.width != w || old.height != h || old.leftMargin != left || old.topMargin != top) {
            val lp = FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.START)
            lp.leftMargin = left
            lp.topMargin = top
            popup.layoutParams = lp
        }
    }

    // ------------------------------------------------------------ aparência e conteúdo

    fun applyStyle() {
        // mesmo vidro, borda e cantos da Dock 2 (desfoque do painel ajustável)
        popup.background = windowBg(popup, cfg.d2qRadius)
        buildContent()
        popup.invalidate()
    }

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun rip(color: Int, r: Int): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(ripple()), rounded(color, r), rounded(Color.WHITE, r))

    private fun buildContent() {
        popup.removeAllViews()
        tileViews.clear()
        val light = isLight()
        val ink = if (light) Color.parseColor("#1F1F1F") else Color.WHITE
        val acc = accent()
        val pad = dp(14)
        val w = min(dp(cfg.d2qW), dm.widthPixels - dp(16))
        val cols = cfg.d2qCols.coerceIn(2, 4)
        val cellM = dp(4)

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, dp(10))

        val title = TextView(act)
        title.text = "Configurações rápidas"
        title.setTextColor(ink)
        title.textSize = 13f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setPadding(dp(4), 0, 0, dp(6))
        col.addView(title)

        val cw = (w - 2 * pad) / cols - 2 * cellM
        val grid = GridLayout(act)
        grid.columnCount = cols
        for (t in tiles()) {
            val v = LinearLayout(act)
            v.orientation = LinearLayout.VERTICAL
            v.gravity = Gravity.CENTER
            v.isClickable = true
            val iv = ImageView(act)
            iv.setImageResource(t.icon)
            val tv = TextView(act)
            tv.text = t.label
            tv.textSize = 11f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            v.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tlp.topMargin = dp(4)
            v.addView(tv, tlp)
            v.setOnClickListener {
                try {
                    t.click()
                } catch (e: Exception) {
                    act.toast("Não foi possível executar")
                }
                if (t.closes) close() else handler.postDelayed({ refresh() }, 250)
            }
            tileViews.add(Triple(v, iv, tv))
            val glp = GridLayout.LayoutParams()
            glp.width = cw
            glp.height = dp(cfg.d2qTile)
            glp.setMargins(cellM, cellM, cellM, cellM)
            grid.addView(v, glp)
        }
        col.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val bs = SeekBar(act)
        bs.max = 255
        bs.progressTintList = ColorStateList.valueOf(acc)
        bs.thumbTintList = ColorStateList.valueOf(acc)
        bs.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (Settings.System.canWrite(act)) {
                    Settings.System.putInt(
                        act.contentResolver,
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    )
                    Settings.System.putInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS, max(p, 1))
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                if (!Settings.System.canWrite(act)) {
                    act.toast("Permita \"Modificar configurações do sistema\" para controlar o brilho")
                    close()
                    try {
                        act.startActivity(
                            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + act.packageName))
                        )
                    } catch (e: Exception) {
                    }
                }
            }

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        brightSeek = bs
        col.addView(sliderRow(R.drawable.ic_brightness, bs, ink), topMargin(8))

        val vs = SeekBar(act)
        vs.progressTintList = ColorStateList.valueOf(acc)
        vs.thumbTintList = ColorStateList.valueOf(acc)
        vs.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                try {
                    (act.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                        .setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                } catch (e: Exception) {
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        volSeek = vs
        col.addView(sliderRow(R.drawable.ic_volume, vs, ink), topMargin(4))

        val foot = LinearLayout(act)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        val bt = TextView(act)
        bt.setTextColor(ink)
        bt.textSize = 13f
        bt.compoundDrawablePadding = dp(6)
        bt.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_battery, 0, 0, 0)
        bt.compoundDrawableTintList = ColorStateList.valueOf(ink)
        batText = bt
        foot.addView(bt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = ImageView(act)
        gear.setImageResource(R.drawable.ic_settings)
        gear.setColorFilter(ink)
        gear.setPadding(dp(10), dp(10), dp(10), dp(10))
        gear.background = rip(Color.TRANSPARENT, 8)
        gear.isClickable = true
        gear.setOnClickListener {
            close()
            try {
                act.startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
                act.toast("Não foi possível abrir")
            }
        }
        foot.addView(gear, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(foot, topMargin(6))

        popup.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun topMargin(v: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(v)
        return lp
    }

    private fun sliderRow(icon: Int, seek: SeekBar, ink: Int): LinearLayout {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), 0, dp(4), 0)
        val iv = ImageView(act)
        iv.setImageResource(icon)
        iv.setColorFilter(ink)
        row.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(8)
        row.addView(seek, lp)
        return row
    }

    // ------------------------------------------------------------ estado do sistema

    fun refresh() {
        val light = isLight()
        val ink = if (light) Color.parseColor("#1F1F1F") else Color.WHITE
        val off = if (light) Color.parseColor("#14000000") else Color.parseColor("#26FFFFFF")
        val list = tiles()
        for ((i, tv) in tileViews.withIndex()) {
            val t = list.getOrNull(i) ?: continue
            val on = try {
                t.active()
            } catch (e: Exception) {
                false
            }
            tv.first.background = rip(if (on) accent() else off, 10)
            val fg = if (on) Color.BLACK else ink
            tv.second.setColorFilter(fg)
            tv.third.setTextColor(fg)
        }
        try {
            val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            volSeek?.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volSeek?.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (e: Exception) {
        }
        try {
            brightSeek?.progress = Settings.System.getInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
        }
        val b = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (sc > 0 && lvl >= 0) lvl * 100 / sc else 0
            batText?.text = "$pct%" + (if (chg) " · carregando" else "")
        }
    }
}
