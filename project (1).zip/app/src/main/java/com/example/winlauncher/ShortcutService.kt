package com.example.winlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Atalhos de teclado que funcionam DENTRO de outros apps (o Android só entrega teclas ao app em primeiro
 * plano; um serviço de acessibilidade com "filtrar eventos de teclas" é a única forma de ouvi-las).
 *
 * Atalhos: ALT + V abre o painel de volume do Android; ALT + R ou CMD/WIN + G começa/para a gravação de tela. Com o launcher na frente, o próprio
 * MainActivity trata o atalho (painel de volume do launcher), então aqui deixamos passar.
 */
class ShortcutService : AccessibilityService() {

    companion object {
        /** true enquanto o serviço de acessibilidade está ligado nas configurações do Android. */
        @Volatile
        var running = false
    }

    override fun onServiceConnected() {
        running = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // ALT + R: começa/para a gravação de tela com a última configuração salva (sem janelinha)
        // Acompanha Alt e CMD/WIN por conta própria: em alguns teclados/aparelhos o estado de modificador do
        // evento da tecla R/G vem vazio dentro de outros apps.
        when (event.keyCode) {
            KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> altDown = event.action == KeyEvent.ACTION_DOWN
            KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT -> metaDown = event.action == KeyEvent.ACTION_DOWN
        }
        val alt = altDown || event.isAltPressed
        val meta = metaDown || event.isMetaPressed
        val altR = event.keyCode == KeyEvent.KEYCODE_R && alt && !meta && !event.isCtrlPressed && !event.isShiftPressed
        // CMD/WIN + G: segundo atalho do gravador
        val metaG = event.keyCode == KeyEvent.KEYCODE_G && meta && !alt && !event.isCtrlPressed && !event.isShiftPressed
        if (altR || metaG) {
            if (VolumeButtonService.launcherForeground) return false // com o launcher na frente, a MainActivity trata
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) toggleRecord()
            return true
        }
        if (event.keyCode != KeyEvent.KEYCODE_V || !event.isAltPressed ||
            event.isCtrlPressed || event.isMetaPressed || event.isShiftPressed
        ) return false
        val dev = event.device
        if (dev == null || dev.isVirtual || !event.isFromSource(InputDevice.SOURCE_KEYBOARD)) return false
        // launcher na frente: quem trata é a MainActivity
        if (VolumeButtonService.launcherForeground) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) showVolumePanel()
        return true
    }

    private var altDown = false
    private var metaDown = false

    private fun toastDbg(msg: String) {
        try {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun toggleRecord() {
        if (ScreenRecordService.recording) {
            try {
                ScreenRecordService.stop(this)
            } catch (e: Exception) {
            }
            return
        }
        val intent = android.content.Intent(this, RecordStartActivity::class.java)
            .addFlags(
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                    android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
        // O Android bloqueia abrir telas "de trás" quando o app não tem janela visível. Primeiro cria uma janelinha
        // invisível (1x1 px), espera ela aparecer e só então tenta abrir. Se ainda assim não abrir, mostra um botão
        // flutuante "Gravar": o toque do usuário numa janela do app sempre libera a abertura.
        RecordStartActivity.launched = false
        toastDbg("Gravador: atalho recebido")
        val overlay = addInvisibleWindow()
        uiHandler.postDelayed({
            try {
                startActivity(intent)
            } catch (e: Exception) {
                toastDbg("Gravador: erro ao abrir: " + e.javaClass.simpleName + " " + (e.message ?: ""))
            }
        }, if (overlay != null) 250L else 0L)
        uiHandler.postDelayed({
            if (!RecordStartActivity.launched && !ScreenRecordService.recording) {
                toastDbg("Gravador: Android bloqueou a abertura, mostrando botão")
                showRecordButton(intent)
            }
        }, 1500)
        if (overlay != null) uiHandler.postDelayed({ removeInvisibleWindow(overlay) }, 4000)
    }

    private var recButton: android.view.View? = null

    private fun showRecordButton(intent: android.content.Intent) {
        try {
            hideRecordButton()
            val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            val tv = android.widget.TextView(this)
            tv.text = "\u25CF  Gravar a tela"
            tv.setTextColor(android.graphics.Color.WHITE)
            tv.textSize = 16f
            tv.setPadding(48, 28, 48, 28)
            val bg = android.graphics.drawable.GradientDrawable()
            bg.setColor(android.graphics.Color.parseColor("#E6C62828"))
            bg.cornerRadius = 80f
            tv.background = bg
            tv.setOnClickListener {
                hideRecordButton()
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    postRecordNotification(intent)
                }
            }
            val lp = android.view.WindowManager.LayoutParams(
                android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            lp.gravity = android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
            lp.y = 120
            wm.addView(tv, lp)
            recButton = tv
            uiHandler.postDelayed({ hideRecordButton() }, 7000)
        } catch (e: Exception) {
            postRecordNotification(intent)
        }
    }

    private fun hideRecordButton() {
        val v = recButton ?: return
        recButton = null
        removeInvisibleWindow(v)
    }

    private fun addInvisibleWindow(): android.view.View? {
        return try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            val v = android.view.View(this)
            val lp = android.view.WindowManager.LayoutParams(
                1, 1,
                android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            lp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
            wm.addView(v, lp)
            v
        } catch (e: Exception) {
            null
        }
    }

    private fun removeInvisibleWindow(v: android.view.View) {
        try {
            (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun postRecordNotification(intent: android.content.Intent) {
        try {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(
                android.app.NotificationChannel(
                    "rec_shortcut", "Atalho do gravador", android.app.NotificationManager.IMPORTANCE_HIGH
                )
            )
            val pi = android.app.PendingIntent.getActivity(
                this, 2, intent,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = android.app.Notification.Builder(this, "rec_shortcut")
                .setSmallIcon(R.drawable.ic_record)
                .setContentTitle("Gravador de tela")
                .setContentText("Toque para começar a gravar")
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(8000)
                .build()
            nm.notify(4714, n)
        } catch (e: Exception) {
        }
    }

    private fun showVolumePanel() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_SAME,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (e: Exception) {
        }
    }
}
