package com.example.winlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Atalhos de teclado que funcionam DENTRO de outros apps (o Android só entrega teclas ao app em primeiro
 * plano; um serviço de acessibilidade com "filtrar eventos de teclas" é a única forma de ouvi-las).
 *
 * Atalhos: ALT + V abre o painel de volume do Android; ALT + R começa/para a gravação de tela. Com o launcher na frente, o próprio
 * MainActivity trata o atalho (painel de volume do launcher), então aqui deixamos passar.
 */
class ShortcutService : AccessibilityService() {

    companion object {
        /** true enquanto o serviço de acessibilidade está ligado nas configurações do Android. */
        @Volatile
        var running = false
    }

    override fun onServiceConnected() {
        running = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // ALT + R: começa/para a gravação de tela com a última configuração salva (sem janelinha)
        if (event.keyCode == KeyEvent.KEYCODE_R && event.isAltPressed &&
            !event.isCtrlPressed && !event.isMetaPressed && !event.isShiftPressed
        ) {
            val d = event.device
            if (d == null || d.isVirtual || !event.isFromSource(InputDevice.SOURCE_KEYBOARD)) return false
            if (VolumeButtonService.launcherForeground) return false // com o launcher na frente, a MainActivity trata
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) toggleRecord()
            return true
        }
        if (event.keyCode != KeyEvent.KEYCODE_V || !event.isAltPressed ||
            event.isCtrlPressed || event.isMetaPressed || event.isShiftPressed
        ) return false
        val dev = event.device
        if (dev == null || dev.isVirtual || !event.isFromSource(InputDevice.SOURCE_KEYBOARD)) return false
        // launcher na frente: quem trata é a MainActivity
        if (VolumeButtonService.launcherForeground) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) showVolumePanel()
        return true
    }

    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun toggleRecord() {
        if (ScreenRecordService.recording) {
            try {
                ScreenRecordService.stop(this)
            } catch (e: Exception) {
            }
            return
        }
        val intent = android.content.Intent(this, RecordStartActivity::class.java)
            .addFlags(
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                    android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
        // O Android bloqueia abrir telas "de trás" quando o app não tem janela visível (Android 10+, ainda mais
        // no 14/15). Uma janelinha invisível de acessibilidade (1x1 px) conta como janela visível e libera o início.
        val overlay = addInvisibleWindow()
        try {
            startActivity(intent)
        } catch (e: Exception) {
            postRecordNotification(intent) // plano B: notificação que abre o gravador com um toque
        }
        if (overlay != null) uiHandler.postDelayed({ removeInvisibleWindow(overlay) }, 3000)
    }

    private fun addInvisibleWindow(): android.view.View? {
        return try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            val v = android.view.View(this)
            val lp = android.view.WindowManager.LayoutParams(
                1, 1,
                android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            lp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
            wm.addView(v, lp)
            v
        } catch (e: Exception) {
            null
        }
    }

    private fun removeInvisibleWindow(v: android.view.View) {
        try {
            (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun postRecordNotification(intent: android.content.Intent) {
        try {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(
                android.app.NotificationChannel(
                    "rec_shortcut", "Atalho do gravador", android.app.NotificationManager.IMPORTANCE_HIGH
                )
            )
            val pi = android.app.PendingIntent.getActivity(
                this, 2, intent,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = android.app.Notification.Builder(this, "rec_shortcut")
                .setSmallIcon(R.drawable.ic_record)
                .setContentTitle("Gravador de tela")
                .setContentText("Toque para começar a gravar")
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(8000)
                .build()
            nm.notify(4714, n)
        } catch (e: Exception) {
        }
    }

    private fun showVolumePanel() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_SAME,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (e: Exception) {
        }
    }
}
