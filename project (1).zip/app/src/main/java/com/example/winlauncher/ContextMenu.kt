package com.example.winlauncher

import android.app.Activity
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MenuItem(
    val label: String,
    val icon: Int = 0,
    val checked: Boolean = false,
    val enabled: Boolean = true,
    val children: List<MenuItem>? = null,
    val panel: (() -> View)? = null,
    val action: (() -> Unit)? = null
)

/**
 * Menu de contexto estilo Windows 11: cartão compacto, branco ~70% translúcido, cantos
 * arredondados e sombra suave. Submenus abrem ao passar o mouse (ou por toque).
 */
class ContextMenuHost(
    private val act: Activity,
    private val root: FrameLayout,
    private val hoverOpens: () -> Boolean
) {
    val layer = FrameLayout(act)

    private val cards = ArrayList<View>()
    private val lists = ArrayList<List<MenuItem>>()
    private val d = act.resources.displayMetrics.density
    private val ink = Color.parseColor("#1F1F1F")
    private val hoverBg = Color.parseColor("#1F000000")

    private companion object {
        /** Opacidade da película do vidro, igual em todos os cartões. */
        const val GLASS_TINT = 0xB0
    }

    val isShowing: Boolean get() = layer.visibility == View.VISIBLE

    init {
        layer.visibility = View.GONE
        layer.tag = CursorController.NOHAND
        layer.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) hide()
            true
        }
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private fun sw(): Int = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
    private fun sh(): Int = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels

    fun hide() {
        layer.removeAllViews()
        cards.clear()
        lists.clear()
        layer.visibility = View.GONE
    }

    /** x e y em coordenadas de tela (rawX/rawY). */
    fun show(items: List<MenuItem>, screenX: Int, screenY: Int) {
        hide()
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        val x = screenX - loc[0]
        val y = screenY - loc[1]
        layer.visibility = View.VISIBLE
        val card = buildList(items, 0)
        lists.add(items)
        cards.add(card)
        layer.addView(card)
        val m = dp(8)
        val w = cardWidth(card)
        val h = measuredHeight(card, w)
        var left = x
        if (left + w > sw() - m) left = x - w
        left = left.coerceIn(m, maxOf(m, sw() - w - m))
        var top = y
        if (top + h > sh() - m) top = y - h
        top = top.coerceIn(m, maxOf(m, sh() - h - m))
        position(card, left, top, w)
    }

    /** Abre programaticamente a linha [index] do nível [level] (usado após recriar a tela). */
    fun openRow(level: Int, index: Int) {
        if (level >= cards.size) return
        val items = lists[level]
        val card = cards[level] as? ViewGroup ?: return
        if (index < 0 || index >= items.size) return
        val row = card.getChildAt(index) ?: return
        openChild(level, items[index], row)
    }

    private fun cardWidth(card: View): Int = (card.layoutParams?.width ?: dp(220)).let {
        if (it > 0) minOf(it, sw() - dp(16)) else dp(220)
    }

    private fun measuredHeight(card: View, w: Int): Int {
        card.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return card.measuredHeight
    }

    private fun position(card: View, left: Int, top: Int, w: Int) {
        val lp = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        lp.leftMargin = left
        lp.topMargin = top
        card.layoutParams = lp
    }

    /**
     * Vidro único de TODOS os cartões (menu raiz, submenus e painéis de configuração):
     * desfoque real do wallpaper ([GlassDrawable]) + película branca translúcida + borda fina + cantos arredondados.
     */
    private fun applyGlass(v: View) {
        val r = dp(8).toFloat()
        val glass = GlassDrawable(v, argb(GLASS_TINT, Color.WHITE), r)
        val border = GradientDrawable()
        border.setColor(Color.TRANSPARENT)
        border.cornerRadius = r
        border.setStroke(dp(1), Color.parseColor("#59FFFFFF"))
        v.background = LayerDrawable(arrayOf<Drawable>(glass, border))
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
                outline.alpha = 0.5f
            }
        }
        v.clipToOutline = false
    }

    private fun argb(a: Int, rgb: Int): Int = (a shl 24) or (rgb and 0xFFFFFF)

    private fun buildList(items: List<MenuItem>, level: Int): LinearLayout {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        applyGlass(card)
        card.setPadding(dp(4), dp(4), dp(4), dp(4))
        card.elevation = dp(12).toFloat()
        card.isClickable = true
        card.tag = CursorController.NOHAND
        card.layoutParams = FrameLayout.LayoutParams(dp(232), ViewGroup.LayoutParams.WRAP_CONTENT)
        for (mi in items) {
            card.addView(buildRow(mi, level), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))
        }
        return card
    }

    private fun buildRow(item: MenuItem, level: Int): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(8), 0, dp(8), 0)

        val lead = FrameLayout(act)
        if (item.icon != 0) {
            val iv = ImageView(act)
            iv.setImageResource(item.icon)
            iv.setColorFilter(ink)
            lead.addView(iv, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        } else if (item.checked) {
            val tv = TextView(act)
            tv.text = "✓"
            tv.setTextColor(ink)
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            lead.addView(tv, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        }
        r.addView(lead, LinearLayout.LayoutParams(dp(24), dp(24)))

        val tv = TextView(act)
        tv.text = if (item.checked && item.icon != 0) "✓  " + item.label else item.label
        tv.setTextColor(ink)
        tv.textSize = 13f
        tv.maxLines = 1
        tv.alpha = if (item.enabled) 1f else 0.4f
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(8)
        r.addView(tv, tlp)

        if (item.children != null || item.panel != null) {
            val ch = TextView(act)
            ch.text = "›"
            ch.setTextColor(ink)
            ch.textSize = 16f
            r.addView(ch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        r.background = rowBg(false)
        r.isClickable = true
        r.setOnHoverListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> {
                    v.background = rowBg(true)
                    if (item.enabled) {
                        if (item.children != null || item.panel != null) {
                            if (hoverOpens()) openChild(level, item, v) else closeAbove(level)
                        } else {
                            closeAbove(level)
                        }
                    }
                }
                MotionEvent.ACTION_HOVER_EXIT -> v.background = rowBg(false)
            }
            false
        }
        r.setOnClickListener { v ->
            if (item.enabled) {
                if (item.children != null || item.panel != null) {
                    openChild(level, item, v)
                } else {
                    hide()
                    item.action?.invoke()
                }
            }
        }
        return r
    }

    private fun rowBg(hover: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(if (hover) hoverBg else Color.TRANSPARENT)
        g.cornerRadius = dp(5).toFloat()
        return g
    }

    private fun closeAbove(level: Int) {
        while (cards.size > level + 1) {
            val c = cards.removeAt(cards.size - 1)
            layer.removeView(c)
            if (lists.size > cards.size) lists.removeAt(lists.size - 1)
        }
    }

    private fun openChild(level: Int, item: MenuItem, anchor: View) {
        if (level >= cards.size) return
        closeAbove(level)
        val parent = cards[level]
        val plp = parent.layoutParams as FrameLayout.LayoutParams
        val m = dp(8)

        val card: View
        if (item.children != null) {
            card = buildList(item.children, level + 1)
            lists.add(item.children)
        } else {
            val content = item.panel!!.invoke()
            val sv = ScrollView(act)
            applyGlass(sv)
            sv.elevation = dp(12).toFloat()
            sv.isClickable = true
            sv.tag = CursorController.NOHAND
            content.setPadding(dp(14), dp(12), dp(14), dp(12))
            sv.addView(content)
            sv.layoutParams = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT)
            card = sv
            lists.add(emptyList())
        }
        cards.add(card)
        layer.addView(card)

        val w = cardWidth(card)
        var h = measuredHeight(card, w)
        val maxH = sh() - 2 * m
        val needsCap = h > maxH
        if (needsCap) h = maxH

        val pw = plp.width
        var left = plp.leftMargin + pw - dp(2)
        if (left + w > sw() - m) left = plp.leftMargin - w + dp(2)
        left = left.coerceIn(m, maxOf(m, sw() - w - m))

        val loc = IntArray(2)
        val rloc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        root.getLocationOnScreen(rloc)
        var top = loc[1] - rloc[1] - dp(4)
        top = top.coerceIn(m, maxOf(m, sh() - h - m))

        val lp = FrameLayout.LayoutParams(w, if (needsCap) h else ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        lp.leftMargin = left
        lp.topMargin = top
        card.layoutParams = lp
    }
}
