package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Wallpapers embutidos da galeria da tela de bloqueio. Todos são desenhados em código (sem arquivos de imagem
 * ou vídeo), então não pesam no APK. Os animados só consomem CPU/GPU enquanto a tela de bloqueio está aberta.
 */

/** Desenha um quadro. [t] = segundos desde o início (0 nos estáticos). Sem alocação por quadro. */
interface WpPainter {
    fun draw(canvas: Canvas, w: Int, h: Int, t: Float)
}

class WpPreset(val id: String, val name: String, val animated: Boolean, val make: () -> WpPainter)

class WpGlow(val fx: Float, val fy: Float, val fr: Float, val color: Int)

object WpPresets {

    val statics: List<WpPreset> = listOf(
        grad(
            "oceano", "Oceano",
            intArrayOf(col("#0B1E3F"), col("#1B5FD0"), col("#0A2A66")),
            listOf(WpGlow(0.78f, 0.20f, 0.60f, col("#5560CDFF")), WpGlow(0.15f, 0.90f, 0.50f, col("#334A7BFF")))
        ),
        grad(
            "por-do-sol", "Pôr do sol",
            intArrayOf(col("#2B1055"), col("#B8407A"), col("#F59E5B")),
            listOf(WpGlow(0.50f, 1.00f, 0.70f, col("#66FFD27A")), WpGlow(0.20f, 0.10f, 0.50f, col("#447A5CFF")))
        ),
        grad(
            "floresta", "Floresta",
            intArrayOf(col("#07201A"), col("#12624A"), col("#7BC47F")),
            listOf(WpGlow(0.30f, 0.10f, 0.60f, col("#4466E0A8")), WpGlow(0.85f, 0.85f, 0.50f, col("#33B8F5A0")))
        ),
        grad(
            "grafite", "Grafite",
            intArrayOf(col("#101216"), col("#262A33"), col("#454B59")),
            listOf(WpGlow(0.80f, 0.15f, 0.55f, col("#33FFFFFF")))
        ),
        grad(
            "lavanda", "Lavanda",
            intArrayOf(col("#24153F"), col("#6E4FE0"), col("#C7A8FF")),
            listOf(WpGlow(0.20f, 0.20f, 0.60f, col("#55FF9AE6")), WpGlow(0.85f, 0.80f, 0.60f, col("#4460CDFF")))
        ),
        grad(
            "brasa", "Brasa",
            intArrayOf(col("#1A0507"), col("#8E1F1F"), col("#FF8A3D")),
            listOf(WpGlow(0.70f, 1.00f, 0.70f, col("#66FFB347")))
        )
    )

    val animated: List<WpPreset> = listOf(
        WpPreset("aurora", "Aurora", true) { AuroraPainter() },
        WpPreset("ondas", "Ondas", true) { WavesPainter() },
        WpPreset("bolhas", "Bolhas", true) { BubblesPainter() },
        WpPreset("estrelas", "Estrelas", true) { StarsPainter() }
    )

    val all: List<WpPreset> get() = statics + animated

    fun find(id: String): WpPreset? = all.firstOrNull { it.id == id }

    /** Miniatura da galeria (os animados aparecem num quadro fixo). */
    fun thumb(p: WpPreset, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(max(1, w), max(1, h), Bitmap.Config.ARGB_8888)
        p.make().draw(Canvas(b), b.width, b.height, 2.5f)
        return b
    }

    private fun grad(id: String, name: String, colors: IntArray, glows: List<WpGlow>) =
        WpPreset(id, name, false) { GradientPainter(colors, glows) }
}

private fun col(s: String): Int = Color.parseColor(s)

private const val TWO_PI = 6.2831855f

// ---------------------------------------------------------------------- estáticos: degradê + brilhos suaves

private class GradientPainter(private val colors: IntArray, private val glows: List<WpGlow>) : WpPainter {
    private val bg = Paint()
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lw = -1
    private var lh = -1
    private var shaders: List<RadialGradient> = emptyList()

    private fun build(w: Int, h: Int) {
        bg.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), colors, null, Shader.TileMode.CLAMP)
        val r0 = max(w, h).toFloat()
        shaders = glows.map {
            RadialGradient(it.fx * w, it.fy * h, r0 * it.fr, it.color, it.color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        }
    }

    override fun draw(canvas: Canvas, w: Int, h: Int, t: Float) {
        if (w != lw || h != lh) {
            lw = w
            lh = h
            build(w, h)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        for (s in shaders) {
            gp.shader = s
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gp)
        }
    }
}

// ---------------------------------------------------------------------- animado: aurora (manchas de luz flutuando)

private class AuroraPainter : WpPainter {
    private class Blob(
        val color: Int, val fx: Float, val fy: Float, val rf: Float,
        val sp: Float, val ax: Float, val ay: Float, val ph: Float
    )

    private val blobs = listOf(
        Blob(col("#9900E5A0"), 0.25f, 0.30f, 0.55f, 0.35f, 0.20f, 0.12f, 0.0f),
        Blob(col("#993D7BFF"), 0.75f, 0.25f, 0.60f, 0.28f, 0.18f, 0.15f, 2.1f),
        Blob(col("#808A4DFF"), 0.50f, 0.75f, 0.65f, 0.22f, 0.25f, 0.10f, 4.2f),
        Blob(col("#8000D0FF"), 0.15f, 0.85f, 0.50f, 0.31f, 0.15f, 0.12f, 5.3f)
    )
    private val bg = Paint()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lw = -1
    private var lh = -1
    private var shaders: List<RadialGradient> = emptyList()
    private var radii = FloatArray(0)

    private fun build(w: Int, h: Int) {
        bg.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(), col("#061426"), col("#0A2C4D"), Shader.TileMode.CLAMP
        )
        val r0 = max(w, h).toFloat()
        radii = FloatArray(blobs.size) { r0 * blobs[it].rf }
        shaders = blobs.mapIndexed { i, b ->
            RadialGradient(0f, 0f, radii[i], b.color, b.color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        }
    }

    override fun draw(canvas: Canvas, w: Int, h: Int, t: Float) {
        if (w != lw || h != lh) {
            lw = w
            lh = h
            build(w, h)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        for (i in blobs.indices) {
            val b = blobs[i]
            val cx = (b.fx + b.ax * sin(t * b.sp + b.ph)) * w
            val cy = (b.fy + b.ay * cos(t * b.sp * 0.8f + b.ph)) * h
            p.shader = shaders[i]
            val save = canvas.save()
            canvas.translate(cx, cy)
            canvas.drawCircle(0f, 0f, radii[i], p)
            canvas.restoreToCount(save)
        }
    }
}

// ---------------------------------------------------------------------- animado: ondas em camadas

private class WavesPainter : WpPainter {
    private class Layer(
        val y: Float, val amp: Float, val wl: Float, val sp: Float, val ph: Float, val color: Int
    )

    private val layers = listOf(
        Layer(0.58f, 0.035f, 0.90f, 0.55f, 0.0f, col("#2E7FD4FF")),
        Layer(0.66f, 0.040f, 0.70f, -0.45f, 1.7f, col("#3A4FB6FF")),
        Layer(0.74f, 0.045f, 1.10f, 0.35f, 3.1f, col("#4A2B7BE0")),
        Layer(0.84f, 0.050f, 0.80f, -0.30f, 4.4f, col("#66123F9A"))
    )
    private val bg = Paint()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var lw = -1
    private var lh = -1

    private fun yAt(l: Layer, x: Float, w: Int, h: Int, t: Float): Float =
        (l.y + l.amp * sin(x / (l.wl * w) * TWO_PI + t * l.sp + l.ph)) * h

    override fun draw(canvas: Canvas, w: Int, h: Int, t: Float) {
        if (w != lw || h != lh) {
            lw = w
            lh = h
            bg.shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(), col("#07203F"), col("#0E5C8F"), Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val step = max(8f, w / 90f)
        for (l in layers) {
            path.reset()
            path.moveTo(0f, h.toFloat())
            var x = 0f
            while (x < w) {
                path.lineTo(x, yAt(l, x, w, h, t))
                x += step
            }
            path.lineTo(w.toFloat(), yAt(l, w.toFloat(), w, h, t))
            path.lineTo(w.toFloat(), h.toFloat())
            path.close()
            p.color = l.color
            canvas.drawPath(path, p)
        }
    }
}

// ---------------------------------------------------------------------- animado: bolhas subindo

private class BubblesPainter : WpPainter {
    private val n = 22
    private val rnd = Random(7)
    private val bx = FloatArray(n) { rnd.nextFloat() }
    private val bs = FloatArray(n) { 0.018f + rnd.nextFloat() * 0.050f } // raio (fração do menor lado)
    private val bv = FloatArray(n) { 0.015f + rnd.nextFloat() * 0.045f } // subida por segundo (fração da altura)
    private val bp = FloatArray(n) { rnd.nextFloat() }

    private val bg = Paint()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(36, 255, 255, 255) }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(89, 255, 255, 255)
    }
    private var lw = -1
    private var lh = -1

    override fun draw(canvas: Canvas, w: Int, h: Int, t: Float) {
        if (w != lw || h != lh) {
            lw = w
            lh = h
            bg.shader = LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(col("#1A0B3D"), col("#2B3FA8"), col("#1B8FD0")), null, Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val base = min(w, h).toFloat()
        for (i in 0 until n) {
            val r = bs[i] * base
            val prog = (t * bv[i] + bp[i]) % 1f
            val y = h + r - prog * (h + 2f * r)
            val x = (bx[i] + 0.02f * sin(t * 0.6f + bp[i] * TWO_PI)) * w
            ring.strokeWidth = max(1f, r * 0.06f)
            canvas.drawCircle(x, y, r, fill)
            canvas.drawCircle(x, y, r, ring)
        }
    }
}

// ---------------------------------------------------------------------- animado: céu estrelado

private class StarsPainter : WpPainter {
    private val n = 120
    private val rnd = Random(21)
    private val sx = FloatArray(n) { rnd.nextFloat() }
    private val sy = FloatArray(n) { rnd.nextFloat() }
    private val sr = FloatArray(n) { 0.5f + rnd.nextFloat() * 1.4f }
    private val sp = FloatArray(n) { 0.6f + rnd.nextFloat() * 2.2f }
    private val sph = FloatArray(n) { rnd.nextFloat() * TWO_PI }
    private val sl = FloatArray(n) { 0.2f + rnd.nextFloat() * 0.8f } // camada: velocidade da deriva

    private val bg = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var lw = -1
    private var lh = -1

    override fun draw(canvas: Canvas, w: Int, h: Int, t: Float) {
        if (w != lw || h != lh) {
            lw = w
            lh = h
            bg.shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(col("#02030A"), col("#0B1030"), col("#1B2150")), null, Shader.TileMode.CLAMP
            )
            glow.shader = RadialGradient(
                w * 0.5f, h * 1.1f, max(w, h) * 0.7f, col("#3358B0FF"), col("#0058B0FF"), Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), glow)
        val scale = max(1f, min(w, h) / 360f)
        for (i in 0 until n) {
            val x = ((sx[i] + t * 0.006f * sl[i]) % 1f) * w
            val y = sy[i] * h
            val tw = 0.5f + 0.5f * sin(t * sp[i] + sph[i])
            p.alpha = (80 + 175 * tw).toInt()
            canvas.drawCircle(x, y, sr[i] * scale, p)
        }
    }
}
