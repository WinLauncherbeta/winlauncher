package com.example.winlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Aviso pequeno no canto inferior direito (fundo escuro arredondado, letra pequena, faixa vermelha para erros).
 * Funciona por cima de qualquer app: usa a janela de acessibilidade quando chamado do serviço, ou "exibir sobre
 * outros apps" quando disponível; se nenhum dos dois der, cai no Toast normal do Android.
 */
object MiniToast {
    private val handler = Handler(Looper.getMainLooper())
    private var current: View? = null
    private var currentWm: WindowManager? = null

    fun error(ctx: Context, msg: String, accessibility: Boolean = false) = show(ctx, "Erro", msg, true, accessibility)
    fun info(ctx: Context, msg: String, accessibility: Boolean = false) = show(ctx, "WinLauncher", msg, false, accessibility)

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun show(ctx: Context, title: String, msg: String, isError: Boolean, accessibility: Boolean, millis: Long = 5000) {
        handler.post {
            try {
                hide()
                val type = when {
                    accessibility -> WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    Build.VERSION.SDK_INT >= 26 && Settings.canDrawOverlays(ctx) ->
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else -> {
                        Toast.makeText(ctx.applicationContext, "$title: $msg", Toast.LENGTH_LONG).show()
                        return@post
                    }
                }
                val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val card = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 9))
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#F2202226"))
                        cornerRadius = dp(ctx, 10).toFloat()
                        setStroke(dp(ctx, 1), if (isError) Color.parseColor("#E5484D") else Color.parseColor("#3A3D44"))
                    }
                    elevation = dp(ctx, 6).toFloat()
                }
                card.addView(TextView(ctx).apply {
                    text = title
                    textSize = 10f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isError) Color.parseColor("#FF8589") else Color.parseColor("#9AA0AA"))
                })
                card.addView(TextView(ctx).apply {
                    text = msg
                    textSize = 11f
                    setTextColor(Color.parseColor("#ECEDEF"))
                    maxWidth = dp(ctx, 260)
                    setPadding(0, dp(ctx, 2), 0, 0)
                })
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.BOTTOM or Gravity.END
                lp.x = dp(ctx, 16)
                lp.y = dp(ctx, 56) // acima da barra de tarefas/navegação
                wm.addView(card, lp)
                current = card
                currentWm = wm
                handler.postDelayed({ hide() }, millis)
            } catch (e: Exception) {
                try {
                    Toast.makeText(ctx.applicationContext, "$title: $msg", Toast.LENGTH_LONG).show()
                } catch (e2: Exception) {
                }
            }
        }
    }

    private fun hide() {
        val v = current ?: return
        current = null
        try {
            currentWm?.removeView(v)
        } catch (e: Exception) {
        }
    }
}
