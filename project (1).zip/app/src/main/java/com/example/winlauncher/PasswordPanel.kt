package com.example.winlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Painel de senha do WinLauncher, com o fundo do modo claro ou escuro.
 *  - [manage]: criar, alterar ou remover a senha (Configurações > Segurança). Se já existe senha,
 *    pede a atual e mostra a opção de remover.
 *  - [verify]: pede a senha antes de sair da tela de bloqueio.
 */
class PasswordPanel private constructor(
    ctx: Context,
    private val prefs: SharedPreferences,
    private val light: Boolean,
    private val verifyOnly: Boolean,
    private val onDone: (Boolean) -> Unit
) : FrameLayout(ctx) {

    companion object {
        fun manage(ctx: Context, prefs: SharedPreferences, light: Boolean, onDone: (Boolean) -> Unit = {}): PasswordPanel =
            PasswordPanel(ctx, prefs, light, false, onDone)

        fun verify(ctx: Context, prefs: SharedPreferences, light: Boolean, onOk: () -> Unit): PasswordPanel =
            PasswordPanel(ctx, prefs, light, true) { ok -> if (ok) onOk() }
    }

    private val d = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    private val hasPass = LockPassword.has(prefs)
    private val cText = if (light) Color.parseColor("#1F1F1F") else Color.WHITE
    private val cSub = if (light) Color.parseColor("#88000000") else Color.parseColor("#B3FFFFFF")
    private val cField = if (light) Color.parseColor("#14000000") else Color.parseColor("#26FFFFFF")
    private val cCard = if (light) Color.parseColor("#F5F5F5") else Color.parseColor("#202020")
    private val cAccent = Color.parseColor("#3D9DFF")
    private val cDanger = Color.parseColor("#D8283A")

    private val card = LinearLayout(ctx)
    private val msg = TextView(ctx)
    private val inputs = ArrayList<EditText>()

    init {
        isClickable = true
        setBackgroundColor(Color.parseColor("#66000000"))

        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(20), dp(18), dp(20), dp(16))
        card.background = rounded(cCard, 16)
        card.isClickable = true
        addView(card, LayoutParams(dp(330), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val title = TextView(ctx).apply {
            text = when {
                verifyOnly -> "Digite a senha"
                hasPass -> "Senha do WinLauncher"
                else -> "Criar senha"
            }
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        card.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        msg.setTextColor(cSub)
        msg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        msg.text = when {
            verifyOnly -> "A senha é necessária para sair da tela de bloqueio."
            hasPass -> "Digite a senha atual para alterar ou remover."
            else -> "Use pelo menos ${LockPassword.MIN_LENGTH} caracteres."
        }
        card.addView(msg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })

        val hints = when {
            verifyOnly -> listOf("Senha")
            hasPass -> listOf("Senha atual", "Nova senha", "Confirmar nova senha")
            else -> listOf("Nova senha", "Confirmar senha")
        }
        for (h in hints) {
            val et = EditText(ctx).apply {
                hint = h
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                isSingleLine = true
                setTextColor(cText)
                setHintTextColor(cSub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(cField, 10)
            }
            inputs.add(et)
            card.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        if (!verifyOnly && hasPass) {
            row.addView(button("Remover senha", cDanger, primary = false) { remove() }, lpBtn(true))
        }
        row.addView(button("Cancelar", cText, primary = false) { finish(false) }, lpBtn(false))
        row.addView(button(if (verifyOnly) "Desbloquear" else "Salvar", cAccent, primary = true) { submit() }, lpBtn(false))
        card.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })
    }

    private fun lpBtn(first: Boolean): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (!first) leftMargin = dp(8)
        }

    private fun submit() {
        if (verifyOnly) {
            if (LockPassword.check(prefs, inputs[0].text.toString())) {
                finish(true)
            } else {
                wrong("Senha incorreta")
            }
            return
        }
        val newPass: String
        val confirm: String
        if (hasPass) {
            if (!LockPassword.check(prefs, inputs[0].text.toString())) {
                wrong("Senha atual incorreta")
                return
            }
            newPass = inputs[1].text.toString()
            confirm = inputs[2].text.toString()
        } else {
            newPass = inputs[0].text.toString()
            confirm = inputs[1].text.toString()
        }
        when {
            newPass.length < LockPassword.MIN_LENGTH -> wrong("A senha precisa de pelo menos ${LockPassword.MIN_LENGTH} caracteres")
            newPass != confirm -> wrong("As senhas não são iguais")
            else -> {
                LockPassword.set(prefs, newPass)
                finish(true)
            }
        }
    }

    private fun remove() {
        if (!LockPassword.check(prefs, inputs[0].text.toString())) {
            wrong("Digite a senha atual para remover")
            return
        }
        LockPassword.remove(prefs)
        finish(true)
    }

    private fun wrong(text: String) {
        msg.text = text
        msg.setTextColor(cDanger)
        inputs.forEach { it.text.clear() }
        inputs.firstOrNull()?.requestFocus()
    }

    private fun finish(ok: Boolean) {
        (parent as? ViewGroup)?.removeView(this)
        onDone(ok)
    }

    private fun button(label: String, color: Int, primary: Boolean, onClick: () -> Unit): TextView =
        TextView(context).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setTextColor(if (primary) Color.WHITE else color)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(9), dp(16), dp(9))
            background = rounded(if (primary) color else Color.TRANSPARENT, 8)
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }
}
