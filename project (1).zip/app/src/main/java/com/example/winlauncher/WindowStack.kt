package com.example.winlauncher

import android.view.View
import android.widget.FrameLayout

/** Ordem das janelas de apps na tela (a janela da frente fica por último na lista de filhos do root). */
object WindowStack {

    /**
     * Traz a camada [layer] para a frente das outras janelas, mas mantém [above] (o menu de contexto)
     * por cima dela. Não faz nada se a janela já estiver logo abaixo do menu.
     */
    fun raise(root: FrameLayout, layer: View, above: View?) {
        if (above == null) return
        if (root.indexOfChild(layer) < 0 || root.indexOfChild(above) < 0) return
        if (root.indexOfChild(layer) == root.indexOfChild(above) - 1) return
        val lp = layer.layoutParams
        root.removeView(layer)
        root.addView(layer, root.indexOfChild(above), lp)
    }

    /** Verdadeiro se [layer] já é a janela da frente (logo abaixo do menu [above]). */
    fun isTop(root: FrameLayout, layer: View, above: View?): Boolean {
        if (above == null) return true
        val i = root.indexOfChild(layer)
        val j = root.indexOfChild(above)
        return i >= 0 && j >= 0 && i == j - 1
    }
}
