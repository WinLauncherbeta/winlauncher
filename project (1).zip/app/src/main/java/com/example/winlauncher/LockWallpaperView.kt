package com.example.winlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Animatable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Build
import android.os.SystemClock
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import java.io.File

/**
 * Fundo da tela de bloqueio do WinLauncher. Fica dentro de [LockScreen.wallpaperSlot], atrás de tudo.
 *
 * Tipos de fundo:
 *  - padrão: não desenha nada (aparece o degradê da própria tela de bloqueio);
 *  - preset: degradê estático ou animação desenhada em código ([WpPresets]);
 *  - arquivo importado: imagem, GIF/WebP animado ou vídeo em loop (sem som).
 *
 * Desempenho:
 *  - vídeo usa MediaPlayer + TextureView (funciona dentro da animação de zoom/fade da tela de bloqueio);
 *  - o primeiro quadro (poster) fica por baixo do vídeo: não há tela preta ao carregar e o desfoque de vidro
 *    dos painéis consegue "enxergar" o fundo;
 *  - só toca/anima enquanto [setActive] for true (tela de bloqueio aberta e app em primeiro plano);
 *    ao fechar ou sair do app o player é liberado e as animações param;
 *  - imagens são decodificadas fora da thread principal e já reduzidas ao tamanho da tela.
 *
 * Nada aqui usa WallpaperManager nem altera o papel de parede do Android.
 */
class LockWallpaperView(ctx: Context, private val store: LockWallpaperStore) : FrameLayout(ctx) {

    companion object {
        private const val FADE_MS = 400L
        private const val FRAME_MS = 33L // animações procedurais a ~30 quadros/s
    }

    // ------------------------------------------------------------------ conteúdos

    private abstract class Content(val view: View) {
        open fun setActive(a: Boolean) {}
        open fun release() {}
    }

    /** Animação/degradê desenhado em código. */
    private class ProceduralView(ctx: Context, private val preset: WpPreset) : View(ctx) {
        private val painter = preset.make()
        private val t0 = SystemClock.uptimeMillis()
        private var running = false
        private var last = 0L

        private val loop = object : Runnable {
            override fun run() {
                if (!running) return
                val now = SystemClock.uptimeMillis()
                if (now - last >= FRAME_MS) {
                    last = now
                    invalidate()
                }
                postOnAnimation(this)
            }
        }

        fun setRunning(r: Boolean) {
            if (r == running) return
            running = r
            removeCallbacks(loop)
            if (r && preset.animated) postOnAnimation(loop)
        }

        override fun onDraw(canvas: Canvas) {
            val t = if (preset.animated) (SystemClock.uptimeMillis() - t0) / 1000f else 0f
            painter.draw(canvas, width, height, t)
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (running && preset.animated) postOnAnimation(loop)
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(loop)
            super.onDetachedFromWindow()
        }
    }

    private class ProceduralContent(ctx: Context, preset: WpPreset) : Content(ProceduralView(ctx, preset)) {
        override fun setActive(a: Boolean) {
            (view as ProceduralView).setRunning(a)
        }
    }

    /** Imagem estática ou GIF/WebP animado. Nos animados, o primeiro quadro fica por baixo. */
    private class ImageContent(ctx: Context, d: Drawable, poster: Bitmap?) : Content(FrameLayout(ctx)) {
        private var animatable: Animatable? = null

        init {
            val root = view as FrameLayout
            if (Build.VERSION.SDK_INT >= 28 && d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                animatable = d
                if (poster != null) {
                    val pv = ImageView(ctx)
                    pv.scaleType = ImageView.ScaleType.CENTER_CROP
                    pv.setImageBitmap(poster)
                    root.addView(pv, wpFill())
                }
            }
            val iv = ImageView(ctx)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageDrawable(d)
            root.addView(iv, wpFill())
        }

        override fun setActive(a: Boolean) {
            val an = animatable ?: return
            if (a) an.start() else an.stop()
        }

        override fun release() {
            animatable?.stop()
            animatable = null
        }
    }

    /** Vídeo em loop, mudo, preenchendo a tela (corte central). */
    private class VideoContent(ctx: Context, private val file: File, poster: Bitmap?) : Content(FrameLayout(ctx)) {
        private val tv = TextureView(ctx)
        private var surface: Surface? = null
        private var player: MediaPlayer? = null
        private var active = false
        private var vw = 0
        private var vh = 0

        init {
            val root = view as FrameLayout
            val pv = ImageView(ctx)
            pv.scaleType = ImageView.ScaleType.CENTER_CROP
            if (poster != null) pv.setImageBitmap(poster)
            root.addView(pv, wpFill())

            tv.isOpaque = false // transparente até o 1º quadro: o poster aparece por baixo
            root.addView(tv, wpFill())
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    surface = Surface(st)
                    applyCrop()
                    startPlayer()
                }

                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                    applyCrop()
                }

                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                    stopPlayer()
                    surface?.release()
                    surface = null
                    return true
                }

                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }

        /** O TextureView estica o vídeo na tela; esta matriz devolve a proporção e corta o excesso (como CENTER_CROP). */
        private fun applyCrop() {
            val w = tv.width
            val h = tv.height
            if (vw <= 0 || vh <= 0 || w <= 0 || h <= 0) return
            val s = maxOf(w.toFloat() / vw, h.toFloat() / vh)
            val m = Matrix()
            m.setScale(vw * s / w, vh * s / h, w / 2f, h / 2f)
            tv.setTransform(m)
        }

        private fun startPlayer() {
            val s = surface ?: return
            if (!active || player != null) return
            val p = MediaPlayer()
            try {
                p.setDataSource(file.absolutePath)
                p.setSurface(s)
                p.isLooping = true
                p.setVolume(0f, 0f)
                p.setOnVideoSizeChangedListener { _, w, h ->
                    vw = w
                    vh = h
                    applyCrop()
                }
                p.setOnErrorListener { _, _, _ ->
                    stopPlayer()
                    true
                }
                p.setOnPreparedListener { it.start() }
                p.prepareAsync()
                player = p
            } catch (e: Exception) {
                try {
                    p.release()
                } catch (e2: Exception) {
                }
                player = null
            }
        }

        private fun stopPlayer() {
            val p = player ?: return
            player = null
            try {
                p.setOnPreparedListener(null)
                p.setOnErrorListener(null)
                p.setOnVideoSizeChangedListener(null)
            } catch (e: Exception) {
            }
            try {
                p.stop()
            } catch (e: Exception) {
            }
            try {
                p.release()
            } catch (e: Exception) {
            }
        }

        override fun setActive(a: Boolean) {
            active = a
            if (a) startPlayer() else stopPlayer()
        }

        override fun release() {
            active = false
            stopPlayer()
        }
    }

    // ------------------------------------------------------------------ troca com transição suave

    private var current: Content? = null
    private var outgoing: Content? = null
    private var gen = 0
    private var active = false

    /** Dados decodificados fora da thread principal; as views só são criadas na thread principal. */
    private class Decoded(val file: File, val isVideo: Boolean, val drawable: Drawable?, val poster: Bitmap?)

    /**
     * Aplica um fundo. [animate] = transição suave (crossfade); false = troca imediata (ao criar a tela).
     * Arquivos importados são decodificados em segundo plano; se o arquivo sumiu, volta ao padrão.
     */
    fun setWallpaper(sel: WpSel, animate: Boolean) {
        val g = ++gen
        when (sel) {
            is WpSel.Default -> swap(null, animate)
            is WpSel.Preset -> swap(ProceduralContent(context, sel.preset), animate)
            is WpSel.Imported -> {
                val e = sel.file
                Thread {
                    val dec = decode(e)
                    post {
                        if (g != gen) return@post // uma escolha mais nova já assumiu
                        val c = dec?.let { makeContent(it) }
                        if (c == null) {
                            store.select(WpSel.Default) // arquivo sumiu ou corrompido: volta ao padrão
                            swap(null, animate)
                        } else {
                            swap(c, animate)
                        }
                    }
                }.start()
            }
        }
    }

    /** Liga/desliga animações e vídeo. Só deve ficar ativo com a tela de bloqueio aberta e o app visível. */
    fun setActive(a: Boolean) {
        active = a
        current?.setActive(a)
        outgoing?.setActive(a)
    }

    private fun decode(e: WpFile): Decoded? {
        val f = store.fileOf(e)
        if (!f.exists()) return null
        val poster = try {
            BitmapFactory.decodeFile(store.posterOf(e).absolutePath)
        } catch (ex: Throwable) {
            null
        }
        if (e.isVideo) return Decoded(f, true, null, poster)
        val dm = resources.displayMetrics
        val d: Drawable? = try {
            if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val sc = maxOf(
                        dm.widthPixels.toFloat() / info.size.width,
                        dm.heightPixels.toFloat() / info.size.height
                    )
                    if (sc < 1f) {
                        decoder.setTargetSize(
                            maxOf(1, (info.size.width * sc).toInt()),
                            maxOf(1, (info.size.height * sc).toInt())
                        )
                    }
                }
            } else {
                store.decodeBitmap(f, dm.widthPixels, dm.heightPixels)?.let { BitmapDrawable(resources, it) }
            }
        } catch (ex: Throwable) {
            null
        }
        return if (d == null) null else Decoded(f, false, d, poster)
    }

    private fun makeContent(dec: Decoded): Content? =
        if (dec.isVideo) VideoContent(context, dec.file, dec.poster)
        else dec.drawable?.let { ImageContent(context, it, dec.poster) }

    private fun swap(next: Content?, animate: Boolean) {
        finishFade() // termina na hora a transição anterior (se houver)
        val old = current
        current = next
        if (next != null) {
            addView(next.view, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            next.setActive(active)
        }
        if (!animate || !isShown) {
            // sem animação (ou tela de bloqueio fechada): troca direta
            old?.let {
                removeView(it.view)
                it.release()
            }
            next?.view?.alpha = 1f
            return
        }
        outgoing = old
        val ease = PathInterpolator(0.2f, 0f, 0f, 1f)
        if (next != null) {
            next.view.alpha = 0f
            next.view.animate().alpha(1f).setDuration(FADE_MS).setInterpolator(ease)
                .withEndAction { finishFade() }
                .start()
        } else if (old != null) {
            old.view.animate().alpha(0f).setDuration(FADE_MS).setInterpolator(ease)
                .withEndAction { finishFade() }
                .start()
        }
    }

    private fun finishFade() {
        current?.let {
            it.view.animate().cancel()
            it.view.alpha = 1f
        }
        outgoing?.let {
            it.view.animate().cancel()
            removeView(it.view)
            it.release()
        }
        outgoing = null
    }
}

private fun wpFill() = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
