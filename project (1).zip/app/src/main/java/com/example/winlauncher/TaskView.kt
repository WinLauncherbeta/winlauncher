package com.example.winlauncher

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.VectorDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** Uma janela da WinLauncher, como aparece na Visão de Tarefas. */
class TaskEntry(
    val title: String,
    val icon: Int,
    val layer: View,
    val isOpen: () -> Boolean,
    val raise: () -> Unit,
    val close: () -> Unit
)

/**
 * Visão de Tarefas: mostra só as janelas nativas da WinLauncher em cartões.
 *  - Toque no cartão: traz a janela para frente e fecha a visão.
 *  - X do cartão: fecha a janela (só as da própria WinLauncher).
 *  - Toque fora do painel: volta para a tela inicial.
 *  - Botão direito no fundo: menu Diminuir / Aumentar / Tamanho padrão (a escala fica salva).
 */
class TaskView(
    private val act: MainActivity,
    private val sp: SharedPreferences,
    private val entries: () -> List<TaskEntry>,
    private val locked: () -> Boolean
) : FrameLayout(act) {

    companion object {
        private const val KEY_SCALE = "taskview_scale"
        private const val MIN_SCALE = 60
        private const val MAX_SCALE = 160
        private const val STEP = 20
        private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val d = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private fun dp(v: Float): Int = (v * d + 0.5f).toInt()

    private var scale = sp.getInt(KEY_SCALE, 100)
    var taskShown = false
        private set

    private val light: Boolean get() = act.isLightTheme()
    private val cText: Int get() = if (light) Color.parseColor("#1F1F1F") else Color.parseColor("#F2F2F2")
    private val cPanel: Int get() = if (light) Color.argb(215, 243, 243, 243) else Color.argb(215, 28, 28, 28)
    private val cCard: Int get() = if (light) Color.argb(240, 255, 255, 255) else Color.argb(235, 44, 44, 44)

    private val panel = LinearLayout(act)
    private val list = LinearLayout(act)
    private val menu = LinearLayout(act)
    private var menuShown = false

    init {
        visibility = GONE
        isClickable = true
        setBackgroundColor(Color.parseColor("#66000000"))

        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(20), dp(20), dp(20), dp(20))
        list.orientation = LinearLayout.VERTICAL
        panel.addView(list, LinearLayout.LayoutParams(WRAP, WRAP))
        addView(panel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        menu.orientation = LinearLayout.VERTICAL
        menu.setPadding(dp(6), dp(6), dp(6), dp(6))
        menu.visibility = GONE
        val labels = listOf("Diminuir", "Aumentar", "Tamanho padrão")
        for ((i, label) in labels.withIndex()) {
            val tv = TextView(act)
            tv.text = label
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            tv.isClickable = true
            tv.setOnClickListener {
                when (i) {
                    0 -> setScale(scale - STEP)
                    1 -> setScale(scale + STEP)
                    else -> setScale(100)
                }
                hideMenu()
            }
            menu.addView(tv, LinearLayout.LayoutParams(dp(190), WRAP))
        }
        addView(menu, FrameLayout.LayoutParams(dp(202), WRAP, Gravity.START or Gravity.TOP))
    }

    // ------------------------------------------------------------ toque

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked != MotionEvent.ACTION_DOWN) return true
        if (menuShown) {
            hideMenu()
            return true
        }
        val onPanel = inside(panel, ev.x, ev.y)
        val rightClick = (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
        if (rightClick) {
            showMenu(ev.x, ev.y)
        } else if (!onPanel) {
            hide()
        }
        return true
    }

    private fun inside(v: View, x: Float, y: Float): Boolean =
        x >= v.left && x < v.right && y >= v.top && y < v.bottom

    private fun showMenu(x: Float, y: Float) {
        menu.background = rounded(cPanel, 14)
        menu.translationX = min(x, width - dp(202).toFloat()).coerceAtLeast(0f)
        menu.translationY = min(y, height - dp(150).toFloat()).coerceAtLeast(0f)
        menu.visibility = VISIBLE
        menuShown = true
    }

    private fun hideMenu() {
        menu.visibility = GONE
        menuShown = false
    }

    private fun setScale(v: Int) {
        scale = v.coerceIn(MIN_SCALE, MAX_SCALE)
        sp.edit().putInt(KEY_SCALE, scale).apply()
        rebuild()
    }

    // ------------------------------------------------------------ conteúdo

    /** Monta os cartões das janelas abertas (chamado ao abrir e ao fechar uma janela pelo X). */
    fun rebuild() {
        panel.background = rounded(cPanel, 28)
        list.removeAllViews()
        val items = entries().filter { it.isOpen() }
        if (items.isEmpty()) {
            val tv = TextView(act)
            tv.text = "Nenhuma janela aberta"
            tv.setTextColor(cText)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(40), dp(30), dp(40), dp(30))
            list.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP))
            return
        }
        val s = scale / 100f
        val cardW = dp(240f * s)
        val cardH = dp(190f * s)
        val gap = dp(16)
        val maxW = resources.displayMetrics.widthPixels - dp(120)
        val cols = max(1, (maxW + gap) / (cardW + gap))
        var row: LinearLayout? = null
        for ((i, e) in items.withIndex()) {
            if (i % cols == 0) {
                val r = LinearLayout(act)
                r.orientation = LinearLayout.HORIZONTAL
                list.addView(r, LinearLayout.LayoutParams(WRAP, WRAP).apply { if (i > 0) topMargin = gap })
                row = r
            }
            val card = buildCard(e, cardW, cardH)
            row?.addView(card, LinearLayout.LayoutParams(cardW, cardH).apply { if (i % cols != 0) leftMargin = gap })
            card.alpha = 0f
            card.translationY = dp(18).toFloat()
            card.animate().alpha(1f).translationY(0f).setStartDelay(i * 30L).setDuration(220L).start()
        }
    }

    private fun buildCard(e: TaskEntry, w: Int, h: Int): View {
        val card = FrameLayout(act)
        card.background = rounded(cCard, 16)
        card.isClickable = true
        card.setOnClickListener {
            hide()
            e.raise()
        }

        val pad = dp(8)
        val footH = dp(40)
        val previewW = w - pad * 2
        val previewH = h - footH - pad * 2
        val preview = ImageView(act)
        preview.scaleType = ImageView.ScaleType.FIT_CENTER
        val bmp = snapshot(e.layer, previewW, previewH)
        if (bmp != null) {
            preview.setImageBitmap(bmp)
        } else {
            preview.setImageResource(e.icon)
            preview.setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        card.addView(preview, FrameLayout.LayoutParams(previewW, previewH).apply {
            leftMargin = pad
            topMargin = pad
        })

        val foot = LinearLayout(act)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.setPadding(pad * 2, 0, pad * 2, 0)
        val icon = ImageView(act)
        icon.setImageResource(e.icon)
        if (act.resources.getDrawable(e.icon, act.theme) is VectorDrawable) icon.setColorFilter(cText)
        foot.addView(icon, LinearLayout.LayoutParams(dp(18), dp(18)))
        val title = TextView(act)
        title.text = e.title
        title.setTextColor(cText)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        title.isSingleLine = true
        title.ellipsize = TextUtils.TruncateAt.END
        foot.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })
        card.addView(foot, FrameLayout.LayoutParams(w, footH, Gravity.BOTTOM))

        val x = ImageView(act)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(cText)
        x.setPadding(dp(6), dp(6), dp(6), dp(6))
        x.background = rounded(if (light) Color.argb(40, 0, 0, 0) else Color.argb(60, 255, 255, 255), 14)
        x.isClickable = true
        x.setOnClickListener {
            e.close()
            rebuild()
        }
        card.addView(x, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(12)
            rightMargin = dp(12)
        })
        return card
    }

    /** Desenha a janela no tamanho do cartão. Páginas web (WebView) não aparecem aqui: mostram o ícone. */
    private fun snapshot(layer: View, w: Int, h: Int): Bitmap? {
        val g = layer as? ViewGroup ?: return null
        var win: View? = null
        for (i in 0 until g.childCount) {
            val c = g.getChildAt(i)
            if (c.visibility == VISIBLE && c.width > 0 && c.height > 0) {
                win = c
                break
            }
        }
        val v = win ?: return null
        if (v is WebView) return null
        return try {
            val bmp = Bitmap.createBitmap(max(1, w), max(1, h), Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val s = min(w.toFloat() / v.width, h.toFloat() / v.height)
            c.scale(s, s)
            v.draw(c)
            bmp
        } catch (ex: Throwable) {
            null
        }
    }

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
        }

    // ------------------------------------------------------------ abrir / fechar

    fun toggle() {
        if (taskShown) hide() else show()
    }

    fun show() {
        if (taskShown || locked()) return
        taskShown = true
        rebuild()
        bringToFront()
        visibility = VISIBLE
        animate().cancel()
        alpha = 0f
        animate().alpha(1f).setDuration(180L).start()
        panel.scaleX = 0.94f
        panel.scaleY = 0.94f
        panel.animate().scaleX(1f).scaleY(1f).setDuration(220L).start()
    }

    fun hide() {
        if (!taskShown) return
        taskShown = false
        hideMenu()
        animate().cancel()
        animate().alpha(0f).setDuration(160L).withEndAction {
            if (!taskShown) visibility = GONE
            alpha = 1f
        }.start()
    }
}
