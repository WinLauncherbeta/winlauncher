package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Janela flutuante "Cidade da previsão" (vidro fosco), aberta ao clicar no cartão do clima da tela de bloqueio.
 *
 * - Vive DENTRO da tela de bloqueio ([parent]): uma camada transparente por cima de tudo que engole os toques,
 *   então a tela de bloqueio nunca é fechada nem recebe cliques enquanto a janela está aberta.
 * - Aparece ao lado do ícone (direita; esquerda se não couber; acima/abaixo como último recurso) e é sempre
 *   mantida dentro dos limites da tela (também quando o teclado redimensiona a tela).
 * - Fecha: clique fora, ESC/Voltar (via [dismiss], chamado pela MainActivity) e botão Fechar.
 * - Não guarda nada: modo e cidade ficam nas preferências, gravadas pela tela de bloqueio ([onPickAuto]/[onPickCity]).
 * - O desfoque é real: antes de abrir, o conteúdo da tela de bloqueio é capturado e borrado com o [Glass.makeBlur]
 *   existente, e desenhado atrás da janela. Se a captura falhar, a janela usa uma película mais opaca.
 */
class WeatherCityWindow(
    private val parent: FrameLayout,
    private val isAuto: () -> Boolean,
    private val chosenCity: () -> String?,
    private val hasLocationPermission: () -> Boolean,
    private val onPickAuto: () -> Unit,
    private val onPickCity: (CityResult) -> Unit
) {
    private val ctx = parent.context
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density + 0.5f).toInt()

    private val white = Color.WHITE
    private val subtle = Color.parseColor("#B3FFFFFF")
    private val accent = Color.parseColor("#60CDFF")

    private var layer: Layer? = null
    private var searchGen = 0

    private lateinit var selection: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var resultsScroll: ScrollView

    val isShowing: Boolean get() = layer != null

    // ------------------------------------------------------------------ abrir / fechar

    /** Abre a janela ao lado de [anchor] (o cartão do clima). Chamada repetida com a janela aberta não faz nada. */
    fun show(anchor: View) {
        if (layer != null || parent.width <= 0 || parent.height <= 0) return

        val blur = captureBlurredBackdrop() // antes de adicionar a janela: só o que fica atrás dela
        val card = buildCard(blur)
        val l = Layer(card)
        l.anchor.set(anchorRect(anchor))
        l.addView(card)
        layer = l
        parent.addView(l, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        renderSelection()
        card.alpha = 0f
        card.scaleX = 0.96f
        card.scaleY = 0.96f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        input.requestFocus() // teclado físico já digita direto; o teclado na tela só aparece ao tocar no campo
    }

    /** Fecha a janela. Retorna true se ela estava aberta (a MainActivity usa isso para o ESC não fechar também a tela de bloqueio). */
    fun dismiss(): Boolean {
        val l = layer ?: return false
        layer = null
        searchGen++ // descarta buscas em andamento
        try {
            val imm = ctx.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
        } catch (e: Exception) {
        }
        l.card.animate().cancel()
        parent.removeView(l)
        (l.card.background as? BackdropGlass)?.release()
        return true
    }

    /** Reavalia os indicadores (modo, cidade, permissão) — chamado quando o clima da tela de bloqueio é atualizado. */
    fun refresh() {
        if (layer != null) renderSelection()
    }

    // ------------------------------------------------------------------ camada e posicionamento

    /**
     * Camada transparente em tela cheia. Posiciona o cartão a cada layout, então a regra de
     * "ao lado do ícone, sem sair da tela" vale também quando o conteúdo cresce ou a tela é redimensionada.
     */
    private inner class Layer(val card: View) : FrameLayout(ctx) {
        val anchor = Rect()

        init {
            isClickable = true
            tag = CursorController.NOHAND // fora do cartão o cursor é a seta normal
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = View.MeasureSpec.getSize(widthMeasureSpec)
            val h = View.MeasureSpec.getSize(heightMeasureSpec)
            setMeasuredDimension(w, h)
            val m = dp(12)
            val cw = minOf(dp(360), w - 2 * m)
            card.measure(
                View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxOf(0, h - 2 * m), View.MeasureSpec.AT_MOST)
            )
        }

        override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
            val w = r - l
            val h = b - t
            val m = dp(12)
            val gap = dp(12)
            val cw = card.measuredWidth
            val ch = card.measuredHeight
            val a = anchor
            var x: Int
            var y: Int
            when {
                a.right + gap + cw <= w - m -> { x = a.right + gap; y = a.centerY() - ch / 2 } // à direita do ícone
                a.left - gap - cw >= m -> { x = a.left - gap - cw; y = a.centerY() - ch / 2 } // à esquerda
                else -> { // tela estreita: acima ou abaixo do ícone
                    x = a.left
                    y = when {
                        a.top - gap - ch >= m -> a.top - gap - ch
                        a.bottom + gap + ch <= h - m -> a.bottom + gap
                        else -> a.centerY() - ch / 2
                    }
                }
            }
            x = x.coerceIn(m, maxOf(m, w - cw - m))
            y = y.coerceIn(m, maxOf(m, h - ch - m))
            card.layout(x, y, x + cw, y + ch)
        }

        /** Só chega aqui o que o cartão não consumiu, ou seja, toque FORA da janela: fecha só a janela. */
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            // fecha no próximo ciclo: não remove a própria camada no meio do despacho do toque
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) post { if (layer === this) dismiss() }
            return true // engole: o clique não chega à tela de bloqueio (que sairia ao clicar em área vazia)
        }
    }

    /** Retângulo de [v] em coordenadas da tela de bloqueio (sem depender de zoom/animação do pai). */
    private fun anchorRect(v: View): Rect {
        var x = 0f
        var y = 0f
        var c: View = v
        while (c !== parent) {
            x += c.left + c.translationX
            y += c.top + c.translationY
            val p = c.parent as? View ?: break
            if (p !== parent) {
                x -= p.scrollX
                y -= p.scrollY
            }
            c = p
        }
        return Rect(x.toInt(), y.toInt(), (x + v.width).toInt(), (y + v.height).toInt())
    }

    // ------------------------------------------------------------------ fundo de vidro

    /** Captura a tela de bloqueio (1/4 da resolução) e borra com o desfoque já usado pelos outros painéis. */
    private fun captureBlurredBackdrop(): Bitmap? = try {
        val w = parent.width
        val h = parent.height
        val sw = maxOf(8, w / 4)
        val sh = maxOf(8, h / 4)
        val snap = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = Canvas(snap)
        c.scale(sw / w.toFloat(), sh / h.toFloat())
        parent.draw(c)
        val out = Glass.makeBlur(snap, w, h)
        snap.recycle()
        out
    } catch (t: Throwable) {
        null
    }

    /** Vidro fosco: fundo borrado (na posição certa atrás do cartão) + película + brilho no topo + borda fina. */
    private inner class BackdropGlass(
        private val view: View,
        private var blur: Bitmap?,
        private val radius: Float
    ) : Drawable() {
        private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            color = Color.parseColor("#4DFFFFFF")
        }
        private val clip = Path()
        private val rect = RectF()
        private val dst = Rect()

        init {
            // sem captura (falha rara) a película fica mais opaca para o texto continuar legível
            tintPaint.color = if (blur != null) Color.parseColor("#80101B2E") else Color.parseColor("#E6162338")
        }

        fun release() {
            blur = null
        }

        override fun onBoundsChange(b: Rect) {
            sheen.shader = LinearGradient(
                0f, 0f, 0f, b.height().toFloat(),
                Color.parseColor("#2EFFFFFF"), Color.parseColor("#05FFFFFF"), Shader.TileMode.CLAMP
            )
        }

        override fun draw(canvas: Canvas) {
            rect.set(bounds)
            clip.reset()
            clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
            val save = canvas.save()
            canvas.clipPath(clip)
            val bmp = blur
            if (bmp != null && !bmp.isRecycled) {
                // o instantâneo cobre a tela de bloqueio inteira; desloca para a posição atual do cartão
                val s2 = canvas.save()
                canvas.translate(-(view.left + view.translationX), -(view.top + view.translationY))
                dst.set(0, 0, parent.width, parent.height)
                canvas.drawBitmap(bmp, null, dst, bmpPaint)
                canvas.restoreToCount(s2)
            }
            canvas.drawPaint(tintPaint)
            canvas.drawPaint(sheen)
            canvas.restoreToCount(save)
            val inset = border.strokeWidth / 2f
            rect.inset(inset, inset)
            canvas.drawRoundRect(rect, radius - inset, radius - inset, border)
        }

        override fun getOutline(outline: Outline) {
            outline.setRoundRect(bounds, radius)
            outline.alpha = 0.6f
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}

        @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    // ------------------------------------------------------------------ conteúdo

    private fun text(size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(ctx).apply {
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    /** Fundo de item: transparente, com realce ao passar o mouse e ao pressionar. */
    private fun hoverBg(radiusDp: Int, base: Int = Color.TRANSPARENT, stroke: Int = 0): Drawable {
        fun shape(c: Int) = GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(c)
            if (stroke != 0) setStroke(dp(1), stroke)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(Color.parseColor("#33FFFFFF")))
            addState(intArrayOf(android.R.attr.state_hovered), shape(Color.parseColor("#26FFFFFF")))
            addState(intArrayOf(), shape(base))
        }
    }

    private fun buildCard(blur: Bitmap?): View {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(16), dp(16), dp(14))
        card.isClickable = true // engole cliques dentro da janela: nada fecha e nada vaza para trás
        card.tag = CursorController.NOHAND
        card.elevation = dp(16).toFloat()
        val radius = dp(20).toFloat()
        card.background = BackdropGlass(card, blur, radius)
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
                outline.alpha = 0.6f
            }
        }
        card.clipToOutline = true

        val title = text(18f, bold = true)
        title.text = "Cidade da previsão"
        card.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        // opção automática + cidade escolhida (com indicador de seleção)
        selection = LinearLayout(ctx)
        selection.orientation = LinearLayout.VERTICAL
        card.addView(selection, LinearLayout.LayoutParams(-1, -2))

        // campo de busca
        val field = LinearLayout(ctx)
        field.orientation = LinearLayout.HORIZONTAL
        field.gravity = Gravity.CENTER_VERTICAL
        field.setPadding(dp(12), 0, dp(6), 0)
        field.background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#1FFFFFFF"))
            setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        }
        input = EditText(ctx)
        input.background = null
        input.hint = "Buscar cidade"
        input.setHintTextColor(Color.parseColor("#99FFFFFF"))
        input.setTextColor(white)
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        input.setSingleLine()
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.setPadding(0, dp(10), dp(8), dp(10))
        field.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        val go = ImageView(ctx)
        go.setImageResource(R.drawable.ic_search)
        go.setColorFilter(Color.parseColor("#E6FFFFFF"))
        go.setPadding(dp(8), dp(8), dp(8), dp(8))
        go.isClickable = true
        go.background = hoverBg(10)
        go.setOnClickListener { search() }
        field.addView(go, LinearLayout.LayoutParams(dp(36), dp(36)))
        card.addView(field, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        input.setOnEditorActionListener { _, actionId, ev ->
            val enter = ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                search()
                true
            } else false
        }

        status = text(12.5f, subtle)
        status.visibility = View.GONE
        card.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        results = LinearLayout(ctx)
        results.orientation = LinearLayout.VERTICAL
        resultsScroll = ScrollView(ctx)
        resultsScroll.isVerticalScrollBarEnabled = false
        resultsScroll.overScrollMode = View.OVER_SCROLL_NEVER
        resultsScroll.visibility = View.GONE
        resultsScroll.addView(results, FrameLayout.LayoutParams(-1, -2))
        card.addView(resultsScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        // rodapé: botão Fechar
        val close = text(14f, bold = true)
        close.text = "Fechar"
        close.gravity = Gravity.CENTER
        close.setPadding(dp(22), dp(9), dp(22), dp(9))
        close.isClickable = true
        close.background = hoverBg(18, base = Color.parseColor("#1FFFFFFF"), stroke = Color.parseColor("#33FFFFFF"))
        close.setOnClickListener { dismiss() }
        card.addView(close, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.END
            topMargin = dp(14)
        })
        return card
    }

    /** Linha de opção com ícone, título, subtítulo e indicador "✓" quando selecionada. */
    private fun optionRow(icon: String, title: String, sub: String, selected: Boolean, click: (() -> Unit)?): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.background = if (selected)
            hoverBg(12, base = Color.parseColor("#2EFFFFFF"), stroke = Color.parseColor("#9960CDFF"))
        else hoverBg(12, base = Color.parseColor("#14FFFFFF"))

        val ic = TextView(ctx)
        ic.text = icon
        ic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        ic.gravity = Gravity.CENTER
        row.addView(ic, LinearLayout.LayoutParams(dp(30), -2))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val t = text(14.5f, bold = true)
        t.text = title
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val s = text(12f, subtle)
        s.text = sub
        s.maxLines = 3
        col.addView(t)
        col.addView(s, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })

        if (selected) {
            val badge = TextView(ctx)
            badge.text = "✓"
            badge.setTextColor(Color.parseColor("#0B1E3F"))
            badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            badge.typeface = Typeface.DEFAULT_BOLD
            badge.gravity = Gravity.CENTER
            badge.includeFontPadding = false
            badge.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accent)
            }
            row.addView(badge, LinearLayout.LayoutParams(dp(22), dp(22)).apply { leftMargin = dp(8) })
        }
        if (click != null) {
            row.isClickable = true
            row.setOnClickListener { click() }
        }
        return row
    }

    private fun renderSelection() {
        if (!::selection.isInitialized) return
        selection.removeAllViews()
        val auto = isAuto()
        val sub = when {
            !auto -> "Usar a posição atual do aparelho"
            hasLocationPermission() -> "Usando a localização atual do aparelho"
            else -> "Sem permissão de localização: usando a localização aproximada pela rede"
        }
        selection.addView(
            optionRow("📍", "Usar localização automática", sub, auto) { onPickAuto(); renderSelection() },
            LinearLayout.LayoutParams(-1, -2)
        )
        val city = chosenCity()
        if (!auto && !city.isNullOrEmpty()) {
            selection.addView(
                optionRow("🏙️", city, "Cidade escolhida manualmente", true, null),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            )
        }
    }

    // ------------------------------------------------------------------ busca

    private fun setStatus(msg: String?) {
        status.text = msg ?: ""
        status.visibility = if (msg.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    private fun search() {
        val q = input.text.toString().trim()
        if (q.length < 2) {
            results.removeAllViews()
            resultsScroll.visibility = View.GONE
            setStatus("Digite pelo menos 2 letras.")
            return
        }
        val gen = ++searchGen
        setStatus("Buscando…")
        results.removeAllViews()
        resultsScroll.visibility = View.GONE
        Thread {
            val found = try { Weather.searchCities(q) } catch (e: Exception) { null }
            parent.post {
                if (gen != searchGen || layer == null) return@post // fechada ou substituída por outra busca
                results.removeAllViews()
                when {
                    found == null -> setStatus("Sem conexão. Não foi possível buscar.")
                    found.isEmpty() -> setStatus("Nenhuma cidade encontrada.")
                    else -> {
                        setStatus(null)
                        for (r in found) results.addView(resultRow(r), LinearLayout.LayoutParams(-1, -2))
                        resultsScroll.visibility = View.VISIBLE
                    }
                }
            }
        }.start()
    }

    private fun resultRow(r: CityResult): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(dp(12), dp(9), dp(12), dp(9))
        row.background = hoverBg(10)
        row.isClickable = true
        val n = text(15f)
        n.text = r.name
        n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        row.addView(n)
        if (r.detail.isNotEmpty()) {
            val d = text(12f, subtle)
            d.text = r.detail
            d.maxLines = 1
            d.ellipsize = TextUtils.TruncateAt.END
            row.addView(d, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(1) })
        }
        row.setOnClickListener {
            searchGen++ // ignora qualquer busca ainda em andamento
            onPickCity(r)
            results.removeAllViews()
            resultsScroll.visibility = View.GONE
            input.setText("")
            setStatus("Previsão definida para ${r.name}.")
            renderSelection()
        }
        return row
    }
}
