package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Janela flutuante "Cidade da previsão" (vidro fosco), aberta ao clicar no cartão do clima da tela de bloqueio.
 *
 * - Vive DENTRO da tela de bloqueio ([parent]): uma camada transparente por cima de tudo que engole os toques,
 *   então a tela de bloqueio nunca é fechada nem recebe cliques enquanto a janela está aberta.
 * - Aparece ao lado do ícone (direita; esquerda se não couber; acima/abaixo como último recurso) e é sempre
 *   mantida dentro dos limites da tela (também quando o teclado redimensiona a tela).
 * - Fecha: clique fora, ESC/Voltar (via [dismiss], chamado pela MainActivity) e botão Fechar.
 * - Não guarda nada: modo e cidade ficam nas preferências, gravadas pela tela de bloqueio ([onPickAuto]/[onPickCity]).
 * - O desfoque é real: antes de abrir, o conteúdo da tela de bloqueio é capturado e borrado com o [Glass.makeBlur]
 *   existente, e desenhado atrás da janela. Se a captura falhar, a janela usa uma película mais opaca.
 */
class WeatherCityWindow(
    private val parent: FrameLayout,
    private val isAuto: () -> Boolean,
    private val chosenCity: () -> String?,
    private val hasLocationPermission: () -> Boolean,
    private val onPickAuto: () -> Unit,
    private val onPickCity: (CityResult) -> Unit,
    /** "Mover previsão": a tela de bloqueio fecha esta janela e abre o painel de personalização já no modo mover. */
    private val onMoveWeather: () -> Unit,
    /** "Personalizar tela": abre o painel completo. */
    private val onMoreOptions: () -> Unit
) {
    private val ctx = parent.context
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density + 0.5f).toInt()

    private val white = Color.WHITE
    private val subtle = Color.parseColor("#B3FFFFFF")
    private val accent = Color.parseColor("#60CDFF")

    private var layer: Layer? = null
    private var searchGen = 0

    private lateinit var selection: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var resultsScroll: ScrollView

    val isShowing: Boolean get() = layer != null

    // ------------------------------------------------------------------ abrir / fechar

    /** Abre a janela ao lado de [anchor] (o cartão do clima). Chamada repetida com a janela aberta não faz nada. */
    fun show(anchor: View) {
        if (layer != null || parent.width <= 0 || parent.height <= 0) return

        val blur = captureBlurredBackdrop(parent) // antes de adicionar a janela: só o que fica atrás dela
        val card = buildCard(blur)
        val l = Layer(card)
        l.anchor.set(anchorRect(anchor))
        l.addView(card)
        layer = l
        parent.addView(l, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        renderSelection()
        card.alpha = 0f
        card.scaleX = 0.96f
        card.scaleY = 0.96f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        input.requestFocus() // teclado físico já digita direto; o teclado na tela só aparece ao tocar no campo
    }

    /** Fecha a janela. Retorna true se ela estava aberta (a MainActivity usa isso para o ESC não fechar também a tela de bloqueio). */
    fun dismiss(): Boolean {
        val l = layer ?: return false
        layer = null
        searchGen++ // descarta buscas em andamento
        try {
            val imm = ctx.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
        } catch (e: Exception) {
        }
        l.card.animate().cancel()
        parent.removeView(l)
        (l.card.background as? BackdropGlass)?.release()
        return true
    }

    /** Reavalia os indicadores (modo, cidade, permissão) — chamado quando o clima da tela de bloqueio é atualizado. */
    fun refresh() {
        if (layer != null) renderSelection()
    }

    // ------------------------------------------------------------------ camada e posicionamento

    /**
     * Camada transparente em tela cheia. Posiciona o cartão a cada layout, então a regra de
     * "ao lado do ícone, sem sair da tela" vale também quando o conteúdo cresce ou a tela é redimensionada.
     */
    private inner class Layer(val card: View) : FrameLayout(ctx) {
        val anchor = Rect()

        init {
            isClickable = true
            tag = CursorController.NOHAND // fora do cartão o cursor é a seta normal
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = View.MeasureSpec.getSize(widthMeasureSpec)
            val h = View.MeasureSpec.getSize(heightMeasureSpec)
            setMeasuredDimension(w, h)
            val m = dp(12)
            val cw = minOf(dp(360), w - 2 * m)
            card.measure(
                View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxOf(0, h - 2 * m), View.MeasureSpec.AT_MOST)
            )
        }

        override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
            val w = r - l
            val h = b - t
            val m = dp(12)
            val gap = dp(12)
            val cw = card.measuredWidth
            val ch = card.measuredHeight
            val a = anchor
            var x: Int
            var y: Int
            when {
                a.right + gap + cw <= w - m -> { x = a.right + gap; y = a.centerY() - ch / 2 } // à direita do ícone
                a.left - gap - cw >= m -> { x = a.left - gap - cw; y = a.centerY() - ch / 2 } // à esquerda
                else -> { // tela estreita: acima ou abaixo do ícone
                    x = a.left
                    y = when {
                        a.top - gap - ch >= m -> a.top - gap - ch
                        a.bottom + gap + ch <= h - m -> a.bottom + gap
                        else -> a.centerY() - ch / 2
                    }
                }
            }
            x = x.coerceIn(m, maxOf(m, w - cw - m))
            y = y.coerceIn(m, maxOf(m, h - ch - m))
            card.layout(x, y, x + cw, y + ch)
        }

        /** Só chega aqui o que o cartão não consumiu, ou seja, toque FORA da janela: fecha só a janela. */
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            // fecha no próximo ciclo: não remove a própria camada no meio do despacho do toque
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) post { if (layer === this) dismiss() }
            return true // engole: o clique não chega à tela de bloqueio (que sairia ao clicar em área vazia)
        }
    }

    /** Retângulo de [v] em coordenadas da tela de bloqueio (sem depender de zoom/animação do pai). */
    private fun anchorRect(v: View): Rect {
        var x = 0f
        var y = 0f
        var c: View = v
        while (c !== parent) {
            x += c.left + c.translationX
            y += c.top + c.translationY
            val p = c.parent as? View ?: break
            if (p !== parent) {
                x -= p.scrollX
                y -= p.scrollY
            }
            c = p
        }
        return Rect(x.toInt(), y.toInt(), (x + v.width).toInt(), (y + v.height).toInt())
    }

    // ------------------------------------------------------------------ conteúdo

    private fun text(size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(ctx).apply {
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun hoverBg(radiusDp: Int, base: Int = Color.TRANSPARENT, stroke: Int = 0): Drawable =
        glassItemBg(density, radiusDp, base, stroke)

    private fun buildCard(blur: Bitmap?): View {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(16), dp(16), dp(14))
        card.isClickable = true // engole cliques dentro da janela: nada fecha e nada vaza para trás
        card.tag = CursorController.NOHAND
        card.elevation = dp(16).toFloat()
        val radius = dp(20).toFloat()
        card.background = BackdropGlass(card, parent, blur, radius, density)
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
                outline.alpha = 0.6f
            }
        }
        card.clipToOutline = true

        val title = text(18f, bold = true)
        title.text = "Cidade da previsão"
        card.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        // opção automática + cidade escolhida (com indicador de seleção)
        selection = LinearLayout(ctx)
        selection.orientation = LinearLayout.VERTICAL
        card.addView(selection, LinearLayout.LayoutParams(-1, -2))

        // campo de busca
        val field = LinearLayout(ctx)
        field.orientation = LinearLayout.HORIZONTAL
        field.gravity = Gravity.CENTER_VERTICAL
        field.setPadding(dp(12), 0, dp(6), 0)
        field.background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#1FFFFFFF"))
            setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        }
        input = EditText(ctx)
        input.background = null
        input.hint = "Buscar cidade"
        input.setHintTextColor(Color.parseColor("#99FFFFFF"))
        input.setTextColor(white)
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        input.setSingleLine()
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.setPadding(0, dp(10), dp(8), dp(10))
        field.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        val go = ImageView(ctx)
        go.setImageResource(R.drawable.ic_search)
        go.setColorFilter(Color.parseColor("#E6FFFFFF"))
        go.setPadding(dp(8), dp(8), dp(8), dp(8))
        go.isClickable = true
        go.background = hoverBg(10)
        go.setOnClickListener { search() }
        field.addView(go, LinearLayout.LayoutParams(dp(36), dp(36)))
        card.addView(field, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        input.setOnEditorActionListener { _, actionId, ev ->
            val enter = ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                search()
                true
            } else false
        }

        status = text(12.5f, subtle)
        status.visibility = View.GONE
        card.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        results = LinearLayout(ctx)
        results.orientation = LinearLayout.VERTICAL
        resultsScroll = ScrollView(ctx)
        resultsScroll.isVerticalScrollBarEnabled = false
        resultsScroll.overScrollMode = View.OVER_SCROLL_NEVER
        resultsScroll.visibility = View.GONE
        resultsScroll.addView(results, FrameLayout.LayoutParams(-1, -2))
        card.addView(resultsScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        // rodapé: Mover previsão / Personalizar tela / Fechar
        fun pill(label: String, strong: Boolean, click: () -> Unit): TextView {
            val t = text(13f, bold = true)
            t.text = label
            t.gravity = Gravity.CENTER
            t.setPadding(dp(14), dp(9), dp(14), dp(9))
            t.isClickable = true
            t.background = hoverBg(
                18,
                base = Color.parseColor(if (strong) "#33FFFFFF" else "#1FFFFFFF"),
                stroke = Color.parseColor("#33FFFFFF")
            )
            t.setOnClickListener { click() }
            return t
        }
        val actions = LinearLayout(ctx)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(pill("Mover previsão", false) { onMoveWeather() }, LinearLayout.LayoutParams(-2, -2))
        actions.addView(pill("Personalizar tela", false) { onMoreOptions() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        card.addView(actions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })

        val close = pill("Fechar", true) { dismiss() }
        card.addView(close, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        return card
    }

    /** Linha de opção com ícone, título, subtítulo e indicador "✓" quando selecionada. */
    private fun optionRow(icon: String, title: String, sub: String, selected: Boolean, click: (() -> Unit)?): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.background = if (selected)
            hoverBg(12, base = Color.parseColor("#2EFFFFFF"), stroke = Color.parseColor("#9960CDFF"))
        else hoverBg(12, base = Color.parseColor("#14FFFFFF"))

        val ic = TextView(ctx)
        ic.text = icon
        ic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        ic.gravity = Gravity.CENTER
        row.addView(ic, LinearLayout.LayoutParams(dp(30), -2))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val t = text(14.5f, bold = true)
        t.text = title
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val s = text(12f, subtle)
        s.text = sub
        s.maxLines = 3
        col.addView(t)
        col.addView(s, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })

        if (selected) {
            val badge = TextView(ctx)
            badge.text = "✓"
            badge.setTextColor(Color.parseColor("#0B1E3F"))
            badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            badge.typeface = Typeface.DEFAULT_BOLD
            badge.gravity = Gravity.CENTER
            badge.includeFontPadding = false
            badge.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accent)
            }
            row.addView(badge, LinearLayout.LayoutParams(dp(22), dp(22)).apply { leftMargin = dp(8) })
        }
        if (click != null) {
            row.isClickable = true
            row.setOnClickListener { click() }
        }
        return row
    }

    private fun renderSelection() {
        if (!::selection.isInitialized) return
        selection.removeAllViews()
        val auto = isAuto()
        val sub = when {
            !auto -> "Usar a posição atual do aparelho"
            hasLocationPermission() -> "Usando a localização atual do aparelho"
            else -> "Sem permissão de localização: usando a localização aproximada pela rede"
        }
        selection.addView(
            optionRow("📍", "Usar localização automática", sub, auto) { onPickAuto(); renderSelection() },
            LinearLayout.LayoutParams(-1, -2)
        )
        val city = chosenCity()
        if (!auto && !city.isNullOrEmpty()) {
            selection.addView(
                optionRow("🏙️", city, "Cidade escolhida manualmente", true, null),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            )
        }
    }

    // ------------------------------------------------------------------ busca

    private fun setStatus(msg: String?) {
        status.text = msg ?: ""
        status.visibility = if (msg.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    private fun search() {
        val q = input.text.toString().trim()
        if (q.length < 2) {
            results.removeAllViews()
            resultsScroll.visibility = View.GONE
            setStatus("Digite pelo menos 2 letras.")
            return
        }
        val gen = ++searchGen
        setStatus("Buscando…")
        results.removeAllViews()
        resultsScroll.visibility = View.GONE
        Thread {
            val found = try { Weather.searchCities(q) } catch (e: Exception) { null }
            parent.post {
                if (gen != searchGen || layer == null) return@post // fechada ou substituída por outra busca
                results.removeAllViews()
                when {
                    found == null -> setStatus("Sem conexão. Não foi possível buscar.")
                    found.isEmpty() -> setStatus("Nenhuma cidade encontrada.")
                    else -> {
                        setStatus(null)
                        for (r in found) results.addView(resultRow(r), LinearLayout.LayoutParams(-1, -2))
                        resultsScroll.visibility = View.VISIBLE
                    }
                }
            }
        }.start()
    }

    private fun resultRow(r: CityResult): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(dp(12), dp(9), dp(12), dp(9))
        row.background = hoverBg(10)
        row.isClickable = true
        val n = text(15f)
        n.text = r.name
        n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        row.addView(n)
        if (r.detail.isNotEmpty()) {
            val d = text(12f, subtle)
            d.text = r.detail
            d.maxLines = 1
            d.ellipsize = TextUtils.TruncateAt.END
            row.addView(d, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(1) })
        }
        row.setOnClickListener {
            searchGen++ // ignora qualquer busca ainda em andamento
            onPickCity(r)
            results.removeAllViews()
            resultsScroll.visibility = View.GONE
            input.setText("")
            setStatus("Previsão definida para ${r.name}.")
            renderSelection()
        }
        return row
    }
}
