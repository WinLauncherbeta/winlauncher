package com.example.winlauncher

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Mapeador de gamepad (Etapa 2) - editor SOBRE o jogo.
 *
 * Abre duas janelas de acessibilidade (TYPE_ACCESSIBILITY_OVERLAY, não pedem permissão extra) por cima do app que
 * estiver na frente:
 *  - a TELA: ocupa tudo, escurece um pouco o jogo e mostra um ponto por botão. Tocar num ponto o seleciona,
 *    arrastar o move, tocar em área vazia põe/move o ponto do botão selecionado;
 *  - a BARRA: janelinha com os botões do controle, modo (toque rápido / segurar), ajuste fino, teste e salvar.
 *
 * Modo TESTAR: a tela deixa de receber toques (o jogo recebe tudo) e o mapeamento volta a valer de verdade:
 * apertar um botão do controle injeta o toque no jogo e acende o ponto correspondente.
 *
 * As mudanças são feitas direto no [PadProfile] (assim o teste usa o que você acabou de arrastar) e só ficam no
 * disco em "Salvar e sair". "Descartar" devolve o perfil ao estado em que estava quando o editor abriu.
 * Só thread principal.
 */
class PadOverlayEditor(
    private val svc: PadMapperService,
    private val prof: PadProfile,
    private val onClosed: () -> Unit
) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    // estado de abertura (para "Descartar")
    private val snapshot: List<PadBinding> = prof.bindings.map { it.copy() }
    private val snapshotLandscape = prof.landscape

    private var selected: PadButton = PadButton.A
    private var testing = false
    private var collapsed = false
    private var barAtTop = true
    private var closed = false
    private var discardArmedAt = 0L

    private var canvas: EditorCanvas? = null
    private var bar: LinearLayout? = null
    private var body: LinearLayout? = null
    private var scroll: HorizontalScrollView? = null

    private var title: TextView? = null
    private var hint: TextView? = null
    private var testChip: TextView? = null
    private val modeChips = LinkedHashMap<BindMode, TextView>()
    private var orientChip: TextView? = null
    private var discardChip: TextView? = null
    private val btnChips = LinkedHashMap<PadButton, TextView>()

    // Etapa 3: ajustes do modo (raio, velocidade, zona morta, cadência, tempos da macro)
    private var paramRow: LinearLayout? = null
    private var macroRow: LinearLayout? = null
    private var stepLabel: TextView? = null
    private var paramKey = ""
    private val paramViews = ArrayList<Pair<TuneParam, TextView>>()

    /** Macro: passo escolhido (o que as setas e os ajustes de tempo mexem). */
    private var selectedStep = 0

    private val engineListener: () -> Unit = {
        canvas?.invalidate()
        refreshHint()
        refreshChips()
    }

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    // ------------------------------------------------------------ abrir / fechar

    /** Mostra o editor. Devolve false se o Android recusou as janelas (nada fica aberto). */
    fun show(): Boolean {
        return try {
            val cv = EditorCanvas(svc)
            canvas = cv
            wm.addView(cv, canvasParams(true))
            val b = buildBar()
            bar = b
            wm.addView(b, barParams())
            PadEngine.editHook = { btn ->
                selected = btn
                selectedStep = 0
                refreshChips()
                refreshHint()
                canvas?.invalidate()
                scrollToSelected()
            }
            PadEngine.addListener(engineListener)
            PadEngine.setEditing(true)
            refreshChips()
            refreshHint()
            true
        } catch (e: Exception) {
            cleanup()
            false
        }
    }

    fun close() {
        if (closed) return
        closed = true
        cleanup()
        onClosed()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        PadEngine.removeListener(engineListener)
        PadEngine.editHook = null
        PadEngine.setEditing(false)
        // saiu no meio de um teste: solta qualquer dedo que ainda esteja na tela
        PadEngine.releaseAll()
        bar?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        canvas?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bar = null
        canvas = null
    }

    fun saveAndExit() {
        PadStore.save(svc)
        PadEngine.notifyProfileEdited()
        close()
    }

    private fun discardAndExit() {
        prof.bindings.clear()
        for (b in snapshot) prof.bindings.add(b.copy())
        prof.landscape = snapshotLandscape
        PadEngine.notifyProfileEdited()
        close()
    }

    // ------------------------------------------------------------ janelas

    private fun canvasParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.title = "WinLauncher gamepad - pontos"
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun barParams(): WindowManager.LayoutParams {
        val w = Math.min((svc.screenWidth() * 0.94f).toInt(), dp(560))
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val lp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (barAtTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.y = dp(if (barAtTop) 28 else 16)
        lp.title = "WinLauncher gamepad - barra"
        return lp
    }

    private fun relayoutBar() {
        val b = bar ?: return
        try {
            wm.updateViewLayout(b, barParams())
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ barra

    private fun box(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = box(if (on) "#19B4F0" else "#33FFFFFF", 6)
        c.setTextColor(Color.WHITE)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val c = TextView(svc)
        c.text = text
        c.textSize = 11.5f
        c.gravity = Gravity.CENTER
        c.setSingleLine(true)
        c.setPadding(dp(8), dp(6), dp(8), dp(6))
        c.isClickable = true
        c.setOnClickListener { onClick() }
        styleChip(c, false)
        return c
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(svc)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun addWeighted(parent: LinearLayout, v: View, weight: Float = 1f) {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        parent.addView(v, lp)
    }

    private fun buildBar(): LinearLayout {
        val col = LinearLayout(svc)
        col.orientation = LinearLayout.VERTICAL
        col.background = box("#EE0E1522", 12)
        col.setPadding(dp(8), dp(6), dp(8), dp(6))

        // ---- linha 1: título + testar / barra em cima-embaixo / recolher
        val r1 = row()
        val t = TextView(svc)
        t.text = "Editando: " + prof.name
        t.textSize = 12.5f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Color.WHITE)
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        title = t
        addWeighted(r1, t, 1f)
        val tc = chip("Testar") { toggleTest() }
        testChip = tc
        r1.addView(tc)
        val pc = chip("⇅") {
            barAtTop = !barAtTop
            relayoutBar()
        }
        r1.addView(pc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = dp(4) })
        val cc = chip("▾") { }
        cc.setOnClickListener {
            collapsed = !collapsed
            body?.visibility = if (collapsed) View.GONE else View.VISIBLE
            cc.text = if (collapsed) "▸" else "▾"
        }
        r1.addView(cc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = dp(4) })
        col.addView(r1)

        val bd = LinearLayout(svc)
        bd.orientation = LinearLayout.VERTICAL
        body = bd
        col.addView(bd)

        // ---- linha 2: botões do controle (rolagem horizontal)
        val sv = HorizontalScrollView(svc)
        sv.isHorizontalScrollBarEnabled = false
        scroll = sv
        val chipsRow = row()
        for (b in PadButton.values()) {
            val ch = chip(b.label) {
                selected = b
                selectedStep = 0
                refreshChips()
                refreshHint()
                canvas?.invalidate()
            }
            btnChips[b] = ch
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(2), dp(4), dp(2), dp(2))
            chipsRow.addView(ch, lp)
        }
        sv.addView(chipsRow)
        bd.addView(sv)

        // ---- linha 3: dica
        val h = TextView(svc)
        h.textSize = 11f
        h.setTextColor(Color.parseColor("#C6D0E0"))
        h.setPadding(dp(2), dp(2), dp(2), dp(2))
        hint = h
        bd.addView(h)

        // ---- linha 4: modo do botão selecionado
        val r4 = row()
        val rem = chip("Remover ponto") {
            prof.remove(selected)
            refreshChips()
            refreshHint()
            canvas?.invalidate()
        }
        for (m in listOf(BindMode.TAP, BindMode.HOLD, BindMode.TURBO, BindMode.JOYSTICK, BindMode.CAMERA, BindMode.SLIDE, BindMode.MACRO)) {
            val mc = chip(m.label) { setMode(m) }
            modeChips[m] = mc
            addWeighted(r4, mc)
        }
        addWeighted(r4, rem)
        bd.addView(r4)

        // ---- linha 4b: ajustes do modo (muda conforme o botão e o modo)
        val rp = row()
        rp.visibility = View.GONE
        paramRow = rp
        bd.addView(rp)

        // ---- linha 4c: passos da macro
        val rm = row()
        rm.visibility = View.GONE
        macroRow = rm
        val prev = chip("‹") { moveStepSel(-1) }
        val lbl = TextView(svc)
        lbl.textSize = 11.5f
        lbl.gravity = Gravity.CENTER
        lbl.setTextColor(Color.WHITE)
        stepLabel = lbl
        val next = chip("›") { moveStepSel(1) }
        val delStep = chip("Apagar passo") { deleteStep() }
        addWeighted(rm, prev, 0.5f)
        addWeighted(rm, lbl, 1.4f)
        addWeighted(rm, next, 0.5f)
        addWeighted(rm, delStep, 1.2f)
        bd.addView(rm)

        // ---- linha 5: ajuste fino + orientação do perfil
        val r5 = row()
        addWeighted(r5, nudgeChip("◀", -1, 0), 0.7f)
        addWeighted(r5, nudgeChip("▶", 1, 0), 0.7f)
        addWeighted(r5, nudgeChip("▲", 0, -1), 0.7f)
        addWeighted(r5, nudgeChip("▼", 0, 1), 0.7f)
        val oc = chip("") {
            prof.landscape = currentLandscape()
            refreshHint()
            refreshChips()
        }
        orientChip = oc
        addWeighted(r5, oc, 2.6f)
        bd.addView(r5)

        // ---- linha 6: ações
        val r6 = row()
        val save = chip("Salvar e sair") { saveAndExit() }
        styleChip(save, true)
        val dis = chip("Descartar") { }
        dis.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - discardArmedAt < 3000L) {
                discardAndExit()
            } else {
                discardArmedAt = now
                dis.text = "Toque de novo"
                handler.postDelayed({ dis.text = "Descartar" }, 3000L)
            }
        }
        discardChip = dis
        val open = chip("Abrir jogo") { openGame() }
        addWeighted(r6, save, 1.3f)
        addWeighted(r6, dis, 1f)
        addWeighted(r6, open, 1f)
        bd.addView(r6)

        return col
    }

    /** Chip que repete a ação enquanto o dedo estiver nele (ajuste fino e −/+ dos ajustes). */
    private fun holdChip(text: String, firstDelay: Long = 380L, every: Long = 70L, action: () -> Unit): TextView {
        val c = chip(text) { }
        var rep: Runnable? = null
        c.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    action()
                    val r = object : Runnable {
                        override fun run() {
                            action()
                            handler.postDelayed(this, every)
                        }
                    }
                    rep = r
                    handler.postDelayed(r, firstDelay)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    rep?.let { handler.removeCallbacks(it) }
                    rep = null
                }
            }
            true
        }
        return c
    }

    /** Setinha de ajuste fino: um toque move 0,25% da tela; segurar repete. */
    private fun nudgeChip(text: String, dx: Int, dy: Int): TextView = holdChip(text) { nudge(dx, dy) }

    private fun nudge(dx: Int, dy: Int) {
        val cur = prof.bindingFor(selected) ?: return
        if (cur.mode == BindMode.OFF) return
        val step = 0.0025f
        if (cur.mode == BindMode.MACRO && cur.steps.isNotEmpty()) {
            // macro: a seta move o passo escolhido
            val st = cur.steps[Math.min(selectedStep, cur.steps.size - 1)]
            cur.moveStep(Math.min(selectedStep, cur.steps.size - 1), st.x + dx * step, st.y + dy * step)
        } else {
            cur.x = PadProfile.clamp01(cur.x + dx * step)
            cur.y = PadProfile.clamp01(cur.y + dy * step)
        }
        canvas?.invalidate()
        refreshHint()
    }

    // ---- ajustes do modo

    /** Refaz a linha de ajustes quando muda o botão, o modo ou o passo; senão só atualiza os valores. */
    private fun refreshParams() {
        val rp = paramRow ?: return
        val rm = macroRow ?: return
        val b = prof.bindingFor(selected)
        if (b == null || b.mode == BindMode.OFF) {
            paramKey = ""
            rp.visibility = View.GONE
            rm.visibility = View.GONE
            return
        }
        if (b.mode == BindMode.MACRO) {
            b.ensureMacro()
            selectedStep = Math.max(0, Math.min(selectedStep, b.steps.size - 1))
        }
        val key = selected.name + "/" + b.mode.name + "/" + (if (b.mode == BindMode.MACRO) selectedStep.toString() else "")
        if (key != paramKey) {
            paramKey = key
            rp.removeAllViews()
            paramViews.clear()
            for (p in PadTuning.paramsFor(b, selectedStep)) addParam(rp, p)
        }
        rp.visibility = if (paramViews.isEmpty()) View.GONE else View.VISIBLE
        for ((p, tv) in paramViews) tv.text = if (p.cycle) p.label + ": " + p.text(b) else p.text(b)
        if (b.mode == BindMode.MACRO) {
            rm.visibility = View.VISIBLE
            stepLabel?.text = "Passo " + (selectedStep + 1) + " de " + b.steps.size
        } else {
            rm.visibility = View.GONE
        }
    }

    private fun addParam(parent: LinearLayout, p: TuneParam) {
        if (p.cycle) {
            val ch = chip("") { changeParam(p, 1) }
            paramViews.add(Pair(p, ch))
            addWeighted(parent, ch, 1f)
            return
        }
        val cell = row()
        val lab = TextView(svc)
        lab.text = p.label
        lab.textSize = 10.5f
        lab.setTextColor(Color.parseColor("#C6D0E0"))
        lab.setSingleLine(true)
        cell.addView(lab)
        val minus = holdChip("−", 350L, 60L) { changeParam(p, -1) }
        val value = TextView(svc)
        value.textSize = 11.5f
        value.typeface = Typeface.DEFAULT_BOLD
        value.setTextColor(Color.WHITE)
        value.gravity = Gravity.CENTER
        value.setSingleLine(true)
        val plus = holdChip("+", 350L, 60L) { changeParam(p, 1) }
        val lm = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lm.leftMargin = dp(4)
        cell.addView(minus, lm)
        cell.addView(value, LinearLayout.LayoutParams(dp(50), ViewGroup.LayoutParams.WRAP_CONTENT))
        cell.addView(plus)
        paramViews.add(Pair(p, value))
        addWeighted(parent, cell, 1f)
    }

    private fun changeParam(p: TuneParam, delta: Int) {
        val b = prof.bindingFor(selected) ?: return
        p.change(b, delta)
        for ((q, tv) in paramViews) {
            if (q === p) tv.text = if (q.cycle) q.label + ": " + q.text(b) else q.text(b)
        }
        refreshParamTexts(b)
        canvas?.invalidate()
        refreshHint()
    }

    private fun refreshParamTexts(b: PadBinding) {
        for ((q, tv) in paramViews) tv.text = if (q.cycle) q.label + ": " + q.text(b) else q.text(b)
    }

    private fun moveStepSel(delta: Int) {
        val b = prof.bindingFor(selected) ?: return
        if (b.mode != BindMode.MACRO || b.steps.isEmpty()) return
        selectedStep = Math.max(0, Math.min(b.steps.size - 1, selectedStep + delta))
        refreshChips()
        refreshHint()
        canvas?.invalidate()
    }

    private fun deleteStep() {
        val b = prof.bindingFor(selected) ?: return
        if (b.mode != BindMode.MACRO) return
        if (b.steps.size <= 1) {
            Toast.makeText(svc, "A macro precisa de pelo menos um passo. Para tirar tudo, use \"Remover ponto\".", Toast.LENGTH_SHORT).show()
            return
        }
        selectedStep = b.removeStep(selectedStep)
        refreshChips()
        refreshHint()
        canvas?.invalidate()
    }

    private fun setMode(m: BindMode) {
        val cur = prof.bindingFor(selected)
        if (cur == null) {
            // ponto novo no meio da tela: arraste para o lugar certo
            prof.set(selected, m, 0.5f, 0.5f).applyModeDefaults()
        } else {
            cur.mode = m
            cur.applyModeDefaults()
        }
        refreshChips()
        refreshHint()
        canvas?.invalidate()
    }

    private fun toggleTest() {
        testing = !testing
        // em teste o mapeamento volta a valer; fora dele os botões só selecionam o ponto
        PadEngine.setEditing(!testing)
        val cv = canvas
        if (cv != null) {
            try {
                wm.updateViewLayout(cv, canvasParams(!testing))
            } catch (e: Exception) {
            }
            cv.invalidate()
        }
        testChip?.text = if (testing) "Parar teste" else "Testar"
        refreshChips()
        refreshHint()
    }

    private fun openGame() {
        try {
            val li = svc.packageManager.getLaunchIntentForPackage(prof.pkg)
            if (li == null) {
                Toast.makeText(svc, "Não encontrei o jogo: abra-o você mesmo", Toast.LENGTH_SHORT).show()
                return
            }
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            svc.startActivity(li)
        } catch (e: Exception) {
            Toast.makeText(svc, "O Android não deixou abrir o jogo daqui: abra-o você mesmo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scrollToSelected() {
        val ch = btnChips[selected] ?: return
        val sv = scroll ?: return
        sv.post { sv.smoothScrollTo(Math.max(0, ch.left - dp(60)), 0) }
    }

    private fun currentLandscape(): Boolean = svc.screenWidth() > svc.screenHeight()

    private fun refreshChips() {
        for ((btn, ch) in btnChips) {
            val bd = prof.bindingFor(btn)
            ch.text = btn.label + (if (bd != null && bd.mode != BindMode.OFF) " •" else "")
            styleChip(ch, !testing && btn == selected)
        }
        val cur = prof.bindingFor(selected)
        val allowed = BindMode.forButton(selected)
        for ((m, mc) in modeChips) {
            mc.visibility = if (m in allowed) View.VISIBLE else View.GONE
            styleChip(mc, !testing && cur?.mode == m)
        }
        val land = currentLandscape()
        val nome = if (prof.landscape) "paisagem" else "retrato"
        orientChip?.text = if (land == prof.landscape) "Perfil: " + nome + " ✓" else "Perfil: " + nome + " ⚠ trocar"
        refreshParams()
    }

    private fun refreshHint() {
        val h = hint ?: return
        if (testing) {
            h.text = testStatus()
            return
        }
        val cur = prof.bindingFor(selected)
        h.text = if (cur == null || cur.mode == BindMode.OFF) {
            "Botão " + selected.label + ": toque na tela onde ele deve tocar. Ou aperte outro botão no controle para escolhê-lo."
        } else if (cur.mode == BindMode.MACRO) {
            "Macro " + selected.label + ": " + cur.steps.size + " passo(s), " + cur.macroLengthMs() + " ms por volta. " +
                "Toque na tela para ACRESCENTAR um passo; arraste um passo para movê-lo."
        } else if (cur.mode == BindMode.SLIDE) {
            "Gradual " + selected.label + " em X " + Math.round(cur.x * 100) + "%, Y " + Math.round(cur.y * 100) +
                "%. O dedo anda na direção da linha conforme o gatilho é apertado."
        } else {
            "Botão " + selected.label + " (" + cur.mode.label + ") em X " + Math.round(cur.x * 100) + "%, Y " +
                Math.round(cur.y * 100) + "%. Arraste o ponto, toque noutro lugar ou use as setas."
        }
    }

    private fun testStatus(): String {
        if (!PadEngine.masterOn) return "Teste: o mapeamento está desligado (chave geral no painel)."
        if (!prof.enabled) return "Teste: este perfil está desativado."
        if (PadEngine.foregroundPkg != prof.pkg) return "Teste: o jogo ainda não está na frente. Abra o jogo."
        if (currentLandscape() != prof.landscape) return "Teste: gire a tela ou toque em \"Perfil\" para trocar a orientação do perfil."
        val hasStick = prof.bindings.any { it.mode == BindMode.JOYSTICK || it.mode == BindMode.CAMERA }
        if (hasStick && !PadEngine.axesSupported) return "Teste: analógicos precisam do Android 14 ou mais novo, ou do Shizuku ligado e autorizado."
        return "Teste: aperte os botões do controle. O toque vai para o jogo e o ponto acende."
    }

    private fun modeColor(m: BindMode): Int = when (m) {
        BindMode.TAP -> Color.rgb(240, 138, 25)
        BindMode.TURBO -> Color.rgb(235, 87, 87)
        BindMode.MACRO -> Color.rgb(155, 89, 182)
        BindMode.SLIDE -> Color.rgb(26, 188, 156)
        else -> Color.rgb(25, 180, 240)
    }

    // ------------------------------------------------------------ tela com os pontos

    private inner class EditorCanvas(c: Context) : View(c) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val loc = IntArray(2)
        private var dragging: PadBinding? = null

        /** Macro: passo que está sendo arrastado (-1 = o arrasto é do ponto do botão). */
        private var dragStep = -1
        private var dragX = -1f
        private var dragY = -1f

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            // girou a tela: a barra precisa da largura nova e o aviso de orientação pode mudar
            post {
                relayoutBar()
                refreshChips()
                refreshHint()
            }
        }

        private fun sw(): Float = Math.max(1, svc.screenWidth() - 1).toFloat()
        private fun sh(): Float = Math.max(1, svc.screenHeight() - 1).toFloat()

        override fun onDraw(canvas: Canvas) {
            getLocationOnScreen(loc)
            val w = sw()
            val h = sh()
            if (!testing) canvas.drawColor(Color.argb(70, 0, 0, 0))
            val r = 20f * d
            paint.textAlign = Paint.Align.CENTER
            for (b in prof.bindings) {
                if (b.mode == BindMode.OFF) continue
                val cx = b.x * w - loc[0]
                val cy = b.y * h - loc[1]
                val sel = !testing && b.button == selected
                val hot = testing && PadEngine.isPressed(b.button)
                val base = modeColor(b.mode)
                val alpha = if (testing && !hot) 110 else 175
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base))
                canvas.drawCircle(cx, cy, if (hot) r * 1.3f else r, paint)
                if (sel || hot) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.5f * d
                    paint.color = if (hot) Color.rgb(61, 220, 132) else Color.WHITE
                    canvas.drawCircle(cx, cy, r + 4f * d, paint)
                }
                // analógico: anel do raio (joystick: até onde o dedo anda; câmera: quando volta ao ponto)
                if (b.mode == BindMode.JOYSTICK || b.mode == BindMode.CAMERA) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 1.5f * d
                    paint.color = Color.argb(150, 255, 255, 255)
                    canvas.drawCircle(cx, cy, b.radius * Math.min(w, h), paint)
                }
                // gradual: linha mostrando até onde o dedo anda com o gatilho no fundo
                if (b.mode == BindMode.SLIDE) {
                    val len = b.radius * Math.min(w, h)
                    val ex = cx + (if (b.dir == 2) -len else if (b.dir == 3) len else 0f)
                    val ey = cy + (if (b.dir == 0) -len else if (b.dir == 1) len else 0f)
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 3f * d
                    paint.color = Color.argb(190, 255, 255, 255)
                    canvas.drawLine(cx, cy, ex, ey, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(ex, ey, 5f * d, paint)
                }
                // macro: os outros passos, numerados e ligados por linhas
                if (b.mode == BindMode.MACRO && b.steps.size > 1) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 1.5f * d
                    paint.color = Color.argb(150, 255, 255, 255)
                    for (i in 1 until b.steps.size) {
                        canvas.drawLine(
                            b.steps[i - 1].x * w - loc[0], b.steps[i - 1].y * h - loc[1],
                            b.steps[i].x * w - loc[0], b.steps[i].y * h - loc[1], paint
                        )
                    }
                    for (i in 1 until b.steps.size) {
                        val sx = b.steps[i].x * w - loc[0]
                        val sy = b.steps[i].y * h - loc[1]
                        paint.style = Paint.Style.FILL
                        paint.color = Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base))
                        canvas.drawCircle(sx, sy, r * 0.8f, paint)
                        if (sel && i == selectedStep) {
                            paint.style = Paint.Style.STROKE
                            paint.strokeWidth = 2.5f * d
                            paint.color = Color.WHITE
                            canvas.drawCircle(sx, sy, r * 0.8f + 4f * d, paint)
                        }
                        paint.style = Paint.Style.FILL
                        paint.color = Color.WHITE
                        canvas.drawCircle(sx, sy, 2f * d, paint)
                        paint.textSize = 11f * d
                        paint.typeface = Typeface.DEFAULT_BOLD
                        paint.setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
                        canvas.drawText((i + 1).toString(), sx, sy - r - 4f * d, paint)
                        paint.clearShadowLayer()
                    }
                    if (sel && selectedStep == 0) {
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 2.5f * d
                        paint.color = Color.WHITE
                        canvas.drawCircle(cx, cy, r + 4f * d, paint)
                    }
                }
                // ponto exato do toque
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                canvas.drawCircle(cx, cy, 2.2f * d, paint)
                // nome do botão, acima do círculo
                paint.textSize = 12f * d
                paint.typeface = Typeface.DEFAULT_BOLD
                paint.color = Color.WHITE
                paint.setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
                canvas.drawText(b.button.tag + (if (b.mode == BindMode.MACRO) " 1" else ""), cx, cy - r - 6f * d, paint)
                paint.clearShadowLayer()
            }
            // mira enquanto arrasta
            if (dragging != null && dragX >= 0f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f * d
                paint.color = Color.argb(170, 255, 255, 255)
                canvas.drawLine(dragX - loc[0], 0f, dragX - loc[0], height.toFloat(), paint)
                canvas.drawLine(0f, dragY - loc[1], width.toFloat(), dragY - loc[1], paint)
            }
        }

        private fun hit(rawX: Float, rawY: Float): PadBinding? {
            val w = sw()
            val h = sh()
            var best: PadBinding? = null
            var bestD = 32f * d
            for (b in prof.bindings) {
                if (b.mode == BindMode.OFF) continue
                val dx = b.x * w - rawX
                val dy = b.y * h - rawY
                val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                if (dist < bestD) {
                    bestD = dist
                    best = b
                }
            }
            return best
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (testing) return false
            val fx = PadProfile.clamp01(ev.rawX / sw())
            val fy = PadProfile.clamp01(ev.rawY / sh())
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStep = -1
                    val selB = prof.bindingFor(selected)
                    val stepHit = if (selB != null && selB.mode == BindMode.MACRO)
                        selB.nearestStep(ev.rawX, ev.rawY, sw(), sh(), 32f * d) else -1
                    val hitB = if (stepHit >= 0) null else hit(ev.rawX, ev.rawY)
                    if (stepHit >= 0 && selB != null) {
                        // macro: pegou um passo do botão selecionado
                        dragging = selB
                        dragStep = stepHit
                        selectedStep = stepHit
                    } else if (hitB != null) {
                        dragging = hitB
                        selected = hitB.button
                        selectedStep = 0
                        scrollToSelected()
                    } else if (selB != null && selB.mode == BindMode.MACRO) {
                        // macro: toque em área vazia ACRESCENTA um passo (não move os existentes)
                        val ni = selB.addStep(fx, fy)
                        if (ni >= 0) {
                            dragging = selB
                            dragStep = ni
                            selectedStep = ni
                        } else {
                            Toast.makeText(svc, "No máximo " + PadBinding.MAX_STEPS + " passos por macro", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        // área vazia: põe (ou move) o ponto do botão selecionado
                        val cur = prof.bindingFor(selected)
                        dragging = if (cur == null) {
                            prof.set(selected, BindMode.defaultFor(selected), fx, fy)
                        } else {
                            if (cur.mode == BindMode.OFF) cur.mode = BindMode.defaultFor(cur.button)
                            cur.x = fx
                            cur.y = fy
                            cur
                        }
                    }
                    dragX = ev.rawX
                    dragY = ev.rawY
                    refreshChips()
                    refreshHint()
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dr = dragging
                    if (dr != null) {
                        if (dr.mode == BindMode.MACRO) {
                            dr.moveStep(if (dragStep >= 0) dragStep else 0, fx, fy)
                        } else {
                            dr.x = fx
                            dr.y = fy
                        }
                        dragX = ev.rawX
                        dragY = ev.rawY
                        refreshHint()
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = null
                    dragStep = -1
                    dragX = -1f
                    dragY = -1f
                    refreshChips()
                    refreshHint()
                    invalidate()
                }
            }
            return true
        }
    }
}
