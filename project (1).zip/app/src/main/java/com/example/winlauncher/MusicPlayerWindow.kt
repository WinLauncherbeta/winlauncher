package com.example.winlauncher

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import kotlin.math.min

/**
 * Reprodutor de música da WinLauncher. Abre um áudio (com a lista das outras músicas da mesma pasta),
 * em uma janela de vidro que segue o modo claro ou escuro.
 */
class MusicPlayerWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    private val light: () -> Boolean
) {
    companion object {
        private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "ogg", "oga", "wav", "flac", "opus", "amr")

        fun isAudioName(name: String): Boolean =
            AUDIO_EXT.contains(name.substringAfterLast('.', "").lowercase())
    }

    val layer = FrameLayout(act)
    private val win = FrameLayout(act)
    private var open = false
    private var minimized = false
    val isOpen: Boolean get() = open
    private var stackAbove: View? = null

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val ui = Handler(Looper.getMainLooper())

    private var player: MediaPlayer? = null
    private var prepared = false
    private var seekDragging = false
    private var queue: List<File> = emptyList()
    private var index = 0

    private val titleTv = TextView(act)
    private val artistTv = TextView(act)
    private val timeTv = TextView(act)
    private val cover = ImageView(act)
    private val seek = SeekBar(act)
    private val playBtn = ImageView(act)
    private val listBox = LinearLayout(act)
    private val closeX = ImageView(act)
    private val minBtn = ImageView(act)
    private var dragSx = 0f
    private var dragSy = 0f
    private var dragX0 = 0f
    private var dragY0 = 0f
    private val prevBtn = ImageView(act)
    private val nextBtn = ImageView(act)
    private val rowViews = ArrayList<TextView>()

    private val tick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!prepared) return
            val dur = p.duration.coerceAtLeast(1)
            if (!seekDragging) seek.progress = (p.currentPosition * 1000L / dur).toInt()
            timeTv.text = fmt(p.currentPosition) + " / " + fmt(p.duration)
            playBtn.setImageResource(if (p.isPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play)
            if (open) ui.postDelayed(this, 300L)
        }
    }

    init {
        layer.visibility = View.GONE

        val winW = min(dp(560), act.resources.displayMetrics.widthPixels - dp(32))
        win.isClickable = true
        win.tag = CursorController.NOHAND
        win.elevation = dp(16).toFloat()
        layer.addView(win, FrameLayout.LayoutParams(winW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(14), dp(20), dp(18))
        win.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // barra de título
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val appName = TextView(act)
        appName.text = "Reprodutor de música"
        appName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        bar.addView(appName, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        minBtn.setImageResource(R.drawable.ic_minimize)
        minBtn.setPadding(dp(6), dp(6), dp(6), dp(6))
        minBtn.isClickable = true
        minBtn.setOnClickListener { minimize() }
        bar.addView(minBtn, LinearLayout.LayoutParams(dp(30), dp(30)))
        closeX.setImageResource(R.drawable.ic_close)
        closeX.setPadding(dp(6), dp(6), dp(6), dp(6))
        closeX.isClickable = true
        closeX.setOnClickListener { close() }
        bar.addView(closeX, LinearLayout.LayoutParams(dp(30), dp(30)))

        // arrastar pela barra de título; botão direito abre o menu da janela
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if ((ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                        showWindowMenu(ev.rawX.toInt(), ev.rawY.toInt())
                    } else {
                        dragSx = ev.rawX
                        dragSy = ev.rawY
                        dragX0 = win.translationX
                        dragY0 = win.translationY
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val screenW = act.resources.displayMetrics.widthPixels
                    val screenH = act.resources.displayMetrics.heightPixels
                    val maxX = (screenW / 2f) - dp(120)
                    val maxY = (screenH / 2f) - dp(40)
                    win.translationX = (dragX0 + (ev.rawX - dragSx)).coerceIn(-maxX, maxX)
                    win.translationY = (dragY0 + (ev.rawY - dragSy)).coerceIn(-maxY, maxY)
                }
            }
            true
        }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // capa e textos
        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        cover.setImageResource(R.drawable.ic_music_note)
        cover.setPadding(dp(24), dp(24), dp(24), dp(24))
        top.addView(cover, LinearLayout.LayoutParams(dp(128), dp(128)))
        val info = LinearLayout(act)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(14), 0, 0, 0)
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        titleTv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        titleTv.isSingleLine = true
        titleTv.ellipsize = android.text.TextUtils.TruncateAt.END
        artistTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        artistTv.isSingleLine = true
        artistTv.ellipsize = android.text.TextUtils.TruncateAt.END
        info.addView(titleTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        info.addView(artistTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        // progresso
        seek.max = 1000
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val mp = player ?: return
                if (fromUser && prepared) mp.seekTo((mp.duration.toLong() * p / 1000L).toInt())
            }
            override fun onStartTrackingTouch(s: SeekBar?) { seekDragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) { seekDragging = false }
        })
        col.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        timeTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        timeTv.text = "0:00 / 0:00"
        col.addView(timeTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // controles
        val ctrl = LinearLayout(act)
        ctrl.orientation = LinearLayout.HORIZONTAL
        ctrl.gravity = Gravity.CENTER
        for ((iv, res) in listOf(prevBtn to R.drawable.ic_media_prev, playBtn to R.drawable.ic_media_play, nextBtn to R.drawable.ic_media_next)) {
            iv.setImageResource(res)
            iv.setPadding(dp(10), dp(10), dp(10), dp(10))
            iv.isClickable = true
        }
        prevBtn.setOnClickListener { prevTrack() }
        playBtn.setOnClickListener { togglePlay() }
        nextBtn.setOnClickListener { nextTrack() }
        ctrl.addView(prevBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        ctrl.addView(playBtn, LinearLayout.LayoutParams(dp(56), dp(56)))
        ctrl.addView(nextBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        col.addView(ctrl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        // lista da pasta
        val scroll = ScrollView(act)
        listBox.orientation = LinearLayout.VERTICAL
        scroll.addView(listBox)
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(180)).apply { topMargin = dp(12) })

        applyTheme()
    }

    /** Coloca a janela na pilha das janelas, logo abaixo do menu (mesma regra das outras janelas). */
    fun attachBelow(menuLayer: View) {
        stackAbove = menuLayer
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    /** Abre um áudio e toca. A lista é formada pelas músicas da mesma pasta. */
    fun openFile(f: File) {
        val siblings = f.parentFile?.listFiles()
            ?.filter { it.isFile && isAudioName(it.name) }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()
        queue = if (siblings.contains(f)) siblings else listOf(f)
        index = queue.indexOf(f).coerceAtLeast(0)
        show()
        playCurrent()
    }

    fun show() {
        applyTheme()
        if (queue.isEmpty()) {
            titleTv.text = "Nenhuma música"
            artistTv.text = "Abra um arquivo de áudio para tocar"
        }
        if (open && !minimized) {
            WindowStack.raise(root, layer, stackAbove)
            return
        }
        open = true
        minimized = false
        WindowStack.raise(root, layer, stackAbove)
        layer.visibility = View.VISIBLE
        layer.animate().cancel()
        layer.alpha = 0f
        layer.animate().alpha(1f).setDuration(160L).start()
    }

    /** Minimiza: a janela some, mas a música continua tocando. */
    fun minimize() {
        if (!open || minimized) return
        minimized = true
        layer.animate().cancel()
        layer.animate().alpha(0f).setDuration(120L).withEndAction {
            if (minimized) layer.visibility = View.GONE
        }.start()
    }

    fun toggleFromTaskbar() {
        if (minimized) show() else minimize()
    }

    private fun showWindowMenu(x: Int, y: Int) {
        val items = arrayListOf(
            MenuItem("Minimizar", R.drawable.ic_minimize, action = { minimize() }),
            MenuItem("Fechar", R.drawable.ic_close, action = { close() })
        )
        act.menu.show(items, x, y)
    }

    fun close() {
        if (!open) return
        open = false
        minimized = false
        release()
        layer.animate().cancel()
        layer.animate().alpha(0f).setDuration(120L).withEndAction {
            if (!open) layer.visibility = View.GONE
        }.start()
    }

    // ------------------------------------------------------------ reprodução

    private fun playCurrent() {
        val f = queue.getOrNull(index) ?: return
        release()
        prepared = false
        titleTv.text = f.nameWithoutExtension
        artistTv.text = ""
        cover.setImageResource(R.drawable.ic_music_note)
        loadMetadata(f)
        rebuildList()
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { p ->
                prepared = true
                p.start()
                ui.post(tick)
            }
            mp.setOnCompletionListener { nextTrack() }
            mp.setOnErrorListener { _, _, _ ->
                artistTv.text = "Não foi possível tocar este arquivo"
                prepared = false
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            artistTv.text = "Não foi possível tocar este arquivo"
        }
    }

    private fun togglePlay() {
        val p = player ?: return
        if (!prepared) return
        if (p.isPlaying) p.pause() else p.start()
        ui.post(tick)
    }

    private fun nextTrack() {
        if (queue.isEmpty()) return
        index = (index + 1) % queue.size
        playCurrent()
    }

    private fun prevTrack() {
        val p = player
        if (p != null && prepared && p.currentPosition > 3000) {
            p.seekTo(0)
            return
        }
        if (queue.isEmpty()) return
        index = (index - 1 + queue.size) % queue.size
        playCurrent()
    }

    private fun release() {
        ui.removeCallbacks(tick)
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        prepared = false
    }

    /** Título, artista e capa vêm dos metadados do arquivo (carregados fora da tela principal). */
    private fun loadMetadata(f: File) {
        val key = f.absolutePath
        Thread {
            var title: String? = null
            var artist: String? = null
            var pic: ByteArray? = null
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(key)
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                pic = r.embeddedPicture
                r.release()
            } catch (e: Exception) {
            }
            val t = title
            val a = artist
            val bmp: Bitmap? = pic?.let {
                try {
                    BitmapFactory.decodeByteArray(it, 0, it.size)
                } catch (e: Exception) {
                    null
                }
            }
            ui.post {
                if (queue.getOrNull(index)?.absolutePath != key) return@post
                if (!t.isNullOrBlank()) titleTv.text = t
                artistTv.text = a ?: ""
                if (bmp != null) {
                    cover.setPadding(0, 0, 0, 0)
                    cover.setImageBitmap(bmp)
                }
            }
        }.start()
    }

    private fun rebuildList() {
        listBox.removeAllViews()
        rowViews.clear()
        for ((i, f) in queue.withIndex()) {
            val tv = TextView(act)
            tv.text = f.nameWithoutExtension
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            tv.isSingleLine = true
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.setPadding(dp(12), dp(9), dp(12), dp(9))
            tv.setTextColor(if (i == index) cAccent else cText())
            tv.background = rounded(if (i == index) Color.argb(40, 61, 157, 255) else Color.TRANSPARENT, 10)
            tv.isClickable = true
            tv.setOnClickListener {
                index = i
                playCurrent()
            }
            rowViews.add(tv)
            listBox.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        }
    }

    // ------------------------------------------------------------ aparência

    private val cAccent = Color.parseColor("#3D9DFF")

    private fun cText(): Int = if (light()) Color.parseColor("#1F1F1F") else Color.WHITE
    private fun cSub(): Int = if (light()) Color.parseColor("#88000000") else Color.parseColor("#B3FFFFFF")
    private fun cGlass(): Int = if (light()) Color.parseColor("#E6F3F3F3") else Color.parseColor("#E61C1C1C")
    private fun cRow(): Int = if (light()) Color.parseColor("#14000000") else Color.parseColor("#26FFFFFF")

    private fun applyTheme() {
        win.background = rounded(cGlass(), 20)
        titleTv.setTextColor(cText())
        artistTv.setTextColor(cSub())
        timeTv.setTextColor(cSub())
        closeX.setColorFilter(cText())
        for (iv in listOf(prevBtn, playBtn, nextBtn)) {
            iv.setColorFilter(cText())
            iv.background = rounded(cRow(), 14)
        }
        cover.background = rounded(cRow(), 14)
        for (tv in rowViews) tv.setTextColor(cText())
    }

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
        }

    private fun fmt(ms: Int): String {
        val total = ms / 1000
        return "%d:%02d".format(total / 60, total % 60)
    }
}
