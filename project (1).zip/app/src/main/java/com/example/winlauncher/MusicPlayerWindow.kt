package com.example.winlauncher

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import kotlin.math.min

/**
 * Reprodutor de música da WinLauncher, no estilo do "Media Player" do Windows 11:
 * menu lateral (Início / Música), lista das músicas do aparelho e barra de reprodução embaixo.
 * Procura as músicas do aparelho sozinho (MediaStore + varredura do armazenamento).
 */
class MusicPlayerWindow(
    private val act: MainActivity,
    private val root: FrameLayout,
    private val light: () -> Boolean
) {
    companion object {
        private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "ogg", "oga", "wav", "flac", "opus", "amr", "wma", "mka")

        fun isAudioName(name: String): Boolean =
            AUDIO_EXT.contains(name.substringAfterLast('.', "").lowercase())
    }

    private class Track(val file: File, val durMs: Long, val modified: Long) {
        val title: String get() = file.name
    }

    val layer = FrameLayout(act)
    private val win = FrameLayout(act)
    private var open = false
    private var minimized = false
    private var maximized = false
    val isOpen: Boolean get() = open
    private var stackAbove: View? = null

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val ui = Handler(Looper.getMainLooper())

    private var player: MediaPlayer? = null
    private var prepared = false
    private var seekDragging = false

    // biblioteca do aparelho
    private var library: List<Track> = emptyList()
    private var loading = false
    private var shown: List<Track> = emptyList()
    private var page = 0 // 0 = Início, 1 = Música

    // fila de reprodução
    private var queue: List<Track> = emptyList()
    private var index = 0
    private var repeatMode = 0 // 0 desligado, 1 todas, 2 uma

    private var navCollapsed = false

    private val titleBar = LinearLayout(act)
    private val appIcon = ImageView(act)
    private val appName = TextView(act)
    private val minBtn = ImageView(act)
    private val maxBtn = ImageView(act)
    private val closeX = ImageView(act)

    private val nav = LinearLayout(act)
    private val menuBtn = ImageView(act)
    private val navHome = NavItem(R.drawable.ic_home, "Início", 0)
    private val navMusic = NavItem(R.drawable.ic_music_note, "Música", 1)

    private val contentPane = LinearLayout(act)
    private val headerTv = TextView(act)
    private val emptyTv = TextView(act)
    private val listView = ListView(act)

    private val bottom = LinearLayout(act)
    private val bottomLine = View(act)
    private val timeTv = TextView(act)
    private val seek = SeekBar(act)
    private val prevBtn = ImageView(act)
    private val playBtn = ImageView(act)
    private val nextBtn = ImageView(act)
    private val repeatBtn = ImageView(act)

    private var dragSx = 0f
    private var dragSy = 0f
    private var dragX0 = 0f
    private var dragY0 = 0f

    private val cAccent = Color.parseColor("#FF9A66")

    private val tick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!prepared) return
            val dur = p.duration.coerceAtLeast(1)
            if (!seekDragging) seek.progress = (p.currentPosition * 1000L / dur).toInt()
            timeTv.text = fmt(p.currentPosition.toLong()) + " / " + fmt(p.duration.toLong())
            playBtn.setImageResource(if (p.isPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play)
            if (open) ui.postDelayed(this, 300L)
        }
    }

    /** Item do menu lateral (ícone + texto + marca laranja quando selecionado). */
    private inner class NavItem(iconRes: Int, text: String, val page: Int) {
        val row = LinearLayout(act)
        val bar = View(act)
        val icon = ImageView(act)
        val label = TextView(act)

        init {
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.isClickable = true
            row.setOnClickListener { setPage(page) }
            row.addView(bar, LinearLayout.LayoutParams(dp(3), dp(18)))
            icon.setImageResource(iconRes)
            row.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)).apply { leftMargin = dp(12) })
            label.text = text
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            label.isSingleLine = true
            row.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(14) })
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: makeRow()
            val t = shown[position]
            val icon = row.getChildAt(0) as ImageView
            val name = row.getChildAt(1) as TextView
            val dur = row.getChildAt(2) as TextView
            name.text = t.title
            dur.text = fmt(t.durMs)
            val cur = player != null && queue.getOrNull(index)?.file?.absolutePath == t.file.absolutePath
            icon.setColorFilter(if (cur) cAccent else cText())
            name.setTextColor(if (cur) cAccent else cText())
            dur.setTextColor(cSub())
            row.background = InsetDrawable(rounded(if (cur) cSel() else Color.TRANSPARENT, 8), 0, dp(2), 0, dp(2))
            return row
        }
    }

    private fun makeRow(): LinearLayout {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(18), 0, dp(18), 0)
        row.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        val icon = ImageView(act)
        icon.setImageResource(R.drawable.ic_music_note)
        row.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))
        val name = TextView(act)
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        name.isSingleLine = true
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(18) })
        val dur = TextView(act)
        dur.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        dur.isSingleLine = true
        row.addView(dur, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(12) })
        return row
    }

    init {
        layer.visibility = View.GONE

        win.isClickable = true
        win.tag = CursorController.NOHAND
        win.elevation = dp(16).toFloat()
        layer.addView(win, FrameLayout.LayoutParams(dp(600), dp(400)))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        win.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- barra de título
        titleBar.orientation = LinearLayout.HORIZONTAL
        titleBar.gravity = Gravity.CENTER_VERTICAL
        appIcon.setImageResource(R.drawable.ic_music_note)
        appIcon.setColorFilter(cAccent)
        titleBar.addView(appIcon, LinearLayout.LayoutParams(dp(20), dp(20)).apply { leftMargin = dp(16) })
        appName.text = "Música"
        appName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        titleBar.addView(appName, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })
        minBtn.setImageResource(R.drawable.ic_minimize)
        minBtn.setPadding(dp(14), dp(12), dp(14), dp(12))
        minBtn.isClickable = true
        minBtn.setOnClickListener { minimize() }
        titleBar.addView(minBtn, LinearLayout.LayoutParams(dp(46), dp(44)))
        maxBtn.setImageResource(R.drawable.ic_maximize)
        maxBtn.setPadding(dp(14), dp(12), dp(14), dp(12))
        maxBtn.isClickable = true
        maxBtn.setOnClickListener { toggleMax() }
        titleBar.addView(maxBtn, LinearLayout.LayoutParams(dp(46), dp(44)))
        closeX.setImageResource(R.drawable.ic_close)
        closeX.setPadding(dp(14), dp(12), dp(14), dp(12))
        closeX.isClickable = true
        closeX.setOnClickListener { close() }
        titleBar.addView(closeX, LinearLayout.LayoutParams(dp(46), dp(44)))

        // arrastar pela barra de título; botão direito abre o menu da janela
        titleBar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if ((ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                        showWindowMenu(ev.rawX.toInt(), ev.rawY.toInt())
                    } else {
                        dragSx = ev.rawX
                        dragSy = ev.rawY
                        dragX0 = win.translationX
                        dragY0 = win.translationY
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!maximized) {
                        val screenW = act.resources.displayMetrics.widthPixels
                        val screenH = act.resources.displayMetrics.heightPixels
                        val maxX = (screenW / 2f) - dp(120)
                        val maxY = (screenH / 2f) - dp(40)
                        win.translationX = (dragX0 + (ev.rawX - dragSx)).coerceIn(-maxX, maxX)
                        win.translationY = (dragY0 + (ev.rawY - dragSy)).coerceIn(-maxY, maxY)
                    }
                }
            }
            true
        }
        col.addView(titleBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))

        // ---- corpo: menu lateral + conteúdo
        val body = LinearLayout(act)
        body.orientation = LinearLayout.HORIZONTAL
        col.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        nav.orientation = LinearLayout.VERTICAL
        nav.setPadding(dp(8), dp(4), dp(8), dp(8))
        menuBtn.setImageResource(R.drawable.ic_menu)
        menuBtn.setPadding(dp(9), dp(9), dp(9), dp(9))
        menuBtn.isClickable = true
        menuBtn.setOnClickListener { setNavCollapsed(!navCollapsed) }
        nav.addView(menuBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { bottomMargin = dp(10) })
        nav.addView(navHome.row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { bottomMargin = dp(4) })
        nav.addView(navMusic.row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        body.addView(nav, LinearLayout.LayoutParams(dp(190), ViewGroup.LayoutParams.MATCH_PARENT))

        contentPane.orientation = LinearLayout.VERTICAL
        contentPane.setPadding(dp(24), dp(8), dp(16), 0)
        headerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        headerTv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        contentPane.addView(headerTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        emptyTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        emptyTv.setPadding(dp(4), dp(12), dp(4), 0)
        emptyTv.visibility = View.GONE
        contentPane.addView(emptyTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        listView.divider = null
        listView.dividerHeight = 0
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.overScrollMode = View.OVER_SCROLL_NEVER
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val t = shown.getOrNull(position) ?: return@setOnItemClickListener
            queue = shown
            index = queue.indexOf(t).coerceAtLeast(0)
            playCurrent()
        }
        contentPane.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        body.addView(contentPane, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // ---- barra de reprodução
        bottom.orientation = LinearLayout.VERTICAL
        col.addView(bottomLine, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        col.addView(bottom, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val seekRow = LinearLayout(act)
        seekRow.orientation = LinearLayout.HORIZONTAL
        seekRow.gravity = Gravity.CENTER_VERTICAL
        seekRow.setPadding(dp(20), dp(10), dp(20), 0)
        timeTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        timeTv.text = "00:00 / 00:00"
        timeTv.minWidth = dp(96)
        seekRow.addView(timeTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        seek.max = 1000
        seek.progressTintList = ColorStateList.valueOf(cAccent)
        seek.thumbTintList = ColorStateList.valueOf(cAccent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val mp = player ?: return
                if (fromUser && prepared) mp.seekTo((mp.duration.toLong() * p / 1000L).toInt())
            }
            override fun onStartTrackingTouch(s: SeekBar?) { seekDragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) { seekDragging = false }
        })
        seekRow.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val ctrlWrap = FrameLayout(act)
        val ctrl = LinearLayout(act)
        ctrl.orientation = LinearLayout.HORIZONTAL
        ctrl.gravity = Gravity.CENTER
        prevBtn.setImageResource(R.drawable.ic_media_prev)
        prevBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        prevBtn.isClickable = true
        prevBtn.setOnClickListener { prevTrack() }
        playBtn.setImageResource(R.drawable.ic_media_play)
        playBtn.setPadding(dp(12), dp(12), dp(12), dp(12))
        playBtn.isClickable = true
        playBtn.setOnClickListener { togglePlay() }
        nextBtn.setImageResource(R.drawable.ic_media_next)
        nextBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        nextBtn.isClickable = true
        nextBtn.setOnClickListener { nextTrack() }
        ctrl.addView(prevBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        ctrl.addView(playBtn, LinearLayout.LayoutParams(dp(54), dp(54)).apply { leftMargin = dp(14); rightMargin = dp(14) })
        ctrl.addView(nextBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        ctrlWrap.addView(ctrl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        repeatBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        repeatBtn.isClickable = true
        repeatBtn.setOnClickListener {
            repeatMode = (repeatMode + 1) % 3
            applyRepeatIcon()
        }
        ctrlWrap.addView(repeatBtn, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
        bottom.addView(ctrlWrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2); bottomMargin = dp(10) })

        applyRepeatIcon()
        setPage(0)
        applyTheme()
    }

    /** Coloca a janela na pilha das janelas, logo abaixo do menu (mesma regra das outras janelas). */
    fun attachBelow(menuLayer: View) {
        stackAbove = menuLayer
        val idx = root.indexOfChild(menuLayer)
        root.addView(layer, if (idx >= 0) idx else root.childCount, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    /** Abre um áudio e toca. Se ele estiver na biblioteca do aparelho, a fila é a biblioteca; senão, a pasta dele. */
    fun openFile(f: File) {
        show()
        val inLib = library.firstOrNull { it.file.absolutePath == f.absolutePath }
        if (inLib != null) {
            queue = library.sortedBy { it.title.lowercase() }
            index = queue.indexOf(inLib).coerceAtLeast(0)
        } else {
            val siblings = (f.parentFile?.listFiles()
                ?.filter { it.isFile && isAudioName(it.name) }
                ?.sortedBy { it.name.lowercase() } ?: emptyList())
                .map { Track(it, 0L, it.lastModified()) }
            queue = if (siblings.any { it.file.absolutePath == f.absolutePath }) siblings else listOf(Track(f, 0L, f.lastModified()))
            index = queue.indexOfFirst { it.file.absolutePath == f.absolutePath }.coerceAtLeast(0)
        }
        playCurrent()
    }

    fun show() {
        applyTheme()
        if (open && !minimized) {
            WindowStack.raise(root, layer, stackAbove)
            return
        }
        val wasClosed = !open
        open = true
        minimized = false
        sizeWindow()
        WindowStack.raise(root, layer, stackAbove)
        layer.visibility = View.VISIBLE
        layer.animate().cancel()
        layer.alpha = 0f
        layer.animate().alpha(1f).setDuration(160L).start()
        if (wasClosed || library.isEmpty()) loadLibrary()
        if (player != null) ui.post(tick)
    }

    /** Minimiza: a janela some, mas a música continua tocando. */
    fun minimize() {
        if (!open || minimized) return
        minimized = true
        layer.animate().cancel()
        layer.animate().alpha(0f).setDuration(120L).withEndAction {
            if (minimized) layer.visibility = View.GONE
        }.start()
    }

    fun toggleFromTaskbar() {
        if (minimized) show() else minimize()
    }

    private fun toggleMax() {
        maximized = !maximized
        sizeWindow()
    }

    private fun showWindowMenu(x: Int, y: Int) {
        val items = arrayListOf(
            MenuItem("Minimizar", R.drawable.ic_minimize, action = { minimize() }),
            MenuItem(if (maximized) "Restaurar" else "Maximizar", if (maximized) R.drawable.ic_restore else R.drawable.ic_maximize, action = { toggleMax() }),
            MenuItem("Fechar", R.drawable.ic_close, action = { close() })
        )
        act.menu.show(items, x, y)
    }

    fun close() {
        if (!open) return
        open = false
        minimized = false
        release()
        queue = emptyList()
        index = 0
        seek.progress = 0
        timeTv.text = "00:00 / 00:00"
        playBtn.setImageResource(R.drawable.ic_media_play)
        adapter.notifyDataSetChanged()
        layer.animate().cancel()
        layer.animate().alpha(0f).setDuration(120L).withEndAction {
            if (!open) layer.visibility = View.GONE
        }.start()
    }

    // ------------------------------------------------------------ tamanho

    private fun sizeWindow() {
        val sw = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels
        val sh = if (root.height > 0) root.height else act.resources.displayMetrics.heightPixels
        val ins = act.taskbarInsetsPx()
        val availH = sh - ins.first - ins.second
        val w: Int
        val h: Int
        if (maximized) {
            w = sw
            h = availH
            win.translationX = 0f
            win.translationY = 0f
        } else {
            w = min(dp(920), sw - dp(24))
            h = min(dp(520), availH - dp(24))
        }
        val lp = win.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        lp.height = h
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = (sw - w) / 2
        lp.topMargin = ins.first + (availH - h) / 2
        win.layoutParams = lp
        applyWindowStyle()
    }

    private fun applyWindowStyle() {
        val r = if (maximized) 0 else 10
        val bg = GradientDrawable()
        bg.setColor(cWin())
        bg.cornerRadius = dp(r).toFloat()
        bg.setStroke(if (maximized) 0 else dp(1), cLine())
        win.background = bg
        win.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
            }
        }
        win.clipToOutline = true
        win.invalidateOutline()
        maxBtn.setImageResource(if (maximized) R.drawable.ic_restore else R.drawable.ic_maximize)
    }

    // ------------------------------------------------------------ navegação e biblioteca

    private fun setNavCollapsed(c: Boolean) {
        navCollapsed = c
        val lp = nav.layoutParams
        lp.width = if (c) dp(60) else dp(190)
        nav.layoutParams = lp
        navHome.label.visibility = if (c) View.GONE else View.VISIBLE
        navMusic.label.visibility = if (c) View.GONE else View.VISIBLE
    }

    private fun setPage(p: Int) {
        page = p
        headerTv.text = if (p == 0) "Início" else "Música"
        refreshShown()
        applyNavSelection()
    }

    private fun refreshShown() {
        shown = if (page == 0) library.sortedByDescending { it.modified }.take(30)
        else library.sortedBy { it.title.lowercase() }
        adapter.notifyDataSetChanged()
        if (shown.isEmpty()) {
            emptyTv.text = if (loading) "Procurando músicas do aparelho…"
            else "Nenhuma música encontrada. Se você tem músicas no aparelho, conceda \"acesso a todos os arquivos\" ao WinLauncher nas configurações do Android."
            emptyTv.visibility = View.VISIBLE
            listView.visibility = View.GONE
        } else {
            emptyTv.visibility = View.GONE
            listView.visibility = View.VISIBLE
        }
    }

    /** Procura as músicas do aparelho fora da tela principal e atualiza a lista quando terminar. */
    private fun loadLibrary() {
        if (loading) return
        loading = true
        refreshShown()
        Thread {
            val map = LinkedHashMap<String, Track>()
            try {
                queryMediaStore(map)
            } catch (e: Exception) {
            }
            try {
                scanStorage(map)
            } catch (e: Exception) {
            }
            val list = ArrayList<Track>(map.values)
            ui.post {
                library = list
                loading = false
                refreshShown()
            }
        }.start()
    }

    private fun queryMediaStore(map: MutableMap<String, Track>) {
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_MODIFIED
        )
        val sel = "${MediaStore.Audio.Media.IS_RINGTONE}=0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION}=0 AND " +
            "${MediaStore.Audio.Media.IS_ALARM}=0"
        act.contentResolver.query(uri, proj, sel, null, null)?.use { c ->
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iMod = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
            while (c.moveToNext()) {
                val path = c.getString(iData) ?: continue
                map[path] = Track(File(path), c.getLong(iDur), c.getLong(iMod) * 1000L)
            }
        }
    }

    /** Complementa o MediaStore: varre o armazenamento atrás de áudios que o Android ainda não indexou. */
    private fun scanStorage(map: MutableMap<String, Track>) {
        val canAll = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
        if (!canAll) return
        val skipTop = setOf("Android", "Ringtones", "Notifications", "Alarms")
        val stack = ArrayList<Pair<File, Int>>()
        stack.add(Pair(Environment.getExternalStorageDirectory(), 0))
        var found = 0
        while (stack.isNotEmpty() && found < 3000) {
            val (dir, depth) = stack.removeAt(stack.size - 1)
            val kids = dir.listFiles() ?: continue
            for (k in kids) {
                val n = k.name
                if (n.startsWith(".")) continue
                if (k.isDirectory) {
                    if (depth == 0 && skipTop.contains(n)) continue
                    if (depth < 8) stack.add(Pair(k, depth + 1))
                } else if (isAudioName(n) && !map.containsKey(k.absolutePath) && k.length() > 1024L) {
                    map[k.absolutePath] = Track(k, probeDuration(k), k.lastModified())
                    found++
                }
            }
        }
    }

    private fun probeDuration(f: File): Long {
        return try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.absolutePath)
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } finally {
                r.release()
            }
        } catch (e: Exception) {
            0L
        }
    }

    // ------------------------------------------------------------ reprodução

    private fun playCurrent() {
        val t = queue.getOrNull(index) ?: return
        release()
        prepared = false
        seek.progress = 0
        timeTv.text = "00:00 / " + fmt(t.durMs)
        adapter.notifyDataSetChanged()
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(t.file.absolutePath)
            mp.setOnPreparedListener { p ->
                prepared = true
                p.start()
                ui.post(tick)
                adapter.notifyDataSetChanged()
            }
            mp.setOnCompletionListener { onCompleted() }
            mp.setOnErrorListener { _, _, _ ->
                timeTv.text = "Não foi possível tocar"
                prepared = false
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            timeTv.text = "Não foi possível tocar"
        }
        adapter.notifyDataSetChanged()
    }

    private fun onCompleted() {
        when {
            repeatMode == 2 -> playCurrent()
            index < queue.size - 1 -> {
                index++
                playCurrent()
            }
            repeatMode == 1 && queue.isNotEmpty() -> {
                index = 0
                playCurrent()
            }
            else -> {
                try {
                    player?.seekTo(0)
                } catch (e: Exception) {
                }
                playBtn.setImageResource(R.drawable.ic_media_play)
                seek.progress = 0
            }
        }
    }

    private fun togglePlay() {
        val p = player
        if (p == null) {
            // nada tocando: começa pela primeira música da lista
            val first = shown.firstOrNull() ?: return
            queue = shown
            index = queue.indexOf(first)
            playCurrent()
            return
        }
        if (!prepared) return
        if (p.isPlaying) p.pause() else p.start()
        ui.post(tick)
    }

    private fun nextTrack() {
        if (queue.isEmpty()) return
        index = (index + 1) % queue.size
        playCurrent()
    }

    private fun prevTrack() {
        val p = player
        if (p != null && prepared && p.currentPosition > 3000) {
            p.seekTo(0)
            return
        }
        if (queue.isEmpty()) return
        index = (index - 1 + queue.size) % queue.size
        playCurrent()
    }

    private fun release() {
        ui.removeCallbacks(tick)
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        prepared = false
    }

    // ------------------------------------------------------------ aparência

    private fun cText(): Int = if (light()) Color.parseColor("#1F1F1F") else Color.WHITE
    private fun cSub(): Int = if (light()) Color.parseColor("#99000000") else Color.parseColor("#B3FFFFFF")
    private fun cWin(): Int = if (light()) Color.parseColor("#F7F7F7") else Color.parseColor("#232323")
    private fun cNav(): Int = if (light()) Color.parseColor("#EAEAEA") else Color.parseColor("#1C1C1C")
    private fun cLine(): Int = if (light()) Color.parseColor("#D6D6D6") else Color.parseColor("#2E2E2E")
    private fun cSel(): Int = if (light()) Color.parseColor("#E2E2E2") else Color.parseColor("#303032")
    private fun cNavSel(): Int = if (light()) Color.parseColor("#DADADA") else Color.parseColor("#2B2B2B")

    private fun applyRepeatIcon() {
        when (repeatMode) {
            0 -> repeatBtn.setImageResource(R.drawable.ic_repeat_off)
            1 -> repeatBtn.setImageResource(R.drawable.ic_repeat)
            else -> repeatBtn.setImageResource(R.drawable.ic_repeat_one)
        }
        repeatBtn.setColorFilter(if (repeatMode == 0) cText() else cAccent)
    }

    private fun applyNavSelection() {
        for (n in listOf(navHome, navMusic)) {
            val sel = n.page == page
            n.row.background = rounded(if (sel) cNavSel() else Color.TRANSPARENT, 6)
            n.bar.background = rounded(cAccent, 2)
            n.bar.visibility = if (sel) View.VISIBLE else View.INVISIBLE
            n.icon.setColorFilter(cText())
            n.label.setTextColor(cText())
        }
    }

    private fun applyTheme() {
        applyWindowStyle()
        titleBar.setBackgroundColor(cNav())
        nav.setBackgroundColor(cNav())
        bottom.setBackgroundColor(cNav())
        bottomLine.setBackgroundColor(cLine())
        appName.setTextColor(cText())
        for (iv in listOf(minBtn, maxBtn, closeX, menuBtn)) iv.setColorFilter(cText())
        headerTv.setTextColor(cText())
        emptyTv.setTextColor(cSub())
        timeTv.setTextColor(cSub())
        seek.progressBackgroundTintList = ColorStateList.valueOf(if (light()) Color.parseColor("#BBBBBB") else Color.parseColor("#666666"))
        for (iv in listOf(prevBtn, nextBtn)) iv.setColorFilter(cText())
        playBtn.setColorFilter(cText())
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(Color.TRANSPARENT)
        ring.setStroke(dp(3), if (light()) Color.parseColor("#9A9A9A") else Color.parseColor("#6B6B6B"))
        playBtn.background = ring
        applyRepeatIcon()
        applyNavSelection()
        adapter.notifyDataSetChanged()
    }

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
        }

    private fun fmt(ms: Long): String {
        if (ms <= 0L) return "00:00"
        val total = ms / 1000
        return "%02d:%02d".format(total / 60, total % 60)
    }
}
