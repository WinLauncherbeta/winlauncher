package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Display
import android.view.Surface
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Gravador de tela (API oficial MediaProjection). Etapa 2: vídeo (H.264) + áudio AAC com microfone e áudio interno
 * (AudioPlaybackCapture, Android 10+) mixados numa só trilha. Salva em Filmes/WinLauncher.
 */
class ScreenRecordService : Service() {

    companion object {
        private const val CHANNEL = "screen_record"
        private const val NOTIF_ID = 4713
        const val ACTION_START = "com.example.winlauncher.REC_START"
        const val ACTION_STOP = "com.example.winlauncher.REC_STOP"
        const val ACTION_SAVE = "com.example.winlauncher.REC_SAVE"
        /** Janela do replay: quantos segundos antes do atalho são salvos. */
        const val REPLAY_SECONDS = 30
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"

        @Volatile
        var recording = false

        /** true quando está no modo replay: grava em memória só os últimos 30 s e salva quando pedido. */
        @Volatile
        var replayMode = false

        @Volatile
        private var instance: ScreenRecordService? = null

        /** Atalho Alt + Q: salva os últimos 30 s do replay (e continua). Avisa se o replay não está ligado. */
        fun saveReplayNow(ctx: Context, fromAccessibility: Boolean = false) {
            if (recording && replayMode) {
                instance?.saveReplayAsync()
            } else if (recording) {
                MiniToast.info(ctx, "Está gravando no modo normal. Para o replay, escolha Modo: Replay ao gravar.", fromAccessibility)
            } else {
                MiniToast.info(ctx, "O replay não está ligado. Inicie o gravador no modo Replay.", fromAccessibility)
            }
        }

        @Volatile
        var startedAtMs = 0L

        /** Fontes de áudio que existem nesta gravação, e se estão silenciadas (ajustável durante a gravação). */
        @Volatile
        var micActive = false

        @Volatile
        var sysActive = false

        @Volatile
        var micMuted = false

        @Volatile
        var sysMuted = false

        /** Chamado (em qualquer thread) quando começa ou termina a gravação. */
        @Volatile
        var onState: (() -> Unit)? = null

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            val i = Intent(ctx, ScreenRecordService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            if (!recording) return
            ctx.startService(Intent(ctx, ScreenRecordService::class.java).setAction(ACTION_STOP))
        }
    }

    /** Para onde vão as amostras codificadas: o arquivo (Mux) ou o buffer do replay. */
    private interface Sink {
        fun addTrack(f: MediaFormat): Int
        fun write(idx: Int, buf: java.nio.ByteBuffer, info: MediaCodec.BufferInfo)
    }

    private class Sample(val track: Int, val data: ByteArray, val pts: Long, val flags: Int)

    /**
     * Guarda em memória os últimos [windowUs] de vídeo+áudio já codificados (H.264/AAC). Sempre mantém desde um quadro
     * chave, para o clipe salvo começar limpo (fica com 30 a ~32 s).
     */
    private class ReplayBuffer(private val windowUs: Long) : Sink {
        private val formats = ArrayList<MediaFormat>()
        private var videoTrack = -1
        private val samples = java.util.ArrayDeque<Sample>()
        private val keyPts = java.util.ArrayDeque<Long>()
        private var bytes = 0L
        private var newest = 0L

        @Synchronized
        override fun addTrack(f: MediaFormat): Int {
            formats.add(f)
            if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) videoTrack = formats.size - 1
            return formats.size - 1
        }

        @Synchronized
        override fun write(idx: Int, buf: java.nio.ByteBuffer, info: MediaCodec.BufferInfo) {
            val d = ByteArray(info.size)
            buf.get(d)
            val key = idx == videoTrack && (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
            samples.addLast(Sample(idx, d, info.presentationTimeUs, info.flags))
            bytes += d.size
            if (info.presentationTimeUs > newest) newest = info.presentationTimeUs
            if (key) {
                keyPts.addLast(info.presentationTimeUs)
                trim()
            }
        }

        /** Descarta o que ficou mais velho que a janela, sempre parando num quadro chave. */
        private fun trim() {
            var cut = -1L
            for (k in keyPts) if (k <= newest - windowUs) cut = k else break
            // trava de segurança de memória (bitrates altos): no máximo ~220 MB
            while (bytes > 220L * 1024 * 1024 && keyPts.size > 1) {
                keyPts.pollFirst()
                cut = keyPts.peekFirst() ?: cut
            }
            if (cut < 0) return
            while (keyPts.size > 1 && (keyPts.peekFirst() ?: Long.MAX_VALUE) < cut) keyPts.pollFirst()
            while (true) {
                val f = samples.peekFirst() ?: break
                if (f.pts >= cut) break
                samples.pollFirst()
                bytes -= f.data.size
            }
        }

        class Snapshot(val formats: List<MediaFormat>, val samples: List<Sample>, val basePts: Long, val endPts: Long)

        /** Cópia do que está guardado, começando no primeiro quadro chave. Null se ainda não há vídeo. */
        @Synchronized
        fun snapshot(): Snapshot? {
            val base = keyPts.peekFirst() ?: return null
            val list = ArrayList<Sample>(samples.size)
            for (x in samples) if (x.pts >= base) list.add(x)
            if (list.isEmpty()) return null
            return Snapshot(ArrayList(formats), list, base, newest)
        }
    }

    // ---- saída (arquivo) ----
    private class Output(
        val muxer: MediaMuxer,
        val uri: Uri?,
        val file: File?,
        val pfd: ParcelFileDescriptor?
    )

    /** Junta as trilhas e só inicia o muxer quando todas estiverem prontas. */
    private class Mux(val muxer: MediaMuxer, val expected: Int) : Sink {
        private var added = 0
        private var started = false
        private val lock = Object()
        private var failed = false

        /** Chamado uma vez se escrever no arquivo falhar (ex.: armazenamento cheio). */
        @Volatile
        var onError: (() -> Unit)? = null

        override fun addTrack(f: MediaFormat): Int = synchronized(lock) {
            val idx = muxer.addTrack(f)
            added++
            if (added == expected) {
                muxer.start()
                started = true
                lock.notifyAll()
            }
            idx
        }

        override fun write(idx: Int, buf: java.nio.ByteBuffer, info: MediaCodec.BufferInfo): Unit = synchronized(lock) {
            if (!started) {
                // espera a outra trilha ficar pronta; se ela não vier em 3 s, segue só com as que existem
                val end = System.currentTimeMillis() + 3000
                while (!started && System.currentTimeMillis() < end) {
                    try {
                        lock.wait(200)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
                if (!started && added > 0) {
                    try {
                        muxer.start()
                        started = true
                    } catch (e: Exception) {
                    }
                }
            }
            if (started) {
                try {
                    muxer.writeSampleData(idx, buf, info)
                } catch (e: Exception) {
                    if (!failed) {
                        failed = true
                        onError?.invoke()
                    }
                }
            }
        }

        val isStarted: Boolean get() = synchronized(lock) { started }
    }

    /** Buffer circular de PCM 16-bit estéreo (1 s). Se encher, descarta o mais antigo. */
    private class Ring(private val cap: Int) {
        private val a = ShortArray(cap)
        private var r = 0
        private var w = 0
        private var size = 0

        @Synchronized
        fun put(src: ShortArray, n: Int) {
            for (i in 0 until n) {
                if (size == cap) {
                    r = (r + 1) % cap
                    size--
                }
                a[w] = src[i]
                w = (w + 1) % cap
                size++
            }
        }

        @Synchronized
        fun trim(max: Int) {
            while (size > max) {
                r = (r + 1) % cap
                size--
            }
        }

        /** Lê até n amostras; o que faltar vira silêncio. */
        @Synchronized
        fun read(dst: ShortArray, n: Int) {
            val k = minOf(n, size)
            for (i in 0 until k) {
                dst[i] = a[r]
                r = (r + 1) % cap
                size--
            }
            for (i in k until n) dst[i] = 0
        }
    }

    private val RATE = 44100
    private val CHUNK = 1024 // quadros por bloco de áudio (~23 ms)

    @Volatile
    private var audioRun = false
    private var micRec: AudioRecord? = null
    private var intRec: AudioRecord? = null
    private var micRing: Ring? = null
    private var intRing: Ring? = null
    private var audioEnc: MediaCodec? = null
    private var audioThread: Thread? = null
    private var readers = ArrayList<Thread>()

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var out: Output? = null
    private var mux: Mux? = null
    private var replay: ReplayBuffer? = null

    @Volatile
    private var saving = false
    private var drain: Thread? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundNow() // sempre: startForegroundService exige isso em até 5 s
                if (recording || stopping) {
                    if (stopping) toast("Aguarde a gravação anterior terminar de salvar")
                    return START_NOT_STICKY
                }
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                if (data == null || !begin(code, data)) {
                    cleanup(deleteFile = true)
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            ACTION_STOP -> finish()
            ACTION_SAVE -> saveReplayAsync()
            else -> if (!recording) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        if (recording) finish()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notificação

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Gravador de tela", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val replayOn = getSharedPreferences("win", MODE_PRIVATE).getBoolean("rec_replay", false)
        val nb = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_record)
            .setContentTitle("WinLauncher")
            .setContentText(if (replayOn) "Replay ligado: Alt + Q salva os últimos $REPLAY_SECONDS s" else "Gravando a tela")
            .setOngoing(true)
            .setUsesChronometer(true) // cronômetro rodando na própria notificação
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
        if (replayOn) {
            val savePi = PendingIntent.getService(
                this, 3, Intent(this, ScreenRecordService::class.java).setAction(ACTION_SAVE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            nb.addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_record), "Salvar $REPLAY_SECONDS s", savePi).build())
        }
        nb.addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_record_stop), "Parar", stopPi).build())
        val n = nb.build()
        if (Build.VERSION.SDK_INT >= 29) {
            var type = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 && hasAudioPermission() && (wantMic() || wantInternal())) {
                type = type or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIF_ID, n, type)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------------ áudio

    private fun hasAudioPermission() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun wantMic() = getSharedPreferences("win", MODE_PRIVATE).getBoolean("rec_mic", true)
    private fun wantInternal() = getSharedPreferences("win", MODE_PRIVATE).getBoolean("rec_int", true)

    /** Prepara microfone e/ou áudio interno e o codificador AAC. Retorna true se há alguma fonte de áudio. */
    private fun setupAudio(proj: MediaProjection): Boolean {
        if (!hasAudioPermission()) return false
        val bufBytes = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            .coerceAtLeast(CHUNK * 4) * 2
        if (wantMic()) {
            try {
                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufBytes
                )
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    micRec = r
                    micRing = Ring(RATE * 2)
                } else r.release()
            } catch (e: Exception) {
            }
        }
        if (wantInternal() && Build.VERSION.SDK_INT >= 29) {
            try {
                val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val r = AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(cfg)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufBytes)
                    .build()
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    intRec = r
                    intRing = Ring(RATE * 2)
                } else r.release()
            } catch (e: Exception) {
            }
        }
        if (micRec == null && intRec == null) return false
        val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 2)
        af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        af.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, CHUNK * 4)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        audioEnc = enc
        return true
    }

    /** Lê uma fonte de áudio e guarda no buffer circular (microfone mono vira estéreo). */
    private fun readLoop(rec: AudioRecord, ring: Ring, mono: Boolean) {
        try {
            rec.startRecording()
            val buf = ShortArray(2048)
            val st = ShortArray(4096)
            while (audioRun) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                if (mono) {
                    for (i in 0 until n) {
                        st[i * 2] = buf[i]
                        st[i * 2 + 1] = buf[i]
                    }
                    ring.put(st, n * 2)
                } else ring.put(buf, n)
            }
        } catch (e: Exception) {
        }
    }

    /** Mistura as fontes, codifica em AAC e escreve no MP4, num ritmo fixo de relógio. */
    private fun audioLoop(enc: MediaCodec, m: Sink, t0Us: Long) {
        val n = CHUNK * 2
        val mic = ShortArray(n)
        val sys = ShortArray(n)
        val bytes = ByteArray(n * 2)
        val info = MediaCodec.BufferInfo()
        val startNs = System.nanoTime()
        val startUs = startNs / 1000 - t0Us
        var frames = 0L
        var track = -1
        var eosSent = false
        var done = false
        try {
            while (!done) {
                if (!eosSent) {
                    val target = startNs + (frames + CHUNK) * 1_000_000_000L / RATE
                    var wait = (target - System.nanoTime()) / 1_000_000
                    while (wait > 0 && audioRun) {
                        Thread.sleep(minOf(wait, 20L))
                        wait = (target - System.nanoTime()) / 1_000_000
                    }
                    val idx = enc.dequeueInputBuffer(10_000)
                    if (idx >= 0) {
                        micRing?.let { it.trim(n * 3); it.read(mic, n) } ?: java.util.Arrays.fill(mic, 0.toShort())
                        intRing?.let { it.trim(n * 3); it.read(sys, n) } ?: java.util.Arrays.fill(sys, 0.toShort())
                        if (micMuted) java.util.Arrays.fill(mic, 0.toShort())
                        if (sysMuted) java.util.Arrays.fill(sys, 0.toShort())
                        for (i in 0 until n) {
                            val v = (mic[i] + sys[i]).coerceIn(-32768, 32767)
                            bytes[i * 2] = (v and 0xFF).toByte()
                            bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
                        }
                        val ib = enc.getInputBuffer(idx)!!
                        ib.clear()
                        ib.put(bytes)
                        val last = !audioRun
                        enc.queueInputBuffer(idx, 0, bytes.size, startUs + frames * 1_000_000L / RATE,
                            if (last) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0)
                        frames += CHUNK
                        if (last) eosSent = true
                    }
                }
                while (true) {
                    val o = enc.dequeueOutputBuffer(info, if (eosSent) 10_000 else 0)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = m.addTrack(enc.outputFormat)
                    } else if (o >= 0) {
                        val ob = enc.getOutputBuffer(o)
                        val config = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                        if (ob != null && info.size > 0 && !config && track >= 0) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            m.write(track, ob, info)
                        }
                        enc.releaseOutputBuffer(o, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            done = true
                            break
                        }
                    } else if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ início

    private fun screenSize(maxSide: Int): IntArray {
        var w: Int
        var h: Int
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            w = b.width()
            h = b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            w = m.widthPixels
            h = m.heightPixels
        }
        // limita o lado maior mantendo a proporção; tamanhos pares (exigência do H.264)
        val scale = minOf(1f, maxSide.toFloat() / maxOf(w, h))
        w = ((w * scale).toInt() / 2) * 2
        h = ((h * scale).toInt() / 2) * 2
        return intArrayOf(w.coerceAtLeast(2), h.coerceAtLeast(2))
    }

    private fun openOutput(): Output {
        val name = "WinLauncher_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/WinLauncher")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("MediaStore recusou o arquivo")
            val pfd = contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("não abriu o arquivo")
            return Output(MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), uri, null, pfd)
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "WinLauncher")
        dir.mkdirs()
        val f = File(dir, name)
        return Output(MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), null, f, null)
    }

    private fun begin(code: Int, data: Intent): Boolean {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data) ?: return false
            projection = proj
            // obrigatório no Android 14+: registrar antes de criar o display virtual
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { if (recording) finish() }
                }
            }, main)

            val replayOn = getSharedPreferences("win", MODE_PRIVATE).getBoolean("rec_replay", false)
            // pouco espaço livre: avisa antes de começar (no replay só importa na hora de salvar)
            try {
                val st = android.os.StatFs(Environment.getExternalStorageDirectory().path)
                if (!replayOn && st.availableBytes < 300L * 1024 * 1024) {
                    toast("Pouco espaço livre no armazenamento (menos de 300 MB). Libere espaço para gravar.")
                    return false
                }
            } catch (e: Exception) {
            }
            // a gravação pega a tela PRINCIPAL do aparelho; o Android não deixa gravar o monitor externo
            val sp0 = getSharedPreferences("win", MODE_PRIVATE)
            if (sp0.getInt("ov_display", Display.DEFAULT_DISPLAY) != Display.DEFAULT_DISPLAY) {
                toast("Atenção: só a tela do aparelho é gravada, não o monitor externo")
            }

            // qualidade escolhida no menu do gravador: resolução máxima (lado maior) e quadros por segundo
            val maxSide = when (sp0.getInt("rec_res", 1)) {
                0 -> 1280 // 720p
                2 -> 2560 // 1440p
                else -> 1920 // 1080p
            }
            val wantBitrate = sp0.getInt("rec_br", 0) * 1_000_000 // 0 = automático
            val wantFps = if (sp0.getInt("rec_fps", 30) >= 60) 60 else 30
            // se o aparelho não aguentar, tenta de novo em 1280 e 30 fps
            var w = 0
            var h = 0
            var enc: MediaCodec? = null
            for (attempt in 0..1) {
                val sz = screenSize(if (attempt == 0) maxSide else minOf(maxSide, 1280))
                w = sz[0]
                h = sz[1]
                val fps = if (attempt == 0) wantFps else 30
                try {
                    val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
                    fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    val autoBr = (w.toLong() * h * fps / 10).toInt().coerceIn(3_000_000, 40_000_000)
                    // 2ª tentativa (o aparelho recusou): volta ao automático
                    fmt.setInteger(MediaFormat.KEY_BIT_RATE, if (attempt == 0 && wantBitrate > 0) wantBitrate else autoBr)
                    fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                    fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                    // tela parada continua gerando quadros (senão o vídeo "congela" e o tempo some)
                    fmt.setLong("repeat-previous-frame-after", 1_000_000L / fps)
                    val e0 = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                    try {
                        e0.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                        inputSurface = e0.createInputSurface()
                        e0.start()
                    } catch (e: Exception) {
                        try {
                            e0.release()
                        } catch (x: Exception) {
                        }
                        throw e
                    }
                    enc = e0
                    break
                } catch (e: Exception) {
                    try {
                        inputSurface?.release()
                    } catch (x: Exception) {
                    }
                    inputSurface = null
                    if (attempt == 1) throw e
                }
            }
            val venc = enc ?: return false
            encoder = venc

            val hasAudio = setupAudio(proj)
            micActive = micRec != null
            sysActive = intRec != null
            micMuted = false
            sysMuted = false
            val m: Sink
            if (replayOn) {
                val rb = ReplayBuffer(REPLAY_SECONDS * 1_000_000L)
                replay = rb
                m = rb
            } else {
                val o = openOutput()
                out = o
                val fm = Mux(o.muxer, if (hasAudio) 2 else 1) // vídeo + (áudio mixado)
                fm.onError = {
                    main.post {
                        if (recording) {
                            toast("Erro ao gravar o arquivo (armazenamento cheio?). Gravação encerrada")
                            finish()
                        }
                    }
                }
                mux = fm
                m = fm
            }
            val t0Us = System.nanoTime() / 1000

            display = proj.createVirtualDisplay(
                "WinLauncherRec", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null
            )

            stopping = false
            drain = Thread { drainVideo(venc, m, t0Us) }.also { it.name = "rec-video"; it.start() }
            if (hasAudio) {
                audioRun = true
                readers = ArrayList()
                micRec?.let { r -> micRing?.let { g -> readers.add(Thread { readLoop(r, g, true) }.also { it.name = "rec-mic"; it.start() }) } }
                intRec?.let { r -> intRing?.let { g -> readers.add(Thread { readLoop(r, g, false) }.also { it.name = "rec-sys"; it.start() }) } }
                val ae = audioEnc!!
                audioThread = Thread { audioLoop(ae, m, t0Us) }.also { it.name = "rec-audio"; it.start() }
            } else if (hasAudioPermission().not() && (wantMic() || wantInternal())) {
                toast("Sem permissão de áudio: gravando só o vídeo")
            }

            startedAtMs = System.currentTimeMillis()
            replayMode = replayOn
            recording = true
            onState?.invoke()
            if (replayOn) toast("Replay ligado: Alt + Q salva os últimos $REPLAY_SECONDS s")
            return true
        } catch (e: Exception) {
            toast("Não foi possível gravar: " + e.javaClass.simpleName + " " + (e.message ?: ""))
            return false
        }
    }

    private fun drainVideo(enc: MediaCodec, m: Sink, t0Us: Long) {
        val info = MediaCodec.BufferInfo()
        var track = -1
        var firstPts = -1L
        var offsetUs = 0L
        try {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> track = m.addTrack(enc.outputFormat)
                    i >= 0 -> {
                        val buf = enc.getOutputBuffer(i)
                        val config = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                        if (buf != null && info.size > 0 && !config && track >= 0) {
                            if (firstPts < 0) {
                                firstPts = info.presentationTimeUs
                                offsetUs = (System.nanoTime() / 1000 - t0Us).coerceAtLeast(0) // alinha com o áudio
                            }
                            info.presentationTimeUs = offsetUs + (info.presentationTimeUs - firstPts)
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            m.write(track, buf, info)
                        }
                        enc.releaseOutputBuffer(i, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ fim

    private fun finish() {
        if (stopping) return
        stopping = true
        recording = false
        onState?.invoke()
        Thread {
            try {
                encoder?.signalEndOfInputStream()
            } catch (e: Exception) {
            }
            audioRun = false
            try {
                audioThread?.join(4000)
            } catch (e: Exception) {
            }
            try {
                drain?.join(4000)
            } catch (e: Exception) {
            }
            for (t in readers) {
                try {
                    t.join(1000)
                } catch (e: Exception) {
                }
            }
            val wasReplay = replayMode
            val ok = cleanup(deleteFile = false)
            main.post {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                if (wasReplay) toast("Replay desligado")
                else toast(if (ok) "Gravação salva em Filmes/WinLauncher" else "A gravação ficou vazia e foi descartada")
            }
        }.start()
    }

    // ------------------------------------------------------------------ replay: salvar os últimos 30 s

    fun saveReplayAsync() {
        val rb = replay
        if (rb == null || !recording) return
        if (saving) {
            toast("Já está salvando o replay…")
            return
        }
        saving = true
        Thread {
            try {
                val snap = rb.snapshot()
                if (snap == null) {
                    toast("Ainda não há nada no replay. Aguarde alguns segundos")
                    return@Thread
                }
                try {
                    val st = android.os.StatFs(Environment.getExternalStorageDirectory().path)
                    if (st.availableBytes < 200L * 1024 * 1024) {
                        toast("Pouco espaço livre no armazenamento. Libere espaço para salvar o replay")
                        return@Thread
                    }
                } catch (e: Exception) {
                }
                val o = openOutput()
                var ok = false
                try {
                    val map = IntArray(snap.formats.size)
                    for (i in snap.formats.indices) map[i] = o.muxer.addTrack(snap.formats[i])
                    o.muxer.start()
                    val bi = MediaCodec.BufferInfo()
                    for (x in snap.samples) {
                        bi.set(0, x.data.size, x.pts - snap.basePts, x.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME)
                        o.muxer.writeSampleData(map[x.track], java.nio.ByteBuffer.wrap(x.data), bi)
                    }
                    o.muxer.stop()
                    ok = true
                } catch (e: Exception) {
                }
                try {
                    o.muxer.release()
                } catch (e: Exception) {
                }
                try {
                    o.pfd?.close()
                } catch (e: Exception) {
                }
                if (ok) {
                    if (o.uri != null) {
                        try {
                            contentResolver.update(o.uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                        } catch (e: Exception) {
                        }
                    } else if (o.file != null) {
                        MediaScannerConnection.scanFile(this, arrayOf(o.file.absolutePath), arrayOf("video/mp4"), null)
                    }
                    val secs = ((snap.endPts - snap.basePts) / 1_000_000L).toInt()
                    toast("Replay salvo (últimos $secs s) em Filmes/WinLauncher")
                } else {
                    try {
                        if (o.uri != null) contentResolver.delete(o.uri, null, null) else o.file?.delete()
                    } catch (e: Exception) {
                    }
                    toast("Não foi possível salvar o replay")
                }
            } catch (e: Exception) {
                toast("Não foi possível salvar o replay")
            } finally {
                saving = false
            }
        }.also { it.name = "rec-replay-save" }.start()
    }

    /** Libera tudo. Retorna true se o arquivo ficou válido. */
    private fun cleanup(deleteFile: Boolean): Boolean {
        var ok = !deleteFile && (mux?.isStarted == true)
        audioRun = false
        micActive = false
        sysActive = false
        for (r in listOf(micRec, intRec)) {
            try {
                r?.stop()
            } catch (e: Exception) {
            }
            try {
                r?.release()
            } catch (e: Exception) {
            }
        }
        micRec = null
        intRec = null
        micRing = null
        intRing = null
        try {
            audioEnc?.stop()
        } catch (e: Exception) {
        }
        try {
            audioEnc?.release()
        } catch (e: Exception) {
        }
        audioEnc = null
        audioThread = null
        readers = ArrayList()
        try {
            display?.release()
        } catch (e: Exception) {
        }
        display = null
        try {
            encoder?.stop()
        } catch (e: Exception) {
        }
        try {
            encoder?.release()
        } catch (e: Exception) {
        }
        encoder = null
        try {
            inputSurface?.release()
        } catch (e: Exception) {
        }
        inputSurface = null
        val o = out
        if (o != null) {
            try {
                if (mux?.isStarted == true) o.muxer.stop()
            } catch (e: Exception) {
                ok = false
            }
            try {
                o.muxer.release()
            } catch (e: Exception) {
            }
            try {
                o.pfd?.close()
            } catch (e: Exception) {
            }
            if (ok) {
                if (o.uri != null) {
                    try {
                        val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                        contentResolver.update(o.uri, v, null, null)
                    } catch (e: Exception) {
                    }
                } else if (o.file != null) {
                    MediaScannerConnection.scanFile(this, arrayOf(o.file.absolutePath), arrayOf("video/mp4"), null)
                }
            } else {
                try {
                    if (o.uri != null) contentResolver.delete(o.uri, null, null) else o.file?.delete()
                } catch (e: Exception) {
                }
            }
        }
        out = null
        mux = null
        replay = null
        replayMode = false
        try {
            projection?.stop()
        } catch (e: Exception) {
        }
        projection = null
        return ok
    }

    private fun toast(msg: String) {
        main.post {
            try {
                MiniToast.info(applicationContext, msg)
            } catch (e: Exception) {
            }
        }
    }
}
