package com.example.winlauncher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Player de música da tela de bloqueio: capa, "música • artista" e os botões voltar / pausar / avançar.
 *
 * - Lê a mídia que estiver tocando no aparelho (MediaSession) usando o mesmo acesso às notificações que o
 *   launcher já usa. Sem esse acesso, o próprio player pede a permissão ao toque.
 * - Fundo em degradê com as cores da capa, sobre o vidro fosco (desfoque real do papel de parede + granulado).
 * - Segurar o player por um instante e arrastar move ele pela tela; o [LockCustomizer] cuida de impedir que ele
 *   fique por cima do relógio, da previsão ou de qualquer outro elemento.
 * - Só escuta o sistema enquanto está visível (tela de bloqueio aberta e player adicionado).
 */
class MusicWidget(ctx: Context) : FrameLayout(ctx) {

    interface DragCb {
        fun onStart()
        fun onMove(dx: Float, dy: Float)
        fun onEnd()
    }

    /** Quem move o player (o [LockCustomizer]). */
    var drag: DragCb? = null

    companion object {
        private val DEF1 = Color.parseColor("#4A7396")
        private val DEF2 = Color.parseColor("#26384F")

        /** O launcher tem acesso às notificações (necessário para enxergar as sessões de mídia)? */
        fun hasAccess(ctx: Context): Boolean {
            val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
                ?: return false
            return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
        }

        fun openAccessSettings(ctx: Context) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
        }
    }

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d + 0.5f).toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val listener = ComponentName(ctx, LauncherNotificationListener::class.java)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private val glass = MusicGlass(this, d)
    private val cover = ImageView(ctx)
    private val title = TextView(ctx)
    private val btnPrev = ImageView(ctx)
    private val btnPlay = ImageView(ctx)
    private val btnNext = ImageView(ctx)

    init {
        isClickable = true // engole o toque (e conta como "ocupado" para a saída da tela de bloqueio)
        tag = CursorController.NOHAND
        background = glass
        elevation = dp(8).toFloat()
        val radius = dp(20).toFloat()
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, radius)
                o.alpha = 0.55f
            }
        }
        clipToOutline = true

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(12), dp(14), dp(12))
        addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // capa (quadrado de cantos arredondados)
        cover.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(14).toFloat())
            }
        }
        cover.clipToOutline = true
        row.addView(cover, LinearLayout.LayoutParams(dp(62), dp(62)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        row.addView(col, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })

        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.isSingleLine = true
        title.ellipsize = TextUtils.TruncateAt.MARQUEE
        title.marqueeRepeatLimit = -1
        title.isSelected = true // o letreiro só anda com o texto "selecionado"
        title.gravity = Gravity.CENTER_HORIZONTAL
        title.setShadowLayer(dp(2).toFloat(), 0f, 1f, 0x40000000)
        col.addView(title, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        val controls = LinearLayout(ctx)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        col.addView(
            controls,
            LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
        )
        for ((iv, res) in listOf(
            btnPrev to R.drawable.ic_media_prev,
            btnPlay to R.drawable.ic_media_play,
            btnNext to R.drawable.ic_media_next
        )) {
            iv.setImageResource(res)
            iv.setColorFilter(Color.WHITE)
            iv.setPadding(dp(9), dp(7), dp(9), dp(7))
            iv.background = glassItemBg(d, 16)
            iv.isClickable = true
            controls.addView(iv, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        btnPrev.setOnClickListener { try { ctrl?.transportControls?.skipToPrevious() } catch (e: Exception) {} }
        btnNext.setOnClickListener { try { ctrl?.transportControls?.skipToNext() } catch (e: Exception) {} }
        btnPlay.setOnClickListener {
            val c = ctrl ?: return@setOnClickListener
            try {
                if (isPlaying(c)) c.transportControls.pause() else c.transportControls.play()
            } catch (e: Exception) {
            }
        }
        title.setOnClickListener { if (!access) openAccessSettings(context) }
    }

    // ------------------------------------------------------------------ tamanho

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val avail = MeasureSpec.getSize(widthMeasureSpec)
        val target = if (avail > 0) min(dp(300), avail - dp(32)) else dp(300)
        super.onMeasure(MeasureSpec.makeMeasureSpec(max(dp(220), target), MeasureSpec.EXACTLY), heightMeasureSpec)
    }

    // ------------------------------------------------------------------ sessões de mídia

    private var msm: MediaSessionManager? = null
    private var ctrl: MediaController? = null
    private var listening = false
    private var access = true

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list ?: emptyList())
    }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = render()
        override fun onPlaybackStateChanged(state: PlaybackState?) = render()
        override fun onSessionDestroyed() = refreshSessions()
    }

    private fun isPlaying(c: MediaController): Boolean {
        val s = c.playbackState?.state
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    fun start() {
        if (listening) return
        listening = true
        val m = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
        msm = m
        if (m == null) {
            access = false
            render()
            return
        }
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, listener, ui)
            access = true
            bind(m.getActiveSessions(listener))
        } catch (e: SecurityException) {
            access = false
            bind(emptyList())
        } catch (e: Exception) {
            bind(emptyList())
        }
    }

    fun stop() {
        if (!listening) return
        listening = false
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        try {
            ctrl?.unregisterCallback(cb)
        } catch (e: Exception) {
        }
        ctrl = null
    }

    private fun refreshSessions() {
        val m = msm ?: return
        try {
            bind(m.getActiveSessions(listener))
        } catch (e: Exception) {
            bind(emptyList())
        }
    }

    private fun bind(list: List<MediaController>) {
        val best = list.firstOrNull { isPlaying(it) }
            ?: list.firstOrNull { it.metadata != null }
            ?: list.firstOrNull()
        if (best?.sessionToken != ctrl?.sessionToken) {
            try {
                ctrl?.unregisterCallback(cb)
            } catch (e: Exception) {
            }
            ctrl = best
            try {
                best?.registerCallback(cb, ui)
            } catch (e: Exception) {
            }
        }
        render()
    }

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible) start() else stop()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ conteúdo

    private var artKey = "\u0000"
    private var artBmp: Bitmap? = null
    private var uriTried = ""

    private fun currentKey(): String {
        val c = ctrl ?: return ""
        val md = c.metadata ?: return ""
        return (md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" +
            (md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "") + "|" + c.packageName
    }

    private fun render() {
        val c = ctrl
        val md = c?.metadata
        val playing = c != null && isPlaying(c)

        when {
            !access -> {
                title.text = "Toque para permitir o acesso à música"
                title.isClickable = true
            }
            c == null || md == null -> {
                title.text = "Nenhuma música tocando"
                title.isClickable = false
            }
            else -> {
                title.isClickable = false
                val t = md.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: "Sem título"
                val a = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                title.text = if (a.isNullOrBlank()) t else "$t • $a"
            }
        }
        btnPlay.setImageResource(if (playing) R.drawable.ic_media_pause else R.drawable.ic_media_play)
        val on = c != null
        for (b in listOf(btnPrev, btnPlay, btnNext)) {
            b.alpha = if (on) 1f else 0.4f
            b.isEnabled = on
        }

        // capa
        if (md == null) {
            if (artKey != "") clearArt("")
            return
        }
        val key = currentKey()
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) {
            if (bmp !== artBmp) setArt(bmp, key)
        } else {
            if (key != artKey) clearArt(key)
            val uri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            if (uri != null && uri != uriTried) {
                uriTried = uri
                loadUri(uri, key)
            }
        }
    }

    private fun setArt(b: Bitmap, key: String) {
        artKey = key
        artBmp = b
        cover.setPadding(0, 0, 0, 0)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        cover.clearColorFilter()
        cover.background = null
        cover.setImageBitmap(b)
        animatePalette(AlbumPalette.pick(b))
    }

    private fun clearArt(key: String) {
        artKey = key
        artBmp = null
        uriTried = ""
        cover.setImageResource(R.drawable.ic_music_note)
        cover.scaleType = ImageView.ScaleType.FIT_CENTER
        cover.setPadding(dp(17), dp(17), dp(17), dp(17))
        cover.setColorFilter(Color.WHITE)
        cover.background = android.graphics.drawable.GradientDrawable().apply { setColor(0x26FFFFFF) }
        animatePalette(intArrayOf(DEF1, DEF2))
    }

    /** Capa que o app só informa por endereço (arquivo, content:// ou https): baixa em segundo plano. */
    private fun loadUri(uri: String, key: String) {
        Thread {
            val b = try {
                decodeUri(uri)
            } catch (t: Throwable) {
                null
            }
            if (b != null) ui.post { if (currentKey() == key) setArt(b, key) }
        }.start()
    }

    private fun decodeUri(uri: String): Bitmap? {
        val bytes: ByteArray = if (uri.startsWith("http://") || uri.startsWith("https://")) {
            val con = URL(uri).openConnection() as HttpURLConnection
            con.connectTimeout = 4000
            con.readTimeout = 4000
            try {
                con.inputStream.use { it.readBytes() }
            } finally {
                con.disconnect()
            }
        } else {
            context.contentResolver.openInputStream(Uri.parse(uri))?.use { it.readBytes() } ?: return null
        }
        if (bytes.size > 8 * 1024 * 1024) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 256 && o.outHeight / (sample * 2) >= 256) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    // ------------------------------------------------------------------ cores (degradê da capa)

    private var cur1 = DEF1
    private var cur2 = DEF2
    private var colorAnim: ValueAnimator? = null

    init {
        glass.setColors(cur1, cur2)
    }

    private fun animatePalette(p: IntArray) {
        colorAnim?.cancel()
        val f1 = cur1
        val f2 = cur2
        val ev = ArgbEvaluator()
        colorAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450L
            addUpdateListener {
                val f = it.animatedFraction
                cur1 = ev.evaluate(f, f1, p[0]) as Int
                cur2 = ev.evaluate(f, f2, p[1]) as Int
                glass.setColors(cur1, cur2)
            }
            start()
        }
    }

    // ------------------------------------------------------------------ vidro fosco (fundo borrado)

    private var capHost: View? = null
    private var capForce = false
    private var capTries = 0
    private var lastCap = ""

    private val capRun = Runnable {
        val host = capHost ?: return@Runnable
        if (!isShown || width <= 0 || host.width <= 0) {
            // ainda sem tamanho (a tela de bloqueio está abrindo): tenta de novo algumas vezes
            if (capTries++ < 6) ui.postDelayed(this.capRunRef(), 120L)
            return@Runnable
        }
        val key = host.width.toString() + "x" + host.height
        if (!capForce && key == lastCap) return@Runnable
        lastCap = key
        val a = alpha
        alpha = 0f // o player não entra na própria captura (o fundo fica livre onde ele estiver)
        val b = captureBlurredBackdrop(host)
        alpha = a
        glass.setBlur(b)
    }

    private fun capRunRef(): Runnable = capRun

    /** Recaptura o papel de parede borrado atrás do player (ao abrir, ao trocar o fundo, ao girar a tela). */
    fun requestBackdropRefresh(host: View, force: Boolean = false, delayMs: Long = 100L) {
        capHost = host
        capForce = capForce || force
        capTries = 0
        ui.removeCallbacks(capRun)
        ui.postDelayed(capRun, delayMs)
    }

    // ------------------------------------------------------------------ arrastar segurando

    private var downRawX = 0f
    private var downRawY = 0f
    private var dragging = false
    private var lpPending = false

    private val lpRun = Runnable {
        lpPending = false
        dragging = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        cancelChildren() // não deixa o toque virar clique em um botão
        animate().scaleX(1.04f).scaleY(1.04f).setDuration(120L).start()
        drag?.onStart()
    }

    private fun cancelChildren() {
        val now = SystemClock.uptimeMillis()
        val c = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, 0f, 0f, 0)
        super.dispatchTouchEvent(c)
        c.recycle()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = ev.rawX
                downRawY = ev.rawY
                dragging = false
                lpPending = true
                ui.postDelayed(lpRun, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    drag?.onMove(ev.rawX - downRawX, ev.rawY - downRawY)
                    return true
                }
                if (lpPending && (abs(ev.rawX - downRawX) > slop || abs(ev.rawY - downRawY) > slop)) {
                    lpPending = false
                    ui.removeCallbacks(lpRun)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                lpPending = false
                ui.removeCallbacks(lpRun)
                if (dragging) {
                    dragging = false
                    animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
                    drag?.onEnd()
                    return true
                }
            }
        }
        if (dragging) return true
        return super.dispatchTouchEvent(ev)
    }

    // por último de propósito: todas as propriedades acima já foram inicializadas
    init {
        clearArt("")
        render()
    }
}

/** Extrai duas cores da capa (as mais presentes e vivas) e escurece o suficiente para o texto branco ficar legível. */
internal object AlbumPalette {
    private val DEFAULT = intArrayOf(Color.parseColor("#4A7396"), Color.parseColor("#26384F"))

    private class Bin {
        var w = 0f
        var r = 0f
        var g = 0f
        var b = 0f
        fun color(): Int = Color.rgb((r / w).toInt().coerceIn(0, 255), (g / w).toInt().coerceIn(0, 255), (b / w).toInt().coerceIn(0, 255))
    }

    fun pick(src: Bitmap): IntArray {
        val s = try {
            Bitmap.createScaledBitmap(src, 24, 24, true)
        } catch (t: Throwable) {
            return DEFAULT
        }
        val bins = HashMap<Int, Bin>()
        val hsv = FloatArray(3)
        var total = 0f
        for (y in 0 until s.height) {
            for (x in 0 until s.width) {
                val c = s.getPixel(x, y)
                if (Color.alpha(c) < 100) continue
                Color.colorToHSV(c, hsv)
                var w = 1f + 4f * hsv[1] * hsv[2] // cores vivas pesam mais que cinzas
                if (hsv[2] < 0.12f) w *= 0.15f
                else if (hsv[1] < 0.10f && hsv[2] > 0.9f) w *= 0.25f
                val key = ((hsv[0] / 24f).toInt() % 15) * 100 +
                    min(2, (hsv[1] * 3f).toInt()) * 10 + min(2, (hsv[2] * 3f).toInt())
                val bin = bins.getOrPut(key) { Bin() }
                bin.w += w
                bin.r += Color.red(c) * w
                bin.g += Color.green(c) * w
                bin.b += Color.blue(c) * w
                total += w
            }
        }
        if (s !== src) s.recycle()
        if (bins.isEmpty() || total <= 0f) return DEFAULT

        val sorted = bins.values.sortedByDescending { it.w }
        val c1 = sorted[0].color()
        val h1 = FloatArray(3)
        Color.colorToHSV(c1, h1)
        var c2 = 0
        var found = false
        val h2 = FloatArray(3)
        for (b in sorted.drop(1)) {
            if (b.w < total * 0.05f) break
            val c = b.color()
            Color.colorToHSV(c, h2)
            var dh = abs(h2[0] - h1[0])
            if (dh > 180f) dh = 360f - dh
            val colorful = h1[1] > 0.15f && h2[1] > 0.15f
            if ((colorful && dh >= 28f) || abs(h2[2] - h1[2]) >= 0.25f) {
                c2 = c
                found = true
                break
            }
        }
        if (!found) {
            // sem segunda cor distinta: deriva uma do mesmo tom (levemente deslocada e mais escura)
            val d = floatArrayOf((h1[0] + 28f) % 360f, h1[1] * 0.9f, h1[2] * 0.65f)
            c2 = Color.HSVToColor(d)
        }
        return intArrayOf(tone(c1), tone(c2))
    }

    /** Mantém brilho entre 30% e 60% para o texto e os ícones brancos continuarem legíveis. */
    private fun tone(c: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[2] = hsv[2].coerceIn(0.30f, 0.60f)
        if (hsv[1] > 0.85f) hsv[1] = 0.85f
        return Color.HSVToColor(hsv)
    }
}

/**
 * Fundo do player: papel de parede borrado (na posição certa atrás do player) + degradê com as cores da capa
 * + película fosca (granulado e brilho no topo) + borda fina.
 */
internal class MusicGlass(private val view: View, private val density: Float) : Drawable() {
    private var blur: Bitmap? = null
    private var c1 = Color.parseColor("#4A7396")
    private var c2 = Color.parseColor("#26384F")

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val tint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frost = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14FFFFFF") }
    private val grain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = BitmapShader(noise(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density
        color = Color.parseColor("#55FFFFFF")
    }
    private val clip = Path()
    private val rect = RectF()
    private val dst = Rect()
    private val radius get() = 20f * density

    private fun noise(): Bitmap {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val rnd = java.util.Random(7)
        val px = IntArray(s * s) { (rnd.nextInt(16) shl 24) or 0xFFFFFF }
        bmp.setPixels(px, 0, s, 0, 0, s, s)
        return bmp
    }

    fun setBlur(b: Bitmap?) {
        blur = b
        rebuild()
        invalidateSelf()
    }

    fun setColors(a: Int, b: Int) {
        c1 = a
        c2 = b
        rebuild()
        invalidateSelf()
    }

    private fun withAlpha(c: Int, a: Int) = (a shl 24) or (c and 0xFFFFFF)

    private fun rebuild() {
        val b = bounds
        if (b.isEmpty) return
        // com o vidro borrado por baixo o degradê pode ser mais transparente; sem ele, mais fechado
        val a = if (blur != null) 0xB4 else 0xE4
        tint.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            withAlpha(c1, a), withAlpha(c2, a), Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
            Color.parseColor("#33FFFFFF"), Color.parseColor("#05FFFFFF"), Shader.TileMode.CLAMP
        )
    }

    override fun onBoundsChange(b: Rect) {
        rebuild()
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        val save = canvas.save()
        canvas.clipPath(clip)
        val bmp = blur
        val host = view.parent as? View
        if (bmp != null && !bmp.isRecycled && host != null && host.width > 0) {
            val s2 = canvas.save()
            canvas.translate(-(view.left + view.translationX), -(view.top + view.translationY))
            dst.set(0, 0, host.width, host.height)
            canvas.drawBitmap(bmp, null, dst, bmpPaint)
            canvas.restoreToCount(s2)
        }
        canvas.drawPaint(tint)
        canvas.drawPaint(frost)
        canvas.drawPaint(grain)
        canvas.drawPaint(sheen)
        canvas.restoreToCount(save)
        val inset = border.strokeWidth / 2f
        rect.inset(inset, inset)
        canvas.drawRoundRect(rect, radius - inset, radius - inset, border)
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, radius)
        outline.alpha = 0.55f
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
