package com.example.winlauncher

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.ConcurrentHashMap

/**
 * Painel de personalização da tela de bloqueio: janela flutuante de vidro, independente dos elementos existentes.
 *
 * O que ele faz (nada disso altera o interior do relógio nem do cartão da previsão):
 *  - Adicionar / remover o relógio (com a data) e a previsão do tempo da tela: só liga e desliga a visibilidade
 *    do contêiner de cada um. Os dois começam "adicionados", então nada muda até o usuário mexer.
 *  - Mover o relógio e a previsão pela tela: arrasta-se o contêiner (translationX/Y), sempre dentro da tela.
 *    A posição é guardada como fração da tela, então sobrevive a rotação e a outras resoluções.
 *  - Trocar a fonte do relógio: fontes do sistema ou as fontes importadas já existentes ([FontStore]).
 *  - Papel de parede: galeria própria do launcher (estáticos, animados e arquivos importados). Vale SÓ para esta
 *    tela de bloqueio; não usa WallpaperManager nem muda o papel de parede/tela de bloqueio do Android.
 *
 * Tudo é salvo em SharedPreferences (lockClockOn, lockWxOn, lockClockDx/Dy, lockWxDx/Dy, lockClockFont).
 * A janela vive dentro da tela de bloqueio ([lock]) e engole os toques: a tela de bloqueio nunca fecha por baixo dela.
 */
class LockCustomizer(
    private val lock: FrameLayout,
    private val prefs: SharedPreferences,
    private val clockBlock: View,
    private val weatherBlock: View,
    /** Aplica a fonte ao relógio; null = fonte original. */
    private val applyClockFont: (Typeface?) -> Unit,
    /** Abre a janelinha de cidade ao lado do ícone da previsão. */
    private val openCityWindow: () -> Unit,
    /** Escolha salva e arquivos importados do papel de parede desta tela de bloqueio. */
    private val store: LockWallpaperStore,
    /** Fundo da tela de bloqueio: recebe a escolha da galeria. */
    private val wallpaperView: LockWallpaperView,
    /** Abre o seletor de arquivos para importar imagem/GIF/vídeo. */
    private val onImportWallpaper: () -> Unit
) {
    enum class Target { CLOCK, WEATHER }

    private companion object {
        const val K_CLOCK_ON = "lockClockOn"
        const val K_WX_ON = "lockWxOn"
        const val K_CLOCK_DX = "lockClockDx"
        const val K_CLOCK_DY = "lockClockDy"
        const val K_WX_DX = "lockWxDx"
        const val K_WX_DY = "lockWxDy"
        const val K_FONT = "lockClockFont"
    }

    private val ctx = lock.context
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density + 0.5f).toInt()

    private val white = Color.WHITE
    private val subtle = Color.parseColor("#B3FFFFFF")
    private val accent = Color.parseColor("#60CDFF")

    private enum class Page { MAIN, WALLPAPER }

    private var layer: Layer? = null
    private var moving: Target? = null
    private var page = Page.MAIN
    private var bodyScroll: ScrollView? = null
    private val thumbCache = ConcurrentHashMap<String, Bitmap>()

    private lateinit var body: LinearLayout
    private lateinit var hint: TextView

    val isShowing: Boolean get() = layer != null

    // ------------------------------------------------------------------ estado salvo e aplicação na tela

    private fun isOn(t: Target) = prefs.getBoolean(if (t == Target.CLOCK) K_CLOCK_ON else K_WX_ON, true)
    private fun block(t: Target) = if (t == Target.CLOCK) clockBlock else weatherBlock
    private fun keyDx(t: Target) = if (t == Target.CLOCK) K_CLOCK_DX else K_WX_DX
    private fun keyDy(t: Target) = if (t == Target.CLOCK) K_CLOCK_DY else K_WX_DY

    /** Aplica tudo o que está salvo (visibilidade, fonte e posições). Chamado ao criar a tela de bloqueio. */
    fun applyAll() {
        applyVisibility()
        applyFont()
        applyPositions()
    }

    private fun applyVisibility() {
        clockBlock.visibility = if (isOn(Target.CLOCK)) View.VISIBLE else View.GONE
        weatherBlock.visibility = if (isOn(Target.WEATHER)) View.VISIBLE else View.GONE
    }

    private fun applyFont() {
        applyClockFont(typefaceFor(prefs.getString(K_FONT, "") ?: ""))
    }

    /** Reaplica as posições salvas, mantendo cada bloco dentro da tela. Chamado a cada layout da tela de bloqueio. */
    fun applyPositions() {
        for (t in Target.values()) {
            val v = block(t)
            if (v.visibility != View.VISIBLE || v.width <= 0 || lock.width <= 0 || lock.height <= 0) continue
            val tx = prefs.getFloat(keyDx(t), 0f) * lock.width
            val ty = prefs.getFloat(keyDy(t), 0f) * lock.height
            v.translationX = clampX(v, tx)
            v.translationY = clampY(v, ty)
        }
    }

    private fun clampX(v: View, tx: Float): Float {
        val lo = -v.left.toFloat()
        return tx.coerceIn(lo, maxOf(lo, (lock.width - v.left - v.width).toFloat()))
    }

    private fun clampY(v: View, ty: Float): Float {
        val lo = -v.top.toFloat()
        return ty.coerceIn(lo, maxOf(lo, (lock.height - v.top - v.height).toFloat()))
    }

    private fun savePosition(t: Target) {
        val v = block(t)
        if (lock.width <= 0 || lock.height <= 0) return
        prefs.edit()
            .putFloat(keyDx(t), v.translationX / lock.width)
            .putFloat(keyDy(t), v.translationY / lock.height)
            .apply()
    }

    private fun resetPositions() {
        prefs.edit().remove(K_CLOCK_DX).remove(K_CLOCK_DY).remove(K_WX_DX).remove(K_WX_DY).apply()
        clockBlock.translationX = 0f
        clockBlock.translationY = 0f
        weatherBlock.translationX = 0f
        weatherBlock.translationY = 0f
        layer?.invalidate()
    }

    // ------------------------------------------------------------------ fontes

    private class FontOpt(val key: String, val label: String, val tf: Typeface)

    private fun typefaceFor(key: String): Typeface? = when {
        key.startsWith("sys:") -> Typeface.create(key.removePrefix("sys:"), Typeface.NORMAL)
        key.startsWith("file:") -> FontStore.typeface(ctx, key.removePrefix("file:")) // null se o arquivo sumiu
        else -> null
    }

    private fun fontOptions(): List<FontOpt> {
        val out = ArrayList<FontOpt>()
        out.add(FontOpt("", "Padrão", Typeface.create("sans-serif-light", Typeface.NORMAL)))
        val sys = listOf(
            "sans-serif" to "Sans-serif", "sans-serif-thin" to "Fina", "sans-serif-medium" to "Média",
            "sans-serif-black" to "Pesada", "sans-serif-condensed" to "Condensada", "serif" to "Serifada",
            "monospace" to "Monoespaçada", "casual" to "Casual", "cursive" to "Cursiva"
        )
        for ((fam, label) in sys) out.add(FontOpt("sys:$fam", label, Typeface.create(fam, Typeface.NORMAL)))
        try {
            for (e in FontStore.list(ctx)) {
                val tf = FontStore.typeface(ctx, e.file) ?: continue
                out.add(FontOpt("file:${e.file}", e.name, tf))
            }
        } catch (e: Exception) {
        }
        return out
    }

    // ------------------------------------------------------------------ abrir / fechar

    /** Abre o painel. Com [startMove], já entra no modo de mover aquele elemento. */
    fun show(startMove: Target? = null, wallpaper: Boolean = false) {
        val existing = layer
        if (existing != null) {
            if (wallpaper) {
                page = Page.WALLPAPER
                moving = null
            } else {
                page = Page.MAIN
                moving = if (startMove != null && isOn(startMove)) startMove else moving
            }
            renderBody()
            existing.invalidate()
            return
        }
        if (lock.width <= 0 || lock.height <= 0) return
        val blur = captureBlurredBackdrop(lock) // antes de adicionar a janela
        val card = buildCard(blur)
        val l = Layer(card)
        l.addView(card)
        layer = l
        page = if (wallpaper) Page.WALLPAPER else Page.MAIN
        moving = if (!wallpaper && startMove != null && isOn(startMove)) startMove else null
        lock.addView(l, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        renderBody()
        card.alpha = 0f
        card.scaleX = 0.96f
        card.scaleY = 0.96f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
    }

    /** Fecha o painel (e o modo mover). Retorna true se ele estava aberto. */
    fun dismiss(): Boolean {
        val l = layer ?: return false
        layer = null
        moving = null
        page = Page.MAIN
        l.removeCallbacks(refreshBackdropRun)
        thumbCache.clear()
        l.card.animate().cancel()
        lock.removeView(l)
        (l.card.background as? BackdropGlass)?.release()
        return true
    }

    // ------------------------------------------------------------------ camada: posição da janela e arrasto dos elementos

    private inner class Layer(val card: View) : FrameLayout(ctx) {
        private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            color = accent
            pathEffect = DashPathEffect(floatArrayOf(dp(8).toFloat(), dp(6).toFloat()), 0f)
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1A60CDFF") }
        private val r = RectF()

        private var dragging = false
        private var startX = 0f
        private var startY = 0f
        private var startTx = 0f
        private var startTy = 0f

        init {
            isClickable = true
            tag = CursorController.NOHAND
            setWillNotDraw(false)
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = View.MeasureSpec.getSize(widthMeasureSpec)
            val h = View.MeasureSpec.getSize(heightMeasureSpec)
            setMeasuredDimension(w, h)
            val m = dp(12)
            card.measure(
                View.MeasureSpec.makeMeasureSpec(minOf(dp(360), w - 2 * m), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxOf(0, h - 2 * m), View.MeasureSpec.AT_MOST)
            )
        }

        override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
            val w = r - l
            val h = b - t
            val m = dp(12)
            val cw = card.measuredWidth
            val ch = card.measuredHeight
            // posição inicial: lado direito, centralizada na vertical (o relógio e o clima ficam à esquerda)
            val x = (w - cw - dp(24)).coerceIn(m, maxOf(m, w - cw - m))
            val y = ((h - ch) / 2).coerceIn(m, maxOf(m, h - ch - m))
            card.layout(x, y, x + cw, y + ch)
            // o arrasto pelo título nunca deixa a janela sair da tela (nem depois de girar/redimensionar)
            val loX = (m - x).toFloat()
            val loY = (m - y).toFloat()
            card.translationX = card.translationX.coerceIn(loX, maxOf(loX, (w - m - cw - x).toFloat()))
            card.translationY = card.translationY.coerceIn(loY, maxOf(loY, (h - m - ch - y).toFloat()))
        }

        /** Contorno tracejado em volta do elemento que está sendo movido. */
        override fun onDraw(canvas: Canvas) {
            val t = moving ?: return
            val v = block(t)
            if (v.visibility != View.VISIBLE) return
            val pad = dp(8).toFloat()
            r.set(
                v.left + v.translationX - pad, v.top + v.translationY - pad,
                v.left + v.translationX + v.width + pad, v.top + v.translationY + v.height + pad
            )
            canvas.drawRoundRect(r, dp(14).toFloat(), dp(14).toFloat(), fill)
            canvas.drawRoundRect(r, dp(14).toFloat(), dp(14).toFloat(), dash)
        }

        /** Só chega aqui o que a janela não consumiu (toques fora dela). */
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            val t = moving
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (t == null) {
                        // clique fora do painel fecha só o painel (no próximo ciclo, para não remover a camada durante o toque)
                        post { if (layer === this) dismiss() }
                    } else {
                        val v = block(t)
                        val pad = dp(12)
                        val hit = ev.x >= v.left + v.translationX - pad && ev.x <= v.left + v.translationX + v.width + pad &&
                            ev.y >= v.top + v.translationY - pad && ev.y <= v.top + v.translationY + v.height + pad
                        if (hit && v.visibility == View.VISIBLE) {
                            dragging = true
                            startX = ev.x
                            startY = ev.y
                            startTx = v.translationX
                            startTy = v.translationY
                        }
                    }
                }
                MotionEvent.ACTION_MOVE -> if (dragging && t != null) {
                    val v = block(t)
                    v.translationX = clampX(v, startTx + (ev.x - startX))
                    v.translationY = clampY(v, startTy + (ev.y - startY))
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                    dragging = false
                    if (t != null) savePosition(t)
                }
            }
            return true // engole tudo: nada chega à tela de bloqueio (que sairia ao clicar em área vazia)
        }
    }

    // ------------------------------------------------------------------ construção da janela

    private fun text(size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(ctx).apply {
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun itemBg(radiusDp: Int, base: Int = Color.TRANSPARENT, stroke: Int = 0): Drawable =
        glassItemBg(density, radiusDp, base, stroke)

    private fun buildCard(blur: android.graphics.Bitmap?): View {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(12), dp(16), dp(14))
        card.isClickable = true // engole cliques dentro da janela
        card.tag = CursorController.NOHAND
        card.elevation = dp(16).toFloat()
        val radius = dp(20).toFloat()
        card.background = BackdropGlass(card, lock, blur, radius, density)
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
                outline.alpha = 0.6f
            }
        }
        card.clipToOutline = true

        // barra de título: também é a alça para arrastar a janela
        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(0, dp(4), 0, dp(10))
        val grip = text(16f, subtle)
        grip.text = "⠿"
        bar.addView(grip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        val title = text(17f, bold = true)
        title.text = "Personalizar tela de bloqueio"
        title.maxLines = 1
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        var gx = 0f
        var gy = 0f
        var sx = 0f
        var sy = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gx = ev.rawX; gy = ev.rawY; sx = card.translationX; sy = card.translationY
                }
                MotionEvent.ACTION_MOVE -> {
                    val m = dp(12)
                    val loX = (m - card.left).toFloat()
                    val loY = (m - card.top).toFloat()
                    card.translationX = (sx + ev.rawX - gx)
                        .coerceIn(loX, maxOf(loX, (lock.width - m - card.width - card.left).toFloat()))
                    card.translationY = (sy + ev.rawY - gy)
                        .coerceIn(loY, maxOf(loY, (lock.height - m - card.height - card.top).toFloat()))
                    card.invalidate() // o desfoque de fundo depende da posição
                }
            }
            true
        }
        card.addView(bar, LinearLayout.LayoutParams(-1, -2))

        hint = text(12.5f, accent)
        hint.visibility = View.GONE
        card.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        body = LinearLayout(ctx)
        body.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(ctx)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(body, FrameLayout.LayoutParams(-1, -2))
        bodyScroll = scroll
        card.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        card.addView(
            pill("Fechar", strong = true) { dismiss() },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        )
        return card
    }

    private fun pill(label: String, strong: Boolean = false, enabled: Boolean = true, click: () -> Unit): TextView {
        val t = text(13.5f, bold = true)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(9), dp(14), dp(9))
        t.background = itemBg(
            18,
            base = Color.parseColor(if (strong) "#33FFFFFF" else "#1FFFFFFF"),
            stroke = Color.parseColor(if (strong) "#8060CDFF" else "#33FFFFFF")
        )
        if (enabled) {
            t.isClickable = true
            t.setOnClickListener { click() }
        } else {
            t.alpha = 0.4f
        }
        return t
    }

    private fun section(label: String): TextView {
        val t = text(11f, subtle, bold = true)
        t.text = label
        t.letterSpacing = 0.1f
        t.setPadding(dp(2), dp(14), 0, dp(6))
        return t
    }

    /** Linha "nome + situação" com o botão Adicionar/Remover à direita. */
    private fun toggleRow(t: Target, name: String, addLabel: String): View {
        val on = isOn(t)
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(8), dp(8), dp(8))
        row.background = itemBg(12, base = Color.parseColor("#14FFFFFF"))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val n = text(14.5f, bold = true)
        n.text = name
        val s = text(12f, if (on) accent else subtle)
        s.text = if (on) "● Na tela" else "○ Fora da tela"
        col.addView(n)
        col.addView(s, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(pill(if (on) "Remover" else addLabel, strong = !on) { toggle(t) }, LinearLayout.LayoutParams(-2, -2))
        return row
    }

    private fun toggle(t: Target) {
        val now = !isOn(t)
        prefs.edit().putBoolean(if (t == Target.CLOCK) K_CLOCK_ON else K_WX_ON, now).apply()
        if (!now && moving == t) moving = null
        applyVisibility()
        lock.requestLayout() // ao reaparecer, applyPositions() roda no próximo layout
        renderBody()
        layer?.invalidate()
    }

    private fun moveButton(t: Target, label: String): View {
        val active = moving == t
        return pill(if (active) "Concluir movimento" else label, strong = active, enabled = isOn(t)) {
            moving = if (moving == t) null else t
            renderBody()
            layer?.invalidate()
        }
    }

    private fun fontList(): View {
        val cur = prefs.getString(K_FONT, "") ?: ""
        val curValid = cur.isEmpty() || typefaceFor(cur) != null
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        for (f in fontOptions()) {
            val selected = if (curValid) f.key == cur else f.key.isEmpty()
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(7), dp(12), dp(7))
            row.background = if (selected) itemBg(10, base = Color.parseColor("#2EFFFFFF"), stroke = Color.parseColor("#9960CDFF"))
            else itemBg(10)
            val sample = text(20f)
            sample.text = "12:34"
            sample.typeface = f.tf
            row.addView(sample, LinearLayout.LayoutParams(dp(84), -2))
            val name = text(13f, subtle)
            name.text = f.label
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            if (selected) {
                val ck = text(14f, accent, bold = true)
                ck.text = "✓"
                row.addView(ck, LinearLayout.LayoutParams(-2, -2))
            }
            row.isClickable = true
            row.setOnClickListener {
                prefs.edit().putString(K_FONT, f.key).apply()
                applyFont()
                lock.requestLayout()
                renderBody()
                layer?.invalidate()
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(list, FrameLayout.LayoutParams(-1, -2))
        // a lista rola por dentro do painel que também rola: o painel não "rouba" o gesto
        sv.setOnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) v.parent.requestDisallowInterceptTouchEvent(true)
            false
        }
        val box = FrameLayout(ctx)
        box.addView(sv, FrameLayout.LayoutParams(-1, dp(176)))
        return box
    }

    // ------------------------------------------------------------------ papel de parede (galeria própria)

    private fun wallpaperLabel(): String = when (val s = store.selection()) {
        is WpSel.Default -> "Padrão"
        is WpSel.Preset -> s.preset.name + (if (s.preset.animated) " · animado" else "")
        is WpSel.Imported -> s.file.name + (if (s.file.isVideo) " · vídeo" else "")
    }

    private fun openWallpaperPage() {
        page = Page.WALLPAPER
        moving = null
        renderBody()
        layer?.invalidate()
    }

    /** Linha "Papel de parede" do painel: mostra o que está aplicado e abre a galeria. */
    private fun wallpaperRow(): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(8), dp(8), dp(8))
        row.background = itemBg(12, base = Color.parseColor("#14FFFFFF"))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val n = text(14.5f, bold = true)
        n.text = "Papel de parede"
        val s = text(12f, accent)
        s.text = wallpaperLabel()
        s.maxLines = 1
        s.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(n)
        col.addView(s, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(pill("Escolher", strong = true) { openWallpaperPage() }, LinearLayout.LayoutParams(-2, -2))
        row.isClickable = true
        row.setOnClickListener { openWallpaperPage() }
        return row
    }

    /** Aplica a escolha como fundo da tela de bloqueio (transição suave) e salva. */
    private fun choose(sel: WpSel) {
        if (store.currentKey() == store.key(sel)) return
        store.select(sel)
        wallpaperView.setWallpaper(sel, true)
        renderKeepScroll()
        scheduleBackdropRefresh()
    }

    private fun deleteImported(e: WpFile) {
        val wasSelected = store.currentKey() == "file:" + e.id
        store.remove(e)
        thumbCache.remove("f:" + e.id)
        if (wasSelected) wallpaperView.setWallpaper(WpSel.Default, true)
        renderKeepScroll()
        if (wasSelected) scheduleBackdropRefresh()
    }

    /** Redesenha o corpo sem voltar ao topo da lista. */
    private fun renderKeepScroll() {
        val sv = bodyScroll
        val y = sv?.scrollY ?: 0
        renderBody()
        sv?.post { sv.scrollTo(0, y) }
    }

    /** O vidro do painel mostra o fundo borrado de quando abriu; depois da troca de papel de parede, atualiza. */
    private val refreshBackdropRun = Runnable {
        val l = layer ?: return@Runnable
        val bg = l.card.background as? BackdropGlass ?: return@Runnable
        l.visibility = View.INVISIBLE // não captura o próprio painel
        val nb = captureBlurredBackdrop(lock)
        l.visibility = View.VISIBLE
        bg.update(nb)
    }

    private fun scheduleBackdropRefresh() {
        val l = layer ?: return
        l.removeCallbacks(refreshBackdropRun)
        l.postDelayed(refreshBackdropRun, 480L) // depois do crossfade (400 ms)
    }

    private fun presetThumb(p: WpPreset): Bitmap =
        thumbCache.getOrPut("p:" + p.id) { WpPresets.thumb(p, dp(120), dp(72)) }

    /** Miniatura de arquivo importado: decodificada em segundo plano (primeiro quadro salvo na importação). */
    private fun loadFileThumb(e: WpFile, iv: ImageView) {
        val key = "f:" + e.id
        val hit = thumbCache[key]
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setBackgroundColor(Color.parseColor("#22FFFFFF"))
        val w = dp(160)
        val h = dp(96)
        Thread {
            val b = store.thumbnail(e, w, h)
            if (b != null) {
                thumbCache[key] = b
                iv.post { iv.setImageBitmap(b) }
            }
        }.start()
    }

    private fun renderWallpaperPage() {
        val sel = store.currentKey()
        fun add(v: View, top: Int = 0) = body.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(pill("‹ Voltar") {
            page = Page.MAIN
            renderBody()
        }, LinearLayout.LayoutParams(-2, -2))
        val ttl = text(15f, bold = true)
        ttl.text = "Papel de parede"
        head.addView(ttl, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        add(head)

        // estáticos (o primeiro é o padrão da tela de bloqueio)
        add(section("ESTÁTICOS"))
        val statics = ArrayList<View>()
        statics.add(
            tile(
                label = "Padrão", selected = sel == "", badge = null,
                thumb = { iv ->
                    iv.setImageDrawable(
                        GradientDrawable(
                            GradientDrawable.Orientation.TOP_BOTTOM,
                            intArrayOf(Color.parseColor("#1B2B45"), Color.parseColor("#34506E"))
                        )
                    )
                },
                onClick = { choose(WpSel.Default) }
            )
        )
        for (p in WpPresets.statics) {
            statics.add(
                tile(
                    label = p.name, selected = sel == "preset:" + p.id, badge = null,
                    thumb = { iv -> iv.setImageBitmap(presetThumb(p)) },
                    onClick = { choose(WpSel.Preset(p)) }
                )
            )
        }
        add(grid(statics))

        // animados
        add(section("ANIMADOS"))
        val animated = ArrayList<View>()
        for (p in WpPresets.animated) {
            animated.add(
                tile(
                    label = p.name, selected = sel == "preset:" + p.id, badge = "▶ ANIMADO",
                    thumb = { iv -> iv.setImageBitmap(presetThumb(p)) },
                    onClick = { choose(WpSel.Preset(p)) }
                )
            )
        }
        add(grid(animated))

        // arquivos do usuário (imagem, GIF e vídeo em loop)
        add(section("MEUS ARQUIVOS"))
        val mine = ArrayList<View>()
        for (e in store.library()) {
            mine.add(
                tile(
                    label = e.name, selected = sel == "file:" + e.id,
                    badge = when {
                        e.isVideo -> "▶ VÍDEO"
                        e.ext == "gif" -> "▶ GIF"
                        else -> null
                    },
                    thumb = { iv -> loadFileThumb(e, iv) },
                    onClick = { choose(WpSel.Imported(e)) },
                    onDelete = { deleteImported(e) }
                )
            )
        }
        mine.add(importTile())
        add(grid(mine))

        val note = text(11.5f, subtle)
        note.text = "Vale só para a tela de bloqueio do WinLauncher. Vídeos tocam em loop, sem som."
        add(note, 10)
    }

    /** Quadradinho da galeria: miniatura, nome, selo (animado/vídeo), marca de selecionado e, se houver, botão de remover. */
    private fun tile(
        label: String,
        selected: Boolean,
        badge: String?,
        thumb: (ImageView) -> Unit,
        onClick: () -> Unit,
        onDelete: (() -> Unit)? = null
    ): View {
        val r = dp(12).toFloat()
        val t = FrameLayout(ctx)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        t.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        t.clipToOutline = true

        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb(iv)
        t.addView(iv, FrameLayout.LayoutParams(-1, -1))

        val lab = text(12f, bold = true)
        lab.text = label
        lab.maxLines = 1
        lab.ellipsize = android.text.TextUtils.TruncateAt.END
        lab.setPadding(dp(8), dp(16), dp(26), dp(6))
        lab.background = GradientDrawable(
            GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(Color.parseColor("#B3000000"), Color.TRANSPARENT)
        )
        t.addView(lab, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        if (badge != null) {
            val b = text(10f, bold = true)
            b.text = badge
            b.setPadding(dp(6), dp(2), dp(6), dp(2))
            b.background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#80000000"))
            }
            t.addView(
                b,
                FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(6), dp(6), 0, 0) }
            )
        }
        if (selected) {
            val ck = text(15f, accent, bold = true)
            ck.text = "✓"
            ck.setPadding(0, 0, dp(8), dp(6))
            t.addView(ck, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        }
        if (onDelete != null) {
            val del = text(11f, bold = true)
            del.text = "✕"
            del.gravity = Gravity.CENTER
            del.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#99000000"))
            }
            del.isClickable = true
            del.setOnClickListener { onDelete() }
            t.addView(
                del,
                FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.END).apply {
                    setMargins(0, dp(6), dp(6), 0)
                }
            )
        }
        t.foreground = GradientDrawable().apply {
            cornerRadius = r
            setColor(Color.TRANSPARENT)
            setStroke(
                dp(if (selected) 2 else 1),
                Color.parseColor(if (selected) "#FF60CDFF" else "#33FFFFFF")
            )
        }
        return t
    }

    private fun importTile(): View {
        val t = LinearLayout(ctx)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#14FFFFFF"))
            setStroke(dp(1), Color.parseColor("#66FFFFFF"), dp(6).toFloat(), dp(4).toFloat())
        }
        val plus = text(24f, accent, bold = true)
        plus.text = "+"
        val lab = text(11.5f, subtle)
        lab.text = "Importar imagem,\nGIF ou vídeo"
        lab.gravity = Gravity.CENTER
        t.addView(plus)
        t.addView(lab, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        t.isClickable = true
        t.setOnClickListener { onImportWallpaper() }
        return t
    }

    /** Grade de 2 colunas. */
    private fun grid(views: List<View>): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < views.size) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val v = views.getOrNull(i + k)
                val lp = LinearLayout.LayoutParams(0, dp(92), 1f).apply {
                    setMargins(if (k == 0) 0 else dp(4), dp(4), if (k == 0) dp(4) else 0, dp(4))
                }
                if (v != null) row.addView(v, lp) else row.addView(View(ctx), lp)
            }
            col.addView(row, LinearLayout.LayoutParams(-1, -2))
            i += 2
        }
        return col
    }

    private fun renderBody() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        if (page == Page.WALLPAPER) {
            hint.visibility = View.GONE
            renderWallpaperPage()
            return
        }
        val m = moving
        hint.text = when (m) {
            Target.CLOCK -> "Arraste o relógio pela tela. Toque em “Concluir movimento” ao terminar."
            Target.WEATHER -> "Arraste a previsão do tempo pela tela. Toque em “Concluir movimento” ao terminar."
            null -> ""
        }
        hint.visibility = if (m == null) View.GONE else View.VISIBLE

        fun add(v: View, top: Int = 0) = body.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })

        body.addView(section("FUNDO").also { it.setPadding(dp(2), 0, 0, dp(6)) }, LinearLayout.LayoutParams(-1, -2))
        add(wallpaperRow())

        add(section("RELÓGIO"))
        add(toggleRow(Target.CLOCK, "Relógio e data", "Adicionar relógio"))
        add(moveButton(Target.CLOCK, "Mover relógio"), 8)
        add(text(12.5f, subtle).also { it.text = "Fonte do relógio"; it.setPadding(dp(2), 0, 0, 0) }, 12)
        add(fontList(), 6)

        add(section("PREVISÃO DO TEMPO"))
        add(toggleRow(Target.WEATHER, "Previsão do tempo", "Adicionar previsão"))
        add(moveButton(Target.WEATHER, "Mover previsão"), 8)
        add(pill("Escolher cidade…", enabled = isOn(Target.WEATHER)) { openCityWindow() }, 8)

        add(section("POSIÇÃO"))
        add(pill("Redefinir posições") { resetPositions() })
    }
}
