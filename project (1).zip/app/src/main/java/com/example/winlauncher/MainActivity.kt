package com.example.winlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.view.ViewOutlineProvider
import android.view.WindowManager
import java.io.File
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.app.Notification
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.media.MediaMetadataRetriever
import android.service.notification.StatusBarNotification
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.ScrollView
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppItem(val label: String, val icon: Drawable, val cn: ComponentName)

class Tile(
    val label: String,
    val icon: Int,
    val closes: Boolean,
    val active: () -> Boolean,
    val click: () -> Unit
) {
    var view: LinearLayout? = null
    var iconView: ImageView? = null
    var textView: TextView? = null
}

@Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
class MainActivity : Activity() {

    companion object {
        const val REQ_WP = 11
        const val REQ_LOC = 12
        const val REQ_AVATAR = 13
        const val REQ_FONT = 14
        const val REQ_LOCK_WP = 15
        const val REQ_WIFI = 16
        const val REQ_APP_ICON = 17
        const val REQ_APK = 18
        const val REQ_WEBICON = 20
        const val REQ_NOTIF_REMOTE = 21
        private const val PREF_REMOTE_NOTIF_ASKED = "remote_notif_asked"
        /** Chave da engrenagem na lista de apps fixados ("tb"): não é um app, não pode ser removida. */
        const val TB_GEAR = "__settings__"
        /** Chave do navegador na lista de fixados ("tb"): vem fixado por padrão, mas pode ser desafixado. */
        const val TB_BROWSER = "__browser__"
        /** Chave do gerenciador de arquivos na lista de fixados (\"tb\"): vem fixado por padrão, mas pode ser desafixado. */
        const val TB_FILES = "__files__"
        /** Chave da galeria de fotos na lista de fixados ("tb"): vem fixada por padrão, mas pode ser desafixada. */
        const val TB_GALLERY = "__gallery__"
        /** Chave do monitor de desempenho na lista de fixados (\"tb\"): só aparece se a pessoa fixar. */
        const val TB_PERF = "__perf__"
        /** Chave do reprodutor de música na lista de fixados ("tb"): só aparece se a pessoa fixar. */
        const val TB_MUSIC = "__music__"
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var prefs: SharedPreferences
    private val ptBR = Locale("pt", "BR")

    private var cPanel = Color.parseColor("#F2202020")
    private var cTaskbar = Color.parseColor("#E61C1C1C")
    private var cTile = Color.parseColor("#26FFFFFF")
    private var cAccent = Color.parseColor("#4CC2FF")
    private var cSub = Color.parseColor("#B3FFFFFF")
    private var cText = Color.WHITE
    private var cLine = Color.parseColor("#22FFFFFF")
    private var ripC = Color.parseColor("#44FFFFFF")
    private var light = false

    // ---- personalização (novo)
    private lateinit var cfg: Prefs
    lateinit var cursor: CursorController
    lateinit var menu: ContextMenuHost
    private lateinit var pcWindow: PcInfoWindow
    private lateinit var apkWindow: ApkInstallerWindow
    private lateinit var webInstaller: WebAppInstallerWindow

    /** Janelas dos apps por link (uma por app, sem abas nem barra de endereço), pela chave do componente. */
    private val webWins = LinkedHashMap<String, BrowserWindow>()
    private lateinit var browser: BrowserWindow
    private lateinit var files: FileManagerWindow
    private lateinit var gallery: GalleryWindow
    private lateinit var updater: UpdateChecker
    private lateinit var settingsWindow: SettingsWindow
    private lateinit var customize: CustomizeUi
    private lateinit var uiCol: LinearLayout
    private lateinit var tbRow: LinearLayout
    private lateinit var tbTray: LinearLayout
    private lateinit var tbClockView: TextClock
    private lateinit var tbBellPad: View
    private lateinit var tbSpacerL: View
    private lateinit var bellBtn: FrameLayout
    private lateinit var chevBtn: ImageView
    private lateinit var volPanel: LinearLayout
    private lateinit var infoPanel: LinearLayout
    private lateinit var infoIcon: ImageView
    private lateinit var infoText: TextView
    private var infoAnchor: View? = null
    private lateinit var volPopSeek: SeekBar
    private lateinit var volPopText: TextView
    private lateinit var bellIcon: ImageView
    private lateinit var bellBadge: TextView
    private lateinit var searchPill: LinearLayout
    private lateinit var tbWeather: TextView
    private lateinit var music: TaskbarMusic
    private lateinit var userInitial: TextView
    private lateinit var userPhoto: ImageView
    private lateinit var userNameView: TextView
    private lateinit var welcomeScreen: WelcomeScreen
    private val wxHandler = Handler(Looper.getMainLooper())
    private val wxTick = object : Runnable {
        override fun run() {
            refreshWeather(false)
            wxHandler.postDelayed(this, 10 * 60 * 1000L)
        }
    }
    private lateinit var pillIcon: ImageView
    private lateinit var pillText: TextView
    private lateinit var searchPanel: LinearLayout
    private lateinit var tbSearchBox: EditText
    private lateinit var tbResults: LinearLayout
    private var tbMatches: List<AppItem> = emptyList()
    private var tbSel = 0
    private lateinit var notifPanel: LinearLayout
    private lateinit var notifBody: LinearLayout
    private lateinit var notifScroll: ScrollView
    private lateinit var notifClear: TextView
    private var insTop = 0
    private var insBottom = 0

    private lateinit var root: FrameLayout
    private lateinit var wallpaperHost: FrameLayout

    /** Avisado quando o wallpaper muda (a tela Configurações > Wallpaper se atualiza). */
    var wallpaperChanged: (() -> Unit)? = null
    private lateinit var desktopFrame: DesktopFrame
    private lateinit var desktopGrid: FrameLayout
    private lateinit var desktopAdapter: AppAdapter

    // ---- widget de relógio e calendário
    lateinit var clock: ClockWidget

    /** Retângulo (x, y, largura, altura em dp) onde o widget está agora; null se oculto. */
    private var widgetRect: IntArray? = null

    /** Ação do usuário no widget (ativar, tamanho, fonte, soltar): grava a posição final depois de acomodar. */
    private var widgetCommit = false
    private lateinit var overlay: FrameLayout

    // tela de bloqueio interna (Parte 1: só estrutura e animações)
    private lateinit var lockScreen: LockScreen

    private lateinit var taskbar: FrameLayout
    private lateinit var pinnedRow: LinearLayout
    private lateinit var startBtn: ImageView
    private lateinit var wifiIcon: ImageView
    private lateinit var volIcon: ImageView
    private lateinit var batIcon: ImageView

    private lateinit var startPanel: LinearLayout
    /** Camada do Menu Iniciar: fica por cima de TODAS as janelas (nativas e de links), mas abaixo do menu de contexto. */
    private lateinit var startHost: FrameLayout
    /** Âncora usada pelas janelas: elas sempre entram logo abaixo da camada do Menu Iniciar. */
    private val winTop: View
        get() = if (::startHost.isInitialized && startHost.parent === root) startHost else menu.layer
    private lateinit var searchBox: EditText
    private lateinit var weatherChip: TextView
    private lateinit var weatherCard: LinearLayout
    private var weatherData: WeatherData? = null
    private var weatherOpen = false
    private var weatherLoading = false
    private lateinit var startGrid: GridView
    private lateinit var startAdapter: AppAdapter

    private lateinit var quickPanel: LinearLayout
    private lateinit var brightSeek: SeekBar
    private lateinit var quickMusic: QuickMusicCard
    private lateinit var taskView: TaskView
    private var swipeStartY = -1f
    private lateinit var musicWin: MusicPlayerWindow
    private lateinit var volSeek: SeekBar
    private lateinit var batText: TextView
    private val tiles = ArrayList<Tile>()

    private lateinit var calPanel: LinearLayout
    private lateinit var calDate: TextView
    private lateinit var calTitle: TextView
    private lateinit var calGrid: GridLayout
    private val calShown: Calendar = Calendar.getInstance()

    private var allApps: List<AppItem> = emptyList()
    private var video: VideoView? = null
    private var anim: AnimatedImageDrawable? = null
    private var torchOn = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps { onAppsLoaded() }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val screenW: Int
        get() = resources.displayMetrics.widthPixels

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun rip(color: Int, r: Int): RippleDrawable =
        RippleDrawable(
            ColorStateList.valueOf(ripC),
            rounded(color, r),
            rounded(Color.WHITE, r)
        )

    private fun panelW(): Int = minOf(dp(360), screenW - dp(16))

    fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun ic(a: AppItem): Drawable = a.icon.constantState?.newDrawable(resources) ?: a.icon

    private fun lpTop(m: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(m)
        return lp
    }

    private fun sectionLabel(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(cText)
        tv.textSize = 13f
        tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun iconBtn(res: Int, tint: Boolean = true, onClick: () -> Unit): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(res)
        if (tint) iv.setColorFilter(cText)
        iv.setPadding(dp(10), dp(10), dp(10), dp(10))
        iv.background = rip(Color.TRANSPARENT, 8)
        iv.setOnClickListener { onClick() }
        return iv
    }

    private fun getList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("|").filter { it.isNotEmpty() }

    private fun setList(k: String, l: List<String>) {
        prefs.edit().putString(k, l.joinToString("|")).apply()
    }

    private fun appFor(key: String): AppItem? =
        allApps.firstOrNull { it.cn.flattenToString() == key }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Não foi possível abrir")
        }
        closeAll()
    }

    private fun launch(cn: ComponentName) {
        if (WebApps.isWeb(cn)) {
            val e = WebApps.find(this, cn)
            if (e == null) {
                toast("Aplicativo não encontrado")
                return
            }
            closeAll()
            openWebApp(e)
            return
        }
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        i.component = cn
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        if (::cursor.isInitialized) cursor.setBusy(1500)
        safeStart(i)
    }

    // -------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("win", MODE_PRIVATE)
        cfg = Prefs(prefs)
        rememberScreenConfig(resources.configuration)
        loadTheme()
        cursor = CursorController(this, cfg)
        cursor.rebuild()

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        // Remove o quadrado translúcido de foco (Enter/Espaço/gamepad) de qualquer view que receber foco.
        window.decorView.viewTreeObserver.addOnGlobalFocusChangeListener { _, newFocus ->
            newFocus?.defaultFocusHighlightEnabled = false
        }

        buildUi()
        installBarLock()
        if (savedInstanceState == null) handleViewIntent(intent)
        if (savedInstanceState == null) updater.checkOnStart()
        ImmersiveController.apply(this)
        cursor.onFrame = {
            try {
                root.pointerIcon = if (cfg.cursorOn) {
                    if (cursor.busy) cursor.busyIcon() else cursor.arrow
                } else {
                    null
                }
            } catch (e: Exception) {
            }
        }
        applyCursorToRoot()
        applyWallpaper()

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addDataScheme("package")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, f)
        }

        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                    if (quickPanel.visibility == View.VISIBLE) refreshTiles()
                }
            }, null)
        } catch (e: Exception) {
        }

        loadApps { onAppsLoaded() }

        LauncherNotificationListener.onChange = { runOnUiThread { updateBell() } }
        ShizukuBridge.addListeners()
        val reopen = prefs.getInt("ui_reopen", -1)
        if (reopen >= 0) {
            prefs.edit().remove("ui_reopen").apply()
            reopenCustomize(reopen)
        }
        // WinLauncher Remote: só liga o servidor se o usuário ativou "Iniciar o servidor junto com o WinLauncher" (padrão: desligado)
        window.decorView.post { RemoteServerService.autoStartIfEnabled(this) }
    }

    override fun onResume() {
        super.onResume()
        // barra flutuante: some enquanto o launcher está na frente e guarda em qual tela ele está
        try {
            @Suppress("DEPRECATION")
            prefs.edit().putInt("ov_display", windowManager.defaultDisplay.displayId).apply()
        } catch (e: Exception) {
        }
        TaskbarOverlayService.launcherForeground = true
        TaskbarOverlayService.sync(this)
        VolumeButtonService.onLauncherForeground(true)
        if (::music.isInitialized) music.refreshAccess()
        VolumeButtonService.sync(this)
        FpsCounterService.sync(this)
        PerfOverlayService.onStateChanged = { runOnUiThread { rebuildTaskbar() } }
        PerfOverlayService.sync(this)
        refreshVolFloat()
        video?.let { if (!it.isPlaying) it.start() }
        anim?.start()
        updateTray()
        updateBell()
        ImmersiveController.apply(this)
        wxHandler.removeCallbacks(wxTick)
        wxHandler.post(wxTick)
        if (::clock.isInitialized) clock.start()
        if (::lockScreen.isInitialized) lockScreen.onHostResume()
        if (::files.isInitialized) files.onHostResume()
    }

    override fun onPause() {
        super.onPause()
        TaskbarOverlayService.launcherForeground = false
        TaskbarOverlayService.instance?.refresh()
        VolumeButtonService.onLauncherForeground(false)
        if (::clock.isInitialized) clock.stop()
        if (::lockScreen.isInitialized) lockScreen.settle() // não deixa animação pela metade ao sair
        wxHandler.removeCallbacks(wxTick)
        video?.pause()
        anim?.stop()
        if (::cursor.isInitialized) cursor.clearBusy()
    }

    private var lastBarApplyMs = 0L

    /** Com "Bloquear barras do Android" ligado, esconde as barras de novo no instante em que tentam aparecer. */
    @Suppress("DEPRECATION")
    private fun installBarLock() {
        val d = window.decorView
        d.setOnApplyWindowInsetsListener { v, insets ->
            if (cfg.lockBars) {
                val shown = if (Build.VERSION.SDK_INT >= 30) {
                    insets.isVisible(android.view.WindowInsets.Type.statusBars()) ||
                        insets.isVisible(android.view.WindowInsets.Type.navigationBars())
                } else {
                    true
                }
                if (shown) v.post { ImmersiveController.apply(this) }
            }
            v.onApplyWindowInsets(insets)
        }
        d.setOnSystemUiVisibilityChangeListener { vis ->
            if (cfg.lockBars && (vis and View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {
                d.post { ImmersiveController.apply(this) }
            }
        }
    }

    fun applyBarLock() {
        ImmersiveController.apply(this)
        toast(if (cfg.lockBars) "Barras do Android bloqueadas" else "Barras do Android liberadas")
    }

    private var lastOrientation = -1
    private var lastWidthDp = 0
    private var lastHeightDp = 0

    private fun rememberScreenConfig(c: android.content.res.Configuration) {
        lastOrientation = c.orientation
        lastWidthDp = c.screenWidthDp
        lastHeightDp = c.screenHeightDp
    }

    /**
     * Girou o celular (em pé <-> deitado) ou a janela mudou bastante de tamanho: refaz a interface inteira
     * com as medidas novas. Painéis, janelas, grade da área de trabalho e barra de tarefas são calculados
     * na criação; sem isso eles ficavam com o tamanho/posição da orientação anterior e saíam da tela.
     */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val changed = newConfig.orientation != lastOrientation ||
            Math.abs(newConfig.screenWidthDp - lastWidthDp) > 48 ||
            Math.abs(newConfig.screenHeightDp - lastHeightDp) > 48
        rememberScreenConfig(newConfig)
        if (changed) recreate()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        LauncherNotificationListener.onChange = null
        ShizukuBridge.onChange = null
        if (::music.isInitialized) music.stop()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeAll()
        handleViewIntent(intent)
        // app por link aberto pela barra de tarefas flutuante
        intent?.getStringExtra("open_webapp")?.let { k ->
            ComponentName.unflattenFromString(k)?.let { launch(it) }
        }
        // pedido vindo da barra de tarefas flutuante: abre o painel correspondente
        when (intent?.getStringExtra("open_panel")) {
            "start" -> openStart()
            "search" -> openSearch()
            "quick" -> showPanel(quickPanel)
            "cal" -> showPanel(calPanel)
            "notif" -> showPanel(notifPanel)
        }
    }

    /**
     * Algo aberto a partir de outro app (o WinLauncher aparece na lista "Abrir com" e pode ser o padrão):
     * link http/https -> navegador nativo; foto -> galeria; pasta -> gerenciador de arquivos; .apk -> instalador.
     */
    private fun handleViewIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        val type = (i.type ?: "").lowercase()
        val scheme = (uri.scheme ?: "").lowercase()
        when {
            scheme == "http" || scheme == "https" -> {
                if (::browser.isInitialized) {
                    closeAll()
                    browser.show(uri.toString())
                }
            }
            type == "application/vnd.android.package-archive" || uri.toString().lowercase().endsWith(".apk") -> {
                if (::apkWindow.isInitialized) apkWindow.openWith(uri)
            }
            type.startsWith("audio/") || MusicPlayerWindow.isAudioName(uri.lastPathSegment ?: "") -> openViewedAudio(uri)
            type.startsWith("image/") -> openViewedImage(uri)
            type == "resource/folder" || type == "vnd.android.document/directory" || type == "inode/directory" -> openViewedFolder(uri)
        }
    }

    /** Áudio aberto de fora (download, gerenciador de arquivos): toca no reprodutor da WinLauncher. */
    private fun openViewedAudio(uri: Uri) {
        val f = fileFromUri(uri) ?: try {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "audio"
            val out = File(cacheDir, "viewed_" + System.currentTimeMillis() + "_" + name)
            contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { input.copyTo(it) }
            }
            out
        } catch (e: Exception) {
            null
        }
        if (f != null && ::musicWin.isInitialized) {
            closeAll()
            musicWin.openFile(f)
        }
    }

    /** Tenta descobrir o caminho real de um arquivo/pasta a partir do endereço recebido. */
    private fun fileFromUri(uri: Uri): File? {
        try {
            if (uri.scheme == "file") return uri.path?.let { File(it) }
            val segs = uri.pathSegments
            if (uri.authority == FileShareProvider.authority(this) && segs != null && segs.size >= 2 && segs[0] == "files") {
                return File("/" + segs.drop(1).joinToString("/"))
            }
            if (uri.authority == "com.android.externalstorage.documents") {
                val id = if (android.provider.DocumentsContract.isTreeUri(uri)) {
                    android.provider.DocumentsContract.getTreeDocumentId(uri)
                } else {
                    android.provider.DocumentsContract.getDocumentId(uri)
                }
                if (id.startsWith("primary:")) {
                    return File(android.os.Environment.getExternalStorageDirectory(), id.removePrefix("primary:"))
                }
            }
        } catch (e: Exception) {
        }
        return null
    }

    private fun openViewedFolder(uri: Uri) {
        val f = fileFromUri(uri)
        if (f != null && f.isDirectory && ::files.isInitialized) {
            closeAll()
            files.show(f.absolutePath)
        } else if (::files.isInitialized) {
            closeAll()
            files.show()
        }
    }

    private fun openViewedImage(uri: Uri) {
        if (!::gallery.isInitialized) return
        val direct = fileFromUri(uri)
        if (direct != null && direct.isFile) {
            showViewedImage(direct)
            return
        }
        // foto vinda de outro app (content://): copia para o cache e abre
        Thread {
            val out = try {
                var name = "foto"
                contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0) ?: name
                }
                name = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (!name.contains('.')) name += ".jpg"
                val dir = File(cacheDir, "viewed")
                dir.mkdirs()
                dir.listFiles()?.forEach { old -> if (System.currentTimeMillis() - old.lastModified() > 3600_000L) old.delete() }
                val f = File(dir, name)
                contentResolver.openInputStream(uri)?.use { ins -> f.outputStream().use { o -> ins.copyTo(o) } }
                if (f.length() > 0) f else null
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (out != null) {
                    showViewedImage(out)
                } else {
                    Toast.makeText(this, "Não foi possível abrir a foto", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun showViewedImage(f: File) {
        val exts = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
        val sib = (f.parentFile?.listFiles() ?: emptyArray())
            .filter { it.isFile && it.extension.lowercase() in exts }
            .sortedBy { it.name.lowercase() }
        closeAll()
        gallery.openImage(f, if (sib.isEmpty()) listOf(f) else sib)
    }

    /**
     * "Definir como padrão". O navegador tem papel próprio no Android (pede direto); fotos e pastas não têm:
     * ao abrir algo em outro app, é só escolher o WinLauncher e tocar em "Sempre" (as Configurações abrem em Apps padrão).
     */
    /** Abre o painel com os apps nativos e o padrão de cada um. */
    fun openDefaultAppsPanel() {
        DefaultAppsPanel.show(root, this, light, { isBrowserDefault() }) { kind -> requestDefault(kind) }
    }

    private fun isBrowserDefault(): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            (getSystemService(Context.ROLE_SERVICE) as android.app.role.RoleManager)
                .isRoleHeld(android.app.role.RoleManager.ROLE_BROWSER)
        } catch (e: Exception) {
            false
        }
    }

    fun requestDefault(kind: String) {
        if (kind == "browser" && Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = getSystemService(Context.ROLE_SERVICE) as android.app.role.RoleManager
                if (rm.isRoleAvailable(android.app.role.RoleManager.ROLE_BROWSER)) {
                    if (rm.isRoleHeld(android.app.role.RoleManager.ROLE_BROWSER)) {
                        Toast.makeText(this, "O WinLauncher já é o navegador padrão", Toast.LENGTH_SHORT).show()
                    } else {
                        startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_BROWSER), 4711)
                    }
                    return
                }
            } catch (e: Exception) {
            }
        }
        if (kind != "browser") {
            val what = when (kind) {
                "gallery" -> "Abra uma foto"
                "apk" -> "Abra um arquivo .apk"
                "audio" -> "Abra uma música"
                else -> "Abra uma pasta"
            }
            Toast.makeText(
                this,
                "$what em outro app, escolha WinLauncher e toque em \"Sempre\"",
                Toast.LENGTH_LONG
            ).show()
        }
        safeStart(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (renameLayer != null) {
            hideRenameDialog()
            return
        }
        if (::lockScreen.isInitialized && lockScreen.isOpen) {
            if (::menu.isInitialized && menu.isShowing) menu.hide()
            else if (!lockScreen.closeOverlays()) lockScreen.requestHide() // saída provisória até a Parte 4
        } else if (::menu.isInitialized && menu.isShowing) {
            menu.hide()
        } else if (overlay.visibility == View.VISIBLE) {
            closeAll()
        } else if (::gallery.isInitialized && gallery.handleBack()) {
            // a galeria de fotos tratou o botão voltar
        } else if (::musicWin.isInitialized && musicWin.handleBack()) {
            // o reprodutor de música tratou o botão voltar
        } else if (::files.isInitialized && files.handleBack()) {
            // o gerenciador de arquivos tratou o botão voltar
        } else if (webWins.values.any { it.isOpen && !it.isMinimized && it.handleBack() }) {
            // um app por link tratou o botão voltar
        } else if (::browser.isInitialized) {
            browser.handleBack()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ImmersiveController.apply(this)
    }

    // ---- botão direito: o gesto inteiro pertence ao menu de contexto ----
    private var rightGesture = false
    private var lastRightMs = 0L

    private fun rightClickRecent(): Boolean =
        rightGesture || SystemClock.uptimeMillis() - lastRightMs < 450L

    // ---------------------------------------------------------------- toque com 2 dedos = botão direito
    private var tfActive = false
    private var tfSwallow = false
    private var tfMoved = false
    private var tfStartMs = 0L
    private val tfStart = FloatArray(4) // x0, y0, x1, y1 no momento em que o 2º dedo encosta

    /**
     * Toque rápido com 2 dedos (sem arrastar) vira um clique com o botão direito do mouse na posição do
     * 1º dedo. Arrastar com 2 dedos continua funcionando normalmente (rolagem etc.).
     * Retorna true quando o evento foi consumido aqui.
     */
    private fun handleTwoFingerTap(ev: MotionEvent): Boolean {
        if (::lockScreen.isInitialized && lockScreen.isOpen) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tfSwallow = false
                tfActive = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (tfSwallow) return true
                if (ev.pointerCount == 2) {
                    tfActive = true
                    tfMoved = false
                    tfStartMs = ev.eventTime
                    tfStart[0] = ev.getX(0)
                    tfStart[1] = ev.getY(0)
                    tfStart[2] = ev.getX(1)
                    tfStart[3] = ev.getY(1)
                } else {
                    tfActive = false
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (tfSwallow) return true
                if (tfActive && !tfMoved && ev.pointerCount >= 2) {
                    val lim = dp(16).toDouble()
                    if (Math.hypot((ev.getX(0) - tfStart[0]).toDouble(), (ev.getY(0) - tfStart[1]).toDouble()) > lim ||
                        Math.hypot((ev.getX(1) - tfStart[2]).toDouble(), (ev.getY(1) - tfStart[3]).toDouble()) > lim
                    ) tfMoved = true
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (tfSwallow) return true
                if (tfActive && !tfMoved && ev.pointerCount == 2 && ev.eventTime - tfStartMs <= 400L) {
                    tfActive = false
                    tfSwallow = true
                    fireRightClick(ev, tfStart[0], tfStart[1])
                    return true
                }
                tfActive = false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = tfSwallow
                tfSwallow = false
                tfActive = false
                if (was) return true
            }
        }
        return tfSwallow
    }

    /** Cancela o toque que as views já tinham começado e envia um clique direito de mouse sintético em (x, y). */
    private fun fireRightClick(ev: MotionEvent, x: Float, y: Float) {
        val c = MotionEvent.obtain(ev)
        c.action = MotionEvent.ACTION_CANCEL
        super.dispatchTouchEvent(c)
        c.recycle()

        val now = SystemClock.uptimeMillis()
        val props = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_MOUSE
        })
        val coords = arrayOf(MotionEvent.PointerCoords().apply {
            this.x = x
            this.y = y
            pressure = 1f
            size = 1f
        })
        val down = MotionEvent.obtain(
            now, now, MotionEvent.ACTION_DOWN, 1, props, coords,
            0, MotionEvent.BUTTON_SECONDARY, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0
        )
        dispatchTouchEvent(down)
        down.recycle()
        val up = MotionEvent.obtain(
            now, now + 10, MotionEvent.ACTION_UP, 1, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0
        )
        dispatchTouchEvent(up)
        up.recycle()
    }

    /** Janelas nativas da WinLauncher para a Visão de Tarefas (inclui os apps instalados por link). */
    private fun taskEntries(): List<TaskEntry> {
        val list = ArrayList<TaskEntry>()
        try {
            list.add(TaskEntry("Navegador", R.drawable.ic_browser, browser.layer, { browser.isOpen },
                { if (browser.isMinimized) browser.restore(); WindowStack.raise(root, browser.layer, winTop) },
                { browser.close() }, { w -> browser.snapshot(w) }))
            list.add(TaskEntry("Arquivos", R.drawable.ic_files, files.layer, { files.isOpen },
                { if (files.isMinimized) files.restore(); WindowStack.raise(root, files.layer, winTop) },
                { files.close() }, { w -> files.snapshot(w) }))
            list.add(TaskEntry("Galeria", R.drawable.ic_gallery, gallery.layer, { gallery.isOpen },
                { if (gallery.isMinimized) gallery.restore(); WindowStack.raise(root, gallery.layer, winTop) },
                { gallery.close() }, { w -> gallery.snapshot(w) }))
            list.add(TaskEntry("Configuração do PC", R.drawable.ic_pc, pcWindow.layer, { pcWindow.isOpen },
                { if (pcWindow.isMinimized) pcWindow.restore(); WindowStack.raise(root, pcWindow.layer, winTop) },
                { pcWindow.close() }, { w -> pcWindow.snapshot(w) }))
            list.add(TaskEntry("Configurações", R.drawable.ic_settings_color, settingsWindow.layer, { settingsWindow.isOpen },
                { if (settingsWindow.isMinimized) settingsWindow.restore(); WindowStack.raise(root, settingsWindow.layer, winTop) },
                { settingsWindow.close() }, { w -> settingsWindow.snapshot(w) }))
            list.add(TaskEntry("Instalar app web", R.drawable.ic_web_install, webInstaller.layer, { webInstaller.isOpen },
                { WindowStack.raise(root, webInstaller.layer, winTop) },
                { webInstaller.close() }))
            list.add(TaskEntry("Instalador de aplicativos", R.drawable.ic_install, apkWindow.layer, { apkWindow.isOpen },
                { WindowStack.raise(root, apkWindow.layer, winTop) },
                { apkWindow.close() }, { w -> apkWindow.snapshot(w) }))
            for ((k, w) in webWins) {
                val cn = ComponentName.unflattenFromString(k) ?: continue
                val name = WebApps.find(this, cn)?.let { AppCustom.label(this, it.cn, it.name) } ?: "App"
                list.add(TaskEntry(name, R.drawable.ic_browser, w.layer, { w.isOpen },
                    { if (w.isMinimized) w.restore(); WindowStack.raise(root, w.layer, winTop) },
                    { w.close() }, { sw -> w.snapshot(sw) }))
            }
            list.add(TaskEntry("Reprodutor de música", R.drawable.ic_music_app, musicWin.layer, { musicWin.isOpen },
                { if (musicWin.isMinimized) musicWin.restore(); WindowStack.raise(root, musicWin.layer, winTop) },
                { musicWin.close() }, { w -> musicWin.snapshot(w) }))
        } catch (e: UninitializedPropertyAccessException) {
        }
        return list
    }

    /** Janelas de apps (cada uma com a sua camada). */
    private fun windowLayers(): List<View> = try {
        listOf(
            browser.layer, files.layer, gallery.layer, pcWindow.layer,
            apkWindow.layer, webInstaller.layer, settingsWindow.layer, musicWin.layer
        ) + webWins.values.map { it.layer }
    } catch (e: UninitializedPropertyAccessException) {
        emptyList()
    }

    /** Traz para frente a janela que estiver embaixo do ponto (toque ou cursor). */
    private fun bringWindowAt(x: Int, y: Int) {
        if (!::menu.isInitialized) return
        var best: View? = null
        var bestIdx = -1
        for (l in windowLayers()) {
            val idx = root.indexOfChild(l)
            if (idx < 0 || l.visibility != View.VISIBLE || idx <= bestIdx) continue
            val group = l as? ViewGroup ?: continue
            var hit = false
            val r = android.graphics.Rect()
            for (i in 0 until group.childCount) {
                val c = group.getChildAt(i)
                if (c.visibility != View.VISIBLE) continue
                // a janela é movida com translationX/Y: getHitRect já considera essa posição
                c.getHitRect(r)
                if (r.contains(x, y)) {
                    hit = true
                    break
                }
            }
            if (hit) {
                best = l
                bestIdx = idx
            }
        }
        best?.let { WindowStack.raise(root, it, winTop) }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) bringWindowAt(ev.x.toInt(), ev.y.toInt())
        // deslizar de baixo para cima no centro da tela abre a Visão de Tarefas
        if (::taskView.isInitialized) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val h = resources.displayMetrics.heightPixels
                    val w = resources.displayMetrics.widthPixels
                    swipeStartY = if (ev.y > h - dp(120) && ev.x > w * 0.3f && ev.x < w * 0.7f && !taskView.taskShown) ev.y else -1f
                }
                MotionEvent.ACTION_UP -> {
                    val locked = ::lockScreen.isInitialized && lockScreen.isOpen
                    if (swipeStartY > 0f && swipeStartY - ev.y > dp(90) && !locked) taskView.show()
                    swipeStartY = -1f
                }
                MotionEvent.ACTION_CANCEL -> swipeStartY = -1f
            }
        }
        // deslizar a partir da borda: já esconde as barras do Android antes de elas terminarem de aparecer
        if (cfg.lockBars && (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_MOVE)) {
            val edge = dp(28)
            val dm = resources.displayMetrics
            if ((ev.rawY < edge || ev.rawY > dm.heightPixels - edge || ev.rawX < edge || ev.rawX > dm.widthPixels - edge) &&
                ev.eventTime - lastBarApplyMs > 120L
            ) {
                lastBarApplyMs = ev.eventTime
                window.decorView.post { ImmersiveController.apply(this) }
            }
        }
        if (ev.isFromSource(InputDevice.SOURCE_TOUCHSCREEN) && !ev.isFromSource(InputDevice.SOURCE_MOUSE) &&
            handleTwoFingerTap(ev)
        ) return true
        if (ev.isFromSource(InputDevice.SOURCE_MOUSE)) {
            val secondary = (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && secondary) {
                rightGesture = true
                lastRightMs = SystemClock.uptimeMillis()
                // só o DOWN chega às views (abre o menu); o resto do gesto é engolido
                super.dispatchTouchEvent(ev)
                return true
            }
            if (rightGesture) {
                lastRightMs = SystemClock.uptimeMillis()
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                    rightGesture = false
                }
                // CANCEL limpa qualquer estado "pressionado" sem gerar clique
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(c)
                c.recycle()
                return true
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_HOVER_MOVE || ev.actionMasked == MotionEvent.ACTION_BUTTON_PRESS) {
            bringWindowAt(ev.x.toInt(), ev.y.toInt())
        }
        if (ev.isFromSource(InputDevice.SOURCE_MOUSE) &&
            (ev.actionMasked == MotionEvent.ACTION_BUTTON_PRESS || ev.actionMasked == MotionEvent.ACTION_BUTTON_RELEASE) &&
            ev.actionButton == MotionEvent.BUTTON_SECONDARY
        ) {
            lastRightMs = SystemClock.uptimeMillis()
            return true // evita performContextClick / ações padrão das views
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    /** Pede a localização aproximada uma única vez (mesma flag do clima da barra de tarefas). */
    private fun askLocationOnce() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) return
        if (prefs.getBoolean("wxAsked", false)) return
        prefs.edit().putBoolean("wxAsked", true).apply()
        try {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
        } catch (e: Exception) {
        }
    }

    /**
     * Camada da janela de app aberta (e não minimizada) que está mais à frente, ou null.
     * As janelas escondem o próprio "win" (filho da camada), então olhamos os filhos visíveis.
     */
    private fun topWindowLayer(): View? {
        var best: View? = null
        var bestIdx = -1
        for (e in taskEntries()) {
            if (!e.isOpen()) continue
            val l = e.layer as? ViewGroup ?: continue
            val idx = root.indexOfChild(l)
            if (idx < 0 || l.visibility != View.VISIBLE || idx <= bestIdx) continue
            var shown = false
            for (k in 0 until l.childCount) {
                if (l.getChildAt(k).visibility == View.VISIBLE) {
                    shown = true
                    break
                }
            }
            if (!shown) continue
            best = l
            bestIdx = idx
        }
        return best
    }

    private fun isPhysicalKeyboard(event: KeyEvent): Boolean {
        val d = event.device ?: return false
        return !d.isVirtual && event.isFromSource(InputDevice.SOURCE_KEYBOARD)
    }

    /** Abre a tela de bloqueio interna fechando antes menus e painéis abertos. */
    /** Usado pelas janelas de configurações: modo claro ou escuro. */
    fun isLightTheme(): Boolean = light

    /** Abre o painel para criar, alterar ou remover a senha da tela de bloqueio. */
    fun openPasswordPanel() {
        val panel = PasswordPanel.manage(this, prefs, light)
        root.addView(panel, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun openLockScreen() {
        if (lockScreen.isOpen) return
        closeAll()
        clearDesktopSelection()
        lockScreen.show()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Alt + \ abre/fecha a Visão de Tarefas; Esc fecha
        if (::taskView.isInitialized && event.isAltPressed && !event.isCtrlPressed && !event.isMetaPressed &&
            !event.isShiftPressed && isPhysicalKeyboard(event) &&
            (event.keyCode == KeyEvent.KEYCODE_BACKSLASH || event.getUnicodeChar(0) == '\\'.code)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) taskView.toggle()
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && ::taskView.isInitialized) {
            if (event.keyCode == KeyEvent.KEYCODE_ESCAPE && taskView.taskShown) {
                taskView.hide()
                return true
            }
        }
        // Bloqueio dos botões físicos de volume (opção em Personalizar). Consumir o evento (DOWN e UP) impede
        // o Android de mudar o volume e de mostrar a barra de volume do sistema. Só vale com o app em primeiro plano.
        if (::cfg.isInitialized && cfg.blockVolKeys && (
                event.keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                    event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
                    event.keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
                )
        ) {
            return true
        }
        // O Android converte o botão direito do mouse em um BACK sintetizado; ele fechava o menu logo após abrir.
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.isFromSource(InputDevice.SOURCE_MOUSE)) {
            return true
        }
        // ALT + Z (teclado físico, só com o WinLauncher em primeiro plano) abre a tela de bloqueio interna.
        if (event.keyCode == KeyEvent.KEYCODE_Z && event.isAltPressed && !event.isCtrlPressed &&
            !event.isMetaPressed && !event.isShiftPressed && isPhysicalKeyboard(event) && ::lockScreen.isInitialized
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) openLockScreen()
            return true
        }
        // ALT + I (teclado físico, só com o WinLauncher em primeiro plano) abre/fecha a janela Configurações.
        if (event.keyCode == KeyEvent.KEYCODE_I && event.isAltPressed && !event.isCtrlPressed &&
            !event.isMetaPressed && !event.isShiftPressed && isPhysicalKeyboard(event) &&
            ::settingsWindow.isInitialized && !(::lockScreen.isInitialized && lockScreen.isOpen)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (settingsWindow.isOpen && !settingsWindow.isMinimized) settingsWindow.close() else settingsWindow.show()
            }
            return true
        }
        // ALT + V (teclado físico, só com o WinLauncher em primeiro plano) abre/fecha o painel de volume.
        if (event.keyCode == KeyEvent.KEYCODE_V && event.isAltPressed && !event.isCtrlPressed &&
            !event.isMetaPressed && !event.isShiftPressed && isPhysicalKeyboard(event) &&
            ::volPanel.isInitialized && !(::lockScreen.isInitialized && lockScreen.isOpen)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (volPanel.visibility == View.VISIBLE) closeAll() else showPanel(volPanel)
            }
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && ::lockScreen.isInitialized && lockScreen.isOpen &&
            event.keyCode == KeyEvent.KEYCODE_ESCAPE
        ) {
            // ESC fecha primeiro o menu e as janelas (cidade, personalização); a tela de bloqueio continua aberta
            // saída provisória; o mecanismo definitivo de saída vem na Parte 4
            if (::menu.isInitialized && menu.isShowing) menu.hide()
            else if (!lockScreen.closeOverlays()) lockScreen.requestHide()
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && ::menu.isInitialized && ::overlay.isInitialized) {
            if (event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (!menu.isShowing && overlay.visibility != View.VISIBLE && selectedKeys.isNotEmpty()) {
                    clearDesktopSelection()
                    return true
                }
                if (menu.isShowing) {
                    menu.hide()
                    return true
                }
                if (overlay.visibility == View.VISIBLE) {
                    closeAll()
                    return true
                }
            }
            if (event.keyCode == KeyEvent.KEYCODE_S && event.isMetaPressed && !(::lockScreen.isInitialized && lockScreen.isOpen)) {
                openSearch()
                return true
            }
        }
        // Apps por link: Alt + 5, Alt + F5, F5 ou Ctrl + R atualizam a página da janela que estiver na frente.
        if (isPhysicalKeyboard(event) && !event.isMetaPressed && !event.isShiftPressed && (
                ((event.keyCode == KeyEvent.KEYCODE_5 || event.keyCode == KeyEvent.KEYCODE_F5) && event.isAltPressed && !event.isCtrlPressed) ||
                    (event.keyCode == KeyEvent.KEYCODE_F5 && !event.isAltPressed && !event.isCtrlPressed) ||
                    (event.keyCode == KeyEvent.KEYCODE_R && event.isCtrlPressed && !event.isAltPressed)
                )
        ) {
            val top = topWindowLayer()
            val w = webWins.values.firstOrNull { it.isOpen && !it.isMinimized && top === it.layer }
            if (w != null) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) w.refreshPage()
                return true
            }
        }
        // ALT + 5 ou ALT + F5: atualiza a página do navegador (só quando a janela dele está na frente).
        if ((event.keyCode == KeyEvent.KEYCODE_5 || event.keyCode == KeyEvent.KEYCODE_F5) && event.isAltPressed &&
            !event.isCtrlPressed && !event.isMetaPressed && !event.isShiftPressed && isPhysicalKeyboard(event) &&
            ::browser.isInitialized && browser.isOpen && !browser.isMinimized && topWindowLayer() === browser.layer
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) browser.refreshPage()
            return true
        }
        // Esc nos apps por link: volta à página anterior (só a janela que estiver na frente)
        for (w in webWins.values) {
            if (w.isOpen && !w.isMinimized && topWindowLayer() === w.layer && w.handleKey(event)) return true
        }
        if (::gallery.isInitialized && gallery.handleKey(event)) return true
        if (::musicWin.isInitialized && musicWin.handleKey(event)) return true
        if (::files.isInitialized && files.handleKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    /** Há um pedido de POST_NOTIFICATIONS do servidor Remote em andamento (evita pedidos duplicados). */
    private var remoteNotifPending = false

    /**
     * Liga o servidor WinLauncher Remote (ação explícita do usuário no painel). No Android 13+ pede POST_NOTIFICATIONS
     * UMA única vez (lembrado em "remote_notif_asked"), antes de ligar, para a notificação do serviço poder aparecer.
     * Se for negada, ou já tiver sido pedida antes, o servidor liga normalmente: a permissão não é necessária para ele funcionar.
     */
    fun startRemoteServerAskingNotifications() {
        if (remoteNotifPending) return
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                !prefs.getBoolean(PREF_REMOTE_NOTIF_ASKED, false)
            ) {
                prefs.edit().putBoolean(PREF_REMOTE_NOTIF_ASKED, true).apply()
                remoteNotifPending = true
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF_REMOTE)
                return
            }
        } catch (e: Exception) {
            remoteNotifPending = false
        }
        RemoteServerService.start(this)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF_REMOTE) {
            // concedida ou negada: o servidor liga do mesmo jeito (a notificação é só um aviso)
            if (remoteNotifPending) {
                remoteNotifPending = false
                if (!RemoteServerService.isActive()) RemoteServerService.start(this)
            }
            return
        }
        if (requestCode == REQ_WIFI && ::infoPanel.isInitialized && infoPanel.visibility == View.VISIBLE &&
            infoAnchor === wifiIcon
        ) {
            val w = wifiInfo(false)
            infoText.text = w.first
            infoAction = w.second
            positionInfoPanel()
        }
        if (requestCode == FileManagerWindow.REQ_STORAGE && ::files.isInitialized) files.onHostResume()
        if (requestCode == REQ_LOC) {
            refreshWeather(true)
            if (::lockScreen.isInitialized && lockScreen.isOpen) lockScreen.refreshWeather(true)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == BrowserWindow.REQ_FILE) {
            if (::browser.isInitialized) browser.onFileChosen(resultCode, data)
            for (w in webWins.values) w.onFileChosen(resultCode, data)
            return
        }
        if (requestCode == REQ_APK) {
            if (::apkWindow.isInitialized && resultCode == RESULT_OK) apkWindow.onPicked(data?.data)
            return
        }
        if (requestCode == REQ_WEBICON) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            if (uri != null && ::webInstaller.isInitialized) {
                try {
                    val bmp = decodeSquare(uri, 192)
                    if (bmp != null) webInstaller.onIconPicked(bmp) else toast("Não foi possível abrir a imagem")
                } catch (e: Exception) {
                    toast("Não foi possível abrir a imagem")
                }
            }
            return
        }
        if (requestCode == REQ_LOCK_WP) {
            // arquivo escolhido para a galeria da TELA DE BLOQUEIO DO LAUNCHER (não mexe no wallpaper do Android)
            if (::lockScreen.isInitialized) {
                val uri = if (resultCode == RESULT_OK) data?.data else null
                if (uri != null) lockScreen.importWallpaper(uri) else lockScreen.openWallpaperGallery()
            }
            return
        }
        if (requestCode == REQ_FONT) {
            if (resultCode == RESULT_OK && data != null) importFonts(data) else reopenCustomize(CustomizeUi.WIDGETS)
            return
        }
        if (requestCode == REQ_APP_ICON) {
            val cn = pendingIconApp
            pendingIconApp = null
            val uri = if (resultCode == RESULT_OK) data?.data else null
            if (cn != null && uri != null) {
                try {
                    val bmp = decodeSquare(uri, 192)
                    if (bmp == null) {
                        Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
                    } else {
                        AppCustom.setIcon(this, cn, bmp)
                        afterAppCustomized()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == REQ_AVATAR && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val bmp = decodeSquare(uri, 256)
                if (bmp == null) {
                    Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
                } else {
                    File(filesDir, "avatar.png").outputStream().use {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    prefs.edit().putBoolean("userHasPhoto", true).apply()
                    refreshProfile()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (requestCode == REQ_WP && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            val type = contentResolver.getType(uri) ?: ""
            prefs.edit()
                .putString("wp", uri.toString())
                .putBoolean("wpVideo", type.startsWith("video/"))
                .apply()
            addRecentWallpaper(uri.toString(), type.startsWith("video/"))
            applyWallpaper()
            wallpaperChanged?.invoke()
        }
    }

    // ------------------------------------------------------------------- apps

    private fun loadApps(after: () -> Unit) {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN)
            q.addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                    AppItem(
                        AppCustom.label(this, cn, ri.loadLabel(pm).toString()),
                        AppCustom.icon(this, cn) ?: ri.loadIcon(pm),
                        cn
                    )
                }
                .sortedBy { it.label.lowercase() }
            val webs = WebApps.list(this).map { e ->
                AppItem(AppCustom.label(this, e.cn, e.name), WebApps.icon(this, e), e.cn)
            }
            val full = (list + webs).sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = full
                after()
            }
        }.start()
    }

    private fun initDefaults() {
        if (prefs.getBoolean("init", false)) return
        val pk = listOf(
            "com.android.chrome",
            "com.sec.android.app.sbrowser",
            "com.android.vending",
            "com.samsung.android.dialer",
            "com.sec.android.app.camera",
            "com.sec.android.gallery3d",
            "com.sec.android.app.myfiles",
            "com.android.settings"
        )
        val cns = pk.mapNotNull { packageManager.getLaunchIntentForPackage(it)?.component?.flattenToString() }
        setList("tb", cns)
        setList("st", cns)
        prefs.edit().putBoolean("init", true).apply()
    }

    private fun onAppsLoaded() {
        initDefaults()
        refreshPins()
        filterApps(searchBox.text?.toString() ?: "")
    }

    private fun refreshPins() {
        rebuildTaskbar()
        rebuildDesktop()
    }

    private fun filterApps(q: String) {
        val all = (allApps + nativeApps()).sortedBy { it.label.lowercase() }
        startAdapter.items = if (q.isEmpty()) all else all.filter { it.label.contains(q, true) }
        startAdapter.notifyDataSetChanged()
        updateWeatherCardVisibility()
    }

    private fun toggle(k: String, v: String) {
        val l = getList(k).toMutableList()
        if (!l.remove(v)) l.add(v)
        setList(k, l)
        refreshPins()
    }

    /** Move o app fixado na barra de tarefas uma posição (dir = -1 esquerda, +1 direita). */
    private fun moveTb(key: String, dir: Int) {
        val l = getList("tb").toMutableList()
        val i = l.indexOf(key)
        if (i < 0) return
        var j = i + dir
        while (j in l.indices && !tbPresent(l[j])) j += dir
        if (j !in l.indices) return
        val t = l[i]
        l[i] = l[j]
        l[j] = t
        setList("tb", l)
        refreshPins()
    }

    private fun canMoveTb(key: String, dir: Int): Boolean {
        val l = getList("tb")
        val i = l.indexOf(key)
        if (i < 0) return false
        var j = i + dir
        while (j in l.indices && !tbPresent(l[j])) j += dir
        return j in l.indices
    }

    /** Item que aparece na barra: a engrenagem ou um app instalado. */
    private fun tbPresent(k: String): Boolean = k == TB_GEAR || k == TB_BROWSER || k == TB_FILES || k == TB_GALLERY || k == TB_PERF || k == TB_MUSIC || appFor(k) != null

    /** Garante a engrenagem entre os fixados (primeira vez: no começo). Ela só pode ser movida, nunca removida. */
    private fun ensureGearPinned() {
        val l = getList("tb")
        if (TB_GEAR in l) return
        setList("tb", listOf(TB_GEAR) + l)
    }

    /** Fixa o navegador na barra de tarefas na primeira vez (depois disso, desafixar é escolha do usuário). */
    private fun ensureBrowserPinned() {
        if (prefs.getBoolean("browserPinnedOnce", false)) return
        prefs.edit().putBoolean("browserPinnedOnce", true).apply()
        val l = getList("tb").toMutableList()
        if (TB_BROWSER in l) return
        val gi = l.indexOf(TB_GEAR)
        l.add(if (gi >= 0) gi + 1 else 0, TB_BROWSER)
        setList("tb", l)
    }

    /** Fixa o gerenciador de arquivos na barra de tarefas na primeira vez (logo depois do navegador). */
    private fun ensureFilesPinned() {
        if (prefs.getBoolean("filesPinnedOnce", false)) return
        prefs.edit().putBoolean("filesPinnedOnce", true).apply()
        val l = getList("tb").toMutableList()
        if (TB_FILES in l) return
        val bi = l.indexOf(TB_BROWSER)
        val gi = l.indexOf(TB_GEAR)
        l.add(if (bi >= 0) bi + 1 else if (gi >= 0) gi + 1 else 0, TB_FILES)
        setList("tb", l)
    }

    /** Fixa a galeria de fotos na barra de tarefas na primeira vez (logo depois do gerenciador de arquivos). */
    private fun ensureGalleryPinned() {
        if (prefs.getBoolean("galleryPinnedOnce", false)) return
        prefs.edit().putBoolean("galleryPinnedOnce", true).apply()
        val l = getList("tb").toMutableList()
        if (TB_GALLERY in l) return
        val fi = l.indexOf(TB_FILES)
        val bi = l.indexOf(TB_BROWSER)
        val gi = l.indexOf(TB_GEAR)
        l.add(if (fi >= 0) fi + 1 else if (bi >= 0) bi + 1 else if (gi >= 0) gi + 1 else 0, TB_GALLERY)
        setList("tb", l)
    }

    // -------------------------------------------------------------- wallpaper

    private fun pickWallpaper() {
        pickWallpaperOf(arrayOf("video/*", "image/*"))
    }

    fun pickWallpaperOf(mimes: Array<String>) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_WP)
        } catch (e: Exception) {
            toast("Nenhum seletor de arquivos encontrado")
        }
    }

    /**
     * Seletor de arquivos do Android usado só para ESCOLHER uma imagem/GIF/vídeo para a galeria da tela de bloqueio
     * do launcher. Nada é aplicado ao papel de parede do sistema; o arquivo é copiado para o espaço do app.
     */
    fun pickLockWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
        try {
            startActivityForResult(i, REQ_LOCK_WP)
        } catch (e: Exception) {
            toast("Nenhum seletor de arquivos encontrado")
        }
    }

    /** Abre o seletor de arquivos do Android para importar fontes TTF/OTF (uma ou várias). */
    fun pickFont() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf(
                "font/ttf", "font/otf", "font/sfnt",
                "application/x-font-ttf", "application/x-font-otf", "application/x-font-opentype",
                "application/font-sfnt", "application/vnd.ms-opentype", "application/octet-stream"
            )
        )
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(i, REQ_FONT)
        } catch (e: Exception) {
            toast("Nenhum seletor de arquivos encontrado")
            reopenCustomize(CustomizeUi.WIDGETS)
        }
    }

    /** Copia as fontes escolhidas para o espaço privado do app (validando cada uma) e reabre o painel. */
    private fun importFonts(data: Intent) {
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        val cd = data.clipData
        if (cd != null) for (i in 0 until cd.itemCount) cd.getItemAt(i).uri?.let { if (it !in uris) uris.add(it) }
        Thread {
            var ok = 0
            var error: String? = null
            for (u in uris) {
                val r = FontStore.import(this, u)
                if (r.entry != null) ok++ else if (error == null) error = r.error
            }
            val added = ok
            val err = error
            runOnUiThread {
                val added1 = if (added == 1) "Fonte adicionada" else "$added fontes adicionadas"
                when {
                    added > 0 && err == null -> toast(added1)
                    added > 0 -> toast(added1 + ". Alguns arquivos foram ignorados: " + err)
                    err != null -> toast(err)
                }
                reopenCustomize(CustomizeUi.WIDGETS)
            }
        }.start()
    }

    private fun applyWallpaper() {
        applyWallpaperCore()
        updateGlassSource()
    }

    private fun applyWallpaperCore() {
        wallpaperHost.removeAllViews()
        video = null
        anim?.stop()
        anim = null
        wallpaperHost.background = null

        val s = prefs.getString("wp", null)
        if (s == null) {
            wallpaperHost.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#0B1E3F"),
                    Color.parseColor("#1B5FD0"),
                    Color.parseColor("#0A2A66")
                )
            )
            return
        }
        val uri = Uri.parse(s)
        try {
            if (prefs.getBoolean("wpVideo", false)) {
                val v = VideoView(this)
                wallpaperHost.addView(v, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
                v.setAudioFocusRequest(AudioManager.AUDIOFOCUS_NONE)
                v.setOnPreparedListener { mp ->
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    val vw = mp.videoWidth
                    val vh = mp.videoHeight
                    val w = wallpaperHost.width
                    val h = wallpaperHost.height
                    if (vw > 0 && vh > 0 && w > 0 && h > 0) {
                        val sc = maxOf(w.toFloat() / vw, h.toFloat() / vh)
                        v.layoutParams = FrameLayout.LayoutParams(
                            (vw * sc).toInt(),
                            (vh * sc).toInt(),
                            Gravity.CENTER
                        )
                    }
                    v.start()
                }
                v.setOnErrorListener { _, _, _ -> true }
                v.setVideoURI(uri)
                video = v
            } else {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                wallpaperHost.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
                if (Build.VERSION.SDK_INT >= 28) {
                    val src = ImageDecoder.createSource(contentResolver, uri)
                    val dm = resources.displayMetrics
                    val d = ImageDecoder.decodeDrawable(src) { decoder, info, _ ->
                        // Qualidade: 0 = Otimizado (tamanho da tela), 1 = Alta (1,5x), 2 = Original
                        val mul = when (wallpaperQuality()) { 0 -> 1f; 1 -> 1.5f; else -> 0f }
                        val sc = maxOf(
                            dm.widthPixels.toFloat() / info.size.width,
                            dm.heightPixels.toFloat() / info.size.height
                        ) * mul
                        if (mul > 0f && sc < 1f) {
                            decoder.setTargetSize(
                                (info.size.width * sc).toInt(),
                                (info.size.height * sc).toInt()
                            )
                        }
                    }
                    iv.setImageDrawable(d)
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                        anim = d
                    }
                } else {
                    iv.setImageURI(uri)
                }
            }
        } catch (e: Exception) {
            toast("Não consegui abrir o wallpaper")
        }
    }

    // --------------------------------------------------------------------- UI

    private fun buildUi() {
        root = PointerRoot(this, cursor)
        root.setBackgroundColor(Color.BLACK)

        wallpaperHost = FrameLayout(this)
        root.addView(wallpaperHost, FrameLayout.LayoutParams(MATCH, MATCH))

        val ui = LinearLayout(this)
        ui.orientation = LinearLayout.VERTICAL
        root.addView(ui, FrameLayout.LayoutParams(MATCH, MATCH))
        // botão de volume flutuante do próprio launcher (aparece no monitor sem criar janelas em outras telas)
        volFloat = FloatingVolumeButton(
            this, root, prefs,
            { isRightClick(it) },
            { if (volPanel.visibility == View.VISIBLE) closeAll() else showPanel(volPanel) },
            { x, y -> volFloatMenu(x, y) }
        )
        volFloat.applyVisibility()
        uiCol = ui

        desktopFrame = DesktopFrame(this, desktopHost)
        ui.addView(desktopFrame, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val catcher = View(this)
        desktopFrame.addView(catcher, FrameLayout.LayoutParams(MATCH, MATCH))
        catcher.tag = CursorController.NOHAND
        rightClick(catcher) { x, y -> desktopContextMenu(x, y) }

        // área de trabalho livre: cada ícone fica na posição salva (arrastável para qualquer lugar)
        loadDkPos()
        desktopGrid = FrameLayout(this)
        desktopGrid.clipChildren = false
        desktopGrid.clipToPadding = false
        desktopAdapter = AppAdapter(emptyList(), 44, 11f)
        desktopFrame.addView(desktopGrid, FrameLayout.LayoutParams(MATCH, MATCH))
        desktopGrid.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - t != ob - ot) desktopGrid.post { rebuildDesktopViews() }
        }

        // widget de relógio e calendário: fica sobre os ícones na hierarquia, mas nunca ocupa o mesmo espaço
        clock = ClockWidget(this, cfg)
        clock.onResize = { rebuildDesktopViews() }
        desktopFrame.addView(clock.view, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START))

        marqueeView = View(this)
        marqueeView.visibility = View.GONE
        marqueeView.isClickable = false
        marqueeView.background = whiteGlass(marqueeView, 60, 8, 3)
        desktopFrame.addView(marqueeView, FrameLayout.LayoutParams(0, 0))

        overlay = FrameLayout(this)
        overlay.visibility = View.GONE
        overlay.setOnClickListener { closeAll() }
        overlay.tag = CursorController.NOHAND
        rightClick(overlay) { x, y ->
            closeAll()
            desktopContextMenu(x, y)
        }
        desktopFrame.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        // tela de bloqueio: por cima de toda a tela, inclusive da barra de tarefas
        lockScreen = LockScreen(this, prefs, { listOf(desktopGrid, clock.view) }, { askLocationOnce() }, { pickLockWallpaper() }) { x, y ->
            // botão direito em área vazia da tela de bloqueio
            menu.show(
                listOf(
                    MenuItem(
                        "Personalizar tela de bloqueio", R.drawable.ic_palette,
                        action = { lockScreen.openCustomizer() }
                    )
                ),
                x, y
            )
        }
        root.addView(lockScreen, FrameLayout.LayoutParams(MATCH, MATCH)) // tela cheia: cobre também a barra de tarefas

        // boas-vindas estilo Windows (foto + nome + carregamento fake de 3 s) entre o desbloqueio e o desktop
        welcomeScreen = WelcomeScreen(this)
        root.addView(welcomeScreen, FrameLayout.LayoutParams(MATCH, MATCH))
        lockScreen.welcomeRunner = { onCovered, onDone ->
            val f = File(filesDir, "avatar.png")
            val photoFile = if (prefs.getBoolean("userHasPhoto", false) && f.exists()) f else null
            welcomeScreen.play(userName(), photoFile, onCovered, onDone)
        }
        lockScreen.welcomeCancel = { welcomeScreen.cancel() }

        buildStartPanel()
        buildQuickPanel()
        buildCalPanel()
        buildSearchPanel()
        buildNotifPanel()
        buildVolPanel()
        buildInfoPanel()
        buildTaskbar()
        ui.addView(taskbar, LinearLayout.LayoutParams(MATCH, WRAP))

        // música na barra de tarefas: chip (capa + nome + ondinhas) só enquanto toca; toque sobe o painel de vidro
        music = TaskbarMusic(this, taskbar, overlay, pinnedRow, cAccent) {
            if (music.isPanelOpen) closeAll() else showPanel(music.panel)
        }
        music.rightAnchor = chevBtn
        music.onChipMenu = { x, y -> openMusicChipMenu(x, y) }
        syncMusicSide()
        music.place(cfg.tbPos == 1, dp(8))
        music.applyMetrics(sdp(cfg.tbHeight), tbFg(), cfg.tbScale)
        music.start()

        root.setOnApplyWindowInsetsListener { _, ins ->
            insTop = ins.systemWindowInsetTop
            insBottom = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        menu = ContextMenuHost(this, root, { cfg.menuHover }, { cfg.menuDark })
        root.addView(startHost, FrameLayout.LayoutParams(MATCH, MATCH))
        desktopFrame.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> desktopFrame.post { syncStartHost() } }
        root.addView(menu.layer, FrameLayout.LayoutParams(MATCH, MATCH))
        taskView = TaskView(this, prefs, { taskEntries() }, { ::lockScreen.isInitialized && lockScreen.isOpen })
        root.addView(taskView, FrameLayout.LayoutParams(MATCH, MATCH))
        tbPreview = TaskbarPreview(this, root, { intArrayOf(cPanel, cText, cAccent) }, { cfg.tbPos == 1 })
        tbPreview.attachBelow(winTop)
        pcWindow = PcInfoWindow(this, root)
        pcWindow.attachBelow(winTop)
        pcWindow.onStateChange = { rebuildTaskbar() }
        apkWindow = ApkInstallerWindow(this, root)
        apkWindow.attachBelow(winTop)
        musicWin = MusicPlayerWindow(this, root) { isLightTheme() }
        musicWin.attachBelow(winTop)
        musicWin.onStateChange = { rebuildTaskbar() }
        apkWindow.onStateChange = { rebuildTaskbar() }
        webInstaller = WebAppInstallerWindow(this, root)
        webInstaller.attachBelow(winTop)
        webInstaller.onInstalled = { e, pin, desk -> onWebAppInstalled(e, pin, desk) }
        browser = BrowserWindow(this, root) { taskbarInsetsPx() }
        browser.attachBelow(winTop)
        browser.onStateChange = { rebuildTaskbar() }
        files = FileManagerWindow(this, root) { taskbarInsetsPx() }
        files.attachBelow(winTop)
        files.onStateChange = { rebuildTaskbar() }
        gallery = GalleryWindow(this, root) { taskbarInsetsPx() }
        gallery.attachBelow(winTop)
        gallery.onStateChange = { rebuildTaskbar() }
        updater = UpdateChecker(this, prefs, apkWindow)
        settingsWindow = SettingsWindow(
            this, root, cfg,
            startPreview = { on -> previewStartMenu(on) },
            taskbarInsets = { taskbarInsetsPx() },
            openPc = { pcWindow.show() },
            editProfile = { profileMenu() },
            userName = { userName() },
            lockNow = { openLockScreen() },
            checkUpdates = { updater.checkNow() }
        )
        settingsWindow.attachBelow(winTop)
        settingsWindow.onStateChange = { rebuildTaskbar() }
        customize = CustomizeUi(this, cfg, dark = cfg.menuDark)
        Glass.root = root
        setContentView(root)
        rebuildTaskbar()
        applyPrefs()
        // mostra o último clima guardado já na abertura (depois atualiza pela internet)
        weatherData = Weather.load(prefs)
        updateTbWeather()
    }

    private fun buildTaskbar() {
        taskbar = FrameLayout(this)
        taskbar.setBackgroundColor(cTaskbar)

        tbRow = LinearLayout(this)
        tbRow.orientation = LinearLayout.HORIZONTAL
        tbRow.gravity = Gravity.CENTER_VERTICAL
        taskbar.addView(tbRow, FrameLayout.LayoutParams(MATCH, dp(48)))
        setupTaskbarEmptyAreaMenu()

        // compensa a largura do sino para não deslocar o grupo central de ícones
        tbBellPad = View(this)
        tbRow.addView(tbBellPad, LinearLayout.LayoutParams(dp(36 + 24), 1))
        tbSpacerL = View(this)
        tbRow.addView(tbSpacerL, LinearLayout.LayoutParams(0, 1, 1f))

        startBtn = ImageView(this)
        startBtn.setImageResource(R.drawable.ic_start)
        startBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        startBtn.background = rip(Color.TRANSPARENT, 6)
        startBtn.setOnClickListener {
            if (startPanel.visibility == View.VISIBLE) closeAll() else openStart()
        }

        pinnedRow = LinearLayout(this)
        pinnedRow.orientation = LinearLayout.HORIZONTAL
        pinnedRow.gravity = Gravity.CENTER_VERTICAL
        tbRow.addView(pinnedRow, LinearLayout.LayoutParams(WRAP, MATCH))

        tbRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        wifiIcon = ImageView(this)
        wifiIcon.setImageResource(R.drawable.ic_wifi)
        volIcon = ImageView(this)
        volIcon.setImageResource(R.drawable.ic_volume)
        batIcon = ImageView(this)
        batIcon.setImageResource(R.drawable.ic_battery)

        tbTray = LinearLayout(this)
        tbTray.orientation = LinearLayout.HORIZONTAL
        tbTray.gravity = Gravity.CENTER_VERTICAL
        tbTray.background = rip(Color.TRANSPARENT, 6)
        tbTray.setPadding(dp(4), 0, dp(4), 0)
        tbTray.setOnClickListener { showPanel(quickPanel) }
        // ícone de áudio: levanta a barra de volume
        // ícone de Wi-Fi: caixinha com o nome da rede; ícone de bateria: caixinha com a porcentagem
        wifiIcon.isClickable = true
        wifiIcon.setOnClickListener {
            // abre o painel "Internet" do Android (mesmo do bloco Wi-Fi do painel rápido)
            if (Build.VERSION.SDK_INT >= 29) {
                safeStart(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            } else {
                safeStart(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        }
        batIcon.isClickable = true
        batIcon.setOnClickListener { toggleInfo(batIcon, R.drawable.ic_battery, batteryLabel()) }
        volIcon.isClickable = true
        volIcon.setOnClickListener {
            if (volPanel.visibility == View.VISIBLE) closeAll() else showPanel(volPanel)
        }
        for (iv in listOf(wifiIcon, volIcon, batIcon)) {
            val lp = LinearLayout.LayoutParams(dp(20), dp(20))
            lp.setMargins(dp(5), 0, dp(5), 0)
            tbTray.addView(iv, lp)
        }
        tbRow.addView(tbTray, LinearLayout.LayoutParams(WRAP, dp(40)))

        tbClockView = TextClock(this)
        tbClockView.format12Hour = "HH:mm\ndd/MM/yyyy"
        tbClockView.format24Hour = "HH:mm\ndd/MM/yyyy"
        tbClockView.setTextColor(Color.WHITE)
        tbClockView.textSize = 11f
        tbClockView.gravity = Gravity.CENTER
        tbClockView.setPadding(dp(8), 0, dp(8), 0)
        tbClockView.background = rip(Color.TRANSPARENT, 6)
        tbClockView.setOnClickListener { showPanel(calPanel) }
        val clp = LinearLayout.LayoutParams(WRAP, dp(40))
        clp.rightMargin = dp(4)
        tbRow.addView(tbClockView, clp)

        bellBtn = FrameLayout(this)
        bellBtn.background = rip(Color.TRANSPARENT, 6)
        bellBtn.isClickable = true
        bellBtn.setOnClickListener {
            if (notifPanel.visibility == View.VISIBLE) closeAll() else showPanel(notifPanel)
        }
        bellIcon = ImageView(this)
        bellIcon.setImageResource(R.drawable.ic_bell)
        bellBtn.addView(bellIcon, FrameLayout.LayoutParams(MATCH, MATCH))
        bellBadge = TextView(this)
        bellBadge.textSize = 8f
        bellBadge.setTextColor(Color.BLACK)
        bellBadge.typeface = Typeface.DEFAULT_BOLD
        bellBadge.gravity = Gravity.CENTER
        bellBadge.minWidth = dp(14)
        bellBadge.minHeight = dp(14)
        val badgeBg = GradientDrawable()
        badgeBg.shape = GradientDrawable.OVAL
        badgeBg.setColor(cAccent)
        bellBadge.background = badgeBg
        bellBadge.visibility = View.GONE
        val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        blp.setMargins(0, dp(4), dp(2), 0)
        bellBtn.addView(bellBadge, blp)
        tbRow.addView(bellBtn, LinearLayout.LayoutParams(dp(36), dp(40)))

        // seta "^" à esquerda do ícone de Wi-Fi: levanta/baixa o painel rápido (Wi-Fi, Bluetooth etc.)
        chevBtn = ImageView(this)
        chevBtn.setImageResource(R.drawable.ic_chevron_up)
        chevBtn.setPadding(dp(4), dp(4), dp(4), dp(4))
        chevBtn.background = rip(Color.TRANSPARENT, 6)
        chevBtn.isClickable = true
        chevBtn.setOnClickListener {
            if (quickPanel.visibility == View.VISIBLE) closeAll() else showPanel(quickPanel)
        }
        tbRow.addView(chevBtn, tbRow.indexOfChild(tbTray), LinearLayout.LayoutParams(dp(24), dp(40)))

        // mantém o grupo central (iniciar + pesquisa + apps) no centro REAL da tela:
        // o espaçador da esquerda sempre acompanha a largura de todo o lado direito
        val centerSync = View.OnLayoutChangeListener { _, l, _, r, _, ol, _, or, _ ->
            if (r - l != or - ol) syncCenterPad()
        }
        tbTray.addOnLayoutChangeListener(centerSync)
        tbClockView.addOnLayoutChangeListener(centerSync)
        bellBtn.addOnLayoutChangeListener(centerSync)
        chevBtn.addOnLayoutChangeListener(centerSync)

        // campo de pesquisa (fora do fluxo da linha, para não mover os demais itens)
        searchPill = LinearLayout(this)
        searchPill.orientation = LinearLayout.HORIZONTAL
        searchPill.gravity = Gravity.CENTER_VERTICAL
        searchPill.background = rounded(cTile, 16)
        searchPill.setPadding(dp(10), 0, dp(10), 0)
        searchPill.isClickable = true
        searchPill.setOnClickListener { if (!rightClickRecent()) openSearch() }
        rightClick(searchPill) { x, y -> searchPillMenu(x, y) }
        pillIcon = ImageView(this)
        pillIcon.setImageResource(R.drawable.ic_search)
        searchPill.addView(pillIcon, LinearLayout.LayoutParams(dp(16), dp(16)))
        pillText = TextView(this)
        pillText.text = "Pesquisar"
        pillText.setTextColor(Color.WHITE)
        pillText.textSize = 12f
        pillText.maxLines = 1
        val ptl = LinearLayout.LayoutParams(0, WRAP, 1f)
        ptl.leftMargin = dp(8)
        searchPill.addView(pillText, ptl)

        // previsão do tempo dentro da barra de pesquisa (nuvem + °C)
        tbWeather = TextView(this)
        tbWeather.setTextColor(Color.WHITE)
        tbWeather.textSize = 12f
        tbWeather.maxLines = 1
        tbWeather.gravity = Gravity.CENTER_VERTICAL
        tbWeather.text = "☁️ --°C"
        tbWeather.visibility = View.VISIBLE
        tbWeather.isClickable = true
        rightClick(tbWeather) { x, y -> searchPillMenu(x, y) }
        tbWeather.setOnClickListener {
            if (rightClickRecent()) return@setOnClickListener
            if (startPanel.visibility == View.VISIBLE) {
                closeAll()
            } else {
                weatherOpen = true
                updateWeatherCardVisibility()
                openStart()
            }
        }
        val wlp = LinearLayout.LayoutParams(WRAP, MATCH)
        wlp.leftMargin = dp(6)
        searchPill.addView(tbWeather, wlp)
    }

    /** Botão direito na barra de pesquisa: alterna entre a barra completa e só a lupa. */
    private fun searchPillMenu(x: Int, y: Int) {
        val compact = cfg.tbSearchIcon
        menu.show(
            listOf(
                MenuItem(
                    if (compact) "Mostrar barra de pesquisa" else "Mostrar apenas a lupa",
                    R.drawable.ic_search,
                    action = {
                        cfg.tbSearchIcon = !compact
                        rebuildTaskbar()
                        TaskbarOverlayService.instance?.removeStripForRebuild()
                    }
                )
            ),
            x, y
        )
    }

    private fun updateTbWeather() {
        if (!::tbWeather.isInitialized || !::pinnedRow.isInitialized) return
        val w = weatherData
        tbWeather.text =
            if (w != null) Weather.emoji(w.code, w.isDay) + " " + w.temp + "°C" else "☁️ --°C"
        tbWeather.visibility = if (cfg.tbSearchIcon) View.GONE else View.VISIBLE
        applyTaskbarMetrics()
        rebuildTaskbar()
    }

    // ---- arrastar para reorganizar os apps da barra de tarefas (botão esquerdo do mouse) ----
    private val tbPinViews = ArrayList<Pair<View, String>>()
    private var dragStartX = 0f
    private var dragging = false

    private fun pinTouch(iv: View, a: AppItem) =
        pinTouch(iv, a.cn.flattenToString()) { x, y -> appContextMenu(a, x, y) }

    private fun pinTouch(iv: View, key: String, onRight: (Int, Int) -> Unit) {
        iv.setOnTouchListener { v, ev ->
            if (isRightClick(ev)) {
                onRight(ev.rawX.toInt(), ev.rawY.toInt())
                return@setOnTouchListener true
            }
            val fromMouse = ev.isFromSource(InputDevice.SOURCE_MOUSE)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = ev.rawX
                    dragging = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && (!fromMouse || (ev.buttonState and MotionEvent.BUTTON_PRIMARY) != 0) &&
                        Math.abs(ev.rawX - dragStartX) > dp(8)
                    ) {
                        dragging = true
                        // cancela o clique/pressionado do próprio ícone
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL
                        v.onTouchEvent(c)
                        c.recycle()
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        v.elevation = dp(8).toFloat()
                        v.alpha = 0.85f
                    }
                    if (dragging) {
                        v.translationX = ev.rawX - dragStartX
                        true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        finishPinDrag(v, key)
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
    }

    private fun finishPinDrag(v: View, key: String) {
        val center = v.left + v.width / 2f + v.translationX
        val others = tbPinViews.filter { it.second != key }
        var newIdx = 0
        for (o in others) {
            if (o.first.left + o.first.width / 2f < center) newIdx++
        }
        val l = getList("tb").toMutableList()
        val oldVisible = tbPinViews.map { it.second }
        val newVisible = others.map { it.second }.toMutableList()
        newVisible.add(newIdx.coerceIn(0, newVisible.size), key)
        if (newVisible != oldVisible && key in l && others.isNotEmpty()) {
            l.remove(key)
            val dest = if (newIdx < others.size) {
                l.indexOf(others[newIdx].second)
            } else {
                l.indexOf(others.last().second) + 1
            }
            l.add(dest.coerceIn(0, l.size), key)
            setList("tb", l)
            refreshPins()
        } else {
            v.translationX = 0f
            v.elevation = 0f
            v.alpha = 1f
        }
    }

    // ---- janelinha de pré-visualização (passar o mouse no ícone de um app nativo aberto)

    /**
     * Distância da barrinha "app aberto" até o fundo do ícone. Se a barra de tarefas for mais baixa que o ícone
     * (a altura é configurável), o ícone é cortado em cima e embaixo; a barrinha sobe para continuar visível.
     */
    private fun indBottom(slot: Int): Int {
        val clip = maxOf(0, (slot - sdp(cfg.tbHeight)) / 2)
        return clip + dp(2)
    }

    private fun tbHover(v: View, e: () -> PreviewEntry) {
        if (::tbPreview.isInitialized) tbPreview.attach(v, e)
    }

    /** Janelinha de pré-visualização de um app por link (usa a foto tirada ao minimizar quando estiver minimizado). */
    private fun entryWeb(key: String): PreviewEntry {
        val cn = ComponentName.unflattenFromString(key)
        val e = cn?.let { WebApps.find(this, it) }
        val name = if (e != null) AppCustom.label(this, e.cn, e.name) else "App"
        return PreviewEntry(
            name, { e?.let { WebApps.icon(this, it) } }, { webWins[key]?.isOpen == true },
            { w -> webWins[key]?.snapshot(w) },
            {
                closeAll()
                val w = webWins[key]
                if (w != null && w.isOpen) {
                    if (w.isMinimized) w.restore()
                    WindowStack.raise(root, w.layer, winTop)
                } else if (e != null) openWebApp(e)
            },
            { webWins[key]?.close() }
        )
    }

    private fun entryBrowser() = PreviewEntry(
        "Navegador", { browserIcon() }, { browser.isOpen }, { w -> browser.snapshot(w) },
        { closeAll(); browser.show() }, { browser.close() }
    )

    private fun entryFiles() = PreviewEntry(
        "Arquivos", { filesIcon() }, { files.isOpen }, { w -> files.snapshot(w) },
        { closeAll(); files.show() }, { files.close() }
    )

    private fun entryGallery() = PreviewEntry(
        "Fotos", { galleryIcon() }, { gallery.isOpen }, { w -> gallery.snapshot(w) },
        { closeAll(); gallery.show() }, { gallery.close() }
    )

    private fun entryMusic() = PreviewEntry(
        "Música", { musicIcon() }, { musicWin.isOpen }, { w -> musicWin.snapshot(w) },
        { closeAll(); musicWin.show() }, { musicWin.close() }
    )

    private fun entryPc() = PreviewEntry(
        "Configuração do PC", { resources.getDrawable(R.drawable.ic_pc, theme).mutate().also { it.setTint(cText) } },
        { pcWindow.isOpen }, { w -> pcWindow.snapshot(w) },
        { closeAll(); pcWindow.show() }, { pcWindow.close() }
    )

    private fun entrySettings() = PreviewEntry(
        "Configurações", { resources.getDrawable(R.drawable.ic_settings_color, theme) },
        { settingsWindow.isOpen }, { w -> settingsWindow.snapshot(w) },
        { closeAll(); settingsWindow.show() }, { settingsWindow.close() }
    )

    private fun entryApk() = PreviewEntry(
        "Instalar aplicativo", { resources.getDrawable(R.drawable.ic_install, theme).mutate().also { it.setTint(cText) } },
        { apkWindow.isOpen }, { w -> apkWindow.snapshot(w) },
        { closeAll(); apkWindow.show() }, { apkWindow.close() }
    )

    private fun rebuildTaskbar() {
        pinnedRow.removeAllViews()
        tbPinViews.clear()
        val slot = sdp(cfg.tbIcon)
        val gap = sdp(cfg.tbSpace)
        val padA = (slot * 8f / 44f).toInt()
        pinnedRow.addView(startBtn, LinearLayout.LayoutParams(slot, slot))
        val showPill = screenW >= dp(600)
        val onlyIcon = cfg.tbSearchIcon
        val pillH = maxOf(dp(24), minOf(sdp(32), sdp(cfg.tbHeight) - dp(8)))
        val pillW = if (onlyIcon) pillH + sdp(8) else sdp(172)
        if (showPill) {
            searchPill.visibility = View.VISIBLE
            pillText.visibility = if (onlyIcon) View.GONE else View.VISIBLE
            if (::tbWeather.isInitialized) tbWeather.visibility = if (onlyIcon) View.GONE else View.VISIBLE
            searchPill.gravity = if (onlyIcon) Gravity.CENTER else Gravity.CENTER_VERTICAL
            if (onlyIcon) searchPill.setPadding(0, 0, 0, 0) else searchPill.setPadding(dp(10), 0, dp(10), 0)
            val plp = LinearLayout.LayoutParams(pillW, pillH)
            plp.leftMargin = gap + sdp(4)
            plp.rightMargin = sdp(4)
            pinnedRow.addView(searchPill, plp)
        }
        val reserve = 3 * (sdp(cfg.tbTray) + sdp(10)) + sdp(8) + sdp(64) + sdp(36) + sdp(24) + sdp(4) +
            (if (showPill) pillW + sdp(8) else 0)
        val winOpen = ::pcWindow.isInitialized && pcWindow.isOpen
        // só ganha botão extra enquanto estiver aberto E desafixado (fixado, o próprio ícone fixado mostra o estado)
        val browserOpen = ::browser.isInitialized && browser.isOpen && TB_BROWSER !in getList("tb")
        val filesOpen = ::files.isInitialized && files.isOpen && TB_FILES !in getList("tb")
        val apkOpen = ::apkWindow.isInitialized && apkWindow.isOpen
        val galleryOpen = ::gallery.isInitialized && gallery.isOpen && TB_GALLERY !in getList("tb")
        val musicOpen = ::musicWin.isInitialized && musicWin.isOpen && TB_MUSIC !in getList("tb")
        val webOpen = webWins.filter { it.value.isOpen && it.key !in getList("tb") }
        val slots = ((screenW - reserve) / (slot + gap)) - 1 - webOpen.size - (if (winOpen) 1 else 0) - (if (browserOpen) 1 else 0) - (if (filesOpen) 1 else 0) - (if (apkOpen) 1 else 0) - (if (galleryOpen) 1 else 0) - (if (musicOpen) 1 else 0)
        ensureGearPinned()
        ensureBrowserPinned()
        ensureFilesPinned()
        ensureGalleryPinned()
        val keys = getList("tb").filter { tbPresent(it) }.take(maxOf(0, slots))
        for (k in keys) {
            if (k == TB_GEAR) {
                addGearButton(slot, gap, padA)
                continue
            }
            if (k == TB_BROWSER) {
                addBrowserPinned(slot, gap, padA)
                continue
            }
            if (k == TB_FILES) {
                addFilesPinned(slot, gap, padA)
                continue
            }
            if (k == TB_GALLERY) {
                addGalleryPinned(slot, gap, padA)
                continue
            }
            if (k == TB_PERF) {
                addPerfPinned(slot, gap, padA)
                continue
            }
            if (k == TB_MUSIC) {
                addMusicPinned(slot, gap, padA)
                continue
            }
            val a = appFor(k) ?: continue
            val iv = ImageView(this)
            iv.setImageDrawable(ic(a))
            iv.setPadding(padA, padA, padA, padA)
            iv.background = rip(Color.TRANSPARENT, 6)
            iv.setOnClickListener { if (!rightClickRecent()) launch(a.cn) }
            pinTouch(iv, a)
            val pinKey = a.cn.flattenToString()
            if (WebApps.find(this, a.cn) != null) tbHover(iv) { entryWeb(pinKey) }
            tbPinViews.add(Pair(iv, pinKey))
            val lp = LinearLayout.LayoutParams(slot, slot)
            lp.leftMargin = gap
            pinnedRow.addView(iv, lp)
        }
        if (winOpen) addWindowButton(slot, gap, padA)
        if (browserOpen) addBrowserButton(slot, gap, padA)
        if (filesOpen) addFilesButton(slot, gap, padA)
        if (galleryOpen) addGalleryButton(slot, gap, padA)
        if (musicOpen) addMusicButton(slot, gap, padA)
        if (apkOpen) addApkButton(slot, gap, padA)
        for ((k, w) in webOpen) addWebAppButton(k, w, slot, gap, padA)
        if (::tbPreview.isInitialized) tbPreview.refresh()
    }

    /** Navegador fixado: abre, restaura ou minimiza; arrasta para reordenar; botão direito tem as opções. */
    private fun addBrowserPinned(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(browserIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        if (browser.isOpen) {
            val ind = View(this)
            ind.background = rounded(cAccent, 2)
            val ilp = FrameLayout.LayoutParams(
                dp(if (browser.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
            ilp.bottomMargin = indBottom(slot)
            wrap.addView(ind, ilp)
        }
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                if (browser.isOpen) browser.toggleFromTaskbar() else browser.show()
            }
        }
        pinTouch(wrap, TB_BROWSER) { x, y -> browserPinnedMenu(x, y) }
        tbHover(wrap) { entryBrowser() }
        tbPinViews.add(Pair(wrap, TB_BROWSER))
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun browserPinnedMenu(x: Int, y: Int) {
        val items = ArrayList<MenuItem>()
        if (!browser.isOpen) {
            items.add(MenuItem("Abrir", R.drawable.ic_open, action = { browser.show() }))
        } else if (browser.isMinimized) {
            items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { browser.restore() }))
        } else {
            items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { browser.minimize() }))
        }
        items.add(MenuItem("Desafixar da barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_BROWSER) }))
        items.addAll(browserMenuItems())
        items.add(
            MenuItem("Mover para a esquerda", enabled = canMoveTb(TB_BROWSER, -1), action = { moveTb(TB_BROWSER, -1) })
        )
        items.add(
            MenuItem("Mover para a direita", enabled = canMoveTb(TB_BROWSER, 1), action = { moveTb(TB_BROWSER, 1) })
        )
        if (browser.isOpen) items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { browser.close() }))
        menu.show(items, x, y)
    }

    /** Botão do navegador na barra de tarefas (existe enquanto a janela estiver aberta, inclusive minimizada). */
    private fun addBrowserButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(browserIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(
            dp(if (browser.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                browser.toggleFromTaskbar()
            }
        }
        tbHover(wrap) { entryBrowser() }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            if (browser.isMinimized) {
                items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { browser.restore() }))
            } else {
                items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { browser.minimize() }))
            }
            items.add(MenuItem("Fixar na barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_BROWSER) }))
            items.addAll(browserMenuItems())
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { browser.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    /** Gerenciador de arquivos fixado: abre, restaura ou minimiza; arrasta para reordenar; botão direito tem as opções. */
    private fun addFilesPinned(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(filesIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        if (files.isOpen) {
            val ind = View(this)
            ind.background = rounded(cAccent, 2)
            val ilp = FrameLayout.LayoutParams(
                dp(if (files.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
            ilp.bottomMargin = indBottom(slot)
            wrap.addView(ind, ilp)
        }
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                if (files.isOpen) files.toggleFromTaskbar() else files.show()
            }
        }
        pinTouch(wrap, TB_FILES) { x, y -> filesPinnedMenu(x, y) }
        tbHover(wrap) { entryFiles() }
        tbPinViews.add(Pair(wrap, TB_FILES))
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun filesPinnedMenu(x: Int, y: Int) {
        val items = ArrayList<MenuItem>()
        if (!files.isOpen) {
            items.add(MenuItem("Abrir", R.drawable.ic_open, action = { files.show() }))
        } else if (files.isMinimized) {
            items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { files.restore() }))
        } else {
            items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { files.minimize() }))
        }
        items.add(MenuItem("Desafixar da barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_FILES) }))
        items.addAll(filesMenuItems())
        items.add(
            MenuItem("Mover para a esquerda", enabled = canMoveTb(TB_FILES, -1), action = { moveTb(TB_FILES, -1) })
        )
        items.add(
            MenuItem("Mover para a direita", enabled = canMoveTb(TB_FILES, 1), action = { moveTb(TB_FILES, 1) })
        )
        if (files.isOpen) items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { files.close() }))
        menu.show(items, x, y)
    }

    /** Botão do gerenciador de arquivos na barra de tarefas (existe enquanto a janela estiver aberta, inclusive minimizada). */
    private fun addFilesButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(filesIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(
            dp(if (files.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                files.toggleFromTaskbar()
            }
        }
        tbHover(wrap) { entryFiles() }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            if (files.isMinimized) {
                items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { files.restore() }))
            } else {
                items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { files.minimize() }))
            }
            items.add(MenuItem("Fixar na barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_FILES) }))
            items.addAll(filesMenuItems())
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { files.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    /** Galeria fixada: abre, restaura ou minimiza; arrasta para reordenar; botão direito tem as opções. */
    private fun addGalleryPinned(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(galleryIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        if (gallery.isOpen) {
            val ind = View(this)
            ind.background = rounded(cAccent, 2)
            val ilp = FrameLayout.LayoutParams(
                dp(if (gallery.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
            ilp.bottomMargin = indBottom(slot)
            wrap.addView(ind, ilp)
        }
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                if (gallery.isOpen) gallery.toggleFromTaskbar() else gallery.show()
            }
        }
        pinTouch(wrap, TB_GALLERY) { x, y -> galleryPinnedMenu(x, y) }
        tbHover(wrap) { entryGallery() }
        tbPinViews.add(Pair(wrap, TB_GALLERY))
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun galleryPinnedMenu(x: Int, y: Int) {
        val items = ArrayList<MenuItem>()
        if (!gallery.isOpen) {
            items.add(MenuItem("Abrir", R.drawable.ic_open, action = { gallery.show() }))
        } else if (gallery.isMinimized) {
            items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { gallery.restore() }))
        } else {
            items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { gallery.minimize() }))
        }
        items.add(MenuItem("Desafixar da barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_GALLERY) }))
        items.addAll(galleryMenuItems())
        items.add(
            MenuItem("Mover para a esquerda", enabled = canMoveTb(TB_GALLERY, -1), action = { moveTb(TB_GALLERY, -1) })
        )
        items.add(
            MenuItem("Mover para a direita", enabled = canMoveTb(TB_GALLERY, 1), action = { moveTb(TB_GALLERY, 1) })
        )
        if (gallery.isOpen) items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { gallery.close() }))
        menu.show(items, x, y)
    }

    /** Botão da galeria de fotos na barra de tarefas (só enquanto a janela estiver aberta e desafixada). */
    private fun addGalleryButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(galleryIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(
            dp(if (gallery.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                gallery.toggleFromTaskbar()
            }
        }
        tbHover(wrap) { entryGallery() }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            if (gallery.isMinimized) {
                items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { gallery.restore() }))
            } else {
                items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { gallery.minimize() }))
            }
            items.add(MenuItem("Fixar na barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_GALLERY) }))
            items.addAll(galleryMenuItems())
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { gallery.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    /** Reprodutor de música fixado: abre, restaura ou minimiza; arrasta para reordenar; botão direito tem as opções. */
    private fun addMusicPinned(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(musicIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        if (musicWin.isOpen) {
            val ind = View(this)
            ind.background = rounded(cAccent, 2)
            val ilp = FrameLayout.LayoutParams(
                dp(if (musicWin.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
            ilp.bottomMargin = indBottom(slot)
            wrap.addView(ind, ilp)
        }
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                if (musicWin.isOpen) musicWin.toggleFromTaskbar() else musicWin.show()
            }
        }
        pinTouch(wrap, TB_MUSIC) { x, y -> musicPinnedMenu(x, y) }
        tbHover(wrap) { entryMusic() }
        tbPinViews.add(Pair(wrap, TB_MUSIC))
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun musicPinnedMenu(x: Int, y: Int) {
        val items = ArrayList<MenuItem>()
        if (!musicWin.isOpen) {
            items.add(MenuItem("Abrir", R.drawable.ic_open, action = { musicWin.show() }))
        } else if (musicWin.isMinimized) {
            items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { musicWin.restore() }))
        } else {
            items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { musicWin.minimize() }))
        }
        items.add(MenuItem("Desafixar da barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_MUSIC) }))
        items.addAll(musicMenuItems())
        items.add(
            MenuItem("Mover para a esquerda", enabled = canMoveTb(TB_MUSIC, -1), action = { moveTb(TB_MUSIC, -1) })
        )
        items.add(
            MenuItem("Mover para a direita", enabled = canMoveTb(TB_MUSIC, 1), action = { moveTb(TB_MUSIC, 1) })
        )
        if (musicWin.isOpen) items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { musicWin.close() }))
        menu.show(items, x, y)
    }

    /** Botão do reprodutor de música na barra de tarefas (só enquanto a janela estiver aberta e desafixada). */
    private fun addMusicButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(musicIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(
            dp(if (musicWin.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                musicWin.toggleFromTaskbar()
            }
        }
        tbHover(wrap) { entryMusic() }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            if (musicWin.isMinimized) {
                items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { musicWin.restore() }))
            } else {
                items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { musicWin.minimize() }))
            }
            items.add(MenuItem("Fixar na barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_MUSIC) }))
            items.addAll(musicMenuItems())
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { musicWin.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    // ------------------------------------------------------------ monitor de desempenho

    /** Chamado pela tela Configurações > Monitor de desempenho para atualizar a prévia do ícone. */
    var perfPanelRefresh: (() -> Unit)? = null

    fun perfIcon(): Drawable =
        AppCustom.icon(this, AppCustom.PERF) ?: resources.getDrawable(R.drawable.ic_perf_color, theme)

    fun hasPerfIcon(): Boolean = AppCustom.hasIcon(this, AppCustom.PERF)

    fun pickPerfIcon() = pickAppIcon(AppCustom.PERF)

    fun resetPerfIcon() {
        AppCustom.resetIcon(this, AppCustom.PERF)
        afterAppCustomized()
    }

    fun perfPinned(): Boolean = TB_PERF in getList("tb")

    fun setPerfPinned(on: Boolean) {
        if (on != perfPinned()) toggle("tb", TB_PERF)
    }

    /** Liga/desliga o painel. Pede a permissão "Exibir sobre outros apps" se ainda não houver. */
    fun setPerfOn(on: Boolean) {
        if (on && !Settings.canDrawOverlays(this)) {
            toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
                )
            } catch (e: Exception) {
            }
            return
        }
        PerfOverlayService.setOn(this, on)
    }

    /** Monitor de desempenho fixado: clique liga/desliga o painel; arrasta para reordenar; botão direito tem as opções. */
    private fun addPerfPinned(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(perfIcon())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        if (PerfOverlayService.isOn(this)) {
            val ind = View(this)
            ind.background = rounded(cAccent, 2)
            val ilp = FrameLayout.LayoutParams(dp(14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            ilp.bottomMargin = indBottom(slot)
            wrap.addView(ind, ilp)
        }
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                setPerfOn(!PerfOverlayService.isOn(this))
            }
        }
        pinTouch(wrap, TB_PERF) { x, y -> perfPinnedMenu(x, y) }
        tbPinViews.add(Pair(wrap, TB_PERF))
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun perfPinnedMenu(x: Int, y: Int) {
        val items = ArrayList<MenuItem>()
        val on = PerfOverlayService.isOn(this)
        items.add(
            MenuItem(
                if (on) "Fechar painel" else "Abrir painel",
                if (on) R.drawable.ic_close else R.drawable.ic_open,
                action = { setPerfOn(!on) }
            )
        )
        items.add(MenuItem("Desafixar da barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", TB_PERF) }))
        items.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickPerfIcon() }))
        if (hasPerfIcon()) {
            items.add(MenuItem("Restaurar ícone", R.drawable.ic_refresh, action = { resetPerfIcon() }))
        }
        items.add(
            MenuItem("Mover para a esquerda", enabled = canMoveTb(TB_PERF, -1), action = { moveTb(TB_PERF, -1) })
        )
        items.add(
            MenuItem("Mover para a direita", enabled = canMoveTb(TB_PERF, 1), action = { moveTb(TB_PERF, 1) })
        )
        menu.show(items, x, y)
    }

    /** Engrenagem de Configurações entre os apps fixados: arrasta ou usa o menu para mover; não tem "desafixar". */
    private fun addGearButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_settings_color)
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        if (::settingsWindow.isInitialized && settingsWindow.isOpen) {
            // barrinha embaixo do ícone: Configurações está aberta
            val ind = View(this)
            ind.background = rounded(cAccent, 2)
            val ilp = FrameLayout.LayoutParams(dp(14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            ilp.bottomMargin = indBottom(slot)
            wrap.addView(ind, ilp)
        }
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                if (settingsWindow.isOpen) {
                    settingsWindow.toggleFromTaskbar()
                } else {
                    closeAll()
                    settingsWindow.show()
                }
            }
        }
        pinTouch(wrap, TB_GEAR) { x, y -> gearContextMenu(x, y) }
        tbHover(wrap) { entrySettings() }
        tbPinViews.add(Pair(wrap, TB_GEAR))
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun gearContextMenu(x: Int, y: Int) {
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Abrir Configurações", R.drawable.ic_settings, action = {
            closeAll()
            settingsWindow.show()
        }))
        items.add(
            MenuItem("Mover para a esquerda", enabled = canMoveTb(TB_GEAR, -1), action = { moveTb(TB_GEAR, -1) })
        )
        items.add(
            MenuItem("Mover para a direita", enabled = canMoveTb(TB_GEAR, 1), action = { moveTb(TB_GEAR, 1) })
        )
        menu.show(items, x, y)
    }

    /** Botão da janela "Configuração do PC" na barra de tarefas (existe enquanto a janela estiver aberta). */
    private fun addWindowButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_pc)
        iv.setColorFilter(tbFg())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        // indicador de janela aberta: barra maior = à frente, menor = minimizada
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(
            dp(if (pcWindow.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                pcWindow.toggleFromTaskbar()
            }
        }
        tbHover(wrap) { entryPc() }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            if (pcWindow.isMinimized) {
                items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { pcWindow.restore() }))
            } else {
                items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { pcWindow.minimize() }))
            }
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { pcWindow.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    /** Botão do instalador de APK na barra de tarefas (existe enquanto a janela estiver aberta). */
    private fun addApkButton(slot: Int, gap: Int, padA: Int) {
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_install)
        iv.setColorFilter(tbFg())
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(dp(14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                apkWindow.show()
            }
        }
        tbHover(wrap) { entryApk() }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { apkWindow.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun rebuildDesktop() {
        desktopAdapter.items = getList("dk").mapNotNull { appFor(it) }
        val valid = desktopAdapter.items.map { it.cn.flattenToString() }.toSet()
        if (selectedKeys.retainAll(valid)) desktopAdapter.selected = HashSet(selectedKeys)
        if (dkPos.keys.retainAll(getList("dk").toSet())) saveDkPos()
        commitNextLayout = true
        rebuildDesktopViews()
    }

    private fun buildStartPanel() {
        val h = minOf(dp(540), (resources.displayMetrics.heightPixels * 0.72f).toInt())
        startPanel = LinearLayout(this)
        startPanel.orientation = LinearLayout.VERTICAL
        startPanel.background = rounded(cPanel, 12)
        startPanel.setPadding(dp(16), dp(16), dp(16), dp(8))
        startPanel.visibility = View.GONE
        startPanel.isClickable = true
        startPanel.tag = CursorController.NOHAND
        startPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), h, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = dp(8)
        startHost = FrameLayout(this)
        startHost.clipChildren = false
        startHost.addView(startPanel, lp)

        searchBox = EditText(this)
        searchBox.hint = "Digite aqui para pesquisar"
        searchBox.setHintTextColor(cSub)
        searchBox.setTextColor(cText)
        searchBox.textSize = 14f
        searchBox.background = rounded(cTile, 20)
        searchBox.setPadding(dp(14), 0, dp(84), 0)
        searchBox.setSingleLine(true)
        searchBox.imeOptions = EditorInfo.IME_ACTION_DONE
        searchBox.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        searchBox.compoundDrawablePadding = dp(8)
        searchBox.compoundDrawableTintList = ColorStateList.valueOf(cText)
        val searchWrap = FrameLayout(this)
        searchWrap.addView(searchBox, FrameLayout.LayoutParams(MATCH, MATCH))
        weatherChip = TextView(this)
        weatherChip.setTextColor(cText)
        weatherChip.textSize = 13f
        weatherChip.gravity = Gravity.CENTER
        weatherChip.setPadding(dp(8), 0, dp(8), 0)
        weatherChip.background = rip(Color.TRANSPARENT, 14)
        weatherChip.visibility = View.GONE
        weatherChip.setOnClickListener { toggleWeather() }
        val wlp = FrameLayout.LayoutParams(WRAP, dp(32), Gravity.END or Gravity.CENTER_VERTICAL)
        wlp.rightMargin = dp(6)
        searchWrap.addView(weatherChip, wlp)
        startPanel.addView(searchWrap, LinearLayout.LayoutParams(MATCH, dp(40)))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        searchBox.setOnEditorActionListener { _, _, _ ->
            startAdapter.items.firstOrNull()?.let { openStartItem(it) }
            true
        }

        weatherCard = LinearLayout(this)
        weatherCard.orientation = LinearLayout.VERTICAL
        weatherCard.background = rounded(cTile, 10)
        weatherCard.setPadding(dp(12), dp(10), dp(12), dp(10))
        weatherCard.visibility = View.GONE
        startPanel.addView(weatherCard, lpTop(10))

        startPanel.addView(sectionLabel("Todos os aplicativos"), lpTop(12))
        startAdapter = AppAdapter(emptyList(), 40, 11f, true)
        startGrid = GridView(this)
        startGrid.numColumns = 4
        startGrid.setSelector(ColorDrawable(Color.TRANSPARENT))
        startGrid.isVerticalScrollBarEnabled = false
        startGrid.adapter = startAdapter
        startGrid.setOnItemClickListener { _, _, pos, _ ->
            if (!rightClickRecent()) openStartItem(startAdapter.items[pos])
        }
        startGrid.setOnTouchListener { _, ev ->
            if (isRightClick(ev)) {
                val pos = startGrid.pointToPosition(ev.x.toInt(), ev.y.toInt())
                if (pos >= 0 && pos < startAdapter.items.size) {
                    appContextMenu(startAdapter.items[pos], ev.rawX.toInt(), ev.rawY.toInt())
                }
                true
            } else {
                false
            }
        }
        startPanel.addView(startGrid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val line = View(this)
        line.setBackgroundColor(cLine)
        val llp = LinearLayout.LayoutParams(MATCH, dp(1))
        llp.topMargin = dp(4)
        startPanel.addView(line, llp)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL

        // perfil (foto + nome): toque para editar
        val profile = LinearLayout(this)
        profile.orientation = LinearLayout.HORIZONTAL
        profile.gravity = Gravity.CENTER_VERTICAL
        profile.background = rip(Color.TRANSPARENT, 6)
        profile.isClickable = true
        profile.setOnClickListener {
            closeAll()
            profileMenu()
        }

        val avatarBox = FrameLayout(this)
        userInitial = TextView(this)
        userInitial.gravity = Gravity.CENTER
        userInitial.setTextColor(Color.BLACK)
        userInitial.textSize = 13f
        userInitial.typeface = Typeface.DEFAULT_BOLD
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(cAccent)
        userInitial.background = oval
        avatarBox.addView(userInitial, FrameLayout.LayoutParams(MATCH, MATCH))
        userPhoto = ImageView(this)
        userPhoto.scaleType = ImageView.ScaleType.CENTER_CROP
        userPhoto.outlineProvider = ViewOutlineProvider.BACKGROUND
        userPhoto.background = oval.constantState?.newDrawable()?.mutate()
        userPhoto.clipToOutline = true
        userPhoto.visibility = View.GONE
        avatarBox.addView(userPhoto, FrameLayout.LayoutParams(MATCH, MATCH))
        val ablp = LinearLayout.LayoutParams(dp(30), dp(30))
        ablp.leftMargin = dp(2)
        profile.addView(avatarBox, ablp)

        userNameView = TextView(this)
        userNameView.setTextColor(cText)
        userNameView.textSize = 13f
        userNameView.maxLines = 1
        userNameView.ellipsize = TextUtils.TruncateAt.END
        val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        nlp.leftMargin = dp(10)
        profile.addView(userNameView, nlp)
        bar.addView(profile, LinearLayout.LayoutParams(0, MATCH, 1f))
        refreshProfile()

        bar.addView(
            iconBtn(R.drawable.ic_lock) {
                openLockScreen()
            },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        bar.addView(
            iconBtn(R.drawable.ic_settings_color, tint = false) {
                closeAll()
                settingsWindow.show()
            },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        startPanel.addView(bar, LinearLayout.LayoutParams(MATCH, dp(44)))
    }

    // ------------------------------------------------------------------- perfil

    private fun userName(): String =
        (prefs.getString("userName", null) ?: "").trim().ifEmpty { "Usuário" }

    private fun refreshProfile() {
        if (!::userNameView.isInitialized) return
        val n = userName()
        userNameView.text = n
        userInitial.text = n.take(1).uppercase()
        val f = File(filesDir, "avatar.png")
        if (prefs.getBoolean("userHasPhoto", false) && f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            if (bmp != null) {
                userPhoto.setImageBitmap(bmp)
                userPhoto.visibility = View.VISIBLE
                if (::settingsWindow.isInitialized) settingsWindow.refresh()
                return
            }
        }
        userPhoto.setImageDrawable(null)
        userPhoto.visibility = View.GONE
        if (::settingsWindow.isInitialized) settingsWindow.refresh()
    }

    private fun profileMenu() {
        val hasPhoto = userPhoto.visibility == View.VISIBLE
        val labels = if (hasPhoto) arrayOf("Editar nome", "Alterar foto", "Remover foto")
        else arrayOf("Editar nome", "Escolher foto")
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Perfil")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> editNameDialog()
                    1 -> pickAvatar()
                    2 -> {
                        File(filesDir, "avatar.png").delete()
                        prefs.edit().putBoolean("userHasPhoto", false).apply()
                        refreshProfile()
                    }
                }
            }
            .show()
    }

    private fun editNameDialog() {
        val et = EditText(this)
        et.setSingleLine(true)
        et.filters = arrayOf(InputFilter.LengthFilter(24))
        et.setText(userName())
        et.setSelection(et.text.length)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        val d = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Nome do usuário")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                prefs.edit().putString("userName", et.text.toString().trim()).apply()
                refreshProfile()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
    }

    private fun pickAvatar() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_AVATAR)
        } catch (e: Exception) {
            Toast.makeText(this, "Nenhum seletor de arquivos encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    /** Lê a imagem, recorta o quadrado central e reduz para size x size. */
    private fun decodeSquare(uri: Uri, size: Int): Bitmap? {
        val bmp: Bitmap = if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val sc = minOf(1f, 512f / maxOf(info.size.width, info.size.height))
                decoder.setTargetSize(
                    maxOf(1, (info.size.width * sc).toInt()),
                    maxOf(1, (info.size.height * sc).toInt())
                )
            }
        } else {
            val o = BitmapFactory.Options()
            o.inSampleSize = 4
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                ?: return null
        }
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, size, size, true)
    }

    private fun sliderRow(icon: Int, seek: SeekBar): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(cText)
        row.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = dp(8)
        row.addView(seek, lp)
        return row
    }

    private fun buildQuickPanel() {
        quickPanel = LinearLayout(this)
        quickPanel.orientation = LinearLayout.VERTICAL
        quickPanel.background = rounded(cPanel, 12)
        quickPanel.setPadding(dp(16), dp(16), dp(16), dp(12))
        quickPanel.visibility = View.GONE
        quickPanel.isClickable = true
        quickPanel.tag = CursorController.NOHAND
        quickPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(quickPanel, lp)

        tiles.clear()
        tiles.add(Tile("Wi-Fi", R.drawable.ic_wifi, true, { wifiOn() }, {
            if (Build.VERSION.SDK_INT >= 29) {
                safeStart(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            } else {
                safeStart(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        }))
        tiles.add(Tile("Bluetooth", R.drawable.ic_bluetooth, true, { btOn() }, {
            safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }))
        tiles.add(Tile("Modo avião", R.drawable.ic_airplane, true, {
            Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        }, {
            safeStart(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
        }))
        tiles.add(Tile("Lanterna", R.drawable.ic_flashlight, false, { torchOn }, { toggleTorch() }))
        tiles.add(Tile("Rotação", R.drawable.ic_rotate, false, {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        }, { toggleRotation() }))
        tiles.add(Tile("Economia", R.drawable.ic_battery, true, {
            (getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        }, {
            safeStart(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }))
        tiles.add(Tile("Não perturbe", R.drawable.ic_moon, true, {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
        }, {
            safeStart(Intent(Settings.ACTION_SOUND_SETTINGS))
        }))
        tiles.add(Tile("Localização", R.drawable.ic_location, true, {
            Build.VERSION.SDK_INT >= 28 &&
                (getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
        }, {
            safeStart(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }))
        tiles.add(Tile("Hotspot", R.drawable.ic_hotspot, true, { false }, {
            safeStart(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }))

        val tw = (panelW() - dp(32)) / 3 - dp(8)
        val g = GridLayout(this)
        g.columnCount = 3
        for (t in tiles) {
            val v = LinearLayout(this)
            v.orientation = LinearLayout.VERTICAL
            v.gravity = Gravity.CENTER
            v.setOnClickListener {
                t.click()
                if (t.closes) closeAll() else refreshQuick()
            }
            val iv = ImageView(this)
            iv.setImageResource(t.icon)
            val tv = TextView(this)
            tv.text = t.label
            tv.textSize = 11f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            v.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tlp = LinearLayout.LayoutParams(WRAP, WRAP)
            tlp.topMargin = dp(4)
            v.addView(tv, tlp)
            t.view = v
            t.iconView = iv
            t.textView = tv
            val glp = GridLayout.LayoutParams()
            glp.width = tw
            glp.height = dp(64)
            glp.setMargins(dp(4), dp(4), dp(4), dp(4))
            g.addView(v, glp)
        }
        quickPanel.addView(g, LinearLayout.LayoutParams(MATCH, WRAP))

        // cartão de música: só aparece com algum app tocando (entre os botões e o brilho)
        quickMusic = QuickMusicCard(this)
        quickMusic.applyColors(cText, cTile, cAccent)
        quickPanel.addView(quickMusic, lpTop(10))

        brightSeek = SeekBar(this)
        brightSeek.max = 255
        brightSeek.progressTintList = ColorStateList.valueOf(cAccent)
        brightSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        brightSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (Settings.System.canWrite(this@MainActivity)) {
                    Settings.System.putInt(
                        contentResolver,
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    )
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, maxOf(p, 1))
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                if (!Settings.System.canWrite(this@MainActivity)) {
                    toast("Permita \"Modificar configurações do sistema\" para controlar o brilho")
                    safeStart(
                        Intent(
                            Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + packageName)
                        )
                    )
                }
            }

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        quickPanel.addView(sliderRow(R.drawable.ic_brightness, brightSeek), lpTop(10))

        volSeek = SeekBar(this)
        volSeek.progressTintList = ColorStateList.valueOf(cAccent)
        volSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                } catch (e: Exception) {
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        quickPanel.addView(sliderRow(R.drawable.ic_volume, volSeek), lpTop(6))

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        batText = TextView(this)
        batText.setTextColor(cText)
        batText.textSize = 13f
        batText.compoundDrawablePadding = dp(6)
        batText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_battery, 0, 0, 0)
        batText.compoundDrawableTintList = ColorStateList.valueOf(cText)
        foot.addView(batText, LinearLayout.LayoutParams(0, WRAP, 1f))
        foot.addView(
            iconBtn(R.drawable.ic_web_install) { openWebAppInstaller() },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        foot.addView(
            iconBtn(R.drawable.ic_settings_color, tint = false) { safeStart(Intent(Settings.ACTION_SETTINGS)) },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        quickPanel.addView(foot, lpTop(8))
    }

    private fun buildCalPanel() {
        calPanel = LinearLayout(this)
        calPanel.orientation = LinearLayout.VERTICAL
        calPanel.background = rounded(cPanel, 12)
        calPanel.setPadding(dp(16), dp(16), dp(16), dp(12))
        calPanel.visibility = View.GONE
        calPanel.isClickable = true
        calPanel.tag = CursorController.NOHAND
        calPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(calPanel, lp)

        calDate = TextView(this)
        calDate.setTextColor(cText)
        calDate.textSize = 16f
        calDate.typeface = Typeface.DEFAULT_BOLD
        calPanel.addView(calDate, lpTop(0))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        calTitle = TextView(this)
        calTitle.setTextColor(cSub)
        calTitle.textSize = 13f
        nav.addView(calTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        nav.addView(iconBtn(R.drawable.ic_chevron_up) { shiftMonth(-1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        nav.addView(iconBtn(R.drawable.ic_chevron_down) { shiftMonth(1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        calPanel.addView(nav, lpTop(8))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        for (d in listOf("D", "S", "T", "Q", "Q", "S", "S")) {
            val tv = TextView(this)
            tv.text = d
            tv.gravity = Gravity.CENTER
            tv.setTextColor(cSub)
            tv.textSize = 11f
            head.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        calPanel.addView(head, lpTop(4))

        calGrid = GridLayout(this)
        calGrid.columnCount = 7
        calPanel.addView(calGrid, lpTop(2))
    }

    private fun shiftMonth(d: Int) {
        calShown.add(Calendar.MONTH, d)
        buildCalGrid()
    }

    private fun showCalendar() {
        calShown.timeInMillis = System.currentTimeMillis()
        calDate.text = SimpleDateFormat("EEEE, d 'de' MMMM", ptBR)
            .format(Date())
            .replaceFirstChar { it.uppercase() }
        buildCalGrid()
    }

    private fun buildCalGrid() {
        calGrid.removeAllViews()
        calTitle.text = SimpleDateFormat("MMMM 'de' yyyy", ptBR)
            .format(calShown.time)
            .replaceFirstChar { it.uppercase() }
        val c = calShown.clone() as Calendar
        c.set(Calendar.DAY_OF_MONTH, 1)
        val offset = c.get(Calendar.DAY_OF_WEEK) - 1
        val days = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = Calendar.getInstance()
        val isThisMonth = today.get(Calendar.YEAR) == c.get(Calendar.YEAR) &&
            today.get(Calendar.MONTH) == c.get(Calendar.MONTH)
        val cell = (panelW() - dp(32)) / 7
        for (i in 0 until 42) {
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.textSize = 13f
            tv.setTextColor(cText)
            val day = i - offset + 1
            if (day in 1..days) {
                tv.text = day.toString()
                if (isThisMonth && day == today.get(Calendar.DAY_OF_MONTH)) {
                    val oval = GradientDrawable()
                    oval.shape = GradientDrawable.OVAL
                    oval.setColor(cAccent)
                    tv.background = oval
                    tv.setTextColor(Color.BLACK)
                }
            }
            val glp = GridLayout.LayoutParams()
            glp.width = cell
            glp.height = cell
            calGrid.addView(tv, glp)
        }
    }

    // ----------------------------------------------------------------- panels

    /** Deixa a camada do Menu Iniciar exatamente sobre a área do desktop (mesmo espaço em que o painel era posicionado). */
    private fun syncStartHost() {
        if (!::startHost.isInitialized || !::desktopFrame.isInitialized || !::root.isInitialized) return
        if (startHost.parent !== root || desktopFrame.width == 0 || root.width == 0) return
        val d = IntArray(2)
        val r = IntArray(2)
        desktopFrame.getLocationOnScreen(d)
        root.getLocationOnScreen(r)
        val l = d[0] - r[0]
        val t = d[1] - r[1]
        val rt = root.width - l - desktopFrame.width
        val b = root.height - t - desktopFrame.height
        val lp = startHost.layoutParams as FrameLayout.LayoutParams
        if (lp.leftMargin == l && lp.topMargin == t && lp.rightMargin == rt && lp.bottomMargin == b) return
        lp.setMargins(l, t, rt, b)
        startHost.layoutParams = lp
    }

    /** front = true: painel na camada da frente (por cima das janelas). false: dentro do overlay (atrás das janelas, só na prévia das Configurações). */
    private fun placeStartPanel(front: Boolean) {
        if (!::startPanel.isInitialized || !::startHost.isInitialized || !::overlay.isInitialized) return
        val target: ViewGroup = if (front) startHost else overlay
        if (startPanel.parent === target) return
        val lp = startPanel.layoutParams
        (startPanel.parent as? ViewGroup)?.removeView(startPanel)
        target.addView(startPanel, lp)
    }

    private fun openStart() {
        showPanel(startPanel)
    }

    private var startPreviewing = false

    /**
     * Prévia ao vivo do Menu Iniciar enquanto ele é personalizado em Configurações: o painel fica
     * aberto atrás da janela e cada slider/botão já chama [applyPrefs], então muda em tempo real.
     */
    fun previewStartMenu(on: Boolean) {
        if (!::startPanel.isInitialized || !::overlay.isInitialized) return
        if (on) {
            startPreviewing = true
            placeStartPanel(false)
            for (x in listOf<View>(quickPanel, calPanel, searchPanel, notifPanel, volPanel, infoPanel)) {
                x.visibility = View.GONE
            }
            if (::music.isInitialized) music.panel.visibility = View.GONE
            startPanel.visibility = View.VISIBLE
            startPanel.alpha = 1f
            startPanel.translationY = 0f
            overlay.visibility = View.VISIBLE
            applyPrefs()
        } else if (startPreviewing) {
            startPreviewing = false
            closeAll()
            placeStartPanel(true)
        }
    }

    /** (espaço no topo, espaço embaixo) ocupado pela barra de tarefas, em px. */
    fun taskbarInsetsPx(): Pair<Int, Int> {
        if (!::taskbar.isInitialized || cfg.tbHidden || taskbar.visibility != View.VISIBLE) return Pair(0, 0)
        val h = if (taskbar.height > 0) taskbar.height else dp(48)
        return if (cfg.tbPos == 1) Pair(h, 0) else Pair(0, h)
    }

    // ------------------------------------------------------------ system state

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun btOn(): Boolean = try {
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    } catch (e: Exception) {
        false
    }

    private fun updateTray() {
        if (!::wifiIcon.isInitialized) return
        wifiIcon.alpha = if (wifiOn()) 1f else 0.4f
    }

    private fun refreshTiles() {
        for (t in tiles) {
            val on = try {
                t.active()
            } catch (e: Exception) {
                false
            }
            t.view?.background = rip(if (on) cAccent else cTile, 8)
            val fg = if (on) Color.BLACK else cText
            t.iconView?.setColorFilter(fg)
            t.textView?.setTextColor(fg)
        }
        updateTray()
    }

    private fun refreshQuick() {
        refreshTiles()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            volSeek.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volSeek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (e: Exception) {
        }
        try {
            brightSeek.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
        }
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (sc > 0 && lvl >= 0) lvl * 100 / sc else 0
            batText.text = "$pct%" + (if (chg) " · carregando" else "")
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("Lanterna indisponível")
                return
            }
            cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            toast("Lanterna indisponível")
        }
    }

    private fun toggleRotation() {
        if (Settings.System.canWrite(this)) {
            val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
        } else {
            toast("Permita \"Modificar configurações do sistema\" para esta opção")
            safeStart(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }
    }

    // ================================================================== novo: tema e preferências

    private fun loadTheme() {
        light = cfg.theme == 1
        cAccent = cfg.accent
        if (light) {
            cText = Color.parseColor("#1F1F1F")
            cTile = Color.parseColor("#14000000")
            cSub = Color.parseColor("#99000000")
            cLine = Color.parseColor("#22000000")
            ripC = Color.parseColor("#22000000")
            cPanel = Color.parseColor("#F2F3F3F3")
            cTaskbar = Color.parseColor("#E6F3F3F3")
        } else {
            cText = Color.WHITE
            cTile = Color.parseColor("#26FFFFFF")
            cSub = Color.parseColor("#B3FFFFFF")
            cLine = Color.parseColor("#22FFFFFF")
            ripC = Color.parseColor("#44FFFFFF")
            cPanel = Color.parseColor("#F2202020")
            cTaskbar = Color.parseColor("#E61C1C1C")
        }
        if (::quickMusic.isInitialized) quickMusic.applyColors(cText, cTile, cAccent)
    }

    private fun sdp(v: Int): Int =
        (v * resources.displayMetrics.density * cfg.tbScale / 100f + 0.5f).toInt()

    private fun argb(alpha: Int, rgb: Int): Int = (alpha.coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)

    private fun tbFg(): Int = if (light && cfg.tbBg != 2) Color.parseColor("#1F1F1F") else Color.WHITE

    private fun tbBase(): Int = if (light) 0xF3F3F3 else 0x1C1C1C

    private fun panelBase(): Int = if (light) 0xF3F3F3 else 0x202020

    private fun panelBackground(host: View, alphaPct: Int, radiusDp: Int, glass: Boolean): Drawable {
        val al = alphaPct * 255 / 100
        return if (glass) {
            GlassDrawable(host, argb((al * 0.6f).toInt(), panelBase()), dp(radiusDp).toFloat())
        } else {
            rounded(argb(al, panelBase()), radiusDp)
        }
    }

    private fun applyTaskbarBackground() {
        val al = cfg.tbAlpha * 255 / 100
        taskbar.background = when (cfg.tbBg) {
            1 -> GlassDrawable(taskbar, argb((al * 0.6f).toInt(), tbBase()), 0f)
            2 -> ColorDrawable(Color.TRANSPARENT)
            else -> ColorDrawable(argb(al, tbBase()))
        }
    }

    /** Alinhamento dos ícones: no meio (padrão) ou colados à esquerda. */
    private fun applyTaskbarAlign() {
        if (!::tbSpacerL.isInitialized || !::pinnedRow.isInitialized) return
        val left = cfg.tbAlign == 1
        val slp = tbSpacerL.layoutParams as LinearLayout.LayoutParams
        val wantW = if (left) 0f else 1f
        if (slp.weight != wantW) {
            slp.weight = wantW
            tbSpacerL.layoutParams = slp
        }
        val plp = pinnedRow.layoutParams as LinearLayout.LayoutParams
        val wantMargin = if (left) dp(4) else 0
        if (plp.leftMargin != wantMargin) {
            plp.leftMargin = wantMargin
            pinnedRow.layoutParams = plp
        }
        syncCenterPad()
    }

    /** 0 = no meio, 1 = à esquerda. Vale também para a barra flutuante sobre outros apps. */
    fun setTaskbarAlign(mode: Int) {
        if (cfg.tbAlign == mode) return
        cfg.tbAlign = mode
        closeAll()
        menu.hide()
        applyTaskbarAlign()
        syncMusicSide()
        placePanels()
        rebuildTaskbar()
        TaskbarOverlayService.instance?.removeStripForRebuild()
    }

    /** Bolha de música na direita: só com os ícones à esquerda e com a opção ligada. */
    private fun syncMusicSide() {
        if (!::music.isInitialized) return
        music.rightSide = cfg.tbAlign == 1 && cfg.tbMusicRight
    }

    /** Opção da bolha de música: ir para a direita quando os ícones/apps estão à esquerda. */
    fun setMusicBubbleRight(on: Boolean) {
        if (cfg.tbMusicRight == on) return
        cfg.tbMusicRight = on
        syncMusicSide()
    }

    /** Menu da bolha de música (botão direito ou toque longo). */
    private fun openMusicChipMenu(x: Int, y: Int) {
        closeAll()
        menu.show(
            listOf(
                MenuItem(
                    "Bolha na direita (ícones à esquerda)", R.drawable.ic_music_note,
                    checked = cfg.tbMusicRight, action = { setMusicBubbleRight(!cfg.tbMusicRight) }
                )
            ),
            x, y
        )
    }

    /** Largura total do lado direito (bandeja + relógio + sino + seta), com margens. */
    private fun syncCenterPad() {
        if (!::tbBellPad.isInitialized || !::tbTray.isInitialized || !::tbClockView.isInitialized) return
        var w = 0
        val alignLeft = cfg.tbAlign == 1
        for (v in (if (alignLeft) emptyList<View>() else listOf<View>(tbTray, tbClockView, bellBtn, chevBtn))) {
            var vw = v.width
            if (vw == 0) {
                v.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                vw = v.measuredWidth
            }
            val m = v.layoutParams as? ViewGroup.MarginLayoutParams
            w += vw + (m?.leftMargin ?: 0) + (m?.rightMargin ?: 0)
        }
        val lp = tbBellPad.layoutParams as LinearLayout.LayoutParams
        if (lp.width != w) {
            lp.width = w
            tbBellPad.layoutParams = lp
        }
    }

    private fun applyTaskbarMetrics() {
        val rowH = sdp(cfg.tbHeight)
        val rlp = tbRow.layoutParams as FrameLayout.LayoutParams
        rlp.height = rowH
        tbRow.layoutParams = rlp
        val fg = tbFg()
        val slot = sdp(cfg.tbIcon)
        val padS = (slot * 10f / 44f).toInt()
        startBtn.setPadding(padS, padS, padS, padS)

        val trayIcon = sdp(cfg.tbTray)
        val trayH = minOf(sdp(40), rowH)
        for (i in 0 until tbTray.childCount) {
            val iv = tbTray.getChildAt(i) as ImageView
            val lp = LinearLayout.LayoutParams(trayIcon, trayIcon)
            lp.setMargins(sdp(5), 0, sdp(5), 0)
            iv.layoutParams = lp
            iv.setColorFilter(fg)
        }
        tbTray.layoutParams = LinearLayout.LayoutParams(WRAP, trayH)

        tbClockView.textSize = cfg.tbClock * cfg.tbScale / 100f
        tbClockView.setTextColor(fg)
        val clp = LinearLayout.LayoutParams(WRAP, trayH)
        clp.rightMargin = sdp(4)
        tbClockView.layoutParams = clp

        val bw = sdp(36)
        val cw = sdp(24)
        bellBtn.layoutParams = LinearLayout.LayoutParams(bw, trayH)
        chevBtn.layoutParams = LinearLayout.LayoutParams(cw, trayH)
        chevBtn.setColorFilter(fg)
        applyTaskbarAlign()
        val bp = (bw * 0.25f).toInt()
        bellIcon.setPadding(bp, bp, bp, bp)
        bellIcon.setColorFilter(fg)

        syncMusicSide()
        if (::music.isInitialized) music.applyMetrics(rowH, fg, cfg.tbScale)
        pillIcon.setColorFilter(fg)
        pillText.setTextColor(fg)
        pillText.textSize = 12f * cfg.tbScale / 100f
        if (::tbWeather.isInitialized) {
            tbWeather.setTextColor(fg)
            tbWeather.textSize = 12f * cfg.tbScale / 100f
        }
    }

    private fun applyInsets() {
        if (!::taskbar.isInitialized) return
        // Modo imersivo: as barras do sistema ficam ocultas, então não reservamos espaço extra
        // (era isso que deixava um vão embaixo e empurrava os ícones para cima).
        taskbar.setPadding(0, 0, 0, 0)
        uiCol.setPadding(0, 0, 0, 0)
    }

    private fun startHeightPx(): Int {
        val h = resources.displayMetrics.heightPixels
        return if (cfg.stH == 0) minOf(dp(540), (h * 0.72f).toInt())
        else minOf(dp(cfg.stH), (h * 0.9f).toInt())
    }

    fun defaultStartHeightDp(): Int =
        (minOf(dp(540), (resources.displayMetrics.heightPixels * 0.72f).toInt()) /
            resources.displayMetrics.density).toInt()

    private fun placePanels() {
        val top = cfg.tbPos == 1
        val vg = if (top) Gravity.TOP else Gravity.BOTTOM
        val edge = dp(8)
        for (pn in listOf<View>(quickPanel, calPanel, notifPanel, volPanel, infoPanel)) {
            val lp = pn.layoutParams as FrameLayout.LayoutParams
            lp.gravity = vg or Gravity.END
            lp.topMargin = if (top) edge else 0
            lp.bottomMargin = if (top) 0 else edge
            lp.rightMargin = edge
            pn.layoutParams = lp
        }
        val slp = searchPanel.layoutParams as FrameLayout.LayoutParams
        slp.gravity = vg or Gravity.START
        slp.topMargin = if (top) edge else 0
        slp.bottomMargin = if (top) 0 else edge
        slp.leftMargin = edge
        searchPanel.layoutParams = slp
        if (::music.isInitialized) music.place(top, edge)

        val lp = startPanel.layoutParams as FrameLayout.LayoutParams
        lp.width = minOf(dp(cfg.stW), screenW - dp(16))
        lp.height = startHeightPx()
        val centered = cfg.stPos == 1
        // ícones à esquerda: a janela de apps (Iniciar) abre à esquerda também (a menos que o usuário
        // tenha escolhido "Centro da tela")
        val stPos = if (cfg.tbAlign == 1 && cfg.stPos == 0) 2 else cfg.stPos
        lp.gravity = when (stPos) {
            1 -> Gravity.CENTER
            2 -> vg or Gravity.START
            else -> vg or Gravity.CENTER_HORIZONTAL
        }
        lp.topMargin = if (top && !centered) edge else 0
        lp.bottomMargin = if (!top && !centered) edge else 0
        lp.leftMargin = if (stPos == 2) edge else 0
        lp.rightMargin = 0
        startPanel.layoutParams = lp
    }

    private fun applyDesktopPrefs() {
        desktopAdapter.iconDp = cfg.dkIcon
        desktopGrid.visibility = if (cfg.dkShow) View.VISIBLE else View.GONE
        rebuildDesktopViews()
    }

    fun applyPrefs() {
        if (!::taskbar.isInitialized || !::notifPanel.isInitialized) return
        taskbar.visibility = if (cfg.tbHidden) View.GONE else View.VISIBLE
        val top = cfg.tbPos == 1
        val wantIdx = if (top) 0 else uiCol.childCount - 1
        if (uiCol.indexOfChild(taskbar) != wantIdx) {
            uiCol.removeView(taskbar)
            if (top) {
                uiCol.addView(taskbar, 0, LinearLayout.LayoutParams(MATCH, WRAP))
            } else {
                uiCol.addView(taskbar, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }
        applyInsets()
        applyTaskbarBackground()
        applyTaskbarMetrics()
        rebuildTaskbar()
        applyDesktopPrefs()
        startPanel.background = panelBackground(startPanel, cfg.stAlpha, cfg.stRadius, cfg.stGlass)
        startGrid.numColumns = cfg.stCols
        quickPanel.background = panelBackground(quickPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        calPanel.background = panelBackground(calPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        searchPanel.background = panelBackground(searchPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        notifPanel.background = panelBackground(notifPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        volPanel.background = panelBackground(volPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        infoPanel.background = panelBackground(infoPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        placePanels()
        invalidateGlass()
    }

    private fun invalidateGlass() {
        if (!::notifPanel.isInitialized) return
        for (v in listOf<View>(taskbar, startPanel, quickPanel, calPanel, searchPanel, notifPanel, volPanel, infoPanel)) {
            v.invalidate()
        }
        if (::music.isInitialized) music.panel.invalidate()
        if (::menu.isInitialized) {
            for (i in 0 until menu.layer.childCount) menu.layer.getChildAt(i).invalidate()
        }
    }

    /** Refaz a tela inteira (tema/cor) e reabre o painel de personalização na categoria [cat]. */
    fun themeChanged(cat: Int) {
        prefs.edit().putInt("ui_reopen", cat).apply()
        recreate()
    }

    /**
     * Espaço vazio da barra de tarefas: botão direito do mouse ou toque longo abre direto
     * o painel "Barra de tarefas" da personalização.
     */
    private fun setupTaskbarEmptyAreaMenu() {
        val detector = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                openTaskbarCustomize(e.rawX.toInt(), e.rawY.toInt())
            }
        })
        taskbar.setOnTouchListener { _, ev ->
            if (isRightClick(ev)) {
                openTaskbarCustomize(ev.rawX.toInt(), ev.rawY.toInt())
                true
            } else {
                detector.onTouchEvent(ev)
                true
            }
        }
    }

    private fun openTaskbarCustomize(x: Int, y: Int) {
        closeAll()
        val cat = customize.categories().first()
        val remove = MenuItem("Remover barra de tarefas", R.drawable.ic_eye_off, action = { setTaskbarHidden(true) })
        val align = MenuItem(
            "Alinhamento dos ícones", R.drawable.ic_tb_align,
            children = listOf(
                MenuItem("À esquerda", R.drawable.ic_tb_align, checked = cfg.tbAlign == 1, action = { setTaskbarAlign(1) }),
                MenuItem("No meio", R.drawable.ic_tb_align_center, checked = cfg.tbAlign == 0, action = { setTaskbarAlign(0) })
            )
        )
        menu.show(listOf(align, remove, cat), x, y)
    }

    /** Remove (some com tudo) ou volta a mostrar a barra de tarefas. */
    fun setTaskbarHidden(hidden: Boolean) {
        if (cfg.tbHidden == hidden) return
        cfg.tbHidden = hidden
        closeAll()
        if (hidden) menu.hide()
        applyPrefs()
        TaskbarOverlayService.sync(this)
        toast(
            if (hidden) "Barra de tarefas removida. Para voltar: botão direito na área de trabalho > Mostrar barra de tarefas"
            else "Barra de tarefas de volta"
        )
    }

    private fun showTaskbarItem(): List<MenuItem> {
        if (!cfg.tbHidden) return emptyList()
        return listOf(MenuItem("Mostrar barra de tarefas", R.drawable.ic_view, action = { setTaskbarHidden(false) }))
    }

    private fun reopenCustomize(cat: Int) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        root.postDelayed({
            menu.show(buildDesktopItems(), loc[0] + dp(24), loc[1] + dp(60))
            root.postDelayed({
                menu.openRow(0, 3)
                root.postDelayed({ menu.openRow(1, cat) }, 90)
            }, 90)
        }, 150)
    }

    fun refreshCursor() {
        cursor.rebuild()
        applyCursorToRoot()
    }

    private fun applyCursorToRoot() {
        try {
            root.pointerIcon = if (cfg.cursorOn) cursor.arrow else null
        } catch (e: Exception) {
        }
    }

    fun openDisplaySettings() {
        safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS))
    }

    // ================================================================== novo: vidro (snapshot do wallpaper)

    private fun updateGlassSource() {
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val s = prefs.getString("wp", null)
        val isVideo = prefs.getBoolean("wpVideo", false)
        Thread {
            var bmp: Bitmap? = null
            try {
                if (s == null) {
                    val small = Bitmap.createBitmap(maxOf(8, w / 8), maxOf(8, h / 8), Bitmap.Config.ARGB_8888)
                    val g = GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        intArrayOf(
                            Color.parseColor("#0B1E3F"),
                            Color.parseColor("#1B5FD0"),
                            Color.parseColor("#0A2A66")
                        )
                    )
                    g.setBounds(0, 0, small.width, small.height)
                    g.draw(Canvas(small))
                    bmp = Glass.makeBlur(small, w, h)
                } else if (isVideo) {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(this, Uri.parse(s))
                        val f = mmr.getFrameAtTime(0)
                        if (f != null) bmp = Glass.makeBlur(f, w, h)
                    } finally {
                        try {
                            mmr.release()
                        } catch (e: Exception) {
                        }
                    }
                } else {
                    val src = decodeForGlass(Uri.parse(s), w, h)
                    if (src != null) bmp = Glass.makeBlur(src, w, h)
                }
            } catch (t: Throwable) {
                bmp = null
            }
            val result = bmp
            runOnUiThread {
                Glass.bitmap = result
                invalidateGlass()
            }
        }.start()
    }

    private fun decodeForGlass(uri: Uri, w: Int, h: Int): Bitmap? {
        return if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val sc = minOf(1f, maxOf(w, h) / 2f / maxOf(info.size.width, info.size.height))
                decoder.setTargetSize(
                    maxOf(1, (info.size.width * sc).toInt()),
                    maxOf(1, (info.size.height * sc).toInt())
                )
            }
        } else {
            val o = BitmapFactory.Options()
            o.inSampleSize = 4
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        }
    }

    // ================================================================== seleção e movimentação (botão esquerdo)

    private lateinit var marqueeView: View
    private val selectedKeys = LinkedHashSet<String>()

    /** Vidro branco translúcido: instantâneo borrado do wallpaper + película branca + borda fina. */
    private fun whiteGlass(host: View, tintAlpha: Int, radiusDp: Int, strokeAlpha: Int): Drawable {
        val glass = GlassDrawable(host, argb(tintAlpha, Color.WHITE), dp(radiusDp).toFloat())
        val border = GradientDrawable()
        border.setColor(Color.TRANSPARENT)
        border.cornerRadius = dp(radiusDp).toFloat()
        border.setStroke(dp(1), argb(strokeAlpha * 55, Color.WHITE))
        return android.graphics.drawable.LayerDrawable(arrayOf(glass, border))
    }

    // ---- posições livres dos ícones (em dp, salvas em prefs "dkpos") ----
    private val dkPos = HashMap<String, IntArray>()
    private var lastDx = 0f
    private var lastDy = 0f

    private fun loadDkPos() {
        dkPos.clear()
        for (e in (prefs.getString("dkpos", "") ?: "").split(";")) {
            val i = e.lastIndexOf('@')
            if (i <= 0) continue
            val xy = e.substring(i + 1).split(",")
            val x = xy.getOrNull(0)?.toIntOrNull()
            val y = xy.getOrNull(1)?.toIntOrNull()
            if (x != null && y != null) dkPos[e.substring(0, i)] = intArrayOf(x, y)
        }
    }

    private fun saveDkPos() {
        prefs.edit().putString("dkpos", dkPos.entries.joinToString(";") { it.key + "@" + it.value[0] + "," + it.value[1] }).apply()
    }

    private fun dkCellW(): Int = dp(cfg.dkIcon + 40)
    private fun dkCellH(): Int = dp(cfg.dkIcon + 44)

    /** Área útil da área de trabalho em dp (usa o tamanho da tela enquanto o layout ainda não saiu). */
    private fun desktopAreaDp(): IntArray {
        val d = resources.displayMetrics
        val wPx = if (desktopGrid.width > 0) desktopGrid.width else d.widthPixels
        val hPx = if (desktopGrid.height > 0) desktopGrid.height else d.heightPixels * 85 / 100
        return intArrayOf(Math.round(wPx / d.density), Math.round(hPx / d.density))
    }

    /** Apps novos (sem posição salva) entram no primeiro espaço livre que respeita margem e folga uniforme. */
    private fun assignDefaultPositions(items: List<AppItem>, reserved: IntArray? = null) {
        var changed = false
        val area = desktopAreaDp()
        val keys = items.map { it.cn.flattenToString() }.toSet()
        for (a in items) {
            val k = a.cn.flattenToString()
            if (dkPos.containsKey(k)) continue
            val placed = dkPos.filterKeys { it in keys }.values
            dkPos[k] = DesktopSpacing.firstFreeSlot(placed, area[0], area[1], cfg.dkIcon + 40, cfg.dkIcon + 44, items.size, reserved)
            changed = true
        }
        if (changed) saveDkPos()
    }

    /** Chaves movidas pelo usuário que ainda precisam ser acomodadas, e se o resultado deve ser gravado. */
    private val pendingMoved = HashSet<String>()
    private var commitNextLayout = false

    private fun rebuildDesktopViews() {
        if (!::desktopGrid.isInitialized || !::desktopAdapter.isInitialized) return
        desktopGrid.removeAllViews()
        val items = desktopAdapter.items
        val widgetOn = ::clock.isInitialized && cfg.wgOn
        assignDefaultPositions(items, if (widgetOn) widgetRect else null)
        // Espaçamento uniforme: só grava (commit) após ação do usuário (soltar, novo app, tamanho de ícone);
        // mudanças de layout (rotação etc.) apenas ajustam a exibição, sem destruir as posições salvas.
        var shown: Map<String, IntArray> = dkPos
        val laidOut = desktopGrid.width > 0 && desktopGrid.height > 0
        val area = desktopAreaDp()
        // ação do usuário nos ícones: o widget fica onde está e são os ícones que se afastam dele
        val iconsYield = commitNextLayout
        if (laidOut) {
            val commit = commitNextLayout
            shown = DesktopSpacing.resolve(
                dkPos, items.map { it.cn.flattenToString() },
                if (commit) pendingMoved else emptySet(),
                area[0], area[1], cfg.dkIcon + 40, cfg.dkIcon + 44,
                if (commit && widgetOn) widgetRect else null
            )
            if (commit) {
                for ((k, v) in shown) dkPos[k] = v.copyOf()
                saveDkPos()
                commitNextLayout = false
                pendingMoved.clear()
            }
        }
        placeWidget(laidOut, area, shown, items.size, iconsYield)
        val cw = dkCellW()
        val ch = dkCellH()
        val maxX = if (desktopGrid.width > 0) maxOf(0, desktopGrid.width - cw) else Int.MAX_VALUE
        val maxY = if (desktopGrid.height > 0) maxOf(0, desktopGrid.height - ch) else Int.MAX_VALUE
        for (i in items.indices) {
            val a = items[i]
            val key = a.cn.flattenToString()
            val row = desktopAdapter.getView(i, null, desktopGrid)
            row.tag = key
            row.isClickable = true
            row.setOnClickListener { if (!rightClickRecent()) launch(a.cn) }
            row.setOnTouchListener { _, ev ->
                if (isRightClick(ev)) {
                    appContextMenu(a, ev.rawX.toInt(), ev.rawY.toInt())
                    true
                } else {
                    false
                }
            }
            val p = shown[key] ?: dkPos[key] ?: intArrayOf(DesktopSpacing.MARGIN, DesktopSpacing.MARGIN)
            val lp = FrameLayout.LayoutParams(cw, WRAP)
            lp.leftMargin = minOf(dp(p[0]), maxX).coerceAtLeast(0)
            lp.topMargin = minOf(dp(p[1]), maxY).coerceAtLeast(0)
            desktopGrid.addView(row, lp)
        }
    }

    /**
     * Posiciona o widget de relógio na área de trabalho, no mesmo mecanismo de espaçamento dos ícones
     * ([DesktopSpacing]): ele nunca ocupa o espaço de um ícone, e a área de trabalho já exclui a barra de tarefas.
     *  - normalmente o widget procura o espaço livre mais próximo do centro salvo, sem mexer nos ícones;
     *  - se o usuário acabou de soltar ícones ([keepRect]), o widget fica onde está e os ícones é que cedem.
     */
    private fun placeWidget(laidOut: Boolean, area: IntArray, shown: Map<String, IntArray>, total: Int, keepRect: Boolean) {
        if (!::clock.isInitialized) return
        val v = clock.view
        if (!cfg.wgOn) {
            v.visibility = View.GONE
            widgetRect = null
            widgetCommit = false
            return
        }
        if (!laidOut) return // ainda sem tamanho; a tela será refeita assim que o layout sair
        var r = widgetRect
        if (!(keepRect && r != null)) {
            val icons: Collection<IntArray> = if (cfg.dkShow) shown.values else emptyList()
            r = clock.place(area[0], area[1], icons, cfg.dkIcon + 40, cfg.dkIcon + 44, total)
            widgetRect = r
            if (r != null && widgetCommit) {
                cfg.wgCx = (r[0] + r[2] / 2f) / area[0]
                cfg.wgCy = (r[1] + r[3] / 2f) / area[1]
            }
        }
        widgetCommit = false
        if (r == null) {
            v.visibility = View.GONE // não há espaço livre nem no menor tamanho: oculta em vez de cobrir ícones
            return
        }
        val lp = v.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = dp(r[0])
        lp.topMargin = dp(r[1])
        v.layoutParams = lp
        v.translationX = 0f
        v.translationY = 0f
        v.visibility = View.VISIBLE
    }

    /** Chamado pelas configurações do widget (ativar, tamanho, fonte): refaz o posicionamento e grava o resultado. */
    fun widgetChanged() {
        widgetCommit = true
        rebuildDesktopViews()
    }

    private fun childKey(i: Int): String? = desktopGrid.getChildAt(i)?.tag as? String

    private fun applySelectionVisual() {
        for (i in 0 until desktopGrid.childCount) {
            val c = desktopGrid.getChildAt(i)
            c.background = if (childKey(i) in selectedKeys) whiteGlass(c, 46, 8, 2) else null
        }
    }

    private fun setDesktopSelection(keys: Collection<String>) {
        if (selectedKeys.size == keys.size && selectedKeys.containsAll(keys)) return
        selectedKeys.clear()
        selectedKeys.addAll(keys)
        desktopAdapter.selected = HashSet(selectedKeys)
        applySelectionVisual()
    }

    private fun clearDesktopSelection() = setDesktopSelection(emptyList())

    private val desktopHost = object : DesktopFrame.Host {
        override fun canGesture(): Boolean =
            ::overlay.isInitialized && overlay.visibility != View.VISIBLE &&
                !(::lockScreen.isInitialized && lockScreen.isOpen) &&
                desktopGrid.visibility == View.VISIBLE &&
                !(::menu.isInitialized && menu.isShowing)

        /** Índice (em desktopAdapter.items) do ícone sob o ponto, ou -1. */
        override fun itemAt(x: Float, y: Float): Int {
            for (i in desktopGrid.childCount - 1 downTo 0) {
                val c = desktopGrid.getChildAt(i)
                if (x >= c.left && x <= c.right && y >= c.top && y <= c.bottom) {
                    val k = childKey(i) ?: continue
                    return desktopAdapter.items.indexOfFirst { it.cn.flattenToString() == k }
                }
            }
            return -1
        }

        override fun isSelected(pos: Int): Boolean =
            desktopAdapter.items.getOrNull(pos)?.cn?.flattenToString() in selectedKeys

        override fun selectOnly(pos: Int) {
            desktopAdapter.items.getOrNull(pos)?.let { setDesktopSelection(listOf(it.cn.flattenToString())) }
        }

        override fun clearSelection() = clearDesktopSelection()

        override fun marquee(r: android.graphics.Rect?) {
            if (r == null) {
                marqueeView.visibility = View.GONE
                return
            }
            val lp = marqueeView.layoutParams as FrameLayout.LayoutParams
            lp.leftMargin = r.left
            lp.topMargin = r.top
            lp.width = maxOf(1, r.width())
            lp.height = maxOf(1, r.height())
            marqueeView.layoutParams = lp
            marqueeView.visibility = View.VISIBLE
            marqueeView.invalidate()
            val hit = ArrayList<String>()
            val cell = android.graphics.Rect()
            for (i in 0 until desktopGrid.childCount) {
                val c = desktopGrid.getChildAt(i)
                cell.set(c.left, c.top, c.right, c.bottom)
                if (android.graphics.Rect.intersects(r, cell)) childKey(i)?.let { hit.add(it) }
            }
            setDesktopSelection(hit)
        }

        // ---- widget de relógio: arrastar com o dedo/mouse (só quando a movimentação está permitida)
        override fun widgetAt(x: Float, y: Float): Boolean {
            if (!::clock.isInitialized || !cfg.wgOn || !cfg.wgMove) return false
            val v = clock.view
            if (v.visibility != View.VISIBLE) return false
            if (!::overlay.isInitialized || overlay.visibility == View.VISIBLE) return false
            if (::lockScreen.isInitialized && lockScreen.isOpen) return false
            if (::menu.isInitialized && menu.isShowing) return false
            val s = dp(8)
            return x >= v.left - s && x <= v.right + s && y >= v.top - s && y <= v.bottom + s
        }

        override fun widgetArmed(on: Boolean) {
            clock.view.alpha = if (on) 0.85f else 1f
        }

        override fun widgetDragMove(dx: Float, dy: Float) {
            val v = clock.view
            val maxX = maxOf(0, desktopGrid.width - v.width).toFloat()
            val maxY = maxOf(0, desktopGrid.height - v.height).toFloat()
            v.translationX = (v.left + dx).coerceIn(0f, maxX) - v.left
            v.translationY = (v.top + dy).coerceIn(0f, maxY) - v.top
            v.alpha = 0.85f
        }

        override fun widgetDragEnd(commit: Boolean) {
            val v = clock.view
            val tx = v.translationX
            val ty = v.translationY
            v.translationX = 0f
            v.translationY = 0f
            v.alpha = 1f
            if (!commit || desktopGrid.width <= 0 || desktopGrid.height <= 0) return
            // o centro onde o usuário soltou vira o desejado; se estiver sobre um ícone, vai para o espaço livre mais próximo
            cfg.wgCx = (v.left + tx + v.width / 2f) / desktopGrid.width
            cfg.wgCy = (v.top + ty + v.height / 2f) / desktopGrid.height
            widgetChanged()
        }

        override fun dragMove(dx: Float, dy: Float) {
            lastDx = dx
            lastDy = dy
            for (i in 0 until desktopGrid.childCount) {
                if (childKey(i) in selectedKeys) {
                    val c = desktopGrid.getChildAt(i)
                    c.translationX = dx
                    c.translationY = dy
                    c.alpha = 0.85f
                    c.elevation = dp(8).toFloat()
                }
            }
        }

        override fun dragEnd(x: Float, y: Float, anchor: Int, commit: Boolean) {
            val sel = ArrayList<android.view.View>()
            for (i in 0 until desktopGrid.childCount) {
                val c = desktopGrid.getChildAt(i)
                if (childKey(i) in selectedKeys) sel.add(c)
                c.translationX = 0f
                c.translationY = 0f
                c.alpha = 1f
                c.elevation = 0f
            }
            if (!commit || sel.isEmpty()) return
            // limita o grupo inteiro à área de trabalho, mantendo a forma do grupo
            var dx = lastDx
            var dy = lastDy
            val minL = sel.minOf { it.left }
            val maxR = sel.maxOf { it.right }
            val minT = sel.minOf { it.top }
            val maxB = sel.maxOf { it.bottom }
            if (minL + dx < 0) dx = -minL.toFloat()
            if (maxR + dx > desktopGrid.width) dx = (desktopGrid.width - maxR).toFloat()
            if (minT + dy < 0) dy = -minT.toFloat()
            if (maxB + dy > desktopGrid.height) dy = (desktopGrid.height - maxB).toFloat()
            val d = resources.displayMetrics.density
            // grava o que o usuário está vendo (todos), depois o grupo movido; o espaçamento é aplicado no rebuild
            for (i in 0 until desktopGrid.childCount) {
                val c = desktopGrid.getChildAt(i)
                val k = c.tag as? String ?: continue
                dkPos[k] = intArrayOf(Math.round(c.left / d), Math.round(c.top / d))
            }
            pendingMoved.clear()
            for (c in sel) {
                val k = c.tag as? String ?: continue
                dkPos[k] = intArrayOf(Math.round((c.left + dx) / d), Math.round((c.top + dy) / d))
                pendingMoved.add(k)
            }
            commitNextLayout = true
            rebuildDesktopViews()
        }
    }

    // ================================================================== novo: botão direito e menus

    private fun isRightClick(ev: MotionEvent): Boolean =
        ev.actionMasked == MotionEvent.ACTION_DOWN &&
            ev.isFromSource(InputDevice.SOURCE_MOUSE) &&
            (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0

    private fun rightClick(v: View, f: (Int, Int) -> Unit) {
        v.setOnTouchListener { _, ev ->
            if (isRightClick(ev)) {
                f(ev.rawX.toInt(), ev.rawY.toInt())
                true
            } else {
                false
            }
        }
    }

    private fun canUninstall(pkg: String): Boolean = try {
        val fl = packageManager.getApplicationInfo(pkg, 0).flags
        (fl and ApplicationInfo.FLAG_SYSTEM) == 0 || (fl and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
    } catch (e: Exception) {
        false
    }

    // ------------------------------------------------ renomear app / trocar ícone

    private var pendingIconApp: ComponentName? = null
    private lateinit var tbPreview: TaskbarPreview
    private var renameLayer: FrameLayout? = null

    private fun afterAppCustomized() {
        refreshWebWindows()
        loadApps { onAppsLoaded() }
        TaskbarOverlayService.instance?.let { it.removeStripForRebuild() }
        if (::browser.isInitialized) browser.refreshIcon()
        if (::files.isInitialized) files.refreshIcon()
        if (::gallery.isInitialized) gallery.refreshIcon()
        if (::musicWin.isInitialized) musicWin.refreshIcon()
        rebuildTaskbar()
        perfPanelRefresh?.invoke()
    }

    private fun pickAppIcon(app: AppItem): Unit = pickAppIcon(app.cn)

    /** Ícone do navegador nativo: o escolhido pelo usuário ou o padrão. */
    fun browserIcon(): Drawable =
        AppCustom.icon(this, AppCustom.BROWSER) ?: resources.getDrawable(R.drawable.ic_browser, theme)

    fun changeBrowserIcon(): Unit = pickAppIcon(AppCustom.BROWSER)

    /** Ícone do gerenciador de arquivos: o escolhido pelo usuário ou o padrão. */
    fun filesIcon(): Drawable =
        AppCustom.icon(this, AppCustom.FILES) ?: resources.getDrawable(R.drawable.ic_files, theme)

    fun filesMenuItems(): List<MenuItem> {
        val l = ArrayList<MenuItem>()
        l.add(MenuItem("Definir como padrão", R.drawable.ic_open, action = { requestDefault("files") }))
        l.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickAppIcon(AppCustom.FILES) }))
        if (AppCustom.hasIcon(this, AppCustom.FILES)) {
            l.add(MenuItem("Restaurar ícone", R.drawable.ic_refresh, action = {
                AppCustom.resetIcon(this, AppCustom.FILES)
                afterAppCustomized()
            }))
        }
        return l
    }

    /** Ícone da galeria de fotos: o escolhido pelo usuário ou o padrão. */
    fun galleryIcon(): Drawable =
        AppCustom.icon(this, AppCustom.GALLERY) ?: resources.getDrawable(R.drawable.ic_gallery, theme)

    fun galleryMenuItems(): List<MenuItem> {
        val l = ArrayList<MenuItem>()
        l.add(MenuItem("Definir como padrão", R.drawable.ic_open, action = { requestDefault("gallery") }))
        l.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickAppIcon(AppCustom.GALLERY) }))
        if (AppCustom.hasIcon(this, AppCustom.GALLERY)) {
            l.add(MenuItem("Restaurar ícone", R.drawable.ic_refresh, action = {
                AppCustom.resetIcon(this, AppCustom.GALLERY)
                afterAppCustomized()
            }))
        }
        return l
    }

    /** Foto escolhida no gerenciador de arquivos: abre na galeria nativa, com as fotos da pasta ao redor. */
    fun openGallery(file: java.io.File, siblings: List<java.io.File>) {
        if (::gallery.isInitialized) {
            closeAll()
            gallery.openImage(file, siblings)
        }
    }

    /** A galeria mudou arquivos (por exemplo, excluiu uma foto): o gerenciador de arquivos recarrega a pasta. */
    fun filesRefresh() {
        if (::files.isInitialized) files.refreshList()
    }

    /** Arquivo .apk escolhido no gerenciador de arquivos: abre o instalador já com ele. */
    fun openApk(uri: Uri) {
        if (::apkWindow.isInitialized) {
            closeAll()
            apkWindow.openWith(uri)
        }
    }

    fun browserMenuItems(): List<MenuItem> {
        val l = ArrayList<MenuItem>()
        l.add(MenuItem("Definir como navegador padrão", R.drawable.ic_open, action = { requestDefault("browser") }))
        l.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickAppIcon(AppCustom.BROWSER) }))
        if (AppCustom.hasIcon(this, AppCustom.BROWSER)) {
            l.add(MenuItem("Restaurar ícone", R.drawable.ic_refresh, action = {
                AppCustom.resetIcon(this, AppCustom.BROWSER)
                afterAppCustomized()
            }))
        }
        return l
    }

    private fun pickAppIcon(cn: ComponentName) {
        pendingIconApp = cn
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            closeAll()
            startActivityForResult(i, REQ_APP_ICON)
        } catch (e: Exception) {
            pendingIconApp = null
            Toast.makeText(this, "Nenhum seletor de arquivos encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hideRenameDialog() {
        val l = renameLayer ?: return
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(l.windowToken, 0)
        } catch (e: Exception) {
        }
        root.removeView(l)
        renameLayer = null
    }

    /** Caixinha estilo vidro para renomear o app. */
    // ------------------------------------------------ instalador de apps por link

    /** Abre a janela "Instalador de Aplicativos" (botão ao lado das configurações no painel rápido). */
    fun openWebAppInstaller() {
        if (!::webInstaller.isInitialized) return
        closeAll()
        webInstaller.show()
    }

    /** Seletor de imagem da galeria para o ícone do app que está sendo instalado. */
    fun pickWebAppIcon() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_WEBICON)
        } catch (e: Exception) {
            toast("Nenhum seletor de arquivos encontrado")
        }
    }

    /** App por link criado: entra na janela de aplicativos e, se marcado, na barra de tarefas e na área de trabalho. */
    private fun onWebAppInstalled(e: WebApps.Entry, pin: Boolean, desk: Boolean) {
        val key = e.cn.flattenToString()
        if (pin) {
            val l = getList("tb")
            if (key !in l) setList("tb", l + key)
        }
        if (desk) {
            val l = getList("dk")
            if (key !in l) setList("dk", l + key)
        }
        afterAppCustomized()
    }

    private fun removeWebApp(cn: ComponentName) {
        val key = cn.flattenToString()
        for (k in listOf("tb", "dk", "st")) {
            val l = getList(k)
            if (key in l) setList(k, l - key)
        }
        webWins.remove(key)?.close()
        WebApps.remove(this, cn)
        afterAppCustomized()
    }

    /** Abre o app por link numa janela própria, sem abas nem barra de endereço (ou traz de volta se já estiver aberta). */
    private fun openWebApp(e: WebApps.Entry) {
        val key = e.cn.flattenToString()
        var w = webWins[key]
        if (w == null) {
            w = BrowserWindow(this, root, true) { taskbarInsetsPx() }
            w.attachBelow(winTop)
            w.onStateChange = { rebuildTaskbar() }
            webWins[key] = w
        }
        w.setApp(AppCustom.label(this, e.cn, e.name), WebApps.icon(this, e))
        if (w.isOpen) {
            if (w.isMinimized) w.restore()
        } else {
            w.show(e.url)
        }
    }

    /** Nome ou ícone de um app por link mudou: atualiza a barra de título das janelas dele. */
    private fun refreshWebWindows() {
        for ((k, w) in webWins) {
            val cn = ComponentName.unflattenFromString(k) ?: continue
            val e = WebApps.find(this, cn) ?: continue
            w.setApp(AppCustom.label(this, e.cn, e.name), WebApps.icon(this, e))
        }
    }

    /** Botão na barra de tarefas de um app por link aberto e não fixado (existe enquanto a janela estiver aberta). */
    private fun addWebAppButton(key: String, w: BrowserWindow, slot: Int, gap: Int, padA: Int) {
        val cn = ComponentName.unflattenFromString(key) ?: return
        val e = WebApps.find(this, cn) ?: return
        val wrap = FrameLayout(this)
        wrap.background = rip(Color.TRANSPARENT, 6)
        wrap.isClickable = true
        val iv = ImageView(this)
        iv.setImageDrawable(WebApps.icon(this, e))
        iv.setPadding(padA, padA, padA, padA)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ind = View(this)
        ind.background = rounded(cAccent, 2)
        val ilp = FrameLayout.LayoutParams(
            dp(if (w.isMinimized) 6 else 14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        ilp.bottomMargin = indBottom(slot)
        wrap.addView(ind, ilp)
        wrap.setOnClickListener {
            if (!rightClickRecent()) {
                closeAll()
                w.toggleFromTaskbar()
            }
        }
        tbHover(wrap) { entryWeb(key) }
        rightClick(wrap) { x, y ->
            val items = ArrayList<MenuItem>()
            if (w.isMinimized) {
                items.add(MenuItem("Restaurar", R.drawable.ic_open, action = { w.restore() }))
            } else {
                items.add(MenuItem("Minimizar", R.drawable.ic_chevron_down, action = { w.minimize() }))
            }
            items.add(MenuItem("Fixar na barra de tarefas", R.drawable.ic_pin, action = { toggle("tb", key) }))
            items.add(MenuItem("Fechar janela", R.drawable.ic_close, action = { w.close() }))
            menu.show(items, x, y)
        }
        val lp = LinearLayout.LayoutParams(slot, slot)
        lp.leftMargin = gap
        pinnedRow.addView(wrap, lp)
    }

    private fun showRenameDialog(app: AppItem, cx: Int = -1, cy: Int = -1) {
        closeAll()
        hideRenameDialog()
        val layer = FrameLayout(this)
        layer.setBackgroundColor(Color.parseColor("#22000000"))
        layer.isClickable = true
        layer.tag = CursorController.NOHAND
        layer.setOnClickListener { hideRenameDialog() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(10))
        card.isClickable = true
        val radius = dp(16).toFloat()
        val tint = argb(if (light) 0x99 else 0x70, panelBase())
        val glass = GlassDrawable(card, tint, radius)
        val border = GradientDrawable()
        border.cornerRadius = radius
        border.setColor(Color.TRANSPARENT)
        border.setStroke(dp(1), Color.parseColor(if (light) "#33000000" else "#40FFFFFF"))
        card.background = android.graphics.drawable.LayerDrawable(arrayOf<Drawable>(
            if (Glass.bitmap != null) glass else rounded(cPanel, 16), border
        ))
        card.elevation = dp(16).toFloat()
        card.clipToOutline = true
        card.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) {
                o.setRoundRect(0, 0, v.width, v.height, radius)
            }
        }

        // cabeçalho: ícone do app + título
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.setImageDrawable(ic(app))
        head.addView(iv, LinearLayout.LayoutParams(dp(32), dp(32)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "Renomear aplicativo"
        title.setTextColor(cText)
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        col.addView(title)
        val sub = TextView(this)
        sub.text = "Só muda aqui no launcher"
        sub.setTextColor(argb(0xAA, cText))
        sub.textSize = 11f
        col.addView(sub)
        val clp = LinearLayout.LayoutParams(0, WRAP, 1f)
        clp.leftMargin = dp(10)
        head.addView(col, clp)
        val closeX = ImageView(this)
        closeX.setImageResource(R.drawable.ic_close)
        closeX.setColorFilter(cText)
        closeX.setPadding(dp(6), dp(6), dp(6), dp(6))
        closeX.isClickable = true
        closeX.background = rip(Color.TRANSPARENT, 14)
        closeX.setOnClickListener { hideRenameDialog() }
        val xlp = LinearLayout.LayoutParams(dp(28), dp(28))
        xlp.gravity = Gravity.TOP
        xlp.leftMargin = dp(6)
        head.addView(closeX, xlp)
        card.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        // campo de texto
        val et = EditText(this)
        et.setSingleLine(true)
        et.filters = arrayOf(InputFilter.LengthFilter(30))
        et.setText(app.label)
        et.setSelection(et.text.length)
        et.setTextColor(cText)
        et.setHintTextColor(argb(0x88, cText))
        et.hint = "Nome do app"
        et.textSize = 14f
        et.setPadding(dp(12), dp(8), dp(12), dp(8))
        et.background = rounded(if (light) Color.parseColor("#14000000") else Color.parseColor("#26FFFFFF"), 10)
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        val elp = LinearLayout.LayoutParams(MATCH, WRAP)
        elp.topMargin = dp(12)
        card.addView(et, elp)

        // botões
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.gravity = Gravity.END
        fun btn(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
            val b = TextView(this)
            b.text = text
            b.setTextColor(fg)
            b.textSize = 13f
            b.typeface = Typeface.DEFAULT_BOLD
            b.gravity = Gravity.CENTER
            b.setPadding(dp(14), dp(7), dp(14), dp(7))
            b.background = rip(bg, 10)
            b.isClickable = true
            b.setOnClickListener { onClick() }
            return b
        }
        val save = {
            val name = et.text.toString().trim()
            AppCustom.setLabel(this, app.cn, if (name == app.label && !AppCustom.hasLabel(this, app.cn)) "" else name)
            hideRenameDialog()
            afterAppCustomized()
        }
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                save()
                true
            } else false
        }
        btns.addView(btn("Cancelar", if (light) Color.parseColor("#14000000") else Color.parseColor("#26FFFFFF"), cText) {
            hideRenameDialog()
        })
        val slp = LinearLayout.LayoutParams(WRAP, WRAP)
        slp.leftMargin = dp(8)
        btns.addView(btn("Salvar", cAccent, Color.BLACK) { save() }, slp)
        val blp = LinearLayout.LayoutParams(MATCH, WRAP)
        blp.topMargin = dp(12)
        card.addView(btns, blp)

        val w = minOf(dp(270), screenW - dp(32))
        val screenHpx = resources.displayMetrics.heightPixels
        val cardH = dp(150) // altura aproximada, só para não sair da tela
        val gap = dp(24)    // espaço entre o cursor e a caixinha
        val m = dp(12)
        val lp = FrameLayout.LayoutParams(w, WRAP, Gravity.LEFT or Gravity.TOP)
        if (cx >= 0 && cy >= 0) {
            var px = cx + gap
            if (px + w > screenW - m) px = cx - gap - w // não cabe à direita: vai para a esquerda
            px = px.coerceIn(m, maxOf(m, screenW - w - m))
            val py = (cy - dp(30)).coerceIn(m, maxOf(m, screenHpx - cardH - m))
            lp.leftMargin = px
            lp.topMargin = py
        } else {
            lp.gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
            lp.topMargin = dp(80)
        }
        layer.addView(card, lp)
        root.addView(layer, FrameLayout.LayoutParams(MATCH, MATCH))
        renameLayer = layer
        et.requestFocus()
        et.post {
            try {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {
            }
        }
    }

    /**
     * Apps nativos do launcher que aparecem na janela de aplicativos (Menu Iniciar), junto com os apps instalados.
     * Os componentes são "virtuais" (AppCustom) e servem também para guardar nome e ícone escolhidos.
     */
    private fun nativeApps(): List<AppItem> = listOf(
        AppItem(AppCustom.label(this, AppCustom.BROWSER, "Navegador"), browserIcon(), AppCustom.BROWSER),
        AppItem(AppCustom.label(this, AppCustom.FILES, "Arquivos"), filesIcon(), AppCustom.FILES),
        AppItem(AppCustom.label(this, AppCustom.GALLERY, "Fotos"), galleryIcon(), AppCustom.GALLERY),
        AppItem(AppCustom.label(this, AppCustom.PERF, "Monitor de desempenho"), perfIcon(), AppCustom.PERF),
        AppItem(AppCustom.label(this, AppCustom.MUSIC, "Reprodutor de música"), musicIcon(), AppCustom.MUSIC)
    )

    fun musicIcon(): Drawable =
        AppCustom.icon(this, AppCustom.MUSIC) ?: resources.getDrawable(R.drawable.ic_music_app, theme)

    fun musicMenuItems(): List<MenuItem> {
        val l = ArrayList<MenuItem>()
        l.add(MenuItem("Definir como padrão", R.drawable.ic_open, action = { requestDefault("audio") }))
        l.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickAppIcon(AppCustom.MUSIC) }))
        if (AppCustom.hasIcon(this, AppCustom.MUSIC)) {
            l.add(MenuItem("Restaurar ícone", R.drawable.ic_refresh, action = {
                AppCustom.resetIcon(this, AppCustom.MUSIC)
                afterAppCustomized()
            }))
        }
        return l
    }

    /** Chave do app nativo na lista de fixados da barra de tarefas (null se não for um app nativo). */
    private fun nativeTbKey(cn: ComponentName): String? = when (cn) {
        AppCustom.BROWSER -> TB_BROWSER
        AppCustom.FILES -> TB_FILES
        AppCustom.GALLERY -> TB_GALLERY
        AppCustom.PERF -> TB_PERF
        AppCustom.MUSIC -> TB_MUSIC
        else -> null
    }

    /** Abre um item da janela de aplicativos: app nativo abre a janela dele; os outros são iniciados normalmente. */
    private fun openStartItem(app: AppItem) {
        val cn = app.cn
        if (cn == AppCustom.MUSIC) {
            closeAll()
            musicWin.show()
            return
        }
        if (nativeTbKey(cn) == null) {
            launch(cn)
            return
        }
        closeAll()
        when (cn) {
            AppCustom.BROWSER -> browser.show()
            AppCustom.FILES -> files.show()
            AppCustom.GALLERY -> gallery.show()
            AppCustom.PERF -> if (!PerfOverlayService.isOn(this)) setPerfOn(true)
        }
    }

    /** Menu de clique direito de um app nativo na janela de aplicativos (mesmas opções do ícone na barra de tarefas). */
    private fun nativeContextMenu(app: AppItem, x: Int, y: Int) {
        val key = nativeTbKey(app.cn) ?: return
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Abrir", R.drawable.ic_open, action = { openStartItem(app) }))
        items.add(
            MenuItem(
                if (key in getList("tb")) "Desafixar da barra de tarefas" else "Fixar na barra de tarefas",
                R.drawable.ic_pin,
                action = { toggle("tb", key) }
            )
        )
        when (app.cn) {
            AppCustom.BROWSER -> items.addAll(browserMenuItems())
            AppCustom.FILES -> items.addAll(filesMenuItems())
            AppCustom.GALLERY -> items.addAll(galleryMenuItems())
            AppCustom.MUSIC -> items.addAll(musicMenuItems())
            AppCustom.PERF -> {
                items.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickPerfIcon() }))
                if (hasPerfIcon()) {
                    items.add(MenuItem("Restaurar ícone", R.drawable.ic_refresh, action = { resetPerfIcon() }))
                }
            }
        }
        menu.show(items, x, y)
    }

    private fun appContextMenu(app: AppItem, x: Int, y: Int) {
        if (nativeTbKey(app.cn) != null) {
            nativeContextMenu(app, x, y)
            return
        }
        val key = app.cn.flattenToString()
        val pkg = app.cn.packageName
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Abrir", R.drawable.ic_open, action = { launch(app.cn) }))
        items.add(
            MenuItem(
                if (key in getList("tb")) "Desafixar da barra de tarefas" else "Fixar na barra de tarefas",
                R.drawable.ic_pin,
                action = { toggle("tb", key) }
            )
        )
        items.add(
            MenuItem(
                if (key in getList("dk")) "Remover da área de trabalho" else "Adicionar à área de trabalho",
                R.drawable.ic_view,
                action = { toggle("dk", key) }
            )
        )
        items.add(MenuItem("Renomear", R.drawable.ic_settings, action = { showRenameDialog(app, x, y) }))
        items.add(MenuItem("Trocar ícone", R.drawable.ic_image, action = { pickAppIcon(app) }))
        if (AppCustom.hasLabel(this, app.cn) || AppCustom.hasIcon(this, app.cn)) {
            items.add(
                MenuItem("Restaurar nome e ícone", R.drawable.ic_refresh, action = {
                    AppCustom.resetAll(this, app.cn)
                    afterAppCustomized()
                })
            )
        }
        if (WebApps.isWeb(app.cn)) {
            items.add(MenuItem("Remover aplicativo", R.drawable.ic_delete, action = { removeWebApp(app.cn) }))
            menu.show(items, x, y)
            return
        }
        items.add(
            MenuItem(
                "Informações do aplicativo",
                R.drawable.ic_info,
                action = {
                    safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)))
                }
            )
        )
        if (canUninstall(pkg)) {
            items.add(
                MenuItem(
                    "Desinstalar",
                    R.drawable.ic_delete,
                    action = { safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))) }
                )
            )
        }
        menu.show(items, x, y)
    }

    private fun desktopContextMenu(x: Int, y: Int) {
        menu.show(buildDesktopItems(), x, y)
    }

    private fun setDesktopIcon(size: Int) {
        cfg.dkIcon = size
        commitNextLayout = true
        applyPrefs()
    }

    private fun buildDesktopItems(): List<MenuItem> = listOf(
        MenuItem("Atualizar", R.drawable.ic_refresh, action = { refreshAll() }),
        MenuItem(
            "Exibir",
            R.drawable.ic_view,
            children = listOf(
                MenuItem("Ícones grandes", checked = cfg.dkIcon == 56, action = { setDesktopIcon(56) }),
                MenuItem("Ícones médios", checked = cfg.dkIcon == 44, action = { setDesktopIcon(44) }),
                MenuItem("Ícones pequenos", checked = cfg.dkIcon == 32, action = { setDesktopIcon(32) }),
                MenuItem(
                    "Mostrar ícones da área de trabalho",
                    checked = cfg.dkShow,
                    action = {
                        cfg.dkShow = !cfg.dkShow
                        applyPrefs()
                    }
                )
            )
        ),
        MenuItem(
            "Trocar wallpaper",
            R.drawable.ic_image,
            children = listOf(
                MenuItem("Estático", action = { pickWallpaperStatic() }),
                MenuItem("Animado", action = { pickWallpaperAnimated() }),
                MenuItem("Restaurar padrão", action = { resetWallpaper() })
            )
        ),
        MenuItem("Personalizar WinLauncher", R.drawable.ic_palette, children = customize.categories()),
        MenuItem("Configurações", R.drawable.ic_settings, action = { settingsWindow.show() }),
        MenuItem(
            "Configurações de exibição",
            R.drawable.ic_brightness,
            action = { safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        ),
        MenuItem(
            "Configuração do PC",
            R.drawable.ic_pc,
            action = { pcWindow.show() }
        )
    ) + apkPermissionItem() + showTaskbarItem()

    /** "Instalar aplicativo (APK)" só aparece enquanto a permissão de instalar apps ainda não foi concedida. */
    private fun apkPermissionItem(): List<MenuItem> {
        if (packageManager.canRequestPackageInstalls()) return emptyList()
        return listOf(
            MenuItem(
                "Instalar aplicativo (APK)",
                R.drawable.ic_install,
                action = {
                    safeStart(
                        Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            )
        )
    }





    private fun refreshAll() {
        loadApps { onAppsLoaded() }
        updateGlassSource()
        updateBell()
    }

    fun pickWallpaperStatic() = pickWallpaperOf(
        arrayOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif", "image/bmp")
    )

    fun pickWallpaperAnimated() = pickWallpaperOf(arrayOf("image/gif", "video/*"))

    fun resetWallpaper() {
        prefs.edit().remove("wp").remove("wpVideo").apply()
        applyWallpaper()
        wallpaperChanged?.invoke()
    }

    fun currentWallpaperUri(): Uri? = prefs.getString("wp", null)?.let { Uri.parse(it) }

    fun currentWallpaperIsVideo(): Boolean = prefs.getBoolean("wpVideo", false)

    /** Aplica um wallpaper já escolhido antes (miniaturas da tela Wallpaper). */
    fun setWallpaper(uri: String, video: Boolean) {
        prefs.edit().putString("wp", uri).putBoolean("wpVideo", video).apply()
        applyWallpaper()
    }

    /** 0 = Otimizado, 1 = Alta, 2 = Original */
    fun wallpaperQuality(): Int = prefs.getInt("wpQuality", 0).coerceIn(0, 2)

    fun setWallpaperQuality(q: Int) {
        prefs.edit().putInt("wpQuality", q).apply()
        applyWallpaper()
    }

    // lista de wallpapers usados: uma linha por item, "v|uri" (vídeo) ou "i|uri" (imagem), mais recente primeiro
    private fun recentLines(): MutableList<String> =
        (prefs.getString("ui_wp_recent", "") ?: "").split("\n").filter { it.length > 2 }.toMutableList()

    fun recentWallpapers(video: Boolean): List<String> {
        val tag = if (video) "v|" else "i|"
        val list = recentLines().filter { it.startsWith(tag) }.map { it.substring(2) }.toMutableList()
        // garante que o wallpaper atual (de antes desta tela existir) também aparece
        val cur = prefs.getString("wp", null)
        if (cur != null && currentWallpaperIsVideo() == video && cur !in list) list.add(0, cur)
        return list
    }

    fun addRecentWallpaper(uri: String, video: Boolean) {
        val line = (if (video) "v|" else "i|") + uri
        val l = recentLines()
        l.remove(line)
        l.add(0, line)
        prefs.edit().putString("ui_wp_recent", l.take(30).joinToString("\n")).apply()
    }

    fun removeRecentWallpaper(uri: String) {
        val l = recentLines().filter { it.substring(2) != uri }
        prefs.edit().putString("ui_wp_recent", l.joinToString("\n")).apply()
    }

    // ================================================================== novo: pesquisa na barra

    private fun buildSearchPanel() {
        searchPanel = LinearLayout(this)
        searchPanel.orientation = LinearLayout.VERTICAL
        searchPanel.background = rounded(cPanel, 12)
        searchPanel.setPadding(dp(14), dp(14), dp(14), dp(10))
        searchPanel.visibility = View.GONE
        searchPanel.isClickable = true
        searchPanel.tag = CursorController.NOHAND
        searchPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(
            minOf(dp(380), screenW - dp(16)), WRAP, Gravity.BOTTOM or Gravity.START
        )
        lp.bottomMargin = dp(8)
        lp.leftMargin = dp(8)
        overlay.addView(searchPanel, lp)

        tbSearchBox = EditText(this)
        tbSearchBox.hint = "Pesquisar aplicativos"
        tbSearchBox.setHintTextColor(cSub)
        tbSearchBox.setTextColor(cText)
        tbSearchBox.textSize = 14f
        tbSearchBox.background = rounded(cTile, 20)
        tbSearchBox.setPadding(dp(14), 0, dp(14), 0)
        tbSearchBox.setSingleLine(true)
        tbSearchBox.imeOptions = EditorInfo.IME_ACTION_DONE
        tbSearchBox.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        tbSearchBox.compoundDrawableTintList = ColorStateList.valueOf(cText)
        tbSearchBox.compoundDrawablePadding = dp(8)
        searchPanel.addView(tbSearchBox, LinearLayout.LayoutParams(MATCH, dp(40)))
        tbSearchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                updateSearchResults(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        tbSearchBox.setOnKeyListener { _, keyCode, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        moveSel(1)
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        moveSel(-1)
                        true
                    }
                    KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        launchSel()
                        true
                    }
                    else -> false
                }
            } else {
                false
            }
        }
        tbSearchBox.setOnEditorActionListener { _, _, _ ->
            launchSel()
            true
        }

        tbResults = LinearLayout(this)
        tbResults.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(tbResults)
        searchPanel.addView(sv, lpTop(8))
    }

    private fun updateSearchResults(q: String) {
        tbResults.removeAllViews()
        val query = q.trim()
        tbMatches = if (query.isEmpty()) emptyList() else allApps.filter { it.label.contains(query, true) }.take(8)
        tbSel = 0
        if (query.isNotEmpty() && tbMatches.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Nenhum aplicativo encontrado"
            tv.setTextColor(cSub)
            tv.textSize = 13f
            tv.setPadding(dp(4), dp(10), dp(4), dp(10))
            tbResults.addView(tv)
        }
        for (i in tbMatches.indices) {
            val app = tbMatches[i]
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(8), 0, dp(8), 0)
            row.isClickable = true
            val iv = ImageView(this)
            iv.setImageDrawable(ic(app))
            row.addView(iv, LinearLayout.LayoutParams(dp(30), dp(30)))
            val tv = TextView(this)
            tv.text = app.label
            tv.setTextColor(cText)
            tv.textSize = 14f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            val tlp = LinearLayout.LayoutParams(0, WRAP, 1f)
            tlp.leftMargin = dp(12)
            row.addView(tv, tlp)
            row.setOnClickListener { if (!rightClickRecent()) launch(app.cn) }
            row.setOnHoverListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_HOVER_ENTER) {
                    tbSel = i
                    paintSel()
                }
                false
            }
            rightClick(row) { x, y -> appContextMenu(app, x, y) }
            tbResults.addView(row, LinearLayout.LayoutParams(MATCH, dp(44)))
        }
        paintSel()
    }

    private fun paintSel() {
        for (i in 0 until tbResults.childCount) {
            val child = tbResults.getChildAt(i)
            if (i < tbMatches.size && i == tbSel) {
                child.background = rounded(cTile, 8)
            } else {
                child.background = null
            }
        }
    }

    private fun moveSel(d: Int) {
        if (tbMatches.isEmpty()) return
        tbSel = (tbSel + d).coerceIn(0, tbMatches.size - 1)
        paintSel()
    }

    private fun launchSel() {
        val app = tbMatches.getOrNull(tbSel) ?: return
        launch(app.cn)
    }

    fun openSearch() {
        showPanel(startPanel)
        searchBox.setText("")
        searchBox.requestFocus()
        searchBox.post {
            try {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(searchBox, 0)
            } catch (e: Exception) {
            }
        }
    }

    // ================================================================== previsão do tempo

    private fun toggleWeather() {
        weatherOpen = !weatherOpen
        if (weatherOpen) refreshWeather(false)
        updateWeatherCardVisibility()
    }

    private fun updateWeatherCardVisibility() {
        if (!::weatherCard.isInitialized || !::searchBox.isInitialized) return
        weatherCard.visibility =
            if (weatherData != null && weatherOpen && searchBox.text.isNullOrEmpty()) View.VISIBLE else View.GONE
    }

    private fun refreshWeather(force: Boolean) {
        if (weatherLoading && !force) return
        if (weatherData == null) {
            weatherData = Weather.load(prefs)
            renderWeather()
        }
        val fresh = weatherData?.let { System.currentTimeMillis() - it.fetchedAt < 30 * 60 * 1000L } ?: false
        if (fresh && !force) return
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("wxAsked", false)
        ) {
            prefs.edit().putBoolean("wxAsked", true).apply()
            try {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
            } catch (e: Exception) {
            }
        }
        weatherLoading = true
        val app = applicationContext
        Thread {
            val data = try {
                Weather.fetchAuto(app, prefs)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                weatherLoading = false
                if (data != null) {
                    weatherData = data
                    renderWeather()
                }
            }
        }.start()
    }

    private fun renderWeather() {
        updateTbWeather()
        if (!::weatherChip.isInitialized) return
        val w = weatherData
        if (w == null) {
            weatherChip.visibility = View.GONE
            weatherCard.visibility = View.GONE
            return
        }
        weatherChip.setTextColor(cText)
        weatherChip.text = Weather.emoji(w.code, w.isDay) + " " + w.temp + "°"
        weatherChip.visibility = View.VISIBLE

        weatherCard.removeAllViews()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL

        val big = TextView(this)
        big.text = Weather.emoji(w.code, w.isDay)
        big.textSize = 34f
        head.addView(big, LinearLayout.LayoutParams(WRAP, WRAP))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = w.temp.toString() + "°C"
        t1.setTextColor(cText)
        t1.textSize = 22f
        t1.typeface = Typeface.DEFAULT_BOLD
        mid.addView(t1)
        val t2 = TextView(this)
        t2.text = Weather.describe(w.code) + " · " + w.city
        t2.setTextColor(cSub)
        t2.textSize = 12f
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        mid.addView(t2)
        val mlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        mlp.leftMargin = dp(12)
        head.addView(mid, mlp)

        val side = TextView(this)
        side.text = "Sensação " + w.feels + "°\nUmidade " + w.humidity + "%\nVento " + w.wind + " km/h"
        side.setTextColor(cSub)
        side.textSize = 11f
        side.gravity = Gravity.END
        head.addView(side, LinearLayout.LayoutParams(WRAP, WRAP))
        weatherCard.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (d in w.days) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val l = TextView(this)
            l.text = d.label
            l.setTextColor(cSub)
            l.textSize = 11f
            l.gravity = Gravity.CENTER
            col.addView(l)
            val e = TextView(this)
            e.text = Weather.emoji(d.code, true)
            e.textSize = 18f
            e.gravity = Gravity.CENTER
            col.addView(e)
            val m = TextView(this)
            m.text = d.max.toString() + "° / " + d.min + "°"
            m.setTextColor(cText)
            m.textSize = 11f
            m.gravity = Gravity.CENTER
            col.addView(m)
            val r = TextView(this)
            r.text = if (d.rain >= 20) "💧" + d.rain + "%" else " "
            r.setTextColor(cSub)
            r.textSize = 10f
            r.gravity = Gravity.CENTER
            col.addView(r)
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        weatherCard.addView(row, lpTop(10))
        updateWeatherCardVisibility()
    }

    // ================================================================== novo: central de notificações

    private fun notifAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    // ================================================================== barra de volume (ícone de áudio)

    private fun volAudio(): AudioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun buildVolPanel() {
        volPanel = LinearLayout(this)
        volPanel.orientation = LinearLayout.HORIZONTAL
        volPanel.gravity = Gravity.CENTER_VERTICAL
        volPanel.background = rounded(cPanel, 12)
        volPanel.setPadding(dp(16), dp(12), dp(16), dp(12))
        volPanel.visibility = View.GONE
        volPanel.isClickable = true
        volPanel.tag = CursorController.NOHAND
        volPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(minOf(dp(300), screenW - dp(16)), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(volPanel, lp)

        // olho: mostra/reativa o botão de volume flutuante (útil se o Android fechar o serviço)
        volEye = ImageView(this)
        volEye.setColorFilter(cText)
        volEye.setPadding(dp(3), dp(3), dp(3), dp(3))
        volEye.tag = CursorController.NOHAND
        volEye.setOnClickListener { toggleFloatingVolumeButton() }
        val elp = LinearLayout.LayoutParams(dp(28), dp(28))
        elp.rightMargin = dp(8)
        volPanel.addView(volEye, elp)
        updateVolEye()

        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_volume)
        iv.setColorFilter(cText)
        volPanel.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))

        volPopSeek = SeekBar(this)
        volPopSeek.progressTintList = ColorStateList.valueOf(cAccent)
        volPopSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        volPopSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    try {
                        volAudio().setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                    } catch (e: Exception) {
                    }
                }
                volPopText.text = (if (sb != null && sb.max > 0) p * 100 / sb.max else 0).toString()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                volTouching = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                volTouching = false
            }
        })
        val slp = LinearLayout.LayoutParams(0, WRAP, 1f)
        slp.leftMargin = dp(8)
        volPanel.addView(volPopSeek, slp)

        volPopText = TextView(this)
        volPopText.setTextColor(cText)
        volPopText.textSize = 13f
        volPopText.gravity = Gravity.END
        volPopText.minWidth = dp(28)
        volPanel.addView(volPopText, LinearLayout.LayoutParams(WRAP, WRAP))
    }

    private var volTouching = false
    private lateinit var volEye: ImageView

    private lateinit var volFloat: FloatingVolumeButton

    fun refreshVolFloat() {
        if (::volFloat.isInitialized) volFloat.applyVisibility()
    }

    /** Olho aberto = botão ligado; apagado = desligado ou serviço (sobre outros apps) fechado pelo Android. */
    private fun updateVolEye() {
        if (!::volEye.isInitialized) return
        val on = prefs.getBoolean("ui_vol_btn", false)
        volEye.setImageResource(if (on) R.drawable.ic_eye else R.drawable.ic_eye_off)
        val serviceOk = VolumeButtonService.isRunning() || !Settings.canDrawOverlays(this)
        volEye.alpha = if (on && serviceOk) 1f else 0.6f
    }

    private fun toggleFloatingVolumeButton() {
        val on = prefs.getBoolean("ui_vol_btn", false)
        val canOverlay = Settings.canDrawOverlays(this)
        if (on && canOverlay && !VolumeButtonService.isRunning()) {
            // ligado, mas o Android fechou o serviço: só reativa
            VolumeButtonService.sync(this, true)
        } else if (on) {
            prefs.edit().putBoolean("ui_vol_btn", false).apply()
            VolumeButtonService.sync(this, true)
        } else {
            prefs.edit().putBoolean("ui_vol_btn", true).apply()
            if (!canOverlay) {
                toast("Botão ligado no launcher. Para aparecer sobre outros apps, permita \"Exibir sobre outros apps\"")
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                }
            } else {
                VolumeButtonService.sync(this, true)
            }
        }
        refreshVolFloat()
        updateVolEye()
        volPanel.postDelayed({ updateVolEye() }, 300)
        volPanel.postDelayed({ updateVolEye() }, 900)
    }

    private fun volSliderPanel(title: String, min: Int, max: Int, cur: Int, unit: String, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val head = TextView(this)
        head.setTextColor(Color.parseColor("#1B1B1B"))
        head.textSize = 12.5f
        head.text = "$title: $cur$unit"
        col.addView(head)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (cur - min).coerceIn(0, max - min)
        sb.progressTintList = ColorStateList.valueOf(cAccent)
        sb.thumbTintList = ColorStateList.valueOf(cAccent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                head.text = "$title: ${min + p}$unit"
                if (fromUser) onChange(min + p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return col
    }

    /** Menu do botão direito no botão de volume do launcher. */
    private fun volFloatMenu(x: Int, y: Int) {
        menu.show(
            listOf(
                MenuItem(
                    "Opacidade", R.drawable.ic_brightness,
                    panel = { volSliderPanel("Opacidade", 20, 100, volFloat.alphaPct(), "%") { volFloat.setAlpha(it) } }
                ),
                MenuItem(
                    "Tamanho", R.drawable.ic_view,
                    panel = {
                        volSliderPanel("Tamanho", FloatingVolumeButton.MIN_SIZE_DP, FloatingVolumeButton.MAX_SIZE_DP, volFloat.sizeDp(), "dp") {
                            volFloat.setSize(it)
                        }
                    }
                ),
                MenuItem(
                    "Ocultar botão", R.drawable.ic_eye_off,
                    action = {
                        prefs.edit().putBoolean("ui_vol_btn", false).apply()
                        VolumeButtonService.sync(this)
                        refreshVolFloat()
                        updateVolEye()
                        toast("Botão oculto. Para voltar: olho na barra de volume")
                    }
                )
            ),
            x, y
        )
    }

    /** Lê o volume atual do sistema e atualiza a barra (também acompanha as teclas físicas enquanto aberta). */
    private fun syncVolPanel() {
        if (volPanel.visibility != View.VISIBLE) return
        updateVolEye()
        if (!volTouching) {
            try {
                val am = volAudio()
                volPopSeek.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                volPopSeek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            } catch (e: Exception) {
            }
        }
        volPanel.postDelayed({ syncVolPanel() }, 400)
    }

    private fun openVolPanel() {
        // centraliza a barra sobre o ícone de áudio (limitada às bordas da tela)
        try {
            val loc = IntArray(2)
            volIcon.getLocationOnScreen(loc)
            val cx = loc[0] + volIcon.width / 2
            val lp = volPanel.layoutParams as FrameLayout.LayoutParams
            val edge = dp(8)
            lp.rightMargin = (screenW - cx - lp.width / 2).coerceIn(edge, maxOf(edge, screenW - lp.width - edge))
            volPanel.layoutParams = lp
        } catch (e: Exception) {
        }
        syncVolPanel()
    }

    // ================================================================== caixinhas de Wi-Fi e bateria

    private fun buildInfoPanel() {
        infoPanel = LinearLayout(this)
        infoPanel.orientation = LinearLayout.HORIZONTAL
        infoPanel.gravity = Gravity.CENTER_VERTICAL
        infoPanel.background = rounded(cPanel, 12)
        infoPanel.setPadding(dp(14), dp(10), dp(16), dp(10))
        infoPanel.visibility = View.GONE
        infoPanel.isClickable = true
        infoPanel.tag = CursorController.NOHAND
        infoPanel.setOnClickListener {
            val a = infoAction
            if (a != null) {
                closeAll()
                a()
            }
        }
        infoPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(infoPanel, lp)

        infoIcon = ImageView(this)
        infoIcon.setColorFilter(cText)
        infoPanel.addView(infoIcon, LinearLayout.LayoutParams(dp(20), dp(20)))

        infoText = TextView(this)
        infoText.setTextColor(cText)
        infoText.textSize = 14f
        infoText.maxLines = 2
        infoText.maxWidth = dp(240)
        val tlp = LinearLayout.LayoutParams(WRAP, WRAP)
        tlp.leftMargin = dp(10)
        infoPanel.addView(infoText, tlp)
    }

    private var infoAction: (() -> Unit)? = null

    private fun toggleInfo(anchor: View, icon: Int, text: String, action: (() -> Unit)? = null) {
        if (infoPanel.visibility == View.VISIBLE && infoAnchor === anchor) {
            closeAll()
            return
        }
        infoAnchor = anchor
        infoAction = action
        infoIcon.setImageResource(icon)
        infoText.text = text
        showPanel(infoPanel)
    }

    /** Centraliza a caixinha sobre o ícone tocado (limitada às bordas da tela). */
    private fun positionInfoPanel() {
        val a = infoAnchor ?: return
        try {
            infoPanel.measure(
                View.MeasureSpec.makeMeasureSpec(screenW - dp(16), View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val w = infoPanel.measuredWidth
            val loc = IntArray(2)
            a.getLocationOnScreen(loc)
            val cx = loc[0] + a.width / 2
            val lp = infoPanel.layoutParams as FrameLayout.LayoutParams
            val edge = dp(8)
            lp.rightMargin = (screenW - cx - w / 2).coerceIn(edge, maxOf(edge, screenW - w - edge))
            infoPanel.layoutParams = lp
        } catch (e: Exception) {
        }
    }

    private fun batteryLabel(): String {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "Bateria indisponível"
        val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (sc <= 0 || lvl < 0) return "Bateria indisponível"
        return "${lvl * 100 / sc}%" + (if (chg) " · carregando" else "")
    }

    /**
     * Nome da rede Wi-Fi conectada + ação ao tocar na caixinha (quando falta algo para o Android liberar o nome).
     * O Android só informa o SSID com a permissão de localização PRECISA e a localização do aparelho ligada.
     */
    @Suppress("DEPRECATION")
    private fun wifiInfo(askPermission: Boolean = true): Pair<String, (() -> Unit)?> {
        if (!wifiOn()) return Pair("Wi-Fi desligado", null)
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val info = wm.connectionInfo
            if (info == null || info.networkId == -1) return Pair("Wi-Fi sem conexão", null)
            val ssid = (info.ssid ?: "").removeSurrounding("\"")
            if (ssid.isNotEmpty() && ssid != "<unknown ssid>") return Pair(ssid, null)
        } catch (e: Exception) {
        }
        val perm = if (Build.VERSION.SDK_INT >= 29) {
            Manifest.permission.ACCESS_FINE_LOCATION
        } else {
            Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            val asked = prefs.getBoolean("wifiPermAsked", false)
            if (askPermission && !asked) {
                prefs.edit().putBoolean("wifiPermAsked", true).apply()
                try {
                    requestPermissions(arrayOf(perm), REQ_WIFI)
                } catch (e: Exception) {
                }
                return Pair("Permita a localização precisa para ver o nome da rede", null)
            }
            // o diálogo do Android não reaparece depois de negado: leva direto às permissões do app
            val openApp: () -> Unit = {
                safeStart(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            return Pair("Toque aqui e permita Localização (precisa) para ver o nome da rede", openApp)
        }
        val locOn = try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled else true
        } catch (e: Exception) {
            true
        }
        if (!locOn) {
            val openLoc: () -> Unit = { safeStart(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            return Pair("Toque aqui e ligue a localização do aparelho para ver o nome da rede", openLoc)
        }
        return Pair("Conectado (o Android não informou o nome desta rede)", null)
    }

    private fun buildNotifPanel() {
        notifPanel = LinearLayout(this)
        notifPanel.orientation = LinearLayout.VERTICAL
        notifPanel.background = rounded(cPanel, 12)
        notifPanel.setPadding(dp(16), dp(14), dp(16), dp(12))
        notifPanel.visibility = View.GONE
        notifPanel.isClickable = true
        notifPanel.tag = CursorController.NOHAND
        notifPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(notifPanel, lp)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Notificações"
        title.setTextColor(cText)
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        notifClear = TextView(this)
        notifClear.text = "Limpar tudo"
        notifClear.setTextColor(cAccent)
        notifClear.textSize = 12f
        notifClear.setPadding(dp(8), dp(6), dp(8), dp(6))
        notifClear.isClickable = true
        notifClear.setOnClickListener {
            LauncherNotificationListener.dismissAll()
            updateBell()
        }
        head.addView(notifClear, LinearLayout.LayoutParams(WRAP, WRAP))
        notifPanel.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        notifBody = LinearLayout(this)
        notifBody.orientation = LinearLayout.VERTICAL
        notifScroll = ScrollView(this)
        // barra de rolagem discreta: mostra que há mais notificações para subir/descer
        notifScroll.isVerticalScrollBarEnabled = true
        notifScroll.isScrollbarFadingEnabled = true
        notifScroll.overScrollMode = View.OVER_SCROLL_NEVER
        notifScroll.isNestedScrollingEnabled = true
        // enquanto o dedo/mouse arrasta a lista, ela não é reconstruída (isso zerava a rolagem)
        notifScroll.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    notifTouching = true
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    notifTouching = false
                    if (notifPendingRefresh) {
                        notifPendingRefresh = false
                        v.postDelayed({ if (notifPanel.visibility == View.VISIBLE) refreshNotifPanel(true) }, 450)
                    }
                }
            }
            false
        }
        notifScroll.addView(notifBody)
        notifPanel.addView(notifScroll, lpTop(8))
    }

    private var notifTouching = false
    private var notifPendingRefresh = false

    private fun refreshNotifPanel(keepScroll: Boolean = false) {
        if (keepScroll && notifTouching) {
            notifPendingRefresh = true
            return
        }
        val oldY = if (keepScroll) notifScroll.scrollY else 0
        notifBody.removeAllViews()
        if (!notifAccess()) {
            notifClear.visibility = View.GONE
            val msg = TextView(this)
            msg.text = "Para mostrar as notificações do Android aqui, o WinLauncher precisa de acesso às notificações. " +
                "Você controla isso nas configurações do sistema e pode revogar quando quiser. " +
                "As notificações não são salvas nem enviadas para fora do aparelho."
            msg.setTextColor(cSub)
            msg.textSize = 12.5f
            notifBody.addView(msg, LinearLayout.LayoutParams(MATCH, WRAP))
            notifBody.addView(
                notifButton("Conceder acesso") {
                    safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                },
                lpTop(10)
            )
            val hint = TextView(this)
            hint.text = "Se a opção aparecer bloqueada (Android 13+), abra as informações do app, toque em ⋮ e escolha \"Permitir configurações restritas\"."
            hint.setTextColor(cSub)
            hint.textSize = 11.5f
            notifBody.addView(hint, lpTop(8))
            notifBody.addView(
                notifButton("Informações do app") {
                    safeStart(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + packageName)
                        )
                    )
                },
                lpTop(8)
            )
        } else {
            notifClear.visibility = View.VISIBLE
            val list = LauncherNotificationListener.current(packageName)
            if (list.isEmpty()) {
                val tv = TextView(this)
                tv.text = "Nenhuma notificação nova"
                tv.setTextColor(cSub)
                tv.textSize = 13f
                tv.setPadding(0, dp(16), 0, dp(16))
                notifBody.addView(tv)
            } else {
                for (sbn in list) notifBody.addView(notifRow(sbn), lpTop(6))
            }
        }
        notifBody.measure(
            View.MeasureSpec.makeMeasureSpec(panelW() - dp(32), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        // altura máxima da lista: o que sobra da tela acima da barra de tarefas (cabeçalho, margens e padding descontados)
        val tbH = if (taskbar.height > 0) taskbar.height else dp(48)
        val cap = maxOf(
            dp(120),
            resources.displayMetrics.heightPixels - tbH - dp(8 + 8) - dp(14 + 12) - dp(40) - dp(8) - dp(16)
        )
        val slp = notifScroll.layoutParams as LinearLayout.LayoutParams
        slp.height = minOf(notifBody.measuredHeight, cap)
        notifScroll.layoutParams = slp
        notifScroll.scrollTo(0, 0)
        if (oldY > 0) {
            notifScroll.post {
                val max = maxOf(0, notifBody.height - notifScroll.height)
                notifScroll.scrollTo(0, oldY.coerceAtMost(max))
            }
        }
    }

    private fun notifButton(text: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.BLACK)
        b.textSize = 13f
        b.gravity = Gravity.CENTER
        b.background = rounded(cAccent, 8)
        b.setPadding(dp(12), dp(10), dp(12), dp(10))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        return b
    }

    private fun notifRow(sbn: StatusBarNotification): View {
        val n = sbn.notification
        val ex = n.extras
        val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex?.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex?.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        val appLabel = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val icon: Drawable? = try {
            packageManager.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = rip(cTile, 8)
        row.setPadding(dp(10), dp(8), dp(4), dp(8))
        row.isClickable = true
        row.setOnClickListener { openNotification(sbn) }

        val iv = ImageView(this)
        if (icon != null) iv.setImageDrawable(icon)
        row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val meta = TextView(this)
        meta.text = appLabel + " · " + SimpleDateFormat("HH:mm", ptBR).format(Date(sbn.postTime))
        meta.setTextColor(cSub)
        meta.textSize = 11f
        meta.maxLines = 1
        meta.ellipsize = TextUtils.TruncateAt.END
        col.addView(meta)
        if (title.isNotEmpty()) {
            val t = TextView(this)
            t.text = title
            t.setTextColor(cText)
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t)
        }
        if (text.isNotEmpty()) {
            val t = TextView(this)
            t.text = text
            t.setTextColor(cSub)
            t.textSize = 12f
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t)
        }
        val clp = LinearLayout.LayoutParams(0, WRAP, 1f)
        clp.leftMargin = dp(10)
        row.addView(col, clp)

        val x = TextView(this)
        x.text = "✕"
        x.setTextColor(cSub)
        x.textSize = 14f
        x.gravity = Gravity.CENTER
        x.isClickable = true
        x.setOnClickListener {
            LauncherNotificationListener.dismiss(sbn.key)
            updateBell()
        }
        row.addView(x, LinearLayout.LayoutParams(dp(36), dp(36)))
        return row
    }

    private fun openNotification(sbn: StatusBarNotification) {
        // 1) tenta a ação própria da notificação (abre a conversa/tela exata do app);
        // 2) se não existir ou falhar, abre o app pelo pacote.
        var opened = false
        val pi = sbn.notification.contentIntent
        if (pi != null) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    val opts = android.app.ActivityOptions.makeBasic()
                    opts.setPendingIntentBackgroundActivityStartMode(
                        android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                    pi.send(this, 0, null, null, null, null, opts.toBundle())
                } else {
                    pi.send()
                }
                opened = true
            } catch (e: Exception) {
            }
        }
        if (!opened) {
            try {
                val li = packageManager.getLaunchIntentForPackage(sbn.packageName)
                if (li != null) {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(li)
                    opened = true
                }
            } catch (e: Exception) {
            }
        }
        if (!opened) toast("Não foi possível abrir")
        if (opened && (sbn.notification.flags and Notification.FLAG_AUTO_CANCEL) != 0) {
            LauncherNotificationListener.dismiss(sbn.key)
        }
        closeAll()
    }

    fun updateBell() {
        if (!::bellBadge.isInitialized || !::notifPanel.isInitialized) return
        val c = if (notifAccess()) LauncherNotificationListener.current(packageName).size else 0
        bellBadge.visibility = if (c > 0) View.VISIBLE else View.GONE
        bellBadge.text = if (c > 9) "9+" else c.toString()
        if (notifPanel.visibility == View.VISIBLE) refreshNotifPanel(true)
    }

    // ================================================================== novo: painéis

    private fun showPanel(p: View) {
        if (p === startPanel && !startPreviewing) placeStartPanel(true)
        for (x in listOf<View>(startPanel, quickPanel, calPanel, searchPanel, notifPanel, volPanel, infoPanel, music.panel)) {
            x.visibility = if (x === p) View.VISIBLE else View.GONE
        }
        overlay.visibility = View.VISIBLE
        if (cfg.anim) {
            p.alpha = 0f
            p.translationY = dp(if (cfg.tbPos == 1) -24 else 24).toFloat()
            p.animate().alpha(1f).translationY(0f).setDuration(140).start()
        } else {
            p.alpha = 1f
            p.translationY = 0f
        }
        if (p === quickPanel) refreshQuick()
        else if (p === calPanel) showCalendar()
        else if (p === notifPanel) refreshNotifPanel()
        else if (p === volPanel) openVolPanel()
        else if (p === infoPanel) positionInfoPanel()
        else if (p === startPanel) refreshWeather(false)
    }

    private fun closeAll() {
        if (::menu.isInitialized) menu.hide()
        if (!::overlay.isInitialized) return
        overlay.visibility = View.GONE
        startPanel.visibility = View.GONE
        quickPanel.visibility = View.GONE
        calPanel.visibility = View.GONE
        searchPanel.visibility = View.GONE
        notifPanel.visibility = View.GONE
        volPanel.visibility = View.GONE
        infoPanel.visibility = View.GONE
        if (::music.isInitialized) music.panel.visibility = View.GONE
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(root.windowToken, 0)
        } catch (e: Exception) {
        }
        searchBox.clearFocus()
        if (searchBox.text.isNotEmpty()) searchBox.setText("")
        tbSearchBox.clearFocus()
        if (tbSearchBox.text.isNotEmpty()) tbSearchBox.setText("")
    }

    // ---------------------------------------------------------------- adapter

    inner class AppAdapter(
        var items: List<AppItem>,
        var iconDp: Int,
        private val textSp: Float,
        private val panelMode: Boolean = false
    ) : BaseAdapter() {

        /** Chaves selecionadas (só a área de trabalho usa). */
        var selected: Set<String> = emptySet()

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView is LinearLayout) {
                row = convertView
            } else {
                row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.VERTICAL
                row.gravity = Gravity.CENTER_HORIZONTAL
                row.setPadding(dp(4), dp(8), dp(4), dp(8))
                val iv = ImageView(this@MainActivity)
                row.addView(iv, LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
                val tv = TextView(this@MainActivity)
                tv.setTextColor(Color.WHITE)
                tv.textSize = textSp
                tv.gravity = Gravity.CENTER
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                tv.setShadowLayer(3f, 0f, 1f, Color.BLACK)
                val tlp = LinearLayout.LayoutParams(MATCH, WRAP)
                tlp.topMargin = dp(4)
                row.addView(tv, tlp)
            }
            val app = items[position]
            val iv0 = row.getChildAt(0) as ImageView
            val want = dp(iconDp)
            val cur = iv0.layoutParams
            if (cur == null || cur.width != want) iv0.layoutParams = LinearLayout.LayoutParams(want, want)
            iv0.setImageDrawable(ic(app))
            val tv0 = row.getChildAt(1) as TextView
            tv0.text = app.label
            tv0.setTextColor(if (panelMode) cText else Color.WHITE)
            // estado visual: seleção White Glass; sem resíduos de arrasto em views recicladas
            row.translationX = 0f
            row.translationY = 0f
            row.alpha = 1f
            row.elevation = 0f
            row.background =
                if (!panelMode && app.cn.flattenToString() in selected) whiteGlass(row, 46, 8, 2) else null
            return row
        }
    }
}
