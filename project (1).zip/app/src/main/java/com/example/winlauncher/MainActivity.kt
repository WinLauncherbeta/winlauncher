package com.example.winlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.view.ViewOutlineProvider
import android.view.WindowManager
import java.io.File
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.app.Notification
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.media.MediaMetadataRetriever
import android.service.notification.StatusBarNotification
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.ScrollView
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppItem(val label: String, val icon: Drawable, val cn: ComponentName)

class Tile(
    val label: String,
    val icon: Int,
    val closes: Boolean,
    val active: () -> Boolean,
    val click: () -> Unit
) {
    var view: LinearLayout? = null
    var iconView: ImageView? = null
    var textView: TextView? = null
}

@Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
class MainActivity : Activity() {

    companion object {
        const val REQ_WP = 11
        const val REQ_LOC = 12
        const val REQ_AVATAR = 13
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var prefs: SharedPreferences
    private val ptBR = Locale("pt", "BR")

    private var cPanel = Color.parseColor("#F2202020")
    private var cTaskbar = Color.parseColor("#E61C1C1C")
    private var cTile = Color.parseColor("#26FFFFFF")
    private var cAccent = Color.parseColor("#4CC2FF")
    private var cSub = Color.parseColor("#B3FFFFFF")
    private var cText = Color.WHITE
    private var cLine = Color.parseColor("#22FFFFFF")
    private var ripC = Color.parseColor("#44FFFFFF")
    private var light = false

    // ---- personalização (novo)
    private lateinit var cfg: Prefs
    lateinit var cursor: CursorController
    lateinit var menu: ContextMenuHost
    private lateinit var customize: CustomizeUi
    private lateinit var uiCol: LinearLayout
    private lateinit var tbRow: LinearLayout
    private lateinit var tbTray: LinearLayout
    private lateinit var tbClockView: TextClock
    private lateinit var tbBellPad: View
    private lateinit var bellBtn: FrameLayout
    private lateinit var bellIcon: ImageView
    private lateinit var bellBadge: TextView
    private lateinit var searchPill: LinearLayout
    private lateinit var tbWeather: TextView
    private lateinit var userInitial: TextView
    private lateinit var userPhoto: ImageView
    private lateinit var userNameView: TextView
    private val wxHandler = Handler(Looper.getMainLooper())
    private val wxTick = object : Runnable {
        override fun run() {
            refreshWeather(false)
            wxHandler.postDelayed(this, 10 * 60 * 1000L)
        }
    }
    private lateinit var pillIcon: ImageView
    private lateinit var pillText: TextView
    private lateinit var searchPanel: LinearLayout
    private lateinit var tbSearchBox: EditText
    private lateinit var tbResults: LinearLayout
    private var tbMatches: List<AppItem> = emptyList()
    private var tbSel = 0
    private lateinit var notifPanel: LinearLayout
    private lateinit var notifBody: LinearLayout
    private lateinit var notifScroll: ScrollView
    private lateinit var notifClear: TextView
    private var insTop = 0
    private var insBottom = 0

    private lateinit var root: FrameLayout
    private lateinit var wallpaperHost: FrameLayout
    private lateinit var desktopFrame: FrameLayout
    private lateinit var desktopGrid: GridView
    private lateinit var desktopAdapter: AppAdapter
    private lateinit var overlay: FrameLayout

    private lateinit var taskbar: FrameLayout
    private lateinit var pinnedRow: LinearLayout
    private lateinit var startBtn: ImageView
    private lateinit var wifiIcon: ImageView
    private lateinit var volIcon: ImageView
    private lateinit var batIcon: ImageView

    private lateinit var startPanel: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var weatherChip: TextView
    private lateinit var weatherCard: LinearLayout
    private var weatherData: WeatherData? = null
    private var weatherOpen = false
    private var weatherLoading = false
    private lateinit var startGrid: GridView
    private lateinit var startAdapter: AppAdapter

    private lateinit var quickPanel: LinearLayout
    private lateinit var brightSeek: SeekBar
    private lateinit var volSeek: SeekBar
    private lateinit var batText: TextView
    private val tiles = ArrayList<Tile>()

    private lateinit var calPanel: LinearLayout
    private lateinit var calDate: TextView
    private lateinit var calTitle: TextView
    private lateinit var calGrid: GridLayout
    private val calShown: Calendar = Calendar.getInstance()

    private var allApps: List<AppItem> = emptyList()
    private var video: VideoView? = null
    private var anim: AnimatedImageDrawable? = null
    private var torchOn = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps { onAppsLoaded() }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val screenW: Int
        get() = resources.displayMetrics.widthPixels

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun rip(color: Int, r: Int): RippleDrawable =
        RippleDrawable(
            ColorStateList.valueOf(ripC),
            rounded(color, r),
            rounded(Color.WHITE, r)
        )

    private fun panelW(): Int = minOf(dp(360), screenW - dp(16))

    fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun ic(a: AppItem): Drawable = a.icon.constantState?.newDrawable(resources) ?: a.icon

    private fun lpTop(m: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(m)
        return lp
    }

    private fun sectionLabel(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(cText)
        tv.textSize = 13f
        tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun iconBtn(res: Int, onClick: () -> Unit): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(res)
        iv.setColorFilter(cText)
        iv.setPadding(dp(10), dp(10), dp(10), dp(10))
        iv.background = rip(Color.TRANSPARENT, 8)
        iv.setOnClickListener { onClick() }
        return iv
    }

    private fun getList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("|").filter { it.isNotEmpty() }

    private fun setList(k: String, l: List<String>) {
        prefs.edit().putString(k, l.joinToString("|")).apply()
    }

    private fun appFor(key: String): AppItem? =
        allApps.firstOrNull { it.cn.flattenToString() == key }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Não foi possível abrir")
        }
        closeAll()
    }

    private fun launch(cn: ComponentName) {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        i.component = cn
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        if (::cursor.isInitialized) cursor.setBusy(1500)
        safeStart(i)
    }

    // -------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("win", MODE_PRIVATE)
        cfg = Prefs(prefs)
        loadTheme()
        cursor = CursorController(this, cfg)
        cursor.rebuild()

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        ImmersiveController.apply(this)
        cursor.onFrame = {
            try {
                root.pointerIcon = if (cfg.cursorOn) {
                    if (cursor.busy) cursor.busyIcon() else cursor.arrow
                } else {
                    null
                }
            } catch (e: Exception) {
            }
        }
        applyCursorToRoot()
        applyWallpaper()

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addDataScheme("package")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, f)
        }

        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                    if (quickPanel.visibility == View.VISIBLE) refreshTiles()
                }
            }, null)
        } catch (e: Exception) {
        }

        loadApps { onAppsLoaded() }

        LauncherNotificationListener.onChange = { runOnUiThread { updateBell() } }
        ShizukuBridge.addListeners()
        val reopen = prefs.getInt("ui_reopen", -1)
        if (reopen >= 0) {
            prefs.edit().remove("ui_reopen").apply()
            reopenCustomize(reopen)
        }
    }

    override fun onResume() {
        super.onResume()
        video?.let { if (!it.isPlaying) it.start() }
        anim?.start()
        updateTray()
        updateBell()
        ImmersiveController.apply(this)
        wxHandler.removeCallbacks(wxTick)
        wxHandler.post(wxTick)
    }

    override fun onPause() {
        super.onPause()
        wxHandler.removeCallbacks(wxTick)
        video?.pause()
        anim?.stop()
        if (::cursor.isInitialized) cursor.clearBusy()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        LauncherNotificationListener.onChange = null
        ShizukuBridge.onChange = null
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeAll()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::menu.isInitialized && menu.isShowing) {
            menu.hide()
        } else if (overlay.visibility == View.VISIBLE) {
            closeAll()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ImmersiveController.apply(this)
    }

    // ---- botão direito: o gesto inteiro pertence ao menu de contexto ----
    private var rightGesture = false
    private var lastRightMs = 0L

    private fun rightClickRecent(): Boolean =
        rightGesture || SystemClock.uptimeMillis() - lastRightMs < 450L

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.isFromSource(InputDevice.SOURCE_MOUSE)) {
            val secondary = (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && secondary) {
                rightGesture = true
                lastRightMs = SystemClock.uptimeMillis()
                // só o DOWN chega às views (abre o menu); o resto do gesto é engolido
                super.dispatchTouchEvent(ev)
                return true
            }
            if (rightGesture) {
                lastRightMs = SystemClock.uptimeMillis()
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                    rightGesture = false
                }
                // CANCEL limpa qualquer estado "pressionado" sem gerar clique
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(c)
                c.recycle()
                return true
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (ev.isFromSource(InputDevice.SOURCE_MOUSE) &&
            (ev.actionMasked == MotionEvent.ACTION_BUTTON_PRESS || ev.actionMasked == MotionEvent.ACTION_BUTTON_RELEASE) &&
            ev.actionButton == MotionEvent.BUTTON_SECONDARY
        ) {
            lastRightMs = SystemClock.uptimeMillis()
            return true // evita performContextClick / ações padrão das views
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // O Android converte o botão direito do mouse em um BACK sintetizado; ele fechava o menu logo após abrir.
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.isFromSource(InputDevice.SOURCE_MOUSE)) {
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && ::menu.isInitialized && ::overlay.isInitialized) {
            if (event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (menu.isShowing) {
                    menu.hide()
                    return true
                }
                if (overlay.visibility == View.VISIBLE) {
                    closeAll()
                    return true
                }
            }
            if (event.keyCode == KeyEvent.KEYCODE_S && event.isMetaPressed) {
                openSearch()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) refreshWeather(true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_AVATAR && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val bmp = decodeSquare(uri, 256)
                if (bmp == null) {
                    Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
                } else {
                    File(filesDir, "avatar.png").outputStream().use {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    prefs.edit().putBoolean("userHasPhoto", true).apply()
                    refreshProfile()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (requestCode == REQ_WP && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            val type = contentResolver.getType(uri) ?: ""
            prefs.edit()
                .putString("wp", uri.toString())
                .putBoolean("wpVideo", type.startsWith("video/"))
                .apply()
            applyWallpaper()
        }
    }

    // ------------------------------------------------------------------- apps

    private fun loadApps(after: () -> Unit) {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN)
            q.addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(
                        ri.loadLabel(pm).toString(),
                        ri.loadIcon(pm),
                        ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                after()
            }
        }.start()
    }

    private fun initDefaults() {
        if (prefs.getBoolean("init", false)) return
        val pk = listOf(
            "com.android.chrome",
            "com.sec.android.app.sbrowser",
            "com.android.vending",
            "com.samsung.android.dialer",
            "com.sec.android.app.camera",
            "com.sec.android.gallery3d",
            "com.sec.android.app.myfiles",
            "com.android.settings"
        )
        val cns = pk.mapNotNull { packageManager.getLaunchIntentForPackage(it)?.component?.flattenToString() }
        setList("tb", cns)
        setList("st", cns)
        prefs.edit().putBoolean("init", true).apply()
    }

    private fun onAppsLoaded() {
        initDefaults()
        refreshPins()
        filterApps(searchBox.text?.toString() ?: "")
    }

    private fun refreshPins() {
        rebuildTaskbar()
        rebuildDesktop()
    }

    private fun filterApps(q: String) {
        startAdapter.items = if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, true) }
        startAdapter.notifyDataSetChanged()
        updateWeatherCardVisibility()
    }

    private fun toggle(k: String, v: String) {
        val l = getList(k).toMutableList()
        if (!l.remove(v)) l.add(v)
        setList(k, l)
        refreshPins()
    }

    private fun appMenu(app: AppItem) {
        val key = app.cn.flattenToString()
        val tb = getList("tb")
        val dk = getList("dk")
        val labels = arrayOf(
            if (key in tb) "Desafixar da barra de tarefas" else "Fixar na barra de tarefas",
            if (key in dk) "Remover da área de trabalho" else "Adicionar à área de trabalho",
            "Informações do app",
            "Desinstalar"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(app.label)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> toggle("tb", key)
                    1 -> toggle("dk", key)
                    2 -> safeStart(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + app.cn.packageName)
                        )
                    )
                    3 -> safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.cn.packageName)))
                }
            }
            .show()
    }

    // -------------------------------------------------------------- wallpaper

    private fun pickWallpaper() {
        pickWallpaperOf(arrayOf("video/*", "image/*"))
    }

    fun pickWallpaperOf(mimes: Array<String>) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_WP)
        } catch (e: Exception) {
            toast("Nenhum seletor de arquivos encontrado")
        }
    }

    private fun desktopMenu() {
        val labels = arrayOf(
            "Trocar wallpaper (vídeo, GIF ou imagem)",
            "Voltar ao wallpaper padrão",
            "Configurações do Android"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Área de trabalho")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> pickWallpaper()
                    1 -> {
                        prefs.edit().remove("wp").remove("wpVideo").apply()
                        applyWallpaper()
                    }
                    2 -> safeStart(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .show()
    }

    private fun applyWallpaper() {
        applyWallpaperCore()
        updateGlassSource()
    }

    private fun applyWallpaperCore() {
        wallpaperHost.removeAllViews()
        video = null
        anim?.stop()
        anim = null
        wallpaperHost.background = null

        val s = prefs.getString("wp", null)
        if (s == null) {
            wallpaperHost.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#0B1E3F"),
                    Color.parseColor("#1B5FD0"),
                    Color.parseColor("#0A2A66")
                )
            )
            return
        }
        val uri = Uri.parse(s)
        try {
            if (prefs.getBoolean("wpVideo", false)) {
                val v = VideoView(this)
                wallpaperHost.addView(v, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
                v.setAudioFocusRequest(AudioManager.AUDIOFOCUS_NONE)
                v.setOnPreparedListener { mp ->
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    val vw = mp.videoWidth
                    val vh = mp.videoHeight
                    val w = wallpaperHost.width
                    val h = wallpaperHost.height
                    if (vw > 0 && vh > 0 && w > 0 && h > 0) {
                        val sc = maxOf(w.toFloat() / vw, h.toFloat() / vh)
                        v.layoutParams = FrameLayout.LayoutParams(
                            (vw * sc).toInt(),
                            (vh * sc).toInt(),
                            Gravity.CENTER
                        )
                    }
                    v.start()
                }
                v.setOnErrorListener { _, _, _ -> true }
                v.setVideoURI(uri)
                video = v
            } else {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                wallpaperHost.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
                if (Build.VERSION.SDK_INT >= 28) {
                    val src = ImageDecoder.createSource(contentResolver, uri)
                    val dm = resources.displayMetrics
                    val d = ImageDecoder.decodeDrawable(src) { decoder, info, _ ->
                        val sc = maxOf(
                            dm.widthPixels.toFloat() / info.size.width,
                            dm.heightPixels.toFloat() / info.size.height
                        )
                        if (sc < 1f) {
                            decoder.setTargetSize(
                                (info.size.width * sc).toInt(),
                                (info.size.height * sc).toInt()
                            )
                        }
                    }
                    iv.setImageDrawable(d)
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                        anim = d
                    }
                } else {
                    iv.setImageURI(uri)
                }
            }
        } catch (e: Exception) {
            toast("Não consegui abrir o wallpaper")
        }
    }

    // --------------------------------------------------------------------- UI

    private fun buildUi() {
        root = PointerRoot(this, cursor)
        root.setBackgroundColor(Color.BLACK)

        wallpaperHost = FrameLayout(this)
        root.addView(wallpaperHost, FrameLayout.LayoutParams(MATCH, MATCH))

        val ui = LinearLayout(this)
        ui.orientation = LinearLayout.VERTICAL
        root.addView(ui, FrameLayout.LayoutParams(MATCH, MATCH))
        uiCol = ui

        desktopFrame = FrameLayout(this)
        ui.addView(desktopFrame, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val catcher = View(this)
        catcher.setOnLongClickListener {
            desktopMenu()
            true
        }
        desktopFrame.addView(catcher, FrameLayout.LayoutParams(MATCH, MATCH))
        catcher.tag = CursorController.NOHAND
        rightClick(catcher) { x, y -> desktopContextMenu(x, y) }

        desktopGrid = GridView(this)
        desktopGrid.numColumns = maxOf(3, screenW / dp(84))
        desktopGrid.setPadding(dp(8), dp(12), dp(8), dp(8))
        desktopGrid.setSelector(ColorDrawable(Color.TRANSPARENT))
        desktopGrid.verticalSpacing = dp(8)
        desktopAdapter = AppAdapter(emptyList(), 44, 11f)
        desktopGrid.adapter = desktopAdapter
        desktopGrid.setOnItemClickListener { _, _, pos, _ ->
            if (!rightClickRecent()) launch(desktopAdapter.items[pos].cn)
        }
        desktopGrid.setOnItemLongClickListener { _, _, pos, _ ->
            appMenu(desktopAdapter.items[pos])
            true
        }
        desktopFrame.addView(desktopGrid, FrameLayout.LayoutParams(MATCH, WRAP))
        desktopGrid.setOnTouchListener { _, ev ->
            if (isRightClick(ev)) {
                val pos = desktopGrid.pointToPosition(ev.x.toInt(), ev.y.toInt())
                if (pos >= 0 && pos < desktopAdapter.items.size) {
                    appContextMenu(desktopAdapter.items[pos], ev.rawX.toInt(), ev.rawY.toInt())
                } else {
                    desktopContextMenu(ev.rawX.toInt(), ev.rawY.toInt())
                }
                true
            } else {
                false
            }
        }

        overlay = FrameLayout(this)
        overlay.visibility = View.GONE
        overlay.setOnClickListener { closeAll() }
        overlay.tag = CursorController.NOHAND
        rightClick(overlay) { x, y ->
            closeAll()
            desktopContextMenu(x, y)
        }
        desktopFrame.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        buildStartPanel()
        buildQuickPanel()
        buildCalPanel()
        buildSearchPanel()
        buildNotifPanel()
        buildTaskbar()
        ui.addView(taskbar, LinearLayout.LayoutParams(MATCH, WRAP))

        root.setOnApplyWindowInsetsListener { _, ins ->
            insTop = ins.systemWindowInsetTop
            insBottom = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        menu = ContextMenuHost(this, root) { cfg.menuHover }
        root.addView(menu.layer, FrameLayout.LayoutParams(MATCH, MATCH))
        customize = CustomizeUi(this, cfg)
        Glass.root = root
        setContentView(root)
        rebuildTaskbar()
        applyPrefs()
        // mostra o último clima guardado já na abertura (depois atualiza pela internet)
        weatherData = Weather.load(prefs)
        updateTbWeather()
    }

    private fun buildTaskbar() {
        taskbar = FrameLayout(this)
        taskbar.setBackgroundColor(cTaskbar)

        tbRow = LinearLayout(this)
        tbRow.orientation = LinearLayout.HORIZONTAL
        tbRow.gravity = Gravity.CENTER_VERTICAL
        taskbar.addView(tbRow, FrameLayout.LayoutParams(MATCH, dp(48)))

        // compensa a largura do sino para não deslocar o grupo central de ícones
        tbBellPad = View(this)
        tbRow.addView(tbBellPad, LinearLayout.LayoutParams(dp(36), 1))
        tbRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        startBtn = ImageView(this)
        startBtn.setImageResource(R.drawable.ic_start)
        startBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        startBtn.background = rip(Color.TRANSPARENT, 6)
        startBtn.setOnClickListener {
            if (startPanel.visibility == View.VISIBLE) closeAll() else openStart()
        }

        pinnedRow = LinearLayout(this)
        pinnedRow.orientation = LinearLayout.HORIZONTAL
        pinnedRow.gravity = Gravity.CENTER_VERTICAL
        tbRow.addView(pinnedRow, LinearLayout.LayoutParams(WRAP, MATCH))

        tbRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        wifiIcon = ImageView(this)
        wifiIcon.setImageResource(R.drawable.ic_wifi)
        volIcon = ImageView(this)
        volIcon.setImageResource(R.drawable.ic_volume)
        batIcon = ImageView(this)
        batIcon.setImageResource(R.drawable.ic_battery)

        tbTray = LinearLayout(this)
        tbTray.orientation = LinearLayout.HORIZONTAL
        tbTray.gravity = Gravity.CENTER_VERTICAL
        tbTray.background = rip(Color.TRANSPARENT, 6)
        tbTray.setPadding(dp(4), 0, dp(4), 0)
        tbTray.setOnClickListener { showPanel(quickPanel) }
        for (iv in listOf(wifiIcon, volIcon, batIcon)) {
            val lp = LinearLayout.LayoutParams(dp(20), dp(20))
            lp.setMargins(dp(5), 0, dp(5), 0)
            tbTray.addView(iv, lp)
        }
        tbRow.addView(tbTray, LinearLayout.LayoutParams(WRAP, dp(40)))

        tbClockView = TextClock(this)
        tbClockView.format12Hour = "HH:mm\ndd/MM/yyyy"
        tbClockView.format24Hour = "HH:mm\ndd/MM/yyyy"
        tbClockView.setTextColor(Color.WHITE)
        tbClockView.textSize = 11f
        tbClockView.gravity = Gravity.CENTER
        tbClockView.setPadding(dp(8), 0, dp(8), 0)
        tbClockView.background = rip(Color.TRANSPARENT, 6)
        tbClockView.setOnClickListener { showPanel(calPanel) }
        val clp = LinearLayout.LayoutParams(WRAP, dp(40))
        clp.rightMargin = dp(4)
        tbRow.addView(tbClockView, clp)

        bellBtn = FrameLayout(this)
        bellBtn.background = rip(Color.TRANSPARENT, 6)
        bellBtn.isClickable = true
        bellBtn.setOnClickListener {
            if (notifPanel.visibility == View.VISIBLE) closeAll() else showPanel(notifPanel)
        }
        bellIcon = ImageView(this)
        bellIcon.setImageResource(R.drawable.ic_bell)
        bellBtn.addView(bellIcon, FrameLayout.LayoutParams(MATCH, MATCH))
        bellBadge = TextView(this)
        bellBadge.textSize = 8f
        bellBadge.setTextColor(Color.BLACK)
        bellBadge.typeface = Typeface.DEFAULT_BOLD
        bellBadge.gravity = Gravity.CENTER
        bellBadge.minWidth = dp(14)
        bellBadge.minHeight = dp(14)
        val badgeBg = GradientDrawable()
        badgeBg.shape = GradientDrawable.OVAL
        badgeBg.setColor(cAccent)
        bellBadge.background = badgeBg
        bellBadge.visibility = View.GONE
        val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        blp.setMargins(0, dp(4), dp(2), 0)
        bellBtn.addView(bellBadge, blp)
        tbRow.addView(bellBtn, LinearLayout.LayoutParams(dp(36), dp(40)))

        // campo de pesquisa (fora do fluxo da linha, para não mover os demais itens)
        searchPill = LinearLayout(this)
        searchPill.orientation = LinearLayout.HORIZONTAL
        searchPill.gravity = Gravity.CENTER_VERTICAL
        searchPill.background = rounded(cTile, 16)
        searchPill.setPadding(dp(10), 0, dp(10), 0)
        searchPill.isClickable = true
        searchPill.setOnClickListener { openSearch() }
        pillIcon = ImageView(this)
        pillIcon.setImageResource(R.drawable.ic_search)
        searchPill.addView(pillIcon, LinearLayout.LayoutParams(dp(16), dp(16)))
        pillText = TextView(this)
        pillText.text = "Pesquisar"
        pillText.setTextColor(Color.WHITE)
        pillText.textSize = 12f
        pillText.maxLines = 1
        val ptl = LinearLayout.LayoutParams(0, WRAP, 1f)
        ptl.leftMargin = dp(8)
        searchPill.addView(pillText, ptl)

        // previsão do tempo dentro da barra de pesquisa (nuvem + °C)
        tbWeather = TextView(this)
        tbWeather.setTextColor(Color.WHITE)
        tbWeather.textSize = 12f
        tbWeather.maxLines = 1
        tbWeather.gravity = Gravity.CENTER_VERTICAL
        tbWeather.text = "☁️ --°C"
        tbWeather.visibility = View.VISIBLE
        tbWeather.isClickable = true
        tbWeather.setOnClickListener {
            if (startPanel.visibility == View.VISIBLE) {
                closeAll()
            } else {
                weatherOpen = true
                updateWeatherCardVisibility()
                openStart()
            }
        }
        val wlp = LinearLayout.LayoutParams(WRAP, MATCH)
        wlp.leftMargin = dp(6)
        searchPill.addView(tbWeather, wlp)
    }

    private fun updateTbWeather() {
        if (!::tbWeather.isInitialized || !::pinnedRow.isInitialized) return
        val w = weatherData
        tbWeather.text =
            if (w != null) Weather.emoji(w.code, w.isDay) + " " + w.temp + "°C" else "☁️ --°C"
        tbWeather.visibility = View.VISIBLE
        applyTaskbarMetrics()
        rebuildTaskbar()
    }

    private fun rebuildTaskbar() {
        pinnedRow.removeAllViews()
        val slot = sdp(cfg.tbIcon)
        val gap = sdp(cfg.tbSpace)
        val padA = (slot * 8f / 44f).toInt()
        pinnedRow.addView(startBtn, LinearLayout.LayoutParams(slot, slot))
        val showPill = screenW >= dp(600)
        val pillW = sdp(172)
        if (showPill) {
            searchPill.visibility = View.VISIBLE
            pillText.visibility = View.VISIBLE
            val plp = LinearLayout.LayoutParams(
                pillW,
                maxOf(dp(24), minOf(sdp(32), sdp(cfg.tbHeight) - dp(8)))
            )
            plp.leftMargin = gap + sdp(4)
            plp.rightMargin = sdp(4)
            pinnedRow.addView(searchPill, plp)
        }
        val reserve = 3 * (sdp(cfg.tbTray) + sdp(10)) + sdp(8) + sdp(64) + sdp(36) + sdp(4) +
            (if (showPill) pillW + sdp(8) else 0)
        val slots = ((screenW - reserve) / (slot + gap)) - 1
        val apps = getList("tb").mapNotNull { appFor(it) }.take(maxOf(0, slots))
        for (a in apps) {
            val iv = ImageView(this)
            iv.setImageDrawable(ic(a))
            iv.setPadding(padA, padA, padA, padA)
            iv.background = rip(Color.TRANSPARENT, 6)
            iv.setOnClickListener { if (!rightClickRecent()) launch(a.cn) }
            iv.setOnLongClickListener {
                appMenu(a)
                true
            }
            rightClick(iv) { x, y -> appContextMenu(a, x, y) }
            val lp = LinearLayout.LayoutParams(slot, slot)
            lp.leftMargin = gap
            pinnedRow.addView(iv, lp)
        }
    }

    private fun rebuildDesktop() {
        desktopAdapter.items = getList("dk").mapNotNull { appFor(it) }
        desktopAdapter.notifyDataSetChanged()
    }

    private fun buildStartPanel() {
        val h = minOf(dp(540), (resources.displayMetrics.heightPixels * 0.72f).toInt())
        startPanel = LinearLayout(this)
        startPanel.orientation = LinearLayout.VERTICAL
        startPanel.background = rounded(cPanel, 12)
        startPanel.setPadding(dp(16), dp(16), dp(16), dp(8))
        startPanel.visibility = View.GONE
        startPanel.isClickable = true
        startPanel.tag = CursorController.NOHAND
        startPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), h, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = dp(8)
        overlay.addView(startPanel, lp)

        searchBox = EditText(this)
        searchBox.hint = "Digite aqui para pesquisar"
        searchBox.setHintTextColor(cSub)
        searchBox.setTextColor(cText)
        searchBox.textSize = 14f
        searchBox.background = rounded(cTile, 20)
        searchBox.setPadding(dp(14), 0, dp(84), 0)
        searchBox.setSingleLine(true)
        searchBox.imeOptions = EditorInfo.IME_ACTION_DONE
        searchBox.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        searchBox.compoundDrawablePadding = dp(8)
        searchBox.compoundDrawableTintList = ColorStateList.valueOf(cText)
        val searchWrap = FrameLayout(this)
        searchWrap.addView(searchBox, FrameLayout.LayoutParams(MATCH, MATCH))
        weatherChip = TextView(this)
        weatherChip.setTextColor(cText)
        weatherChip.textSize = 13f
        weatherChip.gravity = Gravity.CENTER
        weatherChip.setPadding(dp(8), 0, dp(8), 0)
        weatherChip.background = rip(Color.TRANSPARENT, 14)
        weatherChip.visibility = View.GONE
        weatherChip.setOnClickListener { toggleWeather() }
        val wlp = FrameLayout.LayoutParams(WRAP, dp(32), Gravity.END or Gravity.CENTER_VERTICAL)
        wlp.rightMargin = dp(6)
        searchWrap.addView(weatherChip, wlp)
        startPanel.addView(searchWrap, LinearLayout.LayoutParams(MATCH, dp(40)))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        searchBox.setOnEditorActionListener { _, _, _ ->
            startAdapter.items.firstOrNull()?.let { launch(it.cn) }
            true
        }

        weatherCard = LinearLayout(this)
        weatherCard.orientation = LinearLayout.VERTICAL
        weatherCard.background = rounded(cTile, 10)
        weatherCard.setPadding(dp(12), dp(10), dp(12), dp(10))
        weatherCard.visibility = View.GONE
        startPanel.addView(weatherCard, lpTop(10))

        startPanel.addView(sectionLabel("Todos os aplicativos"), lpTop(12))
        startAdapter = AppAdapter(emptyList(), 40, 11f, true)
        startGrid = GridView(this)
        startGrid.numColumns = 4
        startGrid.setSelector(ColorDrawable(Color.TRANSPARENT))
        startGrid.isVerticalScrollBarEnabled = false
        startGrid.adapter = startAdapter
        startGrid.setOnItemClickListener { _, _, pos, _ ->
            if (!rightClickRecent()) launch(startAdapter.items[pos].cn)
        }
        startGrid.setOnItemLongClickListener { _, _, pos, _ ->
            appMenu(startAdapter.items[pos])
            true
        }
        startGrid.setOnTouchListener { _, ev ->
            if (isRightClick(ev)) {
                val pos = startGrid.pointToPosition(ev.x.toInt(), ev.y.toInt())
                if (pos >= 0 && pos < startAdapter.items.size) {
                    appContextMenu(startAdapter.items[pos], ev.rawX.toInt(), ev.rawY.toInt())
                }
                true
            } else {
                false
            }
        }
        startPanel.addView(startGrid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val line = View(this)
        line.setBackgroundColor(cLine)
        val llp = LinearLayout.LayoutParams(MATCH, dp(1))
        llp.topMargin = dp(4)
        startPanel.addView(line, llp)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL

        // perfil (foto + nome): toque para editar
        val profile = LinearLayout(this)
        profile.orientation = LinearLayout.HORIZONTAL
        profile.gravity = Gravity.CENTER_VERTICAL
        profile.background = rip(Color.TRANSPARENT, 6)
        profile.isClickable = true
        profile.setOnClickListener {
            closeAll()
            profileMenu()
        }

        val avatarBox = FrameLayout(this)
        userInitial = TextView(this)
        userInitial.gravity = Gravity.CENTER
        userInitial.setTextColor(Color.BLACK)
        userInitial.textSize = 13f
        userInitial.typeface = Typeface.DEFAULT_BOLD
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(cAccent)
        userInitial.background = oval
        avatarBox.addView(userInitial, FrameLayout.LayoutParams(MATCH, MATCH))
        userPhoto = ImageView(this)
        userPhoto.scaleType = ImageView.ScaleType.CENTER_CROP
        userPhoto.outlineProvider = ViewOutlineProvider.BACKGROUND
        userPhoto.background = oval.constantState?.newDrawable()?.mutate()
        userPhoto.clipToOutline = true
        userPhoto.visibility = View.GONE
        avatarBox.addView(userPhoto, FrameLayout.LayoutParams(MATCH, MATCH))
        val ablp = LinearLayout.LayoutParams(dp(30), dp(30))
        ablp.leftMargin = dp(2)
        profile.addView(avatarBox, ablp)

        userNameView = TextView(this)
        userNameView.setTextColor(cText)
        userNameView.textSize = 13f
        userNameView.maxLines = 1
        userNameView.ellipsize = TextUtils.TruncateAt.END
        val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        nlp.leftMargin = dp(10)
        profile.addView(userNameView, nlp)
        bar.addView(profile, LinearLayout.LayoutParams(0, MATCH, 1f))
        refreshProfile()

        bar.addView(
            iconBtn(R.drawable.ic_image) {
                closeAll()
                pickWallpaper()
            },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        bar.addView(
            iconBtn(R.drawable.ic_settings) { safeStart(Intent(Settings.ACTION_SETTINGS)) },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        startPanel.addView(bar, LinearLayout.LayoutParams(MATCH, dp(44)))
    }

    // ------------------------------------------------------------------- perfil

    private fun userName(): String =
        (prefs.getString("userName", null) ?: "").trim().ifEmpty { "Usuário" }

    private fun refreshProfile() {
        if (!::userNameView.isInitialized) return
        val n = userName()
        userNameView.text = n
        userInitial.text = n.take(1).uppercase()
        val f = File(filesDir, "avatar.png")
        if (prefs.getBoolean("userHasPhoto", false) && f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            if (bmp != null) {
                userPhoto.setImageBitmap(bmp)
                userPhoto.visibility = View.VISIBLE
                return
            }
        }
        userPhoto.setImageDrawable(null)
        userPhoto.visibility = View.GONE
    }

    private fun profileMenu() {
        val hasPhoto = userPhoto.visibility == View.VISIBLE
        val labels = if (hasPhoto) arrayOf("Editar nome", "Alterar foto", "Remover foto")
        else arrayOf("Editar nome", "Escolher foto")
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Perfil")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> editNameDialog()
                    1 -> pickAvatar()
                    2 -> {
                        File(filesDir, "avatar.png").delete()
                        prefs.edit().putBoolean("userHasPhoto", false).apply()
                        refreshProfile()
                    }
                }
            }
            .show()
    }

    private fun editNameDialog() {
        val et = EditText(this)
        et.setSingleLine(true)
        et.filters = arrayOf(InputFilter.LengthFilter(24))
        et.setText(userName())
        et.setSelection(et.text.length)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        val d = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Nome do usuário")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                prefs.edit().putString("userName", et.text.toString().trim()).apply()
                refreshProfile()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
    }

    private fun pickAvatar() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_AVATAR)
        } catch (e: Exception) {
            Toast.makeText(this, "Nenhum seletor de arquivos encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    /** Lê a imagem, recorta o quadrado central e reduz para size x size. */
    private fun decodeSquare(uri: Uri, size: Int): Bitmap? {
        val bmp: Bitmap = if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val sc = minOf(1f, 512f / maxOf(info.size.width, info.size.height))
                decoder.setTargetSize(
                    maxOf(1, (info.size.width * sc).toInt()),
                    maxOf(1, (info.size.height * sc).toInt())
                )
            }
        } else {
            val o = BitmapFactory.Options()
            o.inSampleSize = 4
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                ?: return null
        }
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, size, size, true)
    }

    private fun sliderRow(icon: Int, seek: SeekBar): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(cText)
        row.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = dp(8)
        row.addView(seek, lp)
        return row
    }

    private fun buildQuickPanel() {
        quickPanel = LinearLayout(this)
        quickPanel.orientation = LinearLayout.VERTICAL
        quickPanel.background = rounded(cPanel, 12)
        quickPanel.setPadding(dp(16), dp(16), dp(16), dp(12))
        quickPanel.visibility = View.GONE
        quickPanel.isClickable = true
        quickPanel.tag = CursorController.NOHAND
        quickPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(quickPanel, lp)

        tiles.clear()
        tiles.add(Tile("Wi-Fi", R.drawable.ic_wifi, true, { wifiOn() }, {
            if (Build.VERSION.SDK_INT >= 29) {
                safeStart(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            } else {
                safeStart(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        }))
        tiles.add(Tile("Bluetooth", R.drawable.ic_bluetooth, true, { btOn() }, {
            safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }))
        tiles.add(Tile("Modo avião", R.drawable.ic_airplane, true, {
            Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        }, {
            safeStart(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
        }))
        tiles.add(Tile("Lanterna", R.drawable.ic_flashlight, false, { torchOn }, { toggleTorch() }))
        tiles.add(Tile("Rotação", R.drawable.ic_rotate, false, {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        }, { toggleRotation() }))
        tiles.add(Tile("Economia", R.drawable.ic_battery, true, {
            (getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        }, {
            safeStart(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }))
        tiles.add(Tile("Não perturbe", R.drawable.ic_moon, true, {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
        }, {
            safeStart(Intent(Settings.ACTION_SOUND_SETTINGS))
        }))
        tiles.add(Tile("Localização", R.drawable.ic_location, true, {
            Build.VERSION.SDK_INT >= 28 &&
                (getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
        }, {
            safeStart(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }))
        tiles.add(Tile("Hotspot", R.drawable.ic_hotspot, true, { false }, {
            safeStart(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }))

        val tw = (panelW() - dp(32)) / 3 - dp(8)
        val g = GridLayout(this)
        g.columnCount = 3
        for (t in tiles) {
            val v = LinearLayout(this)
            v.orientation = LinearLayout.VERTICAL
            v.gravity = Gravity.CENTER
            v.setOnClickListener {
                t.click()
                if (t.closes) closeAll() else refreshQuick()
            }
            val iv = ImageView(this)
            iv.setImageResource(t.icon)
            val tv = TextView(this)
            tv.text = t.label
            tv.textSize = 11f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            v.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tlp = LinearLayout.LayoutParams(WRAP, WRAP)
            tlp.topMargin = dp(4)
            v.addView(tv, tlp)
            t.view = v
            t.iconView = iv
            t.textView = tv
            val glp = GridLayout.LayoutParams()
            glp.width = tw
            glp.height = dp(64)
            glp.setMargins(dp(4), dp(4), dp(4), dp(4))
            g.addView(v, glp)
        }
        quickPanel.addView(g, LinearLayout.LayoutParams(MATCH, WRAP))

        brightSeek = SeekBar(this)
        brightSeek.max = 255
        brightSeek.progressTintList = ColorStateList.valueOf(cAccent)
        brightSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        brightSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (Settings.System.canWrite(this@MainActivity)) {
                    Settings.System.putInt(
                        contentResolver,
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    )
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, maxOf(p, 1))
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                if (!Settings.System.canWrite(this@MainActivity)) {
                    toast("Permita \"Modificar configurações do sistema\" para controlar o brilho")
                    safeStart(
                        Intent(
                            Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + packageName)
                        )
                    )
                }
            }

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        quickPanel.addView(sliderRow(R.drawable.ic_brightness, brightSeek), lpTop(10))

        volSeek = SeekBar(this)
        volSeek.progressTintList = ColorStateList.valueOf(cAccent)
        volSeek.thumbTintList = ColorStateList.valueOf(cAccent)
        volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                } catch (e: Exception) {
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        quickPanel.addView(sliderRow(R.drawable.ic_volume, volSeek), lpTop(6))

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        batText = TextView(this)
        batText.setTextColor(cText)
        batText.textSize = 13f
        batText.compoundDrawablePadding = dp(6)
        batText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_battery, 0, 0, 0)
        batText.compoundDrawableTintList = ColorStateList.valueOf(cText)
        foot.addView(batText, LinearLayout.LayoutParams(0, WRAP, 1f))
        foot.addView(
            iconBtn(R.drawable.ic_settings) { safeStart(Intent(Settings.ACTION_SETTINGS)) },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        quickPanel.addView(foot, lpTop(8))
    }

    private fun buildCalPanel() {
        calPanel = LinearLayout(this)
        calPanel.orientation = LinearLayout.VERTICAL
        calPanel.background = rounded(cPanel, 12)
        calPanel.setPadding(dp(16), dp(16), dp(16), dp(12))
        calPanel.visibility = View.GONE
        calPanel.isClickable = true
        calPanel.tag = CursorController.NOHAND
        calPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(calPanel, lp)

        calDate = TextView(this)
        calDate.setTextColor(cText)
        calDate.textSize = 16f
        calDate.typeface = Typeface.DEFAULT_BOLD
        calPanel.addView(calDate, lpTop(0))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        calTitle = TextView(this)
        calTitle.setTextColor(cSub)
        calTitle.textSize = 13f
        nav.addView(calTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        nav.addView(iconBtn(R.drawable.ic_chevron_up) { shiftMonth(-1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        nav.addView(iconBtn(R.drawable.ic_chevron_down) { shiftMonth(1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        calPanel.addView(nav, lpTop(8))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        for (d in listOf("D", "S", "T", "Q", "Q", "S", "S")) {
            val tv = TextView(this)
            tv.text = d
            tv.gravity = Gravity.CENTER
            tv.setTextColor(cSub)
            tv.textSize = 11f
            head.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        calPanel.addView(head, lpTop(4))

        calGrid = GridLayout(this)
        calGrid.columnCount = 7
        calPanel.addView(calGrid, lpTop(2))
    }

    private fun shiftMonth(d: Int) {
        calShown.add(Calendar.MONTH, d)
        buildCalGrid()
    }

    private fun showCalendar() {
        calShown.timeInMillis = System.currentTimeMillis()
        calDate.text = SimpleDateFormat("EEEE, d 'de' MMMM", ptBR)
            .format(Date())
            .replaceFirstChar { it.uppercase() }
        buildCalGrid()
    }

    private fun buildCalGrid() {
        calGrid.removeAllViews()
        calTitle.text = SimpleDateFormat("MMMM 'de' yyyy", ptBR)
            .format(calShown.time)
            .replaceFirstChar { it.uppercase() }
        val c = calShown.clone() as Calendar
        c.set(Calendar.DAY_OF_MONTH, 1)
        val offset = c.get(Calendar.DAY_OF_WEEK) - 1
        val days = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = Calendar.getInstance()
        val isThisMonth = today.get(Calendar.YEAR) == c.get(Calendar.YEAR) &&
            today.get(Calendar.MONTH) == c.get(Calendar.MONTH)
        val cell = (panelW() - dp(32)) / 7
        for (i in 0 until 42) {
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.textSize = 13f
            tv.setTextColor(cText)
            val day = i - offset + 1
            if (day in 1..days) {
                tv.text = day.toString()
                if (isThisMonth && day == today.get(Calendar.DAY_OF_MONTH)) {
                    val oval = GradientDrawable()
                    oval.shape = GradientDrawable.OVAL
                    oval.setColor(cAccent)
                    tv.background = oval
                    tv.setTextColor(Color.BLACK)
                }
            }
            val glp = GridLayout.LayoutParams()
            glp.width = cell
            glp.height = cell
            calGrid.addView(tv, glp)
        }
    }

    // ----------------------------------------------------------------- panels

    private fun openStart() {
        showPanel(startPanel)
    }

    // ------------------------------------------------------------ system state

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun btOn(): Boolean = try {
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    } catch (e: Exception) {
        false
    }

    private fun updateTray() {
        if (!::wifiIcon.isInitialized) return
        wifiIcon.alpha = if (wifiOn()) 1f else 0.4f
    }

    private fun refreshTiles() {
        for (t in tiles) {
            val on = try {
                t.active()
            } catch (e: Exception) {
                false
            }
            t.view?.background = rip(if (on) cAccent else cTile, 8)
            val fg = if (on) Color.BLACK else cText
            t.iconView?.setColorFilter(fg)
            t.textView?.setTextColor(fg)
        }
        updateTray()
    }

    private fun refreshQuick() {
        refreshTiles()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            volSeek.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volSeek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (e: Exception) {
        }
        try {
            brightSeek.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
        }
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (sc > 0 && lvl >= 0) lvl * 100 / sc else 0
            batText.text = "$pct%" + (if (chg) " · carregando" else "")
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("Lanterna indisponível")
                return
            }
            cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            toast("Lanterna indisponível")
        }
    }

    private fun toggleRotation() {
        if (Settings.System.canWrite(this)) {
            val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
        } else {
            toast("Permita \"Modificar configurações do sistema\" para esta opção")
            safeStart(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }
    }

    // ================================================================== novo: tema e preferências

    private fun loadTheme() {
        light = cfg.theme == 1
        cAccent = cfg.accent
        if (light) {
            cText = Color.parseColor("#1F1F1F")
            cTile = Color.parseColor("#14000000")
            cSub = Color.parseColor("#99000000")
            cLine = Color.parseColor("#22000000")
            ripC = Color.parseColor("#22000000")
            cPanel = Color.parseColor("#F2F3F3F3")
            cTaskbar = Color.parseColor("#E6F3F3F3")
        } else {
            cText = Color.WHITE
            cTile = Color.parseColor("#26FFFFFF")
            cSub = Color.parseColor("#B3FFFFFF")
            cLine = Color.parseColor("#22FFFFFF")
            ripC = Color.parseColor("#44FFFFFF")
            cPanel = Color.parseColor("#F2202020")
            cTaskbar = Color.parseColor("#E61C1C1C")
        }
    }

    private fun sdp(v: Int): Int =
        (v * resources.displayMetrics.density * cfg.tbScale / 100f + 0.5f).toInt()

    private fun argb(alpha: Int, rgb: Int): Int = (alpha.coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)

    private fun tbFg(): Int = if (light && cfg.tbBg != 2) Color.parseColor("#1F1F1F") else Color.WHITE

    private fun tbBase(): Int = if (light) 0xF3F3F3 else 0x1C1C1C

    private fun panelBase(): Int = if (light) 0xF3F3F3 else 0x202020

    private fun panelBackground(host: View, alphaPct: Int, radiusDp: Int, glass: Boolean): Drawable {
        val al = alphaPct * 255 / 100
        return if (glass) {
            GlassDrawable(host, argb((al * 0.6f).toInt(), panelBase()), dp(radiusDp).toFloat())
        } else {
            rounded(argb(al, panelBase()), radiusDp)
        }
    }

    private fun applyTaskbarBackground() {
        val al = cfg.tbAlpha * 255 / 100
        taskbar.background = when (cfg.tbBg) {
            1 -> GlassDrawable(taskbar, argb((al * 0.6f).toInt(), tbBase()), 0f)
            2 -> ColorDrawable(Color.TRANSPARENT)
            else -> ColorDrawable(argb(al, tbBase()))
        }
    }

    private fun applyTaskbarMetrics() {
        val rowH = sdp(cfg.tbHeight)
        val rlp = tbRow.layoutParams as FrameLayout.LayoutParams
        rlp.height = rowH
        tbRow.layoutParams = rlp
        val fg = tbFg()
        val slot = sdp(cfg.tbIcon)
        val padS = (slot * 10f / 44f).toInt()
        startBtn.setPadding(padS, padS, padS, padS)

        val trayIcon = sdp(cfg.tbTray)
        val trayH = minOf(sdp(40), rowH)
        for (i in 0 until tbTray.childCount) {
            val iv = tbTray.getChildAt(i) as ImageView
            val lp = LinearLayout.LayoutParams(trayIcon, trayIcon)
            lp.setMargins(sdp(5), 0, sdp(5), 0)
            iv.layoutParams = lp
            iv.setColorFilter(fg)
        }
        tbTray.layoutParams = LinearLayout.LayoutParams(WRAP, trayH)

        tbClockView.textSize = cfg.tbClock * cfg.tbScale / 100f
        tbClockView.setTextColor(fg)
        val clp = LinearLayout.LayoutParams(WRAP, trayH)
        clp.rightMargin = sdp(4)
        tbClockView.layoutParams = clp

        val bw = sdp(36)
        bellBtn.layoutParams = LinearLayout.LayoutParams(bw, trayH)
        tbBellPad.layoutParams = LinearLayout.LayoutParams(bw, 1)
        val bp = (bw * 0.25f).toInt()
        bellIcon.setPadding(bp, bp, bp, bp)
        bellIcon.setColorFilter(fg)

        pillIcon.setColorFilter(fg)
        pillText.setTextColor(fg)
        pillText.textSize = 12f * cfg.tbScale / 100f
        if (::tbWeather.isInitialized) {
            tbWeather.setTextColor(fg)
            tbWeather.textSize = 12f * cfg.tbScale / 100f
        }
    }

    private fun applyInsets() {
        if (!::taskbar.isInitialized) return
        // Modo imersivo: as barras do sistema ficam ocultas, então não reservamos espaço extra
        // (era isso que deixava um vão embaixo e empurrava os ícones para cima).
        taskbar.setPadding(0, 0, 0, 0)
        uiCol.setPadding(0, 0, 0, 0)
    }

    private fun startHeightPx(): Int {
        val h = resources.displayMetrics.heightPixels
        return if (cfg.stH == 0) minOf(dp(540), (h * 0.72f).toInt())
        else minOf(dp(cfg.stH), (h * 0.9f).toInt())
    }

    fun defaultStartHeightDp(): Int =
        (minOf(dp(540), (resources.displayMetrics.heightPixels * 0.72f).toInt()) /
            resources.displayMetrics.density).toInt()

    private fun placePanels() {
        val top = cfg.tbPos == 1
        val vg = if (top) Gravity.TOP else Gravity.BOTTOM
        val edge = dp(8)
        for (pn in listOf<View>(quickPanel, calPanel, notifPanel)) {
            val lp = pn.layoutParams as FrameLayout.LayoutParams
            lp.gravity = vg or Gravity.END
            lp.topMargin = if (top) edge else 0
            lp.bottomMargin = if (top) 0 else edge
            lp.rightMargin = edge
            pn.layoutParams = lp
        }
        val slp = searchPanel.layoutParams as FrameLayout.LayoutParams
        slp.gravity = vg or Gravity.START
        slp.topMargin = if (top) edge else 0
        slp.bottomMargin = if (top) 0 else edge
        slp.leftMargin = edge
        searchPanel.layoutParams = slp

        val lp = startPanel.layoutParams as FrameLayout.LayoutParams
        lp.width = minOf(dp(cfg.stW), screenW - dp(16))
        lp.height = startHeightPx()
        val centered = cfg.stPos == 1
        lp.gravity = when (cfg.stPos) {
            1 -> Gravity.CENTER
            2 -> vg or Gravity.START
            else -> vg or Gravity.CENTER_HORIZONTAL
        }
        lp.topMargin = if (top && !centered) edge else 0
        lp.bottomMargin = if (!top && !centered) edge else 0
        lp.leftMargin = if (cfg.stPos == 2) edge else 0
        lp.rightMargin = 0
        startPanel.layoutParams = lp
    }

    private fun applyDesktopPrefs() {
        desktopAdapter.iconDp = cfg.dkIcon
        desktopGrid.numColumns = maxOf(3, screenW / dp(cfg.dkIcon + 40))
        desktopGrid.visibility = if (cfg.dkShow) View.VISIBLE else View.GONE
        desktopAdapter.notifyDataSetChanged()
    }

    fun applyPrefs() {
        if (!::taskbar.isInitialized || !::notifPanel.isInitialized) return
        val top = cfg.tbPos == 1
        val wantIdx = if (top) 0 else uiCol.childCount - 1
        if (uiCol.indexOfChild(taskbar) != wantIdx) {
            uiCol.removeView(taskbar)
            if (top) {
                uiCol.addView(taskbar, 0, LinearLayout.LayoutParams(MATCH, WRAP))
            } else {
                uiCol.addView(taskbar, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }
        applyInsets()
        applyTaskbarBackground()
        applyTaskbarMetrics()
        rebuildTaskbar()
        applyDesktopPrefs()
        startPanel.background = panelBackground(startPanel, cfg.stAlpha, cfg.stRadius, cfg.stGlass)
        startGrid.numColumns = cfg.stCols
        quickPanel.background = panelBackground(quickPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        calPanel.background = panelBackground(calPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        searchPanel.background = panelBackground(searchPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        notifPanel.background = panelBackground(notifPanel, cfg.pnAlpha, 12, cfg.pnGlass)
        placePanels()
        invalidateGlass()
    }

    private fun invalidateGlass() {
        if (!::notifPanel.isInitialized) return
        for (v in listOf<View>(taskbar, startPanel, quickPanel, calPanel, searchPanel, notifPanel)) {
            v.invalidate()
        }
    }

    /** Refaz a tela inteira (tema/cor) e reabre o painel de personalização na categoria [cat]. */
    fun themeChanged(cat: Int) {
        prefs.edit().putInt("ui_reopen", cat).apply()
        recreate()
    }

    private fun reopenCustomize(cat: Int) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        root.postDelayed({
            menu.show(buildDesktopItems(), loc[0] + dp(24), loc[1] + dp(60))
            root.postDelayed({
                menu.openRow(0, 3)
                root.postDelayed({ menu.openRow(1, cat) }, 90)
            }, 90)
        }, 150)
    }

    fun refreshCursor() {
        cursor.rebuild()
        applyCursorToRoot()
    }

    private fun applyCursorToRoot() {
        try {
            root.pointerIcon = if (cfg.cursorOn) cursor.arrow else null
        } catch (e: Exception) {
        }
    }

    fun openDisplaySettings() {
        safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS))
    }

    // ================================================================== novo: vidro (snapshot do wallpaper)

    private fun updateGlassSource() {
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val s = prefs.getString("wp", null)
        val isVideo = prefs.getBoolean("wpVideo", false)
        Thread {
            var bmp: Bitmap? = null
            try {
                if (s == null) {
                    val small = Bitmap.createBitmap(maxOf(8, w / 8), maxOf(8, h / 8), Bitmap.Config.ARGB_8888)
                    val g = GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        intArrayOf(
                            Color.parseColor("#0B1E3F"),
                            Color.parseColor("#1B5FD0"),
                            Color.parseColor("#0A2A66")
                        )
                    )
                    g.setBounds(0, 0, small.width, small.height)
                    g.draw(Canvas(small))
                    bmp = Glass.makeBlur(small, w, h)
                } else if (isVideo) {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(this, Uri.parse(s))
                        val f = mmr.getFrameAtTime(0)
                        if (f != null) bmp = Glass.makeBlur(f, w, h)
                    } finally {
                        try {
                            mmr.release()
                        } catch (e: Exception) {
                        }
                    }
                } else {
                    val src = decodeForGlass(Uri.parse(s), w, h)
                    if (src != null) bmp = Glass.makeBlur(src, w, h)
                }
            } catch (t: Throwable) {
                bmp = null
            }
            val result = bmp
            runOnUiThread {
                Glass.bitmap = result
                invalidateGlass()
            }
        }.start()
    }

    private fun decodeForGlass(uri: Uri, w: Int, h: Int): Bitmap? {
        return if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val sc = minOf(1f, maxOf(w, h) / 2f / maxOf(info.size.width, info.size.height))
                decoder.setTargetSize(
                    maxOf(1, (info.size.width * sc).toInt()),
                    maxOf(1, (info.size.height * sc).toInt())
                )
            }
        } else {
            val o = BitmapFactory.Options()
            o.inSampleSize = 4
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        }
    }

    // ================================================================== novo: botão direito e menus

    private fun isRightClick(ev: MotionEvent): Boolean =
        ev.actionMasked == MotionEvent.ACTION_DOWN &&
            ev.isFromSource(InputDevice.SOURCE_MOUSE) &&
            (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0

    private fun rightClick(v: View, f: (Int, Int) -> Unit) {
        v.setOnTouchListener { _, ev ->
            if (isRightClick(ev)) {
                f(ev.rawX.toInt(), ev.rawY.toInt())
                true
            } else {
                false
            }
        }
    }

    private fun canUninstall(pkg: String): Boolean = try {
        val fl = packageManager.getApplicationInfo(pkg, 0).flags
        (fl and ApplicationInfo.FLAG_SYSTEM) == 0 || (fl and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
    } catch (e: Exception) {
        false
    }

    private fun appContextMenu(app: AppItem, x: Int, y: Int) {
        val key = app.cn.flattenToString()
        val pkg = app.cn.packageName
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Abrir", R.drawable.ic_open, action = { launch(app.cn) }))
        items.add(
            MenuItem(
                if (key in getList("tb")) "Desafixar da barra de tarefas" else "Fixar na barra de tarefas",
                R.drawable.ic_pin,
                action = { toggle("tb", key) }
            )
        )
        items.add(
            MenuItem(
                if (key in getList("dk")) "Remover da área de trabalho" else "Adicionar à área de trabalho",
                R.drawable.ic_view,
                action = { toggle("dk", key) }
            )
        )
        items.add(
            MenuItem(
                "Informações do aplicativo",
                R.drawable.ic_info,
                action = {
                    safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)))
                }
            )
        )
        if (canUninstall(pkg)) {
            items.add(
                MenuItem(
                    "Desinstalar",
                    R.drawable.ic_delete,
                    action = { safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))) }
                )
            )
        }
        menu.show(items, x, y)
    }

    private fun desktopContextMenu(x: Int, y: Int) {
        menu.show(buildDesktopItems(), x, y)
    }

    private fun setDesktopIcon(size: Int) {
        cfg.dkIcon = size
        applyPrefs()
    }

    private fun buildDesktopItems(): List<MenuItem> = listOf(
        MenuItem("Atualizar", R.drawable.ic_refresh, action = { refreshAll() }),
        MenuItem(
            "Exibir",
            R.drawable.ic_view,
            children = listOf(
                MenuItem("Ícones grandes", checked = cfg.dkIcon == 56, action = { setDesktopIcon(56) }),
                MenuItem("Ícones médios", checked = cfg.dkIcon == 44, action = { setDesktopIcon(44) }),
                MenuItem("Ícones pequenos", checked = cfg.dkIcon == 32, action = { setDesktopIcon(32) }),
                MenuItem(
                    "Mostrar ícones da área de trabalho",
                    checked = cfg.dkShow,
                    action = {
                        cfg.dkShow = !cfg.dkShow
                        applyPrefs()
                    }
                )
            )
        ),
        MenuItem(
            "Trocar wallpaper",
            R.drawable.ic_image,
            children = listOf(
                MenuItem("Estático", action = { pickWallpaperStatic() }),
                MenuItem("Animado", action = { pickWallpaperAnimated() }),
                MenuItem("Restaurar padrão", action = { resetWallpaper() })
            )
        ),
        MenuItem("Personalizar WinLauncher", R.drawable.ic_palette, children = customize.categories()),
        MenuItem(
            "Configurações de exibição",
            R.drawable.ic_brightness,
            action = { safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        ),
        MenuItem(
            "Configurações",
            R.drawable.ic_settings,
            action = { safeStart(Intent(Settings.ACTION_SETTINGS)) }
        )
    )

    private fun refreshAll() {
        loadApps { onAppsLoaded() }
        updateGlassSource()
        updateBell()
    }

    fun pickWallpaperStatic() = pickWallpaperOf(
        arrayOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif", "image/bmp")
    )

    fun pickWallpaperAnimated() = pickWallpaperOf(arrayOf("image/gif", "video/*"))

    fun resetWallpaper() {
        prefs.edit().remove("wp").remove("wpVideo").apply()
        applyWallpaper()
    }

    // ================================================================== novo: pesquisa na barra

    private fun buildSearchPanel() {
        searchPanel = LinearLayout(this)
        searchPanel.orientation = LinearLayout.VERTICAL
        searchPanel.background = rounded(cPanel, 12)
        searchPanel.setPadding(dp(14), dp(14), dp(14), dp(10))
        searchPanel.visibility = View.GONE
        searchPanel.isClickable = true
        searchPanel.tag = CursorController.NOHAND
        searchPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(
            minOf(dp(380), screenW - dp(16)), WRAP, Gravity.BOTTOM or Gravity.START
        )
        lp.bottomMargin = dp(8)
        lp.leftMargin = dp(8)
        overlay.addView(searchPanel, lp)

        tbSearchBox = EditText(this)
        tbSearchBox.hint = "Pesquisar aplicativos"
        tbSearchBox.setHintTextColor(cSub)
        tbSearchBox.setTextColor(cText)
        tbSearchBox.textSize = 14f
        tbSearchBox.background = rounded(cTile, 20)
        tbSearchBox.setPadding(dp(14), 0, dp(14), 0)
        tbSearchBox.setSingleLine(true)
        tbSearchBox.imeOptions = EditorInfo.IME_ACTION_DONE
        tbSearchBox.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        tbSearchBox.compoundDrawableTintList = ColorStateList.valueOf(cText)
        tbSearchBox.compoundDrawablePadding = dp(8)
        searchPanel.addView(tbSearchBox, LinearLayout.LayoutParams(MATCH, dp(40)))
        tbSearchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                updateSearchResults(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        tbSearchBox.setOnKeyListener { _, keyCode, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        moveSel(1)
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        moveSel(-1)
                        true
                    }
                    KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        launchSel()
                        true
                    }
                    else -> false
                }
            } else {
                false
            }
        }
        tbSearchBox.setOnEditorActionListener { _, _, _ ->
            launchSel()
            true
        }

        tbResults = LinearLayout(this)
        tbResults.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(tbResults)
        searchPanel.addView(sv, lpTop(8))
    }

    private fun updateSearchResults(q: String) {
        tbResults.removeAllViews()
        val query = q.trim()
        tbMatches = if (query.isEmpty()) emptyList() else allApps.filter { it.label.contains(query, true) }.take(8)
        tbSel = 0
        if (query.isNotEmpty() && tbMatches.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Nenhum aplicativo encontrado"
            tv.setTextColor(cSub)
            tv.textSize = 13f
            tv.setPadding(dp(4), dp(10), dp(4), dp(10))
            tbResults.addView(tv)
        }
        for (i in tbMatches.indices) {
            val app = tbMatches[i]
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(8), 0, dp(8), 0)
            row.isClickable = true
            val iv = ImageView(this)
            iv.setImageDrawable(ic(app))
            row.addView(iv, LinearLayout.LayoutParams(dp(30), dp(30)))
            val tv = TextView(this)
            tv.text = app.label
            tv.setTextColor(cText)
            tv.textSize = 14f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            val tlp = LinearLayout.LayoutParams(0, WRAP, 1f)
            tlp.leftMargin = dp(12)
            row.addView(tv, tlp)
            row.setOnClickListener { if (!rightClickRecent()) launch(app.cn) }
            row.setOnHoverListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_HOVER_ENTER) {
                    tbSel = i
                    paintSel()
                }
                false
            }
            rightClick(row) { x, y -> appContextMenu(app, x, y) }
            tbResults.addView(row, LinearLayout.LayoutParams(MATCH, dp(44)))
        }
        paintSel()
    }

    private fun paintSel() {
        for (i in 0 until tbResults.childCount) {
            val child = tbResults.getChildAt(i)
            if (i < tbMatches.size && i == tbSel) {
                child.background = rounded(cTile, 8)
            } else {
                child.background = null
            }
        }
    }

    private fun moveSel(d: Int) {
        if (tbMatches.isEmpty()) return
        tbSel = (tbSel + d).coerceIn(0, tbMatches.size - 1)
        paintSel()
    }

    private fun launchSel() {
        val app = tbMatches.getOrNull(tbSel) ?: return
        launch(app.cn)
    }

    fun openSearch() {
        showPanel(startPanel)
        searchBox.setText("")
        searchBox.requestFocus()
        searchBox.post {
            try {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(searchBox, 0)
            } catch (e: Exception) {
            }
        }
    }

    // ================================================================== previsão do tempo

    private fun toggleWeather() {
        weatherOpen = !weatherOpen
        if (weatherOpen) refreshWeather(false)
        updateWeatherCardVisibility()
    }

    private fun updateWeatherCardVisibility() {
        if (!::weatherCard.isInitialized || !::searchBox.isInitialized) return
        weatherCard.visibility =
            if (weatherData != null && weatherOpen && searchBox.text.isNullOrEmpty()) View.VISIBLE else View.GONE
    }

    private fun refreshWeather(force: Boolean) {
        if (weatherLoading && !force) return
        if (weatherData == null) {
            weatherData = Weather.load(prefs)
            renderWeather()
        }
        val fresh = weatherData?.let { System.currentTimeMillis() - it.fetchedAt < 30 * 60 * 1000L } ?: false
        if (fresh && !force) return
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("wxAsked", false)
        ) {
            prefs.edit().putBoolean("wxAsked", true).apply()
            try {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
            } catch (e: Exception) {
            }
        }
        weatherLoading = true
        val app = applicationContext
        Thread {
            val data = try {
                Weather.fetchAuto(app, prefs)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                weatherLoading = false
                if (data != null) {
                    weatherData = data
                    renderWeather()
                }
            }
        }.start()
    }

    private fun renderWeather() {
        updateTbWeather()
        if (!::weatherChip.isInitialized) return
        val w = weatherData
        if (w == null) {
            weatherChip.visibility = View.GONE
            weatherCard.visibility = View.GONE
            return
        }
        weatherChip.setTextColor(cText)
        weatherChip.text = Weather.emoji(w.code, w.isDay) + " " + w.temp + "°"
        weatherChip.visibility = View.VISIBLE

        weatherCard.removeAllViews()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL

        val big = TextView(this)
        big.text = Weather.emoji(w.code, w.isDay)
        big.textSize = 34f
        head.addView(big, LinearLayout.LayoutParams(WRAP, WRAP))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = w.temp.toString() + "°C"
        t1.setTextColor(cText)
        t1.textSize = 22f
        t1.typeface = Typeface.DEFAULT_BOLD
        mid.addView(t1)
        val t2 = TextView(this)
        t2.text = Weather.describe(w.code) + " · " + w.city
        t2.setTextColor(cSub)
        t2.textSize = 12f
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        mid.addView(t2)
        val mlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        mlp.leftMargin = dp(12)
        head.addView(mid, mlp)

        val side = TextView(this)
        side.text = "Sensação " + w.feels + "°\nUmidade " + w.humidity + "%\nVento " + w.wind + " km/h"
        side.setTextColor(cSub)
        side.textSize = 11f
        side.gravity = Gravity.END
        head.addView(side, LinearLayout.LayoutParams(WRAP, WRAP))
        weatherCard.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (d in w.days) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val l = TextView(this)
            l.text = d.label
            l.setTextColor(cSub)
            l.textSize = 11f
            l.gravity = Gravity.CENTER
            col.addView(l)
            val e = TextView(this)
            e.text = Weather.emoji(d.code, true)
            e.textSize = 18f
            e.gravity = Gravity.CENTER
            col.addView(e)
            val m = TextView(this)
            m.text = d.max.toString() + "° / " + d.min + "°"
            m.setTextColor(cText)
            m.textSize = 11f
            m.gravity = Gravity.CENTER
            col.addView(m)
            val r = TextView(this)
            r.text = if (d.rain >= 20) "💧" + d.rain + "%" else " "
            r.setTextColor(cSub)
            r.textSize = 10f
            r.gravity = Gravity.CENTER
            col.addView(r)
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        weatherCard.addView(row, lpTop(10))
        updateWeatherCardVisibility()
    }

    // ================================================================== novo: central de notificações

    private fun notifAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun buildNotifPanel() {
        notifPanel = LinearLayout(this)
        notifPanel.orientation = LinearLayout.VERTICAL
        notifPanel.background = rounded(cPanel, 12)
        notifPanel.setPadding(dp(16), dp(14), dp(16), dp(12))
        notifPanel.visibility = View.GONE
        notifPanel.isClickable = true
        notifPanel.tag = CursorController.NOHAND
        notifPanel.elevation = dp(8).toFloat()
        val lp = FrameLayout.LayoutParams(panelW(), WRAP, Gravity.BOTTOM or Gravity.END)
        lp.bottomMargin = dp(8)
        lp.rightMargin = dp(8)
        overlay.addView(notifPanel, lp)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Notificações"
        title.setTextColor(cText)
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        notifClear = TextView(this)
        notifClear.text = "Limpar tudo"
        notifClear.setTextColor(cAccent)
        notifClear.textSize = 12f
        notifClear.setPadding(dp(8), dp(6), dp(8), dp(6))
        notifClear.isClickable = true
        notifClear.setOnClickListener {
            LauncherNotificationListener.dismissAll()
            updateBell()
        }
        head.addView(notifClear, LinearLayout.LayoutParams(WRAP, WRAP))
        notifPanel.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        notifBody = LinearLayout(this)
        notifBody.orientation = LinearLayout.VERTICAL
        notifScroll = ScrollView(this)
        notifScroll.isVerticalScrollBarEnabled = false
        notifScroll.addView(notifBody)
        notifPanel.addView(notifScroll, lpTop(8))
    }

    private fun refreshNotifPanel() {
        notifBody.removeAllViews()
        if (!notifAccess()) {
            notifClear.visibility = View.GONE
            val msg = TextView(this)
            msg.text = "Para mostrar as notificações do Android aqui, o WinLauncher precisa de acesso às notificações. " +
                "Você controla isso nas configurações do sistema e pode revogar quando quiser. " +
                "As notificações não são salvas nem enviadas para fora do aparelho."
            msg.setTextColor(cSub)
            msg.textSize = 12.5f
            notifBody.addView(msg, LinearLayout.LayoutParams(MATCH, WRAP))
            notifBody.addView(
                notifButton("Conceder acesso") {
                    safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                },
                lpTop(10)
            )
            val hint = TextView(this)
            hint.text = "Se a opção aparecer bloqueada (Android 13+), abra as informações do app, toque em ⋮ e escolha \"Permitir configurações restritas\"."
            hint.setTextColor(cSub)
            hint.textSize = 11.5f
            notifBody.addView(hint, lpTop(8))
            notifBody.addView(
                notifButton("Informações do app") {
                    safeStart(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + packageName)
                        )
                    )
                },
                lpTop(8)
            )
        } else {
            notifClear.visibility = View.VISIBLE
            val list = LauncherNotificationListener.current(packageName)
            if (list.isEmpty()) {
                val tv = TextView(this)
                tv.text = "Nenhuma notificação nova"
                tv.setTextColor(cSub)
                tv.textSize = 13f
                tv.setPadding(0, dp(16), 0, dp(16))
                notifBody.addView(tv)
            } else {
                for (sbn in list) notifBody.addView(notifRow(sbn), lpTop(6))
            }
        }
        notifBody.measure(
            View.MeasureSpec.makeMeasureSpec(panelW() - dp(32), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val cap = (resources.displayMetrics.heightPixels * 0.55f).toInt()
        val slp = notifScroll.layoutParams as LinearLayout.LayoutParams
        slp.height = minOf(notifBody.measuredHeight, cap)
        notifScroll.layoutParams = slp
    }

    private fun notifButton(text: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.BLACK)
        b.textSize = 13f
        b.gravity = Gravity.CENTER
        b.background = rounded(cAccent, 8)
        b.setPadding(dp(12), dp(10), dp(12), dp(10))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        return b
    }

    private fun notifRow(sbn: StatusBarNotification): View {
        val n = sbn.notification
        val ex = n.extras
        val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex?.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex?.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        val appLabel = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val icon: Drawable? = try {
            packageManager.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = rip(cTile, 8)
        row.setPadding(dp(10), dp(8), dp(4), dp(8))
        row.isClickable = true
        row.setOnClickListener { openNotification(sbn) }

        val iv = ImageView(this)
        if (icon != null) iv.setImageDrawable(icon)
        row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val meta = TextView(this)
        meta.text = appLabel + " · " + SimpleDateFormat("HH:mm", ptBR).format(Date(sbn.postTime))
        meta.setTextColor(cSub)
        meta.textSize = 11f
        meta.maxLines = 1
        meta.ellipsize = TextUtils.TruncateAt.END
        col.addView(meta)
        if (title.isNotEmpty()) {
            val t = TextView(this)
            t.text = title
            t.setTextColor(cText)
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t)
        }
        if (text.isNotEmpty()) {
            val t = TextView(this)
            t.text = text
            t.setTextColor(cSub)
            t.textSize = 12f
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t)
        }
        val clp = LinearLayout.LayoutParams(0, WRAP, 1f)
        clp.leftMargin = dp(10)
        row.addView(col, clp)

        val x = TextView(this)
        x.text = "✕"
        x.setTextColor(cSub)
        x.textSize = 14f
        x.gravity = Gravity.CENTER
        x.isClickable = true
        x.setOnClickListener {
            LauncherNotificationListener.dismiss(sbn.key)
            updateBell()
        }
        row.addView(x, LinearLayout.LayoutParams(dp(36), dp(36)))
        return row
    }

    private fun openNotification(sbn: StatusBarNotification) {
        try {
            sbn.notification.contentIntent?.send()
        } catch (e: Exception) {
            toast("Não foi possível abrir")
        }
        if ((sbn.notification.flags and Notification.FLAG_AUTO_CANCEL) != 0) {
            LauncherNotificationListener.dismiss(sbn.key)
        }
        closeAll()
    }

    fun updateBell() {
        if (!::bellBadge.isInitialized || !::notifPanel.isInitialized) return
        val c = if (notifAccess()) LauncherNotificationListener.current(packageName).size else 0
        bellBadge.visibility = if (c > 0) View.VISIBLE else View.GONE
        bellBadge.text = if (c > 9) "9+" else c.toString()
        if (notifPanel.visibility == View.VISIBLE) refreshNotifPanel()
    }

    // ================================================================== novo: painéis

    private fun showPanel(p: View) {
        for (x in listOf<View>(startPanel, quickPanel, calPanel, searchPanel, notifPanel)) {
            x.visibility = if (x === p) View.VISIBLE else View.GONE
        }
        overlay.visibility = View.VISIBLE
        if (cfg.anim) {
            p.alpha = 0f
            p.translationY = dp(if (cfg.tbPos == 1) -24 else 24).toFloat()
            p.animate().alpha(1f).translationY(0f).setDuration(140).start()
        } else {
            p.alpha = 1f
            p.translationY = 0f
        }
        if (p === quickPanel) refreshQuick()
        else if (p === calPanel) showCalendar()
        else if (p === notifPanel) refreshNotifPanel()
        else if (p === startPanel) refreshWeather(false)
    }

    private fun closeAll() {
        if (::menu.isInitialized) menu.hide()
        if (!::overlay.isInitialized) return
        overlay.visibility = View.GONE
        startPanel.visibility = View.GONE
        quickPanel.visibility = View.GONE
        calPanel.visibility = View.GONE
        searchPanel.visibility = View.GONE
        notifPanel.visibility = View.GONE
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(root.windowToken, 0)
        } catch (e: Exception) {
        }
        searchBox.clearFocus()
        if (searchBox.text.isNotEmpty()) searchBox.setText("")
        tbSearchBox.clearFocus()
        if (tbSearchBox.text.isNotEmpty()) tbSearchBox.setText("")
    }

    // ---------------------------------------------------------------- adapter

    inner class AppAdapter(
        var items: List<AppItem>,
        var iconDp: Int,
        private val textSp: Float,
        private val panelMode: Boolean = false
    ) : BaseAdapter() {

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView is LinearLayout) {
                row = convertView
            } else {
                row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.VERTICAL
                row.gravity = Gravity.CENTER_HORIZONTAL
                row.setPadding(dp(4), dp(8), dp(4), dp(8))
                val iv = ImageView(this@MainActivity)
                row.addView(iv, LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
                val tv = TextView(this@MainActivity)
                tv.setTextColor(Color.WHITE)
                tv.textSize = textSp
                tv.gravity = Gravity.CENTER
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                tv.setShadowLayer(3f, 0f, 1f, Color.BLACK)
                val tlp = LinearLayout.LayoutParams(MATCH, WRAP)
                tlp.topMargin = dp(4)
                row.addView(tv, tlp)
            }
            val app = items[position]
            val iv0 = row.getChildAt(0) as ImageView
            val want = dp(iconDp)
            val cur = iv0.layoutParams
            if (cur == null || cur.width != want) iv0.layoutParams = LinearLayout.LayoutParams(want, want)
            iv0.setImageDrawable(ic(app))
            val tv0 = row.getChildAt(1) as TextView
            tv0.text = app.label
            tv0.setTextColor(if (panelMode) cText else Color.WHITE)
            return row
        }
    }
}
