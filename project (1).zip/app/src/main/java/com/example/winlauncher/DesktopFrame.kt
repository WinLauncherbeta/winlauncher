package com.example.winlauncher

import android.content.Context
import android.graphics.Rect
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Área de trabalho: único dono dos gestos do botão esquerdo (ou do dedo).
 *
 *  - arrastar em área vazia            -> caixa de seleção White Glass
 *  - arrastar em app (selecionado ou não) -> mover o app / o grupo selecionado
 *  - toque longo + arrastar no widget de relógio -> mover o widget (se a movimentação estiver permitida)
 *  - toque simples                     -> passa para as views (abre o app normalmente)
 *  - botão direito                     -> não é tratado aqui; segue para o menu de contexto
 *
 * Não existe mais gesto de segurar/toque longo para abrir menu.
 */
class DesktopFrame(ctx: Context, private val host: Host) : FrameLayout(ctx) {

    interface Host {
        fun canGesture(): Boolean
        fun itemAt(x: Float, y: Float): Int
        fun isSelected(pos: Int): Boolean
        fun selectOnly(pos: Int)
        fun clearSelection()
        fun marquee(r: Rect?)
        fun dragMove(dx: Float, dy: Float)
        fun dragEnd(x: Float, y: Float, anchor: Int, commit: Boolean)

        /** O ponto está sobre o widget de relógio e ele pode ser movido agora? */
        fun widgetAt(x: Float, y: Float): Boolean = false
        fun widgetDragMove(dx: Float, dy: Float) {}
        fun widgetDragEnd(commit: Boolean) {}

        /** Toque longo no widget reconhecido (true) ou gesto terminado sem mover (false). */
        fun widgetArmed(on: Boolean) {}
    }

    private enum class Mode { IDLE, PENDING, MARQUEE, MOVING, WIDGET }

    private var mode = Mode.IDLE
    private var widgetHit = false
    private var widgetArmed = false
    private val longPress = Runnable {
        if (mode == Mode.PENDING && widgetHit && anchor < 0) {
            widgetArmed = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            host.widgetArmed(true)
        }
    }
    private var downX = 0f
    private var downY = 0f
    private var anchor = -1
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            mode = Mode.IDLE
            widgetHit = false
            widgetArmed = false
            removeCallbacks(longPress)
            val otherButton = (ev.buttonState and (MotionEvent.BUTTON_SECONDARY or MotionEvent.BUTTON_TERTIARY)) != 0
            if (otherButton) return super.dispatchTouchEvent(ev)
            val iconsOn = host.canGesture()
            widgetHit = host.widgetAt(ev.x, ev.y)
            if (!iconsOn && !widgetHit) return super.dispatchTouchEvent(ev)
            mode = Mode.PENDING
            downX = ev.x
            downY = ev.y
            anchor = if (iconsOn) host.itemAt(ev.x, ev.y) else -1
            if (widgetHit && anchor < 0) postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            super.dispatchTouchEvent(ev)
            return true // fico com o resto do gesto para decidir entre clique, seleção e movimento
        }
        if (mode == Mode.IDLE) return super.dispatchTouchEvent(ev)

        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> when (mode) {
                Mode.PENDING ->
                    if (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop) {
                        removeCallbacks(longPress)
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL // cancela o clique/pressionado dos filhos
                        super.dispatchTouchEvent(c)
                        c.recycle()
                        startGesture(ev)
                    } else {
                        super.dispatchTouchEvent(ev)
                    }
                Mode.MARQUEE -> host.marquee(rect(ev))
                Mode.MOVING -> host.dragMove(ev.x - downX, ev.y - downY)
                Mode.WIDGET -> host.widgetDragMove(ev.x - downX, ev.y - downY)
                else -> {}
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (widgetArmed && mode == Mode.PENDING) host.widgetArmed(false)
                when (mode) {
                    Mode.PENDING -> {
                        super.dispatchTouchEvent(ev) // clique simples: abre o app
                        if (anchor < 0) host.clearSelection() // clique em área vazia desmarca
                    }
                    Mode.MARQUEE -> host.marquee(null)
                    Mode.MOVING -> host.dragEnd(ev.x, ev.y, anchor, true)
                    Mode.WIDGET -> host.widgetDragEnd(true)
                    else -> {}
                }
                mode = Mode.IDLE
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (widgetArmed && mode == Mode.PENDING) host.widgetArmed(false)
                when (mode) {
                    Mode.PENDING -> super.dispatchTouchEvent(ev)
                    Mode.MARQUEE -> host.marquee(null)
                    Mode.MOVING -> host.dragEnd(ev.x, ev.y, anchor, false)
                    Mode.WIDGET -> host.widgetDragEnd(false)
                    else -> {}
                }
                mode = Mode.IDLE
            }
            else -> if (mode == Mode.PENDING) super.dispatchTouchEvent(ev)
        }
        return true
    }

    private fun startGesture(ev: MotionEvent) {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (anchor < 0 && widgetHit && widgetArmed) {
            mode = Mode.WIDGET
            host.widgetDragMove(ev.x - downX, ev.y - downY)
        } else if (anchor >= 0) {
            if (!host.isSelected(anchor)) host.selectOnly(anchor)
            mode = Mode.MOVING
            host.dragMove(ev.x - downX, ev.y - downY)
        } else {
            host.clearSelection()
            mode = Mode.MARQUEE
            host.marquee(rect(ev))
        }
    }

    private fun rect(ev: MotionEvent): Rect {
        val l = max(0f, min(downX, ev.x))
        val t = max(0f, min(downY, ev.y))
        val r = min(width.toFloat(), max(downX, ev.x))
        val b = min(height.toFloat(), max(downY, ev.y))
        return Rect(l.toInt(), t.toInt(), r.toInt(), b.toInt())
    }
}
