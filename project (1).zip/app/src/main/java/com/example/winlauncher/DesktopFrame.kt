package com.example.winlauncher

import android.content.Context
import android.graphics.Rect
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Área de trabalho: único dono dos gestos do botão esquerdo (ou do dedo).
 *
 *  - arrastar em área vazia            -> caixa de seleção White Glass
 *  - arrastar em app (selecionado ou não) -> mover o app / o grupo selecionado
 *  - toque simples                     -> passa para as views (abre o app normalmente)
 *  - botão direito                     -> não é tratado aqui; segue para o menu de contexto
 *
 * Não existe mais gesto de segurar/toque longo para abrir menu.
 */
class DesktopFrame(ctx: Context, private val host: Host) : FrameLayout(ctx) {

    interface Host {
        fun canGesture(): Boolean
        fun itemAt(x: Float, y: Float): Int
        fun isSelected(pos: Int): Boolean
        fun selectOnly(pos: Int)
        fun clearSelection()
        fun marquee(r: Rect?)
        fun dragMove(dx: Float, dy: Float)
        fun dragEnd(x: Float, y: Float, anchor: Int, commit: Boolean)
    }

    private enum class Mode { IDLE, PENDING, MARQUEE, MOVING }

    private var mode = Mode.IDLE
    private var downX = 0f
    private var downY = 0f
    private var anchor = -1
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            mode = Mode.IDLE
            val otherButton = (ev.buttonState and (MotionEvent.BUTTON_SECONDARY or MotionEvent.BUTTON_TERTIARY)) != 0
            if (otherButton || !host.canGesture()) return super.dispatchTouchEvent(ev)
            mode = Mode.PENDING
            downX = ev.x
            downY = ev.y
            anchor = host.itemAt(ev.x, ev.y)
            super.dispatchTouchEvent(ev)
            return true // fico com o resto do gesto para decidir entre clique, seleção e movimento
        }
        if (mode == Mode.IDLE) return super.dispatchTouchEvent(ev)

        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> when (mode) {
                Mode.PENDING ->
                    if (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop) {
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL // cancela o clique/pressionado dos filhos
                        super.dispatchTouchEvent(c)
                        c.recycle()
                        startGesture(ev)
                    } else {
                        super.dispatchTouchEvent(ev)
                    }
                Mode.MARQUEE -> host.marquee(rect(ev))
                Mode.MOVING -> host.dragMove(ev.x - downX, ev.y - downY)
                else -> {}
            }
            MotionEvent.ACTION_UP -> {
                when (mode) {
                    Mode.PENDING -> {
                        super.dispatchTouchEvent(ev) // clique simples: abre o app
                        if (anchor < 0) host.clearSelection() // clique em área vazia desmarca
                    }
                    Mode.MARQUEE -> host.marquee(null)
                    Mode.MOVING -> host.dragEnd(ev.x, ev.y, anchor, true)
                    else -> {}
                }
                mode = Mode.IDLE
            }
            MotionEvent.ACTION_CANCEL -> {
                when (mode) {
                    Mode.PENDING -> super.dispatchTouchEvent(ev)
                    Mode.MARQUEE -> host.marquee(null)
                    Mode.MOVING -> host.dragEnd(ev.x, ev.y, anchor, false)
                    else -> {}
                }
                mode = Mode.IDLE
            }
            else -> if (mode == Mode.PENDING) super.dispatchTouchEvent(ev)
        }
        return true
    }

    private fun startGesture(ev: MotionEvent) {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (anchor >= 0) {
            if (!host.isSelected(anchor)) host.selectOnly(anchor)
            mode = Mode.MOVING
            host.dragMove(ev.x - downX, ev.y - downY)
        } else {
            host.clearSelection()
            mode = Mode.MARQUEE
            host.marquee(rect(ev))
        }
    }

    private fun rect(ev: MotionEvent): Rect {
        val l = max(0f, min(downX, ev.x))
        val t = max(0f, min(downY, ev.y))
        val r = min(width.toFloat(), max(downX, ev.x))
        val b = min(height.toFloat(), max(downY, ev.y))
        return Rect(l.toInt(), t.toInt(), r.toInt(), b.toInt())
    }
}
