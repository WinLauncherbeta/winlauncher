package com.example.winlauncher

import android.app.ActivityManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import java.io.File
import java.util.Locale

/** Dados estáticos do processador (não mudam enquanto o app roda). */
class CpuStatic(
    val vendor: String?,
    /** Nome completo para exibição, ex.: "Qualcomm Snapdragon 680". */
    val title: String?,
    /** Código bruto do SoC informado pelo sistema, ex.: "SM6225". */
    val model: String?,
    /** Código para mostrar em letras pequenas (só quando o título usa o nome comercial). */
    val code: String?,
    val cores: Int?
)

class CpuLive(val curKHz: Long?, val maxKHz: Long?)

class Usage(val total: Long, val used: Long) {
    val avail: Long get() = (total - used).coerceAtLeast(0)
    val pct: Int
        get() = if (total > 0) ((used * 100.0 / total) + 0.5).toInt().coerceIn(0, 100) else 0
}

/**
 * Lê informações reais de hardware do aparelho. Nada aqui é valor fixo de exemplo:
 * quando o Android não permite a leitura, a função devolve null (a janela mostra "Não disponível").
 */
object HwInfo {

    private val PT = Locale("pt", "BR")
    private val CPU_DIR = Regex("cpu\\d+")

    // Tabela de nomes comerciais Qualcomm (código SM -> nome). O código real sempre é exibido junto.
    private val QCOM = mapOf(
        "SM4250" to "Snapdragon 460",
        "SM6115" to "Snapdragon 662",
        "SM6125" to "Snapdragon 665",
        "SM6150" to "Snapdragon 675",
        "SM6225" to "Snapdragon 680",
        "SM6350" to "Snapdragon 690",
        "SM6375" to "Snapdragon 695",
        "SM7125" to "Snapdragon 720G",
        "SM7150" to "Snapdragon 730",
        "SM7225" to "Snapdragon 750G",
        "SM7250" to "Snapdragon 765G",
        "SM7325" to "Snapdragon 778G",
        "SM8150" to "Snapdragon 855",
        "SM8250" to "Snapdragon 865",
        "SM8350" to "Snapdragon 888",
        "SM8450" to "Snapdragon 8 Gen 1",
        "SM8475" to "Snapdragon 8+ Gen 1",
        "SM8550" to "Snapdragon 8 Gen 2",
        "SM8650" to "Snapdragon 8 Gen 3",
        "SM8750" to "Snapdragon 8 Elite"
    )

    // ------------------------------------------------------------------ CPU

    fun loadCpu(): CpuStatic {
        var man: String? = null
        var model: String? = null
        if (Build.VERSION.SDK_INT >= 31) {
            man = clean(Build.SOC_MANUFACTURER)
            model = clean(Build.SOC_MODEL)
        }
        if (model == null) model = clean(prop("ro.soc.model"))
        if (man == null) man = clean(prop("ro.soc.manufacturer"))
        if (model == null) model = clean(cpuinfoName())
        if (model == null) {
            val h = clean(Build.HARDWARE)
            if (h != null && !isGeneric(h)) model = h
        }

        val vendor = normVendor(man)
            ?: model?.let { vendorFromCode(it) }
            ?: vendorFromCode(Build.HARDWARE)

        var title: String? = null
        var code: String? = null
        if (model != null) {
            val nice = marketingName(vendor, model)
            if (nice != null) {
                title = (vendor?.let { "$it " } ?: "") + nice
                code = model
            } else {
                title = if (vendor == null || model.contains(vendor, ignoreCase = true)) model else "$vendor $model"
            }
        }
        return CpuStatic(vendor, title, model, code, coreCount())
    }

    private fun marketingName(vendor: String?, model: String): String? {
        val m = model.uppercase(Locale.ROOT).trim()
        if (vendor == "Qualcomm") {
            QCOM[m.substringBefore('-')]?.let { return it }
            Regex("^SDM(\\d+)").find(m)?.let { return "Snapdragon " + it.groupValues[1] }
        }
        return null
    }

    fun coreCount(): Int? {
        val listed = try {
            File("/sys/devices/system/cpu").listFiles()?.count { it.name.matches(CPU_DIR) } ?: 0
        } catch (t: Throwable) {
            0
        }
        val best = maxOf(listed, Runtime.getRuntime().availableProcessors())
        return if (best > 0) best else null
    }

    /** Frequência atual (maior entre os núcleos legíveis) e máxima, em kHz. */
    fun cpuLive(): CpuLive {
        val n = coreCount() ?: 0
        var cur: Long? = null
        var max: Long? = null
        for (i in 0 until n) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val c = readLong(base + "scaling_cur_freq") ?: readLong(base + "cpuinfo_cur_freq")
            if (c != null && (cur == null || c > cur)) cur = c
            val m = readLong(base + "cpuinfo_max_freq") ?: readLong(base + "scaling_max_freq")
            if (m != null && (max == null || m > max)) max = m
        }
        return CpuLive(cur, max)
    }

    // ------------------------------------------------------------------ memória

    fun ram(ctx: Context): Usage? = try {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        if (mi.totalMem > 0) Usage(mi.totalMem, (mi.totalMem - mi.availMem).coerceIn(0, mi.totalMem)) else null
    } catch (t: Throwable) {
        null
    }

    fun storage(ctx: Context): Usage? {
        try {
            val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
            val total = ssm.getTotalBytes(StorageManager.UUID_DEFAULT)
            val free = ssm.getFreeBytes(StorageManager.UUID_DEFAULT)
            if (total > 0) return Usage(total, (total - free).coerceIn(0, total))
        } catch (t: Throwable) {
        }
        return try {
            val s = StatFs(Environment.getDataDirectory().path)
            val total = s.totalBytes
            val free = s.availableBytes
            if (total > 0) Usage(total, (total - free).coerceIn(0, total)) else null
        } catch (t: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------ formatação

    /** RAM: o kernel reporta em base 1024. */
    fun fmtBin(b: Long): String = fmtUnit(b, 1024.0)

    /** Armazenamento: o Android exibe em base 1000. */
    fun fmtDec(b: Long): String = fmtUnit(b, 1000.0)

    private fun fmtUnit(b: Long, base: Double): String {
        val gb = b / (base * base * base)
        return when {
            gb >= base -> String.format(PT, "%.1f TB", gb / base)
            gb >= 100 -> String.format(PT, "%.0f GB", gb)
            gb >= 1 -> String.format(PT, "%.1f GB", gb)
            else -> String.format(PT, "%.0f MB", b / (base * base))
        }
    }

    fun fmtGhz(kHz: Long): String = String.format(PT, "%.2f GHz", kHz / 1_000_000.0)

    // ------------------------------------------------------------------ utilitários

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLongOrNull()?.takeIf { it > 0 }
    } catch (t: Throwable) {
        null
    }

    private fun prop(name: String): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("getprop", name))
        val s = p.inputStream.bufferedReader().use { it.readText() }.trim()
        p.destroy()
        if (s.isEmpty()) null else s
    } catch (t: Throwable) {
        null
    }

    private fun cpuinfoName(): String? = try {
        File("/proc/cpuinfo").useLines { lines ->
            var hw: String? = null
            var name: String? = null
            for (l in lines) {
                if (hw == null && l.startsWith("Hardware")) hw = l.substringAfter(":").trim()
                if (name == null && l.startsWith("model name")) name = l.substringAfter(":").trim()
            }
            hw ?: name
        }
    } catch (t: Throwable) {
        null
    }

    private fun clean(s: String?): String? {
        val t = s?.trim() ?: return null
        if (t.isEmpty()) return null
        val l = t.lowercase(Locale.ROOT)
        return if (l == "unknown" || l == "generic" || l == "n/a") null else t
    }

    private fun isGeneric(h: String): Boolean {
        val l = h.lowercase(Locale.ROOT)
        return l == "qcom" || l == "ranchu" || l == "goldfish" || l == "board" || l == "device"
    }

    private fun normVendor(raw: String?): String? {
        val s = clean(raw) ?: return null
        val l = s.lowercase(Locale.ROOT)
        return when {
            l.contains("qti") || l.contains("qualcomm") || l.contains("qcom") -> "Qualcomm"
            l.contains("mediatek") || Regex("^mt\\d").containsMatchIn(l) -> "MediaTek"
            l.contains("samsung") || l.contains("exynos") -> "Samsung"
            l.contains("google") || l.contains("tensor") -> "Google"
            l.contains("hisilicon") || l.contains("kirin") -> "HiSilicon"
            l.contains("unisoc") || l.contains("spreadtrum") -> "UNISOC"
            l.contains("intel") -> "Intel"
            l.contains("nvidia") -> "NVIDIA"
            l.contains("rockchip") -> "Rockchip"
            l.contains("amlogic") -> "Amlogic"
            l.contains("allwinner") -> "Allwinner"
            else -> s
        }
    }

    private fun vendorFromCode(code: String?): String? {
        val l = code?.lowercase(Locale.ROOT)?.trim() ?: return null
        return when {
            Regex("^(sm|sdm|msm|apq|qcm|sxr|sa)\\d").containsMatchIn(l) -> "Qualcomm"
            Regex("^mt\\d").containsMatchIn(l) -> "MediaTek"
            l.startsWith("exynos") || l.startsWith("s5e") -> "Samsung"
            Regex("^(gs\\d|zuma|tensor)").containsMatchIn(l) -> "Google"
            l.startsWith("kirin") || Regex("^hi\\d").containsMatchIn(l) -> "HiSilicon"
            Regex("^(ums|sc\\d{4}|sp\\d{4})").containsMatchIn(l) -> "UNISOC"
            l.contains("intel") -> "Intel"
            else -> null
        }
    }
}
