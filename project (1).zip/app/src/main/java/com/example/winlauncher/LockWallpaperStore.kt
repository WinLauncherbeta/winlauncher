package com.example.winlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Random

/**
 * Papel de parede da tela de bloqueio PRÓPRIA do WinLauncher.
 *
 * Nada aqui toca no papel de parede do Android (nem na tela de bloqueio nativa): os arquivos importados são
 * copiados para o espaço privado do app (filesDir/lockwp) e a escolha fica em SharedPreferences.
 *
 * Chaves (mesmo SharedPreferences da tela de bloqueio):
 *  - lockWpSel: "" (padrão) | "preset:<id>" | "file:<id>"
 *  - lockWpLib: JSON com os arquivos importados
 */

/** Arquivo importado para a galeria. [kind]: "image" (inclui GIF) ou "video". */
class WpFile(val id: String, val kind: String, val name: String, val ext: String) {
    val isVideo: Boolean get() = kind == "video"
}

/** O que está selecionado como fundo da tela de bloqueio. */
sealed class WpSel {
    object Default : WpSel()
    class Preset(val preset: WpPreset) : WpSel()
    class Imported(val file: WpFile) : WpSel()
}

class LockWallpaperStore(private val ctx: Context, private val prefs: SharedPreferences) {

    class ImportResult(val entry: WpFile?, val error: String?)

    companion object {
        const val K_SEL = "lockWpSel"
        const val K_LIB = "lockWpLib"
        private const val DIR = "lockwp"

        /** Limite de tamanho por arquivo importado (protege o armazenamento do aparelho). */
        const val MAX_BYTES = 200L * 1024L * 1024L
        private const val POSTER_MAX_SIDE = 1280
    }

    private val dir: File
        get() = File(ctx.filesDir, DIR).also { it.mkdirs() }

    fun fileOf(e: WpFile): File = File(dir, "${e.id}.${e.ext}")

    /** Primeiro quadro (JPEG): serve de miniatura, de fundo enquanto o vídeo carrega e de base do desfoque de vidro. */
    fun posterOf(e: WpFile): File = File(dir, "${e.id}.poster.jpg")

    // ------------------------------------------------------------------ seleção

    fun key(sel: WpSel): String = when (sel) {
        is WpSel.Default -> ""
        is WpSel.Preset -> "preset:${sel.preset.id}"
        is WpSel.Imported -> "file:${sel.file.id}"
    }

    fun currentKey(): String = prefs.getString(K_SEL, "") ?: ""

    /** Seleção salva. Se o preset ou o arquivo não existir mais, volta ao padrão. */
    fun selection(): WpSel {
        val s = currentKey()
        return when {
            s.startsWith("preset:") ->
                WpPresets.find(s.removePrefix("preset:"))?.let { WpSel.Preset(it) } ?: WpSel.Default
            s.startsWith("file:") -> {
                val id = s.removePrefix("file:")
                library().firstOrNull { it.id == id && fileOf(it).exists() }
                    ?.let { WpSel.Imported(it) } ?: WpSel.Default
            }
            else -> WpSel.Default
        }
    }

    fun select(sel: WpSel) {
        prefs.edit().putString(K_SEL, key(sel)).apply()
    }

    // ------------------------------------------------------------------ biblioteca de arquivos importados

    fun library(): List<WpFile> {
        val out = ArrayList<WpFile>()
        try {
            val arr = JSONArray(prefs.getString(K_LIB, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    WpFile(
                        o.getString("id"), o.getString("kind"),
                        o.optString("name", "Arquivo"), o.optString("ext", "bin")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveLibrary(list: List<WpFile>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(JSONObject().put("id", e.id).put("kind", e.kind).put("name", e.name).put("ext", e.ext))
        }
        prefs.edit().putString(K_LIB, arr.toString()).apply()
    }

    fun remove(e: WpFile) {
        fileOf(e).delete()
        posterOf(e).delete()
        saveLibrary(library().filter { it.id != e.id })
        if (currentKey() == "file:${e.id}") select(WpSel.Default)
    }

    /**
     * Copia o arquivo escolhido para o espaço privado do app e gera o primeiro quadro.
     * BLOQUEIA (cópia + decodificação): chamar fora da thread principal.
     */
    fun import(uri: Uri): ImportResult {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: ""
        val kind = when {
            mime.startsWith("video/") -> "video"
            mime.startsWith("image/") -> "image"
            else -> return ImportResult(null, "Formato não suportado. Use imagem, GIF ou vídeo.")
        }

        var name = "Arquivo"
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) name = n
                }
            }
        } catch (e: Exception) {
        }
        var ext = name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(5)
        if (ext.isEmpty()) {
            ext = mime.substringAfter('/').filter { it.isLetterOrDigit() }.take(5)
            if (ext.isEmpty()) ext = if (kind == "video") "mp4" else "img"
        }
        val id = java.lang.Long.toString(System.currentTimeMillis(), 36) +
            java.lang.Integer.toString(Random().nextInt(46656), 36)
        val shown = name.substringBeforeLast('.').take(40).ifBlank { "Arquivo" }
        val entry = WpFile(id, kind, shown, ext)
        val dest = fileOf(entry)

        // cópia em blocos (não carrega o arquivo inteiro na memória)
        var tooBig = false
        try {
            val input = cr.openInputStream(uri) ?: return ImportResult(null, "Não consegui abrir o arquivo")
            input.use { ins ->
                dest.outputStream().use { outs ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) {
                            tooBig = true
                            break
                        }
                        outs.write(buf, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            dest.delete()
            return ImportResult(null, "Não consegui copiar o arquivo")
        }
        if (tooBig) {
            dest.delete()
            return ImportResult(null, "Arquivo muito grande (máximo ${MAX_BYTES / (1024L * 1024L)} MB)")
        }

        val poster = try {
            makePoster(entry, dest)
        } catch (e: Throwable) {
            null
        }
        if (poster == null) {
            dest.delete()
            return ImportResult(
                null,
                if (kind == "video") "Não consegui ler esse vídeo" else "Não consegui abrir essa imagem"
            )
        }
        try {
            posterOf(entry).outputStream().use { poster.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        } catch (e: Exception) {
            dest.delete()
            posterOf(entry).delete()
            return ImportResult(null, "Sem espaço para salvar o papel de parede")
        }
        poster.recycle()

        saveLibrary(library() + entry)
        return ImportResult(entry, null)
    }

    private fun makePoster(e: WpFile, f: File): Bitmap? {
        val raw: Bitmap? = if (e.isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.absolutePath)
                r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } finally {
                try {
                    r.release()
                } catch (ex: Exception) {
                }
            }
        } else {
            decodeBitmap(f, POSTER_MAX_SIDE, POSTER_MAX_SIDE)
        }
        val b = raw ?: return null
        val side = maxOf(b.width, b.height)
        if (side <= POSTER_MAX_SIDE) return b
        val s = POSTER_MAX_SIDE.toFloat() / side
        val scaled = Bitmap.createScaledBitmap(
            b, maxOf(1, (b.width * s).toInt()), maxOf(1, (b.height * s).toInt()), true
        )
        if (scaled !== b) b.recycle()
        return scaled
    }

    // ------------------------------------------------------------------ decodificação

    /**
     * Decodifica a imagem já reduzida (nunca maior que o necessário para cobrir [tw] x [th]).
     * Sempre em memória comum (não "hardware"), para o desfoque de vidro conseguir capturar a tela.
     * Em GIF/WebP animado devolve o primeiro quadro.
     */
    fun decodeBitmap(f: File, tw: Int, th: Int): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val sc = maxOf(tw.toFloat() / info.size.width, th.toFloat() / info.size.height)
                    if (sc < 1f) {
                        decoder.setTargetSize(
                            maxOf(1, (info.size.width * sc).toInt()),
                            maxOf(1, (info.size.height * sc).toInt())
                        )
                    }
                }
            } else {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.absolutePath, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) {
                    null
                } else {
                    var s = 1
                    while (o.outWidth / (s * 2) >= tw && o.outHeight / (s * 2) >= th) s *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = s
                    BitmapFactory.decodeFile(f.absolutePath, o2)
                }
            }
        } catch (e: Throwable) {
            null
        }
    }

    /** Miniatura da galeria (a partir do primeiro quadro salvo). Chamar fora da thread principal. */
    fun thumbnail(e: WpFile, tw: Int, th: Int): Bitmap? {
        val p = posterOf(e)
        if (!p.exists()) return null
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(p.absolutePath, o)
            var s = 1
            while (o.outWidth / (s * 2) >= tw && o.outHeight / (s * 2) >= th) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            BitmapFactory.decodeFile(p.absolutePath, o2)
        } catch (ex: Throwable) {
            null
        }
    }
}
