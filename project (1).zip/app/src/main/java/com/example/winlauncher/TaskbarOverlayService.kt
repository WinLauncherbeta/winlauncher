package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.display.DisplayManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/**
 * Barra de tarefas flutuante: quando outro app está na frente, encostar o mouse na borda da tela
 * levanta uma barra idêntica à do launcher (mesmo fundo, tamanhos, apps fixados, bandeja e relógio).
 * Os painéis (Iniciar, pesquisa, painel rápido, calendário, notificações) abrem no próprio launcher.
 * Não usa os botões de navegação do Android.
 */
class TaskbarOverlayService : Service() {

    companion object {
        private const val CHANNEL = "taskbar_overlay"
        private const val NOTIF_ID = 4711
        private const val MATCH = android.view.ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = android.view.ViewGroup.LayoutParams.WRAP_CONTENT

        @Volatile
        var instance: TaskbarOverlayService? = null

        /** true enquanto o launcher está na frente (nesse caso a barra normal já aparece e a flutuante some). */
        @Volatile
        var launcherForeground = false

        /** Liga ou desliga o serviço conforme a opção e a permissão "Exibir sobre outros apps". */
        fun sync(ctx: Context) {
            val sp = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)
            val pf = Prefs(sp)
            val on = pf.tbOverlay && !pf.tbHidden && Settings.canDrawOverlays(ctx)
            val inst = instance
            if (on) {
                if (inst == null) {
                    try {
                        ctx.startForegroundService(Intent(ctx, TaskbarOverlayService::class.java))
                    } catch (e: Exception) {
                    }
                } else {
                    inst.refresh()
                }
            } else if (inst != null) {
                inst.removeAll()
                inst.stopSelf()
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hideBar() }

    private var wm: WindowManager? = null
    private var dctx: Context? = null
    private var strip: View? = null
    private var bar: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Barra de tarefas flutuante", NotificationManager.IMPORTANCE_MIN)
            )
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_start)
                .setContentTitle("WinLauncher")
                .setContentText("Barra de tarefas disponível na borda da tela")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refresh()
        return START_STICKY
    }

    override fun onDestroy() {
        removeAll()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ janelas

    /** Força a barra flutuante a ser recriada (ex.: ícone de app trocado). */
    fun removeStripForRebuild() {
        handler.post {
            removeAll()
            refresh()
        }
    }

    fun refresh() {
        handler.post {
            val cfg = Prefs(getSharedPreferences("win", MODE_PRIVATE))
            val allowed = cfg.tbOverlay && !cfg.tbHidden && Settings.canDrawOverlays(this) && !launcherForeground
            if (!allowed) {
                removeAll()
                return@post
            }
            if (strip == null) addStrip(cfg)
        }
    }

    private fun displayContext(): Context {
        return try {
            val id = getSharedPreferences("win", MODE_PRIVATE).getInt("ov_display", Display.DEFAULT_DISPLAY)
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val d = dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
            createDisplayContext(d)
        } catch (e: Exception) {
            this
        }
    }

    private fun overlayParams(h: Int, flags: Int, top: Boolean): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            MATCH, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.START
        return lp
    }

    /** Faixa fina e invisível na borda da tela: encostar o mouse nela levanta a barra. */
    private fun addStrip(cfg: Prefs) {
        try {
            val c = displayContext()
            dctx = c
            val w = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = w
            val v = View(c)
            v.setOnHoverListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_HOVER_ENTER || ev.actionMasked == MotionEvent.ACTION_HOVER_MOVE) {
                    showBar()
                }
                false
            }
            v.setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) showBar()
                false
            }
            val h = (3 * c.resources.displayMetrics.density + 0.5f).toInt().coerceAtLeast(2)
            w.addView(v, overlayParams(h, 0, cfg.tbPos == 1))
            strip = v
        } catch (e: Exception) {
            strip = null
        }
    }

    private fun showBar() {
        if (launcherForeground) return
        handler.removeCallbacks(hideRun)
        if (bar != null) return
        val c = dctx ?: return
        val w = wm ?: return
        try {
            val cfg = Prefs(getSharedPreferences("win", MODE_PRIVATE))
            val top = cfg.tbPos == 1
            val rowH = scaledDp(c, cfg, cfg.tbHeight)
            val b = buildBar(c, cfg, rowH)
            var flags = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            if (cfg.tbBg == 1 && Build.VERSION.SDK_INT >= 31) flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            val lp = overlayParams(rowH, flags, top)
            if (cfg.tbBg == 1 && Build.VERSION.SDK_INT >= 31) {
                lp.blurBehindRadius = (30 * c.resources.displayMetrics.density).toInt()
            }
            b.translationY = if (top) -rowH.toFloat() else rowH.toFloat()
            w.addView(b, lp)
            b.animate().translationY(0f).setDuration(140).start()
            bar = b
            // segurança: se o mouse nunca chegar na barra, ela some sozinha
            handler.postDelayed(hideRun, 3000)
        } catch (e: Exception) {
            bar = null
        }
    }

    private fun hideBar() {
        handler.removeCallbacks(hideRun)
        val b = bar ?: return
        bar = null
        val w = wm
        try {
            val top = Prefs(getSharedPreferences("win", MODE_PRIVATE)).tbPos == 1
            val dist = b.height.toFloat()
            b.animate().translationY(if (top) -dist else dist).setDuration(120).withEndAction {
                try {
                    w?.removeView(b)
                } catch (e: Exception) {
                }
            }.start()
        } catch (e: Exception) {
            try {
                w?.removeView(b)
            } catch (e2: Exception) {
            }
        }
    }

    fun removeAll() {
        handler.removeCallbacks(hideRun)
        val w = wm
        bar?.let {
            try {
                w?.removeView(it)
            } catch (e: Exception) {
            }
        }
        bar = null
        strip?.let {
            try {
                w?.removeView(it)
            } catch (e: Exception) {
            }
        }
        strip = null
    }

    // ------------------------------------------------------------------ ações

    private fun openPanel(name: String) {
        removeBarNow()
        try {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra("open_panel", name)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun launchApp(cn: ComponentName) {
        removeBarNow()
        if (WebApps.isWeb(cn)) {
            // app por link: o launcher abre o endereço no navegador embutido
            try {
                val w = Intent(this, MainActivity::class.java)
                w.putExtra("open_webapp", cn.flattenToString())
                w.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                startActivity(w)
            } catch (e: Exception) {
            }
            return
        }
        try {
            val i = Intent(Intent.ACTION_MAIN)
            i.addCategory(Intent.CATEGORY_LAUNCHER)
            i.component = cn
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun removeBarNow() {
        handler.removeCallbacks(hideRun)
        val b = bar ?: return
        bar = null
        try {
            wm?.removeView(b)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ barra (réplica da barra do launcher)

    private fun scaledDp(c: Context, cfg: Prefs, v: Int): Int =
        (v * c.resources.displayMetrics.density * cfg.tbScale / 100f + 0.5f).toInt()

    private inner class BarRoot(c: Context) : FrameLayout(c) {
        override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_HOVER_MOVE -> handler.removeCallbacks(hideRun)
                MotionEvent.ACTION_HOVER_EXIT -> {
                    handler.removeCallbacks(hideRun)
                    handler.postDelayed(hideRun, 450)
                }
            }
            return super.dispatchGenericMotionEvent(ev)
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                hideBar()
                return true
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun buildBar(c: Context, cfg: Prefs, rowH: Int): View {
        val density = c.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density + 0.5f).toInt()
        fun sdp(v: Int): Int = scaledDp(c, cfg, v)

        val light = cfg.theme == 1
        val fg = if (light && cfg.tbBg != 2) Color.parseColor("#1F1F1F") else Color.WHITE
        val base = if (light) 0xF3F3F3 else 0x1C1C1C
        val accent = cfg.accent
        val tile = Color.parseColor(if (light) "#14000000" else "#26FFFFFF")
        val ripC = Color.parseColor(if (light) "#22000000" else "#44FFFFFF")
        val screenW = c.resources.displayMetrics.widthPixels

        fun argb(a: Int, rgb: Int): Int = (a.coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)
        fun rounded(color: Int, r: Int): GradientDrawable {
            val g = GradientDrawable()
            g.setColor(color)
            g.cornerRadius = dp(r).toFloat()
            return g
        }
        fun rip(color: Int, r: Int): RippleDrawable =
            RippleDrawable(ColorStateList.valueOf(ripC), rounded(color, r), rounded(Color.WHITE, r))

        val al = cfg.tbAlpha * 255 / 100
        val bg = when (cfg.tbBg) {
            1 -> argb((al * 0.6f).toInt(), base)
            2 -> Color.TRANSPARENT
            else -> argb(al, base)
        }

        val root = BarRoot(c)
        root.setBackgroundColor(bg)

        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        root.addView(row, FrameLayout.LayoutParams(MATCH, rowH))

        val slot = sdp(cfg.tbIcon)
        val gap = sdp(cfg.tbSpace)
        val padA = (slot * 8f / 44f).toInt()
        val padS = (slot * 10f / 44f).toInt()
        val trayIcon = sdp(cfg.tbTray)
        val trayH = minOf(sdp(40), rowH)
        val bw = sdp(36)
        val cw = sdp(24)

        // compensa sino + seta para manter o grupo central no mesmo lugar da barra do launcher
        val leftPad = View(c)
        row.addView(leftPad, LinearLayout.LayoutParams(bw + cw, 1))
        row.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))

        val pinned = LinearLayout(c)
        pinned.orientation = LinearLayout.HORIZONTAL
        pinned.gravity = Gravity.CENTER_VERTICAL
        row.addView(pinned, LinearLayout.LayoutParams(WRAP, MATCH))

        // botão Iniciar
        val start = ImageView(c)
        start.setImageResource(R.drawable.ic_start)
        start.setPadding(padS, padS, padS, padS)
        start.background = rip(Color.TRANSPARENT, 6)
        start.setOnClickListener { openPanel("start") }
        pinned.addView(start, LinearLayout.LayoutParams(slot, slot))

        // campo de pesquisa + clima
        val showPill = screenW >= dp(600)
        val pillW = sdp(172)
        if (showPill) {
            val pill = LinearLayout(c)
            pill.orientation = LinearLayout.HORIZONTAL
            pill.gravity = Gravity.CENTER_VERTICAL
            pill.background = rounded(tile, 16)
            pill.setPadding(dp(10), 0, dp(10), 0)
            pill.isClickable = true
            pill.setOnClickListener { openPanel("search") }
            val pi = ImageView(c)
            pi.setImageResource(R.drawable.ic_search)
            pi.setColorFilter(fg)
            pill.addView(pi, LinearLayout.LayoutParams(dp(16), dp(16)))
            val pt = TextView(c)
            pt.text = "Pesquisar"
            pt.setTextColor(fg)
            pt.textSize = 12f * cfg.tbScale / 100f
            pt.maxLines = 1
            val ptl = LinearLayout.LayoutParams(0, WRAP, 1f)
            ptl.leftMargin = dp(8)
            pill.addView(pt, ptl)
            val wx = TextView(c)
            val wd = Weather.load(getSharedPreferences("win", MODE_PRIVATE))
            wx.text = if (wd != null) Weather.emoji(wd.code, wd.isDay) + " " + wd.temp + "°C" else "☁️ --°C"
            wx.setTextColor(fg)
            wx.textSize = 12f * cfg.tbScale / 100f
            wx.maxLines = 1
            wx.gravity = Gravity.CENTER_VERTICAL
            wx.isClickable = true
            wx.setOnClickListener { openPanel("start") }
            val wlp = LinearLayout.LayoutParams(WRAP, MATCH)
            wlp.leftMargin = dp(6)
            pill.addView(wx, wlp)
            val plp = LinearLayout.LayoutParams(
                pillW,
                maxOf(dp(24), minOf(sdp(32), sdp(cfg.tbHeight) - dp(8)))
            )
            plp.leftMargin = gap + sdp(4)
            plp.rightMargin = sdp(4)
            pinned.addView(pill, plp)
        }

        // apps fixados (mesma lista e ordem da barra do launcher)
        val reserve = 3 * (trayIcon + sdp(10)) + sdp(8) + sdp(64) + sdp(36) + sdp(24) + sdp(4) +
            (if (showPill) pillW + sdp(8) else 0)
        val slots = ((screenW - reserve) / (slot + gap)) - 1
        val keys =
            (getSharedPreferences("win", MODE_PRIVATE).getString("tb", "") ?: "")
                .split("|").filter { it.isNotEmpty() }
        var shown = 0
        for (k in keys) {
            if (shown >= maxOf(0, slots)) break
            val cn = ComponentName.unflattenFromString(k) ?: continue
            var icon: android.graphics.drawable.Drawable? = null
            try {
                icon = if (WebApps.isWeb(cn)) {
                    WebApps.find(this, cn)?.let { WebApps.icon(this, it) }
                } else {
                    AppCustom.icon(this, cn) ?: packageManager.getActivityIcon(cn)
                }
            } catch (e: Exception) {
            }
            if (icon == null) continue
            val iv = ImageView(c)
            iv.setImageDrawable(icon)
            iv.setPadding(padA, padA, padA, padA)
            iv.background = rip(Color.TRANSPARENT, 6)
            iv.setOnClickListener { launchApp(cn) }
            val lp = LinearLayout.LayoutParams(slot, slot)
            lp.leftMargin = gap
            pinned.addView(iv, lp)
            shown++
        }

        row.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))

        // bandeja (Wi-Fi, volume, bateria)
        val tray = LinearLayout(c)
        tray.orientation = LinearLayout.HORIZONTAL
        tray.gravity = Gravity.CENTER_VERTICAL
        tray.background = rip(Color.TRANSPARENT, 6)
        tray.setPadding(dp(4), 0, dp(4), 0)
        tray.setOnClickListener { openPanel("quick") }
        val icons = listOf(R.drawable.ic_wifi, R.drawable.ic_volume, R.drawable.ic_battery)
        for ((i, res) in icons.withIndex()) {
            val iv = ImageView(c)
            iv.setImageResource(res)
            iv.setColorFilter(fg)
            if (i == 0) iv.alpha = if (wifiOn()) 1f else 0.4f
            val lp = LinearLayout.LayoutParams(trayIcon, trayIcon)
            lp.setMargins(sdp(5), 0, sdp(5), 0)
            tray.addView(iv, lp)
        }
        row.addView(tray, LinearLayout.LayoutParams(WRAP, trayH))

        // relógio
        val clock = TextClock(c)
        clock.format12Hour = "HH:mm\ndd/MM/yyyy"
        clock.format24Hour = "HH:mm\ndd/MM/yyyy"
        clock.setTextColor(fg)
        clock.textSize = cfg.tbClock * cfg.tbScale / 100f
        clock.gravity = Gravity.CENTER
        clock.setPadding(dp(8), 0, dp(8), 0)
        clock.background = rip(Color.TRANSPARENT, 6)
        clock.setOnClickListener { openPanel("cal") }
        val clp = LinearLayout.LayoutParams(WRAP, trayH)
        clp.rightMargin = sdp(4)
        row.addView(clock, clp)

        // sino com contador
        val bell = FrameLayout(c)
        bell.background = rip(Color.TRANSPARENT, 6)
        bell.isClickable = true
        bell.setOnClickListener { openPanel("notif") }
        val bi = ImageView(c)
        bi.setImageResource(R.drawable.ic_bell)
        bi.setColorFilter(fg)
        val bp = (bw * 0.25f).toInt()
        bi.setPadding(bp, bp, bp, bp)
        bell.addView(bi, FrameLayout.LayoutParams(MATCH, MATCH))
        val count = try {
            LauncherNotificationListener.current(packageName).size
        } catch (e: Exception) {
            0
        }
        if (count > 0) {
            val badge = TextView(c)
            badge.textSize = 8f
            badge.setTextColor(Color.BLACK)
            badge.typeface = Typeface.DEFAULT_BOLD
            badge.gravity = Gravity.CENTER
            badge.minWidth = dp(14)
            badge.minHeight = dp(14)
            val bb = GradientDrawable()
            bb.shape = GradientDrawable.OVAL
            bb.setColor(accent)
            badge.background = bb
            badge.text = if (count > 9) "9+" else count.toString()
            val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
            blp.setMargins(0, dp(4), dp(2), 0)
            bell.addView(badge, blp)
        }
        row.addView(bell, LinearLayout.LayoutParams(bw, trayH))

        // seta "^" (painel rápido)
        val chev = ImageView(c)
        chev.setImageResource(R.drawable.ic_chevron_up)
        chev.setColorFilter(fg)
        chev.setPadding(dp(4), dp(4), dp(4), dp(4))
        chev.background = rip(Color.TRANSPARENT, 6)
        chev.isClickable = true
        chev.setOnClickListener { openPanel("quick") }
        row.addView(chev, LinearLayout.LayoutParams(cw, trayH))

        // o espaçador da esquerda iguala a largura de TODO o lado direito (bandeja + relógio + sino + seta),
        // deixando o grupo central no centro real da tela
        var rightW = 0
        for (v in listOf<View>(tray, clock, bell, chev)) {
            v.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val lp = v.layoutParams as LinearLayout.LayoutParams
            val w = if (lp.width > 0) lp.width else v.measuredWidth
            rightW += w + lp.leftMargin + lp.rightMargin
        }
        leftPad.layoutParams = LinearLayout.LayoutParams(rightW, 1)

        return root
    }
}
