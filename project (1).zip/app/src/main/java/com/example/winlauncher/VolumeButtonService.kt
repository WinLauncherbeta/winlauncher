package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * Botão de volume flutuante: fica sobre qualquer app, pode ser arrastado (mouse ou toque) para
 * qualquer ponto da tela e, ao clicar, abre o painel de volume nativo do Android.
 * Botão direito (ou segurar com o dedo) abre um menu com opacidade, tamanho e "ocultar".
 * Posição, opacidade e tamanho ficam salvos.
 */
class VolumeButtonService : Service() {

    companion object {
        private const val CHANNEL = "volume_button"
        private const val NOTIF_ID = 4712
        private const val MIN_SIZE_DP = 32
        private const val MAX_SIZE_DP = 120
        private const val DEF_SIZE_DP = 48

        @Volatile
        var instance: VolumeButtonService? = null

        /** true enquanto o botão está de fato na tela (o Android pode matar o serviço sem avisar). */
        fun isRunning(): Boolean = instance?.button != null

        /** Liga ou desliga o botão conforme a opção e a permissão "Exibir sobre outros apps". */
        @Volatile
        var announce = false

        private fun say(ctx: Context, msg: String) {
            try {
                android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
            }
        }

        /** [verbose] = chamado pelo usuário (interruptor/olho): explica na tela o que aconteceu. */
        fun sync(ctx: Context, verbose: Boolean = false) {
            val sp = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)
            val pref = sp.getBoolean("ui_vol_btn", false)
            val perm = Settings.canDrawOverlays(ctx)
            val on = pref && perm
            val inst = instance
            if (verbose) {
                announce = on
                if (!pref) say(ctx, "Botão de volume: desligado")
                else if (!perm) say(ctx, "Botão de volume: falta a permissão \"Exibir sobre outros apps\"")
                else if (inst?.button != null) {
                    val lp = inst.params
                    say(ctx, "Botão de volume já está na tela (x=" + (lp?.x ?: -1) + ", y=" + (lp?.y ?: -1) + ")")
                } else say(ctx, "Botão de volume: iniciando...")
            }
            if (on) {
                if (inst == null) {
                    try {
                        ctx.startForegroundService(Intent(ctx, VolumeButtonService::class.java))
                    } catch (e: Exception) {
                        say(ctx, "Botão de volume não iniciou: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                    }
                } else if (inst.button == null) {
                    inst.handler.post { if (inst.button == null) inst.addButton() }
                }
            } else if (inst != null) {
                inst.dismissMenu()
                inst.removeButton()
                inst.stopSelf()
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var ctxDisplay: Context? = null
    private var button: FrameLayout? = null
    private var icon: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private var menu: View? = null

    private val sp get() = getSharedPreferences("win", MODE_PRIVATE)
    private fun density() = (ctxDisplay ?: this).resources.displayMetrics.density
    private fun sizePx() = (sp.getInt("vb_size", DEF_SIZE_DP) * density() + 0.5f).toInt()
    private fun baseAlpha() = sp.getInt("vb_alpha", 100).coerceIn(20, 100) / 100f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Botão de volume flutuante", NotificationManager.IMPORTANCE_MIN)
            )
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_volume)
                .setContentTitle("WinLauncher")
                .setContentText("Botão de volume flutuante ativo")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.post { if (button == null) addButton() }
        return START_STICKY
    }

    override fun onDestroy() {
        dismissMenu()
        removeButton()
        instance = null
        super.onDestroy()
    }

    private fun displayContext(): Context {
        return try {
            val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val d = dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
            createDisplayContext(d)
        } catch (e: Exception) {
            this
        }
    }

    /** Mensagem flutuante na MESMA tela onde o botão é criado (o Toast comum vai para a tela do celular). */
    private fun bubble(msg: String) {
        try {
            val c = ctxDisplay ?: displayContext()
            val w = wm ?: (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
            val m = c.resources.displayMetrics
            val d = m.density
            val t = TextView(c)
            t.text = msg
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.maxWidth = (m.widthPixels * 0.8f).toInt()
            t.setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
            t.background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(Color.argb(235, 30, 30, 30))
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = (60 * d).toInt()
            w.addView(t, lp)
            handler.postDelayed({
                try {
                    w.removeView(t)
                } catch (e: Exception) {
                }
            }, 6000)
        } catch (e: Exception) {
        }
    }

    private fun toastErr(msg: String) {
        bubble(msg)
        try {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    private fun targetDisplay(): Display? {
        return try {
            val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            dm.getDisplay(id) ?: dm.getDisplay(Display.DEFAULT_DISPLAY)
        } catch (e: Exception) {
            null
        }
    }

    /** Contexto de janela (API 30+) da tela do launcher: o jeito certo de colocar overlay em monitor externo. */
    private fun windowContext(): Context {
        val d = targetDisplay() ?: throw IllegalStateException("tela não encontrada")
        val dc = createDisplayContext(d)
        return if (Build.VERSION.SDK_INT >= 30) {
            dc.createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
        } else dc
    }

    /**
     * Tenta na tela do launcher (monitor) de dois jeitos e, por último, na tela padrão do celular.
     * Se algum jeito falhar, o erro é mostrado mesmo quando o seguinte funcionar.
     */
    private fun addButton() {
        val id = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
        val attempts = listOf<Pair<String, () -> Context>>(
            "janela tela $id" to { windowContext() },
            "contexto tela $id" to { createDisplayContext(targetDisplay() ?: throw IllegalStateException("tela não encontrada")) },
            "tela padrão" to { this }
        )
        val errs = StringBuilder()
        for ((name, make) in attempts) {
            try {
                addButtonWith(make())
                if (errs.isNotEmpty()) toastErr("Botão criado em: $name. Falhas antes: $errs")
                return
            } catch (e: Exception) {
                removeButton()
                errs.append("[").append(name).append(": ").append(e.javaClass.simpleName).append(" ")
                    .append(e.message ?: "").append("] ")
            }
        }
        toastErr("Botão de volume não pôde ser exibido: $errs")
    }

    private fun addButtonWith(c: Context) {
        try {
            ctxDisplay = c
            val w = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = w
            val dm = c.resources.displayMetrics
            val d = dm.density
            val size = sizePx()

            val root = FrameLayout(c)
            root.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(210, 30, 30, 30))
                setStroke((1 * d).toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
            }
            val iv = ImageView(c)
            iv.setImageResource(R.drawable.ic_volume)
            iv.setPadding(size / 4, size / 4, size / 4, size / 4)
            root.addView(iv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            root.alpha = baseAlpha()

            val lp = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val maxX = (dm.widthPixels - size).coerceAtLeast(0)
            val maxY = (dm.heightPixels - size).coerceAtLeast(0)
            lp.x = sp.getInt("vb_x", maxX - (16 * d).toInt()).coerceIn(0, maxX)
            lp.y = sp.getInt("vb_y", (dm.heightPixels * 0.4f).toInt()).coerceIn(0, maxY)
            params = lp
            button = root
            icon = iv

            val slop = 8 * d
            var downRawX = 0f
            var downRawY = 0f
            var startX = 0
            var startY = 0
            var dragging = false
            var menuShown = false
            val longPress = Runnable {
                if (!dragging) {
                    menuShown = true
                    showMenu()
                }
            }

            root.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dismissMenu()
                        downRawX = ev.rawX
                        downRawY = ev.rawY
                        startX = lp.x
                        startY = lp.y
                        dragging = false
                        menuShown = false
                        if (ev.isButtonPressed(MotionEvent.BUTTON_SECONDARY)) {
                            // botão direito do mouse: abre o menu
                            menuShown = true
                            showMenu()
                        } else {
                            v.alpha = (baseAlpha() * 0.7f)
                            handler.postDelayed(longPress, 600) // toque longo com o dedo
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (menuShown) return@setOnTouchListener true
                        val dx = ev.rawX - downRawX
                        val dy = ev.rawY - downRawY
                        if (!dragging && (dx * dx + dy * dy) > slop * slop) {
                            dragging = true
                            handler.removeCallbacks(longPress)
                        }
                        if (dragging) {
                            val m = c.resources.displayMetrics
                            val s = lp.width
                            lp.x = (startX + dx).toInt().coerceIn(0, (m.widthPixels - s).coerceAtLeast(0))
                            lp.y = (startY + dy).toInt().coerceIn(0, (m.heightPixels - s).coerceAtLeast(0))
                            try {
                                w.updateViewLayout(v, lp)
                            } catch (e: Exception) {
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(longPress)
                        v.alpha = baseAlpha()
                        if (dragging) {
                            sp.edit().putInt("vb_x", lp.x).putInt("vb_y", lp.y).apply()
                        } else if (!menuShown) {
                            showVolumePanel()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(longPress)
                        v.alpha = baseAlpha()
                        true
                    }
                    else -> false
                }
            }

            w.addView(root, lp)
            if (announce) {
                announce = false
                toastErr("Botão de volume criado em x=" + lp.x + ", y=" + lp.y + " (tela " + dm.widthPixels + "x" + dm.heightPixels + ", " + size + "px)")
            }
        } catch (e: Exception) {
            button = null
            throw e
        }
    }

    /** Abre o painel de volume nativo sem alterar o volume. */
    private fun showVolumePanel() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_SAME,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ menu (botão direito)

    private fun showMenu() {
        val c = ctxDisplay ?: return
        val w = wm ?: return
        val btn = button ?: return
        val bp = params ?: return
        if (menu != null) return
        try {
            val d = c.resources.displayMetrics.density
            fun dp(v: Int) = (v * d + 0.5f).toInt()

            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(16), dp(12), dp(16), dp(12))
            col.background = GradientDrawable().apply {
                cornerRadius = 14 * d
                setColor(Color.argb(240, 32, 32, 32))
                setStroke(dp(1), Color.argb(80, 255, 255, 255))
            }

            fun label(text: String): TextView {
                val t = TextView(c)
                t.text = text
                t.setTextColor(Color.WHITE)
                t.textSize = 13f
                return t
            }

            fun slider(title: String, min: Int, max: Int, cur: Int, unit: String, onChange: (Int) -> Unit) {
                val head = LinearLayout(c)
                head.orientation = LinearLayout.HORIZONTAL
                val name = label(title)
                val value = label("$cur$unit")
                head.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                head.addView(value, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                col.addView(head)
                val sb = SeekBar(c)
                sb.max = max - min
                sb.progress = (cur - min).coerceIn(0, max - min)
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        val v = min + p
                        value.text = "$v$unit"
                        if (fromUser) onChange(v)
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(6)
                col.addView(sb, lp)
            }

            slider("Opacidade", 20, 100, sp.getInt("vb_alpha", 100), "%") { v ->
                sp.edit().putInt("vb_alpha", v).apply()
                btn.alpha = v / 100f
            }
            slider("Tamanho", MIN_SIZE_DP, MAX_SIZE_DP, sp.getInt("vb_size", DEF_SIZE_DP), "dp") { v ->
                sp.edit().putInt("vb_size", v).apply()
                applySize()
            }

            val hide = label("Ocultar botão")
            hide.setPadding(dp(4), dp(10), dp(4), dp(4))
            hide.setTextColor(Color.rgb(255, 140, 130))
            hide.setOnClickListener {
                sp.edit().putBoolean("ui_vol_btn", false).apply()
                dismissMenu()
                sync(this)
            }
            col.addView(hide)
            val tip = label("Para trazer de volta: ícone do olho na barra de volume do launcher.")
            tip.textSize = 11f
            tip.alpha = 0.6f
            tip.setPadding(dp(4), 0, dp(4), 0)
            col.addView(tip)

            // clique fora fecha o menu
            col.setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) dismissMenu()
                false
            }

            val m = c.resources.displayMetrics
            val mw = minOf(dp(250), m.widthPixels - dp(16))
            col.measure(
                View.MeasureSpec.makeMeasureSpec(mw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val mh = col.measuredHeight
            val lp = WindowManager.LayoutParams(
                mw, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (bp.x + bp.width / 2 - mw / 2).coerceIn(dp(8), maxOf(dp(8), m.widthPixels - mw - dp(8)))
            val below = bp.y + bp.height + dp(8)
            lp.y = if (below + mh <= m.heightPixels - dp(8)) below else maxOf(dp(8), bp.y - mh - dp(8))
            w.addView(col, lp)
            menu = col
        } catch (e: Exception) {
            menu = null
        }
    }

    private fun applySize() {
        val btn = button ?: return
        val lp = params ?: return
        val w = wm ?: return
        val c = ctxDisplay ?: return
        val size = sizePx()
        val m = c.resources.displayMetrics
        lp.width = size
        lp.height = size
        lp.x = lp.x.coerceIn(0, (m.widthPixels - size).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (m.heightPixels - size).coerceAtLeast(0))
        icon?.setPadding(size / 4, size / 4, size / 4, size / 4)
        try {
            w.updateViewLayout(btn, lp)
        } catch (e: Exception) {
        }
        sp.edit().putInt("vb_x", lp.x).putInt("vb_y", lp.y).apply()
    }

    fun dismissMenu() {
        val mv = menu ?: return
        menu = null
        try {
            wm?.removeView(mv)
        } catch (e: Exception) {
        }
    }

    fun removeButton() {
        val b = button ?: return
        button = null
        try {
            wm?.removeView(b)
        } catch (e: Exception) {
        }
    }
}
