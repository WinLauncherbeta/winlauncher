package com.example.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * Botão de volume flutuante. É criado na tela onde o launcher está aberto, pode ser
 * arrastado (mouse ou toque) e, ao clicar, abre o painel de volume nativo do Android.
 * Botão direito (ou segurar com o dedo) abre um menu com opacidade, tamanho e "ocultar".
 * Posição (por tela), opacidade e tamanho ficam salvos.
 */
class VolumeButtonService : Service() {

    private class Holder(
        val display: Display,
        val ctx: Context,
        val wm: WindowManager,
        val root: FrameLayout,
        val icon: ImageView,
        val lp: WindowManager.LayoutParams
    )

    companion object {
        private const val CHANNEL = "volume_button"
        private const val NOTIF_ID = 4712
        private const val MIN_SIZE_DP = 32
        private const val MAX_SIZE_DP = 120
        private const val DEF_SIZE_DP = 48

        @Volatile
        var instance: VolumeButtonService? = null

        /** true enquanto o botão está de fato na tela (o Android pode matar o serviço sem avisar). */
        fun isRunning(): Boolean = instance?.holders?.isNotEmpty() == true

        @Volatile
        var announce = false

        private fun say(ctx: Context, msg: String) {
            try {
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
            }
        }

        /** [verbose] = chamado pelo usuário (interruptor/olho): explica na tela o que aconteceu. */
        fun sync(ctx: Context, verbose: Boolean = false) {
            val sp = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)
            val pref = sp.getBoolean("ui_vol_btn", false)
            val perm = Settings.canDrawOverlays(ctx)
            val on = pref && perm
            val inst = instance
            if (verbose) {
                announce = on
                if (!pref) say(ctx, "Botão de volume: desligado")
                else if (!perm) say(ctx, "Botão de volume: falta a permissão \"Exibir sobre outros apps\"")
                else if (inst != null && inst.holders.isNotEmpty()) say(ctx, "Botão de volume já está na tela (" + inst.holders.size + " tela(s))")
                else say(ctx, "Botão de volume: iniciando...")
            }
            if (on) {
                if (inst == null) {
                    try {
                        ctx.startForegroundService(Intent(ctx, VolumeButtonService::class.java))
                    } catch (e: Exception) {
                        say(ctx, "Botão de volume não iniciou: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                    }
                } else if (inst.holders.isEmpty()) {
                    inst.handler.post { if (inst.holders.isEmpty()) inst.addButtons() }
                }
            } else if (inst != null) {
                inst.dismissMenu()
                inst.removeAllButtons()
                inst.stopSelf()
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val holders = LinkedHashMap<Int, Holder>()
    private var menu: View? = null
    private var menuWm: WindowManager? = null

    private val sp get() = getSharedPreferences("win", MODE_PRIVATE)
    private fun sizePx(c: Context): Int =
        (sp.getInt("vb_size", DEF_SIZE_DP) * c.resources.displayMetrics.density + 0.5f).toInt()

    private fun baseAlpha() = sp.getInt("vb_alpha", 100).coerceIn(20, 100) / 100f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Botão de volume flutuante", NotificationManager.IMPORTANCE_MIN)
            )
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_volume)
                .setContentTitle("WinLauncher")
                .setContentText("Botão de volume flutuante ativo")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.post { if (holders.isEmpty()) addButtons() }
        return START_STICKY
    }

    override fun onDestroy() {
        dismissMenu()
        removeAllButtons()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ criação do botão em cada tela

    private fun displaySize(d: Display): String {
        return try {
            val p = Point()
            @Suppress("DEPRECATION")
            d.getRealSize(p)
            p.x.toString() + "x" + p.y
        } catch (e: Exception) {
            "?"
        }
    }

    /** Contexto de janela (API 30+) de uma tela: o jeito certo de colocar overlay em monitor externo. */
    private fun windowContext(d: Display): Context {
        val dc = createDisplayContext(d)
        return if (Build.VERSION.SDK_INT >= 30) {
            dc.createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
        } else dc
    }

    /** Cria o botão em todas as telas conectadas e, se pedido ou se algo falhar, mostra o resultado de cada uma. */
    private fun addButtons() {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val report = StringBuilder()
        var failed = false
        // Só a tela onde o launcher está aberto: criar janela em outra tela (ex.: HDMI) faz o Android
        // parar de espelhar o launcher nela e deixa o monitor preto mostrando apenas a janela.
        val target = sp.getInt("ov_display", Display.DEFAULT_DISPLAY)
        for (d in dm.displays) {
            if (holders.containsKey(d.displayId)) continue
            if ((d.flags and Display.FLAG_PRIVATE) != 0) continue
            val label = "tela " + d.displayId + " (" + d.name + ", " + displaySize(d) + ")"
            if (d.displayId != target) {
                report.append(label).append(": não usada\n")
                continue
            }
            var ok = false
            val err = StringBuilder()
            val makers = listOf<Pair<String, () -> Context>>(
                "janela" to { windowContext(d) },
                "contexto" to { createDisplayContext(d) }
            )
            for ((name, make) in makers) {
                try {
                    addHolder(d, make())
                    ok = true
                    report.append(label).append(": botão criado (").append(name).append(")\n")
                    break
                } catch (e: Exception) {
                    err.append(name).append(" ").append(e.javaClass.simpleName).append(" ").append(e.message ?: "").append("; ")
                }
            }
            if (!ok) {
                failed = true
                report.append(label).append(": FALHOU ").append(err).append("\n")
            }
        }
        if (holders.isEmpty()) {
            try {
                val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
                addHolder(d, this)
                report.append("tela padrão: botão criado (serviço)\n")
            } catch (e: Exception) {
                failed = true
                report.append("tela padrão: FALHOU ").append(e.javaClass.simpleName).append(" ").append(e.message ?: "").append("\n")
            }
        }
        if (announce || failed) {
            announce = false
            toastErr(report.toString().trim())
        }
    }

    private fun addHolder(d: Display, c: Context) {
        val w = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = c.resources.displayMetrics
        val dens = m.density
        val size = sizePx(c)
        val id = d.displayId

        val root = FrameLayout(c)
        root.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(210, 30, 30, 30))
            setStroke(dens.toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        val iv = ImageView(c)
        iv.setImageResource(R.drawable.ic_volume)
        iv.setPadding(size / 4, size / 4, size / 4, size / 4)
        root.addView(iv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.alpha = baseAlpha()

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val maxX = (m.widthPixels - size).coerceAtLeast(0)
        val maxY = (m.heightPixels - size).coerceAtLeast(0)
        lp.x = sp.getInt("vb_x_$id", maxX - (16 * dens).toInt()).coerceIn(0, maxX)
        lp.y = sp.getInt("vb_y_$id", (m.heightPixels * 0.4f).toInt()).coerceIn(0, maxY)

        val h = Holder(d, c, w, root, iv, lp)

        val slop = 8 * dens
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        var menuShown = false
        val longPress = Runnable {
            if (!dragging) {
                menuShown = true
                showMenu(h)
            }
        }

        root.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dismissMenu()
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    menuShown = false
                    if (ev.isButtonPressed(MotionEvent.BUTTON_SECONDARY)) {
                        // botão direito do mouse: abre o menu
                        menuShown = true
                        showMenu(h)
                    } else {
                        v.alpha = baseAlpha() * 0.7f
                        handler.postDelayed(longPress, 600) // toque longo com o dedo
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!menuShown) {
                        val dx = ev.rawX - downRawX
                        val dy = ev.rawY - downRawY
                        if (!dragging && (dx * dx + dy * dy) > slop * slop) {
                            dragging = true
                            handler.removeCallbacks(longPress)
                        }
                        if (dragging) {
                            val mm = c.resources.displayMetrics
                            val s = lp.width
                            lp.x = (startX + dx).toInt().coerceIn(0, (mm.widthPixels - s).coerceAtLeast(0))
                            lp.y = (startY + dy).toInt().coerceIn(0, (mm.heightPixels - s).coerceAtLeast(0))
                            try {
                                w.updateViewLayout(v, lp)
                            } catch (e: Exception) {
                            }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    v.alpha = baseAlpha()
                    if (dragging) {
                        sp.edit().putInt("vb_x_$id", lp.x).putInt("vb_y_$id", lp.y).apply()
                    } else if (!menuShown) {
                        showVolumePanel()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    v.alpha = baseAlpha()
                    true
                }
                else -> false
            }
        }

        w.addView(root, lp) // se falhar, nada foi adicionado e o chamador tenta o próximo método
        holders[id] = h
    }

    /** Abre o painel de volume nativo sem alterar o volume. */
    private fun showVolumePanel() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_SAME,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ mensagens

    /** Mostra a mensagem como Toast (tela do celular) e como caixinha em cada tela onde há botão (ex.: monitor). */
    private fun toastErr(msg: String) {
        try {
            Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
        for (h in holders.values.toList()) bubble(h, msg)
    }

    private fun bubble(h: Holder, msg: String) {
        try {
            val m = h.ctx.resources.displayMetrics
            val d = m.density
            val t = TextView(h.ctx)
            t.text = msg
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.maxWidth = (m.widthPixels * 0.8f).toInt()
            t.setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
            t.background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(Color.argb(235, 30, 30, 30))
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = (60 * d).toInt()
            h.wm.addView(t, lp)
            handler.postDelayed({
                try {
                    h.wm.removeView(t)
                } catch (e: Exception) {
                }
            }, 7000)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ menu (botão direito)

    private fun showMenu(h: Holder) {
        if (menu != null) return
        val c = h.ctx
        val w = h.wm
        val bp = h.lp
        try {
            val d = c.resources.displayMetrics.density
            fun dp(v: Int) = (v * d + 0.5f).toInt()

            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(16), dp(12), dp(16), dp(12))
            col.background = GradientDrawable().apply {
                cornerRadius = 14 * d
                setColor(Color.argb(240, 32, 32, 32))
                setStroke(dp(1), Color.argb(80, 255, 255, 255))
            }

            fun label(text: String): TextView {
                val t = TextView(c)
                t.text = text
                t.setTextColor(Color.WHITE)
                t.textSize = 13f
                return t
            }

            fun slider(title: String, min: Int, max: Int, cur: Int, unit: String, onChange: (Int) -> Unit) {
                val head = LinearLayout(c)
                head.orientation = LinearLayout.HORIZONTAL
                val value = label("$cur$unit")
                head.addView(label(title), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                head.addView(value, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                col.addView(head)
                val sb = SeekBar(c)
                sb.max = max - min
                sb.progress = (cur - min).coerceIn(0, max - min)
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        val v = min + p
                        value.text = "$v$unit"
                        if (fromUser) onChange(v)
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(6)
                col.addView(sb, lp)
            }

            slider("Opacidade", 20, 100, sp.getInt("vb_alpha", 100), "%") { v ->
                sp.edit().putInt("vb_alpha", v).apply()
                for (x in holders.values) x.root.alpha = v / 100f
            }
            slider("Tamanho", MIN_SIZE_DP, MAX_SIZE_DP, sp.getInt("vb_size", DEF_SIZE_DP), "dp") { v ->
                sp.edit().putInt("vb_size", v).apply()
                for (x in holders.values) applySize(x)
            }

            val hide = label("Ocultar botão")
            hide.setPadding(dp(4), dp(10), dp(4), dp(4))
            hide.setTextColor(Color.rgb(255, 140, 130))
            hide.setOnClickListener {
                sp.edit().putBoolean("ui_vol_btn", false).apply()
                dismissMenu()
                sync(this)
            }
            col.addView(hide)
            val tip = label("Para trazer de volta: ícone do olho na barra de volume do launcher.")
            tip.textSize = 11f
            tip.alpha = 0.6f
            tip.setPadding(dp(4), 0, dp(4), 0)
            col.addView(tip)

            // clique fora fecha o menu
            col.setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) dismissMenu()
                false
            }

            val m = c.resources.displayMetrics
            val mw = minOf(dp(250), m.widthPixels - dp(16))
            col.measure(
                View.MeasureSpec.makeMeasureSpec(mw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val mh = col.measuredHeight
            val lp = WindowManager.LayoutParams(
                mw, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (bp.x + bp.width / 2 - mw / 2).coerceIn(dp(8), maxOf(dp(8), m.widthPixels - mw - dp(8)))
            val below = bp.y + bp.height + dp(8)
            lp.y = if (below + mh <= m.heightPixels - dp(8)) below else maxOf(dp(8), bp.y - mh - dp(8))
            w.addView(col, lp)
            menu = col
            menuWm = w
        } catch (e: Exception) {
            menu = null
            menuWm = null
        }
    }

    private fun applySize(h: Holder) {
        val m = h.ctx.resources.displayMetrics
        val size = sizePx(h.ctx)
        h.lp.width = size
        h.lp.height = size
        h.lp.x = h.lp.x.coerceIn(0, (m.widthPixels - size).coerceAtLeast(0))
        h.lp.y = h.lp.y.coerceIn(0, (m.heightPixels - size).coerceAtLeast(0))
        h.icon.setPadding(size / 4, size / 4, size / 4, size / 4)
        try {
            h.wm.updateViewLayout(h.root, h.lp)
        } catch (e: Exception) {
        }
        val id = h.display.displayId
        sp.edit().putInt("vb_x_$id", h.lp.x).putInt("vb_y_$id", h.lp.y).apply()
    }

    fun dismissMenu() {
        val mv = menu ?: return
        val w = menuWm
        menu = null
        menuWm = null
        try {
            w?.removeView(mv)
        } catch (e: Exception) {
        }
    }

    fun removeAllButtons() {
        val all = holders.values.toList()
        holders.clear()
        for (h in all) {
            try {
                h.wm.removeView(h.root)
            } catch (e: Exception) {
            }
        }
    }
}
