package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL

/**
 * Dono único da sessão de mídia do YouTube Music (WinLauncher Remote, etapa 2).
 *
 * - Enxerga SOMENTE o pacote [YT_MUSIC_PKG]. Não cai em "qualquer sessão tocando":
 *   se o YouTube Music não tiver sessão, o estado é "sem sessão".
 * - Usa o mesmo acesso às notificações que o launcher já pede ([LauncherNotificationListener]).
 * - Guarda o estado (tocando/pausado, título, artista, álbum, capa, ações anunciadas pelo app)
 *   e executa play/pause, próxima e anterior.
 * - Tudo roda na thread principal (mesmo modelo de TaskbarMusic/QuickMusicCard/MusicWidget).
 *   Quem estiver em outra thread (futuro servidor do Remote) deve postar na principal.
 * - Uso: [start] ao precisar, [stop] ao terminar (contagem de usos; várias telas podem usar ao mesmo tempo).
 *
 * As classes TaskbarMusic, QuickMusicCard e MusicWidget NÃO usam este objeto (ainda): continuam
 * com a lógica própria, para não mexer em telas que já funcionam.
 */
object MediaSessionHub {

    const val YT_MUSIC_PKG = "com.google.android.apps.youtube.music"

    enum class Result { OK, NO_ACCESS, NO_SESSION, UNAVAILABLE, ERROR }

    /** Foto imutável do que o YouTube Music está publicando. */
    class State(
        val hasSession: Boolean,
        /** O sistema deixou o launcher ler as sessões (acesso às notificações concedido)? */
        val access: Boolean,
        val playing: Boolean,
        /** PlaybackState.STATE_*; -1 quando o app não publicou estado. */
        val stateCode: Int,
        val title: String,
        val artist: String,
        val album: String,
        val art: Bitmap?,
        /** De onde veio a capa (para diagnóstico): chave do bitmap, URI ou "nenhuma". */
        val artInfo: String,
        val actions: Long,
        val canPlay: Boolean,
        val canPause: Boolean,
        val canNext: Boolean,
        val canPrev: Boolean,
        val durationMs: Long,
        val positionMs: Long,
        val speed: Float,
        val customActions: List<String>
    ) {
        val canPlayPause: Boolean get() = if (playing) canPause else canPlay
    }

    interface Listener {
        fun onMediaState(s: State)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()

    private var appCtx: Context? = null
    private var listenerCn: ComponentName? = null
    private var msm: MediaSessionManager? = null
    private var ctrl: MediaController? = null
    private var users = 0
    private var registered = false
    private var access = true

    // capa carregada por URI (quando o app não manda bitmap)
    private var uriBmp: Bitmap? = null
    private var uriKey = ""
    private var uriTried = ""

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list ?: emptyList())
    }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = refresh()
    }

    // ------------------------------------------------------------------ acesso

    /** O launcher tem acesso às notificações (necessário para enxergar as sessões de mídia)? */
    fun hasAccess(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
    }

    // ------------------------------------------------------------------ ciclo de vida

    /** Começa a acompanhar o YouTube Music. Chame na thread principal. */
    fun start(ctx: Context) {
        val app = ctx.applicationContext
        appCtx = app
        if (listenerCn == null) listenerCn = ComponentName(app, LauncherNotificationListener::class.java)
        users++
        if (!registered) register()
    }

    /** Termina um uso. Quando o último sai, solta tudo. */
    fun stop() {
        if (users > 0) users--
        if (users > 0) return
        if (registered) {
            registered = false
            try {
                msm?.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
            }
        }
        try {
            ctrl?.unregisterCallback(cb)
        } catch (e: Exception) {
        }
        ctrl = null
        uriBmp = null
        uriKey = ""
        uriTried = ""
    }

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    /** Lê as sessões de novo (útil depois que o usuário concede o acesso às notificações). */
    fun refresh() {
        if (users == 0) return
        if (!registered) {
            register()
            return
        }
        val m = msm
        val cn = listenerCn
        if (m == null || cn == null) return
        try {
            access = true
            bind(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            access = false
            bind(emptyList())
        } catch (e: Exception) {
            bind(emptyList())
        }
    }

    private fun register() {
        val app = appCtx ?: return
        val cn = listenerCn ?: return
        val m = app.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
        msm = m
        if (m == null) {
            access = false
            publish()
            return
        }
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn, ui)
            registered = true
            access = true
            bind(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // sem acesso às notificações: tentamos de novo no refresh()
            registered = false
            access = false
            bind(emptyList())
        } catch (e: Exception) {
            registered = false
            bind(emptyList())
        }
    }

    private fun bind(list: List<MediaController>) {
        val best = list.firstOrNull { it.packageName == YT_MUSIC_PKG }
        if (best?.sessionToken != ctrl?.sessionToken) {
            try {
                ctrl?.unregisterCallback(cb)
            } catch (e: Exception) {
            }
            ctrl = best
            uriBmp = null
            uriKey = ""
            uriTried = ""
            try {
                best?.registerCallback(cb, ui)
            } catch (e: Exception) {
            }
        }
        publish()
    }

    // ------------------------------------------------------------------ estado

    private fun isPlayingState(st: Int): Boolean =
        st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING

    private fun trackKey(md: MediaMetadata?): String =
        (md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" +
            (md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")

    /** Estado atual (monta na hora a partir do controlador). */
    fun state(): State {
        val c = ctrl
        if (c == null) {
            return State(
                false, access, false, -1, "", "", "", null, "nenhuma", 0L,
                false, false, false, false, 0L, 0L, 1f, emptyList()
            )
        }
        val md = c.metadata
        val st = c.playbackState
        val code = st?.state ?: -1
        val actions = st?.actions ?: 0L
        fun has(a: Long) = (actions and a) != 0L

        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""

        // capa: bitmap em uma das chaves; senão, a que foi baixada pela URI
        var art: Bitmap? = null
        var info = "nenhuma"
        if (md != null) {
            val keys = listOf(
                "ALBUM_ART" to MediaMetadata.METADATA_KEY_ALBUM_ART,
                "ART" to MediaMetadata.METADATA_KEY_ART,
                "DISPLAY_ICON" to MediaMetadata.METADATA_KEY_DISPLAY_ICON
            )
            for ((name, k) in keys) {
                val b = md.getBitmap(k)
                if (b != null) {
                    art = b
                    info = "bitmap em $name"
                    break
                }
            }
            if (art == null) {
                val uri = artUri(md)
                if (uri != null) {
                    if (uriBmp != null && uriKey == trackKey(md)) {
                        art = uriBmp
                        info = "URI carregada"
                    } else {
                        info = "só URI (" + uri.take(60) + ")"
                    }
                }
            }
        }

        val custom = ArrayList<String>()
        try {
            st?.customActions?.forEach { custom.add(it.name?.toString() ?: it.action) }
        } catch (e: Exception) {
        }

        return State(
            hasSession = true,
            access = access,
            playing = isPlayingState(code),
            stateCode = code,
            title = title,
            artist = artist,
            album = album,
            art = art,
            artInfo = info,
            actions = actions,
            canPlay = has(PlaybackState.ACTION_PLAY) || has(PlaybackState.ACTION_PLAY_PAUSE),
            canPause = has(PlaybackState.ACTION_PAUSE) || has(PlaybackState.ACTION_PLAY_PAUSE),
            canNext = has(PlaybackState.ACTION_SKIP_TO_NEXT),
            canPrev = has(PlaybackState.ACTION_SKIP_TO_PREVIOUS),
            durationMs = (md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L).coerceAtLeast(0L),
            positionMs = st?.position ?: 0L,
            speed = if (st != null && st.playbackSpeed > 0f) st.playbackSpeed else 1f,
            customActions = custom
        )
    }

    private fun artUri(md: MediaMetadata): String? =
        md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)

    private fun publish() {
        // capa por URI: só tenta se não há bitmap e ainda não tentou esta URI
        val c = ctrl
        val md = c?.metadata
        if (c != null && md != null) {
            val hasBitmap = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) != null ||
                md.getBitmap(MediaMetadata.METADATA_KEY_ART) != null ||
                md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON) != null
            val key = trackKey(md)
            if (key != uriKey) {
                // faixa mudou: descarta a capa antiga
                uriBmp = null
                uriKey = key
                uriTried = ""
            }
            val uri = artUri(md)
            if (!hasBitmap && uri != null && uri != uriTried) {
                uriTried = uri
                loadUri(uri, key)
            }
        }
        val s = state()
        for (l in ArrayList(listeners)) {
            try {
                l.onMediaState(s)
            } catch (e: Exception) {
            }
        }
    }

    private fun loadUri(uri: String, key: String) {
        val app = appCtx ?: return
        Thread {
            val b = try {
                decodeUri(app, uri)
            } catch (t: Throwable) {
                null
            }
            if (b != null) ui.post {
                val md = ctrl?.metadata
                if (md != null && trackKey(md) == key) {
                    uriBmp = b
                    uriKey = key
                    publish()
                }
            }
        }.start()
    }

    private fun decodeUri(app: Context, uri: String): Bitmap? {
        val bytes: ByteArray = if (uri.startsWith("http://") || uri.startsWith("https://")) {
            val con = URL(uri).openConnection() as HttpURLConnection
            con.connectTimeout = 4000
            con.readTimeout = 4000
            try {
                con.inputStream.use { it.readBytes() }
            } finally {
                con.disconnect()
            }
        } else {
            app.contentResolver.openInputStream(Uri.parse(uri))?.use { it.readBytes() } ?: return null
        }
        if (bytes.size > 8 * 1024 * 1024) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 256 && o.outHeight / (sample * 2) >= 256) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    // ------------------------------------------------------------------ comandos

    private fun controller(): Pair<MediaController?, Result> {
        val c = ctrl
        if (c != null) return c to Result.OK
        return null to (if (!access) Result.NO_ACCESS else Result.NO_SESSION)
    }

    /**
     * Toca se estiver pausado, pausa se estiver tocando.
     * [force] = true envia mesmo que o app não anuncie a ação (só para teste/diagnóstico).
     */
    fun togglePlayPause(force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        val s = state()
        if (!force && !s.canPlayPause) return Result.UNAVAILABLE
        return try {
            if (s.playing) c.transportControls.pause() else c.transportControls.play()
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    fun next(force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        if (!force && !state().canNext) return Result.UNAVAILABLE
        return try {
            c.transportControls.skipToNext()
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    fun previous(force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        if (!force && !state().canPrev) return Result.UNAVAILABLE
        return try {
            c.transportControls.skipToPrevious()
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }
}
