package com.example.winlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL

/**
 * Dono único da sessão de mídia controlada pelo WinLauncher Remote.
 *
 * - NÃO depende de um nome de pacote fixo. Lê TODAS as sessões de mídia ativas
 *   ([MediaSessionManager.getActiveSessions]) e descobre o pacote real de cada uma em tempo de execução.
 * - Modo automático: só escolhe sessões que PARECEM YouTube Music (pacote oficial, nome do app com
 *   "YouTube Music" ou pacote com "youtube" + "music": cobre versões modificadas, como ReVanced/Morphe).
 *   Nunca presume que uma sessão qualquer é do YouTube Music.
 * - Modo manual: o usuário escolhe qualquer sessão (ou app instalado) e a escolha fica salva.
 * - Usa o acesso às notificações que o launcher já pede ([LauncherNotificationListener]).
 * - Atualiza sozinho quando uma sessão aparece, some, troca de faixa ou muda de estado.
 * - Tudo roda na thread principal. Quem estiver em outra thread (futuro servidor do Remote) deve postar na principal.
 * - Uso: [start] ao precisar, [stop] ao terminar (contagem de usos).
 *
 * TaskbarMusic, QuickMusicCard e MusicWidget NÃO usam este objeto: continuam com a lógica própria.
 */
object MediaSessionHub {

    /** Pacote do YouTube Music oficial. Usado só como pista no modo automático, nunca como filtro único. */
    const val OFFICIAL_PKG = "com.google.android.apps.youtube.music"

    private const val PREF_KEY = "remote_media_pkg"

    enum class Result { OK, NO_ACCESS, NO_SESSION, UNAVAILABLE, ERROR }

    /** Uma sessão de mídia ativa no aparelho. */
    class SessionInfo(
        val pkg: String,
        val label: String,
        val playing: Boolean,
        val title: String,
        /** Parece YouTube Music (pacote oficial ou nome/pacote parecido). */
        val ytLike: Boolean,
        /** É o player da própria WinLauncher. */
        val own: Boolean
    )

    /** App instalado que parece YouTube Music (mesmo sem sessão ativa). */
    class Installed(val pkg: String, val label: String)

    /** Por que a fila está, ou não está, disponível. */
    enum class QueueStatus {
        /** A sessão publicou uma fila com itens. */
        OK,

        /** Sem acesso às notificações: o launcher não enxerga as sessões. */
        NO_ACCESS,

        /** Não há sessão controlada. */
        NO_SESSION,

        /** Há sessão, mas o app NÃO publicou fila pela MediaSession ([MediaController.getQueue] devolveu null). */
        NOT_PUBLISHED,

        /** Há sessão e o app publicou uma fila, mas vazia. */
        EMPTY
    }

    /**
     * Um item da fila REAL publicada pelo app ([MediaSession.QueueItem]). Nada aqui é deduzido: título e subtítulo vêm do
     * [android.media.MediaDescription] do item. [mediaId] só serve para localizar o item ativo quando o app não informa o
     * activeQueueItemId (não vai para o protocolo).
     */
    data class QueueEntry(val queueId: Long, val title: String, val subtitle: String, val mediaId: String)

    /**
     * Foto imutável da fila da sessão controlada. [activeId] é o activeQueueItemId do PlaybackState (-1 = o app não informou);
     * [activeIndex] é a posição do item ativo em [items] (-1 = não foi possível identificar com certeza).
     */
    data class Queue(
        val status: QueueStatus,
        val pkg: String,
        val title: String,
        val activeId: Long,
        val activeIndex: Int,
        val items: List<QueueEntry>
    )

    /** Fila "sem sessão": usada quando não há o que ler. */
    val NO_QUEUE = Queue(QueueStatus.NO_SESSION, "", "", -1L, -1, emptyList())

    /** Foto imutável da sessão controlada. */
    class State(
        val hasSession: Boolean,
        /** O launcher pode ler as sessões (acesso às notificações concedido e funcionando)? */
        val access: Boolean,
        /** Pacote real e nome do app da sessão controlada ("" quando não há). */
        val pkg: String,
        val appLabel: String,
        /** Pacote escolhido manualmente ("" = modo automático). */
        val selectedPkg: String,
        /** Todas as sessões de mídia ativas agora. */
        val sessions: List<SessionInfo>,
        val playing: Boolean,
        /** PlaybackState.STATE_*; -1 quando o app não publicou estado. */
        val stateCode: Int,
        val title: String,
        val artist: String,
        val album: String,
        val art: Bitmap?,
        /** De onde veio a capa (diagnóstico). */
        val artInfo: String,
        val actions: Long,
        val canPlay: Boolean,
        val canPause: Boolean,
        val canNext: Boolean,
        val canPrev: Boolean,
        val durationMs: Long,
        val positionMs: Long,
        val speed: Float,
        val customActions: List<String>
    ) {
        val canPlayPause: Boolean get() = if (playing) canPause else canPlay
        val manual: Boolean get() = selectedPkg.isNotEmpty()
    }

    interface Listener {
        fun onMediaState(s: State)

        /**
         * A fila da sessão controlada mudou (itens, título, item ativo, sessão trocada ou fila deixou de existir).
         * Corpo padrão vazio: ouvintes que só conhecem [onMediaState] continuam valendo sem mudança.
         */
        fun onQueue(q: Queue) {
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()

    private var appCtx: Context? = null
    private var listenerCn: ComponentName? = null
    private var msm: MediaSessionManager? = null
    private var users = 0
    private var registered = false
    private var access = true

    /** Controladores de todas as sessões ativas (todos com callback, para reagir a qualquer mudança). */
    private var sessionsList: List<MediaController> = emptyList()
    private val watched = HashMap<MediaSession.Token, MediaController>()

    /** Sessão que está sendo controlada agora. */
    private var ctrl: MediaController? = null

    private val labels = HashMap<String, String>()

    // fila real da sessão controlada (cache lido por binder; ver readQueueCache)
    private var qItems: List<QueueEntry> = emptyList()
    private var qTitle = ""

    /** [MediaController.getQueue] devolveu uma lista (mesmo vazia)? false = o app não publicou fila. */
    private var qPublished = false

    /** true = a próxima [reselect] relê a fila (pedido por [refresh]). */
    private var qForceRead = false
    private var lastQueue: Queue? = null

    /**
     * Itens crus da última leitura da fila, só para [queueArtSource] achar a imagem (iconBitmap/iconUri) de um item pelo
     * queueId. Fila grande: guarda só a parte perto do item ativo, para não segurar centenas de bitmaps na memória.
     */
    private var qRaw: List<MediaSession.QueueItem> = emptyList()

    // capa carregada por URI (quando o app não manda bitmap)
    private var uriBmp: Bitmap? = null
    private var uriKey = ""
    private var uriTried = ""

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list ?: emptyList())
    }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = reselect()
        override fun onPlaybackStateChanged(state: PlaybackState?) = reselect()
        override fun onSessionDestroyed() = refresh()

        // A fila real chega por aqui (setQueue/setQueueTitle do app). Não diz de qual sessão veio: relê a da sessão controlada.
        override fun onQueueChanged(queue: MutableList<MediaSession.QueueItem>?) = publishQueue(true)
        override fun onQueueTitleChanged(title: CharSequence?) = publishQueue(true)
    }

    // ------------------------------------------------------------------ acesso

    /** O launcher tem acesso às notificações (necessário para enxergar as sessões de mídia)? */
    fun hasAccess(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
    }

    // ------------------------------------------------------------------ ciclo de vida

    /** Começa a acompanhar as sessões. Chame na thread principal. */
    fun start(ctx: Context) {
        val app = ctx.applicationContext
        appCtx = app
        if (listenerCn == null) listenerCn = ComponentName(app, LauncherNotificationListener::class.java)
        users++
        if (!registered) register()
    }

    /** Termina um uso. Quando o último sai, solta tudo. */
    fun stop() {
        if (users > 0) users--
        if (users > 0) return
        if (registered) {
            registered = false
            try {
                msm?.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
            }
        }
        for (c in watched.values) {
            try {
                c.unregisterCallback(cb)
            } catch (e: Exception) {
            }
        }
        watched.clear()
        sessionsList = emptyList()
        ctrl = null
        resetArt()
        qItems = emptyList()
        qTitle = ""
        qPublished = false
        qForceRead = false
        lastQueue = null
        qRaw = emptyList()
    }

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    /** Lê as sessões de novo (útil depois que o usuário concede o acesso às notificações). */
    fun refresh() {
        if (users == 0) return
        qForceRead = true
        if (!registered) {
            register()
            return
        }
        val m = msm
        val cn = listenerCn
        if (m == null || cn == null) return
        try {
            access = true
            bind(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            access = false
            bind(emptyList())
        } catch (e: Exception) {
            bind(emptyList())
        }
    }

    private fun register() {
        val app = appCtx ?: return
        val cn = listenerCn ?: return
        val m = app.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
        msm = m
        if (m == null) {
            access = false
            bind(emptyList())
            return
        }
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn, ui)
            registered = true
            access = true
            bind(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // sem acesso às notificações: tentamos de novo no refresh()
            registered = false
            access = false
            bind(emptyList())
        } catch (e: Exception) {
            registered = false
            bind(emptyList())
        }
    }

    /** Lista de sessões mudou (app abriu, fechou ou trocou de sessão). */
    private fun bind(list: List<MediaController>) {
        sessionsList = list
        val tokens = HashSet<MediaSession.Token>()
        for (c in list) tokens.add(c.sessionToken)
        // para de observar o que sumiu
        val gone = watched.keys.filter { it !in tokens }
        for (t in gone) {
            try {
                watched[t]?.unregisterCallback(cb)
            } catch (e: Exception) {
            }
            watched.remove(t)
        }
        // passa a observar o que apareceu
        for (c in list) {
            if (!watched.containsKey(c.sessionToken)) {
                try {
                    c.registerCallback(cb, ui)
                    watched[c.sessionToken] = c
                } catch (e: Exception) {
                }
            }
        }
        reselect()
    }

    // ------------------------------------------------------------------ escolha da sessão

    private fun prefs() = appCtx?.getSharedPreferences("win", Context.MODE_PRIVATE)

    /** Pacote escolhido manualmente ("" = automático). */
    fun selectedPkg(): String = prefs()?.getString(PREF_KEY, "") ?: ""

    /** Escolhe manualmente o app a controlar; null volta ao modo automático. */
    fun select(pkg: String?) {
        prefs()?.edit()?.putString(PREF_KEY, pkg ?: "")?.apply()
        reselect()
    }

    private fun labelOf(pkg: String): String = labels.getOrPut(pkg) {
        try {
            val pm = appCtx!!.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    /** Pacote oficial, ou nome/pacote que lembra YouTube Music (versões modificadas). É só uma pista. */
    private fun looksLikeYtMusic(pkg: String, label: String): Boolean {
        val p = pkg.lowercase()
        val l = label.lowercase()
        return pkg == OFFICIAL_PKG || l.contains("youtube music") || l.contains("yt music") ||
            (p.contains("youtube") && p.contains("music"))
    }

    private fun isPlayingState(st: Int): Boolean =
        st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING

    private fun isPlaying(c: MediaController): Boolean = isPlayingState(c.playbackState?.state ?: -1)

    private fun choose(): MediaController? {
        val sel = selectedPkg()
        if (sel.isNotEmpty()) {
            val l = sessionsList.filter { it.packageName == sel }
            return l.firstOrNull { isPlaying(it) } ?: l.firstOrNull()
        }
        val own = appCtx?.packageName
        val l = sessionsList.filter { it.packageName != own && looksLikeYtMusic(it.packageName, labelOf(it.packageName)) }
        return l.firstOrNull { isPlaying(it) } ?: l.firstOrNull()
    }

    /** Reavalia qual sessão controlar e avisa quem está ouvindo. */
    private fun reselect() {
        val best = choose()
        var reread = qForceRead
        if (best?.sessionToken != ctrl?.sessionToken) {
            ctrl = best
            resetArt()
            reread = true
        }
        // sessão trocada (ou pedido de refresh): a fila em cache é de outra sessão ou pode estar velha
        if (reread) {
            qForceRead = false
            readQueueCache()
        }
        publish()
    }

    private fun resetArt() {
        uriBmp = null
        uriKey = ""
        uriTried = ""
    }

    // ------------------------------------------------------------------ apps instalados

    /** Apps com ícone no launcher que parecem YouTube Music (inclui versões modificadas). */
    fun installedCandidates(): List<Installed> {
        val app = appCtx ?: return emptyList()
        val pm = app.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = try {
            pm.queryIntentActivities(q, 0)
        } catch (e: Exception) {
            emptyList()
        }
        val out = ArrayList<Installed>()
        val seen = HashSet<String>()
        for (ri in list) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (!seen.add(pkg)) continue
            val label = try {
                ri.loadLabel(pm).toString()
            } catch (e: Exception) {
                pkg
            }
            if (looksLikeYtMusic(pkg, label)) out.add(Installed(pkg, label))
        }
        return out
    }

    /**
     * Abre o app da sessão controlada (ou o escolhido manualmente). Sem escolha, só abre se houver
     * exatamente um app instalado parecido com YouTube Music. Devolve false se não souber qual abrir.
     */
    fun openApp(): Boolean {
        val app = appCtx ?: return false
        val sel = selectedPkg()
        val pkg: String = ctrl?.packageName
            ?: (if (sel.isNotEmpty()) sel else null)
            ?: installedCandidates().singleOrNull()?.pkg
            ?: return false
        try {
            val i = app.packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            }
        } catch (e: Exception) {
        }
        // sem ícone visível para o launcher: usa a atividade que o próprio app registrou na sessão
        return try {
            val pi = ctrl?.sessionActivity
            if (pi != null) {
                pi.send()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------ estado

    private fun trackKey(md: MediaMetadata?): String =
        (md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" +
            (md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")

    private fun sessionInfos(): List<SessionInfo> {
        val own = appCtx?.packageName
        return sessionsList.map { c ->
            val pkg = c.packageName
            val label = labelOf(pkg)
            SessionInfo(
                pkg = pkg,
                label = label,
                playing = isPlaying(c),
                title = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
                ytLike = looksLikeYtMusic(pkg, label),
                own = pkg == own
            )
        }
    }

    /** Estado atual (monta na hora a partir do controlador). */
    fun state(): State {
        val app = appCtx
        val acc = access && (app == null || hasAccess(app))
        val sessions = sessionInfos()
        val sel = selectedPkg()
        val c = ctrl
        if (c == null) {
            return State(
                hasSession = false, access = acc, pkg = "", appLabel = "", selectedPkg = sel,
                sessions = sessions, playing = false, stateCode = -1, title = "", artist = "", album = "",
                art = null, artInfo = "nenhuma", actions = 0L, canPlay = false, canPause = false,
                canNext = false, canPrev = false, durationMs = 0L, positionMs = 0L, speed = 1f,
                customActions = emptyList()
            )
        }
        val md = c.metadata
        val st = c.playbackState
        val code = st?.state ?: -1
        val actions = st?.actions ?: 0L
        fun has(a: Long) = (actions and a) != 0L

        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""

        // capa: bitmap em uma das chaves; senão, a que foi baixada pela URI
        var art: Bitmap? = null
        var info = "nenhuma"
        if (md != null) {
            val keys = listOf(
                "ALBUM_ART" to MediaMetadata.METADATA_KEY_ALBUM_ART,
                "ART" to MediaMetadata.METADATA_KEY_ART,
                "DISPLAY_ICON" to MediaMetadata.METADATA_KEY_DISPLAY_ICON
            )
            for ((name, k) in keys) {
                val b = md.getBitmap(k)
                if (b != null) {
                    art = b
                    info = "bitmap em $name"
                    break
                }
            }
            if (art == null) {
                val uri = artUri(md)
                if (uri != null) {
                    if (uriBmp != null && uriKey == trackKey(md)) {
                        art = uriBmp
                        info = "URI carregada"
                    } else {
                        info = "só URI (" + uri.take(60) + ")"
                    }
                }
            }
        }

        val custom = ArrayList<String>()
        try {
            st?.customActions?.forEach { custom.add(it.name?.toString() ?: it.action) }
        } catch (e: Exception) {
        }

        return State(
            hasSession = true,
            access = acc,
            pkg = c.packageName,
            appLabel = labelOf(c.packageName),
            selectedPkg = sel,
            sessions = sessions,
            playing = isPlayingState(code),
            stateCode = code,
            title = title,
            artist = artist,
            album = album,
            art = art,
            artInfo = info,
            actions = actions,
            canPlay = has(PlaybackState.ACTION_PLAY) || has(PlaybackState.ACTION_PLAY_PAUSE),
            canPause = has(PlaybackState.ACTION_PAUSE) || has(PlaybackState.ACTION_PLAY_PAUSE),
            canNext = has(PlaybackState.ACTION_SKIP_TO_NEXT),
            canPrev = has(PlaybackState.ACTION_SKIP_TO_PREVIOUS),
            durationMs = (md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L).coerceAtLeast(0L),
            positionMs = st?.position ?: 0L,
            speed = if (st != null && st.playbackSpeed > 0f) st.playbackSpeed else 1f,
            customActions = custom
        )
    }

    private fun artUri(md: MediaMetadata): String? =
        md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)

    private fun publish() {
        // capa por URI: só tenta se não há bitmap e ainda não tentou esta URI
        val c = ctrl
        val md = c?.metadata
        if (c != null && md != null) {
            val hasBitmap = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) != null ||
                md.getBitmap(MediaMetadata.METADATA_KEY_ART) != null ||
                md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON) != null
            val key = trackKey(md)
            if (key != uriKey) {
                // faixa mudou: descarta a capa antiga
                uriBmp = null
                uriKey = key
                uriTried = ""
            }
            val uri = artUri(md)
            if (!hasBitmap && uri != null && uri != uriTried) {
                uriTried = uri
                loadUri(uri, key)
            }
        }
        val s = state()
        for (l in ArrayList(listeners)) {
            try {
                l.onMediaState(s)
            } catch (e: Exception) {
            }
        }
        // o item ativo (activeQueueItemId) muda junto com o PlaybackState: reavalia a fila a partir do cache, sem binder pesado
        publishQueue(false)
    }

    private fun loadUri(uri: String, key: String) {
        val app = appCtx ?: return
        Thread {
            val b = try {
                decodeUri(app, uri)
            } catch (t: Throwable) {
                null
            }
            if (b != null) ui.post {
                val md = ctrl?.metadata
                if (md != null && trackKey(md) == key) {
                    uriBmp = b
                    uriKey = key
                    publish()
                }
            }
        }.start()
    }

    private fun decodeUri(app: Context, uri: String): Bitmap? {
        val bytes: ByteArray = if (uri.startsWith("http://") || uri.startsWith("https://")) {
            val con = URL(uri).openConnection() as HttpURLConnection
            con.connectTimeout = 4000
            con.readTimeout = 4000
            try {
                con.inputStream.use { it.readBytes() }
            } finally {
                con.disconnect()
            }
        } else {
            app.contentResolver.openInputStream(Uri.parse(uri))?.use { it.readBytes() } ?: return null
        }
        if (bytes.size > 8 * 1024 * 1024) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 256 && o.outHeight / (sample * 2) >= 256) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    // ------------------------------------------------------------------ fila (MediaSession.getQueue)

    /** Teto de itens guardados e de caracteres por texto (só proteção de memória; o protocolo limita de novo). */
    private const val QUEUE_KEEP_MAX = 5000
    private const val RAW_KEEP_ALL = 300
    private const val RAW_KEEP_AROUND = 100
    private const val QUEUE_TEXT_MAX = 200

    private fun clipText(s: CharSequence?): String {
        val t = s?.toString() ?: return ""
        return if (t.length <= QUEUE_TEXT_MAX) t else t.substring(0, QUEUE_TEXT_MAX)
    }

    /**
     * Lê por binder a fila REAL da sessão controlada e guarda em cache. Nunca inventa itens: se o app não publicou fila
     * ([MediaController.getQueue] == null), o cache fica vazio e [qPublished] = false. Thread principal.
     */
    private fun readQueueCache() {
        val c = ctrl
        if (c == null) {
            qItems = emptyList()
            qTitle = ""
            qPublished = false
            qRaw = emptyList()
            return
        }
        try {
            val raw: List<MediaSession.QueueItem>? = c.queue
            qPublished = raw != null
            val out = ArrayList<QueueEntry>()
            if (raw != null) {
                for (qi in raw) {
                    if (out.size >= QUEUE_KEEP_MAX) break
                    val d = qi.description
                    val title = clipText(d?.title).ifBlank { clipText(d?.description) }
                    out.add(QueueEntry(qi.queueId, title, clipText(d?.subtitle), d?.mediaId ?: ""))
                }
            }
            qItems = out
            qTitle = clipText(c.queueTitle)
            qRaw = keepRawAroundActive(raw, c)
        } catch (e: Exception) {
            // sessão morreu no meio da leitura ou sem permissão: trata como "não publicada" (sem inventar nada)
            qItems = emptyList()
            qTitle = ""
            qPublished = false
            qRaw = emptyList()
        }
    }

    /** Até [RAW_KEEP_ALL] itens: guarda todos. Mais que isso: só ±[RAW_KEEP_AROUND] em volta do item ativo (ou o começo, se não se sabe). */
    private fun keepRawAroundActive(raw: List<MediaSession.QueueItem>?, c: MediaController): List<MediaSession.QueueItem> {
        if (raw == null) return emptyList()
        if (raw.size <= RAW_KEEP_ALL) return ArrayList(raw)
        val activeId = try {
            c.playbackState?.activeQueueItemId ?: -1L
        } catch (e: Exception) {
            -1L
        }
        val at = if (activeId != -1L) raw.indexOfFirst { it.queueId == activeId } else -1
        val from = if (at >= 0) maxOf(0, at - RAW_KEEP_AROUND) else 0
        val to = minOf(raw.size, (if (at >= 0) at else 0) + RAW_KEEP_AROUND)
        return ArrayList(raw.subList(from, to))
    }

    /**
     * Origem da capa do item [queueId] da fila REAL: o iconBitmap da descrição do item; se o app não mandou bitmap, o iconUri.
     * null se o item não existe (mais) ou o app não deu imagem nenhuma para ele. NUNCA devolve captura de tela nem o ícone
     * do aplicativo (só o que o app publicou no item). Thread principal.
     */
    fun queueArtSource(queueId: Long): QueueArtSource? {
        for (qi in qRaw) {
            if (qi.queueId != queueId) continue
            val d = qi.description ?: return null
            val bmp = try {
                d.iconBitmap
            } catch (e: Exception) {
                null
            }
            val uri = try {
                d.iconUri?.toString() ?: ""
            } catch (e: Exception) {
                ""
            }
            val usable = if (bmp != null && !bmp.isRecycled && bmp.width > 0 && bmp.height > 0) bmp else null
            if (usable == null && uri.isEmpty()) return null
            // chave estável entre leituras (o binder devolve bitmaps novos a cada leitura): identifica a faixa, não o objeto
            val id = d.mediaId ?: ""
            val key = if (usable != null) {
                "b:" + id + "|" + (d.title ?: "") + "|" + usable.width + "x" + usable.height
            } else {
                "u:" + uri
            }
            return QueueArtSource(key, usable, if (usable != null) "" else uri)
        }
        return null
    }

    /** Monta a foto da fila a partir do cache + item ativo atual (leituras baratas). */
    private fun buildQueue(): Queue {
        val c = ctrl
        if (c == null) {
            val app = appCtx
            val acc = access && (app == null || hasAccess(app))
            return Queue(if (acc) QueueStatus.NO_SESSION else QueueStatus.NO_ACCESS, "", "", -1L, -1, emptyList())
        }
        val items = qItems
        val status = when {
            !qPublished -> QueueStatus.NOT_PUBLISHED
            items.isEmpty() -> QueueStatus.EMPTY
            else -> QueueStatus.OK
        }
        val activeId = try {
            c.playbackState?.activeQueueItemId ?: -1L
        } catch (e: Exception) {
            -1L
        }
        var idx = -1
        if (items.isNotEmpty() && activeId != -1L) idx = items.indexOfFirst { it.queueId == activeId }
        if (idx < 0 && items.isNotEmpty()) {
            // o app não informou (ou informou um id que não está na lista): só aceita casar pelo mediaId da faixa atual
            // se houver UM único item com esse mediaId. Título/artista não servem (podem repetir).
            val mid = try {
                c.metadata?.getString(MediaMetadata.METADATA_KEY_MEDIA_ID) ?: ""
            } catch (e: Exception) {
                ""
            }
            if (mid.isNotEmpty()) {
                var hit = -1
                var n = 0
                for (i in items.indices) {
                    if (items[i].mediaId == mid) {
                        hit = i
                        n++
                    }
                }
                if (n == 1) idx = hit
            }
        }
        return Queue(status, c.packageName, qTitle, activeId, idx, items)
    }

    /** Fila atual da sessão controlada (a partir do cache; o cache é atualizado pelos callbacks e por [refresh]). */
    fun queue(): Queue = buildQueue()

    /** Avisa os ouvintes se a fila mudou. [reread] = relê do app antes (callbacks de fila). Thread principal. */
    private fun publishQueue(reread: Boolean) {
        if (users == 0) return
        if (reread) readQueueCache()
        val q = buildQueue()
        if (q == lastQueue) return
        lastQueue = q
        for (l in ArrayList(listeners)) {
            try {
                l.onQueue(q)
            } catch (e: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ comandos

    private fun controller(): Pair<MediaController?, Result> {
        val c = ctrl
        if (c != null) return c to Result.OK
        val acc = access && (appCtx == null || hasAccess(appCtx!!))
        return null to (if (!acc) Result.NO_ACCESS else Result.NO_SESSION)
    }

    /**
     * Toca se estiver pausado, pausa se estiver tocando.
     * [force] = true envia mesmo que o app não anuncie a ação (só para teste/diagnóstico).
     */
    fun togglePlayPause(force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        val s = state()
        if (!force && !s.canPlayPause) return Result.UNAVAILABLE
        return try {
            if (s.playing) c.transportControls.pause() else c.transportControls.play()
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    fun next(force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        if (!force && !state().canNext) return Result.UNAVAILABLE
        return try {
            c.transportControls.skipToNext()
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    fun previous(force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        if (!force && !state().canPrev) return Result.UNAVAILABLE
        return try {
            c.transportControls.skipToPrevious()
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    /**
     * Toca o item da fila REAL cujo [queueId] veio do Remote ([MediaController.TransportControls.skipToQueueItem]).
     * Só aceita ids que estão na fila atual (se a fila mudou entre o envio da lista e o toque, devolve UNAVAILABLE e o
     * Remote avisa "a fila pode ter mudado"). Sem "force": se o app não anuncia ACTION_SKIP_TO_QUEUE_ITEM, UNAVAILABLE.
     */
    fun skipToQueueItem(queueId: Long, force: Boolean = false): Result {
        val (c, r) = controller()
        if (c == null) return r
        if (qItems.none { it.queueId == queueId }) return Result.UNAVAILABLE
        if (!force) {
            val acts = try {
                c.playbackState?.actions ?: 0L
            } catch (e: Exception) {
                0L
            }
            // O app não anuncia "pular para item da fila" (comum em YouTube Music modificado): em vez de recusar, anda pela
            // fila com próxima/anterior (que ele anuncia) o número de posições que separa o item atual do escolhido.
            if (acts and PlaybackState.ACTION_SKIP_TO_QUEUE_ITEM == 0L) return stepToQueueItem(c, queueId)
        }
        return try {
            c.transportControls.skipToQueueItem(queueId)
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    /** Máximo de passos de próxima/anterior para chegar a um item da fila (mais longe que isso: UNAVAILABLE). */
    private const val MAX_STEPS = 20

    /**
     * Fallback de [skipToQueueItem]: chega ao item [queueId] com skipToNext/skipToPrevious. Só se a posição atual e a do alvo
     * são conhecidas com certeza, o app anuncia a ação de próxima/anterior e a distância é de até [MAX_STEPS]. Nunca chuta.
     */
    private fun stepToQueueItem(c: MediaController, queueId: Long): Result {
        val q = buildQueue()
        val target = qItems.indexOfFirst { it.queueId == queueId }
        if (q.activeIndex < 0 || target < 0) return Result.UNAVAILABLE
        val delta = target - q.activeIndex
        if (delta == 0) return Result.OK
        val steps = Math.abs(delta)
        if (steps > MAX_STEPS) return Result.UNAVAILABLE
        val s = state()
        if (delta > 0 && !s.canNext) return Result.UNAVAILABLE
        if (delta < 0 && !s.canPrev) return Result.UNAVAILABLE
        return try {
            for (i in 0 until steps) {
                if (delta > 0) c.transportControls.skipToNext() else c.transportControls.skipToPrevious()
            }
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }

    /** Dispara a ação extra de índice [index] anunciada pelo app (aleatório, repetir, gostei...). Mesma ordem de [State.customActions]. */
    fun customAction(index: Int): Result {
        val (c, r) = controller()
        if (c == null) return r
        return try {
            val ca = c.playbackState?.customActions?.getOrNull(index) ?: return Result.UNAVAILABLE
            c.transportControls.sendCustomAction(ca, null)
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }
}
