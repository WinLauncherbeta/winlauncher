package com.example.winlauncher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Música na barra de tarefas (área de trabalho):
 *  - um "chip" à esquerda da barra (capa + nome + ondinhas animadas) que só aparece enquanto toca música;
 *  - ao tocar no chip sobe um painel de vidro (capa, nome, artista, voltar / pausar / avançar) com o fundo
 *    em degradê nas cores da capa. O painel vive no [overlay] e é aberto/fechado pelo MainActivity (showPanel/closeAll).
 *
 * Lê a mídia pelo mesmo acesso às notificações que o launcher já usa (MediaSession).
 */
class TaskbarMusic(
    private val act: MainActivity,
    private val taskbar: FrameLayout,
    overlay: FrameLayout,
    private val anchor: View,
    private val accent: Int,
    private val onChip: () -> Unit
) {

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val listenerCn = ComponentName(act, LauncherNotificationListener::class.java)

    private val defA = Color.parseColor("#4A7396")
    private val defB = Color.parseColor("#26384F")
    private var colA = defA
    private var colB = defB
    private var fg = Color.WHITE
    private var scalePct = 100

    // ------------------------------------------------------------------ chip na barra

    private val chipBg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(withA(colA, 0x66), withA(colB, 0x66)))
    private val chip = LinearLayout(act)
    private val chipCover = ImageView(act)
    private val chipTextCol = LinearLayout(act)
    private val chipTitle = TextView(act)
    private val chipArtist = TextView(act)
    private val wave = WaveView(act)

    // ------------------------------------------------------------------ painel que sobe

    val panel = LinearLayout(act)
    private val panelGlass = CoverGlass(panel, d, 18)
    private val panelCover = ImageView(act)
    private val panelTitle = TextView(act)
    private val panelArtist = TextView(act)
    private val btnPrev = ImageView(act)
    private val btnPlay = ImageView(act)
    private val btnNext = ImageView(act)
    private val playBg = GradientDrawable()

    private var fits = true
    private var compact = false
    private var wantShown = false
    private var chipShown = false

    init {
        // ---- chip
        chipBg.cornerRadius = dp(10).toFloat()
        chipBg.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        val mask = GradientDrawable()
        mask.cornerRadius = dp(10).toFloat()
        mask.setColor(Color.WHITE)
        chip.background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), chipBg, mask)
        chip.orientation = LinearLayout.HORIZONTAL
        chip.gravity = Gravity.CENTER_VERTICAL
        chip.setPadding(dp(5), 0, dp(10), 0)
        chip.isClickable = true
        chip.tag = CursorController.NOHAND
        chip.visibility = View.GONE
        chip.alpha = 0f
        chip.setOnClickListener { onChip() }

        roundCover(chipCover, 7)
        chip.addView(chipCover, LinearLayout.LayoutParams(dp(28), dp(28)))

        chipTextCol.orientation = LinearLayout.VERTICAL
        chipTextCol.gravity = Gravity.CENTER_VERTICAL
        chipTitle.setTextColor(fg)
        chipTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        chipTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        chipTitle.isSingleLine = true
        chipTitle.ellipsize = TextUtils.TruncateAt.END
        chipArtist.setTextColor(withA(fg, 0xB8))
        chipArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        chipArtist.isSingleLine = true
        chipArtist.ellipsize = TextUtils.TruncateAt.END
        chipTextCol.addView(chipTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        chipTextCol.addView(chipArtist, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        chip.addView(chipTextCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })

        chip.addView(wave, LinearLayout.LayoutParams(dp(24), dp(20)).apply { leftMargin = dp(8) })

        taskbar.addView(chip, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36), Gravity.START or Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(10)
        })

        // ---- painel
        panel.orientation = LinearLayout.HORIZONTAL
        panel.gravity = Gravity.CENTER_VERTICAL
        panel.background = panelGlass
        panel.setPadding(dp(12), dp(12), dp(14), dp(12))
        panel.visibility = View.GONE
        panel.isClickable = true
        panel.tag = CursorController.NOHAND
        panel.elevation = dp(10).toFloat()
        val r = dp(18).toFloat()
        panel.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, r)
                o.alpha = 0.55f
            }
        }
        panel.clipToOutline = true
        val sw = act.resources.displayMetrics.widthPixels
        overlay.addView(panel, FrameLayout.LayoutParams(min(dp(390), sw - dp(16)), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            bottomMargin = dp(8)
            leftMargin = dp(8)
        })

        roundCover(panelCover, 14)
        panel.addView(panelCover, LinearLayout.LayoutParams(dp(64), dp(64)))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.isClickable = true
        col.setOnClickListener {
            // toque no nome/capa: abre o app de música
            try {
                ctrl?.sessionActivity?.send()
            } catch (e: Exception) {
            }
        }
        panelTitle.setTextColor(Color.WHITE)
        panelTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        panelTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        panelTitle.isSingleLine = true
        panelTitle.ellipsize = TextUtils.TruncateAt.END
        panelTitle.gravity = Gravity.CENTER
        panelTitle.setShadowLayer(dp(2).toFloat(), 0f, 1f, 0x40000000)
        panelArtist.setTextColor(Color.parseColor("#CCFFFFFF"))
        panelArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        panelArtist.isSingleLine = true
        panelArtist.ellipsize = TextUtils.TruncateAt.END
        panelArtist.gravity = Gravity.CENTER
        col.addView(panelTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(panelArtist, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        panel.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dp(10)
            rightMargin = dp(6)
        })

        for ((iv, res) in listOf(btnPrev to R.drawable.ic_media_prev, btnNext to R.drawable.ic_media_next)) {
            iv.setImageResource(res)
            iv.setColorFilter(Color.WHITE)
            iv.setPadding(dp(9), dp(9), dp(9), dp(9))
            iv.background = glassItemBg(d, 14)
            iv.isClickable = true
        }
        playBg.cornerRadius = dp(14).toFloat()
        playBg.setColor(accent)
        btnPlay.setImageResource(R.drawable.ic_media_play)
        btnPlay.setColorFilter(Color.parseColor("#0B1B2B"))
        btnPlay.setPadding(dp(14), dp(14), dp(14), dp(14))
        btnPlay.background = RippleDrawable(
            ColorStateList.valueOf(Color.parseColor("#33000000")), playBg,
            GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.WHITE)
            }
        )
        btnPlay.isClickable = true

        panel.addView(btnPrev, LinearLayout.LayoutParams(dp(40), dp(40)))
        panel.addView(btnPlay, LinearLayout.LayoutParams(dp(54), dp(54)).apply {
            leftMargin = dp(6)
            rightMargin = dp(6)
        })
        panel.addView(btnNext, LinearLayout.LayoutParams(dp(40), dp(40)))

        btnPrev.setOnClickListener { try { ctrl?.transportControls?.skipToPrevious() } catch (e: Exception) {} }
        btnNext.setOnClickListener { try { ctrl?.transportControls?.skipToNext() } catch (e: Exception) {} }
        btnPlay.setOnClickListener {
            val c = ctrl ?: return@setOnClickListener
            try {
                if (isPlaying(c)) c.transportControls.pause() else c.transportControls.play()
            } catch (e: Exception) {
            }
        }

        panelGlass.setColors(colA, colB)

        val fit = View.OnLayoutChangeListener { _, l, _, r2, _, ol, _, or2, _ ->
            if (r2 - l != or2 - ol || l != ol) updateFit()
        }
        anchor.addOnLayoutChangeListener(fit)
        taskbar.addOnLayoutChangeListener(fit)
    }

    private fun withA(c: Int, a: Int): Int = (a shl 24) or (c and 0xFFFFFF)

    private fun roundCover(iv: ImageView, radiusDp: Int) {
        val rr = dp(radiusDp).toFloat()
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, rr)
            }
        }
        iv.clipToOutline = true
    }

    // ------------------------------------------------------------------ API para o MainActivity

    val isPanelOpen: Boolean get() = panel.visibility == View.VISIBLE

    /** Cor/tamanho da barra de tarefas mudaram: ajusta o chip. */
    fun applyMetrics(rowH: Int, fgColor: Int, scale: Int) {
        fg = fgColor
        scalePct = scale
        val h = (rowH - dp(10)).coerceIn(dp(28), dp(42))
        val lp = chip.layoutParams as FrameLayout.LayoutParams
        lp.height = h
        chip.layoutParams = lp
        val cs = h - dp(8)
        val clp = chipCover.layoutParams
        clp.width = cs
        clp.height = cs
        chipCover.layoutParams = clp
        chipTitle.setTextColor(fg)
        chipArtist.setTextColor(withA(fg, 0xB8))
        chipTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f * scale / 100f)
        chipArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f * scale / 100f)
        wave.barColor = fg
        wave.invalidate()
        updateFit()
    }

    /** Posiciona o painel (embaixo ou em cima, conforme a barra de tarefas). */
    fun place(top: Boolean, edge: Int) {
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.gravity = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.START
        lp.topMargin = if (top) edge else 0
        lp.bottomMargin = if (top) 0 else edge
        lp.leftMargin = edge
        panel.layoutParams = lp
    }

    /** Reavalia a permissão de acesso às notificações (o usuário pode ter acabado de permitir). */
    fun refreshAccess() {
        if (!listening) start() else refreshSessions()
    }

    // ------------------------------------------------------------------ espaço disponível na barra

    private fun updateFit() {
        if (anchor.width <= 0) return
        val avail = anchor.left - dp(10) - dp(14)
        val wasFits = fits
        val wasCompact = compact
        when {
            avail >= dp(150) -> {
                fits = true
                compact = false
            }
            avail >= dp(84) -> {
                fits = true
                compact = true
            }
            else -> {
                fits = false
                compact = false
            }
        }
        chipTextCol.visibility = if (compact) View.GONE else View.VISIBLE
        val lp = chip.layoutParams as FrameLayout.LayoutParams
        val w = if (compact || !fits) ViewGroup.LayoutParams.WRAP_CONTENT else min(dp(230), avail)
        if (lp.width != w) {
            lp.width = w
            chip.layoutParams = lp
        }
        if (wasFits != fits || wasCompact != compact) applyChip()
    }

    private fun applyChip() {
        val show = wantShown && fits
        if (show == chipShown) return
        chipShown = show
        chip.animate().cancel()
        if (show) {
            chip.visibility = View.VISIBLE
            chip.alpha = 0f
            chip.translationX = -dp(14).toFloat()
            chip.animate().alpha(1f).translationX(0f).setDuration(200L).start()
        } else {
            chip.animate().alpha(0f).translationX(-dp(14).toFloat()).setDuration(160L).withEndAction {
                if (!chipShown) chip.visibility = View.GONE
            }.start()
        }
    }

    // ------------------------------------------------------------------ sessões de mídia

    private var msm: MediaSessionManager? = null
    private var ctrl: MediaController? = null
    private var listening = false

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list ?: emptyList())
    }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = render()
        override fun onPlaybackStateChanged(state: PlaybackState?) = render()
        override fun onSessionDestroyed() = refreshSessions()
    }

    private fun isPlaying(c: MediaController): Boolean {
        val s = c.playbackState?.state
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    fun start() {
        if (listening) return
        val m = act.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, listenerCn, ui)
            listening = true
            bind(m.getActiveSessions(listenerCn))
        } catch (e: SecurityException) {
            // sem acesso às notificações: o chip simplesmente não aparece
            listening = false
        } catch (e: Exception) {
            listening = false
        }
    }

    fun stop() {
        if (listening) {
            listening = false
            try {
                msm?.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
            }
        }
        try {
            ctrl?.unregisterCallback(cb)
        } catch (e: Exception) {
        }
        ctrl = null
        ui.removeCallbacks(hideRun)
    }

    private fun refreshSessions() {
        val m = msm ?: return
        try {
            bind(m.getActiveSessions(listenerCn))
        } catch (e: Exception) {
            bind(emptyList())
        }
    }

    private fun bind(list: List<MediaController>) {
        val best = list.firstOrNull { isPlaying(it) }
            ?: list.firstOrNull { it.metadata != null }
            ?: list.firstOrNull()
        if (best?.sessionToken != ctrl?.sessionToken) {
            try {
                ctrl?.unregisterCallback(cb)
            } catch (e: Exception) {
            }
            ctrl = best
            try {
                best?.registerCallback(cb, ui)
            } catch (e: Exception) {
            }
        }
        render()
    }

    // ------------------------------------------------------------------ aparecer só enquanto toca

    private val hideRun = Runnable {
        if (isPanelOpen) {
            // o painel está aberto (ex.: música pausada de propósito): espera ele fechar
            scheduleHide(5000L)
        } else {
            wantShown = false
            applyChip()
        }
    }

    private fun scheduleHide(ms: Long) {
        ui.removeCallbacks(hideRun)
        ui.postDelayed(hideRun, ms)
    }

    private fun updateShown(playing: Boolean, hasSession: Boolean) {
        wave.playing = playing
        if (playing) {
            ui.removeCallbacks(hideRun)
            wantShown = true
            applyChip()
        } else if (wantShown) {
            // pausada: a barra continua um tempo para dar para retomar; sem sessão, some rápido
            scheduleHide(if (hasSession) 20000L else 1500L)
        }
    }

    // ------------------------------------------------------------------ conteúdo

    private var artBmp: Bitmap? = null
    private var artKey = "\u0000"
    private var uriTried = ""

    private fun currentKey(): String {
        val c = ctrl ?: return ""
        val md = c.metadata ?: return ""
        return (md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" +
            (md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "") + "|" + c.packageName
    }

    private fun render() {
        val c = ctrl
        val md = c?.metadata
        val playing = c != null && isPlaying(c)
        btnPlay.setImageResource(if (playing) R.drawable.ic_media_pause else R.drawable.ic_media_play)
        updateShown(playing, c != null)

        if (c == null || md == null) {
            if (artKey != "") setNoArt()
            return
        }
        val t = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: "Sem título"
        val a = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        chipTitle.text = t
        panelTitle.text = t
        chipArtist.text = a
        chipArtist.visibility = if (a.isBlank()) View.GONE else View.VISIBLE
        panelArtist.text = a
        panelArtist.visibility = if (a.isBlank()) View.GONE else View.VISIBLE

        val key = currentKey()
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) {
            if (bmp !== artBmp) setArt(bmp, key)
        } else {
            if (key != artKey) setNoArt(key)
            val uri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            if (uri != null && uri != uriTried) {
                uriTried = uri
                loadUri(uri, key)
            }
        }
    }

    private fun setArt(b: Bitmap, key: String) {
        artKey = key
        artBmp = b
        for (iv in listOf(chipCover, panelCover)) {
            iv.setPadding(0, 0, 0, 0)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.clearColorFilter()
            iv.background = null
            iv.setImageBitmap(b)
        }
        animatePalette(AlbumPalette.pick(b))
    }

    private fun setNoArt(key: String = "") {
        artKey = key
        artBmp = null
        uriTried = ""
        for (iv in listOf(chipCover, panelCover)) {
            val pad = if (iv === chipCover) dp(5) else dp(18)
            iv.setImageResource(R.drawable.ic_music_note)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(pad, pad, pad, pad)
            iv.setColorFilter(Color.WHITE)
            iv.background = GradientDrawable().apply { setColor(0x26FFFFFF) }
        }
        animatePalette(intArrayOf(defA, defB))
    }

    private fun loadUri(uri: String, key: String) {
        Thread {
            val b = try {
                decodeUri(uri)
            } catch (t: Throwable) {
                null
            }
            if (b != null) ui.post { if (currentKey() == key) setArt(b, key) }
        }.start()
    }

    private fun decodeUri(uri: String): Bitmap? {
        val bytes: ByteArray = if (uri.startsWith("http://") || uri.startsWith("https://")) {
            val con = URL(uri).openConnection() as HttpURLConnection
            con.connectTimeout = 4000
            con.readTimeout = 4000
            try {
                con.inputStream.use { it.readBytes() }
            } finally {
                con.disconnect()
            }
        } else {
            act.contentResolver.openInputStream(Uri.parse(uri))?.use { it.readBytes() } ?: return null
        }
        if (bytes.size > 8 * 1024 * 1024) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 256 && o.outHeight / (sample * 2) >= 256) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    // ------------------------------------------------------------------ cores (degradê da capa)

    private var colorAnim: ValueAnimator? = null

    private fun animatePalette(p: IntArray) {
        colorAnim?.cancel()
        val f1 = colA
        val f2 = colB
        val ev = ArgbEvaluator()
        colorAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450L
            addUpdateListener {
                val f = it.animatedFraction
                colA = ev.evaluate(f, f1, p[0]) as Int
                colB = ev.evaluate(f, f2, p[1]) as Int
                panelGlass.setColors(colA, colB)
                chipBg.setColors(intArrayOf(withA(colA, 0x77), withA(colB, 0x77)))
                chipBg.invalidateSelf()
            }
            start()
        }
    }

    // por último de propósito: todas as propriedades acima já foram inicializadas
    init {
        setNoArt()
    }

    // ------------------------------------------------------------------ ondinhas animadas

    /** Barrinhas que dançam enquanto toca (efeito visual; não lê o áudio de verdade). */
    private class WaveView(ctx: Context) : View(ctx) {
        var barColor = Color.WHITE
        var playing = false
            set(v) {
                field = v
                if (v) postInvalidateOnAnimation()
            }

        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
        private val n = 9
        private val level = FloatArray(n) { 0.15f }

        override fun onDraw(c: Canvas) {
            val t = SystemClock.uptimeMillis() / 1000f
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val step = w / n
            p.strokeWidth = step * 0.5f
            p.color = barColor
            var moving = false
            for (i in 0 until n) {
                val target = if (playing) {
                    0.22f + 0.78f * abs(sin(t * (2.1f + i * 0.37f) + i * 1.7f) * cos(t * (1.3f + i * 0.21f) + i))
                } else {
                    0.14f
                }
                level[i] += (target - level[i]) * 0.25f
                if (abs(target - level[i]) > 0.01f) moving = true
                val bh = max(h * level[i], p.strokeWidth)
                val x = step * (i + 0.5f)
                c.drawLine(x, (h - bh) / 2f, x, (h + bh) / 2f, p)
            }
            if (playing || moving) postInvalidateOnAnimation()
        }
    }
}

/**
 * Fundo do painel de música: papel de parede borrado (o mesmo dos outros painéis) + degradê com as cores da capa
 * + película fosca (granulado e brilho no topo) + borda fina.
 */
internal class CoverGlass(private val host: View, private val density: Float, private val radiusDp: Int) : Drawable() {
    private var c1 = Color.parseColor("#4A7396")
    private var c2 = Color.parseColor("#26384F")

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val tint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frost = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14FFFFFF") }
    private val grain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = BitmapShader(noise(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density
        color = Color.parseColor("#55FFFFFF")
    }
    private val clip = Path()
    private val rect = RectF()
    private val dst = Rect()
    private val loc = IntArray(2)
    private val rloc = IntArray(2)
    private val radius get() = radiusDp * density

    private fun noise(): Bitmap {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val rnd = java.util.Random(7)
        val px = IntArray(s * s) { (rnd.nextInt(16) shl 24) or 0xFFFFFF }
        bmp.setPixels(px, 0, s, 0, 0, s, s)
        return bmp
    }

    fun setColors(a: Int, b: Int) {
        c1 = a
        c2 = b
        rebuild()
        invalidateSelf()
    }

    private fun withAlpha(c: Int, a: Int) = (a shl 24) or (c and 0xFFFFFF)

    private fun rebuild() {
        val b = bounds
        if (b.isEmpty) return
        val a = if (Glass.bitmap != null) 0xB4 else 0xE4
        tint.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            withAlpha(c1, a), withAlpha(c2, a), Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
            Color.parseColor("#33FFFFFF"), Color.parseColor("#05FFFFFF"), Shader.TileMode.CLAMP
        )
    }

    override fun onBoundsChange(b: Rect) {
        rebuild()
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        val save = canvas.save()
        canvas.clipPath(clip)
        val bmp = Glass.bitmap
        val r = Glass.root
        if (bmp != null && r != null && !bmp.isRecycled && r.width > 0 && r.height > 0) {
            host.getLocationOnScreen(loc)
            r.getLocationOnScreen(rloc)
            val s2 = canvas.save()
            canvas.translate((rloc[0] - loc[0]).toFloat(), (rloc[1] - loc[1]).toFloat())
            dst.set(0, 0, r.width, r.height)
            canvas.drawBitmap(bmp, null, dst, bmpPaint)
            canvas.restoreToCount(s2)
        }
        canvas.drawPaint(tint)
        canvas.drawPaint(frost)
        canvas.drawPaint(grain)
        canvas.drawPaint(sheen)
        canvas.restoreToCount(save)
        val inset = border.strokeWidth / 2f
        rect.inset(inset, inset)
        canvas.drawRoundRect(rect, radius - inset, radius - inset, border)
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, radius)
        outline.alpha = 0.55f
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
