package com.example.winlauncher

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Protocolo entre a WinLauncher (servidor) e o WinLauncher Remote (cliente).
 *
 * Etapa 3A: somente definição das mensagens, codificação/decodificação, validação e limites.
 * Nada aqui abre socket, usa rede ou mexe no MediaSessionHub (só lê os tipos dele para mapear resultados).
 *
 * Etapa 3B, Parte 2 (acréscimos, sem alterar nada que já existia): mensagem "art" (capa em blocos de até 9000 bytes,
 * com id, índice, total, tamanho e SHA-256 da imagem inteira), campo "artId" na mensagem "state" e [ArtAssembler]
 * (remonta e valida a capa; é o que o app Remote usará).
 *
 * Formato: uma mensagem JSON por linha (UTF-8, terminada em '\n'), sempre com "v" (versão) e "t" (tipo).
 * O JSON gerado pelo org.json nunca contém quebra de linha crua, então '\n' é um delimitador seguro.
 *
 * Esboço do fluxo (será implementado nas próximas etapas):
 *  - Pareamento (TLS já ativo, cliente ainda sem confiar no certificado):
 *      Remote -> hello, pair_request(deviceId, deviceName, clientNonce)
 *      Server -> pair_challenge(serverNonce, serverName)
 *      Os dois celulares calculam o mesmo número (RemoteAuth.pairingCode) e o usuário compara;
 *      toca "Permitir" na WinLauncher -> Server -> pair_ok(token)   (ou error PAIRING_DENIED)
 *  - Uso normal: Remote -> hello, auth(deviceId, token) -> Server: auth_ok; depois command/state.
 */
object RemoteProtocol {

    const val VERSION = 1

    /** Porta padrão (reservada; o servidor real é da Etapa 3B). */
    const val DEFAULT_PORT = 48655

    /** Tipo de serviço NSD (reservado para a divulgação na rede, etapa seguinte). */
    const val SERVICE_TYPE = "_winlauncher._tcp."

    /** Tamanho máximo de uma mensagem (bytes, sem contar o '\n'). */
    const val MAX_FRAME_BYTES = 16 * 1024

    const val MAX_NAME = 64
    const val MAX_TEXT = 256
    const val NONCE_BYTES = 16
    const val TOKEN_BYTES = 32

    /** Capa: bytes de imagem por bloco (antes do base64), máximo de blocos e de bytes da imagem inteira. */
    const val ART_CHUNK_BYTES = 9000
    const val MAX_ART_CHUNKS = 24
    const val MAX_ART_BYTES = 192 * 1024
    const val ART_ID_LEN = 16
    private const val ART_DATA_MAX = (ART_CHUNK_BYTES * 4 + 2) / 3

    private const val B64_FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private val ID_REGEX = Regex("^[A-Za-z0-9_-]{8,64}$")
    private val ART_ID_REGEX = Regex("^[0-9a-f]{16}$")
    private val SHA_REGEX = Regex("^[0-9a-f]{64}$")

    // ------------------------------------------------------------------ tipos

    object Types {
        const val HELLO = "hello"
        const val PAIR_REQUEST = "pair_request"
        const val PAIR_CHALLENGE = "pair_challenge"
        const val PAIR_OK = "pair_ok"
        const val AUTH = "auth"
        const val AUTH_OK = "auth_ok"
        const val COMMAND = "command"
        const val COMMAND_RESULT = "command_result"
        const val STATE = "state"
        const val ART = "art"

        /** Fila de reprodução (servidor -> cliente), só para quem anunciou a capacidade "queue": ver o bloco "Fila" mais abaixo. */
        const val QUEUE = "queue"

        /** Capas individuais da fila (cap "queue_art"): "qart" (servidor -> cliente, blocos) e "art_req" (cliente -> servidor, pedido). */
        const val QUEUE_ART = "qart"
        const val ART_REQ = "art_req"
        const val ERROR = "error"
        const val PING = "ping"
        const val PONG = "pong"

        /** Mouse Flow (Etapa 1): ver o bloco "Mouse Flow" mais abaixo. */
        const val MOUSE_SUB = "mouse_sub"
        const val MOUSE_STATE = "mouse_state"
        const val MOUSE = "mouse"

        /** Resultados da busca com lista (servidor -> cliente), só em resposta a "search_list": ver "Busca" mais abaixo. */
        const val SEARCH_RESULTS = "sres"
    }

    enum class Command(val wire: String) {
        PLAY_PAUSE("play_pause"),
        NEXT("next"),
        PREVIOUS("previous"),

        /** Fila sincronizada: toca o item da fila cujo queueId vai no campo "queueId" do comando (o mesmo id da mensagem "queue"). */
        PLAY_QUEUE_ITEM("play_queue_item"),

        /** Busca: pede ao app de música que toque o melhor resultado de [Message.CommandMsg.query] (campo "query"). Só com a capacidade "search". */
        SEARCH("search"),

        /** Busca com lista: o WinLauncher procura [Message.CommandMsg.query] no app de música e responde com "sres". Só com "search_list". */
        SEARCH_LIST("search_list"),

        /** Toca o resultado de índice [Message.CommandMsg.queueId] da última lista "sres" enviada. */
        PLAY_RESULT("play_result"),

        /** Ir para um ponto da música: [Message.CommandMsg.positionMs] (campo "positionMs"). Só com a capacidade "seek". */
        SEEK("seek"),

        /** Volume de música do aparelho do WinLauncher, de 0 a 100 %: [Message.CommandMsg.volume] (campo "volume"). Só com "volume". */
        VOLUME("volume");

        companion object {
            fun fromWire(s: String?): Command? = values().firstOrNull { it.wire == s }
        }
    }

    enum class ErrorCode(val wire: String) {
        BAD_REQUEST("bad_request"),
        UNSUPPORTED_VERSION("unsupported_version"),
        TOO_LARGE("too_large"),
        NOT_PAIRED("not_paired"),
        PAIRING_DENIED("pairing_denied"),
        PAIRING_BUSY("pairing_busy"),
        RATE_LIMITED("rate_limited"),
        NO_ACCESS("no_access"),
        NO_SESSION("no_session"),
        UNAVAILABLE("unavailable"),
        INTERNAL("internal");

        companion object {
            fun fromWire(s: String?): ErrorCode = values().firstOrNull { it.wire == s } ?: INTERNAL
        }
    }

    class ProtocolException(val code: ErrorCode, message: String) : Exception(message)

    sealed class Message(val type: String) {
        /**
         * role: "remote" ou "server". [caps] (Mouse Flow): capacidades opcionais; vazio = não vai no JSON, igual ao hello de antes.
         */
        data class Hello(
            val version: Int,
            val deviceId: String,
            val deviceName: String,
            val role: String,
            val caps: List<String> = emptyList()
        ) : Message(Types.HELLO)

        data class PairRequest(val deviceId: String, val deviceName: String, val clientNonce: String) :
            Message(Types.PAIR_REQUEST)

        data class PairChallenge(val serverNonce: String, val serverName: String) : Message(Types.PAIR_CHALLENGE)

        data class PairOk(val token: String, val serverName: String) : Message(Types.PAIR_OK)

        data class Auth(val deviceId: String, val token: String) : Message(Types.AUTH)

        data class AuthOk(val serverName: String, val version: Int) : Message(Types.AUTH_OK)

        /** [queueId] só existe (e é obrigatório) em [Command.PLAY_QUEUE_ITEM]; nos demais comandos é sempre null. */
        data class CommandMsg(
            val id: Long,
            val command: Command,
            val queueId: Long? = null,
            val query: String? = null,
            val positionMs: Long? = null,
            val volume: Int? = null
        ) : Message(Types.COMMAND)

        data class CommandResult(val id: Long, val ok: Boolean, val error: ErrorCode?) : Message(Types.COMMAND_RESULT)

        data class StateMsg(
            val access: Boolean,
            val hasSession: Boolean,
            val playing: Boolean,
            val title: String,
            val artist: String,
            val album: String,
            val appLabel: String,
            val canPlayPause: Boolean,
            val canNext: Boolean,
            val canPrev: Boolean,
            val durationMs: Long,
            val positionMs: Long,
            /** Id da capa já enviada em blocos ("art"); "" = sem capa (ou ainda sendo preparada). */
            val artId: String = "",
            /** Volume de música do aparelho, 0 a 100 %; -1 = não informado (campo opcional "vol"). */
            val vol: Int = -1
        ) : Message(Types.STATE)

        /**
         * Um bloco da capa (JPEG). [sha256] é o hash (hex minúsculo) da imagem INTEIRA, [artId] são os 16 primeiros
         * caracteres dele, [size] o tamanho da imagem inteira e [data] os bytes do bloco em base64 URL-safe sem padding.
         * Todos os blocos, menos o último, têm exatamente [ART_CHUNK_BYTES] bytes.
         */
        data class ArtChunk(
            val artId: String,
            val index: Int,
            val total: Int,
            val size: Int,
            val sha256: String,
            val data: String
        ) : Message(Types.ART)

        /**
         * Fila de reprodução REAL da sessão de mídia controlada (servidor -> cliente). Sempre é um retrato completo e
         * substitui o anterior. [items] é uma JANELA da fila (no máximo [MAX_QUEUE_ITEMS] itens e o que couber em um quadro):
         * [from] = posição do primeiro item da janela dentro da fila inteira, [total] = tamanho da fila inteira,
         * [cur] = posição do item que está tocando na fila inteira (-1 = o app não informou / não foi possível identificar).
         * [status] diz por que não há itens quando a lista vem vazia (ex.: o app não publica fila pela MediaSession).
         */
        data class QueueMsg(
            val status: QueueCode,
            val title: String,
            val cur: Int,
            val total: Int,
            val from: Int,
            val items: List<QueueRow>
        ) : Message(Types.QUEUE)

        /**
         * Capa de UMA faixa da fila (servidor -> cliente), só para quem anunciou "queue_art" e só depois de pedir com [ArtReq].
         * Mesmo formato de [ArtChunk], mas tipo próprio ("qart"): NUNCA é confundida com a capa do player (tipo "art").
         */
        data class QueueArtChunk(
            val artId: String,
            val index: Int,
            val total: Int,
            val size: Int,
            val sha256: String,
            val data: String
        ) : Message(Types.QUEUE_ART)

        /** Pedido de capas da fila (cliente -> servidor): só as que NÃO estão no cache do aparelho. */
        data class ArtReq(val ids: List<String>) : Message(Types.ART_REQ)

        /** Mouse Flow, cliente -> servidor: liga/desliga o recebimento do fluxo de mouse (só se o servidor anunciou "mouse"). */
        data class MouseSub(val on: Boolean) : Message(Types.MOUSE_SUB)

        /** Mouse Flow, servidor -> cliente: a captura do mouse no WinLauncher ficou ativa/inativa. */
        data class MouseState(val active: Boolean) : Message(Types.MOUSE_STATE)

        /** Mouse Flow, servidor -> cliente: movimento/rolagem acumulados e estado atual dos botões (ver o bloco "Mouse Flow"). */
        data class MouseEvent(
            val seq: Long,
            val dx: Int,
            val dy: Int,
            val wx: Int,
            val wy: Int,
            val buttons: Int
        ) : Message(Types.MOUSE)

        /**
         * Resultados da busca com lista (servidor -> cliente). Retrato completo: cada mensagem substitui a anterior (as capas
         * vão chegando e o servidor reenvia a lista com os "art" prontos). [query] repete o texto buscado.
         */
        data class SearchResults(val status: SearchCode, val query: String, val items: List<SearchRow>) : Message(Types.SEARCH_RESULTS)

        data class ErrorMsg(val code: ErrorCode, val message: String, val id: Long?) : Message(Types.ERROR)

        object Ping : Message(Types.PING)

        object Pong : Message(Types.PONG)
    }

    // ------------------------------------------------------------------ ligação com o MediaSessionHub

    /** Resultado de um comando do Hub -> código de erro do protocolo (null = sucesso). */
    fun errorFor(r: MediaSessionHub.Result): ErrorCode? = when (r) {
        MediaSessionHub.Result.OK -> null
        MediaSessionHub.Result.NO_ACCESS -> ErrorCode.NO_ACCESS
        MediaSessionHub.Result.NO_SESSION -> ErrorCode.NO_SESSION
        MediaSessionHub.Result.UNAVAILABLE -> ErrorCode.UNAVAILABLE
        MediaSessionHub.Result.ERROR -> ErrorCode.INTERNAL
    }

    /** Estado do Hub -> mensagem "state" (sem a capa: ela terá um canal próprio em etapa futura). */
    fun stateOf(s: MediaSessionHub.State): Message.StateMsg = Message.StateMsg(
        access = s.access,
        hasSession = s.hasSession,
        playing = s.playing,
        title = clip(s.title, MAX_TEXT),
        artist = clip(s.artist, MAX_TEXT),
        album = clip(s.album, MAX_TEXT),
        appLabel = clip(s.appLabel, MAX_NAME),
        canPlayPause = s.canPlayPause,
        canNext = s.canNext,
        canPrev = s.canPrev,
        durationMs = s.durationMs.coerceAtLeast(0L),
        positionMs = s.positionMs.coerceAtLeast(0L)
    )

    fun clip(s: String, max: Int): String = if (s.length <= max) s else s.substring(0, max)

    // ------------------------------------------------------------------ base64 (URL-safe, sem padding)

    fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, B64_FLAGS)

    /** Decodifica e só aceita a forma canônica (a mesma que b64() produziria). */
    fun unb64(s: String): ByteArray? {
        return try {
            val b = Base64.decode(s, B64_FLAGS)
            if (b64(b) == s) b else null
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    // ------------------------------------------------------------------ codificação

    fun toJson(m: Message): JSONObject {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("t", m.type)
        when (m) {
            is Message.Hello -> {
                o.put("version", m.version)
                o.put("deviceId", m.deviceId)
                o.put("deviceName", m.deviceName)
                o.put("role", m.role)
                if (m.caps.isNotEmpty()) o.put("caps", JSONArray(m.caps))
            }
            is Message.PairRequest -> {
                o.put("deviceId", m.deviceId)
                o.put("deviceName", m.deviceName)
                o.put("clientNonce", m.clientNonce)
            }
            is Message.PairChallenge -> {
                o.put("serverNonce", m.serverNonce)
                o.put("serverName", m.serverName)
            }
            is Message.PairOk -> {
                o.put("token", m.token)
                o.put("serverName", m.serverName)
            }
            is Message.Auth -> {
                o.put("deviceId", m.deviceId)
                o.put("token", m.token)
            }
            is Message.AuthOk -> {
                o.put("serverName", m.serverName)
                o.put("version", m.version)
            }
            is Message.CommandMsg -> {
                o.put("id", m.id)
                o.put("cmd", m.command.wire)
                if (m.queueId != null) o.put("queueId", m.queueId)
                if (m.query != null) o.put("query", m.query)
                if (m.positionMs != null) o.put("positionMs", m.positionMs)
                if (m.volume != null) o.put("volume", m.volume)
            }
            is Message.CommandResult -> {
                o.put("id", m.id)
                o.put("ok", m.ok)
                if (m.error != null) o.put("error", m.error.wire)
            }
            is Message.StateMsg -> {
                o.put("access", m.access)
                o.put("hasSession", m.hasSession)
                o.put("playing", m.playing)
                o.put("title", m.title)
                o.put("artist", m.artist)
                o.put("album", m.album)
                o.put("appLabel", m.appLabel)
                o.put("canPlayPause", m.canPlayPause)
                o.put("canNext", m.canNext)
                o.put("canPrev", m.canPrev)
                o.put("durationMs", m.durationMs)
                o.put("positionMs", m.positionMs)
                o.put("artId", m.artId)
                if (m.vol >= 0) o.put("vol", m.vol)
            }
            is Message.ArtChunk -> {
                o.put("id", m.artId)
                o.put("index", m.index)
                o.put("total", m.total)
                o.put("size", m.size)
                o.put("sha", m.sha256)
                o.put("data", m.data)
            }
            is Message.QueueMsg -> {
                o.put("st", m.status.wire)
                o.put("title", m.title)
                o.put("cur", m.cur)
                o.put("total", m.total)
                o.put("from", m.from)
                val arr = JSONArray()
                for (r in m.items) arr.put(queueRowJson(r))
                o.put("items", arr)
            }
            is Message.QueueArtChunk -> {
                o.put("id", m.artId)
                o.put("index", m.index)
                o.put("total", m.total)
                o.put("size", m.size)
                o.put("sha", m.sha256)
                o.put("data", m.data)
            }
            is Message.ArtReq -> {
                val arr = JSONArray()
                m.ids.take(MAX_ART_REQ).forEach { arr.put(it) }
                o.put("ids", arr)
            }
            is Message.ErrorMsg -> {
                o.put("code", m.code.wire)
                o.put("message", m.message)
                if (m.id != null) o.put("id", m.id)
            }
            is Message.MouseSub -> {
                o.put("on", m.on)
            }
            is Message.MouseState -> {
                o.put("active", m.active)
            }
            is Message.MouseEvent -> {
                o.put("seq", m.seq.coerceIn(0L, MOUSE_MAX_SEQ))
                o.put("dx", clampMouseDelta(m.dx))
                o.put("dy", clampMouseDelta(m.dy))
                o.put("wx", clampMouseScroll(m.wx))
                o.put("wy", clampMouseScroll(m.wy))
                o.put("b", m.buttons and MOUSE_BTN_MASK)
            }
            is Message.SearchResults -> {
                o.put("st", m.status.wire)
                o.put("q", m.query)
                val arr = JSONArray()
                for (r in m.items) {
                    val it = JSONObject()
                    it.put("i", r.index)
                    it.put("title", r.title)
                    it.put("sub", r.subtitle)
                    if (r.artId.isNotEmpty()) it.put("art", r.artId)
                    arr.put(it)
                }
                o.put("items", arr)
            }
            Message.Ping -> {
            }
            Message.Pong -> {
            }
        }
        return o
    }

    /** Uma mensagem como texto JSON (uma linha, sem '\n'). */
    fun encode(m: Message): String = toJson(m).toString()

    /** Mensagem pronta para enviar: JSON + '\n'. Lança se passar do limite. */
    fun encodeFrame(m: Message): ByteArray {
        val bytes = (encode(m) + "\n").toByteArray(Charsets.UTF_8)
        if (bytes.size - 1 > MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
        return bytes
    }

    // ------------------------------------------------------------------ decodificação (com validação)

    private fun bad(msg: String) = ProtocolException(ErrorCode.BAD_REQUEST, msg)

    private fun JSONObject.reqStr(key: String, max: Int): String {
        val v = opt(key)
        if (v !is String || v.isEmpty() || v.length > max) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.optStr(key: String, max: Int): String {
        if (!has(key)) return ""
        val v = opt(key)
        if (v !is String || v.length > max) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqLong(key: String): Long {
        val v = opt(key)
        if (v !is Number) throw bad("campo '$key' inválido")
        return v.toLong()
    }

    private fun JSONObject.reqBool(key: String): Boolean {
        val v = opt(key)
        if (v !is Boolean) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqId(key: String): String {
        val v = reqStr(key, 64)
        if (!ID_REGEX.matches(v)) throw bad("campo '$key' fora do formato")
        return v
    }

    private fun JSONObject.reqNonce(key: String): String {
        val v = reqStr(key, 64)
        val b = unb64(v)
        if (b == null || b.size != NONCE_BYTES) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqToken(key: String): String {
        val v = reqStr(key, 96)
        val b = unb64(v)
        if (b == null || b.size != TOKEN_BYTES) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqIntIn(key: String, min: Int, max: Int): Int {
        val v = opt(key)
        if (v !is Number) throw bad("campo '$key' inválido")
        val l = v.toLong()
        if (l < min || l > max) throw bad("campo '$key' fora do limite")
        return l.toInt()
    }

    private fun JSONObject.optArtId(key: String): String {
        val v = optStr(key, ART_ID_LEN)
        if (v.isNotEmpty() && !ART_ID_REGEX.matches(v)) throw bad("campo '$key' fora do formato")
        return v
    }

    /** Campos de um bloco de capa (iguais em "art" e "qart"), com toda a validação. */
    private fun decodeArtFields(o: JSONObject): Message.QueueArtChunk {
        val id = o.reqStr("id", ART_ID_LEN)
        if (!ART_ID_REGEX.matches(id)) throw bad("campo 'id' fora do formato")
        val total = o.reqIntIn("total", 1, MAX_ART_CHUNKS)
        val index = o.reqIntIn("index", 0, total - 1)
        val size = o.reqIntIn("size", 1, MAX_ART_BYTES)
        val sha = o.reqStr("sha", 64)
        if (!SHA_REGEX.matches(sha) || !sha.startsWith(id)) throw bad("campo 'sha' inválido")
        val data = o.reqStr("data", ART_DATA_MAX)
        if ((size + ART_CHUNK_BYTES - 1) / ART_CHUNK_BYTES != total) throw bad("total de blocos inconsistente")
        val raw = unb64(data) ?: throw bad("campo 'data' inválido")
        val expected = if (index < total - 1) ART_CHUNK_BYTES else size - (total - 1) * ART_CHUNK_BYTES
        if (raw.size != expected) throw bad("tamanho do bloco inconsistente")
        return Message.QueueArtChunk(id, index, total, size, sha, data)
    }

    private fun decodeArtReq(o: JSONObject): Message.ArtReq {
        val a = o.opt("ids")
        if (a !is JSONArray || a.length() == 0 || a.length() > MAX_ART_REQ) throw bad("campo 'ids' inválido")
        val out = ArrayList<String>(a.length())
        for (i in 0 until a.length()) {
            val v = a.opt(i)
            if (v !is String || !ART_ID_REGEX.matches(v)) throw bad("campo 'ids' inválido")
            if (!out.contains(v)) out.add(v)
        }
        return Message.ArtReq(out)
    }

    fun decode(line: String): Message {
        if (line.length > MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
        val o = try {
            JSONObject(line)
        } catch (e: Exception) {
            throw bad("JSON inválido")
        }
        val v = o.opt("v")
        if (v !is Number || v.toInt() != VERSION) {
            throw ProtocolException(ErrorCode.UNSUPPORTED_VERSION, "versão de protocolo não suportada")
        }
        return when (o.opt("t")) {
            Types.HELLO -> Message.Hello(
                version = o.reqLong("version").toInt(),
                deviceId = o.reqId("deviceId"),
                deviceName = o.reqStr("deviceName", MAX_NAME),
                role = o.reqStr("role", 16),
                caps = o.optCaps("caps")
            )
            Types.PAIR_REQUEST -> Message.PairRequest(
                deviceId = o.reqId("deviceId"),
                deviceName = o.reqStr("deviceName", MAX_NAME),
                clientNonce = o.reqNonce("clientNonce")
            )
            Types.PAIR_CHALLENGE -> Message.PairChallenge(
                serverNonce = o.reqNonce("serverNonce"),
                serverName = o.reqStr("serverName", MAX_NAME)
            )
            Types.PAIR_OK -> Message.PairOk(
                token = o.reqToken("token"),
                serverName = o.reqStr("serverName", MAX_NAME)
            )
            Types.AUTH -> Message.Auth(
                deviceId = o.reqId("deviceId"),
                token = o.reqToken("token")
            )
            Types.AUTH_OK -> Message.AuthOk(
                serverName = o.reqStr("serverName", MAX_NAME),
                version = o.reqLong("version").toInt()
            )
            Types.COMMAND -> decodeCommand(o)
            Types.COMMAND_RESULT -> Message.CommandResult(
                id = o.reqLong("id"),
                ok = o.reqBool("ok"),
                error = if (o.has("error")) ErrorCode.fromWire(o.optString("error", "")) else null
            )
            Types.STATE -> Message.StateMsg(
                access = o.reqBool("access"),
                hasSession = o.reqBool("hasSession"),
                playing = o.reqBool("playing"),
                title = o.optStr("title", MAX_TEXT),
                artist = o.optStr("artist", MAX_TEXT),
                album = o.optStr("album", MAX_TEXT),
                appLabel = o.optStr("appLabel", MAX_NAME),
                canPlayPause = o.reqBool("canPlayPause"),
                canNext = o.reqBool("canNext"),
                canPrev = o.reqBool("canPrev"),
                durationMs = o.reqLong("durationMs"),
                positionMs = o.reqLong("positionMs"),
                artId = o.optArtId("artId"),
                vol = if (o.has("vol")) o.reqIntIn("vol", -1, 100) else -1
            )
            Types.ART -> {
                val c = decodeArtFields(o)
                Message.ArtChunk(c.artId, c.index, c.total, c.size, c.sha256, c.data)
            }
            Types.QUEUE_ART -> decodeArtFields(o)
            Types.ART_REQ -> decodeArtReq(o)
            Types.QUEUE -> decodeQueue(o)
            Types.SEARCH_RESULTS -> decodeSearchResults(o)
            Types.ERROR -> Message.ErrorMsg(
                code = ErrorCode.fromWire(o.optString("code", "")),
                message = o.optStr("message", MAX_TEXT),
                id = if (o.has("id")) o.reqLong("id") else null
            )
            Types.MOUSE_SUB -> Message.MouseSub(on = o.reqBool("on"))
            Types.MOUSE_STATE -> Message.MouseState(active = o.reqBool("active"))
            Types.MOUSE -> Message.MouseEvent(
                seq = o.reqWhole("seq", 0L, MOUSE_MAX_SEQ),
                dx = o.reqWhole("dx", -MOUSE_MAX_DELTA.toLong(), MOUSE_MAX_DELTA.toLong()).toInt(),
                dy = o.reqWhole("dy", -MOUSE_MAX_DELTA.toLong(), MOUSE_MAX_DELTA.toLong()).toInt(),
                wx = o.reqWhole("wx", -MOUSE_MAX_SCROLL.toLong(), MOUSE_MAX_SCROLL.toLong()).toInt(),
                wy = o.reqWhole("wy", -MOUSE_MAX_SCROLL.toLong(), MOUSE_MAX_SCROLL.toLong()).toInt(),
                buttons = o.reqWhole("b", 0L, MOUSE_BTN_MASK.toLong()).toInt()
            )
            Types.PING -> Message.Ping
            Types.PONG -> Message.Pong
            else -> throw bad("tipo de mensagem desconhecido")
        }
    }

    // ------------------------------------------------------------------ capa em blocos

    fun sha256Hex(b: ByteArray): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(b)
        val sb = StringBuilder(d.size * 2)
        for (x in d) {
            sb.append(Character.forDigit((x.toInt() shr 4) and 0xf, 16))
            sb.append(Character.forDigit(x.toInt() and 0xf, 16))
        }
        return sb.toString()
    }

    /** Id da capa = primeiros 16 caracteres do SHA-256 (hex) da imagem. */
    fun artIdOf(sha256Hex: String): String = sha256Hex.substring(0, ART_ID_LEN)

    /** Divide a imagem em blocos prontos para enviar. Lança TOO_LARGE se vazia ou maior que [MAX_ART_BYTES]. */
    fun artChunks(bytes: ByteArray): List<Message.ArtChunk> {
        if (bytes.isEmpty() || bytes.size > MAX_ART_BYTES) {
            throw ProtocolException(ErrorCode.TOO_LARGE, "capa fora do limite")
        }
        val sha = sha256Hex(bytes)
        val id = artIdOf(sha)
        val total = (bytes.size + ART_CHUNK_BYTES - 1) / ART_CHUNK_BYTES
        val out = ArrayList<Message.ArtChunk>(total)
        for (i in 0 until total) {
            val from = i * ART_CHUNK_BYTES
            val to = minOf(bytes.size, from + ART_CHUNK_BYTES)
            out.add(Message.ArtChunk(id, i, total, bytes.size, sha, b64(bytes.copyOfRange(from, to))))
        }
        return out
    }

    /** Igual a [artChunks], mas com o tipo "qart" (capa de faixa da fila). */
    fun queueArtChunks(bytes: ByteArray): List<Message.QueueArtChunk> =
        artChunks(bytes).map { Message.QueueArtChunk(it.artId, it.index, it.total, it.size, it.sha256, it.data) }

    /** Remonta a capa a partir dos blocos (em ordem) e confere tamanho e SHA-256. Uma instância por conexão. */
    class ArtAssembler {
        private var id = ""
        private var total = 0
        private var size = 0
        private var sha = ""
        private var next = 0
        private val buf = ByteArrayOutputStream()

        private fun reset() {
            id = ""
            total = 0
            size = 0
            sha = ""
            next = 0
            buf.reset()
        }

        /** Devolve a imagem quando o último bloco chega e confere; null enquanto faltam blocos. Lança ProtocolException se algo não bate. */
        fun add(m: Message.QueueArtChunk): ByteArray? =
            add(Message.ArtChunk(m.artId, m.index, m.total, m.size, m.sha256, m.data))

        fun add(m: Message.ArtChunk): ByteArray? {
            if (m.index == 0) {
                reset()
                id = m.artId
                total = m.total
                size = m.size
                sha = m.sha256
            } else if (m.artId != id || m.total != total || m.size != size || m.sha256 != sha || m.index != next) {
                reset()
                throw ProtocolException(ErrorCode.BAD_REQUEST, "bloco de capa fora de ordem")
            }
            val raw = unb64(m.data)
            if (raw == null) {
                reset()
                throw ProtocolException(ErrorCode.BAD_REQUEST, "bloco de capa inválido")
            }
            buf.write(raw)
            next = m.index + 1
            if (next < total) return null
            val all = buf.toByteArray()
            val wantSize = size
            val wantSha = sha
            reset()
            if (all.size != wantSize || sha256Hex(all) != wantSha) {
                throw ProtocolException(ErrorCode.BAD_REQUEST, "capa corrompida (tamanho ou hash não conferem)")
            }
            return all
        }
    }

    // ================================================================== Fila de reprodução (queue)
    //
    // Acréscimo ADITIVO ao protocolo v1 (VERSION continua 1), no mesmo molde do Mouse Flow.
    //  - Capacidade "queue" ([CAP_QUEUE]). O servidor a anuncia no hello dele ([SERVER_CAPS]); o cliente que quer receber a
    //    fila a anuncia no hello dele (caps). O servidor SÓ envia "queue" a cliente que anunciou "queue": um Remote antigo
    //    recusa tipos desconhecidos e encerraria a conexão.
    //  - queue (servidor -> cliente): {"st","title","cur","total","from","items":[{"id","title","sub"}]}
    //      st: "ok" (há itens), "empty" (o app publicou uma fila vazia), "not_published" (há sessão, mas o app NÃO publica fila
    //          pela MediaSession), "no_session", "no_access" (sem acesso às notificações), "unknown" (valor futuro)
    //      id: queueId do item (MediaSession.QueueItem.getQueueId); title/sub: título e subtítulo do MediaDescription do item
    //      A mensagem é sempre um retrato COMPLETO e substitui a anterior (mensagens antigas ainda não enviadas são descartadas).
    //  - Os itens são uma janela de até [MAX_QUEUE_ITEMS] itens começando [QUEUE_PRE_ITEMS] antes do item atual; quando a fila
    //    é maior, [total] e [from] dizem o que a janela mostra. Nada é inventado: itens e posições vêm do app de música.

    const val CAP_QUEUE = "queue"

    /**
     * Capacidade "queue_select": o servidor entende o comando play_queue_item (tocar um item da fila pelo queueId).
     * Um WinLauncher sem ela devolveria erro de comando desconhecido, então o Remote só envia o comando se ela vier no hello.
     */
    const val CAP_QUEUE_SELECT = "queue_select"

    /**
     * O servidor sabe mandar a capa individual de cada faixa da fila: itens de "queue" ganham o campo opcional "art"
     * (id da capa, 16 hex) e as imagens vão em "qart" SOMENTE depois de pedidas com "art_req". Só vale se os DOIS lados
     * anunciarem "queue_art". O servidor nem manda o campo "art" a quem não anunciou a capacidade.
     */
    const val CAP_QUEUE_ART = "queue_art"

    /** Máximo de ids por pedido "art_req". */
    const val MAX_ART_REQ = 8

    /** Capacidades que o servidor anuncia no hello. */

    /**
     * Capacidade "search": o servidor entende o comando "search" (campo "query") e pede ao app de música que busque e toque
     * o melhor resultado (MediaController.transportControls.playFromSearch). Só o SERVIDOR anuncia; sem ela o Remote NÃO
     * envia "search" (um programa antigo recusa comando desconhecido e derruba a conexão).
     */
    const val CAP_SEARCH = "search"

    /** Tamanho máximo do texto de busca (caracteres). */
    const val MAX_SEARCH = 80

    // ================================================================== Busca com lista (search_list / sres / play_result)
    //
    // Acréscimo ADITIVO ao protocolo v1. Só o SERVIDOR anuncia "search_list"; o Remote só envia "search_list" e "play_result"
    // a quem anunciou, e o servidor só manda "sres" em resposta a um "search_list". As capas dos resultados usam o MESMO canal
    // da fila ("queue_art": campo "art" + art_req -> qart), então o Remote precisa ter anunciado "queue_art".
    //  - search_list (cliente -> servidor): {"cmd":"search_list","query":"..."}  -> command_result ok = busca iniciada
    //  - sres (servidor -> cliente): {"st","q","items":[{"i","title","sub","art"?}]}
    //  - play_result (cliente -> servidor): {"cmd":"play_result","queueId":<i>} toca o item i da última lista

    const val CAP_SEARCH_LIST = "search_list"

    /**
     * Capacidade "seek": o servidor entende o comando "seek" (ir para um ponto da música, em "positionMs"). Só o SERVIDOR
     * anuncia; sem ela o Remote NÃO envia "seek".
     */
    const val CAP_SEEK = "seek"

    /**
     * Capacidade "volume": o servidor entende o comando "volume" (0 a 100 %, volume de música do aparelho do WinLauncher) e
     * informa o volume atual no campo opcional "vol" do estado. Só o SERVIDOR anuncia.
     */
    const val CAP_VOLUME = "volume"

    /** Maior posição aceita em "seek" (24 h em ms). */
    const val MAX_SEEK_MS = 86_400_000L

    /** Capacidades que o servidor anuncia no hello. (Declarada DEPOIS de todas as CAP_*: a ordem importa na inicialização.) */
    val SERVER_CAPS: List<String> = listOf(CAP_QUEUE, CAP_QUEUE_SELECT, CAP_QUEUE_ART, CAP_SEARCH, CAP_SEARCH_LIST, CAP_SEEK, CAP_VOLUME)
    const val MAX_RESULTS = 10
    const val RESULT_TITLE_MAX = 100
    const val RESULT_SUB_MAX = 80

    enum class SearchCode(val wire: String) {
        OK("ok"),
        EMPTY("empty"),

        /** O app de música não permite listar resultados (o Remote cai na busca simples). */
        UNAVAILABLE("unavailable"),
        ERROR("error");

        companion object {
            fun fromWire(s: String?): SearchCode = values().firstOrNull { it.wire == s } ?: ERROR
        }
    }

    data class SearchRow(val index: Int, val title: String, val subtitle: String, val artId: String = "")

    private fun decodeSearchResults(o: JSONObject): Message.SearchResults {
        val code = SearchCode.fromWire(o.reqStr("st", 16))
        val q = o.optStr("q", MAX_SEARCH)
        val arr = o.opt("items")
        if (arr !is JSONArray || arr.length() > MAX_RESULTS) throw bad("campo 'items' inválido")
        val rows = ArrayList<SearchRow>(arr.length())
        for (i in 0 until arr.length()) {
            val item = arr.opt(i)
            if (item !is JSONObject) throw bad("resultado inválido")
            rows.add(
                SearchRow(
                    index = item.reqIntIn("i", 0, MAX_RESULTS - 1),
                    title = item.optStr("title", RESULT_TITLE_MAX),
                    subtitle = item.optStr("sub", RESULT_SUB_MAX),
                    artId = (item.opt("art") as? String)?.takeIf { ART_ID_REGEX.matches(it) } ?: ""
                )
            )
        }
        return Message.SearchResults(code, q, rows)
    }

    const val MAX_QUEUE_ITEMS = 50
    const val MAX_QUEUE_TOTAL = 5000
    const val QUEUE_PRE_ITEMS = 5
    const val QUEUE_TITLE_MAX = 100
    const val QUEUE_SUB_MAX = 80
    const val QUEUE_NAME_MAX = 100

    /** Sobra mantida no quadro da fila (o quadro inteiro nunca passa de [MAX_FRAME_BYTES]). */
    private const val QUEUE_FRAME_MARGIN = 512

    enum class QueueCode(val wire: String) {
        OK("ok"),
        EMPTY("empty"),
        NOT_PUBLISHED("not_published"),
        NO_SESSION("no_session"),
        NO_ACCESS("no_access"),
        UNKNOWN("unknown");

        companion object {
            /** Valor que este programa não conhece vira UNKNOWN (um servidor mais novo pode ter acrescentado outros). */
            fun fromWire(s: String?): QueueCode = values().firstOrNull { it.wire == s } ?: UNKNOWN
        }
    }

    /** Um item da fila no protocolo. */
    data class QueueRow(val id: Long, val title: String, val subtitle: String, val artId: String = "")

    private fun queueRowJson(r: QueueRow): JSONObject {
        val o = JSONObject()
        o.put("id", r.id)
        o.put("title", r.title)
        o.put("sub", r.subtitle)
        if (r.artId.isNotEmpty()) o.put("art", r.artId)
        return o
    }

    /**
     * Comando de mídia. "play_queue_item" EXIGE "queueId" (inteiro); nos outros comandos um "queueId" eventual é ignorado
     * (o Remote só o envia quando existe, mas um cliente mais novo pode mandá-lo à toa).
     */
    private fun decodeCommand(o: JSONObject): Message.CommandMsg {
        val id = o.reqLong("id")
        val cmd = Command.fromWire(o.optString("cmd", "")) ?: throw bad("comando desconhecido")
        if (cmd == Command.SEARCH) {
            // "search" EXIGE "query" (texto de 1 a MAX_SEARCH caracteres, sem ser só espaços)
            val q = o.reqStr("query", MAX_SEARCH)
            if (q.isBlank()) throw bad("search com query vazia")
            return Message.CommandMsg(id, cmd, null, q)
        }
        if (cmd == Command.SEARCH_LIST) {
            val q = o.reqStr("query", MAX_SEARCH)
            if (q.isBlank()) throw bad("search_list com query vazia")
            return Message.CommandMsg(id, cmd, null, q)
        }
        if (cmd == Command.SEEK) {
            if (!o.has("positionMs")) throw bad("seek sem positionMs")
            val p = o.reqLong("positionMs")
            if (p < 0L || p > MAX_SEEK_MS) throw bad("seek com positionMs fora do limite")
            return Message.CommandMsg(id, cmd, positionMs = p)
        }
        if (cmd == Command.VOLUME) {
            if (!o.has("volume")) throw bad("volume sem o campo volume")
            return Message.CommandMsg(id, cmd, volume = o.reqIntIn("volume", 0, 100))
        }
        if (cmd != Command.PLAY_QUEUE_ITEM && cmd != Command.PLAY_RESULT) return Message.CommandMsg(id, cmd)
        if (!o.has("queueId")) throw bad("${cmd.wire} sem queueId")
        return Message.CommandMsg(id, cmd, o.reqLong("queueId"))
    }

    private fun decodeQueue(o: JSONObject): Message.QueueMsg {
        val code = QueueCode.fromWire(o.reqStr("st", 16))
        val title = o.optStr("title", QUEUE_NAME_MAX)
        val total = o.reqIntIn("total", 0, MAX_QUEUE_TOTAL)
        val from = o.reqIntIn("from", 0, MAX_QUEUE_TOTAL)
        val cur = o.reqIntIn("cur", -1, MAX_QUEUE_TOTAL - 1)
        val arr = o.opt("items")
        if (arr !is JSONArray || arr.length() > MAX_QUEUE_ITEMS) throw bad("campo 'items' inválido")
        val rows = ArrayList<QueueRow>(arr.length())
        for (i in 0 until arr.length()) {
            val item = arr.opt(i)
            if (item !is JSONObject) throw bad("item da fila inválido")
            rows.add(
                QueueRow(
                    id = item.reqWhole("id", Long.MIN_VALUE, Long.MAX_VALUE),
                    title = item.optStr("title", QUEUE_TITLE_MAX),
                    subtitle = item.optStr("sub", QUEUE_SUB_MAX),
                    // tolerante: "art" ausente ou fora do formato = sem capa (nunca derruba a fila nem a conexão)
                    artId = (item.opt("art") as? String)?.takeIf { ART_ID_REGEX.matches(it) } ?: ""
                )
            )
        }
        if (from + rows.size > total) throw bad("janela da fila passa do total")
        if (cur >= total) throw bad("item atual fora da fila")
        if (code == QueueCode.OK) {
            if (rows.isEmpty()) throw bad("fila 'ok' sem itens")
        } else if (rows.isNotEmpty() || total != 0 || from != 0 || cur != -1) {
            throw bad("fila sem itens com dados")
        }
        return Message.QueueMsg(code, title, cur, total, from, rows)
    }

    /**
     * Fila do Hub -> mensagem "queue". A janela começa [QUEUE_PRE_ITEMS] itens antes do atual (ou no começo, se o atual é
     * desconhecido) e é preenchida para a frente até [MAX_QUEUE_ITEMS] itens ou até o limite de bytes do quadro; se sobrar espaço
     * (fim da fila), completa para trás. Assim o item atual sempre entra na janela, mesmo com textos longos. Nunca acrescenta
     * item que o app não publicou.
     */
    fun queueOf(q: MediaSessionHub.Queue, artOf: (Long) -> String = { "" }): Message.QueueMsg {
        val code = when (q.status) {
            MediaSessionHub.QueueStatus.OK -> QueueCode.OK
            MediaSessionHub.QueueStatus.EMPTY -> QueueCode.EMPTY
            MediaSessionHub.QueueStatus.NOT_PUBLISHED -> QueueCode.NOT_PUBLISHED
            MediaSessionHub.QueueStatus.NO_SESSION -> QueueCode.NO_SESSION
            MediaSessionHub.QueueStatus.NO_ACCESS -> QueueCode.NO_ACCESS
        }
        val all = q.items
        if (code != QueueCode.OK || all.isEmpty()) {
            val c = if (code == QueueCode.OK) QueueCode.EMPTY else code
            return Message.QueueMsg(c, "", -1, 0, 0, emptyList())
        }
        val total = minOf(all.size, MAX_QUEUE_TOTAL)
        val cur = if (q.activeIndex in 0 until total) q.activeIndex else -1
        val title = clip(q.title, QUEUE_NAME_MAX)
        val start = if (cur >= 0) maxOf(0, cur - QUEUE_PRE_ITEMS) else 0
        // o cabeçalho (sem itens) mede o quadro; "from" só muda se completarmos para trás, e muda poucos dígitos: a margem cobre
        val head = Message.QueueMsg(QueueCode.OK, title, cur, total, 0, emptyList())
        var used = encode(head).toByteArray(Charsets.UTF_8).size + 1
        val budget = MAX_FRAME_BYTES - QUEUE_FRAME_MARGIN

        fun rowAt(i: Int): QueueRow {
            val e = all[i]
            return QueueRow(e.queueId, clip(e.title, QUEUE_TITLE_MAX), clip(e.subtitle, QUEUE_SUB_MAX), artOf(e.queueId))
        }

        fun cost(r: QueueRow): Int = queueRowJson(r).toString().toByteArray(Charsets.UTF_8).size + 1

        val rows = ArrayList<QueueRow>()
        var i = start
        while (i < total && rows.size < MAX_QUEUE_ITEMS) {
            val r = rowAt(i)
            val c = cost(r)
            if (used + c > budget) break
            used += c
            rows.add(r)
            i++
        }
        var from = start
        while (from > 0 && rows.size < MAX_QUEUE_ITEMS) {
            val r = rowAt(from - 1)
            val c = cost(r)
            if (used + c > budget) break
            used += c
            rows.add(0, r)
            from--
        }
        return Message.QueueMsg(QueueCode.OK, title, cur, total, from, rows)
    }

    /** Autoteste da fila: ida e volta, janela, limite de quadro, rejeições e compatibilidade. null = tudo certo. */
    fun selfTestQueue(): String? {
        return try {
            fun fail(msg: String): Nothing = throw IllegalStateException(msg)
            fun rejects(what: String, text: String) {
                try {
                    decode(text)
                } catch (e: ProtocolException) {
                    if (e.code == ErrorCode.BAD_REQUEST) return
                    fail("$what: erro ${e.code.wire} em vez de bad_request")
                }
                fail("$what: deveria ser rejeitado")
            }

            fun entries(n: Int, title: (Int) -> String = { "Faixa $it" }, sub: (Int) -> String = { "Artista $it" }) =
                (0 until n).map { MediaSessionHub.QueueEntry(1000L + it, title(it), sub(it), "mid$it") }

            fun hubQueue(items: List<MediaSessionHub.QueueEntry>, activeIdx: Int, status: MediaSessionHub.QueueStatus = MediaSessionHub.QueueStatus.OK) =
                MediaSessionHub.Queue(status, "pkg.teste", "Mix de teste", if (activeIdx >= 0) 1000L + activeIdx else -1L, activeIdx, items)

            fun check(m: Message.QueueMsg, what: String) {
                val text = encode(m)
                if (text.contains('\n')) fail("$what: quebra de linha no JSON")
                if (decode(text) != m) fail("$what: ida e volta diferente")
                if (encodeFrame(m).size - 1 > MAX_FRAME_BYTES) fail("$what: quadro grande demais")
            }

            // sem itens: um código por motivo
            for (st in MediaSessionHub.QueueStatus.values()) {
                val m = queueOf(hubQueue(emptyList(), -1, st))
                check(m, "fila vazia ${st.name}")
                if (m.items.isNotEmpty() || m.total != 0 || m.cur != -1) fail("fila sem itens com dados (${st.name})")
                val want = when (st) {
                    MediaSessionHub.QueueStatus.OK -> QueueCode.EMPTY
                    MediaSessionHub.QueueStatus.EMPTY -> QueueCode.EMPTY
                    MediaSessionHub.QueueStatus.NOT_PUBLISHED -> QueueCode.NOT_PUBLISHED
                    MediaSessionHub.QueueStatus.NO_SESSION -> QueueCode.NO_SESSION
                    MediaSessionHub.QueueStatus.NO_ACCESS -> QueueCode.NO_ACCESS
                }
                if (m.status != want) fail("código ${m.status.wire} para ${st.name}")
            }
            // a fila vem com itens mas o status não é OK: nenhum item vaza
            if (queueOf(hubQueue(entries(3), 1, MediaSessionHub.QueueStatus.NOT_PUBLISHED)).items.isNotEmpty()) fail("itens vazaram com status não publicado")

            // fila pequena inteira, item atual no meio
            val small = queueOf(hubQueue(entries(7), 3))
            check(small, "fila pequena")
            if (small.items.size != 7 || small.from != 0 || small.total != 7 || small.cur != 3) fail("fila pequena: janela errada")
            if (small.items[3].id != 1003L || small.items[3].title != "Faixa 3" || small.items[3].subtitle != "Artista 3") fail("fila pequena: item errado")
            if (small.title != "Mix de teste") fail("título da fila perdido")

            // fila grande: janela começa 5 antes do atual
            val big = queueOf(hubQueue(entries(300), 120))
            check(big, "fila grande")
            if (big.items.size != MAX_QUEUE_ITEMS || big.from != 120 - QUEUE_PRE_ITEMS || big.total != 300 || big.cur != 120) fail("fila grande: janela errada")
            if (big.items[big.cur - big.from].id != 1120L) fail("fila grande: o item atual não está na posição certa da janela")
            // atual perto do fim: a janela encosta no fim
            val tail = queueOf(hubQueue(entries(300), 298))
            check(tail, "fila no fim")
            if (tail.from != 300 - MAX_QUEUE_ITEMS || tail.items.last().id != 1299L || tail.cur != 298) fail("fila no fim: janela errada")
            // atual desconhecido: começa do começo, cur = -1
            val unk = queueOf(hubQueue(entries(300), -1))
            check(unk, "atual desconhecido")
            if (unk.cur != -1 || unk.from != 0 || unk.items.first().id != 1000L) fail("atual desconhecido: janela errada")

            // textos enormes e caracteres de 3-4 bytes: o quadro nunca passa do limite e ainda inclui o item atual
            val wide = "\uD83C\uDFB5é\"\\/\n\t".repeat(200)
            val heavy = queueOf(hubQueue(entries(300, { wide }, { wide }), 100))
            check(heavy, "textos enormes")
            if (heavy.items.size < QUEUE_PRE_ITEMS + 1 || heavy.items.size > MAX_QUEUE_ITEMS) fail("textos enormes: ${heavy.items.size} itens")
            if (heavy.cur - heavy.from >= heavy.items.size) fail("textos enormes: o item atual ficou fora da janela")
            if (heavy.items.any { it.title.length > QUEUE_TITLE_MAX || it.subtitle.length > QUEUE_SUB_MAX }) fail("texto sem cortar")

            // textos enormes com o item atual no FIM (e perto do começo de uma fila curta): o item atual continua dentro da janela
            val heavyTail = queueOf(hubQueue(entries(300, { wide }, { wide }), 299))
            check(heavyTail, "textos enormes no fim")
            if (heavyTail.items.isEmpty() || heavyTail.items.last().id != 1299L || heavyTail.from + heavyTail.items.size != 300) fail("textos enormes no fim: a janela não termina no último item")
            if (heavyTail.cur - heavyTail.from !in heavyTail.items.indices) fail("textos enormes no fim: o item atual ficou fora da janela")
            val heavyShort = queueOf(hubQueue(entries(50, { wide }, { wide }), 48))
            check(heavyShort, "fila curta com textos enormes")
            if (heavyShort.cur - heavyShort.from !in heavyShort.items.indices) fail("fila curta com textos enormes: o item atual ficou fora da janela")

            // caracteres especiais voltam iguais
            val odd = QueueRow(-7L, "Ação \"1\" \\ / \u00E9\u00F1 \uD83C\uDFB5\n2", "")
            val oddMsg = Message.QueueMsg(QueueCode.OK, "T\u00EDtulo", 0, 1, 0, listOf(odd))
            check(oddMsg, "caracteres especiais")
            val maxId = QueueRow(Long.MAX_VALUE, "x", "y")
            val maxBack = decode(encode(Message.QueueMsg(QueueCode.OK, "", -1, 1, 0, listOf(maxId)))) as Message.QueueMsg
            if (maxBack.items[0] != maxId) fail("id muito grande não voltou igual")

            // rejeições (um quadro inválido derruba a conexão; o lado que envia nunca deve gerar nada disso)
            fun q(st: String = "ok", total: String = "2", from: String = "0", cur: String = "0", items: String = "[{\"id\":1,\"title\":\"a\",\"sub\":\"b\"}]") =
                "{\"v\":1,\"t\":\"queue\",\"st\":\"$st\",\"title\":\"x\",\"cur\":$cur,\"total\":$total,\"from\":$from,\"items\":$items}"
            if (decode(q()) !is Message.QueueMsg) fail("literal válido não decodificou")
            rejects("ok sem itens", q(items = "[]"))
            rejects("itens passam do total", q(total = "1", from = "1"))
            rejects("atual fora da fila", q(cur = "2"))
            rejects("total acima do limite", q(total = "5001"))
            rejects("total negativo", q(total = "-1"))
            rejects("cur abaixo de -1", q(cur = "-2"))
            rejects("id fracionário", q(items = "[{\"id\":1.5,\"title\":\"a\",\"sub\":\"b\"}]"))
            rejects("id texto", q(items = "[{\"id\":\"1\",\"title\":\"a\",\"sub\":\"b\"}]"))
            rejects("item não é objeto", q(items = "[1]"))
            rejects("items não é lista", q(items = "\"x\""))
            rejects("título do item grande demais", q(items = "[{\"id\":1,\"title\":\"" + "a".repeat(QUEUE_TITLE_MAX + 1) + "\",\"sub\":\"b\"}]"))
            rejects("itens demais", q(total = "5000", items = "[" + (0..MAX_QUEUE_ITEMS).joinToString(",") { "{\"id\":$it,\"title\":\"a\",\"sub\":\"b\"}" } + "]"))
            rejects("não publicada com itens", q(st = "not_published"))
            rejects("vazia com total", q(st = "empty", items = "[]", total = "1", cur = "-1"))
            rejects("sem st", "{\"v\":1,\"t\":\"queue\",\"cur\":0,\"total\":0,\"from\":0,\"items\":[]}")
            // código desconhecido (de um servidor mais novo) é aceito, desde que sem itens
            val fut = decode(q(st = "coisa_futura", total = "0", from = "0", cur = "-1", items = "[]"))
            if (fut !is Message.QueueMsg || fut.status != QueueCode.UNKNOWN) fail("código futuro não virou UNKNOWN")

            // capacidade e compatibilidade com o que já existia
            if (!SERVER_CAPS.contains(CAP_QUEUE)) fail("o servidor não anuncia a capacidade")
            if (!SERVER_CAPS.contains(CAP_QUEUE_SELECT)) fail("o servidor não anuncia queue_select")
            if (SERVER_CAPS.size > MAX_CAPS || SERVER_CAPS.any { !CAP_REGEX.matches(it) }) fail("SERVER_CAPS fora do formato do hello")
            val srvHello = Message.Hello(VERSION, "AbCdEfGh12345678", "WinLauncher", "server", SERVER_CAPS)
            if (decode(encode(srvHello)) != srvHello) fail("hello do servidor com SERVER_CAPS: ida e volta diferente")
            val id = "AbCdEfGh12345678"
            val h = Message.Hello(VERSION, id, "Remote", "remote", listOf(CAP_QUEUE, CAP_MOUSE))
            if (decode(encode(h)) != h) fail("hello com caps queue+mouse: ida e volta diferente")
            if (decode("{\"v\":1,\"t\":\"state\",\"access\":true,\"hasSession\":false,\"playing\":false,\"canPlayPause\":false,\"canNext\":false,\"canPrev\":false,\"durationMs\":0,\"positionMs\":0}") !is Message.StateMsg) {
                fail("estado no formato antigo mudou")
            }
            if (Command.values().map { it.wire } != listOf("play_pause", "next", "previous", "play_queue_item", "search", "search_list", "play_result", "seek", "volume")) fail("a lista de comandos de música mudou")
            if (!SERVER_CAPS.contains(CAP_SEARCH)) fail("o servidor não anuncia search")
            if (!SERVER_CAPS.contains(CAP_SEARCH_LIST)) fail("o servidor não anuncia search_list")
            val sl = Message.CommandMsg(12L, Command.SEARCH_LIST, null, "tempo perdido")
            if (decode(encode(sl)) != sl) fail("search_list: ida e volta diferente")
            if (!SERVER_CAPS.contains(CAP_SEEK)) fail("o servidor não anuncia seek")
            if (!SERVER_CAPS.contains(CAP_VOLUME)) fail("o servidor não anuncia volume")
            val sk = Message.CommandMsg(14L, Command.SEEK, positionMs = 91_000L)
            if (decode(encode(sk)) != sk) fail("seek: ida e volta diferente")
            val vl = Message.CommandMsg(15L, Command.VOLUME, volume = 40)
            if (decode(encode(vl)) != vl) fail("volume: ida e volta diferente")
            rejects("seek sem positionMs", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"seek\"}")
            rejects("volume fora do limite", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"volume\",\"volume\":101}")
            val stv = Message.StateMsg(true, true, true, "t", "a", "", "App", true, true, true, 1000L, 10L, "", 55)
            if (decode(encode(stv)) != stv) fail("state com vol: ida e volta diferente")
            val pr = Message.CommandMsg(13L, Command.PLAY_RESULT, 3L)
            if (decode(encode(pr)) != pr) fail("play_result: ida e volta diferente")
            rejects("play_result sem queueId", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"play_result\"}")
            rejects("search_list sem query", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"search_list\"}")
            val sres = Message.SearchResults(SearchCode.OK, "tempo", listOf(SearchRow(0, "Tempo Perdido", "Legião Urbana", "0123456789abcdef"), SearchRow(1, "Sem capa", "")))
            if (decode(encode(sres)) != sres) fail("sres: ida e volta diferente")
            if (decode(encode(Message.SearchResults(SearchCode.UNAVAILABLE, "x", emptyList()))) !is Message.SearchResults) fail("sres vazio")
            rejects("sres com índice fora do limite", "{\"v\":1,\"t\":\"sres\",\"st\":\"ok\",\"q\":\"x\",\"items\":[{\"i\":99,\"title\":\"a\",\"sub\":\"b\"}]}")
            // busca: ida e volta, exige query, corta nada e recusa vazia/só espaços/longa demais
            val sq = Message.CommandMsg(11L, Command.SEARCH, null, "Legião Urbana - Tempo Perdido")
            if (decode(encode(sq)) != sq) fail("search: ida e volta diferente")
            if (encode(Message.CommandMsg(1L, Command.NEXT)).contains("query")) fail("comando comum não deve levar query")
            rejects("search sem query", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"search\"}")
            rejects("search com query vazia", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"search\",\"query\":\"\"}")
            rejects("search com query só de espaços", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"search\",\"query\":\"   \"}")
            rejects("search com query de número", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"search\",\"query\":5}")
            rejects("search com query longa demais", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"search\",\"query\":\"" + "a".repeat(MAX_SEARCH + 1) + "\"}")

            // seleção na fila: play_queue_item leva o queueId (ida e volta, inclusive negativo e Long.MAX_VALUE) e o exige
            for (qid in longArrayOf(0L, 1000L, -7L, Long.MAX_VALUE)) {
                val sel = Message.CommandMsg(9L, Command.PLAY_QUEUE_ITEM, qid)
                if (decode(encode(sel)) != sel) fail("play_queue_item $qid: ida e volta diferente")
            }
            if (encode(Message.CommandMsg(1L, Command.NEXT)).contains("queueId")) fail("comando comum não deve levar queueId")
            if (decode("{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"play_queue_item\",\"queueId\":1042}") != Message.CommandMsg(3L, Command.PLAY_QUEUE_ITEM, 1042L)) {
                fail("literal play_queue_item não decodificou")
            }
            rejects("play_queue_item sem queueId", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"play_queue_item\"}")
            rejects("play_queue_item com queueId de texto", "{\"v\":1,\"t\":\"command\",\"id\":3,\"cmd\":\"play_queue_item\",\"queueId\":\"x\"}")
            // queueId num comando comum é ignorado (o resultado é o comando de sempre)
            if (decode("{\"v\":1,\"t\":\"command\",\"id\":4,\"cmd\":\"next\",\"queueId\":5}") != Message.CommandMsg(4L, Command.NEXT)) fail("queueId em comando comum devia ser ignorado")
            if (VERSION != 1) fail("a versão do protocolo mudou")
            null
        } catch (e: Throwable) {
            e.message ?: e.javaClass.simpleName
        }
    }

    // ================================================================== Mouse Flow (Etapa 1: SÓ o protocolo)
    //
    // Acréscimo ADITIVO e compatível com o protocolo v1 (VERSION continua 1). Nada aqui muda hello/auth/command/state/art.
    //  - hello ganha o campo OPCIONAL "caps" (lista de capacidades). Quem não conhece o campo o ignora, e sem capacidades
    //    o campo nem é enviado (o hello fica igual ao de antes).
    //  - Capacidade "mouse": quem a anuncia entende os tipos abaixo. O servidor só pode mandar "mouse"/"mouse_state" a um
    //    cliente que pediu com "mouse_sub", e o cliente só pode mandar "mouse_sub" a um servidor que anunciou "mouse".
    //    Motivo: um programa antigo recusa tipos desconhecidos e encerra a conexão.
    //  - mouse_sub   (cliente -> servidor): {"on":true|false}
    //  - mouse_state (servidor -> cliente): {"active":true|false}  (captura do mouse ligada/desligada no WinLauncher)
    //  - mouse       (servidor -> cliente): {"seq","dx","dy","wx","wy","b"}
    //      dx, dy: deslocamento acumulado desde o quadro anterior, em pixels do aparelho do WinLauncher (+x direita, +y baixo)
    //      wx, wy: rolagem acumulada em centésimos de "clique" da roda, convenção do Android
    //              (wy > 0 = rolar para cima, wx > 0 = rolar para a direita)
    //      b: estado ATUAL dos botões (bits MOUSE_BTN_*), não o evento
    //      seq: contador crescente por conexão
    // Quem envia deve limitar os valores (clampMouseDelta/clampMouseScroll); toJson também limita, para nunca gerar um
    // quadro que o outro lado recusaria (uma recusa derruba a conexão).

    const val CAP_MOUSE = "mouse"
    const val MAX_CAPS = 8
    const val MAX_CAP_LEN = 16
    const val MOUSE_BTN_LEFT = 1
    const val MOUSE_BTN_RIGHT = 2
    const val MOUSE_BTN_MASK = 3
    const val MOUSE_MAX_DELTA = 32767
    const val MOUSE_MAX_SCROLL = 32767
    const val MOUSE_MAX_SEQ = 9007199254740991L

    private val CAP_REGEX = Regex("^[a-z0-9_]{1,16}$")

    fun clampMouseDelta(v: Int): Int = v.coerceIn(-MOUSE_MAX_DELTA, MOUSE_MAX_DELTA)

    fun clampMouseScroll(v: Int): Int = v.coerceIn(-MOUSE_MAX_SCROLL, MOUSE_MAX_SCROLL)

    /** Lista opcional de capacidades: ausente = vazia; presente tem de ser lista de até [MAX_CAPS] textos no formato certo. */
    private fun JSONObject.optCaps(key: String): List<String> {
        if (!has(key)) return emptyList()
        val a = opt(key)
        if (a !is JSONArray || a.length() > MAX_CAPS) throw bad("campo '$key' inválido")
        val out = ArrayList<String>(a.length())
        for (i in 0 until a.length()) {
            val s = a.opt(i)
            if (s !is String || !CAP_REGEX.matches(s)) throw bad("campo '$key' inválido")
            if (!out.contains(s)) out.add(s)
        }
        return out
    }

    /** Número INTEIRO (rejeita 1.5, 1e2, texto e booleano) dentro de [min, max]. */
    private fun JSONObject.reqWhole(key: String, min: Long, max: Long): Long {
        val v = opt(key)
        if (v !is Int && v !is Long) throw bad("campo '$key' inválido")
        val l = (v as Number).toLong()
        if (l < min || l > max) throw bad("campo '$key' fora do limite")
        return l
    }

    /** Autoteste do Mouse Flow (Etapa 1): ida e volta, rejeições, limites e compatibilidade com quadros no formato antigo. null = tudo certo. */
    fun selfTestMouse(): String? {
        return try {
            fun fail(msg: String): Nothing = throw IllegalStateException(msg)
            fun rejects(code: ErrorCode, what: String, text: String) {
                try {
                    decode(text)
                } catch (e: ProtocolException) {
                    if (e.code == code) return
                    fail("$what: erro ${e.code.wire} em vez de ${code.wire}")
                }
                fail("$what: deveria ser rejeitado")
            }

            val id = "AbCdEfGh12345678"
            val withoutCaps = Message.Hello(VERSION, id, "Sem capacidades", "remote")
            val samples = listOf<Message>(
                Message.Hello(VERSION, id, "Celular da Ana", "remote", listOf(CAP_MOUSE)),
                Message.Hello(VERSION, id, "WinLauncher", "server", listOf(CAP_MOUSE, "future_cap_2")),
                withoutCaps,
                Message.MouseSub(true),
                Message.MouseSub(false),
                Message.MouseState(true),
                Message.MouseState(false),
                Message.MouseEvent(0L, 0, 0, 0, 0, 0),
                Message.MouseEvent(1L, 12, -7, 0, 0, MOUSE_BTN_LEFT),
                Message.MouseEvent(
                    2L, -MOUSE_MAX_DELTA, MOUSE_MAX_DELTA, -MOUSE_MAX_SCROLL, MOUSE_MAX_SCROLL,
                    MOUSE_BTN_LEFT or MOUSE_BTN_RIGHT
                ),
                Message.MouseEvent(MOUSE_MAX_SEQ, 1, 1, 100, -100, MOUSE_BTN_RIGHT)
            )
            for (m in samples) {
                val text = encode(m)
                if (text.contains('\n')) fail("${m.type}: quebra de linha no JSON")
                if (decode(text) != m) fail("${m.type}: ida e volta diferente")
                val frame = encodeFrame(m)
                if (frame.last() != '\n'.code.toByte()) fail("${m.type}: quadro sem '\\n'")
                if (m is Message.MouseEvent && frame.size > 128) fail("mouse: quadro de ${frame.size} bytes (esperado até 128)")
            }
            if (encode(withoutCaps).contains("\"caps\"")) fail("hello sem capacidades não deve ter o campo caps")

            // quadros no formato ANTIGO (sem caps) continuam valendo; o que é de música não mudou
            val oldHello = decode("{\"v\":1,\"t\":\"hello\",\"version\":1,\"deviceId\":\"$id\",\"deviceName\":\"Celular\",\"role\":\"remote\"}")
            if (oldHello != Message.Hello(VERSION, id, "Celular", "remote", emptyList())) fail("hello antigo decodificado diferente")
            if (decode("{\"v\":1,\"t\":\"command\",\"id\":5,\"cmd\":\"play_pause\"}") != Message.CommandMsg(5L, Command.PLAY_PAUSE)) {
                fail("comando de música antigo mudou")
            }
            if (decode("{\"v\":1,\"t\":\"ping\"}") != Message.Ping) fail("ping antigo mudou")
            if (Command.values().map { it.wire } != listOf("play_pause", "next", "previous", "play_queue_item", "search", "search_list", "play_result", "seek", "volume")) fail("a lista de comandos de música mudou")
            if (VERSION != 1) fail("a versão do protocolo mudou")

            // capacidade desconhecida é aceita (compatibilidade futura); repetida vira uma só
            val fut = decode("{\"v\":1,\"t\":\"hello\",\"version\":1,\"deviceId\":\"$id\",\"deviceName\":\"x\",\"role\":\"server\",\"caps\":[\"mouse\",\"coisa_futura\",\"mouse\"]}")
            if (fut !is Message.Hello || fut.caps != listOf("mouse", "coisa_futura")) fail("caps com desconhecida/repetida")

            // caps inválido
            fun helloWith(caps: String) =
                "{\"v\":1,\"t\":\"hello\",\"version\":1,\"deviceId\":\"$id\",\"deviceName\":\"x\",\"role\":\"remote\",\"caps\":$caps}"
            rejects(ErrorCode.BAD_REQUEST, "caps não é lista", helloWith("\"mouse\""))
            rejects(ErrorCode.BAD_REQUEST, "caps com número", helloWith("[1]"))
            rejects(ErrorCode.BAD_REQUEST, "caps com null", helloWith("[null]"))
            rejects(ErrorCode.BAD_REQUEST, "caps com maiúscula", helloWith("[\"Mouse\"]"))
            rejects(ErrorCode.BAD_REQUEST, "caps vazia", helloWith("[\"\"]"))
            rejects(ErrorCode.BAD_REQUEST, "caps longa demais", helloWith("[\"" + "a".repeat(MAX_CAP_LEN + 1) + "\"]"))
            rejects(ErrorCode.BAD_REQUEST, "caps demais", helloWith("[\"a\",\"b\",\"c\",\"d\",\"e\",\"f\",\"g\",\"h\",\"i\"]"))

            // mouse: valores
            fun mouseJson(seq: String, dx: String, dy: String, wx: String, wy: String, b: String) =
                "{\"v\":1,\"t\":\"mouse\",\"seq\":$seq,\"dx\":$dx,\"dy\":$dy,\"wx\":$wx,\"wy\":$wy,\"b\":$b}"
            if (decode(mouseJson("1", "1", "1", "0", "0", "1")) != Message.MouseEvent(1L, 1, 1, 0, 0, 1)) fail("mouse literal diferente")
            rejects(ErrorCode.BAD_REQUEST, "seq negativo", mouseJson("-1", "1", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "seq acima do limite", mouseJson("9007199254740992", "1", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx acima do limite", mouseJson("1", "32768", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx abaixo do limite", mouseJson("1", "-32768", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx fracionário", mouseJson("1", "1.5", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dy em notação científica", mouseJson("1", "1", "1e2", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "dx como texto", mouseJson("1", "\"1\"", "1", "0", "0", "1"))
            rejects(ErrorCode.BAD_REQUEST, "wy acima do limite", mouseJson("1", "1", "1", "0", "40000", "1"))
            rejects(ErrorCode.BAD_REQUEST, "botões com bit desconhecido", mouseJson("1", "1", "1", "0", "0", "4"))
            rejects(ErrorCode.BAD_REQUEST, "botões negativos", mouseJson("1", "1", "1", "0", "0", "-1"))
            rejects(ErrorCode.BAD_REQUEST, "botões booleano", mouseJson("1", "1", "1", "0", "0", "true"))
            rejects(ErrorCode.BAD_REQUEST, "mouse sem campo wy", "{\"v\":1,\"t\":\"mouse\",\"seq\":1,\"dx\":1,\"dy\":1,\"wx\":0,\"b\":1}")
            rejects(ErrorCode.UNSUPPORTED_VERSION, "mouse com versão 2", mouseJson("1", "1", "1", "0", "0", "1").replace("\"v\":1", "\"v\":2"))
            rejects(ErrorCode.BAD_REQUEST, "mouse_sub sem on", "{\"v\":1,\"t\":\"mouse_sub\"}")
            rejects(ErrorCode.BAD_REQUEST, "mouse_sub com on texto", "{\"v\":1,\"t\":\"mouse_sub\",\"on\":\"yes\"}")
            rejects(ErrorCode.BAD_REQUEST, "mouse_sub com on número", "{\"v\":1,\"t\":\"mouse_sub\",\"on\":1}")
            rejects(ErrorCode.BAD_REQUEST, "mouse_state sem active", "{\"v\":1,\"t\":\"mouse_state\"}")
            rejects(ErrorCode.BAD_REQUEST, "tipo mouse desconhecido", "{\"v\":1,\"t\":\"mouse_xyz\"}")

            // toJson limita: nunca gera um quadro que o outro lado recusaria
            val over = decode(encode(Message.MouseEvent(5L, 100000, -100000, 100000, -100000, 7)))
            if (over !is Message.MouseEvent || over.dx != MOUSE_MAX_DELTA || over.dy != -MOUSE_MAX_DELTA ||
                over.wx != MOUSE_MAX_SCROLL || over.wy != -MOUSE_MAX_SCROLL || over.buttons != MOUSE_BTN_MASK
            ) {
                fail("valores fora do limite não foram limitados na codificação")
            }
            val neg = decode(encode(Message.MouseEvent(-9L, 0, 0, 0, 0, 0)))
            if (neg !is Message.MouseEvent || neg.seq != 0L) fail("seq negativo não foi limitado na codificação")

            // fluxo de quadros, na ordem, lidos por readFrame
            val sb = StringBuilder()
            for (i in 0 until 1000) {
                sb.append(encode(Message.MouseEvent(i.toLong(), i % 50 - 25, 3, 0, if (i % 100 == 0) -100 else 0, i % 4))).append('\n')
            }
            val ins = java.io.ByteArrayInputStream(sb.toString().toByteArray(Charsets.UTF_8))
            for (i in 0 until 1000) {
                val line = readFrame(ins) ?: fail("fluxo de mouse acabou no quadro $i")
                val e = decode(line)
                if (e !is Message.MouseEvent || e.seq != i.toLong()) fail("fluxo de mouse fora de ordem no quadro $i")
            }
            if (readFrame(ins) != null) fail("fim do fluxo de mouse deveria devolver null")
            null
        } catch (e: Throwable) {
            (e.message ?: e.javaClass.simpleName)
        }
    }

    /** Autoteste das capas da fila (queue_art, art_req, qart): ida e volta, rejeições, remontagem e compatibilidade. null = tudo certo. */
    fun selfTestQueueArt(): String? {
        return try {
            fun fail(msg: String): Nothing = throw IllegalStateException(msg)
            fun rejects(what: String, text: String) {
                try {
                    decode(text)
                } catch (e: ProtocolException) {
                    if (e.code == ErrorCode.BAD_REQUEST) return
                    fail("$what: erro ${e.code.wire} em vez de bad_request")
                }
                fail("$what: deveria ser rejeitado")
            }

            if (!SERVER_CAPS.contains(CAP_QUEUE_ART)) fail("o servidor não anuncia queue_art")
            if (CAP_QUEUE_ART.length > MAX_CAP_LEN || !CAP_REGEX.matches(CAP_QUEUE_ART)) fail("queue_art fora do formato de capacidade")
            if (Types.QUEUE_ART == Types.ART) fail("qart não pode ter o mesmo tipo de art")

            // imagem de teste de 3 blocos (9000 + 9000 + resto)
            val img = ByteArray(ART_CHUNK_BYTES * 2 + 123) { (it * 31 + 7).toByte() }
            val chunks = queueArtChunks(img)
            if (chunks.size != 3) fail("qart: esperava 3 blocos, vieram ${chunks.size}")
            val asm = ArtAssembler()
            var done: ByteArray? = null
            for (ch in chunks) {
                val text = encode(ch)
                if (text.contains('\n')) fail("qart: quebra de linha no JSON")
                val back = decode(text)
                if (back != ch) fail("qart: ida e volta diferente")
                if (encodeFrame(ch).size - 1 > MAX_FRAME_BYTES) fail("qart: quadro acima do limite")
                done = asm.add(back as Message.QueueArtChunk)
            }
            if (done == null || !done.contentEquals(img)) fail("qart: remontagem diferente da imagem")
            val id = chunks[0].artId
            if (!ART_ID_REGEX.matches(id)) fail("qart: id fora do formato")

            // art_req
            val req = Message.ArtReq(listOf(id, "0123456789abcdef"))
            if (decode(encode(req)) != req) fail("art_req: ida e volta diferente")
            rejects("art_req vazio", "{\"v\":1,\"t\":\"art_req\",\"ids\":[]}")
            rejects("art_req sem ids", "{\"v\":1,\"t\":\"art_req\"}")
            rejects("art_req com id inválido", "{\"v\":1,\"t\":\"art_req\",\"ids\":[\"ZZ\"]}")
            rejects("art_req com número", "{\"v\":1,\"t\":\"art_req\",\"ids\":[1]}")
            val nine = (0 until 9).joinToString(",") { "\"0123456789abcde" + "0123456789abcdef"[it] + "\"" }
            rejects("art_req com mais de $MAX_ART_REQ ids", "{\"v\":1,\"t\":\"art_req\",\"ids\":[$nine]}")
            // ids repetidos viram um só
            val dup = decode("{\"v\":1,\"t\":\"art_req\",\"ids\":[\"$id\",\"$id\"]}")
            if (dup !is Message.ArtReq || dup.ids != listOf(id)) fail("art_req: id repetido não virou um só")

            // qart adulterado
            rejects("qart com índice trocado (tamanho do bloco não confere)", encode(chunks[1]).replace("\"index\":1", "\"index\":2"))
            rejects("qart com índice fora do total", encode(chunks[0]).replace("\"total\":3", "\"total\":2"))
            val asm2 = ArtAssembler()
            asm2.add(chunks[0])
            try {
                asm2.add(chunks[2])
                fail("qart fora de ordem deveria ser recusado")
            } catch (e: ProtocolException) {
            }

            // "queue": item com e sem capa; formato antigo; art inválido é ignorado; tamanho do quadro
            val withArt = Message.QueueMsg(
                QueueCode.OK, "T", 1, 3, 0,
                listOf(QueueRow(1L, "A", "x", id), QueueRow(2L, "B", "y"), QueueRow(3L, "C", "z", "0123456789abcdef"))
            )
            if (decode(encode(withArt)) != withArt) fail("queue com art: ida e volta diferente")
            if (encode(withArt).split("\"art\"").size != 3) fail("queue: campo art só nos itens com capa")
            val old = decode("{\"v\":1,\"t\":\"queue\",\"st\":\"ok\",\"title\":\"\",\"cur\":0,\"total\":1,\"from\":0,\"items\":[{\"id\":5,\"title\":\"A\",\"sub\":\"B\"}]}")
            if (old !is Message.QueueMsg || old.items[0].artId != "") fail("queue no formato antigo (sem art) mudou")
            val junk = decode("{\"v\":1,\"t\":\"queue\",\"st\":\"ok\",\"title\":\"\",\"cur\":0,\"total\":1,\"from\":0,\"items\":[{\"id\":5,\"title\":\"A\",\"sub\":\"B\",\"art\":\"nao-e-id\"}]}")
            if (junk !is Message.QueueMsg || junk.items[0].artId != "") fail("art inválido deveria ser ignorado")
            // fila cheia de capas cabe no quadro e a janela continua com o item atual
            val entries = (0 until 300).map { MediaSessionHub.QueueEntry(1000L + it, "Faixa $it", "Artista $it", "mid$it") }
            val hq = MediaSessionHub.Queue(MediaSessionHub.QueueStatus.OK, "pkg.teste", "Mix", 1100L, 100, entries)
            val big = queueOf(hq) { "0123456789abcdef" }
            if (encodeFrame(big).size - 1 > MAX_FRAME_BYTES) fail("queue com capas passou do limite de quadro")
            if (big.cur !in big.from until big.from + big.items.size) fail("queue com capas: item atual fora da janela")
            if (big.items.any { it.artId != "0123456789abcdef" }) fail("queue: artOf não foi aplicado")
            if (queueOf(hq).items.any { it.artId.isNotEmpty() }) fail("queue sem artOf não deveria ter capas")
            null
        } catch (e: Throwable) {
            (e.message ?: e.javaClass.simpleName)
        }
    }

    // ------------------------------------------------------------------ leitura de uma linha

    /**
     * Lê uma mensagem (até '\n') do fluxo, no máximo MAX_FRAME_BYTES. Devolve null se o fluxo terminou
     * limpo (nenhum byte pendente). Use um BufferedInputStream por cima do socket (a leitura é byte a byte).
     */
    fun readFrame(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        while (true) {
            val b = input.read()
            if (b < 0) {
                if (buf.size() == 0) return null
                throw bad("conexão encerrada no meio de uma mensagem")
            }
            if (b == '\n'.code) return buf.toString("UTF-8")
            if (buf.size() >= MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
            buf.write(b)
        }
    }

    // ------------------------------------------------------------------ autoteste

    private fun expectFail(code: ErrorCode, what: String, block: () -> Unit) {
        try {
            block()
        } catch (e: ProtocolException) {
            if (e.code == code) return
            throw IllegalStateException("$what: erro ${e.code.wire} em vez de ${code.wire}")
        }
        throw IllegalStateException("$what: deveria ser rejeitado")
    }

    /** Testa codificação, decodificação, validações e leitura de linhas. null = tudo certo; senão, o motivo. */
    fun selfTest(): String? {
        return try {
            val id = "AbCdEfGh12345678"
            val nonceA = b64(ByteArray(NONCE_BYTES) { 0x22 })
            val nonceB = b64(ByteArray(NONCE_BYTES) { 0x33 })
            val token = b64(ByteArray(TOKEN_BYTES) { 0x44 })
            val samples = listOf<Message>(
                Message.Hello(VERSION, id, "Celular da Ana", "remote"),
                Message.PairRequest(id, "Celular da Ana", nonceA),
                Message.PairChallenge(nonceB, "WinLauncher"),
                Message.PairOk(token, "WinLauncher"),
                Message.Auth(id, token),
                Message.AuthOk("WinLauncher", VERSION),
                Message.CommandMsg(7L, Command.NEXT),
                Message.CommandResult(7L, true, null),
                Message.CommandResult(8L, false, ErrorCode.UNAVAILABLE),
                Message.StateMsg(
                    true, true, true, "Título \"com aspas\" e acentuação ãéç", "Artista\nem duas linhas", "Álbum",
                    "YouTube Music", true, true, false, 215000L, 12345L, "0123456789abcdef"
                ),
                Message.StateMsg(false, false, false, "", "", "", "", false, false, false, 0L, 0L),
                Message.ErrorMsg(ErrorCode.NOT_PAIRED, "não pareado", 9L),
                Message.ErrorMsg(ErrorCode.INTERNAL, "erro", null),
                Message.Ping,
                Message.Pong
            )
            for (m in samples) {
                val text = encode(m)
                if (text.contains('\n')) throw IllegalStateException("${m.type}: quebra de linha no JSON")
                val back = decode(text)
                if (back != m) throw IllegalStateException("${m.type}: ida e volta diferente")
                val frame = encodeFrame(m)
                if (frame.last() != '\n'.code.toByte()) throw IllegalStateException("${m.type}: quadro sem '\\n'")
            }

            // rejeições
            expectFail(ErrorCode.BAD_REQUEST, "JSON quebrado") { decode("{nao e json") }
            expectFail(ErrorCode.UNSUPPORTED_VERSION, "versão errada") { decode("{\"v\":99,\"t\":\"ping\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "tipo desconhecido") { decode("{\"v\":1,\"t\":\"xyz\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "comando desconhecido") { decode("{\"v\":1,\"t\":\"command\",\"id\":1,\"cmd\":\"format\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "nonce curto") {
                decode("{\"v\":1,\"t\":\"pair_request\",\"deviceId\":\"$id\",\"deviceName\":\"x\",\"clientNonce\":\"AAAA\"}")
            }
            expectFail(ErrorCode.BAD_REQUEST, "id fora do formato") {
                decode("{\"v\":1,\"t\":\"auth\",\"deviceId\":\"a b\",\"token\":\"$token\"}")
            }
            expectFail(ErrorCode.TOO_LARGE, "mensagem enorme") { decode("x".repeat(MAX_FRAME_BYTES + 1)) }
            expectFail(ErrorCode.BAD_REQUEST, "artId fora do formato") {
                decode("{\"v\":1,\"t\":\"state\",\"access\":true,\"hasSession\":true,\"playing\":true,\"canPlayPause\":true," +
                    "\"canNext\":true,\"canPrev\":true,\"durationMs\":1,\"positionMs\":1,\"artId\":\"ZZ\"}")
            }

            // capa em blocos
            for (n in listOf(1, 100, ART_CHUNK_BYTES, ART_CHUNK_BYTES + 1, 3 * ART_CHUNK_BYTES, 50000, MAX_ART_BYTES)) {
                val img = ByteArray(n) { i -> ((i * 31 + n) and 0xff).toByte() }
                val chunks = artChunks(img)
                if (chunks.size != (n + ART_CHUNK_BYTES - 1) / ART_CHUNK_BYTES) throw IllegalStateException("capa $n: número de blocos errado")
                val asm = ArtAssembler()
                var got: ByteArray? = null
                for (ch in chunks) {
                    val text = encode(ch)
                    if (text.length > MAX_FRAME_BYTES) throw IllegalStateException("capa $n: bloco maior que o limite da mensagem")
                    if (decode(text) != ch) throw IllegalStateException("capa $n: ida e volta do bloco diferente")
                    got = asm.add(decode(text) as Message.ArtChunk)
                }
                if (got == null || !got.contentEquals(img)) throw IllegalStateException("capa $n: remontagem diferente da original")
            }
            val big = ByteArray(MAX_ART_BYTES + 1)
            expectFail(ErrorCode.TOO_LARGE, "capa grande demais") { artChunks(big) }
            val artTwo = artChunks(ByteArray(ART_CHUNK_BYTES + 10) { 5 })
            val asmBad = ArtAssembler()
            asmBad.add(artTwo[0])
            val tampered = artTwo[1].copy(data = b64(ByteArray(10) { 6 }))
            expectFail(ErrorCode.BAD_REQUEST, "capa adulterada") { asmBad.add(tampered) }
            val asmOrder = ArtAssembler()
            expectFail(ErrorCode.BAD_REQUEST, "bloco fora de ordem") { asmOrder.add(artTwo[1]) }
            expectFail(ErrorCode.BAD_REQUEST, "índice fora do total") {
                decode(encode(artTwo[0]).replace("\"index\":0", "\"index\":2"))
            }
            expectFail(ErrorCode.BAD_REQUEST, "tamanho do bloco inconsistente") {
                decode(encode(artTwo[0]).replace("\"size\":${ART_CHUNK_BYTES + 10}", "\"size\":${ART_CHUNK_BYTES * 2 + 10}"))
            }

            // leitura de linhas
            val two = (encode(Message.Ping) + "\n" + encode(Message.Pong) + "\n").toByteArray(Charsets.UTF_8)
            val ins = ByteArrayInputStream(two)
            if (decode(readFrame(ins) ?: throw IllegalStateException("leitura 1 vazia")) != Message.Ping) {
                throw IllegalStateException("leitura 1 errada")
            }
            if (decode(readFrame(ins) ?: throw IllegalStateException("leitura 2 vazia")) != Message.Pong) {
                throw IllegalStateException("leitura 2 errada")
            }
            if (readFrame(ins) != null) throw IllegalStateException("fim do fluxo deveria devolver null")
            expectFail(ErrorCode.TOO_LARGE, "linha enorme") {
                readFrame(ByteArrayInputStream(ByteArray(MAX_FRAME_BYTES + 10) { 'a'.code.toByte() }))
            }
            expectFail(ErrorCode.BAD_REQUEST, "linha cortada") {
                readFrame(ByteArrayInputStream("{\"v\":1".toByteArray(Charsets.UTF_8)))
            }
            null
        } catch (e: Throwable) {
            (e.message ?: e.javaClass.simpleName)
        }
    }
}
