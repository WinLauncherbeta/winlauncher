package com.example.winlauncher

import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Protocolo entre a WinLauncher (servidor) e o WinLauncher Remote (cliente).
 *
 * Etapa 3A: somente definição das mensagens, codificação/decodificação, validação e limites.
 * Nada aqui abre socket, usa rede ou mexe no MediaSessionHub (só lê os tipos dele para mapear resultados).
 *
 * Formato: uma mensagem JSON por linha (UTF-8, terminada em '\n'), sempre com "v" (versão) e "t" (tipo).
 * O JSON gerado pelo org.json nunca contém quebra de linha crua, então '\n' é um delimitador seguro.
 *
 * Esboço do fluxo (será implementado nas próximas etapas):
 *  - Pareamento (TLS já ativo, cliente ainda sem confiar no certificado):
 *      Remote -> hello, pair_request(deviceId, deviceName, clientNonce)
 *      Server -> pair_challenge(serverNonce, serverName)
 *      Os dois celulares calculam o mesmo número (RemoteAuth.pairingCode) e o usuário compara;
 *      toca "Permitir" na WinLauncher -> Server -> pair_ok(token)   (ou error PAIRING_DENIED)
 *  - Uso normal: Remote -> hello, auth(deviceId, token) -> Server: auth_ok; depois command/state.
 */
object RemoteProtocol {

    const val VERSION = 1

    /** Porta padrão (reservada; o servidor real é da Etapa 3B). */
    const val DEFAULT_PORT = 48655

    /** Tipo de serviço NSD (reservado para a divulgação na rede, etapa seguinte). */
    const val SERVICE_TYPE = "_winlauncher._tcp."

    /** Tamanho máximo de uma mensagem (bytes, sem contar o '\n'). */
    const val MAX_FRAME_BYTES = 16 * 1024

    const val MAX_NAME = 64
    const val MAX_TEXT = 256
    const val NONCE_BYTES = 16
    const val TOKEN_BYTES = 32

    private const val B64_FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private val ID_REGEX = Regex("^[A-Za-z0-9_-]{8,64}$")

    // ------------------------------------------------------------------ tipos

    object Types {
        const val HELLO = "hello"
        const val PAIR_REQUEST = "pair_request"
        const val PAIR_CHALLENGE = "pair_challenge"
        const val PAIR_OK = "pair_ok"
        const val AUTH = "auth"
        const val AUTH_OK = "auth_ok"
        const val COMMAND = "command"
        const val COMMAND_RESULT = "command_result"
        const val STATE = "state"
        const val ERROR = "error"
        const val PING = "ping"
        const val PONG = "pong"
    }

    enum class Command(val wire: String) {
        PLAY_PAUSE("play_pause"),
        NEXT("next"),
        PREVIOUS("previous");

        companion object {
            fun fromWire(s: String?): Command? = values().firstOrNull { it.wire == s }
        }
    }

    enum class ErrorCode(val wire: String) {
        BAD_REQUEST("bad_request"),
        UNSUPPORTED_VERSION("unsupported_version"),
        TOO_LARGE("too_large"),
        NOT_PAIRED("not_paired"),
        PAIRING_DENIED("pairing_denied"),
        PAIRING_BUSY("pairing_busy"),
        RATE_LIMITED("rate_limited"),
        NO_ACCESS("no_access"),
        NO_SESSION("no_session"),
        UNAVAILABLE("unavailable"),
        INTERNAL("internal");

        companion object {
            fun fromWire(s: String?): ErrorCode = values().firstOrNull { it.wire == s } ?: INTERNAL
        }
    }

    class ProtocolException(val code: ErrorCode, message: String) : Exception(message)

    sealed class Message(val type: String) {
        /** role: "remote" ou "server". */
        data class Hello(val version: Int, val deviceId: String, val deviceName: String, val role: String) :
            Message(Types.HELLO)

        data class PairRequest(val deviceId: String, val deviceName: String, val clientNonce: String) :
            Message(Types.PAIR_REQUEST)

        data class PairChallenge(val serverNonce: String, val serverName: String) : Message(Types.PAIR_CHALLENGE)

        data class PairOk(val token: String, val serverName: String) : Message(Types.PAIR_OK)

        data class Auth(val deviceId: String, val token: String) : Message(Types.AUTH)

        data class AuthOk(val serverName: String, val version: Int) : Message(Types.AUTH_OK)

        data class CommandMsg(val id: Long, val command: Command) : Message(Types.COMMAND)

        data class CommandResult(val id: Long, val ok: Boolean, val error: ErrorCode?) : Message(Types.COMMAND_RESULT)

        data class StateMsg(
            val access: Boolean,
            val hasSession: Boolean,
            val playing: Boolean,
            val title: String,
            val artist: String,
            val album: String,
            val appLabel: String,
            val canPlayPause: Boolean,
            val canNext: Boolean,
            val canPrev: Boolean,
            val durationMs: Long,
            val positionMs: Long
        ) : Message(Types.STATE)

        data class ErrorMsg(val code: ErrorCode, val message: String, val id: Long?) : Message(Types.ERROR)

        object Ping : Message(Types.PING)

        object Pong : Message(Types.PONG)
    }

    // ------------------------------------------------------------------ ligação com o MediaSessionHub

    /** Resultado de um comando do Hub -> código de erro do protocolo (null = sucesso). */
    fun errorFor(r: MediaSessionHub.Result): ErrorCode? = when (r) {
        MediaSessionHub.Result.OK -> null
        MediaSessionHub.Result.NO_ACCESS -> ErrorCode.NO_ACCESS
        MediaSessionHub.Result.NO_SESSION -> ErrorCode.NO_SESSION
        MediaSessionHub.Result.UNAVAILABLE -> ErrorCode.UNAVAILABLE
        MediaSessionHub.Result.ERROR -> ErrorCode.INTERNAL
    }

    /** Estado do Hub -> mensagem "state" (sem a capa: ela terá um canal próprio em etapa futura). */
    fun stateOf(s: MediaSessionHub.State): Message.StateMsg = Message.StateMsg(
        access = s.access,
        hasSession = s.hasSession,
        playing = s.playing,
        title = clip(s.title, MAX_TEXT),
        artist = clip(s.artist, MAX_TEXT),
        album = clip(s.album, MAX_TEXT),
        appLabel = clip(s.appLabel, MAX_NAME),
        canPlayPause = s.canPlayPause,
        canNext = s.canNext,
        canPrev = s.canPrev,
        durationMs = s.durationMs.coerceAtLeast(0L),
        positionMs = s.positionMs.coerceAtLeast(0L)
    )

    fun clip(s: String, max: Int): String = if (s.length <= max) s else s.substring(0, max)

    // ------------------------------------------------------------------ base64 (URL-safe, sem padding)

    fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, B64_FLAGS)

    /** Decodifica e só aceita a forma canônica (a mesma que b64() produziria). */
    fun unb64(s: String): ByteArray? {
        return try {
            val b = Base64.decode(s, B64_FLAGS)
            if (b64(b) == s) b else null
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    // ------------------------------------------------------------------ codificação

    fun toJson(m: Message): JSONObject {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("t", m.type)
        when (m) {
            is Message.Hello -> {
                o.put("version", m.version)
                o.put("deviceId", m.deviceId)
                o.put("deviceName", m.deviceName)
                o.put("role", m.role)
            }
            is Message.PairRequest -> {
                o.put("deviceId", m.deviceId)
                o.put("deviceName", m.deviceName)
                o.put("clientNonce", m.clientNonce)
            }
            is Message.PairChallenge -> {
                o.put("serverNonce", m.serverNonce)
                o.put("serverName", m.serverName)
            }
            is Message.PairOk -> {
                o.put("token", m.token)
                o.put("serverName", m.serverName)
            }
            is Message.Auth -> {
                o.put("deviceId", m.deviceId)
                o.put("token", m.token)
            }
            is Message.AuthOk -> {
                o.put("serverName", m.serverName)
                o.put("version", m.version)
            }
            is Message.CommandMsg -> {
                o.put("id", m.id)
                o.put("cmd", m.command.wire)
            }
            is Message.CommandResult -> {
                o.put("id", m.id)
                o.put("ok", m.ok)
                if (m.error != null) o.put("error", m.error.wire)
            }
            is Message.StateMsg -> {
                o.put("access", m.access)
                o.put("hasSession", m.hasSession)
                o.put("playing", m.playing)
                o.put("title", m.title)
                o.put("artist", m.artist)
                o.put("album", m.album)
                o.put("appLabel", m.appLabel)
                o.put("canPlayPause", m.canPlayPause)
                o.put("canNext", m.canNext)
                o.put("canPrev", m.canPrev)
                o.put("durationMs", m.durationMs)
                o.put("positionMs", m.positionMs)
            }
            is Message.ErrorMsg -> {
                o.put("code", m.code.wire)
                o.put("message", m.message)
                if (m.id != null) o.put("id", m.id)
            }
            Message.Ping -> {
            }
            Message.Pong -> {
            }
        }
        return o
    }

    /** Uma mensagem como texto JSON (uma linha, sem '\n'). */
    fun encode(m: Message): String = toJson(m).toString()

    /** Mensagem pronta para enviar: JSON + '\n'. Lança se passar do limite. */
    fun encodeFrame(m: Message): ByteArray {
        val bytes = (encode(m) + "\n").toByteArray(Charsets.UTF_8)
        if (bytes.size - 1 > MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
        return bytes
    }

    // ------------------------------------------------------------------ decodificação (com validação)

    private fun bad(msg: String) = ProtocolException(ErrorCode.BAD_REQUEST, msg)

    private fun JSONObject.reqStr(key: String, max: Int): String {
        val v = opt(key)
        if (v !is String || v.isEmpty() || v.length > max) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.optStr(key: String, max: Int): String {
        if (!has(key)) return ""
        val v = opt(key)
        if (v !is String || v.length > max) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqLong(key: String): Long {
        val v = opt(key)
        if (v !is Number) throw bad("campo '$key' inválido")
        return v.toLong()
    }

    private fun JSONObject.reqBool(key: String): Boolean {
        val v = opt(key)
        if (v !is Boolean) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqId(key: String): String {
        val v = reqStr(key, 64)
        if (!ID_REGEX.matches(v)) throw bad("campo '$key' fora do formato")
        return v
    }

    private fun JSONObject.reqNonce(key: String): String {
        val v = reqStr(key, 64)
        val b = unb64(v)
        if (b == null || b.size != NONCE_BYTES) throw bad("campo '$key' inválido")
        return v
    }

    private fun JSONObject.reqToken(key: String): String {
        val v = reqStr(key, 96)
        val b = unb64(v)
        if (b == null || b.size != TOKEN_BYTES) throw bad("campo '$key' inválido")
        return v
    }

    fun decode(line: String): Message {
        if (line.length > MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
        val o = try {
            JSONObject(line)
        } catch (e: Exception) {
            throw bad("JSON inválido")
        }
        val v = o.opt("v")
        if (v !is Number || v.toInt() != VERSION) {
            throw ProtocolException(ErrorCode.UNSUPPORTED_VERSION, "versão de protocolo não suportada")
        }
        return when (o.opt("t")) {
            Types.HELLO -> Message.Hello(
                version = o.reqLong("version").toInt(),
                deviceId = o.reqId("deviceId"),
                deviceName = o.reqStr("deviceName", MAX_NAME),
                role = o.reqStr("role", 16)
            )
            Types.PAIR_REQUEST -> Message.PairRequest(
                deviceId = o.reqId("deviceId"),
                deviceName = o.reqStr("deviceName", MAX_NAME),
                clientNonce = o.reqNonce("clientNonce")
            )
            Types.PAIR_CHALLENGE -> Message.PairChallenge(
                serverNonce = o.reqNonce("serverNonce"),
                serverName = o.reqStr("serverName", MAX_NAME)
            )
            Types.PAIR_OK -> Message.PairOk(
                token = o.reqToken("token"),
                serverName = o.reqStr("serverName", MAX_NAME)
            )
            Types.AUTH -> Message.Auth(
                deviceId = o.reqId("deviceId"),
                token = o.reqToken("token")
            )
            Types.AUTH_OK -> Message.AuthOk(
                serverName = o.reqStr("serverName", MAX_NAME),
                version = o.reqLong("version").toInt()
            )
            Types.COMMAND -> Message.CommandMsg(
                id = o.reqLong("id"),
                command = Command.fromWire(o.optString("cmd", "")) ?: throw bad("comando desconhecido")
            )
            Types.COMMAND_RESULT -> Message.CommandResult(
                id = o.reqLong("id"),
                ok = o.reqBool("ok"),
                error = if (o.has("error")) ErrorCode.fromWire(o.optString("error", "")) else null
            )
            Types.STATE -> Message.StateMsg(
                access = o.reqBool("access"),
                hasSession = o.reqBool("hasSession"),
                playing = o.reqBool("playing"),
                title = o.optStr("title", MAX_TEXT),
                artist = o.optStr("artist", MAX_TEXT),
                album = o.optStr("album", MAX_TEXT),
                appLabel = o.optStr("appLabel", MAX_NAME),
                canPlayPause = o.reqBool("canPlayPause"),
                canNext = o.reqBool("canNext"),
                canPrev = o.reqBool("canPrev"),
                durationMs = o.reqLong("durationMs"),
                positionMs = o.reqLong("positionMs")
            )
            Types.ERROR -> Message.ErrorMsg(
                code = ErrorCode.fromWire(o.optString("code", "")),
                message = o.optStr("message", MAX_TEXT),
                id = if (o.has("id")) o.reqLong("id") else null
            )
            Types.PING -> Message.Ping
            Types.PONG -> Message.Pong
            else -> throw bad("tipo de mensagem desconhecido")
        }
    }

    // ------------------------------------------------------------------ leitura de uma linha

    /**
     * Lê uma mensagem (até '\n') do fluxo, no máximo MAX_FRAME_BYTES. Devolve null se o fluxo terminou
     * limpo (nenhum byte pendente). Use um BufferedInputStream por cima do socket (a leitura é byte a byte).
     */
    fun readFrame(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        while (true) {
            val b = input.read()
            if (b < 0) {
                if (buf.size() == 0) return null
                throw bad("conexão encerrada no meio de uma mensagem")
            }
            if (b == '\n'.code) return buf.toString("UTF-8")
            if (buf.size() >= MAX_FRAME_BYTES) throw ProtocolException(ErrorCode.TOO_LARGE, "mensagem grande demais")
            buf.write(b)
        }
    }

    // ------------------------------------------------------------------ autoteste

    private fun expectFail(code: ErrorCode, what: String, block: () -> Unit) {
        try {
            block()
        } catch (e: ProtocolException) {
            if (e.code == code) return
            throw IllegalStateException("$what: erro ${e.code.wire} em vez de ${code.wire}")
        }
        throw IllegalStateException("$what: deveria ser rejeitado")
    }

    /** Testa codificação, decodificação, validações e leitura de linhas. null = tudo certo; senão, o motivo. */
    fun selfTest(): String? {
        return try {
            val id = "AbCdEfGh12345678"
            val nonceA = b64(ByteArray(NONCE_BYTES) { 0x22 })
            val nonceB = b64(ByteArray(NONCE_BYTES) { 0x33 })
            val token = b64(ByteArray(TOKEN_BYTES) { 0x44 })
            val samples = listOf<Message>(
                Message.Hello(VERSION, id, "Celular da Ana", "remote"),
                Message.PairRequest(id, "Celular da Ana", nonceA),
                Message.PairChallenge(nonceB, "WinLauncher"),
                Message.PairOk(token, "WinLauncher"),
                Message.Auth(id, token),
                Message.AuthOk("WinLauncher", VERSION),
                Message.CommandMsg(7L, Command.NEXT),
                Message.CommandResult(7L, true, null),
                Message.CommandResult(8L, false, ErrorCode.UNAVAILABLE),
                Message.StateMsg(
                    true, true, true, "Título \"com aspas\" e acentuação ãéç", "Artista\nem duas linhas", "Álbum",
                    "YouTube Music", true, true, false, 215000L, 12345L
                ),
                Message.ErrorMsg(ErrorCode.NOT_PAIRED, "não pareado", 9L),
                Message.ErrorMsg(ErrorCode.INTERNAL, "erro", null),
                Message.Ping,
                Message.Pong
            )
            for (m in samples) {
                val text = encode(m)
                if (text.contains('\n')) throw IllegalStateException("${m.type}: quebra de linha no JSON")
                val back = decode(text)
                if (back != m) throw IllegalStateException("${m.type}: ida e volta diferente")
                val frame = encodeFrame(m)
                if (frame.last() != '\n'.code.toByte()) throw IllegalStateException("${m.type}: quadro sem '\\n'")
            }

            // rejeições
            expectFail(ErrorCode.BAD_REQUEST, "JSON quebrado") { decode("{nao e json") }
            expectFail(ErrorCode.UNSUPPORTED_VERSION, "versão errada") { decode("{\"v\":99,\"t\":\"ping\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "tipo desconhecido") { decode("{\"v\":1,\"t\":\"xyz\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "comando desconhecido") { decode("{\"v\":1,\"t\":\"command\",\"id\":1,\"cmd\":\"format\"}") }
            expectFail(ErrorCode.BAD_REQUEST, "nonce curto") {
                decode("{\"v\":1,\"t\":\"pair_request\",\"deviceId\":\"$id\",\"deviceName\":\"x\",\"clientNonce\":\"AAAA\"}")
            }
            expectFail(ErrorCode.BAD_REQUEST, "id fora do formato") {
                decode("{\"v\":1,\"t\":\"auth\",\"deviceId\":\"a b\",\"token\":\"$token\"}")
            }
            expectFail(ErrorCode.TOO_LARGE, "mensagem enorme") { decode("x".repeat(MAX_FRAME_BYTES + 1)) }

            // leitura de linhas
            val two = (encode(Message.Ping) + "\n" + encode(Message.Pong) + "\n").toByteArray(Charsets.UTF_8)
            val ins = ByteArrayInputStream(two)
            if (decode(readFrame(ins) ?: throw IllegalStateException("leitura 1 vazia")) != Message.Ping) {
                throw IllegalStateException("leitura 1 errada")
            }
            if (decode(readFrame(ins) ?: throw IllegalStateException("leitura 2 vazia")) != Message.Pong) {
                throw IllegalStateException("leitura 2 errada")
            }
            if (readFrame(ins) != null) throw IllegalStateException("fim do fluxo deveria devolver null")
            expectFail(ErrorCode.TOO_LARGE, "linha enorme") {
                readFrame(ByteArrayInputStream(ByteArray(MAX_FRAME_BYTES + 10) { 'a'.code.toByte() }))
            }
            expectFail(ErrorCode.BAD_REQUEST, "linha cortada") {
                readFrame(ByteArrayInputStream("{\"v\":1".toByteArray(Charsets.UTF_8)))
            }
            null
        } catch (e: Throwable) {
            (e.message ?: e.javaClass.simpleName)
        }
    }
}
