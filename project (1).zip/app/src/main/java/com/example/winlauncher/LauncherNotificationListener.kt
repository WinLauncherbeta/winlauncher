package com.example.winlauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Lê as notificações ativas do sistema sob demanda. Nada é gravado em disco
 * nem guardado em memória além do que o próprio Android já mantém.
 */
class LauncherNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: LauncherNotificationListener? = null

        @Volatile
        var onChange: (() -> Unit)? = null

        fun current(ownPackage: String): List<StatusBarNotification> {
            return try {
                val all = instance?.activeNotifications ?: return emptyList()
                all.filter {
                    it.packageName != ownPackage &&
                        (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                        (it.notification.flags and Notification.FLAG_ONGOING_EVENT) == 0
                }.sortedByDescending { it.postTime }
            } catch (e: Exception) {
                emptyList()
            }
        }

        fun dismiss(key: String) {
            try {
                instance?.cancelNotification(key)
            } catch (e: Exception) {
            }
        }

        fun dismissAll() {
            try {
                instance?.cancelAllNotifications()
            } catch (e: Exception) {
            }
        }
    }

    override fun onListenerConnected() {
        instance = this
        onChange?.invoke()
    }

    override fun onListenerDisconnected() {
        instance = null
        onChange?.invoke()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }
}
