package com.example.winlauncher

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Etapa 3B - leitor de eixos para Android 13 ou menor. O Android só entrega eixos a serviços de acessibilidade a partir
 * do 14; aqui o `getevent` (com a permissão do Shizuku) lê o controle direto em /dev/input e manda os mesmos [PadAxes]
 * ao [PadEngine]. Ao contrário da acessibilidade do Android 14, ler o evdev NÃO tira os eixos do jogo.
 *
 * Tudo fora da thread principal; os resultados voltam pela thread principal. Não testado em aparelho.
 */
object PadAxisReader {

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false

    @Volatile
    private var procs = ArrayList<Process>()

    /** Texto curto de diagnóstico para o painel. */
    @Volatile
    var status: String = ""
        private set

    fun isRunning(): Boolean = running

    /** Liga a leitura. Devolve false se o Shizuku não está pronto. */
    @Synchronized
    fun start(ctx: android.content.Context): Boolean {
        if (running) return true
        if (ShizukuBridge.state(ctx) != ShizukuBridge.State.GRANTED) {
            status = "Shizuku sem autorização"
            return false
        }
        running = true
        status = "iniciando..."
        val t = Thread({ runLoop() }, "pad-axis-reader")
        t.isDaemon = true
        t.start()
        return true
    }

    @Synchronized
    fun stop() {
        running = false
        for (p in procs) {
            try {
                p.destroy()
            } catch (e: Throwable) {
            }
        }
        procs = ArrayList()
        status = ""
    }

    private fun runLoop() {
        try {
            val listing = ShizukuBridge.exec(arrayOf("getevent", "-lp"))
            if (listing == null) {
                status = "getevent falhou" + (ShizukuBridge.lastError?.let { ": $it" } ?: "")
                running = false
                return
            }
            val devs = GetEventParser.parseDevices(listing)
            if (devs.isEmpty()) {
                status = "nenhum controle encontrado em /dev/input"
                running = false
                return
            }
            status = "lendo " + devs.joinToString(", ") { it.name }
            val threads = ArrayList<Thread>()
            for (d in devs) {
                val lay = GetEventParser.layoutFor(d) ?: continue
                val th = Thread({ readDevice(d, lay) }, "pad-axis-" + d.path)
                th.isDaemon = true
                th.start()
                threads.add(th)
            }
            for (th in threads) th.join()
        } catch (t: Throwable) {
            status = "erro: " + t.javaClass.simpleName
        } finally {
            running = false
        }
    }

    private fun readDevice(d: GetEventParser.Device, lay: GetEventParser.Layout) {
        val p = ShizukuBridge.spawn(arrayOf("getevent", "-lq", d.path))
        if (p == null) {
            status = "não consegui abrir " + d.path
            return
        }
        synchronized(this) {
            if (!running) {
                p.destroy()
                return
            }
            procs.add(p)
        }
        val reader = GetEventParser.Reader(lay, d.name)
        try {
            p.inputStream.bufferedReader().use { br ->
                while (running) {
                    val line = br.readLine() ?: break
                    val ax = reader.feed(line, SystemClock.uptimeMillis()) ?: continue
                    main.post { if (running) PadEngine.onAxes(ax) }
                }
            }
        } catch (e: Throwable) {
        } finally {
            try {
                p.destroy()
            } catch (e: Throwable) {
            }
        }
    }
}
