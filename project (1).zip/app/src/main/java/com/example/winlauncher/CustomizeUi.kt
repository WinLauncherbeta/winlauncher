package com.example.winlauncher

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Outline
import android.media.MediaMetadataRetriever
import android.os.Build
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.PopupWindow
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Painéis de "Personalizar WinLauncher". Cada categoria é um MenuItem com um painel de controles. */
class CustomizeUi(private val a: MainActivity, private val p: Prefs, private val dark: Boolean = false) {

    private val d = a.resources.displayMetrics.density
    // dark = true: versão para a janela Configurações (fundo escuro); false: menu de contexto claro
    private val ink = Color.parseColor(if (dark) "#F2F5FA" else "#1F1F1F")
    private val sub = Color.parseColor(if (dark) "#A9B3C6" else "#5C5C5C")
    private val accHex = if (dark) "#19B4F0" else "#0067C0"
    private val ctl = Color.parseColor(accHex)
    private val chipOff = if (dark) "#24FFFFFF" else "#14000000"
    private val rowBg = if (dark) "#14FFFFFF" else "#0F000000"
    private val rowBgSel = if (dark) "#3319B4F0" else "#240067C0"
    private val ringOff = if (dark) "#33FFFFFF" else "#33000000"
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    /** Avisa a janela Configurações quando um slider começa/termina de ser arrastado (para ela ficar translúcida e mostrar a prévia). */
    var onDrag: ((Boolean) -> Unit)? = null

    /** Avisa quando um chip/switch é tocado (a janela fica translúcida por um instante). */
    var onTap: (() -> Unit)? = null

    companion object {
        /** Posição da categoria Widgets em [categories] (usada para reabrir o painel depois de importar fontes). */
        const val WIDGETS = 5
    }

    /** Painel avulso por chave, para a janela Configurações. */
    fun panel(key: String): View? = when (key) {
        "taskbar" -> taskbarPanel()
        "start" -> startMenuPanel()
        "wallpaper" -> wallpaperPanel()
        "appearance" -> appearancePanel()
        "screen" -> screenPanel()
        "mouse" -> mousePanel()
        "widgets" -> widgetsPanel()
        "volkeys" -> volumeKeysPanel()
        "fps" -> fpsPanel()
        "perf" -> perfPanel()
        "keyboard" -> keyboardPanel()
        "ytdiag" -> ytDiagPanel()
        "remotediag" -> halfWidth(remoteDiagPanel())
        "remoteserver" -> halfWidth(remoteServerPanel())
        else -> null
    }

    /** Deixa o painel com 50% da largura disponível (alinhado à esquerda). */
    private fun halfWidth(content: View): View {
        val box = object : FrameLayout(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                val mode = View.MeasureSpec.getMode(widthMeasureSpec)
                val size = View.MeasureSpec.getSize(widthMeasureSpec)
                val spec = if (mode == View.MeasureSpec.UNSPECIFIED) widthMeasureSpec
                else View.MeasureSpec.makeMeasureSpec(size / 2, View.MeasureSpec.EXACTLY)
                super.onMeasure(spec, heightMeasureSpec)
            }
        }
        box.addView(content, FrameLayout.LayoutParams(match, wrap))
        return box
    }

    fun categories(): List<MenuItem> = listOf(
        MenuItem("Barra de tarefas", R.drawable.ic_view, panel = { taskbarPanel() }),
        MenuItem("Menu Iniciar", R.drawable.ic_start, panel = { startMenuPanel() }),
        MenuItem("Aparência", R.drawable.ic_palette, panel = { appearancePanel() }),
        MenuItem("Tela e navegação", R.drawable.ic_brightness, panel = { screenPanel() }),
        MenuItem("Mouse e interação", R.drawable.ic_mouse, panel = { mousePanel() }),
        MenuItem("Widgets", R.drawable.ic_widgets, panel = { widgetsPanel() }),
        MenuItem("Botões de volume", R.drawable.ic_volume, panel = { volumeKeysPanel() }),
        MenuItem("Teclado", R.drawable.ic_keyboard, panel = { keyboardPanel() })
    )

    // ------------------------------------------------------------ widgets

    private fun column(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(a)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun heading(parent: LinearLayout, t: String) {
        val tv = label(t, 15f, ink, true)
        tv.setPadding(0, 0, 0, dp(6))
        parent.addView(tv)
    }

    private fun note(parent: LinearLayout, t: String) {
        val tv = label(t, 11.5f, sub)
        tv.setPadding(0, dp(6), 0, dp(2))
        parent.addView(tv)
    }

    private fun box(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun slider(
        parent: LinearLayout,
        text: String,
        key: String,
        min: Int,
        max: Int,
        def: Int,
        unit: String,
        initial: Int = p.int(key, def),
        onChange: () -> Unit = { a.applyPrefs() }
    ) {
        val tv = label("", 12.5f, ink)
        tv.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(a)
        sb.max = max - min
        sb.progress = (initial - min).coerceIn(0, max - min)
        tv.text = text + ": " + (sb.progress + min) + unit
        sb.progressTintList = ColorStateList.valueOf(ctl)
        sb.thumbTintList = ColorStateList.valueOf(ctl)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                val value = min + v
                tv.text = text + ": " + value + unit
                if (fromUser) {
                    p.putInt(key, value)
                    onChange()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                onDrag?.invoke(true)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDrag?.invoke(false)
            }
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = box(if (on) accHex else chipOff, 6)
        c.setTextColor(if (on) Color.WHITE else ink)
    }

    private fun choice(
        parent: LinearLayout,
        text: String,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ) {
        val tv = label(text, 12.5f, ink)
        tv.setPadding(0, dp(10), 0, dp(4))
        parent.addView(tv)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        for (i in options.indices) {
            val c = TextView(a)
            c.text = options[i]
            c.textSize = 11.5f
            c.gravity = Gravity.CENTER
            c.setPadding(dp(4), dp(8), dp(4), dp(8))
            c.isClickable = true
            c.setOnClickListener {
                for (j in chips.indices) styleChip(chips[j], j == i)
                onSelect(i)
                onTap?.invoke()
            }
            chips.add(c)
            val lp = LinearLayout.LayoutParams(0, wrap, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            row.addView(c, lp)
        }
        for (i in chips.indices) styleChip(chips[i], i == selected)
        parent.addView(row, LinearLayout.LayoutParams(match, wrap))
    }

    private fun switchRow(parent: LinearLayout, text: String, value: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(a)
        s.text = text
        s.setTextColor(ink)
        s.textSize = 12.5f
        s.isChecked = value
        s.setOnCheckedChangeListener { _, v ->
            onChange(v)
            onTap?.invoke()
        }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(10)
        parent.addView(s, lp)
        return s
    }

    private fun button(parent: LinearLayout, text: String, onClick: () -> Unit) {
        val b = TextView(a)
        b.text = text
        b.textSize = 12.5f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.background = box(accHex, 6)
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
    }

    // ------------------------------------------------------------ painéis

    private fun taskbarPanel(): View {
        val c = column()
        heading(c, "Barra de tarefas")
        switchRow(c, "Mostrar barra de tarefas", !p.tbHidden) { on -> a.setTaskbarHidden(!on) }
        note(c, "Desligado: a barra de tarefas some por completo (ícones, bandeja e relógio). Para voltar: botão direito na área de trabalho > Mostrar barra de tarefas.")
        slider(c, "Escala geral", "ui_tb_scale", 60, 200, 100, "%")
        slider(c, "Altura", "ui_tb_height", 36, 80, 48, " dp")
        slider(c, "Tamanho dos ícones", "ui_tb_icon", 32, 64, 44, " dp")
        slider(c, "Ícones da bandeja", "ui_tb_tray", 14, 32, 20, " dp")
        slider(c, "Relógio e textos", "ui_tb_clock", 8, 18, 11, " sp")
        slider(c, "Espaçamento", "ui_tb_space", 0, 16, 0, " dp")
        choice(c, "Posição", listOf("Embaixo", "Em cima"), p.tbPos) {
            p.tbPos = it
            a.applyPrefs()
        }
        choice(c, "Fundo", listOf("Ajustável", "Vidro fosco", "Invisível"), p.tbBg) {
            p.tbBg = it
            a.applyPrefs()
        }
        slider(c, "Opacidade do fundo", "ui_tb_alpha", 0, 100, 90, "%")
        note(c, "Estas opções alteram somente o fundo da barra. Ícones, bandeja, relógio e notificações permanecem totalmente visíveis.")
        switchRow(c, "Barra sobre outros apps (mouse na borda)", p.tbOverlay) { on ->
            p.tbOverlay = on
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                TaskbarOverlayService.sync(a)
            }
        }
        switchRow(c, "Botão de volume flutuante (arraste para qualquer lugar)", p.volBtn) { on ->
            p.volBtn = on
            a.refreshVolFloat()
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                VolumeButtonService.sync(a, true)
            }
        }
        note(c, "Clique no botão para abrir o volume do Android. Segure e arraste (mouse ou toque) para mover.")
        note(c, "Com outro app aberto, encoste o mouse na borda da tela (embaixo ou em cima, conforme a posição da barra) para levantar a barra de tarefas.")
        return c
    }


    private fun startMenuPanel(): View {
        val c = column()
        heading(c, "Menu Iniciar")
        slider(c, "Largura", "ui_st_w", 260, 560, 360, " dp")
        slider(c, "Altura", "ui_st_h", 240, 800, 0, " dp", initial = if (p.stH == 0) a.defaultStartHeightDp() else p.stH)
        choice(c, "Posição", listOf("Centro inferior", "Centro da tela", "Esquerda"), p.stPos) {
            p.stPos = it
            a.applyPrefs()
        }
        slider(c, "Opacidade", "ui_st_alpha", 30, 100, 95, "%")
        slider(c, "Arredondamento dos cantos", "ui_st_radius", 0, 32, 12, " dp")
        slider(c, "Aplicativos por linha", "ui_st_cols", 3, 8, 4, "")
        switchRow(c, "Efeito de vidro", p.stGlass) {
            p.stGlass = it
            a.applyPrefs()
        }
        button(c, "Restaurar largura e altura padrão") {
            p.stW = 360
            p.stH = 0
            a.applyPrefs()
            a.menu.hide()
        }
        return c
    }

    // ------------------------------------------------------------ wallpaper (estilo Plano de fundo do Windows 11)

    private fun wallpaperPanel(): View {
        val root = column()
        // 0 = Imagem, 1 = Vídeo (começa no tipo do wallpaper atual)
        var mode = if (a.currentWallpaperIsVideo()) 1 else 0

        fun build() {
            root.removeAllViews()
            val video = mode == 1

            // ---- prévia do wallpaper atual (moldura de monitor)
            val frame = FrameLayout(a)
            frame.background = box("#000000", 14)
            frame.setPadding(dp(3), dp(3), dp(3), dp(3))
            val prev = ImageView(a)
            prev.scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(prev, 11)
            val cur = a.currentWallpaperUri()
            if (cur != null) {
                prev.setBackgroundColor(Color.parseColor("#111111"))
                loadThumb(prev, cur, a.currentWallpaperIsVideo(), dp(360))
            } else {
                prev.setImageDrawable(defaultWallpaperDrawable())
            }
            frame.addView(prev, FrameLayout.LayoutParams(match, match))
            val flp = LinearLayout.LayoutParams(dp(200), dp(118))
            flp.bottomMargin = dp(12)
            root.addView(frame, flp)

            // ---- "Personalize seu plano de fundo" + dropdown Imagem / Vídeo
            val modeDrop = dropdown(listOf("Imagem", "Vídeo")[mode], listOf("Imagem", "Vídeo"), mode) {
                mode = it
                build()
            }
            root.addView(
                settingRow(
                    R.drawable.ic_image,
                    "Personalize seu plano de fundo",
                    if (video) "Um plano de fundo com vídeo se aplica à sua área de trabalho atual"
                    else "Um plano de fundo com imagem se aplica à sua área de trabalho atual",
                    modeDrop
                ),
                rowLp()
            )

            // ---- grade de miniaturas + botão "+"
            val grid = LinearLayout(a)
            grid.orientation = LinearLayout.VERTICAL
            grid.background = box(rowBg, 8)
            grid.setPadding(dp(14), dp(12), dp(14), dp(12))
            grid.addView(label(if (video) "Vídeos" else "Imagens", 13.5f, ink))

            val strip = LinearLayout(a)
            strip.orientation = LinearLayout.HORIZONTAL
            val curStr = a.currentWallpaperUri()?.toString()
            val curIsVideo = a.currentWallpaperIsVideo()

            if (!video) {
                strip.addView(tile(selected = curStr == null) { iv ->
                    iv.setImageDrawable(defaultWallpaperDrawable())
                }.also {
                    it.setOnClickListener {
                        a.resetWallpaper()
                        build()
                        onTap?.invoke()
                    }
                })
            }
            for (s in a.recentWallpapers(video)) {
                val uri = Uri.parse(s)
                val t = tile(selected = curStr == s && curIsVideo == video) { iv ->
                    loadThumb(iv, uri, video, dp(160))
                }
                t.setOnClickListener {
                    a.setWallpaper(s, video)
                    build()
                    onTap?.invoke()
                }
                // segurar remove da lista (não apaga o arquivo)
                t.setOnLongClickListener {
                    a.removeRecentWallpaper(s)
                    build()
                    true
                }
                strip.addView(t)
            }
            strip.addView(plusTile {
                if (!dark) a.menu.hide()
                if (video) a.pickWallpaperAnimated() else a.pickWallpaperStatic()
            })
            val hs = HorizontalScrollView(a)
            hs.isHorizontalScrollBarEnabled = false
            hs.addView(strip)
            val hlp = LinearLayout.LayoutParams(match, wrap)
            hlp.topMargin = dp(8)
            grid.addView(hs, hlp)
            root.addView(grid, rowLp())

            // ---- qualidade do papel de parede (só imagem)
            if (!video) {
                val q = listOf("Otimizado", "Alta", "Original")
                val qDrop = dropdown(q[a.wallpaperQuality()], q, a.wallpaperQuality()) {
                    a.setWallpaperQuality(it)
                    build()
                }
                root.addView(settingRow(null, "Qualidade do papel de parede", null, qDrop), rowLp())
            }

            // ---- escolher arquivo
            val browse = TextView(a)
            browse.text = if (video) "Procurar vídeos" else "Procurar fotos"
            browse.textSize = 12.5f
            browse.setTextColor(ink)
            browse.gravity = Gravity.CENTER
            browse.background = box(chipOff, 6)
            browse.setPadding(dp(14), dp(8), dp(14), dp(8))
            browse.isClickable = true
            browse.setOnClickListener {
                if (!dark) a.menu.hide()
                if (video) a.pickWallpaperAnimated() else a.pickWallpaperStatic()
            }
            root.addView(
                settingRow(null, if (video) "Escolha um vídeo ou GIF" else "Escolha uma foto", null, browse),
                rowLp()
            )
        }

        build()
        // quando o seletor de arquivos volta, a grade se atualiza sozinha
        a.wallpaperChanged = {
            if (root.isAttachedToWindow) {
                mode = if (a.currentWallpaperIsVideo()) 1 else 0
                build()
            }
        }
        return root
    }

    private fun rowLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(match, wrap).also { it.bottomMargin = dp(6) }

    private fun defaultWallpaperDrawable(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#0B1E3F"), Color.parseColor("#1B5FD0"), Color.parseColor("#0A2A66"))
    )

    private fun roundClip(v: View, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
            }
        }
    }

    /** Linha de configuração: ícone opcional, título, subtítulo opcional e um controle à direita. */
    private fun settingRow(icon: Int?, title: String, subtitle: String?, right: View?): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = box(rowBg, 8)
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        if (icon != null) {
            val iv = ImageView(a)
            iv.setImageResource(icon)
            iv.setColorFilter(ink)
            val ilp = LinearLayout.LayoutParams(dp(22), dp(22))
            ilp.rightMargin = dp(12)
            row.addView(iv, ilp)
        }
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 13.5f, ink))
        if (subtitle != null) col.addView(label(subtitle, 11f, sub))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        if (right != null) {
            val rlp = LinearLayout.LayoutParams(wrap, wrap)
            rlp.leftMargin = dp(10)
            row.addView(right, rlp)
        }
        return row
    }

    /** Caixa de seleção que abre uma lista (como "Imagem ▾" e "Otimizado ▾"). */
    private fun dropdown(text: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.background = box(chipOff, 6)
        b.setPadding(dp(12), dp(8), dp(10), dp(8))
        b.minimumWidth = dp(104)
        b.addView(label(text, 12.5f, ink), LinearLayout.LayoutParams(0, wrap, 1f))
        val ch = ImageView(a)
        ch.setImageResource(R.drawable.ic_chevron_down)
        ch.setColorFilter(ink)
        val clp = LinearLayout.LayoutParams(dp(14), dp(14))
        clp.leftMargin = dp(8)
        b.addView(ch, clp)
        b.isClickable = true
        b.setOnClickListener {
            val list = LinearLayout(a)
            list.orientation = LinearLayout.VERTICAL
            list.setPadding(dp(4), dp(4), dp(4), dp(4))
            val pw = PopupWindow(list, maxOf(b.width, dp(120)), wrap, true)
            pw.setBackgroundDrawable(box(if (dark) "#FF2B3345" else "#FFFFFFFF", 8))
            pw.isOutsideTouchable = true
            pw.elevation = dp(8).toFloat()
            for (i in options.indices) {
                val item = TextView(a)
                item.text = options[i]
                item.textSize = 12.5f
                item.setTextColor(ink)
                item.setPadding(dp(12), dp(10), dp(12), dp(10))
                if (i == selected) item.background = box(rowBgSel, 6)
                item.isClickable = true
                item.setOnClickListener {
                    pw.dismiss()
                    if (i != selected) onSelect(i)
                }
                list.addView(item, LinearLayout.LayoutParams(match, wrap))
            }
            pw.showAsDropDown(b, 0, dp(2))
        }
        return b
    }

    /** Miniatura quadrada; [selected] desenha o anel de destaque. */
    private fun tile(selected: Boolean, fill: (ImageView) -> Unit): FrameLayout {
        val f = FrameLayout(a)
        f.setPadding(dp(3), dp(3), dp(3), dp(3))
        if (selected) {
            val g = GradientDrawable()
            g.setColor(Color.TRANSPARENT)
            g.cornerRadius = dp(10).toFloat()
            g.setStroke(dp(2), ctl)
            f.background = g
        }
        val iv = ImageView(a)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(Color.parseColor("#22000000"))
        roundClip(iv, 8)
        fill(iv)
        f.addView(iv, FrameLayout.LayoutParams(dp(76), dp(76)))
        f.isClickable = true
        val lp = LinearLayout.LayoutParams(wrap, wrap)
        lp.rightMargin = dp(6)
        f.layoutParams = lp
        return f
    }

    private fun plusTile(onClick: () -> Unit): View {
        val f = FrameLayout(a)
        f.setPadding(dp(3), dp(3), dp(3), dp(3))
        val inner = FrameLayout(a)
        inner.background = box(chipOff, 8)
        val ic = ImageView(a)
        ic.setImageResource(R.drawable.ic_plus)
        ic.setColorFilter(ink)
        inner.addView(ic, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        f.addView(inner, FrameLayout.LayoutParams(dp(76), dp(76)))
        f.isClickable = true
        f.setOnClickListener { onClick() }
        f.layoutParams = LinearLayout.LayoutParams(wrap, wrap)
        return f
    }

    /** Carrega uma miniatura (imagem, GIF ou quadro de vídeo) fora da thread principal. */
    private fun loadThumb(iv: ImageView, uri: Uri, video: Boolean, px: Int) {
        val key = uri.toString()
        iv.tag = key
        Thread {
            var bmp: Bitmap? = null
            try {
                if (video) {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(a, uri)
                        bmp = r.getFrameAtTime(0)
                    } finally {
                        r.release()
                    }
                } else if (Build.VERSION.SDK_INT >= 28) {
                    val src = ImageDecoder.createSource(a.contentResolver, uri)
                    bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val sc = px.toFloat() / minOf(info.size.width, info.size.height)
                        if (sc < 1f) dec.setTargetSize((info.size.width * sc).toInt(), (info.size.height * sc).toInt())
                    }
                } else {
                    val o = BitmapFactory.Options()
                    o.inJustDecodeBounds = true
                    a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                    var s = 1
                    while (minOf(o.outWidth, o.outHeight) / (s * 2) >= px) s *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = s
                    bmp = a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                }
                if (bmp != null && minOf(bmp.width, bmp.height) > px * 2) {
                    val sc = px.toFloat() / minOf(bmp.width, bmp.height)
                    bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
                }
            } catch (e: Throwable) {
                bmp = null
            }
            val out = bmp
            if (out != null) a.runOnUiThread { if (iv.tag == key) iv.setImageBitmap(out) }
        }.start()
    }

    private fun appearancePanel(): View {
        val c = column()
        heading(c, "Aparência")
        choice(c, "Tema", listOf("Escuro", "Claro"), p.theme) {
            p.theme = it
            a.themeChanged(2)
        }
        val tv = label("Cor de destaque", 12.5f, ink)
        tv.setPadding(0, dp(12), 0, dp(6))
        c.addView(tv)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = intArrayOf(
            0xFF4CC2FF.toInt(), 0xFF6CCB5F.toInt(), 0xFFFCE100.toInt(), 0xFFFF8C3A.toInt(),
            0xFFFF7EB6.toInt(), 0xFFB39DFF.toInt(), 0xFFFF6B6B.toInt(), 0xFF4DD0C8.toInt()
        )
        for (col in colors) {
            val sw = View(a)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(dp(if (col == p.accent) 3 else 1), if (col == p.accent) ink else Color.parseColor(ringOff))
            sw.background = g
            sw.isClickable = true
            sw.setOnClickListener {
                p.accent = col
                a.themeChanged(2)
            }
            val lp = LinearLayout.LayoutParams(dp(26), dp(26))
            lp.setMargins(0, 0, dp(8), 0)
            row.addView(sw, lp)
        }
        c.addView(row)
        slider(c, "Opacidade dos painéis", "ui_pn_alpha", 30, 100, 95, "%")
        switchRow(c, "Efeito de vidro nos painéis", p.pnGlass) {
            p.pnGlass = it
            a.applyPrefs()
        }
        switchRow(c, "Animações dos painéis", p.anim) {
            p.anim = it
        }
        choice(c, "Menu de contexto (Windows 11)", listOf("Claro", "Escuro"), if (p.menuDark) 1 else 0) {
            p.menuDark = it == 1
            a.themeChanged(2)
        }
        note(c, "Cor do menu de clique direito e dos painéis de personalização, igual ao Windows 11.")
        return c
    }

    private fun screenPanel(): View {
        val c = column()
        heading(c, "Tela e navegação")
        note(c, "Modo imersivo: ativo sempre que o WinLauncher está aberto. As barras do sistema ficam ocultas.")
        switchRow(c, "Bloquear barras do Android", p.lockBars) {
            p.lockBars = it
            a.applyBarLock()
        }
        note(c, "Ligado: a barra superior e a de botões de navegação não aparecem ao deslizar da borda (somem na hora). Desligado: deslizar da borda mostra as barras por alguns segundos. Vale só enquanto o WinLauncher está aberto.")
        switchRow(c, "Mostrar ícones da área de trabalho", p.dkShow) {
            p.dkShow = it
            a.applyPrefs()
        }
        button(c, "Configurações de exibição do Android") {
            a.menu.hide()
            a.openDisplaySettings()
        }
        return c
    }

    private fun widgetsPanel(): View {
        val c = column()
        heading(c, "Widgets")

        // ---- Relógio e calendário
        val h1 = label("Relógio e calendário", 13.5f, ink, true)
        h1.setPadding(0, dp(4), 0, 0)
        c.addView(h1)
        switchRow(c, "Ativar relógio e calendário", p.wgOn) {
            p.wgOn = it
            a.widgetChanged()
        }
        switchRow(c, "Permitir movimentação", p.wgMove) {
            p.wgMove = it
        }
        slider(c, "Tamanho do widget", "ui_wg_scale", ClockWidget.MIN_PCT, ClockWidget.MAX_PCT, 100, "%") {
            a.widgetChanged()
        }
        note(
            c,
            "Ao ativar, o widget aparece centralizado na área de trabalho. Para mover, toque e segure o widget até vibrar, depois arraste. " +
                "Ele nunca cobre ícones nem a barra de tarefas: se faltar espaço livre, é reduzido automaticamente."
        )

        // ---- Tipografia
        val h2 = label("Tipografia", 13.5f, ink, true)
        h2.setPadding(0, dp(16), 0, 0)
        c.addView(h2)
        button(c, "Adicionar fonte (TTF ou OTF)") {
            a.menu.hide()
            a.pickFont()
        }

        var target = ClockWidget.DAY
        val summary = label("", 11.5f, sub)
        summary.setPadding(0, dp(10), 0, dp(2))
        val list = column()

        fun selectedName(t: Int): String {
            val f = a.clock.fontFile(t)
            if (f.isEmpty()) return "Padrão"
            return FontStore.list(a).firstOrNull { it.file == f }?.name ?: "Padrão"
        }

        fun fontRow(name: String, file: String, tf: Typeface, selected: Boolean): View {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = box(if (selected) rowBgSel else rowBg, 8)
            row.setPadding(dp(10), dp(6), dp(6), dp(6))
            row.isClickable = true

            val col = column()
            val nm = label((if (selected) "✓  " else "") + name, 11f, if (selected) ctl else sub, selected)
            nm.maxLines = 1
            nm.ellipsize = android.text.TextUtils.TruncateAt.END
            val pv = label(a.clock.text(target), 18f, ink)
            pv.typeface = tf
            pv.maxLines = 1
            pv.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(nm)
            col.addView(pv)
            row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))

            if (file.isNotEmpty()) {
                val del = ImageView(a)
                del.setImageResource(R.drawable.ic_delete)
                del.setColorFilter(sub)
                del.setPadding(dp(8), dp(8), dp(8), dp(8))
                del.isClickable = true
                del.setOnClickListener { deleteFont(file); }
                row.addView(del, LinearLayout.LayoutParams(dp(36), dp(36)))
            }
            val lp = LinearLayout.LayoutParams(match, wrap)
            lp.topMargin = dp(6)
            row.layoutParams = lp
            row.setOnClickListener {
                a.clock.setFontFile(target, file)
                fontsChanged()
            }
            return row
        }

        render = {
            list.removeAllViews()
            val cur = a.clock.fontFile(target)
            val fonts = FontStore.list(a)
            val valid = cur.isNotEmpty() && fonts.any { it.file == cur }
            summary.text = "Dia: " + selectedName(ClockWidget.DAY) +
                "\nData: " + selectedName(ClockWidget.DATE) +
                "\nHorário: " + selectedName(ClockWidget.TIME)
            list.addView(fontRow("Fonte padrão", "", a.clock.defaultTypeface(target), !valid))
            for (f in fonts) {
                list.addView(fontRow(f.name, f.file, FontStore.typeface(a, f.file) ?: a.clock.defaultTypeface(target), valid && f.file == cur))
            }
        }

        choice(c, "Aplicar fonte em", listOf("Dia da semana", "Data", "Horário"), target) {
            target = it
            render?.invoke()
        }
        c.addView(summary)
        c.addView(list, LinearLayout.LayoutParams(match, wrap))
        button(c, "Restaurar fonte padrão") {
            a.clock.setFontFile(ClockWidget.DAY, "")
            a.clock.setFontFile(ClockWidget.DATE, "")
            a.clock.setFontFile(ClockWidget.TIME, "")
            fontsChanged()
        }
        note(
            c,
            "Toque em uma fonte para aplicá-la ao texto escolhido acima; a prévia mostra como ele ficará. " +
                "As fontes ficam guardadas só dentro do WinLauncher e não alteram o Android nem outros apps."
        )
        render?.invoke()
        return c
    }

    /** Redesenha a lista de fontes do painel Widgets aberto no momento. */
    private var render: (() -> Unit)? = null

    private fun fontsChanged() {
        a.clock.applyFonts()
        a.widgetChanged()
        render?.invoke()
    }

    private fun deleteFont(file: String) {
        for (t in listOf(ClockWidget.DAY, ClockWidget.DATE, ClockWidget.TIME)) {
            if (a.clock.fontFile(t) == file) a.clock.setFontFile(t, "")
        }
        FontStore.delete(a, file)
        a.toast("Fonte removida")
        fontsChanged()
    }

    private fun fpsPanel(): View {
        val c = column()
        heading(c, "Contador de FPS")
        switchRow(c, "Mostrar contador de FPS (sobre os apps)", p.fpsOn) { on ->
            p.fpsOn = on
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                FpsCounterService.sync(a)
            }
        }
        choice(c, "Tipo de FPS", listOf("FPS real", "FPS falso"), p.fpsMode) {
            p.fpsMode = it
            FpsCounterService.sync(a)
        }
        slider(c, "Tamanho do contador", "ui_fps_size", 8, 60, 13, " sp") {
            FpsCounterService.instance?.applyStyle()
        }
        note(c, "FPS real: com o Shizuku autorizado, mostra o FPS do app que está aberto (jogo, vídeo...). Sem o Shizuku, mostra só a taxa de atualização da tela (60, 90, 120...). FPS falso: número de brincadeira que alterna entre 190 e 255.")
        note(c, "A barrinha preta fica sobre qualquer app. Segure e arraste (dedo ou mouse) para mudar de lugar.")

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        val detail = label("", 11.5f, sub)
        fun updateStatus() {
            val st = ShizukuBridge.state(a)
            status.text = "Shizuku: " + when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
            detail.text = when (st) {
                ShizukuBridge.State.GRANTED -> "FPS real do app aberto ativado."
                ShizukuBridge.State.NEEDS_PERMISSION -> "Toque em \"Solicitar autorização\" e aceite o pedido do Shizuku."
                ShizukuBridge.State.NOT_RUNNING -> "Abra o Shizuku e toque em iniciar. Depois volte aqui."
                ShizukuBridge.State.NOT_INSTALLED -> "Instale e inicie o Shizuku para ver o FPS real do app aberto."
                ShizukuBridge.State.UNSUPPORTED -> "Atualize o Shizuku para a versão mais recente."
            }
        }
        updateStatus()
        ShizukuBridge.onChange = {
            a.runOnUiThread {
                updateStatus()
                FpsCounterService.sync(a)
            }
        }
        c.addView(status)
        c.addView(detail)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Abrir Shizuku") {
            if (!ShizukuBridge.open(a)) a.toast("Shizuku não encontrado")
        }
        button(c, "Atualizar estado") {
            updateStatus()
            FpsCounterService.sync(a)
        }
        return c
    }

    private fun perfPanel(): View {
        val c = column()
        heading(c, "Monitor de desempenho")
        note(c, "Painel sobre os apps com FPS, frametime, CPU, GPU e RAM. Clique com o botão direito (ou segure) no painel para Mover, mudar Opacidade e Tamanho.")
        note(c, "Os números são reais, menos as temperaturas, que ficam fixas perto de 42 °C. Uso de CPU/GPU, MHz e FPS do app aberto precisam do Shizuku autorizado; sem ele essas linhas mostram \"--\".")

        switchRow(c, "Mostrar o painel (sobre os apps)", PerfOverlayService.isOn(a)) { on -> a.setPerfOn(on) }
        switchRow(c, "Fixar na barra de tarefas", a.perfPinned()) { on -> a.setPerfPinned(on) }

        // ícone do programa (usado na barra de tarefas)
        val iconRow = LinearLayout(a)
        iconRow.orientation = LinearLayout.HORIZONTAL
        iconRow.gravity = Gravity.CENTER_VERTICAL
        val preview = ImageView(a)
        preview.setImageDrawable(a.perfIcon())
        iconRow.addView(preview, LinearLayout.LayoutParams(dp(40), dp(40)))
        val iconText = label("Ícone na barra de tarefas", 12.5f, ink)
        iconText.setPadding(dp(12), 0, 0, 0)
        iconRow.addView(iconText)
        val ilp = LinearLayout.LayoutParams(match, wrap)
        ilp.topMargin = dp(12)
        c.addView(iconRow, ilp)
        a.perfPanelRefresh = {
            if (preview.isAttachedToWindow) preview.setImageDrawable(a.perfIcon())
        }
        button(c, "Trocar ícone") {
            if (!dark) a.menu.hide()
            a.pickPerfIcon()
        }
        button(c, "Restaurar ícone") {
            a.resetPerfIcon()
            preview.setImageDrawable(a.perfIcon())
        }
        button(c, "Restaurar posição, tamanho e opacidade") {
            p.putInt("ui_perf_alpha", 100)
            p.putInt("ui_perf_scale", 100)
            p.putInt("ui_perf_anchor", 0)
            p.putInt("ui_perf_x", dp(12))
            p.putInt("ui_perf_y", dp(12))
            PerfOverlayService.instance?.let {
                // recria a janela para a nova posição valer na hora
                PerfOverlayService.setOn(a, false)
                PerfOverlayService.setOn(a, true)
            }
        }

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        fun updateStatus() {
            status.text = "Shizuku: " + when (ShizukuBridge.state(a)) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado (CPU, GPU e FPS do app aparecem como --)"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
        }
        updateStatus()
        c.addView(status)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Atualizar estado") { updateStatus() }
        return c
    }

    private fun volumeKeysPanel(): View {
        val c = column()
        heading(c, "Botões de volume")
        switchRow(c, "Bloquear botões físicos de volume (aumentar/diminuir)", p.blockVolKeys) { on ->
            p.blockVolKeys = on
            a.toast(if (on) "Botões de volume bloqueados" else "Botões de volume liberados")
        }
        note(c, "Ligado: os botões físicos de volume não fazem nada enquanto o WinLauncher está aberto. Desligado: funcionam normalmente. Em outros apps eles sempre funcionam.")

        val sc = label("Atalho Alt + V dentro de outros apps", 13f, ink, true)
        sc.setPadding(0, dp(18), 0, 0)
        c.addView(sc)
        note(c, "Para o Alt + V abrir o painel de volume também dentro de outros apps, ative \"WinLauncher - atalhos de teclado\" em Acessibilidade (Apps instalados). O serviço só lê as teclas Alt + V.")
        val st = label(
            if (ShortcutService.running) "Status: ativado" else "Status: desativado",
            12f, if (ShortcutService.running) ctl else sub
        )
        st.setPadding(0, dp(4), 0, 0)
        c.addView(st)
        button(c, "Abrir configurações de Acessibilidade") {
            try {
                a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir Acessibilidade")
            }
        }
        return c
    }

    private fun keyboardPanel(): View {
        val c = column()
        heading(c, "Teclado")
        val status = label("", 12f, sub)
        status.setPadding(0, dp(8), 0, dp(2))
        var guard = false
        var sw: Switch? = null
        fun refresh() {
            status.text = "Estado: " + when {
                KeyboardBlocker.isActive(a) -> "teclado na tela bloqueado"
                KeyboardBlocker.isEnabled(a) -> "teclado vazio ativado, mas não selecionado"
                else -> "teclado normal em uso"
            }
        }
        sw = switchRow(c, "Bloquear teclado na tela (todos os apps)", KeyboardBlocker.isActive(a)) { on ->
            if (guard) return@switchRow
            fun revert() {
                guard = true
                sw?.isChecked = KeyboardBlocker.isActive(a)
                guard = false
            }
            val viaShizuku = ShizukuBridge.state(a) == ShizukuBridge.State.GRANTED
            val direct = KeyboardBlocker.canWriteSecure(a)
            if (!viaShizuku && !direct) {
                // sem Shizuku nem permissão especial: guia pelo Android (lista de teclados / seletor)
                revert()
                if (on && !KeyboardBlocker.isEnabled(a)) {
                    a.toast("Ative \"WinLauncher - sem teclado\" na lista e volte aqui")
                    try {
                        a.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                } else {
                    a.toast(if (on) "Escolha \"WinLauncher - sem teclado\"" else "Escolha o seu teclado de antes")
                    KeyboardBlocker.showPicker(a)
                }
                return@switchRow
            }
            Thread {
                val ok = if (viaShizuku) KeyboardBlocker.set(a, p, on) else KeyboardBlocker.setDirect(a, p, on)
                a.runOnUiThread {
                    revert()
                    refresh()
                    a.toast(
                        when {
                            !ok -> "Não consegui trocar o teclado. Use os passos manuais abaixo."
                            on -> "Teclado na tela bloqueado em todos os apps"
                            else -> "Teclado normal restaurado"
                        }
                    )
                }
            }.start()
        }
        refresh()
        c.addView(status)
        note(c, "Ligado: troca o teclado do Android por um teclado vazio, então nenhum teclado aparece na tela em nenhum app (mesmo truque do Button Mapper). O teclado físico continua funcionando. Desligado: volta para o teclado que você usava antes. Troca automática com o Shizuku autorizado; sem ele, o switch abre a lista de teclados e o seletor do Android para você escolher.")
        note(c, "Atenção: com o bloqueio ligado, sem teclado físico você não consegue digitar em lugar nenhum. Para voltar, desligue aqui.")

        val man = label("Passos manuais (sem o Shizuku)", 13f, ink, true)
        man.setPadding(0, dp(18), 0, 0)
        c.addView(man)
        note(c, "1) Ative \"WinLauncher - sem teclado\" na lista de teclados. 2) Escolha-o no seletor. Para voltar ao normal, abra o seletor e escolha o seu teclado de antes.")
        button(c, "1) Abrir lista de teclados do Android") {
            try {
                a.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir as configurações de teclado")
            }
        }
        button(c, "2) Escolher teclado (seletor)") {
            KeyboardBlocker.showPicker(a)
            refresh()
        }
        button(c, "Atualizar estado") {
            guard = true
            sw?.isChecked = KeyboardBlocker.isActive(a)
            guard = false
            refresh()
        }
        return c
    }

    /**
     * Página TEMPORÁRIA de diagnóstico (WinLauncher Remote): mostra as sessões de mídia do aparelho
     * (nome do app + pacote real), deixa escolher qual controlar e testar play/pause, próxima e anterior.
     * Só será removida depois da confirmação do dono do projeto.
     */
    private fun ytDiagPanel(): View {
        val c = column()
        val white = Color.WHITE
        val dimWhite = Color.parseColor("#B3FFFFFF")
        val faintWhite = Color.parseColor("#4DFFFFFF")

        fun rounded(color: Int, r: Int): GradientDrawable {
            val g = GradientDrawable()
            g.setColor(color)
            g.cornerRadius = dp(r).toFloat()
            return g
        }

        // ---------------------------------------------------------------- estado / comandos (lógica original)
        val result = label("", 12.5f, ctl, true)
        result.setPadding(0, dp(10), 0, 0)
        result.gravity = Gravity.CENTER

        var installed: List<MediaSessionHub.Installed> = emptyList()
        var force = false
        var onRefresh: () -> Unit = {}

        fun show(name: String, r: MediaSessionHub.Result) {
            result.text = name + ": " + when (r) {
                MediaSessionHub.Result.OK -> "comando enviado. Confira se o app respondeu."
                MediaSessionHub.Result.NO_ACCESS -> "sem acesso às notificações."
                MediaSessionHub.Result.NO_SESSION -> "nenhuma sessão selecionada/encontrada (abra o app e toque uma música)."
                MediaSessionHub.Result.UNAVAILABLE -> "ação não anunciada pelo app. Ligue \"Device\" (forçar) para testar mesmo assim."
                MediaSessionHub.Result.ERROR -> "erro ao enviar o comando."
            }
        }

        // índices das ações extras anunciadas pelo app (-1 = não anunciada)
        var shuffleIdx = -1
        var repeatIdx = -1
        var likeIdx = -1
        var shuffleOn = false
        var repeatOn = false
        var liked = false
        var curTitle = ""
        var curArtist = ""

        // ---------------------------------------------------------------- topo: título da página
        val head = label("Diagnóstico da música (YouTube Music e variantes)", 14f, ink, true)
        c.addView(head)

        note(c, "Página temporária do WinLauncher Remote. Abra o app de música (YouTube Music oficial ou modificado), toque uma música e volte aqui.")

        // lista de sessões (abre pela lupa do celular)
        val sessCard = column()
        sessCard.visibility = View.GONE
        sessCard.background = rounded(Color.parseColor("#22FFFFFF"), 16)
        sessCard.setPadding(dp(10), dp(8), dp(10), dp(10))
        val sessTitle = label("Sessão controlada: Automático", 12.5f, white, true)
        sessCard.addView(sessTitle)
        val sessNote = label("Toque para escolher qual sessão será controlada. \"Automático\" só escolhe apps que parecem YouTube Music (pelo nome ou pelo pacote); qualquer outro app precisa ser escolhido por você. O nome real do pacote aparece em cada item.", 10.5f, dimWhite)
        sessNote.setPadding(0, dp(3), 0, 0)
        sessCard.addView(sessNote)
        val sessBox = column()
        val sessBoxLp = LinearLayout.LayoutParams(match, wrap)
        sessBoxLp.topMargin = dp(6)
        sessCard.addView(sessBox, sessBoxLp)

        // ---------------------------------------------------------------- celular com o player dentro
        val phoneFrame = FrameLayout(a)
        phoneFrame.setPadding(dp(3), 0, dp(3), 0)
        val bezel = column()
        bezel.setPadding(dp(5), dp(5), dp(5), dp(5))
        val bezelBg = GradientDrawable()
        bezelBg.setColor(Color.parseColor("#0B0A10"))
        bezelBg.cornerRadius = dp(42).toFloat()
        bezelBg.setStroke(dp(3), Color.parseColor("#8B7BC0"))
        bezel.background = bezelBg
        phoneFrame.addView(bezel, FrameLayout.LayoutParams(match, wrap))
        fun sideButton(g: Int, topDp: Int, hDp: Int) {
            val v = View(a)
            v.background = rounded(Color.parseColor("#8B7BC0"), 2)
            val lp = FrameLayout.LayoutParams(dp(3), dp(hDp), g)
            lp.topMargin = dp(topDp)
            phoneFrame.addView(v, lp)
        }
        sideButton(Gravity.START, 110, 38)
        sideButton(Gravity.START, 160, 56)
        sideButton(Gravity.END, 150, 70)

        val card = column()
        card.setPadding(dp(14), dp(14), dp(14), dp(8))
        card.background = rounded(Color.parseColor("#2A2733"), 34)
        bezel.addView(card, LinearLayout.LayoutParams(match, wrap))
        val phoneLp = LinearLayout.LayoutParams(dp(312), wrap)
        phoneLp.gravity = Gravity.CENTER_HORIZONTAL
        phoneLp.topMargin = dp(14)
        c.addView(phoneFrame, phoneLp)

        // cabeçalho do celular: voltar | Liquid Audio | lupa (sessão: Automático / escolha manual)
        val phoneTop = LinearLayout(a)
        phoneTop.orientation = LinearLayout.HORIZONTAL
        phoneTop.gravity = Gravity.CENTER_VERTICAL
        val ivBack = ImageView(a)
        ivBack.setImageResource(R.drawable.ic_arrow_left)
        ivBack.setColorFilter(white)
        ivBack.setPadding(dp(4), dp(4), dp(4), dp(4))
        ivBack.setOnClickListener { sessCard.visibility = View.GONE }
        phoneTop.addView(ivBack, LinearLayout.LayoutParams(dp(30), dp(30)))
        val phoneTitle = label("Liquid Audio", 13f, white, true)
        phoneTitle.gravity = Gravity.CENTER
        phoneTop.addView(phoneTitle, LinearLayout.LayoutParams(0, wrap, 1f))
        val ivSearch = ImageView(a)
        ivSearch.setImageResource(R.drawable.ic_search)
        ivSearch.setColorFilter(white)
        ivSearch.setPadding(dp(4), dp(4), dp(4), dp(4))
        ivSearch.isClickable = true
        ivSearch.setOnClickListener {
            sessCard.visibility = if (sessCard.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        phoneTop.addView(ivSearch, LinearLayout.LayoutParams(dp(30), dp(30)))
        card.addView(phoneTop, LinearLayout.LayoutParams(match, wrap))
        val sessLp = LinearLayout.LayoutParams(match, wrap)
        sessLp.topMargin = dp(8)
        card.addView(sessCard, sessLp)

        // capa grande, quadrada, com moldura de vidro
        val coverBox = object : FrameLayout(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, widthMeasureSpec)
            }
        }
        coverBox.setPadding(dp(8), dp(8), dp(8), dp(8))
        coverBox.background = rounded(Color.parseColor("#26FFFFFF"), 26)
        val cover = ImageView(a)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        cover.background = rounded(Color.parseColor("#14FFFFFF"), 20)
        cover.clipToOutline = true
        cover.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(20).toFloat())
            }
        }
        coverBox.addView(cover, FrameLayout.LayoutParams(match, match))
        val coverIcon = ImageView(a)
        coverIcon.setImageResource(R.drawable.ic_music_note)
        coverIcon.setColorFilter(faintWhite)
        coverBox.addView(coverIcon, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        val coverLp = LinearLayout.LayoutParams(match, wrap)
        coverLp.topMargin = dp(10)
        coverLp.leftMargin = dp(6)
        coverLp.rightMargin = dp(6)
        card.addView(coverBox, coverLp)

        // título e artista
        val tvTitle = label("—", 18f, white, true)
        tvTitle.gravity = Gravity.CENTER
        tvTitle.maxLines = 1
        tvTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        tvTitle.setPadding(0, dp(14), 0, 0)
        card.addView(tvTitle, LinearLayout.LayoutParams(match, wrap))
        val tvArtist = label("", 13f, dimWhite)
        tvArtist.gravity = Gravity.CENTER
        tvArtist.maxLines = 1
        tvArtist.ellipsize = android.text.TextUtils.TruncateAt.END
        tvArtist.setPadding(0, dp(2), 0, 0)
        card.addView(tvArtist, LinearLayout.LayoutParams(match, wrap))

        // barra de progresso + tempos (só leitura: o app não expõe "ir para o tempo")
        val track = FrameLayout(a)
        track.background = rounded(Color.parseColor("#33FFFFFF"), 3)
        val fill = View(a)
        fill.background = rounded(white, 3)
        track.addView(fill, FrameLayout.LayoutParams(0, match))
        val trackLp = LinearLayout.LayoutParams(match, dp(5))
        trackLp.topMargin = dp(12)
        card.addView(track, trackLp)
        val times = LinearLayout(a)
        times.orientation = LinearLayout.HORIZONTAL
        val tvPos = label("0:00", 11f, dimWhite)
        val tvDur = label("--:--", 11f, dimWhite)
        tvDur.gravity = Gravity.END
        times.addView(tvPos, LinearLayout.LayoutParams(0, wrap, 1f))
        times.addView(tvDur, LinearLayout.LayoutParams(0, wrap, 1f))
        val timesLp = LinearLayout.LayoutParams(match, wrap)
        timesLp.topMargin = dp(4)
        card.addView(times, timesLp)

        // helpers de ícone / célula
        fun icon(res: Int, sizeDp: Int, tint: Int): ImageView {
            val iv = ImageView(a)
            iv.setImageResource(res)
            iv.setColorFilter(tint)
            iv.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
            return iv
        }

        fun cell(child: View, wrapWidth: Boolean = false, onClick: () -> Unit): LinearLayout {
            val w = LinearLayout(a)
            w.gravity = Gravity.CENTER
            w.setPadding(dp(4), dp(6), dp(4), dp(6))
            w.addView(child)
            w.isClickable = true
            w.setOnClickListener { onClick() }
            w.layoutParams = if (wrapWidth) LinearLayout.LayoutParams(wrap, wrap) else LinearLayout.LayoutParams(0, wrap, 1f)
            return w
        }

        // controles: aleatório | anterior | play/pause | próxima | repetir
        val ctrlRow = LinearLayout(a)
        ctrlRow.orientation = LinearLayout.HORIZONTAL
        ctrlRow.gravity = Gravity.CENTER_VERTICAL
        val ivShuffle = icon(R.drawable.ic_shuffle, 22, dimWhite)
        val ivPrev = icon(R.drawable.ic_media_prev, 28, white)
        val ivPlay = ImageView(a)
        ivPlay.setImageResource(R.drawable.ic_media_play)
        ivPlay.setColorFilter(Color.parseColor("#14181F"))
        ivPlay.setPadding(dp(15), dp(15), dp(15), dp(15))
        ivPlay.background = rounded(Color.parseColor("#EDE3FF"), 40)
        ivPlay.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        val ivNext = icon(R.drawable.ic_media_next, 28, white)
        val ivRepeat = icon(R.drawable.ic_repeat, 22, dimWhite)
        ctrlRow.addView(cell(ivShuffle) {
            if (shuffleIdx >= 0) {
                show("Aleatório", MediaSessionHub.customAction(shuffleIdx))
            } else {
                result.text = "Aleatório: ação não anunciada pelo app."
            }
        })
        ctrlRow.addView(cell(ivPrev) { show("Anterior", MediaSessionHub.previous(force)) })
        ctrlRow.addView(cell(ivPlay, true) { show("Play/Pause", MediaSessionHub.togglePlayPause(force)) })
        ctrlRow.addView(cell(ivNext) { show("Próxima", MediaSessionHub.next(force)) })
        ctrlRow.addView(cell(ivRepeat) {
            if (repeatIdx >= 0) {
                show("Repetir", MediaSessionHub.customAction(repeatIdx))
            } else {
                result.text = "Repetir: ação não anunciada pelo app."
            }
        })
        val ctrlLp = LinearLayout.LayoutParams(match, wrap)
        ctrlLp.topMargin = dp(8)
        card.addView(ctrlRow, ctrlLp)

        // fileira Salvar / Compartilhar / Forçar
        fun tile(res: Int, text: String, onClick: () -> Unit): Array<View> {
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.setPadding(dp(4), dp(10), dp(4), dp(8))
            val iv = icon(res, 20, white)
            col.addView(iv)
            val tv = label(text, 10f, dimWhite, true)
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(3), 0, 0)
            col.addView(tv)
            col.isClickable = true
            col.setOnClickListener { onClick() }
            col.layoutParams = LinearLayout.LayoutParams(0, wrap, 1f)
            return arrayOf(col, iv, tv)
        }

        val tileRow = LinearLayout(a)
        tileRow.orientation = LinearLayout.HORIZONTAL
        tileRow.background = rounded(Color.parseColor("#26FFFFFF"), 22)
        val tSave = tile(R.drawable.ic_heart, "Save") {
            if (likeIdx >= 0) {
                show("Gostei", MediaSessionHub.customAction(likeIdx))
            } else {
                result.text = "Gostei: ação não anunciada pelo app."
            }
        }
        val tShare = tile(R.drawable.ic_fm_share, "Share") {
            val txt = (curTitle + (if (curArtist.isBlank()) "" else " — $curArtist")).trim()
            if (txt.isEmpty()) {
                a.toast("Nenhuma música para compartilhar")
            } else {
                try {
                    val send = Intent(Intent.ACTION_SEND)
                    send.type = "text/plain"
                    send.putExtra(Intent.EXTRA_TEXT, txt)
                    a.startActivity(Intent.createChooser(send, "Compartilhar música").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    a.toast("Não foi possível compartilhar")
                }
            }
        }
        val tForce = tile(R.drawable.ic_device, "Device") { }
        fun paintForce() {
            (tForce[1] as ImageView).setColorFilter(if (force) ctl else white)
            (tForce[2] as TextView).setTextColor(if (force) ctl else dimWhite)
            tForce[0].background = if (force) rounded(Color.parseColor("#3319B4F0"), 22) else null
        }
        tForce[0].setOnClickListener {
            force = !force
            paintForce()
            result.text = if (force) "Device (forçar) ligado: ignora as ações anunciadas pelo app." else "Device (forçar) desligado."
        }
        tileRow.addView(tSave[0])
        tileRow.addView(tShare[0])
        tileRow.addView(tForce[0])
        val tileLp = LinearLayout.LayoutParams(match, wrap)
        tileLp.topMargin = dp(12)
        card.addView(tileRow, tileLp)
        result.textSize = 11f
        result.setPadding(0, dp(8), 0, 0)
        card.addView(result, LinearLayout.LayoutParams(match, wrap))

        // ---------------------------------------------------------------- barra de baixo do celular
        // Queue = acesso às notificações | Now Playing = atualizar | Lyrics = abrir o aplicativo selecionado
        fun navItem(res: Int, text: String, onClick: () -> Unit): View {
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.setPadding(dp(4), dp(8), dp(4), dp(6))
            col.addView(icon(res, 22, dimWhite))
            val tv = label(text, 10f, dimWhite, true)
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.setPadding(0, dp(3), 0, 0)
            col.addView(tv)
            col.isClickable = true
            col.setOnClickListener { onClick() }
            col.layoutParams = LinearLayout.LayoutParams(0, wrap, 1f)
            return col
        }

        val nav = LinearLayout(a)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.addView(navItem(R.drawable.ic_queue, "Queue") {
            try {
                a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir as configurações")
            }
        })
        nav.addView(navItem(R.drawable.ic_now_playing, "Now Playing") { onRefresh() })
        nav.addView(navItem(R.drawable.ic_lyrics, "Lyrics") {
            if (!MediaSessionHub.openApp()) {
                a.toast("Escolha primeiro um app na lista de sessões")
            }
        })
        val navLp = LinearLayout.LayoutParams(match, wrap)
        navLp.topMargin = dp(6)
        card.addView(nav, navLp)

        // ---------------------------------------------------------------- diagnóstico (recolhível)
        val diagHead = label("▸ Diagnóstico detalhado", 13f, ink, true)
        diagHead.setPadding(0, dp(16), 0, dp(4))
        diagHead.isClickable = true
        c.addView(diagHead)
        val info = label("", 12.5f, ink)
        info.setPadding(0, dp(4), 0, 0)
        info.visibility = View.GONE
        c.addView(info)
        diagHead.setOnClickListener {
            val open = info.visibility != View.VISIBLE
            info.visibility = if (open) View.VISIBLE else View.GONE
            diagHead.text = if (open) "▾ Diagnóstico detalhado" else "▸ Diagnóstico detalhado"
        }

        // ---------------------------------------------------------------- lógica original de texto/sessões
        fun mark(ok: Boolean) = if (ok) "✔" else "✘"
        fun stateName(code: Int): String = when (code) {
            -1 -> "sem estado"
            android.media.session.PlaybackState.STATE_NONE -> "NONE"
            android.media.session.PlaybackState.STATE_STOPPED -> "STOPPED"
            android.media.session.PlaybackState.STATE_PAUSED -> "PAUSED"
            android.media.session.PlaybackState.STATE_PLAYING -> "PLAYING"
            android.media.session.PlaybackState.STATE_BUFFERING -> "BUFFERING"
            android.media.session.PlaybackState.STATE_ERROR -> "ERROR"
            else -> "código $code"
        }

        fun item(text: String, selected: Boolean, onClick: () -> Unit) {
            val tv = TextView(a)
            tv.text = text
            tv.textSize = 12f
            tv.setTextColor(if (selected) Color.WHITE else ink)
            tv.background = box(if (selected) accHex else rowBg, 6)
            tv.setPadding(dp(10), dp(8), dp(10), dp(8))
            tv.isClickable = true
            tv.setOnClickListener {
                onClick()
                sessCard.visibility = View.GONE
            }
            val lp = LinearLayout.LayoutParams(match, wrap)
            lp.topMargin = dp(4)
            sessBox.addView(tv, lp)
        }

        fun whyNone(s: MediaSessionHub.State): String = when {
            !s.access ->
                "Sem acesso às notificações: o Android só mostra as sessões de mídia para apps com esse acesso. " +
                    "Use o botão \"Abrir acesso às notificações do Android\", ative o WinLauncher e volte aqui. " +
                    "Se a opção estiver bloqueada (Android 13 ou superior): Configurações > Apps > WinLauncher > ⋮ > Permitir configurações restritas."
            s.selectedPkg.isNotEmpty() ->
                "O app escolhido (${s.selectedPkg}) não tem sessão de mídia ativa. Abra-o e toque uma música."
            s.sessions.isEmpty() ->
                "Nenhum app está publicando sessão de mídia. Abra o app de música e toque uma música. " +
                    "Se já está tocando e nada aparece: desligue e ligue de novo o acesso do WinLauncher às notificações, " +
                    "e deixe o WinLauncher e o app de música sem economia de bateria."
            else ->
                "Há sessões de mídia ativas, mas nenhuma parece YouTube Music. Escolha uma na lista acima (o pacote real aparece em cada item)."
        }

        // ---------------------------------------------------------------- progresso (relógio local entre as atualizações do app)
        var posBase = 0L
        var posAt = 0L
        var durMs = 0L
        var isPlaying = false
        var speed = 1f

        fun fmt(ms: Long): String {
            val sec = if (ms < 0L) 0L else ms / 1000L
            return "%d:%02d".format(sec / 60L, sec % 60L)
        }

        fun tick() {
            val now = android.os.SystemClock.elapsedRealtime()
            var pos = posBase + (if (isPlaying) ((now - posAt) * speed).toLong() else 0L)
            if (durMs > 0L && pos > durMs) pos = durMs
            if (pos < 0L) pos = 0L
            tvPos.text = fmt(pos)
            tvDur.text = if (durMs > 0L) fmt(durMs) else "--:--"
            val frac = if (durMs > 0L) pos.toFloat() / durMs.toFloat() else 0f
            val lp = fill.layoutParams
            val w = (track.width * frac).toInt()
            if (lp.width != w) {
                lp.width = w
                fill.layoutParams = lp
            }
        }

        // cor do cartão a partir da capa
        var tintedFor: Bitmap? = null
        fun tintCard(b: Bitmap?) {
            if (b === tintedFor) return
            tintedFor = b
            var topColor = Color.parseColor("#3A3547")
            if (b != null) {
                try {
                    val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
                    val r = (Color.red(px) * 0.55f).toInt()
                    val g = (Color.green(px) * 0.55f).toInt()
                    val bl = (Color.blue(px) * 0.55f).toInt()
                    topColor = Color.rgb(r, g, bl)
                } catch (e: Exception) {
                }
            }
            val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(topColor, Color.parseColor("#17151D")))
            g.cornerRadius = dp(34).toFloat()
            card.background = g
        }

        fun lower(s: String) = s.lowercase()

        fun render(s: MediaSessionHub.State) {
            val sb = StringBuilder()
            sb.append(mark(s.access)).append(" Acesso às notificações\n")
            sb.append(mark(s.hasSession)).append(" Sessão de música encontrada\n")
            if (s.hasSession) {
                sb.append("App: ").append(s.appLabel).append('\n')
                sb.append("Pacote: ").append(s.pkg).append('\n')
                sb.append("Modo: ").append(if (s.manual) "escolha manual" else "automático").append('\n')
                sb.append("Estado: ").append(stateName(s.stateCode)).append('\n')
                sb.append(mark(s.title.isNotBlank())).append(" Título: ").append(if (s.title.isBlank()) "—" else s.title).append('\n')
                sb.append(mark(s.artist.isNotBlank())).append(" Artista: ").append(if (s.artist.isBlank()) "—" else s.artist).append('\n')
                sb.append("Álbum: ").append(if (s.album.isBlank()) "—" else s.album).append('\n')
                sb.append(mark(s.art != null)).append(" Capa: ").append(s.artInfo).append('\n')
                sb.append(mark(s.canPlay)).append(" Play anunciado  ")
                sb.append(mark(s.canPause)).append(" Pause anunciado\n")
                sb.append(mark(s.canNext)).append(" Próxima anunciada  ")
                sb.append(mark(s.canPrev)).append(" Anterior anunciada\n")
                sb.append("Ações (bruto): 0x").append(s.actions.toString(16)).append('\n')
                if (s.customActions.isNotEmpty()) sb.append("Ações extras: ").append(s.customActions.joinToString(", ")).append('\n')
            } else {
                sb.append(whyNone(s)).append('\n')
            }
            info.text = sb.toString().trimEnd()
            cover.setImageBitmap(s.art)
            coverIcon.visibility = if (s.art == null) View.VISIBLE else View.GONE

            // player
            curTitle = s.title
            curArtist = s.artist
            tvTitle.text = if (s.title.isBlank()) (if (s.hasSession) "Sem título" else "Nada tocando") else s.title
            tvArtist.text = if (s.artist.isBlank()) (if (s.hasSession) s.appLabel else "Abra um app de música") else s.artist
            ivPlay.setImageResource(if (s.playing) R.drawable.ic_media_pause else R.drawable.ic_media_play)
            ivPrev.alpha = if (s.hasSession && (s.canPrev || force)) 1f else 0.4f
            ivNext.alpha = if (s.hasSession && (s.canNext || force)) 1f else 0.4f
            ivPlay.alpha = if (s.hasSession) 1f else 0.5f
            tintCard(s.art)

            // lupa + título da lista: mostra a sessão controlada (Automático ou escolha manual)
            val sessName = when {
                s.manual -> if (s.appLabel.isNotBlank()) s.appLabel else s.selectedPkg
                s.hasSession -> "Automático · " + s.appLabel
                else -> "Automático"
            }
            sessTitle.text = "Sessão controlada: " + sessName
            ivSearch.setColorFilter(if (s.manual) ctl else white)

            // ações extras -> aleatório / repetir / gostei
            shuffleIdx = -1
            repeatIdx = -1
            likeIdx = -1
            shuffleOn = false
            repeatOn = false
            liked = false
            for (i in s.customActions.indices) {
                val n = lower(s.customActions[i])
                val off = n.contains("desativ") || n.contains(" off")
                if (shuffleIdx < 0 && (n.contains("aleat") || n.contains("shuffle"))) {
                    shuffleIdx = i
                    shuffleOn = !off
                } else if (repeatIdx < 0 && (n.contains("repet") || n.contains("repeat"))) {
                    repeatIdx = i
                    repeatOn = !off
                } else if (likeIdx < 0 && !n.contains("não") && !n.contains("dislike") &&
                    (n.contains("gostei") || n.contains("like") || n.contains("salvar") || n.contains("save"))
                ) {
                    likeIdx = i
                    liked = n.contains("remov") || n.contains("desmarc") || n.contains("unlike")
                }
            }
            ivShuffle.setColorFilter(if (shuffleIdx < 0) faintWhite else if (shuffleOn) ctl else dimWhite)
            ivRepeat.setColorFilter(if (repeatIdx < 0) faintWhite else if (repeatOn) ctl else dimWhite)
            (tSave[1] as ImageView).setImageResource(if (liked) R.drawable.ic_heart_filled else R.drawable.ic_heart)
            (tSave[1] as ImageView).setColorFilter(if (likeIdx < 0) faintWhite else if (liked) ctl else white)
            (tSave[2] as TextView).setTextColor(if (likeIdx < 0) faintWhite else dimWhite)

            // progresso
            posBase = s.positionMs
            posAt = android.os.SystemClock.elapsedRealtime()
            durMs = s.durationMs
            isPlaying = s.playing
            speed = s.speed
            tick()

            // lista de sessões / apps instalados parecidos
            sessBox.removeAllViews()
            item(
                "Automático" + (if (!s.manual && s.hasSession) " — usando: ${s.appLabel}" else ""),
                !s.manual
            ) { MediaSessionHub.select(null) }
            val shown = HashSet<String>()
            for (x in s.sessions) {
                shown.add(x.pkg)
                val tags = ArrayList<String>()
                if (x.ytLike) tags.add("parece YouTube Music")
                if (x.own) tags.add("player da WinLauncher")
                val line2 = (if (x.playing) "tocando" else "pausado/parado") +
                    (if (x.title.isNotBlank()) " — " + x.title else "")
                item(
                    x.label + "\n" + x.pkg + "\n" + line2 + (if (tags.isEmpty()) "" else "\n" + tags.joinToString(" · ")),
                    s.selectedPkg == x.pkg
                ) { MediaSessionHub.select(x.pkg) }
            }
            if (s.selectedPkg.isNotEmpty() && s.selectedPkg !in shown) {
                shown.add(s.selectedPkg)
                item(s.selectedPkg + "\nescolhido, sem sessão ativa agora", true) { }
            }
            for (x in installed) {
                if (x.pkg in shown) continue
                shown.add(x.pkg)
                item(x.label + "\n" + x.pkg + "\ninstalado, sem sessão ativa · parece YouTube Music", s.selectedPkg == x.pkg) {
                    MediaSessionHub.select(x.pkg)
                }
            }
        }

        onRefresh = {
            MediaSessionHub.refresh()
            installed = MediaSessionHub.installedCandidates()
            render(MediaSessionHub.state())
        }

        paintForce()

        // acompanha as sessões só enquanto esta página está na tela
        val l = object : MediaSessionHub.Listener {
            override fun onMediaState(s: MediaSessionHub.State) {
                render(s)
            }
        }
        val ticker = object : Runnable {
            override fun run() {
                tick()
                c.postDelayed(this, 500L)
            }
        }
        c.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                MediaSessionHub.addListener(l)
                MediaSessionHub.start(a)
                installed = MediaSessionHub.installedCandidates()
                render(MediaSessionHub.state())
                c.removeCallbacks(ticker)
                c.postDelayed(ticker, 500L)
            }

            override fun onViewDetachedFromWindow(v: View) {
                c.removeCallbacks(ticker)
                MediaSessionHub.removeListener(l)
                MediaSessionHub.stop()
            }
        })
        render(MediaSessionHub.state())
        return c
    }

    // ------------------------------------------------------------ componentes estilo Configurações do Windows 11

    private class WinRow(val root: LinearLayout, val title: TextView, val sub: TextView, val right: LinearLayout)

    private fun winBg(fill: String, stroke: String?, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.cornerRadius = dp(r).toFloat()
        if (stroke != null) g.setStroke(dp(1), Color.parseColor(stroke))
        return g
    }

    /** Cartão arredondado com borda fina; as linhas entram dentro dele. */
    private fun winCard(parent: LinearLayout): LinearLayout {
        val card = column()
        card.background = winBg("#1AFFFFFF", "#14FFFFFF", 8)
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(6)
        parent.addView(card, lp)
        return card
    }

    private fun winSection(parent: LinearLayout, text: String) {
        val tv = label(text, 13f, ink, true)
        tv.setPadding(dp(2), dp(16), 0, dp(2))
        parent.addView(tv)
    }

    private fun winDivider(parent: LinearLayout) {
        val v = View(a)
        v.setBackgroundColor(Color.parseColor("#14FFFFFF"))
        parent.addView(v, LinearLayout.LayoutParams(match, dp(1)))
    }

    /** Linha horizontal vazia dentro do cartão (com divisória em cima, se não for a primeira). */
    private fun winRowRaw(parent: LinearLayout): LinearLayout {
        if (parent.childCount > 0) winDivider(parent)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(9), dp(16), dp(9))
        row.minimumHeight = dp(50)
        parent.addView(row, LinearLayout.LayoutParams(match, wrap))
        return row
    }

    /** Linha padrão: ícone, título, descrição pequena e uma área à direita para botões/valores. */
    private fun winRow(parent: LinearLayout, iconRes: Int, title: String, subtitle: String): WinRow {
        val row = winRowRaw(parent)
        if (iconRes != 0) {
            val iv = ImageView(a)
            iv.setImageResource(iconRes)
            iv.setColorFilter(ink)
            val ilp = LinearLayout.LayoutParams(dp(20), dp(20))
            ilp.rightMargin = dp(14)
            row.addView(iv, ilp)
        }
        val col = column()
        val t = label(title, 13f, ink)
        val s = label(subtitle, 11.5f, sub)
        s.setPadding(0, dp(1), 0, 0)
        if (subtitle.isEmpty()) s.visibility = View.GONE
        col.addView(t)
        col.addView(s)
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        val right = LinearLayout(a)
        right.orientation = LinearLayout.HORIZONTAL
        right.gravity = Gravity.CENTER_VERTICAL
        val rlp = LinearLayout.LayoutParams(wrap, wrap)
        rlp.leftMargin = dp(12)
        row.addView(right, rlp)
        return WinRow(row, t, s, right)
    }

    /** kind: 0 = normal, 1 = principal (azul), 2 = perigo (vermelho), 3 = confirmar (verde). */
    private fun winBtn(text: String, kind: Int, enabled: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(a)
        b.text = text
        b.textSize = 12.5f
        b.gravity = Gravity.CENTER
        b.setPadding(dp(14), 0, dp(14), 0)
        when (kind) {
            1 -> {
                b.setTextColor(Color.parseColor("#001A26"))
                b.typeface = Typeface.DEFAULT_BOLD
                b.background = winBg(accHex, null, 5)
            }
            2 -> {
                b.setTextColor(Color.parseColor("#FF6B6B"))
                b.background = winBg("#14FF6B6B", "#55FF6B6B", 5)
            }
            3 -> {
                b.setTextColor(Color.WHITE)
                b.typeface = Typeface.DEFAULT_BOLD
                b.background = winBg("#2E9B4F", null, 5)
            }
            else -> {
                b.setTextColor(ink)
                b.background = winBg("#1AFFFFFF", "#26FFFFFF", 5)
            }
        }
        b.alpha = if (enabled) 1f else 0.45f
        if (enabled) {
            b.isClickable = true
            b.setOnClickListener { onClick() }
        }
        return b
    }

    private fun addBtn(row: WinRow, b: View) {
        val lp = LinearLayout.LayoutParams(wrap, dp(32))
        lp.leftMargin = dp(8)
        row.right.addView(b, lp)
    }

    /** Selo de estado (ex.: "Ligado"). [hex] sem "#", ex.: "6CCB5F". */
    private fun winPill(text: String, hex: String): TextView {
        val tv = label(text, 11.5f, Color.parseColor("#$hex"), true)
        tv.setPadding(dp(10), dp(3), dp(10), dp(3))
        tv.background = winBg("#26$hex", null, 12)
        return tv
    }

    private fun setPill(tv: TextView, text: String, hex: String) {
        tv.text = text
        tv.setTextColor(Color.parseColor("#$hex"))
        tv.background = winBg("#26$hex", null, 12)
    }

    private fun winValue(row: WinRow, text: String, mono: Boolean = false): TextView {
        val v = label(text, 12.5f, sub)
        v.gravity = Gravity.END
        if (mono) v.typeface = Typeface.MONOSPACE
        row.right.addView(v)
        return v
    }

    /** Texto solto dentro do cartão, alinhado com as linhas. */
    private fun winPadText(parent: LinearLayout, text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = label(text, size, color, bold)
        tv.setPadding(dp(16), dp(8), dp(16), dp(10))
        parent.addView(tv)
        return tv
    }

    /** Célula "rótulo + valor" da grade de 3 colunas. */
    private fun winKv(parent: LinearLayout, title: String, withLeftLine: Boolean): TextView {
        val col = column()
        col.setPadding(dp(16), dp(9), dp(12), dp(9))
        col.addView(label(title, 11.5f, sub))
        val v = label("—", 13f, ink)
        col.addView(v)
        if (withLeftLine) {
            val line = View(a)
            line.setBackgroundColor(Color.parseColor("#14FFFFFF"))
            parent.addView(line, LinearLayout.LayoutParams(dp(1), match))
        }
        parent.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        return v
    }

    private fun winGridRow(parent: LinearLayout): LinearLayout {
        if (parent.childCount > 0) winDivider(parent)
        val g = LinearLayout(a)
        g.orientation = LinearLayout.HORIZONTAL
        parent.addView(g, LinearLayout.LayoutParams(match, wrap))
        return g
    }

    /**
     * Página TEMPORÁRIA de diagnóstico da Etapa 3A do WinLauncher Remote: chave no Android Keystore,
     * hash do certificado, assinatura/verificação e criação do SSLContext. Não existe servidor TLS ainda.
     */
    private fun remoteDiagPanel(): View {
        RemoteAuth.init(a)
        val c = column()

        val okColor = Color.parseColor("#2E9B4F")
        val badColor = Color.parseColor("#D13438")
        val handler = android.os.Handler(android.os.Looper.getMainLooper())

        // cartão da chave
        val keyCard = winCard(c)
        val keyRow = winRow(keyCard, R.drawable.ic_rm_shield, "Chave do WinLauncher Remote", "Lendo o estado da chave…")
        val pill = winPill("…", "A9B3C6")
        keyRow.right.addView(pill)
        val aliasRow = winRow(keyCard, R.drawable.ic_rm_key, "Alias", "")
        val aliasV = winValue(aliasRow, "—", true)
        val validRow = winRow(keyCard, R.drawable.ic_rm_calendar, "Certificado válido", "")
        val validV = winValue(validRow, "—")
        val pairedRow = winRow(keyCard, R.drawable.ic_rm_link, "Pareamentos salvos", "")
        val pairedV = winValue(pairedRow, "—")
        val regenRow = winRow(keyCard, R.drawable.ic_rm_history, "Última regeneração", "Nenhuma")

        // hash
        winSection(c, "Hash do certificado (SHA-256)")
        val hashCard = winCard(c)
        val hashRowV = winRowRaw(hashCard)
        val hashTv = label("—", 12f, ink)
        hashTv.typeface = Typeface.MONOSPACE
        hashRowV.addView(hashTv, LinearLayout.LayoutParams(0, wrap, 1f))

        val result = label("", 12f, ink)
        result.setPadding(dp(2), dp(12), 0, 0)

        var fullHash = ""
        var busy = false
        var armed = false

        fun showKey(r: RemoteAuth.KeyReport?, paired: Int) {
            if (r == null) {
                setPill(pill, "Sem chave", "FF6B6B")
                keyRow.sub.text = "Chave: ainda não criada. Toque em \"Executar\" no autoteste para criar."
                aliasV.text = "—"
                validV.text = "—"
                pairedV.text = paired.toString()
                regenRow.sub.text = RemoteAuth.lastRegenInfo() ?: "Nenhuma"
                hashTv.text = "—"
                fullHash = ""
                return
            }
            setPill(pill, "● Chave segura", "6CCB5F")
            val sb = StringBuilder()
            sb.append(r.algorithm)
            if (r.usedFallback) sb.append(" (alternativa: o EC P-256 falhou neste aparelho)")
            sb.append(" · Local: ").append(r.securityLevel)
            if (r.pairingsCleared > 0) {
                sb.append("\n⚠ ").append(r.pairingsCleared).append(" pareamento(s) foram apagados porque a chave mudou: será preciso parear de novo.")
            }
            keyRow.sub.text = sb.toString()
            aliasV.text = RemoteAuth.ALIAS
            val df = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.ROOT)
            validV.text = df.format(r.notBefore) + " até " + df.format(r.notAfter)
            pairedV.text = paired.toString()
            regenRow.sub.text = RemoteAuth.lastRegenInfo() ?: "Nenhuma"
            hashTv.text = RemoteAuth.formatFingerprint(r.fingerprint)
            fullHash = RemoteAuth.formatFingerprint(r.fingerprint).replace("\n", ":")
        }

        fun showTest(t: RemoteAuth.SelfTestResult) {
            val sb = StringBuilder()
            for (ch in t.checks) {
                val mark = if (ch.essential) (if (ch.ok) "✔" else "✘") else (if (ch.ok) "ℹ" else "⚠")
                sb.append(mark).append(' ').append(ch.name)
                if (ch.detail.isNotBlank()) sb.append("\n    ").append(ch.detail)
                sb.append('\n')
            }
            sb.append('\n')
            sb.append(
                if (t.essentialOk) "RESULTADO: todos os testes essenciais passaram."
                else "RESULTADO: FALHOU. Veja os itens ✘ acima."
            )
            sb.append("\nLembrete: SSLContext criado não prova que o servidor TLS funciona; o handshake real fica para a Etapa 3B.")
            result.text = sb.toString()
            result.setTextColor(if (t.essentialOk) okColor else badColor)
            showKey(t.report, RemoteAuth.pairedList().size)
        }

        fun regenSummary(r: RemoteAuth.RegenReport): String {
            val oldFp = r.oldFingerprint
            val sb = StringBuilder()
            sb.append("✔ CHAVE REGENERADA COM SUCESSO\n")
            sb.append("Chave antiga apagada do Keystore: sim (conferido)\n")
            sb.append("Nova chave e novo certificado criados: ").append(r.key.algorithm).append(", ").append(r.key.securityLevel).append('\n')
            sb.append("Hash antigo: ").append(if (oldFp == null) "(não havia chave)" else RemoteAuth.shortFingerprint(oldFp) + "…").append('\n')
            sb.append("Hash novo:   ").append(RemoteAuth.shortFingerprint(r.key.fingerprint)).append("… (lido do certificado novo)\n")
            sb.append("Serial: ").append(r.oldSerial ?: "—").append(" → ").append(r.newSerial).append('\n')
            sb.append("Pareamentos: ").append(r.pairingsBefore).append(" antes, ").append(r.pairingsAfter).append(" depois.\n")
            sb.append("TODOS os celulares pareados antes precisarão ser pareados de novo.")
            return sb.toString()
        }

        fun runTest(afterRegen: RemoteAuth.RegenReport?) {
            if (busy) return
            busy = true
            result.setTextColor(ink)
            result.text = "Executando o autoteste…"
            Thread {
                val t = try {
                    RemoteAuth.selfTest()
                } catch (e: Throwable) {
                    RemoteAuth.SelfTestResult(
                        listOf(RemoteAuth.Check("Autoteste", false, e.javaClass.simpleName + ": " + (e.message ?: ""))), null
                    )
                }
                a.runOnUiThread {
                    busy = false
                    showTest(t)
                    if (afterRegen != null) {
                        result.text = regenSummary(afterRegen) + "\n\n" + result.text
                    }
                }
            }.start()
        }

        fun copyHash() {
            if (fullHash.isEmpty()) {
                a.toast("Ainda não há certificado. Execute o autoteste.")
            } else {
                val cm = a.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Hash SHA-256 do certificado", fullHash))
                a.toast("Hash copiado")
            }
        }

        fun regenerate() {
            if (busy) return
            // estado real do servidor (não depende de botão desabilitado)
            val blockedNow = RemoteAuth.regenBlockedReason()
            if (blockedNow != null) {
                armed = false
                handler.removeCallbacksAndMessages(null)
                result.setTextColor(badColor)
                result.text = "✘ $blockedNow"
                a.toast("Desligue o servidor antes de regenerar a chave")
                return
            }
            if (!armed) {
                armed = true
                result.setTextColor(badColor)
                result.text = "⚠ Regenerar cria um novo certificado e APAGA todos os pareamentos: os celulares já pareados " +
                    "precisarão ser pareados de novo. Toque em \"Regenerar\" mais uma vez em até 8 segundos para confirmar."
                handler.postDelayed({
                    if (armed) {
                        armed = false
                        result.setTextColor(ink)
                        result.text = "Regeneração cancelada."
                    }
                }, 8000)
            } else {
                armed = false
                handler.removeCallbacksAndMessages(null)
                busy = true
                result.setTextColor(ink)
                result.text = "Regenerando a chave…"
                Thread {
                    var rep: RemoteAuth.RegenReport? = null
                    var err = ""
                    try {
                        rep = RemoteAuth.regenerate()
                    } catch (e: RemoteAuth.RegenBlockedException) {
                        // o servidor foi ligado entre o toque e a execução: nada foi alterado
                        val msg = e.message ?: ""
                        a.runOnUiThread {
                            busy = false
                            result.setTextColor(badColor)
                            result.text = "✘ $msg"
                        }
                        return@Thread
                    } catch (e: Throwable) {
                        err = e.javaClass.simpleName + ": " + (e.message ?: "")
                    }
                    val done = rep
                    // estado real depois da tentativa (lido de novo do Keystore, nada em cache)
                    var cur: RemoteAuth.KeyReport? = null
                    var n = 0
                    try {
                        cur = RemoteAuth.inspect()
                        n = RemoteAuth.pairedList().size
                    } catch (e: Throwable) {
                    }
                    val cur0 = cur
                    val n0 = n
                    a.runOnUiThread {
                        busy = false
                        if (done == null) {
                            result.setTextColor(badColor)
                            result.text = "✘ REGENERAÇÃO FALHOU\nMotivo: $err\n" +
                                "Estado atual: " + (if (cur0 == null) "não há chave no Keystore" else "há uma chave " + cur0.algorithm) +
                                "; pareamentos salvos: $n0.\n" +
                                "Se a chave antiga foi apagada, os pareamentos antigos também foram apagados."
                            showKey(cur0, n0)
                        } else {
                            showKey(done.key, n0)
                            runTest(done)
                        }
                    }
                }.start()
            }
        }

        // botão Copiar ao lado do hash
        val copyLp = LinearLayout.LayoutParams(wrap, dp(32))
        copyLp.leftMargin = dp(12)
        val copyBtn = winBtn("Copiar", 0) { copyHash() }
        hashRowV.addView(copyBtn, copyLp)

        // ações
        winSection(c, "Ações")
        val actCard = winCard(c)
        val testRow = winRow(actCard, R.drawable.ic_rm_play, "Executar autoteste", "Testa a chave, a assinatura, a verificação e o SSLContext")
        addBtn(testRow, winBtn("Executar", 1) { runTest(null) })
        val regRow = winRow(actCard, R.drawable.ic_rm_history, "Regenerar chave", "Os pareamentos anteriores são apagados e precisam ser refeitos")
        regRow.root.getChildAt(0).let { (it as? ImageView)?.setColorFilter(Color.parseColor("#FF6B6B")) }
        addBtn(regRow, winBtn("Regenerar", 2) { regenerate() })
        c.addView(result)

        note(c, "Página temporária. Testa a chave no Android Keystore, a assinatura, a verificação e a criação do SSLContext. " +
            "Ainda não existe servidor TLS: o SSLContext criado aqui NÃO prova que o TLS funciona (isso só será testado na Etapa 3B).")
        note(c, "Se a chave for regenerada (ou sumir, por exemplo após restaurar um backup), os pareamentos anteriores são apagados e precisam ser refeitos.")

        // estado inicial, só leitura (não cria chave)
        Thread {
            var rep: RemoteAuth.KeyReport? = null
            var n = 0
            try {
                rep = RemoteAuth.inspect()
                n = RemoteAuth.pairedList().size
            } catch (e: Throwable) {
            }
            val r0 = rep
            val n0 = n
            a.runOnUiThread { showKey(r0, n0) }
        }.start()
        return c
    }

    /**
     * Painel do servidor do WinLauncher Remote (Etapa 3B). Parte 1: liga/desliga o servidor TLS local, mostra estado, IP,
     * porta, hash curto do certificado, erros e roda o autoteste do servidor. Parte 2: opção de início automático,
     * pareamento (janela de 2 min, número de 6 dígitos, Permitir/Negar), lista de aparelhos pareados com remoção e
     * autoteste da integração (pareamento, autenticação, comandos, capa, revogação e limite de tentativas).
     */
    private fun remoteServerPanel(): View {
        RemoteAuth.init(a)
        val c = column()

        val okColor = Color.parseColor("#2E9B4F")
        val badColor = Color.parseColor("#D13438")

        // ---------------------------------------------------------------- cartão principal: estado + ligar/desligar
        val mainCard = winCard(c)
        val mainRow = winRow(mainCard, R.drawable.ic_rm_power, "Servidor do WinLauncher Remote", "TLS local · só aceita conexões da sua rede local")
        val pill = winPill("…", "A9B3C6")
        mainRow.right.addView(pill)

        // botão ligar/desligar (o texto muda com o estado)
        val toggle = winBtn("Ligar servidor", 0) { }
        addBtn(mainRow, toggle)

        val errTv = label("", 12f, badColor, true)
        errTv.setPadding(dp(16), dp(8), dp(16), dp(8))
        errTv.visibility = View.GONE
        mainCard.addView(errTv)

        val g1 = winGridRow(mainCard)
        val portV = winKv(g1, "Porta", false)
        val ipV = winKv(g1, "IP local", true)
        val clientsV = winKv(g1, "Clientes", true)
        val g2 = winGridRow(mainCard)
        val wifiV = winKv(g2, "WifiLock", false)
        val protoV = winKv(g2, "Protocolo", true)
        val hashTv = winKv(g2, "Certificado SHA-256", true)
        hashTv.typeface = Typeface.MONOSPACE

        val warnTv = label("", 11.5f, sub)
        warnTv.setPadding(dp(16), dp(8), dp(16), dp(8))
        warnTv.visibility = View.GONE
        mainCard.addView(warnTv)

        val autoRow = winRow(
            mainCard, R.drawable.ic_bolt, "Iniciar o servidor junto com o WinLauncher",
            "Desligado por padrão. Quando ligado, o servidor sobe sozinho sempre que o WinLauncher abrir (não há início com o " +
                "celular desligado: só quando o launcher abre). Desligar esta opção não derruba um servidor que já está ligado."
        )
        val autoSw = Switch(a)
        autoSw.isChecked = p.remoteAutostart
        autoSw.setOnCheckedChangeListener { _, v ->
            p.remoteAutostart = v
            onTap?.invoke()
        }
        autoRow.right.addView(autoSw)

        // ---------------------------------------------------------------- pareamento (Parte 2)
        winSection(c, "Pareamento")
        val pairBox = winCard(c)
        var armedId = ""
        var armedAt = 0L
        var timeTv: TextView? = null
        var timeText: ((RemoteBridge.Info) -> String)? = null

        fun mmss(ms: Long): String {
            val sec = ((ms + 999L) / 1000L).toInt().coerceAtLeast(0)
            return String.format(java.util.Locale.ROOT, "%d:%02d", sec / 60, sec % 60)
        }

        fun fmtCode(code: String): String = if (code.length == 6) code.substring(0, 3) + " " + code.substring(3) else code

        fun refreshPairing() {
            pairBox.removeAllViews()
            timeTv = null
            timeText = null
            val running = RemoteServerService.status.state == RemoteServer.State.RUNNING
            val info = RemoteServerService.bridgeInfo()
            val pending = info?.pending
            if (info != null && pending != null) {
                val t = winRow(pairBox, R.drawable.ic_rm_phone, "Pedido de pareamento", "\"" + pending.deviceName + "\" (" + pending.address + ")")
                t.title.typeface = Typeface.DEFAULT_BOLD
                val codeTv = label(fmtCode(pending.code), 30f, ink, true)
                codeTv.typeface = Typeface.MONOSPACE
                codeTv.gravity = Gravity.CENTER
                codeTv.background = winBg("#14FFFFFF", null, 6)
                codeTv.setPadding(dp(10), dp(12), dp(10), dp(12))
                val codeLp = LinearLayout.LayoutParams(match, wrap)
                codeLp.setMargins(dp(16), dp(4), dp(16), 0)
                pairBox.addView(codeTv, codeLp)
                val fmt: (RemoteBridge.Info) -> String = { i ->
                    "Confira se este número é IGUAL ao que aparece no celular que está pareando (restam " +
                        mmss(i.pending?.leftMs ?: 0L) + "). Se for diferente, ou se você não reconhece o aparelho, toque em Negar."
                }
                val n = winPadText(pairBox, fmt(info), 11.5f, sub)
                timeTv = n
                timeText = fmt
                val btns = LinearLayout(a)
                btns.orientation = LinearLayout.HORIZONTAL
                btns.setPadding(dp(16), dp(2), dp(16), dp(12))
                val b1 = winBtn("Permitir", 3) {
                    if (!RemoteServerService.approvePairing()) a.toast("O pedido expirou")
                    refreshPairing()
                }
                val b2 = winBtn("Negar", 2) {
                    RemoteServerService.denyPairing()
                    refreshPairing()
                }
                val l1 = LinearLayout.LayoutParams(0, dp(34), 1f)
                l1.rightMargin = dp(8)
                btns.addView(b1, l1)
                btns.addView(b2, LinearLayout.LayoutParams(0, dp(34), 1f))
                pairBox.addView(btns)
            } else if (info != null && info.windowOpen) {
                val fmt: (RemoteBridge.Info) -> String = { i ->
                    "Pareamento aberto por mais " + mmss(i.windowLeftMs) +
                        ". No WinLauncher Remote, escolha este aparelho e peça para parear. Nenhum pedido chegou ainda."
                }
                val r = winRow(pairBox, R.drawable.ic_rm_plus, "Pareamento aberto", fmt(info))
                timeTv = r.sub
                timeText = fmt
                addBtn(r, winBtn("Cancelar pareamento", 0) {
                    RemoteServerService.closePairing()
                    refreshPairing()
                })
            } else {
                val r = winRow(
                    pairBox, R.drawable.ic_rm_plus, "Permitir novo pareamento",
                    if (running) "Compare o número nos dois celulares e toque em Permitir" else "Ligue o servidor para parear um novo aparelho."
                )
                addBtn(r, winBtn("Permitir (2 min)", 1, running) {
                    if (!RemoteServerService.openPairing()) a.toast("Ligue o servidor primeiro")
                    refreshPairing()
                })
            }

            val paired: List<RemoteAuth.Paired> = info?.paired ?: try {
                RemoteAuth.pairedList()
            } catch (e: Throwable) {
                emptyList()
            }
            val connected: Set<String> = info?.connectedIds ?: emptySet()
            winDivider(pairBox)
            winPadText(pairBox, "Aparelhos pareados (" + paired.size + ")", 12.5f, ink, true)
            if (paired.isEmpty()) {
                winPadText(pairBox, "Nenhum aparelho pareado.", 12f, sub)
            }
            val df = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
            for (d in paired) {
                val when0 = if (d.id in connected) "conectado agora" else "pareado em " + df.format(java.util.Date(d.createdMs))
                val row = winRow(pairBox, R.drawable.ic_rm_phone, d.name, when0 + " · id " + d.id.take(8))
                row.title.typeface = Typeface.DEFAULT_BOLD
                val armed = armedId == d.id && android.os.SystemClock.elapsedRealtime() - armedAt < 6000L
                addBtn(row, winBtn(if (armed) "Toque de novo" else "Remover", 2) {
                    val t = android.os.SystemClock.elapsedRealtime()
                    if (armedId == d.id && t - armedAt < 6000L) {
                        armedId = ""
                        RemoteServerService.revokeDevice(d.id) { ok ->
                            a.toast(if (ok) "Pareamento removido" else "Esse aparelho já não estava pareado")
                            refreshPairing()
                        }
                    } else {
                        armedId = d.id
                        armedAt = t
                        a.toast("Toque de novo em até 6 s para confirmar")
                        refreshPairing()
                    }
                })
            }
            if (paired.isNotEmpty()) {
                winPadText(pairBox, "Remover apaga o pareamento e desconecta o aparelho na hora; para voltar a usar, será preciso parear de novo.", 11.5f, sub)
            }
        }

        val logTv = label("", 11f, sub)
        logTv.typeface = Typeface.MONOSPACE
        logTv.setPadding(dp(16), dp(10), dp(16), dp(10))

        val result = label("", 12f, ink)
        result.setPadding(dp(2), dp(12), 0, 0)
        var testing = false

        fun refresh(s: RemoteServerService.Status) {
            val st = s.state
            when (st) {
                RemoteServer.State.STOPPED -> setPill(pill, "Desligado", "A9B3C6")
                RemoteServer.State.STARTING -> setPill(pill, "Ligando…", "FFC857")
                RemoteServer.State.RUNNING -> setPill(pill, "● Ligado", "6CCB5F")
                RemoteServer.State.STOPPING -> setPill(pill, "Desligando…", "FFC857")
                RemoteServer.State.ERROR -> setPill(pill, "Erro", "FF6B6B")
            }
            portV.text = (if (st == RemoteServer.State.RUNNING) s.port else RemoteProtocol.DEFAULT_PORT).toString()
            val addrs = RemoteServer.localAddresses()
            if (addrs.isEmpty()) {
                ipV.text = "nenhum (conecte-se ao Wi-Fi ou ligue o hotspot)"
            } else {
                val sbIp = StringBuilder()
                for ((i, ad) in addrs.withIndex()) {
                    if (i > 0) sbIp.append('\n')
                    sbIp.append(ad.first).append("  (").append(ad.second).append(')')
                }
                ipV.text = sbIp.toString()
            }
            clientsV.text = s.clients.toString() + " de " + RemoteServer.MAX_CLIENTS
            val warn = StringBuilder()
            if (st == RemoteServer.State.RUNNING) {
                if (RemoteServerService.wifiLockHeld) {
                    wifiV.text = "ativo"
                } else {
                    wifiV.text = "não ativado"
                    warn.append("⚠ WifiLock não ativado: o Wi-Fi pode dormir com a tela apagada.")
                }
            } else {
                wifiV.text = "—"
            }
            protoV.text = "TLS 1.2 / 1.3 · JSON até 16 KB"
            try {
                val nm = a.getSystemService(android.app.NotificationManager::class.java)
                if (st == RemoteServer.State.RUNNING && !nm.areNotificationsEnabled()) {
                    if (warn.isNotEmpty()) warn.append('\n')
                    warn.append("⚠ As notificações do WinLauncher estão bloqueadas no Android: o servidor funciona, mas a notificação não aparece.")
                }
            } catch (e: Exception) {
            }
            warnTv.text = warn.toString()
            warnTv.visibility = if (warn.isEmpty()) View.GONE else View.VISIBLE
            val errText = if (st == RemoteServer.State.ERROR && s.error.isNotEmpty()) "✘ " + s.error else ""
            errTv.text = errText
            errTv.visibility = if (errText.isEmpty()) View.GONE else View.VISIBLE
            val busy = st == RemoteServer.State.STARTING || st == RemoteServer.State.STOPPING
            toggle.text = when {
                st == RemoteServer.State.STARTING -> "Ligando…"
                st == RemoteServer.State.STOPPING -> "Desligando…"
                st == RemoteServer.State.RUNNING -> "Desligar"
                else -> "Ligar servidor"
            }
            toggle.alpha = if (busy) 0.5f else 1f
            val lines = RemoteServerService.recentLog().takeLast(8)
            logTv.text = if (lines.isEmpty()) "Nenhum evento ainda." else lines.joinToString("\n")
            refreshPairing()
        }

        toggle.isClickable = true
        toggle.setOnClickListener {
            val st = RemoteServerService.status.state
            when (st) {
                RemoteServer.State.RUNNING -> RemoteServerService.stop(a)
                RemoteServer.State.STOPPED, RemoteServer.State.ERROR -> a.startRemoteServerAskingNotifications()
                else -> {
                }
            }
        }

        fun showHash() {
            Thread {
                var text = "—"
                try {
                    val r = RemoteAuth.inspect()
                    text = if (r == null) "(a chave ainda não existe; ela é criada ao ligar o servidor ou no autoteste)"
                    else RemoteAuth.shortFingerprint(r.fingerprint) + "…"
                } catch (e: Throwable) {
                    text = "não foi possível ler: " + e.javaClass.simpleName
                }
                a.runOnUiThread { hashTv.text = text }
            }.start()
        }

        fun runSuite(intro: String, suite: () -> List<RemoteAuth.Check>) {
            if (testing) return
            testing = true
            result.setTextColor(ink)
            result.text = intro
            Thread {
                val checks: List<RemoteAuth.Check> = try {
                    suite()
                } catch (e: Throwable) {
                    listOf(RemoteAuth.Check("Autoteste", false, e.javaClass.simpleName + ": " + (e.message ?: "")))
                }
                a.runOnUiThread {
                    testing = false
                    val sb = StringBuilder()
                    for (ch in checks) {
                        val mark = if (ch.essential) (if (ch.ok) "✔" else "✘") else (if (ch.ok) "ℹ" else "⚠")
                        sb.append(mark).append(' ').append(ch.name)
                        if (ch.detail.isNotBlank()) sb.append("\n    ").append(ch.detail)
                        sb.append('\n')
                    }
                    val allOk = checks.filter { it.essential }.all { it.ok }
                    sb.append('\n').append(
                        if (allOk) "RESULTADO: todos os testes essenciais passaram."
                        else "RESULTADO: FALHOU. Veja os itens ✘ acima."
                    )
                    result.text = sb.toString()
                    result.setTextColor(if (allOk) okColor else badColor)
                    showHash()
                    refreshPairing()
                }
            }.start()
        }

        // ---------------------------------------------------------------- testes
        winSection(c, "Testes")
        val testCard = winCard(c)
        val t1 = winRow(testCard, R.drawable.ic_rm_terminal, "Autoteste do servidor", "Sobe um servidor de teste em porta aleatória e conecta clientes TLS reais")
        addBtn(t1, winBtn("Executar", 0) {
            runSuite("Executando o autoteste (sobe um servidor de teste em porta aleatória e conecta clientes TLS reais)…") {
                RemoteServerTest.selfTest(a)
            }
        })
        val t2 = winRow(testCard, R.drawable.ic_rm_terminal, "Autoteste da integração", "Pareamento, comandos e capa · não usa a porta ${RemoteProtocol.DEFAULT_PORT} nem altera os pareamentos")
        addBtn(t2, winBtn("Executar", 0) {
            runSuite("Executando o autoteste da integração (servidor e música de teste, porta aleatória; não mexe no servidor ligado nem nos seus pareamentos)…") {
                RemoteBridgeTest.selfTest(a)
            }
        })
        c.addView(result)

        winSection(c, "Últimos eventos")
        val logCard = winCard(c)
        logCard.addView(logTv)

        note(c, "Servidor local seguro (TLS) do WinLauncher Remote. Só aceita conexões da sua rede local. Aparelhos novos precisam ser " +
            "pareados aqui (você compara um número nos dois celulares e toca em Permitir); depois de pareados, podem ver a música " +
            "tocando e usar play/pause, próxima e anterior.")
        note(c, "Protocolo: TLS 1.2 / 1.3, mensagens JSON de até 16 KB; só IPv4 de rede local (192.168.x.x, 10.x.x.x, 172.16–31.x.x, 169.254.x.x).")
        note(c, "O servidor só aceita conexões da sua rede local e só fica ligado enquanto você deixar (a notificação tem o botão Desligar). " +
            "Os autotestes não usam a porta ${RemoteProtocol.DEFAULT_PORT}, não mexem no servidor ligado e não alteram os pareamentos reais.")

        val listener: (RemoteServerService.Status) -> Unit = { s -> refresh(s) }
        val bridgeListener: () -> Unit = { refreshPairing() }
        // atualiza só o texto da contagem regressiva (sem recriar os botões); quando o tempo acaba o bridge avisa e a lista é refeita
        val ticker = object : Runnable {
            override fun run() {
                if (!c.isAttachedToWindow) return
                val i = RemoteServerService.bridgeInfo()
                val tv = timeTv
                val f = timeText
                if (i != null && tv != null && f != null) tv.text = f(i)
                c.postDelayed(this, 1000L)
            }
        }
        c.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                RemoteServerService.addListener(listener)
                RemoteServerService.addBridgeListener(bridgeListener)
                refresh(RemoteServerService.status)
                showHash()
                c.removeCallbacks(ticker)
                c.postDelayed(ticker, 1000L)
            }

            override fun onViewDetachedFromWindow(v: View) {
                RemoteServerService.removeListener(listener)
                RemoteServerService.removeBridgeListener(bridgeListener)
                c.removeCallbacks(ticker)
            }
        })
        refresh(RemoteServerService.status)
        showHash()
        return c
    }

    private fun mousePanel(): View {
        val c = column()
        heading(c, "Mouse e interação")

        val arrowIv = ImageView(a)
        val handIv = ImageView(a)
        val busyIv = ImageView(a)
        val previewRow = LinearLayout(a)
        previewRow.orientation = LinearLayout.HORIZONTAL
        previewRow.gravity = Gravity.CENTER
        previewRow.background = box("#7A8794", 8)
        previewRow.setPadding(dp(8), dp(10), dp(8), dp(10))
        for (iv in listOf(arrowIv, handIv, busyIv)) {
            previewRow.addView(iv, LinearLayout.LayoutParams(0, wrap, 1f))
        }
        fun refreshPreview() {
            arrowIv.setImageBitmap(a.cursor.arrowBitmap)
            handIv.setImageBitmap(a.cursor.handBitmap)
            busyIv.setImageBitmap(a.cursor.busyBitmap)
        }
        refreshPreview()

        switchRow(c, "Cursor estilo Windows 11", p.cursorOn) {
            p.cursorOn = it
            a.refreshCursor()
        }
        slider(c, "Tamanho do ponteiro", "ui_cursor_size", 16, 64, 24, " dp") {
            a.refreshCursor()
            refreshPreview()
        }
        val pv = label("Pré-visualização (seta, mão e ocupado)", 12f, sub)
        pv.setPadding(0, dp(10), 0, dp(4))
        c.addView(pv)
        c.addView(previewRow, LinearLayout.LayoutParams(match, wrap))
        note(c, "O cursor personalizado aparece somente sobre as telas do WinLauncher. O Android não permite trocar o cursor do sistema em outros aplicativos com as permissões atuais.")

        choice(c, "Abrir submenus", listOf("Passar o mouse", "Clicar"), if (p.menuHover) 0 else 1) {
            p.menuHover = it == 0
        }

        switchRow(c, "Arrastar e soltar entre apps", p.dragDrop) {
            p.dragDrop = it
        }
        note(c, "Arraste arquivos e fotos entre o Gerenciador de arquivos, as Fotos e o navegador (nos dois sentidos). No toque: segure o item e arraste. No mouse: clique e arraste. Imagens do navegador: segure a imagem e solte numa pasta ou nas Fotos. Arquivos .apk soltos no Instalador abrem a instalação.")

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        val detail = label("", 11.5f, sub)
        fun updateStatus() {
            val st = ShizukuBridge.state(a)
            status.text = "Shizuku: " + when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
            detail.text = when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "Instale o app Shizuku e inicie o serviço (depuração sem fio ou root). O WinLauncher funciona normalmente sem ele."
                ShizukuBridge.State.NOT_RUNNING -> "Abra o Shizuku e toque em iniciar. Depois volte aqui e atualize o estado."
                ShizukuBridge.State.NEEDS_PERMISSION -> "Toque em \"Solicitar autorização\" e aceite o pedido do Shizuku."
                ShizukuBridge.State.GRANTED -> "Para renovar ou revogar, use o app Shizuku → aplicativos autorizados."
                ShizukuBridge.State.UNSUPPORTED -> "Atualize o Shizuku para a versão mais recente."
            }
        }
        updateStatus()
        ShizukuBridge.onChange = { a.runOnUiThread { updateStatus() } }
        c.addView(status)
        c.addView(detail)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Abrir Shizuku") {
            if (!ShizukuBridge.open(a)) a.toast("Shizuku não encontrado")
        }
        button(c, "Atualizar estado") { updateStatus() }
        note(c, "Nesta versão o Shizuku é usado apenas para mostrar o estado e pedir autorização; o cursor não depende dele.")
        return c
    }
}
