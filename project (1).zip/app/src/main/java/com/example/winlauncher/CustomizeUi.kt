package com.example.winlauncher

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Outline
import android.media.MediaMetadataRetriever
import android.os.Build
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.PopupWindow
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Painéis de "Personalizar WinLauncher". Cada categoria é um MenuItem com um painel de controles. */
class CustomizeUi(private val a: MainActivity, private val p: Prefs, private val dark: Boolean = false) {

    private val d = a.resources.displayMetrics.density
    // dark = true: versão para a janela Configurações (fundo escuro); false: menu de contexto claro
    private val ink = Color.parseColor(if (dark) "#F2F5FA" else "#1F1F1F")
    private val sub = Color.parseColor(if (dark) "#A9B3C6" else "#5C5C5C")
    private val accHex = if (dark) "#19B4F0" else "#0067C0"
    private val ctl = Color.parseColor(accHex)
    private val chipOff = if (dark) "#24FFFFFF" else "#14000000"
    private val rowBg = if (dark) "#14FFFFFF" else "#0F000000"
    private val rowBgSel = if (dark) "#3319B4F0" else "#240067C0"
    private val ringOff = if (dark) "#33FFFFFF" else "#33000000"
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    /** Avisa a janela Configurações quando um slider começa/termina de ser arrastado (para ela ficar translúcida e mostrar a prévia). */
    var onDrag: ((Boolean) -> Unit)? = null

    /** Avisa quando um chip/switch é tocado (a janela fica translúcida por um instante). */
    var onTap: (() -> Unit)? = null

    companion object {
        /** Posição da categoria Widgets em [categories] (usada para reabrir o painel depois de importar fontes). */
        const val WIDGETS = 5
    }

    /** Painel avulso por chave, para a janela Configurações. */
    fun panel(key: String): View? = when (key) {
        "taskbar" -> taskbarPanel()
        "start" -> startMenuPanel()
        "wallpaper" -> wallpaperPanel()
        "appearance" -> appearancePanel()
        "screen" -> screenPanel()
        "mouse" -> mousePanel()
        "widgets" -> widgetsPanel()
        "volkeys" -> volumeKeysPanel()
        "fps" -> fpsPanel()
        "perf" -> perfPanel()
        "keyboard" -> keyboardPanel()
        "ytdiag" -> ytDiagPanel()
        else -> null
    }

    fun categories(): List<MenuItem> = listOf(
        MenuItem("Barra de tarefas", R.drawable.ic_view, panel = { taskbarPanel() }),
        MenuItem("Menu Iniciar", R.drawable.ic_start, panel = { startMenuPanel() }),
        MenuItem("Aparência", R.drawable.ic_palette, panel = { appearancePanel() }),
        MenuItem("Tela e navegação", R.drawable.ic_brightness, panel = { screenPanel() }),
        MenuItem("Mouse e interação", R.drawable.ic_mouse, panel = { mousePanel() }),
        MenuItem("Widgets", R.drawable.ic_widgets, panel = { widgetsPanel() }),
        MenuItem("Botões de volume", R.drawable.ic_volume, panel = { volumeKeysPanel() }),
        MenuItem("Teclado", R.drawable.ic_keyboard, panel = { keyboardPanel() })
    )

    // ------------------------------------------------------------ widgets

    private fun column(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(a)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun heading(parent: LinearLayout, t: String) {
        val tv = label(t, 15f, ink, true)
        tv.setPadding(0, 0, 0, dp(6))
        parent.addView(tv)
    }

    private fun note(parent: LinearLayout, t: String) {
        val tv = label(t, 11.5f, sub)
        tv.setPadding(0, dp(6), 0, dp(2))
        parent.addView(tv)
    }

    private fun box(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun slider(
        parent: LinearLayout,
        text: String,
        key: String,
        min: Int,
        max: Int,
        def: Int,
        unit: String,
        initial: Int = p.int(key, def),
        onChange: () -> Unit = { a.applyPrefs() }
    ) {
        val tv = label("", 12.5f, ink)
        tv.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(a)
        sb.max = max - min
        sb.progress = (initial - min).coerceIn(0, max - min)
        tv.text = text + ": " + (sb.progress + min) + unit
        sb.progressTintList = ColorStateList.valueOf(ctl)
        sb.thumbTintList = ColorStateList.valueOf(ctl)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                val value = min + v
                tv.text = text + ": " + value + unit
                if (fromUser) {
                    p.putInt(key, value)
                    onChange()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                onDrag?.invoke(true)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDrag?.invoke(false)
            }
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = box(if (on) accHex else chipOff, 6)
        c.setTextColor(if (on) Color.WHITE else ink)
    }

    private fun choice(
        parent: LinearLayout,
        text: String,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ) {
        val tv = label(text, 12.5f, ink)
        tv.setPadding(0, dp(10), 0, dp(4))
        parent.addView(tv)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        for (i in options.indices) {
            val c = TextView(a)
            c.text = options[i]
            c.textSize = 11.5f
            c.gravity = Gravity.CENTER
            c.setPadding(dp(4), dp(8), dp(4), dp(8))
            c.isClickable = true
            c.setOnClickListener {
                for (j in chips.indices) styleChip(chips[j], j == i)
                onSelect(i)
                onTap?.invoke()
            }
            chips.add(c)
            val lp = LinearLayout.LayoutParams(0, wrap, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            row.addView(c, lp)
        }
        for (i in chips.indices) styleChip(chips[i], i == selected)
        parent.addView(row, LinearLayout.LayoutParams(match, wrap))
    }

    private fun switchRow(parent: LinearLayout, text: String, value: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(a)
        s.text = text
        s.setTextColor(ink)
        s.textSize = 12.5f
        s.isChecked = value
        s.setOnCheckedChangeListener { _, v ->
            onChange(v)
            onTap?.invoke()
        }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(10)
        parent.addView(s, lp)
        return s
    }

    private fun button(parent: LinearLayout, text: String, onClick: () -> Unit) {
        val b = TextView(a)
        b.text = text
        b.textSize = 12.5f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.background = box(accHex, 6)
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
    }

    // ------------------------------------------------------------ painéis

    private fun taskbarPanel(): View {
        val c = column()
        heading(c, "Barra de tarefas")
        switchRow(c, "Mostrar barra de tarefas", !p.tbHidden) { on -> a.setTaskbarHidden(!on) }
        note(c, "Desligado: a barra de tarefas some por completo (ícones, bandeja e relógio). Para voltar: botão direito na área de trabalho > Mostrar barra de tarefas.")
        slider(c, "Escala geral", "ui_tb_scale", 60, 200, 100, "%")
        slider(c, "Altura", "ui_tb_height", 36, 80, 48, " dp")
        slider(c, "Tamanho dos ícones", "ui_tb_icon", 32, 64, 44, " dp")
        slider(c, "Ícones da bandeja", "ui_tb_tray", 14, 32, 20, " dp")
        slider(c, "Relógio e textos", "ui_tb_clock", 8, 18, 11, " sp")
        slider(c, "Espaçamento", "ui_tb_space", 0, 16, 0, " dp")
        choice(c, "Posição", listOf("Embaixo", "Em cima"), p.tbPos) {
            p.tbPos = it
            a.applyPrefs()
        }
        choice(c, "Fundo", listOf("Ajustável", "Vidro fosco", "Invisível"), p.tbBg) {
            p.tbBg = it
            a.applyPrefs()
        }
        slider(c, "Opacidade do fundo", "ui_tb_alpha", 0, 100, 90, "%")
        note(c, "Estas opções alteram somente o fundo da barra. Ícones, bandeja, relógio e notificações permanecem totalmente visíveis.")
        switchRow(c, "Barra sobre outros apps (mouse na borda)", p.tbOverlay) { on ->
            p.tbOverlay = on
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                TaskbarOverlayService.sync(a)
            }
        }
        switchRow(c, "Botão de volume flutuante (arraste para qualquer lugar)", p.volBtn) { on ->
            p.volBtn = on
            a.refreshVolFloat()
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                VolumeButtonService.sync(a, true)
            }
        }
        note(c, "Clique no botão para abrir o volume do Android. Segure e arraste (mouse ou toque) para mover.")
        note(c, "Com outro app aberto, encoste o mouse na borda da tela (embaixo ou em cima, conforme a posição da barra) para levantar a barra de tarefas.")
        return c
    }


    private fun startMenuPanel(): View {
        val c = column()
        heading(c, "Menu Iniciar")
        slider(c, "Largura", "ui_st_w", 260, 560, 360, " dp")
        slider(c, "Altura", "ui_st_h", 240, 800, 0, " dp", initial = if (p.stH == 0) a.defaultStartHeightDp() else p.stH)
        choice(c, "Posição", listOf("Centro inferior", "Centro da tela", "Esquerda"), p.stPos) {
            p.stPos = it
            a.applyPrefs()
        }
        slider(c, "Opacidade", "ui_st_alpha", 30, 100, 95, "%")
        slider(c, "Arredondamento dos cantos", "ui_st_radius", 0, 32, 12, " dp")
        slider(c, "Aplicativos por linha", "ui_st_cols", 3, 8, 4, "")
        switchRow(c, "Efeito de vidro", p.stGlass) {
            p.stGlass = it
            a.applyPrefs()
        }
        button(c, "Restaurar largura e altura padrão") {
            p.stW = 360
            p.stH = 0
            a.applyPrefs()
            a.menu.hide()
        }
        return c
    }

    // ------------------------------------------------------------ wallpaper (estilo Plano de fundo do Windows 11)

    private fun wallpaperPanel(): View {
        val root = column()
        // 0 = Imagem, 1 = Vídeo (começa no tipo do wallpaper atual)
        var mode = if (a.currentWallpaperIsVideo()) 1 else 0

        fun build() {
            root.removeAllViews()
            val video = mode == 1

            // ---- prévia do wallpaper atual (moldura de monitor)
            val frame = FrameLayout(a)
            frame.background = box("#000000", 14)
            frame.setPadding(dp(3), dp(3), dp(3), dp(3))
            val prev = ImageView(a)
            prev.scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(prev, 11)
            val cur = a.currentWallpaperUri()
            if (cur != null) {
                prev.setBackgroundColor(Color.parseColor("#111111"))
                loadThumb(prev, cur, a.currentWallpaperIsVideo(), dp(360))
            } else {
                prev.setImageDrawable(defaultWallpaperDrawable())
            }
            frame.addView(prev, FrameLayout.LayoutParams(match, match))
            val flp = LinearLayout.LayoutParams(dp(200), dp(118))
            flp.bottomMargin = dp(12)
            root.addView(frame, flp)

            // ---- "Personalize seu plano de fundo" + dropdown Imagem / Vídeo
            val modeDrop = dropdown(listOf("Imagem", "Vídeo")[mode], listOf("Imagem", "Vídeo"), mode) {
                mode = it
                build()
            }
            root.addView(
                settingRow(
                    R.drawable.ic_image,
                    "Personalize seu plano de fundo",
                    if (video) "Um plano de fundo com vídeo se aplica à sua área de trabalho atual"
                    else "Um plano de fundo com imagem se aplica à sua área de trabalho atual",
                    modeDrop
                ),
                rowLp()
            )

            // ---- grade de miniaturas + botão "+"
            val grid = LinearLayout(a)
            grid.orientation = LinearLayout.VERTICAL
            grid.background = box(rowBg, 8)
            grid.setPadding(dp(14), dp(12), dp(14), dp(12))
            grid.addView(label(if (video) "Vídeos" else "Imagens", 13.5f, ink))

            val strip = LinearLayout(a)
            strip.orientation = LinearLayout.HORIZONTAL
            val curStr = a.currentWallpaperUri()?.toString()
            val curIsVideo = a.currentWallpaperIsVideo()

            if (!video) {
                strip.addView(tile(selected = curStr == null) { iv ->
                    iv.setImageDrawable(defaultWallpaperDrawable())
                }.also {
                    it.setOnClickListener {
                        a.resetWallpaper()
                        build()
                        onTap?.invoke()
                    }
                })
            }
            for (s in a.recentWallpapers(video)) {
                val uri = Uri.parse(s)
                val t = tile(selected = curStr == s && curIsVideo == video) { iv ->
                    loadThumb(iv, uri, video, dp(160))
                }
                t.setOnClickListener {
                    a.setWallpaper(s, video)
                    build()
                    onTap?.invoke()
                }
                // segurar remove da lista (não apaga o arquivo)
                t.setOnLongClickListener {
                    a.removeRecentWallpaper(s)
                    build()
                    true
                }
                strip.addView(t)
            }
            strip.addView(plusTile {
                if (!dark) a.menu.hide()
                if (video) a.pickWallpaperAnimated() else a.pickWallpaperStatic()
            })
            val hs = HorizontalScrollView(a)
            hs.isHorizontalScrollBarEnabled = false
            hs.addView(strip)
            val hlp = LinearLayout.LayoutParams(match, wrap)
            hlp.topMargin = dp(8)
            grid.addView(hs, hlp)
            root.addView(grid, rowLp())

            // ---- qualidade do papel de parede (só imagem)
            if (!video) {
                val q = listOf("Otimizado", "Alta", "Original")
                val qDrop = dropdown(q[a.wallpaperQuality()], q, a.wallpaperQuality()) {
                    a.setWallpaperQuality(it)
                    build()
                }
                root.addView(settingRow(null, "Qualidade do papel de parede", null, qDrop), rowLp())
            }

            // ---- escolher arquivo
            val browse = TextView(a)
            browse.text = if (video) "Procurar vídeos" else "Procurar fotos"
            browse.textSize = 12.5f
            browse.setTextColor(ink)
            browse.gravity = Gravity.CENTER
            browse.background = box(chipOff, 6)
            browse.setPadding(dp(14), dp(8), dp(14), dp(8))
            browse.isClickable = true
            browse.setOnClickListener {
                if (!dark) a.menu.hide()
                if (video) a.pickWallpaperAnimated() else a.pickWallpaperStatic()
            }
            root.addView(
                settingRow(null, if (video) "Escolha um vídeo ou GIF" else "Escolha uma foto", null, browse),
                rowLp()
            )
        }

        build()
        // quando o seletor de arquivos volta, a grade se atualiza sozinha
        a.wallpaperChanged = {
            if (root.isAttachedToWindow) {
                mode = if (a.currentWallpaperIsVideo()) 1 else 0
                build()
            }
        }
        return root
    }

    private fun rowLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(match, wrap).also { it.bottomMargin = dp(6) }

    private fun defaultWallpaperDrawable(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#0B1E3F"), Color.parseColor("#1B5FD0"), Color.parseColor("#0A2A66"))
    )

    private fun roundClip(v: View, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
            }
        }
    }

    /** Linha de configuração: ícone opcional, título, subtítulo opcional e um controle à direita. */
    private fun settingRow(icon: Int?, title: String, subtitle: String?, right: View?): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = box(rowBg, 8)
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        if (icon != null) {
            val iv = ImageView(a)
            iv.setImageResource(icon)
            iv.setColorFilter(ink)
            val ilp = LinearLayout.LayoutParams(dp(22), dp(22))
            ilp.rightMargin = dp(12)
            row.addView(iv, ilp)
        }
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 13.5f, ink))
        if (subtitle != null) col.addView(label(subtitle, 11f, sub))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        if (right != null) {
            val rlp = LinearLayout.LayoutParams(wrap, wrap)
            rlp.leftMargin = dp(10)
            row.addView(right, rlp)
        }
        return row
    }

    /** Caixa de seleção que abre uma lista (como "Imagem ▾" e "Otimizado ▾"). */
    private fun dropdown(text: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.background = box(chipOff, 6)
        b.setPadding(dp(12), dp(8), dp(10), dp(8))
        b.minimumWidth = dp(104)
        b.addView(label(text, 12.5f, ink), LinearLayout.LayoutParams(0, wrap, 1f))
        val ch = ImageView(a)
        ch.setImageResource(R.drawable.ic_chevron_down)
        ch.setColorFilter(ink)
        val clp = LinearLayout.LayoutParams(dp(14), dp(14))
        clp.leftMargin = dp(8)
        b.addView(ch, clp)
        b.isClickable = true
        b.setOnClickListener {
            val list = LinearLayout(a)
            list.orientation = LinearLayout.VERTICAL
            list.setPadding(dp(4), dp(4), dp(4), dp(4))
            val pw = PopupWindow(list, maxOf(b.width, dp(120)), wrap, true)
            pw.setBackgroundDrawable(box(if (dark) "#FF2B3345" else "#FFFFFFFF", 8))
            pw.isOutsideTouchable = true
            pw.elevation = dp(8).toFloat()
            for (i in options.indices) {
                val item = TextView(a)
                item.text = options[i]
                item.textSize = 12.5f
                item.setTextColor(ink)
                item.setPadding(dp(12), dp(10), dp(12), dp(10))
                if (i == selected) item.background = box(rowBgSel, 6)
                item.isClickable = true
                item.setOnClickListener {
                    pw.dismiss()
                    if (i != selected) onSelect(i)
                }
                list.addView(item, LinearLayout.LayoutParams(match, wrap))
            }
            pw.showAsDropDown(b, 0, dp(2))
        }
        return b
    }

    /** Miniatura quadrada; [selected] desenha o anel de destaque. */
    private fun tile(selected: Boolean, fill: (ImageView) -> Unit): FrameLayout {
        val f = FrameLayout(a)
        f.setPadding(dp(3), dp(3), dp(3), dp(3))
        if (selected) {
            val g = GradientDrawable()
            g.setColor(Color.TRANSPARENT)
            g.cornerRadius = dp(10).toFloat()
            g.setStroke(dp(2), ctl)
            f.background = g
        }
        val iv = ImageView(a)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(Color.parseColor("#22000000"))
        roundClip(iv, 8)
        fill(iv)
        f.addView(iv, FrameLayout.LayoutParams(dp(76), dp(76)))
        f.isClickable = true
        val lp = LinearLayout.LayoutParams(wrap, wrap)
        lp.rightMargin = dp(6)
        f.layoutParams = lp
        return f
    }

    private fun plusTile(onClick: () -> Unit): View {
        val f = FrameLayout(a)
        f.setPadding(dp(3), dp(3), dp(3), dp(3))
        val inner = FrameLayout(a)
        inner.background = box(chipOff, 8)
        val ic = ImageView(a)
        ic.setImageResource(R.drawable.ic_plus)
        ic.setColorFilter(ink)
        inner.addView(ic, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        f.addView(inner, FrameLayout.LayoutParams(dp(76), dp(76)))
        f.isClickable = true
        f.setOnClickListener { onClick() }
        f.layoutParams = LinearLayout.LayoutParams(wrap, wrap)
        return f
    }

    /** Carrega uma miniatura (imagem, GIF ou quadro de vídeo) fora da thread principal. */
    private fun loadThumb(iv: ImageView, uri: Uri, video: Boolean, px: Int) {
        val key = uri.toString()
        iv.tag = key
        Thread {
            var bmp: Bitmap? = null
            try {
                if (video) {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(a, uri)
                        bmp = r.getFrameAtTime(0)
                    } finally {
                        r.release()
                    }
                } else if (Build.VERSION.SDK_INT >= 28) {
                    val src = ImageDecoder.createSource(a.contentResolver, uri)
                    bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val sc = px.toFloat() / minOf(info.size.width, info.size.height)
                        if (sc < 1f) dec.setTargetSize((info.size.width * sc).toInt(), (info.size.height * sc).toInt())
                    }
                } else {
                    val o = BitmapFactory.Options()
                    o.inJustDecodeBounds = true
                    a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                    var s = 1
                    while (minOf(o.outWidth, o.outHeight) / (s * 2) >= px) s *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = s
                    bmp = a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                }
                if (bmp != null && minOf(bmp.width, bmp.height) > px * 2) {
                    val sc = px.toFloat() / minOf(bmp.width, bmp.height)
                    bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
                }
            } catch (e: Throwable) {
                bmp = null
            }
            val out = bmp
            if (out != null) a.runOnUiThread { if (iv.tag == key) iv.setImageBitmap(out) }
        }.start()
    }

    private fun appearancePanel(): View {
        val c = column()
        heading(c, "Aparência")
        choice(c, "Tema", listOf("Escuro", "Claro"), p.theme) {
            p.theme = it
            a.themeChanged(2)
        }
        val tv = label("Cor de destaque", 12.5f, ink)
        tv.setPadding(0, dp(12), 0, dp(6))
        c.addView(tv)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = intArrayOf(
            0xFF4CC2FF.toInt(), 0xFF6CCB5F.toInt(), 0xFFFCE100.toInt(), 0xFFFF8C3A.toInt(),
            0xFFFF7EB6.toInt(), 0xFFB39DFF.toInt(), 0xFFFF6B6B.toInt(), 0xFF4DD0C8.toInt()
        )
        for (col in colors) {
            val sw = View(a)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(dp(if (col == p.accent) 3 else 1), if (col == p.accent) ink else Color.parseColor(ringOff))
            sw.background = g
            sw.isClickable = true
            sw.setOnClickListener {
                p.accent = col
                a.themeChanged(2)
            }
            val lp = LinearLayout.LayoutParams(dp(26), dp(26))
            lp.setMargins(0, 0, dp(8), 0)
            row.addView(sw, lp)
        }
        c.addView(row)
        slider(c, "Opacidade dos painéis", "ui_pn_alpha", 30, 100, 95, "%")
        switchRow(c, "Efeito de vidro nos painéis", p.pnGlass) {
            p.pnGlass = it
            a.applyPrefs()
        }
        switchRow(c, "Animações dos painéis", p.anim) {
            p.anim = it
        }
        choice(c, "Menu de contexto (Windows 11)", listOf("Claro", "Escuro"), if (p.menuDark) 1 else 0) {
            p.menuDark = it == 1
            a.themeChanged(2)
        }
        note(c, "Cor do menu de clique direito e dos painéis de personalização, igual ao Windows 11.")
        return c
    }

    private fun screenPanel(): View {
        val c = column()
        heading(c, "Tela e navegação")
        note(c, "Modo imersivo: ativo sempre que o WinLauncher está aberto. As barras do sistema ficam ocultas.")
        switchRow(c, "Bloquear barras do Android", p.lockBars) {
            p.lockBars = it
            a.applyBarLock()
        }
        note(c, "Ligado: a barra superior e a de botões de navegação não aparecem ao deslizar da borda (somem na hora). Desligado: deslizar da borda mostra as barras por alguns segundos. Vale só enquanto o WinLauncher está aberto.")
        switchRow(c, "Mostrar ícones da área de trabalho", p.dkShow) {
            p.dkShow = it
            a.applyPrefs()
        }
        button(c, "Configurações de exibição do Android") {
            a.menu.hide()
            a.openDisplaySettings()
        }
        return c
    }

    private fun widgetsPanel(): View {
        val c = column()
        heading(c, "Widgets")

        // ---- Relógio e calendário
        val h1 = label("Relógio e calendário", 13.5f, ink, true)
        h1.setPadding(0, dp(4), 0, 0)
        c.addView(h1)
        switchRow(c, "Ativar relógio e calendário", p.wgOn) {
            p.wgOn = it
            a.widgetChanged()
        }
        switchRow(c, "Permitir movimentação", p.wgMove) {
            p.wgMove = it
        }
        slider(c, "Tamanho do widget", "ui_wg_scale", ClockWidget.MIN_PCT, ClockWidget.MAX_PCT, 100, "%") {
            a.widgetChanged()
        }
        note(
            c,
            "Ao ativar, o widget aparece centralizado na área de trabalho. Para mover, toque e segure o widget até vibrar, depois arraste. " +
                "Ele nunca cobre ícones nem a barra de tarefas: se faltar espaço livre, é reduzido automaticamente."
        )

        // ---- Tipografia
        val h2 = label("Tipografia", 13.5f, ink, true)
        h2.setPadding(0, dp(16), 0, 0)
        c.addView(h2)
        button(c, "Adicionar fonte (TTF ou OTF)") {
            a.menu.hide()
            a.pickFont()
        }

        var target = ClockWidget.DAY
        val summary = label("", 11.5f, sub)
        summary.setPadding(0, dp(10), 0, dp(2))
        val list = column()

        fun selectedName(t: Int): String {
            val f = a.clock.fontFile(t)
            if (f.isEmpty()) return "Padrão"
            return FontStore.list(a).firstOrNull { it.file == f }?.name ?: "Padrão"
        }

        fun fontRow(name: String, file: String, tf: Typeface, selected: Boolean): View {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = box(if (selected) rowBgSel else rowBg, 8)
            row.setPadding(dp(10), dp(6), dp(6), dp(6))
            row.isClickable = true

            val col = column()
            val nm = label((if (selected) "✓  " else "") + name, 11f, if (selected) ctl else sub, selected)
            nm.maxLines = 1
            nm.ellipsize = android.text.TextUtils.TruncateAt.END
            val pv = label(a.clock.text(target), 18f, ink)
            pv.typeface = tf
            pv.maxLines = 1
            pv.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(nm)
            col.addView(pv)
            row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))

            if (file.isNotEmpty()) {
                val del = ImageView(a)
                del.setImageResource(R.drawable.ic_delete)
                del.setColorFilter(sub)
                del.setPadding(dp(8), dp(8), dp(8), dp(8))
                del.isClickable = true
                del.setOnClickListener { deleteFont(file); }
                row.addView(del, LinearLayout.LayoutParams(dp(36), dp(36)))
            }
            val lp = LinearLayout.LayoutParams(match, wrap)
            lp.topMargin = dp(6)
            row.layoutParams = lp
            row.setOnClickListener {
                a.clock.setFontFile(target, file)
                fontsChanged()
            }
            return row
        }

        render = {
            list.removeAllViews()
            val cur = a.clock.fontFile(target)
            val fonts = FontStore.list(a)
            val valid = cur.isNotEmpty() && fonts.any { it.file == cur }
            summary.text = "Dia: " + selectedName(ClockWidget.DAY) +
                "\nData: " + selectedName(ClockWidget.DATE) +
                "\nHorário: " + selectedName(ClockWidget.TIME)
            list.addView(fontRow("Fonte padrão", "", a.clock.defaultTypeface(target), !valid))
            for (f in fonts) {
                list.addView(fontRow(f.name, f.file, FontStore.typeface(a, f.file) ?: a.clock.defaultTypeface(target), valid && f.file == cur))
            }
        }

        choice(c, "Aplicar fonte em", listOf("Dia da semana", "Data", "Horário"), target) {
            target = it
            render?.invoke()
        }
        c.addView(summary)
        c.addView(list, LinearLayout.LayoutParams(match, wrap))
        button(c, "Restaurar fonte padrão") {
            a.clock.setFontFile(ClockWidget.DAY, "")
            a.clock.setFontFile(ClockWidget.DATE, "")
            a.clock.setFontFile(ClockWidget.TIME, "")
            fontsChanged()
        }
        note(
            c,
            "Toque em uma fonte para aplicá-la ao texto escolhido acima; a prévia mostra como ele ficará. " +
                "As fontes ficam guardadas só dentro do WinLauncher e não alteram o Android nem outros apps."
        )
        render?.invoke()
        return c
    }

    /** Redesenha a lista de fontes do painel Widgets aberto no momento. */
    private var render: (() -> Unit)? = null

    private fun fontsChanged() {
        a.clock.applyFonts()
        a.widgetChanged()
        render?.invoke()
    }

    private fun deleteFont(file: String) {
        for (t in listOf(ClockWidget.DAY, ClockWidget.DATE, ClockWidget.TIME)) {
            if (a.clock.fontFile(t) == file) a.clock.setFontFile(t, "")
        }
        FontStore.delete(a, file)
        a.toast("Fonte removida")
        fontsChanged()
    }

    private fun fpsPanel(): View {
        val c = column()
        heading(c, "Contador de FPS")
        switchRow(c, "Mostrar contador de FPS (sobre os apps)", p.fpsOn) { on ->
            p.fpsOn = on
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                FpsCounterService.sync(a)
            }
        }
        choice(c, "Tipo de FPS", listOf("FPS real", "FPS falso"), p.fpsMode) {
            p.fpsMode = it
            FpsCounterService.sync(a)
        }
        slider(c, "Tamanho do contador", "ui_fps_size", 8, 60, 13, " sp") {
            FpsCounterService.instance?.applyStyle()
        }
        note(c, "FPS real: com o Shizuku autorizado, mostra o FPS do app que está aberto (jogo, vídeo...). Sem o Shizuku, mostra só a taxa de atualização da tela (60, 90, 120...). FPS falso: número de brincadeira que alterna entre 190 e 255.")
        note(c, "A barrinha preta fica sobre qualquer app. Segure e arraste (dedo ou mouse) para mudar de lugar.")

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        val detail = label("", 11.5f, sub)
        fun updateStatus() {
            val st = ShizukuBridge.state(a)
            status.text = "Shizuku: " + when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
            detail.text = when (st) {
                ShizukuBridge.State.GRANTED -> "FPS real do app aberto ativado."
                ShizukuBridge.State.NEEDS_PERMISSION -> "Toque em \"Solicitar autorização\" e aceite o pedido do Shizuku."
                ShizukuBridge.State.NOT_RUNNING -> "Abra o Shizuku e toque em iniciar. Depois volte aqui."
                ShizukuBridge.State.NOT_INSTALLED -> "Instale e inicie o Shizuku para ver o FPS real do app aberto."
                ShizukuBridge.State.UNSUPPORTED -> "Atualize o Shizuku para a versão mais recente."
            }
        }
        updateStatus()
        ShizukuBridge.onChange = {
            a.runOnUiThread {
                updateStatus()
                FpsCounterService.sync(a)
            }
        }
        c.addView(status)
        c.addView(detail)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Abrir Shizuku") {
            if (!ShizukuBridge.open(a)) a.toast("Shizuku não encontrado")
        }
        button(c, "Atualizar estado") {
            updateStatus()
            FpsCounterService.sync(a)
        }
        return c
    }

    private fun perfPanel(): View {
        val c = column()
        heading(c, "Monitor de desempenho")
        note(c, "Painel sobre os apps com FPS, frametime, CPU, GPU e RAM. Clique com o botão direito (ou segure) no painel para Mover, mudar Opacidade e Tamanho.")
        note(c, "Os números são reais, menos as temperaturas, que ficam fixas perto de 42 °C. Uso de CPU/GPU, MHz e FPS do app aberto precisam do Shizuku autorizado; sem ele essas linhas mostram \"--\".")

        switchRow(c, "Mostrar o painel (sobre os apps)", PerfOverlayService.isOn(a)) { on -> a.setPerfOn(on) }
        switchRow(c, "Fixar na barra de tarefas", a.perfPinned()) { on -> a.setPerfPinned(on) }

        // ícone do programa (usado na barra de tarefas)
        val iconRow = LinearLayout(a)
        iconRow.orientation = LinearLayout.HORIZONTAL
        iconRow.gravity = Gravity.CENTER_VERTICAL
        val preview = ImageView(a)
        preview.setImageDrawable(a.perfIcon())
        iconRow.addView(preview, LinearLayout.LayoutParams(dp(40), dp(40)))
        val iconText = label("Ícone na barra de tarefas", 12.5f, ink)
        iconText.setPadding(dp(12), 0, 0, 0)
        iconRow.addView(iconText)
        val ilp = LinearLayout.LayoutParams(match, wrap)
        ilp.topMargin = dp(12)
        c.addView(iconRow, ilp)
        a.perfPanelRefresh = {
            if (preview.isAttachedToWindow) preview.setImageDrawable(a.perfIcon())
        }
        button(c, "Trocar ícone") {
            if (!dark) a.menu.hide()
            a.pickPerfIcon()
        }
        button(c, "Restaurar ícone") {
            a.resetPerfIcon()
            preview.setImageDrawable(a.perfIcon())
        }
        button(c, "Restaurar posição, tamanho e opacidade") {
            p.putInt("ui_perf_alpha", 100)
            p.putInt("ui_perf_scale", 100)
            p.putInt("ui_perf_anchor", 0)
            p.putInt("ui_perf_x", dp(12))
            p.putInt("ui_perf_y", dp(12))
            PerfOverlayService.instance?.let {
                // recria a janela para a nova posição valer na hora
                PerfOverlayService.setOn(a, false)
                PerfOverlayService.setOn(a, true)
            }
        }

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        fun updateStatus() {
            status.text = "Shizuku: " + when (ShizukuBridge.state(a)) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado (CPU, GPU e FPS do app aparecem como --)"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
        }
        updateStatus()
        c.addView(status)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Atualizar estado") { updateStatus() }
        return c
    }

    private fun volumeKeysPanel(): View {
        val c = column()
        heading(c, "Botões de volume")
        switchRow(c, "Bloquear botões físicos de volume (aumentar/diminuir)", p.blockVolKeys) { on ->
            p.blockVolKeys = on
            a.toast(if (on) "Botões de volume bloqueados" else "Botões de volume liberados")
        }
        note(c, "Ligado: os botões físicos de volume não fazem nada enquanto o WinLauncher está aberto. Desligado: funcionam normalmente. Em outros apps eles sempre funcionam.")

        val sc = label("Atalho Alt + V dentro de outros apps", 13f, ink, true)
        sc.setPadding(0, dp(18), 0, 0)
        c.addView(sc)
        note(c, "Para o Alt + V abrir o painel de volume também dentro de outros apps, ative \"WinLauncher - atalhos de teclado\" em Acessibilidade (Apps instalados). O serviço só lê as teclas Alt + V.")
        val st = label(
            if (ShortcutService.running) "Status: ativado" else "Status: desativado",
            12f, if (ShortcutService.running) ctl else sub
        )
        st.setPadding(0, dp(4), 0, 0)
        c.addView(st)
        button(c, "Abrir configurações de Acessibilidade") {
            try {
                a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir Acessibilidade")
            }
        }
        return c
    }

    private fun keyboardPanel(): View {
        val c = column()
        heading(c, "Teclado")
        val status = label("", 12f, sub)
        status.setPadding(0, dp(8), 0, dp(2))
        var guard = false
        var sw: Switch? = null
        fun refresh() {
            status.text = "Estado: " + when {
                KeyboardBlocker.isActive(a) -> "teclado na tela bloqueado"
                KeyboardBlocker.isEnabled(a) -> "teclado vazio ativado, mas não selecionado"
                else -> "teclado normal em uso"
            }
        }
        sw = switchRow(c, "Bloquear teclado na tela (todos os apps)", KeyboardBlocker.isActive(a)) { on ->
            if (guard) return@switchRow
            fun revert() {
                guard = true
                sw?.isChecked = KeyboardBlocker.isActive(a)
                guard = false
            }
            val viaShizuku = ShizukuBridge.state(a) == ShizukuBridge.State.GRANTED
            val direct = KeyboardBlocker.canWriteSecure(a)
            if (!viaShizuku && !direct) {
                // sem Shizuku nem permissão especial: guia pelo Android (lista de teclados / seletor)
                revert()
                if (on && !KeyboardBlocker.isEnabled(a)) {
                    a.toast("Ative \"WinLauncher - sem teclado\" na lista e volte aqui")
                    try {
                        a.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                } else {
                    a.toast(if (on) "Escolha \"WinLauncher - sem teclado\"" else "Escolha o seu teclado de antes")
                    KeyboardBlocker.showPicker(a)
                }
                return@switchRow
            }
            Thread {
                val ok = if (viaShizuku) KeyboardBlocker.set(a, p, on) else KeyboardBlocker.setDirect(a, p, on)
                a.runOnUiThread {
                    revert()
                    refresh()
                    a.toast(
                        when {
                            !ok -> "Não consegui trocar o teclado. Use os passos manuais abaixo."
                            on -> "Teclado na tela bloqueado em todos os apps"
                            else -> "Teclado normal restaurado"
                        }
                    )
                }
            }.start()
        }
        refresh()
        c.addView(status)
        note(c, "Ligado: troca o teclado do Android por um teclado vazio, então nenhum teclado aparece na tela em nenhum app (mesmo truque do Button Mapper). O teclado físico continua funcionando. Desligado: volta para o teclado que você usava antes. Troca automática com o Shizuku autorizado; sem ele, o switch abre a lista de teclados e o seletor do Android para você escolher.")
        note(c, "Atenção: com o bloqueio ligado, sem teclado físico você não consegue digitar em lugar nenhum. Para voltar, desligue aqui.")

        val man = label("Passos manuais (sem o Shizuku)", 13f, ink, true)
        man.setPadding(0, dp(18), 0, 0)
        c.addView(man)
        note(c, "1) Ative \"WinLauncher - sem teclado\" na lista de teclados. 2) Escolha-o no seletor. Para voltar ao normal, abra o seletor e escolha o seu teclado de antes.")
        button(c, "1) Abrir lista de teclados do Android") {
            try {
                a.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir as configurações de teclado")
            }
        }
        button(c, "2) Escolher teclado (seletor)") {
            KeyboardBlocker.showPicker(a)
            refresh()
        }
        button(c, "Atualizar estado") {
            guard = true
            sw?.isChecked = KeyboardBlocker.isActive(a)
            guard = false
            refresh()
        }
        return c
    }

    /**
     * Página TEMPORÁRIA de diagnóstico (WinLauncher Remote, etapa 2): mostra o que o YouTube Music
     * publica na sessão de mídia e deixa testar play/pause, próxima e anterior.
     * Só será removida depois da confirmação do dono do projeto.
     */
    private fun ytDiagPanel(): View {
        val c = column()
        heading(c, "Diagnóstico do YouTube Music")
        note(c, "Página temporária do WinLauncher Remote. Abra o YouTube Music, toque uma música e volte aqui. Os testes abaixo usam só a sessão de mídia do YouTube Music.")

        val cover = ImageView(a)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        cover.background = box(rowBg, 8)
        val coverLp = LinearLayout.LayoutParams(dp(96), dp(96))
        coverLp.topMargin = dp(8)
        c.addView(cover, coverLp)

        val info = label("", 12.5f, ink)
        info.setPadding(0, dp(8), 0, 0)
        c.addView(info)

        val result = label("", 12.5f, ctl, true)
        result.setPadding(0, dp(10), 0, 0)

        fun mark(ok: Boolean) = if (ok) "✔" else "✘"
        fun stateName(code: Int): String = when (code) {
            -1 -> "sem estado"
            android.media.session.PlaybackState.STATE_NONE -> "NONE"
            android.media.session.PlaybackState.STATE_STOPPED -> "STOPPED"
            android.media.session.PlaybackState.STATE_PAUSED -> "PAUSED"
            android.media.session.PlaybackState.STATE_PLAYING -> "PLAYING"
            android.media.session.PlaybackState.STATE_BUFFERING -> "BUFFERING"
            android.media.session.PlaybackState.STATE_ERROR -> "ERROR"
            else -> "código $code"
        }

        fun render(s: MediaSessionHub.State) {
            val sb = StringBuilder()
            sb.append(mark(s.access)).append(" Acesso às notificações\n")
            sb.append(mark(s.hasSession)).append(" YouTube Music encontrado\n")
            if (s.hasSession) {
                sb.append("Estado: ").append(stateName(s.stateCode)).append('\n')
                sb.append(mark(s.title.isNotBlank())).append(" Título: ").append(if (s.title.isBlank()) "—" else s.title).append('\n')
                sb.append(mark(s.artist.isNotBlank())).append(" Artista: ").append(if (s.artist.isBlank()) "—" else s.artist).append('\n')
                sb.append("Álbum: ").append(if (s.album.isBlank()) "—" else s.album).append('\n')
                sb.append(mark(s.art != null)).append(" Capa: ").append(s.artInfo).append('\n')
                sb.append(mark(s.canPlay)).append(" Play anunciado  ")
                sb.append(mark(s.canPause)).append(" Pause anunciado\n")
                sb.append(mark(s.canNext)).append(" Próxima anunciada  ")
                sb.append(mark(s.canPrev)).append(" Anterior anunciada\n")
                sb.append("Ações (bruto): 0x").append(s.actions.toString(16)).append('\n')
                if (s.customActions.isNotEmpty()) sb.append("Ações extras: ").append(s.customActions.joinToString(", ")).append('\n')
            } else if (!s.access) {
                sb.append("Conceda o acesso às notificações ao WinLauncher (botão abaixo). No Android 13 ou superior, se a opção estiver bloqueada: Configurações > Apps > WinLauncher > ⋮ > Permitir configurações restritas.\n")
            } else {
                sb.append("Abra o YouTube Music e toque uma música.\n")
            }
            info.text = sb.toString().trimEnd()
            cover.setImageBitmap(s.art)
        }

        var force = false
        fun show(name: String, r: MediaSessionHub.Result) {
            result.text = name + ": " + when (r) {
                MediaSessionHub.Result.OK -> "comando enviado. Confira se o YouTube Music respondeu."
                MediaSessionHub.Result.NO_ACCESS -> "sem acesso às notificações."
                MediaSessionHub.Result.NO_SESSION -> "YouTube Music sem sessão (abra e toque uma música)."
                MediaSessionHub.Result.UNAVAILABLE -> "ação não anunciada pelo app. Ligue \"Forçar\" para testar mesmo assim."
                MediaSessionHub.Result.ERROR -> "erro ao enviar o comando."
            }
        }

        button(c, "Play / Pause") { show("Play/Pause", MediaSessionHub.togglePlayPause(force)) }
        button(c, "Próxima música") { show("Próxima", MediaSessionHub.next(force)) }
        button(c, "Música anterior") { show("Anterior", MediaSessionHub.previous(force)) }
        switchRow(c, "Forçar (ignora as ações anunciadas pelo app)", false) { on -> force = on }
        c.addView(result)

        button(c, "Atualizar") {
            MediaSessionHub.refresh()
            render(MediaSessionHub.state())
        }
        button(c, "Abrir o YouTube Music") {
            val i = a.packageManager.getLaunchIntentForPackage(MediaSessionHub.YT_MUSIC_PKG)
            if (i == null) {
                a.toast("YouTube Music não encontrado neste aparelho")
            } else {
                try {
                    a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    a.toast("Não foi possível abrir o YouTube Music")
                }
            }
        }
        button(c, "Abrir acesso às notificações do Android") {
            try {
                a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir as configurações")
            }
        }

        // acompanha o YouTube Music só enquanto esta página está na tela
        val l = object : MediaSessionHub.Listener {
            override fun onMediaState(s: MediaSessionHub.State) {
                render(s)
            }
        }
        c.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                MediaSessionHub.addListener(l)
                MediaSessionHub.start(a)
                render(MediaSessionHub.state())
            }

            override fun onViewDetachedFromWindow(v: View) {
                MediaSessionHub.removeListener(l)
                MediaSessionHub.stop()
            }
        })
        render(MediaSessionHub.state())
        return c
    }

    private fun mousePanel(): View {
        val c = column()
        heading(c, "Mouse e interação")

        val arrowIv = ImageView(a)
        val handIv = ImageView(a)
        val busyIv = ImageView(a)
        val previewRow = LinearLayout(a)
        previewRow.orientation = LinearLayout.HORIZONTAL
        previewRow.gravity = Gravity.CENTER
        previewRow.background = box("#7A8794", 8)
        previewRow.setPadding(dp(8), dp(10), dp(8), dp(10))
        for (iv in listOf(arrowIv, handIv, busyIv)) {
            previewRow.addView(iv, LinearLayout.LayoutParams(0, wrap, 1f))
        }
        fun refreshPreview() {
            arrowIv.setImageBitmap(a.cursor.arrowBitmap)
            handIv.setImageBitmap(a.cursor.handBitmap)
            busyIv.setImageBitmap(a.cursor.busyBitmap)
        }
        refreshPreview()

        switchRow(c, "Cursor estilo Windows 11", p.cursorOn) {
            p.cursorOn = it
            a.refreshCursor()
        }
        slider(c, "Tamanho do ponteiro", "ui_cursor_size", 16, 64, 24, " dp") {
            a.refreshCursor()
            refreshPreview()
        }
        val pv = label("Pré-visualização (seta, mão e ocupado)", 12f, sub)
        pv.setPadding(0, dp(10), 0, dp(4))
        c.addView(pv)
        c.addView(previewRow, LinearLayout.LayoutParams(match, wrap))
        note(c, "O cursor personalizado aparece somente sobre as telas do WinLauncher. O Android não permite trocar o cursor do sistema em outros aplicativos com as permissões atuais.")

        choice(c, "Abrir submenus", listOf("Passar o mouse", "Clicar"), if (p.menuHover) 0 else 1) {
            p.menuHover = it == 0
        }

        switchRow(c, "Arrastar e soltar entre apps", p.dragDrop) {
            p.dragDrop = it
        }
        note(c, "Arraste arquivos e fotos entre o Gerenciador de arquivos, as Fotos e o navegador (nos dois sentidos). No toque: segure o item e arraste. No mouse: clique e arraste. Imagens do navegador: segure a imagem e solte numa pasta ou nas Fotos. Arquivos .apk soltos no Instalador abrem a instalação.")

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        val detail = label("", 11.5f, sub)
        fun updateStatus() {
            val st = ShizukuBridge.state(a)
            status.text = "Shizuku: " + when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
            detail.text = when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "Instale o app Shizuku e inicie o serviço (depuração sem fio ou root). O WinLauncher funciona normalmente sem ele."
                ShizukuBridge.State.NOT_RUNNING -> "Abra o Shizuku e toque em iniciar. Depois volte aqui e atualize o estado."
                ShizukuBridge.State.NEEDS_PERMISSION -> "Toque em \"Solicitar autorização\" e aceite o pedido do Shizuku."
                ShizukuBridge.State.GRANTED -> "Para renovar ou revogar, use o app Shizuku → aplicativos autorizados."
                ShizukuBridge.State.UNSUPPORTED -> "Atualize o Shizuku para a versão mais recente."
            }
        }
        updateStatus()
        ShizukuBridge.onChange = { a.runOnUiThread { updateStatus() } }
        c.addView(status)
        c.addView(detail)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Abrir Shizuku") {
            if (!ShizukuBridge.open(a)) a.toast("Shizuku não encontrado")
        }
        button(c, "Atualizar estado") { updateStatus() }
        note(c, "Nesta versão o Shizuku é usado apenas para mostrar o estado e pedir autorização; o cursor não depende dele.")
        return c
    }
}
