package com.example.winlauncher

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Painéis de "Personalizar WinLauncher". Cada categoria é um MenuItem com um painel de controles. */
class CustomizeUi(private val a: MainActivity, private val p: Prefs, private val dark: Boolean = false) {

    private val d = a.resources.displayMetrics.density
    // dark = true: versão para a janela Configurações (fundo escuro); false: menu de contexto claro
    private val ink = Color.parseColor(if (dark) "#F2F5FA" else "#1F1F1F")
    private val sub = Color.parseColor(if (dark) "#A9B3C6" else "#5C5C5C")
    private val accHex = if (dark) "#19B4F0" else "#0067C0"
    private val ctl = Color.parseColor(accHex)
    private val chipOff = if (dark) "#24FFFFFF" else "#14000000"
    private val rowBg = if (dark) "#14FFFFFF" else "#0F000000"
    private val rowBgSel = if (dark) "#3319B4F0" else "#240067C0"
    private val ringOff = if (dark) "#33FFFFFF" else "#33000000"
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private fun dp(v: Int): Int = (v * d + 0.5f).toInt()

    /** Avisa a janela Configurações quando um slider começa/termina de ser arrastado (para ela ficar translúcida e mostrar a prévia). */
    var onDrag: ((Boolean) -> Unit)? = null

    /** Avisa quando um chip/switch é tocado (a janela fica translúcida por um instante). */
    var onTap: (() -> Unit)? = null

    companion object {
        /** Posição da categoria Widgets em [categories] (usada para reabrir o painel depois de importar fontes). */
        const val WIDGETS = 6
    }

    /** Painel avulso por chave, para a janela Configurações. */
    fun panel(key: String): View? = when (key) {
        "taskbar" -> taskbarPanel()
        "start" -> startMenuPanel()
        "wallpaper" -> wallpaperPanel()
        "appearance" -> appearancePanel()
        "screen" -> screenPanel()
        "mouse" -> mousePanel()
        "widgets" -> widgetsPanel()
        "volkeys" -> volumeKeysPanel()
        else -> null
    }

    fun categories(): List<MenuItem> = listOf(
        MenuItem("Barra de tarefas", R.drawable.ic_view, panel = { taskbarPanel() }),
        MenuItem("Menu Iniciar", R.drawable.ic_start, panel = { startMenuPanel() }),
        MenuItem("Wallpaper", R.drawable.ic_image, panel = { wallpaperPanel() }),
        MenuItem("Aparência", R.drawable.ic_palette, panel = { appearancePanel() }),
        MenuItem("Tela e navegação", R.drawable.ic_brightness, panel = { screenPanel() }),
        MenuItem("Mouse e interação", R.drawable.ic_mouse, panel = { mousePanel() }),
        MenuItem("Widgets", R.drawable.ic_widgets, panel = { widgetsPanel() }),
        MenuItem("Botões de volume", R.drawable.ic_volume, panel = { volumeKeysPanel() })
    )

    // ------------------------------------------------------------ widgets

    private fun column(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(a)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun heading(parent: LinearLayout, t: String) {
        val tv = label(t, 15f, ink, true)
        tv.setPadding(0, 0, 0, dp(6))
        parent.addView(tv)
    }

    private fun note(parent: LinearLayout, t: String) {
        val tv = label(t, 11.5f, sub)
        tv.setPadding(0, dp(6), 0, dp(2))
        parent.addView(tv)
    }

    private fun box(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun slider(
        parent: LinearLayout,
        text: String,
        key: String,
        min: Int,
        max: Int,
        def: Int,
        unit: String,
        initial: Int = p.int(key, def),
        onChange: () -> Unit = { a.applyPrefs() }
    ) {
        val tv = label("", 12.5f, ink)
        tv.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(a)
        sb.max = max - min
        sb.progress = (initial - min).coerceIn(0, max - min)
        tv.text = text + ": " + (sb.progress + min) + unit
        sb.progressTintList = ColorStateList.valueOf(ctl)
        sb.thumbTintList = ColorStateList.valueOf(ctl)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                val value = min + v
                tv.text = text + ": " + value + unit
                if (fromUser) {
                    p.putInt(key, value)
                    onChange()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                onDrag?.invoke(true)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDrag?.invoke(false)
            }
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = box(if (on) accHex else chipOff, 6)
        c.setTextColor(if (on) Color.WHITE else ink)
    }

    private fun choice(
        parent: LinearLayout,
        text: String,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ) {
        val tv = label(text, 12.5f, ink)
        tv.setPadding(0, dp(10), 0, dp(4))
        parent.addView(tv)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        for (i in options.indices) {
            val c = TextView(a)
            c.text = options[i]
            c.textSize = 11.5f
            c.gravity = Gravity.CENTER
            c.setPadding(dp(4), dp(8), dp(4), dp(8))
            c.isClickable = true
            c.setOnClickListener {
                for (j in chips.indices) styleChip(chips[j], j == i)
                onSelect(i)
                onTap?.invoke()
            }
            chips.add(c)
            val lp = LinearLayout.LayoutParams(0, wrap, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            row.addView(c, lp)
        }
        for (i in chips.indices) styleChip(chips[i], i == selected)
        parent.addView(row, LinearLayout.LayoutParams(match, wrap))
    }

    private fun switchRow(parent: LinearLayout, text: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val s = Switch(a)
        s.text = text
        s.setTextColor(ink)
        s.textSize = 12.5f
        s.isChecked = value
        s.setOnCheckedChangeListener { _, v ->
            onChange(v)
            onTap?.invoke()
        }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(10)
        parent.addView(s, lp)
    }

    private fun button(parent: LinearLayout, text: String, onClick: () -> Unit) {
        val b = TextView(a)
        b.text = text
        b.textSize = 12.5f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.background = box(accHex, 6)
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
    }

    // ------------------------------------------------------------ painéis

    private fun taskbarPanel(): View {
        val c = column()
        heading(c, "Barra de tarefas")
        switchRow(c, "Mostrar barra de tarefas", !p.tbHidden) { on -> a.setTaskbarHidden(!on) }
        note(c, "Desligado: a barra de tarefas some por completo (ícones, bandeja e relógio). Para voltar: botão direito na área de trabalho > Mostrar barra de tarefas.")
        slider(c, "Escala geral", "ui_tb_scale", 60, 200, 100, "%")
        slider(c, "Altura", "ui_tb_height", 36, 80, 48, " dp")
        slider(c, "Tamanho dos ícones", "ui_tb_icon", 32, 64, 44, " dp")
        slider(c, "Ícones da bandeja", "ui_tb_tray", 14, 32, 20, " dp")
        slider(c, "Relógio e textos", "ui_tb_clock", 8, 18, 11, " sp")
        slider(c, "Espaçamento", "ui_tb_space", 0, 16, 0, " dp")
        choice(c, "Posição", listOf("Embaixo", "Em cima"), p.tbPos) {
            p.tbPos = it
            a.applyPrefs()
        }
        choice(c, "Fundo", listOf("Ajustável", "Vidro fosco", "Invisível"), p.tbBg) {
            p.tbBg = it
            a.applyPrefs()
        }
        slider(c, "Opacidade do fundo", "ui_tb_alpha", 0, 100, 90, "%")
        note(c, "Estas opções alteram somente o fundo da barra. Ícones, bandeja, relógio e notificações permanecem totalmente visíveis.")
        switchRow(c, "Barra sobre outros apps (mouse na borda)", p.tbOverlay) { on ->
            p.tbOverlay = on
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                TaskbarOverlayService.sync(a)
            }
        }
        switchRow(c, "Botão de volume flutuante (arraste para qualquer lugar)", p.volBtn) { on ->
            p.volBtn = on
            a.refreshVolFloat()
            if (on && !Settings.canDrawOverlays(a)) {
                a.toast("Permita \"Exibir sobre outros apps\" para o WinLauncher")
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
                    )
                } catch (e: Exception) {
                }
            } else {
                VolumeButtonService.sync(a, true)
            }
        }
        note(c, "Clique no botão para abrir o volume do Android. Segure e arraste (mouse ou toque) para mover.")
        note(c, "Com outro app aberto, encoste o mouse na borda da tela (embaixo ou em cima, conforme a posição da barra) para levantar a barra de tarefas.")
        return c
    }


    private fun startMenuPanel(): View {
        val c = column()
        heading(c, "Menu Iniciar")
        slider(c, "Largura", "ui_st_w", 260, 560, 360, " dp")
        slider(c, "Altura", "ui_st_h", 240, 800, 0, " dp", initial = if (p.stH == 0) a.defaultStartHeightDp() else p.stH)
        choice(c, "Posição", listOf("Centro inferior", "Centro da tela", "Esquerda"), p.stPos) {
            p.stPos = it
            a.applyPrefs()
        }
        slider(c, "Opacidade", "ui_st_alpha", 30, 100, 95, "%")
        slider(c, "Arredondamento dos cantos", "ui_st_radius", 0, 32, 12, " dp")
        slider(c, "Aplicativos por linha", "ui_st_cols", 3, 8, 4, "")
        switchRow(c, "Efeito de vidro", p.stGlass) {
            p.stGlass = it
            a.applyPrefs()
        }
        button(c, "Restaurar largura e altura padrão") {
            p.stW = 360
            p.stH = 0
            a.applyPrefs()
            a.menu.hide()
        }
        return c
    }

    private fun wallpaperPanel(): View {
        val c = column()
        heading(c, "Wallpaper")
        note(c, "Estático: imagem. Animado: GIF ou vídeo. Os recursos atuais de wallpaper continuam iguais.")
        button(c, "Escolher imagem (estático)") {
            a.menu.hide()
            a.pickWallpaperStatic()
        }
        button(c, "Escolher GIF ou vídeo (animado)") {
            a.menu.hide()
            a.pickWallpaperAnimated()
        }
        button(c, "Restaurar wallpaper padrão") {
            a.menu.hide()
            a.resetWallpaper()
        }
        return c
    }

    private fun appearancePanel(): View {
        val c = column()
        heading(c, "Aparência")
        choice(c, "Tema", listOf("Escuro", "Claro"), p.theme) {
            p.theme = it
            a.themeChanged(3)
        }
        val tv = label("Cor de destaque", 12.5f, ink)
        tv.setPadding(0, dp(12), 0, dp(6))
        c.addView(tv)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = intArrayOf(
            0xFF4CC2FF.toInt(), 0xFF6CCB5F.toInt(), 0xFFFCE100.toInt(), 0xFFFF8C3A.toInt(),
            0xFFFF7EB6.toInt(), 0xFFB39DFF.toInt(), 0xFFFF6B6B.toInt(), 0xFF4DD0C8.toInt()
        )
        for (col in colors) {
            val sw = View(a)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(dp(if (col == p.accent) 3 else 1), if (col == p.accent) ink else Color.parseColor(ringOff))
            sw.background = g
            sw.isClickable = true
            sw.setOnClickListener {
                p.accent = col
                a.themeChanged(3)
            }
            val lp = LinearLayout.LayoutParams(dp(26), dp(26))
            lp.setMargins(0, 0, dp(8), 0)
            row.addView(sw, lp)
        }
        c.addView(row)
        slider(c, "Opacidade dos painéis", "ui_pn_alpha", 30, 100, 95, "%")
        switchRow(c, "Efeito de vidro nos painéis", p.pnGlass) {
            p.pnGlass = it
            a.applyPrefs()
        }
        switchRow(c, "Animações dos painéis", p.anim) {
            p.anim = it
        }
        note(c, "O menu de contexto mantém o visual claro e translúcido do Windows 11 em qualquer tema.")
        return c
    }

    private fun screenPanel(): View {
        val c = column()
        heading(c, "Tela e navegação")
        note(c, "Modo imersivo: ativo sempre que o WinLauncher está aberto. As barras do sistema ficam ocultas.")
        switchRow(c, "Bloquear barras do Android", p.lockBars) {
            p.lockBars = it
            a.applyBarLock()
        }
        note(c, "Ligado: a barra superior e a de botões de navegação não aparecem ao deslizar da borda (somem na hora). Desligado: deslizar da borda mostra as barras por alguns segundos. Vale só enquanto o WinLauncher está aberto.")
        switchRow(c, "Mostrar ícones da área de trabalho", p.dkShow) {
            p.dkShow = it
            a.applyPrefs()
        }
        button(c, "Configurações de exibição do Android") {
            a.menu.hide()
            a.openDisplaySettings()
        }
        return c
    }

    private fun widgetsPanel(): View {
        val c = column()
        heading(c, "Widgets")

        // ---- Relógio e calendário
        val h1 = label("Relógio e calendário", 13.5f, ink, true)
        h1.setPadding(0, dp(4), 0, 0)
        c.addView(h1)
        switchRow(c, "Ativar relógio e calendário", p.wgOn) {
            p.wgOn = it
            a.widgetChanged()
        }
        switchRow(c, "Permitir movimentação", p.wgMove) {
            p.wgMove = it
        }
        slider(c, "Tamanho do widget", "ui_wg_scale", ClockWidget.MIN_PCT, ClockWidget.MAX_PCT, 100, "%") {
            a.widgetChanged()
        }
        note(
            c,
            "Ao ativar, o widget aparece centralizado na área de trabalho. Para mover, toque e segure o widget até vibrar, depois arraste. " +
                "Ele nunca cobre ícones nem a barra de tarefas: se faltar espaço livre, é reduzido automaticamente."
        )

        // ---- Tipografia
        val h2 = label("Tipografia", 13.5f, ink, true)
        h2.setPadding(0, dp(16), 0, 0)
        c.addView(h2)
        button(c, "Adicionar fonte (TTF ou OTF)") {
            a.menu.hide()
            a.pickFont()
        }

        var target = ClockWidget.DAY
        val summary = label("", 11.5f, sub)
        summary.setPadding(0, dp(10), 0, dp(2))
        val list = column()

        fun selectedName(t: Int): String {
            val f = a.clock.fontFile(t)
            if (f.isEmpty()) return "Padrão"
            return FontStore.list(a).firstOrNull { it.file == f }?.name ?: "Padrão"
        }

        fun fontRow(name: String, file: String, tf: Typeface, selected: Boolean): View {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = box(if (selected) rowBgSel else rowBg, 8)
            row.setPadding(dp(10), dp(6), dp(6), dp(6))
            row.isClickable = true

            val col = column()
            val nm = label((if (selected) "✓  " else "") + name, 11f, if (selected) ctl else sub, selected)
            nm.maxLines = 1
            nm.ellipsize = android.text.TextUtils.TruncateAt.END
            val pv = label(a.clock.text(target), 18f, ink)
            pv.typeface = tf
            pv.maxLines = 1
            pv.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(nm)
            col.addView(pv)
            row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))

            if (file.isNotEmpty()) {
                val del = ImageView(a)
                del.setImageResource(R.drawable.ic_delete)
                del.setColorFilter(sub)
                del.setPadding(dp(8), dp(8), dp(8), dp(8))
                del.isClickable = true
                del.setOnClickListener { deleteFont(file); }
                row.addView(del, LinearLayout.LayoutParams(dp(36), dp(36)))
            }
            val lp = LinearLayout.LayoutParams(match, wrap)
            lp.topMargin = dp(6)
            row.layoutParams = lp
            row.setOnClickListener {
                a.clock.setFontFile(target, file)
                fontsChanged()
            }
            return row
        }

        render = {
            list.removeAllViews()
            val cur = a.clock.fontFile(target)
            val fonts = FontStore.list(a)
            val valid = cur.isNotEmpty() && fonts.any { it.file == cur }
            summary.text = "Dia: " + selectedName(ClockWidget.DAY) +
                "\nData: " + selectedName(ClockWidget.DATE) +
                "\nHorário: " + selectedName(ClockWidget.TIME)
            list.addView(fontRow("Fonte padrão", "", a.clock.defaultTypeface(target), !valid))
            for (f in fonts) {
                list.addView(fontRow(f.name, f.file, FontStore.typeface(a, f.file) ?: a.clock.defaultTypeface(target), valid && f.file == cur))
            }
        }

        choice(c, "Aplicar fonte em", listOf("Dia da semana", "Data", "Horário"), target) {
            target = it
            render?.invoke()
        }
        c.addView(summary)
        c.addView(list, LinearLayout.LayoutParams(match, wrap))
        button(c, "Restaurar fonte padrão") {
            a.clock.setFontFile(ClockWidget.DAY, "")
            a.clock.setFontFile(ClockWidget.DATE, "")
            a.clock.setFontFile(ClockWidget.TIME, "")
            fontsChanged()
        }
        note(
            c,
            "Toque em uma fonte para aplicá-la ao texto escolhido acima; a prévia mostra como ele ficará. " +
                "As fontes ficam guardadas só dentro do WinLauncher e não alteram o Android nem outros apps."
        )
        render?.invoke()
        return c
    }

    /** Redesenha a lista de fontes do painel Widgets aberto no momento. */
    private var render: (() -> Unit)? = null

    private fun fontsChanged() {
        a.clock.applyFonts()
        a.widgetChanged()
        render?.invoke()
    }

    private fun deleteFont(file: String) {
        for (t in listOf(ClockWidget.DAY, ClockWidget.DATE, ClockWidget.TIME)) {
            if (a.clock.fontFile(t) == file) a.clock.setFontFile(t, "")
        }
        FontStore.delete(a, file)
        a.toast("Fonte removida")
        fontsChanged()
    }

    private fun volumeKeysPanel(): View {
        val c = column()
        heading(c, "Botões de volume")
        switchRow(c, "Bloquear botões físicos de volume (aumentar/diminuir)", p.blockVolKeys) { on ->
            p.blockVolKeys = on
            a.toast(if (on) "Botões de volume bloqueados" else "Botões de volume liberados")
        }
        note(c, "Ligado: os botões físicos de volume não fazem nada enquanto o WinLauncher está aberto. Desligado: funcionam normalmente. Em outros apps eles sempre funcionam.")

        val sc = label("Atalho Alt + V dentro de outros apps", 13f, ink, true)
        sc.setPadding(0, dp(18), 0, 0)
        c.addView(sc)
        note(c, "Para o Alt + V abrir o painel de volume também dentro de outros apps, ative \"WinLauncher - atalhos de teclado\" em Acessibilidade (Apps instalados). O serviço só lê as teclas Alt + V.")
        val st = label(
            if (ShortcutService.running) "Status: ativado" else "Status: desativado",
            12f, if (ShortcutService.running) ctl else sub
        )
        st.setPadding(0, dp(4), 0, 0)
        c.addView(st)
        button(c, "Abrir configurações de Acessibilidade") {
            try {
                a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("Não foi possível abrir Acessibilidade")
            }
        }
        return c
    }

    private fun mousePanel(): View {
        val c = column()
        heading(c, "Mouse e interação")

        val arrowIv = ImageView(a)
        val handIv = ImageView(a)
        val busyIv = ImageView(a)
        val previewRow = LinearLayout(a)
        previewRow.orientation = LinearLayout.HORIZONTAL
        previewRow.gravity = Gravity.CENTER
        previewRow.background = box("#7A8794", 8)
        previewRow.setPadding(dp(8), dp(10), dp(8), dp(10))
        for (iv in listOf(arrowIv, handIv, busyIv)) {
            previewRow.addView(iv, LinearLayout.LayoutParams(0, wrap, 1f))
        }
        fun refreshPreview() {
            arrowIv.setImageBitmap(a.cursor.arrowBitmap)
            handIv.setImageBitmap(a.cursor.handBitmap)
            busyIv.setImageBitmap(a.cursor.busyBitmap)
        }
        refreshPreview()

        switchRow(c, "Cursor estilo Windows 11", p.cursorOn) {
            p.cursorOn = it
            a.refreshCursor()
        }
        slider(c, "Tamanho do ponteiro", "ui_cursor_size", 16, 64, 24, " dp") {
            a.refreshCursor()
            refreshPreview()
        }
        val pv = label("Pré-visualização (seta, mão e ocupado)", 12f, sub)
        pv.setPadding(0, dp(10), 0, dp(4))
        c.addView(pv)
        c.addView(previewRow, LinearLayout.LayoutParams(match, wrap))
        note(c, "O cursor personalizado aparece somente sobre as telas do WinLauncher. O Android não permite trocar o cursor do sistema em outros aplicativos com as permissões atuais.")

        choice(c, "Abrir submenus", listOf("Passar o mouse", "Clicar"), if (p.menuHover) 0 else 1) {
            p.menuHover = it == 0
        }

        val status = label("", 12f, ink)
        status.setPadding(0, dp(12), 0, dp(2))
        val detail = label("", 11.5f, sub)
        fun updateStatus() {
            val st = ShizukuBridge.state(a)
            status.text = "Shizuku: " + when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "não instalado"
                ShizukuBridge.State.NOT_RUNNING -> "instalado, serviço parado"
                ShizukuBridge.State.NEEDS_PERMISSION -> "em execução, autorização pendente"
                ShizukuBridge.State.GRANTED -> "conectado e autorizado"
                ShizukuBridge.State.UNSUPPORTED -> "versão incompatível ou indisponível"
            }
            detail.text = when (st) {
                ShizukuBridge.State.NOT_INSTALLED -> "Instale o app Shizuku e inicie o serviço (depuração sem fio ou root). O WinLauncher funciona normalmente sem ele."
                ShizukuBridge.State.NOT_RUNNING -> "Abra o Shizuku e toque em iniciar. Depois volte aqui e atualize o estado."
                ShizukuBridge.State.NEEDS_PERMISSION -> "Toque em \"Solicitar autorização\" e aceite o pedido do Shizuku."
                ShizukuBridge.State.GRANTED -> "Para renovar ou revogar, use o app Shizuku → aplicativos autorizados."
                ShizukuBridge.State.UNSUPPORTED -> "Atualize o Shizuku para a versão mais recente."
            }
        }
        updateStatus()
        ShizukuBridge.onChange = { a.runOnUiThread { updateStatus() } }
        c.addView(status)
        c.addView(detail)
        button(c, "Solicitar autorização do Shizuku") {
            if (!ShizukuBridge.request()) {
                a.toast("Não foi possível pedir agora. Abra o Shizuku → aplicativos autorizados → WinLauncher.")
            }
            updateStatus()
        }
        button(c, "Abrir Shizuku") {
            if (!ShizukuBridge.open(a)) a.toast("Shizuku não encontrado")
        }
        button(c, "Atualizar estado") { updateStatus() }
        note(c, "Nesta versão o Shizuku é usado apenas para mostrar o estado e pedir autorização; o cursor não depende dele.")
        return c
    }
}
