# HANDOFF_WINLAUNCHER — histórico e próximas etapas

Documento principal de continuidade. Os arquivos antigos `HANDOFF.md` … `HANDOFF7.md` continuam no projeto, sem alteração
(são o histórico das funcionalidades do launcher: gerenciador de arquivos, arrastar e soltar, downloads do navegador,
música na barra de tarefas etc.). A partir daqui, atualizar SOMENTE este arquivo.

## Projeto (não mudar sem necessidade)
- Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, Java 17, compileSdk/targetSdk 34, minSdk 26.
- Package/applicationId/namespace: `com.example.winlauncher`.
- Assinatura fixa: `app/debug.keystore` (alias `androiddebugkey`, senha `android`), configurada em `app/build.gradle.kts`.
  Mantém a mesma assinatura entre builds para atualizar o app por cima sem perder dados.
- Interface programática (Views), só framework Android; única dependência: Shizuku (opcional).
- Build: GitHub Actions (Java 17, Gradle 8.7, `assembleDebug`). O arquivo do workflow NÃO está dentro do ZIP
  (vive no repositório); o ZIP não traz `gradlew`/wrapper. O ZIP do projeto é enviado ao repositório e o workflow gera o APK.
- O ambiente onde o código é escrito NÃO tem Android SDK nem kotlinc: nada é compilado aqui. Só o GitHub Actions compila.
- `_wip/` contém rascunhos `.txt` antigos (fora do build). Não mexer.

## Versões
- 2.2 (versionCode 4): versão funcional da Etapa 2.
- 2.3 (versionCode 5): Etapa 3A (primeiro teste no aparelho).
- **2.3.1 (versionCode 6): Etapa 3A + correção 3A.1 da regeneração de chave** (este ZIP). Versão subida só para o APK atualizar por cima da 2.3 já instalada; nenhuma outra mudança além do versionCode/versionName.

## Mapa de etapas do WinLauncher Remote
Numeração atual (a do dono). Equivalência com o antigo HANDOFF7: "etapa 3 = protocolo + servidor de teste" e
"etapa 4 = TLS/Keystore + pareamento" foram reorganizadas em 3A/3B/… abaixo.

- **Etapa 2 — CONCLUÍDA e testada no aparelho real** (YouTube Music ReVanced Morphe): `MediaSessionHub`
  (detecção automática da sessão, identificação do app, capa/título/artista, play/pause, próxima, anterior, abrir o app
  correto) + página de diagnóstico `ytdiag`. NÃO MODIFICAR sem necessidade comprovada.
- **Etapa 3A — IMPLEMENTADA, aguardando teste no aparelho** (ver abaixo).
- **Etapa 3B — NÃO INICIADA (precisa de autorização do dono).** Proposta, a confirmar: servidor TLS de teste usando
  `RemoteAuth.buildServerSslContext()`, ligado ao Hub (só comandos play/pause/próxima/anterior + estado), ainda sem NSD.
- Depois (rascunho, sem compromisso): pareamento completo com número + "Permitir"; NSD + serviço em primeiro plano +
  painel em Configurações; app WinLauncher Remote (projeto Android separado, interface estilo Windows 11); testes em Android 8+.

## Etapa 3A — o que foi feito
Objetivo: base de protocolo e autenticação + teste da chave no Android Keystore + hash do certificado na página de diagnóstico.

Arquivos CRIADOS
- `app/src/main/java/com/example/winlauncher/RemoteProtocol.kt`
- `app/src/main/java/com/example/winlauncher/RemoteAuth.kt`
- `HANDOFF_WINLAUNCHER.md` (este arquivo)

Arquivos MODIFICADOS (somente acréscimos; única linha alterada fora o build.gradle: `})` virou `}),` no SettingsWindow.kt para encaixar a nova linha)
- `app/build.gradle.kts`: versionCode 4→6, versionName 2.2→2.3.1 (5/2.3 na 3A; 6/2.3.1 na correção 3A.1).
- `app/src/main/java/com/example/winlauncher/CustomizeUi.kt`: nova rota `"remotediag"` em `panel()` e nova função
  `remoteDiagPanel()` (logo antes de `mousePanel()`).
- `app/src/main/java/com/example/winlauncher/SettingsWindow.kt`: nova linha "Diagnóstico do Remote (chave e certificado)"
  em Rede e Internet, abaixo do diagnóstico do YouTube Music.

NÃO modificados: `MediaSessionHub.kt`, `AndroidManifest.xml`, `settings.gradle.kts`, `build.gradle.kts` da raiz,
`debug.keystore`, package name. Nenhuma dependência nova (Keystore, JSSE e org.json são do framework).

### RemoteProtocol.kt
- Constantes: VERSION=1, DEFAULT_PORT=48655 e SERVICE_TYPE `_winlauncher._tcp.` (reservadas, ainda não usadas),
  limite de 16 KB por mensagem.
- Mensagens JSON, uma por linha (UTF-8 + `\n`), sempre com `v` e `t`: hello, pair_request, pair_challenge, pair_ok,
  auth, auth_ok, command (play_pause/next/previous), command_result, state, error, ping, pong.
- Validação rígida na decodificação (tipos, tamanhos, formato de id/nonce/token, versão). `readFrame()` lê uma linha com limite.
- `errorFor(MediaSessionHub.Result)` e `stateOf(MediaSessionHub.State)` (só LEEM tipos do Hub; capa fica para depois).
- `selfTest()`: ida e volta de todas as mensagens, rejeições (JSON quebrado, versão, tipo/comando desconhecido, nonce curto,
  id inválido, mensagem/linha enorme, linha cortada) e leitura de linhas.
- Fluxo planejado (documentado no cabeçalho do arquivo): pareamento com número comparado nos dois celulares + "Permitir".

### RemoteAuth.kt
- Chave `winlauncher_remote_server` no Android Keystore: EC P-256 (secp256r1); se falhar (geração ou teste de assinatura),
  apaga e gera RSA 2048. Certificado autoassinado (CN=WinLauncher Remote), validade de 10 anos, criado pelo próprio Keystore.
  Digests: NONE/SHA-256/384/512 (NONE por compatibilidade com o TLS de alguns aparelhos); RSA também PKCS1 e PSS.
- Hash do certificado: SHA-256 do DER (`fingerprint`, `formatFingerprint`, `shortFingerprint`).
- `pairingCode(fpDoServidor, clientNonce, serverNonce)`: 6 dígitos = SHA-256("WLR1|pair|<fp hex>|<nonce cliente>|<nonce servidor>")
  (primeiros 4 bytes mod 1.000.000). Cada lado usa o hash que ELE enxerga, então um intermediário com outro certificado
  gera números diferentes.
- Tokens: 32 bytes aleatórios (base64url); só o SHA-256 do token é guardado. Cadastro de pareados em
  SharedPreferences próprio `win_remote` (separado do `win`): `addPaired`, `removePaired`, `verifyPaired`, `clearPaired`, `pairedList`.
- **Regeneração/perda da chave apaga todos os pareamentos** (também detecta chave ausente ou trocada, por exemplo após restaurar
  backup, comparando o hash guardado com o do certificado atual). A página avisa que os celulares precisarão ser pareados de novo.
- `buildServerSslContext()` e `testSslContext()`: criam SSLContext/SSLEngine com a chave do Keystore apenas para teste.
  **Isso NÃO prova que um servidor TLS funciona**; o handshake real é da Etapa 3B.
- `selfTest()` com itens essenciais (✔/✘) e informativos (ℹ/⚠).

### Página de diagnóstico (temporária)
Configurações > Rede e Internet > "Diagnóstico do Remote (chave e certificado)":
- Estado da chave (algoritmo, local — hardware/StrongBox/software —, validade, pareamentos salvos) e hash SHA-256 do certificado
  (selecionável via botão "Copiar hash do certificado").
- "Executar autoteste": cria a chave se não existir e roda os testes abaixo.
- "Regenerar chave": pede confirmação (tocar duas vezes em 8 s), apaga pareamentos e roda o autoteste de novo.

Itens essenciais do autoteste: 1) chave no Keystore; 2) certificado autoassinado + validade + hash; 3) assinatura;
4) verificação (inclui recusar dado alterado); 5) SSLContext inicializado; 6) protocolo; 7) número de pareamento e tokens.
Informativos: local da chave, protocolos TLS habilitados, alias no gerenciador de chaves, pareamentos salvos/apagados.

## Resultado do primeiro teste no aparelho (Etapa 3A, build 2.3)
- Autoteste: TODOS os itens essenciais ✔. Chave EC P-256 (sem precisar do RSA), local: hardware seguro (TEE),
  TLS habilitado: TLSv1.2 e TLSv1.3, gerenciador de chaves enxerga o alias.
- Fechar e reabrir o app: o hash do certificado CONTINUA o mesmo (chave persiste). ✔
- **"Regenerar chave": o hash NÃO mudou (reportado pelo dono).** Ainda sem causa comprovada.

## Correção 3A.1 — regeneração de chave (arquivos: RemoteAuth.kt e CustomizeUi.kt; versão 2.3.1 / code 6)
Análise do código anterior: `regenerate()` só é chamado pelo botão (nunca ao abrir o app). Ele chamava `deleteKey()`,
que engolia QUALQUER erro em silêncio, e depois `createKey()`; nada confirmava que o alias tinha saído do Keystore e nada
comparava o hash antigo com o novo. Pela leitura, o fluxo parecia correto, então NÃO foi possível apontar a causa só no
papel; a correção faz a regeneração provar cada passo (ou falhar com o motivo), para o próximo teste mostrar onde está o problema.

`RemoteAuth.regenerate()` agora devolve `RegenReport` e lança exceção com o motivo se algum passo falhar:
1. `deleteKeyStrict()`: apaga o alias e confere com uma instância NOVA do Keystore que ele não existe mais; se continuar,
   aborta (chave e pareamentos ficam intactos).
2. `createKey()`: gera nova chave EC P-256 (RSA 2048 se falhar), com assinatura/verificação de teste; o certificado é lido
   de novo do Keystore.
3. Compara o SHA-256 antigo com o novo; se forem iguais, falha com "o hash do certificado não mudou".
4. Apaga os pareamentos e confere que sobraram 0. Se algo falhar depois de apagar a chave antiga, os pareamentos também são apagados.
5. Guarda "última regeneração" (data, hash antigo → novo, algoritmo) e escreve no logcat (tag `WinRemoteAuth`).
Nada em cache: o hash exibido sai sempre do certificado lido no Keystore (`certOrNull()` abre uma instância nova a cada vez).

Interface (Diagnóstico do Remote):
- Sucesso: "✔ CHAVE REGENERADA COM SUCESSO" com: chave antiga apagada (conferido), algoritmo e local da nova chave,
  hash antigo e novo, serial antigo → novo, pareamentos antes/depois e o aviso de que todos precisam ser refeitos.
  O hash na caixa é atualizado na hora e o autoteste roda em seguida.
- Erro: "✘ REGENERAÇÃO FALHOU" com o motivo e o estado real do Keystore depois da tentativa.
- A linha "Última regeneração: …" aparece no status (persiste entre aberturas).
- A regeneração continua SOMENTE pelo botão, com confirmação (tocar duas vezes em 8 s). Nunca automática.

Teste pedido ao dono: abrir o Diagnóstico do Remote, anotar o hash, tocar duas vezes em "Regenerar chave" (segundo toque em
até 8 s) e enviar o texto que aparecer (sucesso ou erro). Se o hash ainda não mudar, o texto do erro (ou o logcat `WinRemoteAuth`) diz o passo.

## FALTA — testar no aparelho real (Etapa 3A) antes da 3B
1. O build do GitHub Actions compila (o código NÃO foi compilado aqui; corrigir qualquer erro de compilação que aparecer).
2. O app atualiza por cima da versão 2.2 sem perder preferências (mesma assinatura).
3. Etapa 2 continua funcionando: página "Diagnóstico do YouTube Music", play/pause, próxima, anterior, capa, abrir o app.
4. Abrir "Diagnóstico do Remote": executar o autoteste e anotar:
   - algoritmo usado (EC P-256 ou RSA 2048, e o motivo se for RSA), local da chave, protocolos TLS listados;
   - se todos os itens essenciais aparecem com ✔;
   - o hash SHA-256 mostrado.
5. Fechar e reabrir o app: o hash deve ser o MESMO (a chave persiste).
6. "Regenerar chave": o hash deve MUDAR; deve aparecer "✔ CHAVE REGENERADA COM SUCESSO" (ou "✘ REGENERAÇÃO FALHOU" com o motivo). (Correção 3A.1)
7. Se algum item ✘ aparecer, copiar o texto do detalhe (modelo do aparelho e versão do Android também).

## Riscos e observações
- `allowBackup=true` no Manifest: chaves do Keystore não vão no backup, mas preferências podem ir. Mitigação já feita:
  pareamentos são apagados se o hash guardado não bater com o certificado atual. Não foi alterado o Manifest.
- Android 8–10 usa TLS 1.2 (TLS 1.3 só no 10+ em alguns casos); a 3B deve validar o handshake nesses níveis.
- Chave com `DIGEST_NONE` adicional: só afeta assinaturas dessa chave (que nunca sai do Keystore).
- As páginas de diagnóstico (`ytdiag` e `remotediag`) são temporárias: NÃO remover sem confirmação do dono.
- O MediaSessionHub em modo automático só escolhe sessões que "parecem YouTube Music"; outros apps exigem escolha manual
  (comportamento já testado). O Remote controlará a sessão selecionada pelo Hub.

## Regras de trabalho combinadas
- Não avançar de etapa sem autorização do dono.
- Ao fim de cada etapa: ZIP completo do projeto + este arquivo atualizado + lista exata de arquivos criados/modificados.
- Preservar package, assinatura, funcionalidades existentes e o MediaSessionHub.
- Sem Shizuku e sem servidores externos no Remote; comunicação local por Wi-Fi com TLS e pareamento seguro.
