# HANDOFF_WINLAUNCHER — histórico e próximas etapas

Documento principal de continuidade. Os arquivos antigos `HANDOFF.md` … `HANDOFF7.md` continuam no projeto, sem alteração
(são o histórico das funcionalidades do launcher: gerenciador de arquivos, arrastar e soltar, downloads do navegador,
música na barra de tarefas etc.). A partir daqui, atualizar SOMENTE este arquivo.

## Projeto (não mudar sem necessidade)
- Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, Java 17, compileSdk/targetSdk 34, minSdk 26.
- Package/applicationId/namespace: `com.example.winlauncher`.
- Assinatura fixa: `app/debug.keystore` (alias `androiddebugkey`, senha `android`), configurada em `app/build.gradle.kts`.
  Mantém a mesma assinatura entre builds para atualizar o app por cima sem perder dados.
- Interface programática (Views), só framework Android; única dependência: Shizuku (opcional).
- Build: GitHub Actions (Java 17, Gradle 8.7, `assembleDebug`). O workflow `.github/workflows/build-debug.yml` ESTÁ dentro do ZIP (conferido na Etapa 3, Bloco 3);
  o ZIP não traz `gradlew`/wrapper (o workflow usa o Gradle 8.7 instalado pela action). O ZIP do projeto é enviado ao repositório e o workflow gera o APK.
- O ambiente onde o código é escrito NÃO tem Android SDK nem kotlinc: nada é compilado aqui. Só o GitHub Actions compila.
- `_wip/` contém rascunhos `.txt` antigos (fora do build). Não mexer.

## Versões
- 2.2 (versionCode 4): versão funcional da Etapa 2.
- 2.3 (versionCode 5): Etapa 3A (primeiro teste no aparelho).
- 2.3.1 (versionCode 6): Etapa 3A + correção 3A.1 da regeneração de chave. Versão subida só para o APK atualizar por cima da 2.3 já instalada.
- 2.4.0 (versionCode 7): Etapa 3B, Parte 1 (servidor TLS local). Sobe por cima da 2.3.1 (mesma assinatura, versionCode maior).
- 2.5.0 (versionCode 8): Etapa 3B, Parte 2 (pareamento, autenticação, música e comandos). Sobe por cima da 2.4.0.
- **2.5.1 (versionCode 9): Etapa 3 (estabilidade do servidor: Blocos 1, 2 e 3) — CÓDIGO E TESTES ESCRITOS; NADA DO BLOCO 3 FOI COMPILADO NEM EXECUTADO** (este ZIP; ver a seção "Etapa 3 — Bloco 3 (estado final)" no fim). Sobe por cima da 2.5.0 (mesma assinatura, versionCode maior). `app/build.gradle.kts`: `versionCode = 9`, `versionName = "2.5.1"`; applicationId e assinatura intactos.

## Mapa de etapas do WinLauncher Remote
Numeração atual (a do dono). Equivalência com o antigo HANDOFF7: "etapa 3 = protocolo + servidor de teste" e
"etapa 4 = TLS/Keystore + pareamento" foram reorganizadas em 3A/3B/… abaixo.

- **Etapa 2 — CONCLUÍDA e testada no aparelho real** (YouTube Music ReVanced Morphe): `MediaSessionHub`
  (detecção automática da sessão, identificação do app, capa/título/artista, play/pause, próxima, anterior, abrir o app
  correto) + página de diagnóstico `ytdiag`. NÃO MODIFICAR sem necessidade comprovada.
- **Etapa 3A — IMPLEMENTADA, aguardando teste no aparelho** (ver abaixo).
- **Etapa 3B — dividida em duas partes.**
  - **Parte 1 — IMPLEMENTADA, NÃO COMPILADA e NÃO TESTADA no aparelho** (ver "Etapa 3B, Parte 1" abaixo): servidor TLS real, serviço em primeiro plano, painel básico e autoteste com handshake TLS real.
  - **Parte 2 — IMPLEMENTADA NO CÓDIGO (2.5.0), NÃO COMPILADA e NÃO TESTADA**: pareamento, aprovação, música, comandos, WifiLock, início automático, notificação de pedido, painel e autoteste da integração (ver a seção "Etapa 3B, Parte 2" no fim).
- Depois (rascunho, sem compromisso): pareamento completo com número + "Permitir"; NSD + serviço em primeiro plano +
  painel em Configurações; app WinLauncher Remote (projeto Android separado, interface estilo Windows 11); testes em Android 8+.

## Etapa 3A — o que foi feito
Objetivo: base de protocolo e autenticação + teste da chave no Android Keystore + hash do certificado na página de diagnóstico.

Arquivos CRIADOS
- `app/src/main/java/com/example/winlauncher/RemoteProtocol.kt`
- `app/src/main/java/com/example/winlauncher/RemoteAuth.kt`
- `HANDOFF_WINLAUNCHER.md` (este arquivo)

Arquivos MODIFICADOS (somente acréscimos; única linha alterada fora o build.gradle: `})` virou `}),` no SettingsWindow.kt para encaixar a nova linha)
- `app/build.gradle.kts`: versionCode 4→6, versionName 2.2→2.3.1 (5/2.3 na 3A; 6/2.3.1 na correção 3A.1).
- `app/src/main/java/com/example/winlauncher/CustomizeUi.kt`: nova rota `"remotediag"` em `panel()` e nova função
  `remoteDiagPanel()` (logo antes de `mousePanel()`).
- `app/src/main/java/com/example/winlauncher/SettingsWindow.kt`: nova linha "Diagnóstico do Remote (chave e certificado)"
  em Rede e Internet, abaixo do diagnóstico do YouTube Music.

NÃO modificados: `MediaSessionHub.kt`, `AndroidManifest.xml`, `settings.gradle.kts`, `build.gradle.kts` da raiz,
`debug.keystore`, package name. Nenhuma dependência nova (Keystore, JSSE e org.json são do framework).

### RemoteProtocol.kt
- Constantes: VERSION=1, DEFAULT_PORT=48655 e SERVICE_TYPE `_winlauncher._tcp.` (reservadas, ainda não usadas),
  limite de 16 KB por mensagem.
- Mensagens JSON, uma por linha (UTF-8 + `\n`), sempre com `v` e `t`: hello, pair_request, pair_challenge, pair_ok,
  auth, auth_ok, command (play_pause/next/previous), command_result, state, error, ping, pong.
- Validação rígida na decodificação (tipos, tamanhos, formato de id/nonce/token, versão). `readFrame()` lê uma linha com limite.
- `errorFor(MediaSessionHub.Result)` e `stateOf(MediaSessionHub.State)` (só LEEM tipos do Hub; capa fica para depois).
- `selfTest()`: ida e volta de todas as mensagens, rejeições (JSON quebrado, versão, tipo/comando desconhecido, nonce curto,
  id inválido, mensagem/linha enorme, linha cortada) e leitura de linhas.
- Fluxo planejado (documentado no cabeçalho do arquivo): pareamento com número comparado nos dois celulares + "Permitir".

### RemoteAuth.kt
- Chave `winlauncher_remote_server` no Android Keystore: EC P-256 (secp256r1); se falhar (geração ou teste de assinatura),
  apaga e gera RSA 2048. Certificado autoassinado (CN=WinLauncher Remote), validade de 10 anos, criado pelo próprio Keystore.
  Digests: NONE/SHA-256/384/512 (NONE por compatibilidade com o TLS de alguns aparelhos); RSA também PKCS1 e PSS.
- Hash do certificado: SHA-256 do DER (`fingerprint`, `formatFingerprint`, `shortFingerprint`).
- `pairingCode(fpDoServidor, clientNonce, serverNonce)`: 6 dígitos = SHA-256("WLR1|pair|<fp hex>|<nonce cliente>|<nonce servidor>")
  (primeiros 4 bytes mod 1.000.000). Cada lado usa o hash que ELE enxerga, então um intermediário com outro certificado
  gera números diferentes.
- Tokens: 32 bytes aleatórios (base64url); só o SHA-256 do token é guardado. Cadastro de pareados em
  SharedPreferences próprio `win_remote` (separado do `win`): `addPaired`, `removePaired`, `verifyPaired`, `clearPaired`, `pairedList`.
- **Regeneração/perda da chave apaga todos os pareamentos** (também detecta chave ausente ou trocada, por exemplo após restaurar
  backup, comparando o hash guardado com o do certificado atual). A página avisa que os celulares precisarão ser pareados de novo.
- `buildServerSslContext()` e `testSslContext()`: criam SSLContext/SSLEngine com a chave do Keystore apenas para teste.
  **Isso NÃO prova que um servidor TLS funciona**; o handshake real é da Etapa 3B.
- `selfTest()` com itens essenciais (✔/✘) e informativos (ℹ/⚠).

### Página de diagnóstico (temporária)
Configurações > Rede e Internet > "Diagnóstico do Remote (chave e certificado)":
- Estado da chave (algoritmo, local — hardware/StrongBox/software —, validade, pareamentos salvos) e hash SHA-256 do certificado
  (selecionável via botão "Copiar hash do certificado").
- "Executar autoteste": cria a chave se não existir e roda os testes abaixo.
- "Regenerar chave": pede confirmação (tocar duas vezes em 8 s), apaga pareamentos e roda o autoteste de novo.

Itens essenciais do autoteste: 1) chave no Keystore; 2) certificado autoassinado + validade + hash; 3) assinatura;
4) verificação (inclui recusar dado alterado); 5) SSLContext inicializado; 6) protocolo; 7) número de pareamento e tokens.
Informativos: local da chave, protocolos TLS habilitados, alias no gerenciador de chaves, pareamentos salvos/apagados.

## Resultado do primeiro teste no aparelho (Etapa 3A, build 2.3)
- Autoteste: TODOS os itens essenciais ✔. Chave EC P-256 (sem precisar do RSA), local: hardware seguro (TEE),
  TLS habilitado: TLSv1.2 e TLSv1.3, gerenciador de chaves enxerga o alias.
- Fechar e reabrir o app: o hash do certificado CONTINUA o mesmo (chave persiste). ✔
- **"Regenerar chave": o hash NÃO mudou (reportado pelo dono).** Ainda sem causa comprovada.

## Correção 3A.1 — regeneração de chave (arquivos: RemoteAuth.kt e CustomizeUi.kt; versão 2.3.1 / code 6)
Análise do código anterior: `regenerate()` só é chamado pelo botão (nunca ao abrir o app). Ele chamava `deleteKey()`,
que engolia QUALQUER erro em silêncio, e depois `createKey()`; nada confirmava que o alias tinha saído do Keystore e nada
comparava o hash antigo com o novo. Pela leitura, o fluxo parecia correto, então NÃO foi possível apontar a causa só no
papel; a correção faz a regeneração provar cada passo (ou falhar com o motivo), para o próximo teste mostrar onde está o problema.

`RemoteAuth.regenerate()` agora devolve `RegenReport` e lança exceção com o motivo se algum passo falhar:
1. `deleteKeyStrict()`: apaga o alias e confere com uma instância NOVA do Keystore que ele não existe mais; se continuar,
   aborta (chave e pareamentos ficam intactos).
2. `createKey()`: gera nova chave EC P-256 (RSA 2048 se falhar), com assinatura/verificação de teste; o certificado é lido
   de novo do Keystore.
3. Compara o SHA-256 antigo com o novo; se forem iguais, falha com "o hash do certificado não mudou".
4. Apaga os pareamentos e confere que sobraram 0. Se algo falhar depois de apagar a chave antiga, os pareamentos também são apagados.
5. Guarda "última regeneração" (data, hash antigo → novo, algoritmo) e escreve no logcat (tag `WinRemoteAuth`).
Nada em cache: o hash exibido sai sempre do certificado lido no Keystore (`certOrNull()` abre uma instância nova a cada vez).

Interface (Diagnóstico do Remote):
- Sucesso: "✔ CHAVE REGENERADA COM SUCESSO" com: chave antiga apagada (conferido), algoritmo e local da nova chave,
  hash antigo e novo, serial antigo → novo, pareamentos antes/depois e o aviso de que todos precisam ser refeitos.
  O hash na caixa é atualizado na hora e o autoteste roda em seguida.
- Erro: "✘ REGENERAÇÃO FALHOU" com o motivo e o estado real do Keystore depois da tentativa.
- A linha "Última regeneração: …" aparece no status (persiste entre aberturas).
- A regeneração continua SOMENTE pelo botão, com confirmação (tocar duas vezes em 8 s). Nunca automática.

Teste pedido ao dono: abrir o Diagnóstico do Remote, anotar o hash, tocar duas vezes em "Regenerar chave" (segundo toque em
até 8 s) e enviar o texto que aparecer (sucesso ou erro). Se o hash ainda não mudar, o texto do erro (ou o logcat `WinRemoteAuth`) diz o passo.

## Etapa 3B, Parte 1 — servidor TLS local (versão 2.4.0 / code 7)
Objetivo: infraestrutura do servidor, sem pareamento e sem música. A 3A (RemoteAuth, RemoteProtocol, diagnóstico `remotediag`) foi preservada.

Arquivos CRIADOS
- `app/src/main/java/com/example/winlauncher/RemoteServer.kt` (servidor, leitor de linhas, autoteste)
- `app/src/main/java/com/example/winlauncher/RemoteServerService.kt` (serviço em primeiro plano)

Arquivos MODIFICADOS (somente acréscimos, exceto versão)
- `app/build.gradle.kts`: versionCode 6→7, versionName 2.3.1→2.4.0.
- `app/src/main/AndroidManifest.xml`: novo `<service android:name=".RemoteServerService">` (exported=false, foregroundServiceType=specialUse + property de subtipo). Nenhuma permissão nova (INTERNET, FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE e POST_NOTIFICATIONS já existiam).
- `app/src/main/java/com/example/winlauncher/CustomizeUi.kt`: rota `"remoteserver"` em `panel()` e função `remoteServerPanel()` (antes de `mousePanel()`).
- `app/src/main/java/com/example/winlauncher/SettingsWindow.kt`: nova linha "Servidor do WinLauncher Remote" em Rede e Internet (a linha anterior passou de `})` para `}),`).
- `HANDOFF_WINLAUNCHER.md` (este arquivo).

NÃO modificados: `RemoteAuth.kt`, `RemoteProtocol.kt`, `MediaSessionHub.kt`, `debug.keystore`, `settings.gradle.kts`, `build.gradle.kts` da raiz, package name, assinatura. Nenhuma dependência nova.

### RemoteServer.kt
- `RemoteServer(ctx, port=48655, allowLoopback=false, maxClients=4, tag, idleMs=45000, pingMs=15000, events)`. Estados: STOPPED, STARTING, RUNNING, STOPPING, ERROR. `start()` nunca lança (falha => ERROR com motivo e tudo liberado); `stop()` é idempotente.
- `start()`: `RemoteAuth.init` + `RemoteAuth.ensureKey()` (cria a chave se não existir; pode apagar pareamentos se a chave tiver mudado, comportamento da 3A) + `RemoteAuth.buildServerSslContext()` + `SSLServerSocket` em 0.0.0.0 (`createServerSocket(port, backlog, InetAddress)`). Protocolos habilitados = TLSv1.3 e TLSv1.2 que o aparelho suportar; sem TLS 1.2 não liga. Sem certificado de cliente.
- Filtro de IP logo depois do `accept()`, ANTES do handshake: só `Inet4Address` em 10/8, 172.16/12, 192.168/16, 169.254/16. Loopback só com `allowLoopback=true` (usado somente nos servidores de teste). Fora disso: fecha com RST e conta em `rejectedCount()`.
- Limite de 4 clientes (contador atômico incluindo quem ainda está no handshake); o 5º é fechado na hora. Uma thread daemon por cliente (`WinRemote-<tag>-client-N`) + uma de aceitação (`WinRemote-<tag>-accept`).
- Tempos: handshake 10 s; leitura com timeout curto; mensagem incompleta por mais de 10 s => erro; sem receber nada por 45 s => desconecta; servidor manda `ping` quando fica 15 s sem receber nada e o cliente deve responder `pong` (qualquer mensagem recebida zera o relógio).
- Protocolo: o primeiro quadro tem de ser `hello` (role "remote", versão 1); o servidor responde `hello` (role "server", id = 32 primeiros hex do hash do certificado, nome = Build.MODEL). `ping`→`pong`. JSON inválido, versão errada, tipo não aceito do cliente, hello repetido, mensagem antes do hello ou maior que 16 KB => `error` + descarta o que sobrou (até 64 KB / 0,5 s, para o erro chegar) + fecha. `auth`/`command` => `error not_paired` (a conexão continua); `pair_request` => `error pairing_denied` ("ainda não disponível"). Gancho `onMessage` (pair_request, auth, command) é onde a Parte 2 entra.
- Leitor próprio `FrameReader` (privado no arquivo) em vez de `RemoteProtocol.readFrame`: o `readFrame` perde os bytes já lidos se o socket der timeout no meio da mensagem. Mesmo limite (16384 bytes sem o `\n`) e mesma decodificação (`RemoteProtocol.decode`).
- `Client.send()` é thread-safe mas NÃO deve ser chamado da thread principal (escrita em socket pode bloquear).
- `stop()`: fecha o socket de escuta, fecha todos os clientes com RST (não trava em cliente lento), espera as threads até ~2 s no total. Deve ser chamado fora da thread principal (o serviço já faz isso).
- `RemoteServer.localAddresses()`: IPv4 locais do aparelho (Wi-Fi/hotspot primeiro) para o painel.
- NÃO referencia o `MediaSessionHub`.

### RemoteServerService.kt
- `RemoteServerService.start(ctx)` / `stop(ctx)` (thread principal), `status` (estado, porta, clientes, erro), `addListener`/`removeListener` (callbacks na thread principal) e `recentLog()` (últimas 40 linhas do servidor).
- Em `onStartCommand(ACTION_START)`: `startForeground` primeiro (notificação persistente, canal `remote_server`, ícone `ic_lock`, id 4715, tipo specialUse no Android 14+), depois o servidor sobe numa thread. A notificação mostra IP:porta e o número de clientes e tem o botão "Desligar" (ACTION_STOP).
- Desligar: `shutdown()` roda `server.stop()` numa thread própria e só então `stopForeground` + `stopSelf`. Falha ao ligar (ex.: porta ocupada): `shutdown(motivo)` => estado final ERROR com o motivo, serviço encerra, nada fica ativo.
- `START_NOT_STICKY`: se o Android matar o serviço, o servidor NÃO volta sozinho (o início automático é da Parte 2). `onDestroy` ainda fecha o servidor se o serviço morrer sem o desligamento normal.
- Sem WifiLock (Parte 2): com a tela apagada o Wi-Fi do aparelho pode dormir e atrapalhar conexões.
- Se as notificações do app estiverem bloqueadas no Android, o serviço funciona mas a notificação não aparece (o painel avisa).

### Painel (Configurações > Rede e Internet > "Servidor do WinLauncher Remote")
Botão Ligar/Desligar, estado, porta, IPs locais (com a interface), clientes conectados (x de 4), protocolo/limites, hash curto do certificado (leitura sem criar chave), erro, últimos eventos e "Executar autoteste do servidor". Não há lista de pareados.

### Autoteste do servidor (`RemoteServerTest.selfTest`)
Roda em thread própria; sobe servidores de teste em porta 0 (NÃO usa a 48655 nem mexe no servidor ligado) e conecta clientes TLS reais por 127.0.0.1 com um TrustManager que fixa o hash do certificado (o mesmo que o app Remote fará). Itens: chave/certificado; regra de IPs (aceita 192.168/10/172.16–31/169.254, recusa públicos, 172.15/172.32, 100.64, loopback, 0.0.0.0, multicast, IPv6); servidor liga; handshake TLS real + certificado confere com o hash da 3A; TLS 1.2; TLS 1.3 (informativo, depende do Android); cliente com hash errado/confiança padrão recusa o handshake (informativo); hello; ping/pong; command/auth sem pareamento => not_paired com a conexão viva; ping antes do hello, JSON quebrado, versão 99, role errado => erro + fechamento; mensagem > 16 KB => too_large + fechamento; limite de 4 clientes (5º recusado, vaga liberada depois); cliente de IP não permitido (servidor de teste sem loopback) recusado antes do hello; ping do servidor e timeout de inatividade (servidor de teste com 1,5 s); desligamento (cliente conectado é desconectado, porta fecha, nenhuma thread `WinRemote-test*` sobra).

### O que FOI e o que NÃO FOI verificado (honestidade)
- NÃO compilado (este ambiente não tem kotlinc nem Android SDK): erros de compilação são possíveis; corrigir o que o GitHub Actions apontar.
- NÃO testado em aparelho: nenhum handshake TLS, nenhuma conexão, nenhum teste da interface, do serviço ou da notificação foi executado de verdade. O autoteste existe, mas ainda não foi rodado.
- Feito aqui: conferência de balanço de chaves/parênteses nos arquivos alterados e um teste da LÓGICA do leitor de linhas portada para Java (mensagem partida por timeout, duas mensagens no mesmo bloco, limite de 16384 bytes, linha cortada). Isso não prova que o código Kotlin compila nem que funciona no Android.

## FALTA — testar no aparelho (Etapa 3B, Parte 1)
1. O build do GitHub Actions compila; o APK 2.4.0 atualiza por cima da 2.3.1 sem perder dados.
2. Etapas 2 e 3A continuam funcionando (diagnóstico do YouTube Music e do Remote, regenerar chave).
3. Painel: ligar => notificação aparece, estado "LIGADO", IP e porta corretos; desligar pelo painel e pelo botão da notificação.
4. "Executar autoteste do servidor": anotar todos os itens (✔/✘/⚠), a versão do Android e o protocolo TLS negociado. Atenção a: TLS 1.2 com chave EC no Keystore, TLS 1.3, contagem de threads no desligamento.
5. Ligar com a porta 48655 ocupada (ou ligar duas vezes) deve dar erro claro e não deixar serviço/notificação.
6. Com o servidor ligado, fechar o launcher/limpar recentes: ver se o serviço continua (esperado) e se desligar ainda funciona.
7. De outro aparelho na mesma rede (ex.: `openssl s_client -connect IP:48655` ou o futuro app Remote): handshake, hello, ping. De fora da rede/IP público: recusado.
8. Hotspot: o IP do aparelho como hotspot (interface ap0/swlan0) aparece na lista e aceita clientes?

## Plano original da Parte 2 (HISTÓRICO: já implementado no código; o estado atual está na seção "Etapa 3B, Parte 2" no fim)
- Pareamento: janela de 2 minutos aberta ao tocar em "Permitir novo pareamento"; fluxo `pair_request` → `pair_challenge` → número de 6 dígitos (`RemoteAuth.pairingCode`) comparado nos dois celulares → `pair_ok(token)`; `RemoteAuth.addPaired`. Fora da janela: `pairing_denied`/`pairing_busy`. Só um pareamento pendente por vez.
- Aprovar/negar SOMENTE dentro do WinLauncher; a notificação só avisa do pedido (sem botões de aprovar).
- `auth` com `RemoteAuth.verifyPaired` (limite de tentativas/`rate_limited`), marcar `Client.authenticated`; lista e revogação de aparelhos no painel.
- Estado musical e comandos: o servidor só REGISTRA um `MediaSessionHub.Listener` (addListener) e o REMOVE (removeListener); nunca reinicia o Hub. ATENÇÃO (achado desta análise): hoje NINGUÉM mantém o Hub ligado — só a página `ytdiag` chama `MediaSessionHub.start()/stop()` (contagem de usos; TaskbarMusic, QuickMusicCard e MusicWidget não usam o Hub). Sem alguém ter chamado `start()`, o Hub não tem sessão e os comandos devolvem NO_SESSION. A Parte 2 precisa de uma decisão do dono sobre quem chama `start()` enquanto o servidor estiver ligado (por exemplo, o servidor usar um par balanceado `start()`/`stop()` da própria contagem de usos do Hub, o que não afeta os outros usuários; ou outra forma). Não chamar `stop()` fora desse par. Os callbacks do Hub vêm na thread principal: o envio para os sockets deve sair dela.
- Mensagens novas no protocolo (acréscimos em `RemoteProtocol.kt`): blocos de capa de até 16 KB com id da capa, índice, total e validação (hash/tamanho) — cada mensagem continua com limite de 16 KB nos dois sentidos.
- `command` (play_pause, next, previous) → `MediaSessionHub.togglePlayPause/next/previous` (postar na thread principal) → `command_result`.
- WifiLock enquanto o servidor estiver ligado (liberar no desligamento e no `onDestroy`).
- Opção "Iniciar o servidor junto com o launcher", desligada por padrão (preferência nova, chave com prefixo `ui_`), com `START_NOT_STICKY` mantido ou decisão explícita.
- Notificação de solicitação de pareamento (canal próprio, só informa).
- Estender o autoteste: pareamento, autenticação, comandos, blocos de capa, WifiLock liberado.
- Depois (sem compromisso): NSD (`_winlauncher._tcp.`), app WinLauncher Remote.

## FALTA — testar no aparelho real (Etapa 3A) antes da 3B
1. O build do GitHub Actions compila (o código NÃO foi compilado aqui; corrigir qualquer erro de compilação que aparecer).
2. O app atualiza por cima da versão 2.2 sem perder preferências (mesma assinatura).
3. Etapa 2 continua funcionando: página "Diagnóstico do YouTube Music", play/pause, próxima, anterior, capa, abrir o app.
4. Abrir "Diagnóstico do Remote": executar o autoteste e anotar:
   - algoritmo usado (EC P-256 ou RSA 2048, e o motivo se for RSA), local da chave, protocolos TLS listados;
   - se todos os itens essenciais aparecem com ✔;
   - o hash SHA-256 mostrado.
5. Fechar e reabrir o app: o hash deve ser o MESMO (a chave persiste).
6. "Regenerar chave": o hash deve MUDAR; deve aparecer "✔ CHAVE REGENERADA COM SUCESSO" (ou "✘ REGENERAÇÃO FALHOU" com o motivo). (Correção 3A.1)
7. Se algum item ✘ aparecer, copiar o texto do detalhe (modelo do aparelho e versão do Android também).

## Riscos e observações
- `allowBackup=true` no Manifest: chaves do Keystore não vão no backup, mas preferências podem ir. Mitigação já feita:
  pareamentos são apagados se o hash guardado não bater com o certificado atual. Não foi alterado o Manifest.
- Android 8–10 usa TLS 1.2 (TLS 1.3 só no 10+ em alguns casos); a 3B deve validar o handshake nesses níveis.
- Chave com `DIGEST_NONE` adicional: só afeta assinaturas dessa chave (que nunca sai do Keystore).
- As páginas de diagnóstico (`ytdiag` e `remotediag`) são temporárias: NÃO remover sem confirmação do dono.
- O MediaSessionHub em modo automático só escolhe sessões que "parecem YouTube Music"; outros apps exigem escolha manual
  (comportamento já testado). O Remote controlará a sessão selecionada pelo Hub.

## Regras de trabalho combinadas
- Não avançar de etapa sem autorização do dono.
- Ao fim de cada etapa: ZIP completo do projeto + este arquivo atualizado + lista exata de arquivos criados/modificados.
- Preservar package, assinatura, funcionalidades existentes e o MediaSessionHub.
- Sem Shizuku e sem servidores externos no Remote; comunicação local por Wi-Fi com TLS e pareamento seguro.


## Etapa 3B, Parte 2 — IMPLEMENTADA NO CÓDIGO (2.5.0 / code 8) — NÃO COMPILADA, NÃO TESTADA

Decisões aprovadas pelo dono: (1) o servidor controla o MediaSessionHub por attach()/detach() com start()/stop() balanceados, sem interromper outros usuários do Hub; (2) limite de tentativas mantido POR IP (5 erros = bloqueio de 60 s) nesta versão; (3) início automático com o launcher, DESLIGADO por padrão.

### Arquivos
CRIADO
- `RemoteBridgeTest.kt`: `FakeMediaPort` (Hub falso: conta start/stop/refresh, registra ouvintes e comandos, devolve o Result escolhido, publica estados na thread principal) e `RemoteBridgeTest.selfTest` (autoteste da integração).

MODIFICADOS nesta sessão (o `RemoteBridge.kt` e os acréscimos do `RemoteProtocol.kt` já vinham do ZIP parcial)
- `RemoteBridge.kt`: uso único (`finished`: depois do detach() não liga de novo); `snapshotArt()` copia/reduz a capa (máx. 320 px) NA THREAD PRINCIPAL antes de ir ao pool (o Hub pode reciclar o bitmap dele).
- `RemoteServerService.kt`: cria UM `RemoteBridge(HubPort)` ao ligar e chama `attach()` ANTES do servidor aceitar conexões; `releaseBridgeAndLocks()` (idempotente) chama `detach()`, solta o WifiLock e cancela o aviso de pareamento em `shutdown()` (inclui falha ao ligar/porta ocupada), `finishStop()` e `onDestroy()`; WifiLock (`WIFI_MODE_FULL_HIGH_PERF`, não contado, `WakeLock` não usado); notificação de pedido de pareamento (canal `remote_pairing`, importância alta, id 4716, expira em 120 s; SÓ informa, sem botões e SEM o número); API estática para o painel: `bridgeInfo`, `openPairing`, `closePairing`, `approvePairing`, `denyPairing`, `revokeDevice` (em thread própria), `addBridgeListener`/`removeBridgeListener`, `wifiLockHeld`, `autoStartIfEnabled`.
- `CustomizeUi.kt` (`remoteServerPanel`): opção "Iniciar o servidor junto com o WinLauncher"; seção Pareamento (botão "Permitir novo pareamento (2 minutos)", contagem regressiva, número de 6 dígitos com Permitir/Negar, cancelar janela); lista de aparelhos pareados com "Remover" (dois toques em 6 s); linha do WifiLock no status; segundo botão "Executar autoteste da integração"; textos atualizados.
- `Prefs.kt`: `remoteAutostart` (`ui_remote_autostart`, padrão false). `MainActivity.kt`: `window.decorView.post { RemoteServerService.autoStartIfEnabled(this) }` no fim do onCreate.
- `AndroidManifest.xml`: permissão `WAKE_LOCK` (necessária ao WifiLock). `app/build.gradle.kts`: versionCode 7→8, versionName 2.4.0→2.5.0.
NÃO modificados: `MediaSessionHub.kt`, `RemoteAuth.kt`, `RemoteServer.kt`, `debug.keystore`, package e assinatura.

### Como funciona
- Ligar: serviço em primeiro plano -> bridge.attach() (um start() do Hub, ouvinte registrado) + WifiLock -> servidor sobe numa thread. Desligar/erro/onDestroy: bridge.detach() (stop() só se o start() deu certo; remove o ouvinte) + WifiLock liberado + servidor parado.
- Pareamento: janela de 2 min aberta pelo botão; pair_request -> pair_challenge; o painel mostra o número de 6 dígitos que o Remote também calcula; Permitir/Negar SÓ dentro do WinLauncher; um pedido pendente por vez (pairing_busy); pedido pendente expira em 120 s; janela fecha ao aceitar um pedido.
- Autenticação: `auth` com `RemoteAuth.verifyPaired`; 5 erros do mesmo IP em 60 s bloqueiam o IP por 60 s (rate_limited), inclusive com token certo. Estado e capa só vão a clientes autenticados. Comandos: máx. 10 por segundo por cliente.
- Revogar: remove o pareamento e derruba (RST) todas as conexões desse aparelho; funciona também com o servidor desligado (só apaga o pareamento).
- Início automático: só quando o launcher abre (não há receptor de BOOT_COMPLETED). Se o Android recusar iniciar o serviço em segundo plano, o painel mostra o erro.

### Autoteste da integração (`RemoteBridgeTest`, botão no painel)
Sobe 3 servidores de teste (porta aleatória) + bridges com `FakeMediaPort` e clientes TLS reais por 127.0.0.1. Não usa a porta 48655, não mexe no servidor ligado nem no Hub real; usa ids `BridgeTestDevA01/B02/C03`, removidos no começo e no fim (os pareamentos reais não são tocados). Itens: Hub start/stop balanceados e bridge de uso único; start() que falha não gera stop(); pareamento sem janela negado; pareamento completo (número confere, token válido); Negar; pairing_busy; expiração da janela e do pedido; auth certo/errado/id trocado; comando sem auth; play_pause/next/previous no Hub; unavailable/no_session no command_result; rate_limited de comandos; estado só para autenticados; capa em blocos (SHA-256, artId, JPEG ≤ 320 px, cliente tardio recebe a mesma capa); revogação; 5 erros por IP; desligamento (Hub 1x start/1x stop, ouvinte removido, nenhuma thread `WinRemote-btest*`).

### O que FOI e o que NÃO FOI verificado (honestidade)
- NÃO compilado: este ambiente não tem kotlinc nem Android SDK. Só foram feitas conferência de balanço de chaves/parênteses nos arquivos alterados e checagem manual de símbolos/assinaturas contra o código existente. Erros de compilação são possíveis; corrigir o que o GitHub Actions apontar.
- NÃO executado: o autoteste da integração (e o do servidor) nunca rodou; nenhum teste em aparelho; WifiLock, notificação, painel e início automático não foram vistos funcionando.
- Teste manual possível sem o app Remote: `openssl s_client -quiet -connect IP:48655`, mandar linhas JSON (`{"v":1,"t":"hello","version":1,"deviceId":"ManualTest0001","deviceName":"openssl","role":"remote"}`, `{"v":1,"t":"ping"}`) cobre hello/ping/erros. O pareamento completo exige calcular o número (SHA-256) e só é coberto pelo autoteste da integração ou pelo futuro app Remote.

### Riscos e limites conhecidos
- Limite de tentativas por IP: em hotspot/NAT vários aparelhos podem compartilhar o IP e se bloquear juntos (aceito pelo dono nesta versão).
- Um aparelho da rede pode ocupar a janela de pareamento com um pedido; o usuário deve negar se o número não for igual ao do Remote. O nome do aparelho aparece na notificação e no painel: é texto enviado pelo cliente (controles removidos, 64 caracteres).
- Cliente não autenticado pode ocupar uma das 4 vagas (rede local, timeout de 45 s). Escrita em socket travada não tem timeout (o desligamento fecha com RST).
- WifiLock: `FULL_HIGH_PERF` está obsoleto no Android recente e pode não ser respeitado com a tela apagada; não há WakeLock de CPU (decisão de bateria). Testar com a tela apagada.
- `allowBackup=true`: pareamentos vão no backup mas a chave do Keystore não; ao restaurar, o hash não bate e os pareamentos são apagados (comportamento da 3A, testar).
- O Hub só escolhe sozinho sessões "tipo YouTube Music"; outros players exigem escolha manual (Etapa 2).

## FALTA — testar no aparelho (Etapa 3B, Parte 2)
1. O build do GitHub Actions compila (corrigir erros). O APK 2.5.0 atualiza por cima da 2.4.0.
2. Etapas 2, 3A e 3B Parte 1 continuam funcionando (ytdiag, remotediag, servidor, autoteste do servidor).
3. "Executar autoteste da integração": anotar todos os itens (✔/✘/⚠) e a versão do Android.
4. Ligar o servidor: aparece a linha "WifiLock: ativo"; o Hub funciona sem abrir o ytdiag; música do YouTube Music segue funcionando na barra de tarefas e no cartão rápido (o Remote não deve atrapalhar).
5. Desligar (painel e notificação) e fechar o launcher com o servidor ligado: nada fica ativo; o ytdiag continua fazendo seu próprio start()/stop().
6. Pareamento com o app Remote real quando existir (ou script): número igual nos dois lados, Permitir, Negar, expiração, remover.
7. Início automático: ligar a opção, fechar e abrir o launcher; desligar a opção e confirmar que não liga sozinho.
8. Tela apagada por alguns minutos com o Remote conectado: a conexão sobrevive?

## Próxima etapa sugerida
Compilar e testar a Parte 2 no aparelho; só depois iniciar o app WinLauncher Remote (projeto Android separado) e, opcionalmente, NSD (`_winlauncher._tcp.`). Não avançar sem autorização do dono.

## Etapa 1A — Permissão de notificações (POST_NOTIFICATIONS)
- `MainActivity.kt`: novo `startRemoteServerAskingNotifications()` (usado pelo botão "Ligar servidor"). No Android 13+, se a permissão não está concedida e ainda não foi pedida (`remote_notif_asked` em prefs "win"), pede uma vez e liga o servidor no `onRequestPermissionsResult` (REQ_NOTIF_REMOTE=21), concedida ou negada. Caso contrário liga direto. Guarda `remoteNotifPending` contra toques repetidos.
- `CustomizeUi.kt`: botão de ligar chama o método acima. Início automático não pede permissão. Backups em `_backup_etapa1A/`. Não compilado nem testado.

## Etapa 1B — Proteção contra regeneração da chave (CONCLUÍDA no código; NÃO compilada nem executada)
- `RemoteAuth.kt`: `regenBlockedReason()` consulta o estado real (`RemoteServerService.status.state`): bloqueia em STARTING, RUNNING e STOPPING; libera em STOPPED e ERROR. `regenerate()` chama a verificação ANTES de tocar na chave/pareamentos e lança `RegenBlockedException` (nada é alterado). Novo teste não destrutivo `regenGuardTest()` (simula estados via `testServerState`, confere que chave e pareamentos não mudam) incluído no `selfTest()` como "Proteção contra regeneração com o servidor ligado". Nenhum teste existente foi removido.
- `CustomizeUi.kt`: o botão "Regenerar chave" consulta `regenBlockedReason()` a cada toque (antes de armar e antes de confirmar), mostra a mensagem "desligue o servidor primeiro" e trata `RegenBlockedException` caso o servidor ligue entre o toque e a execução.
- Não alterados: pareamentos, protocolo, notificações (Etapa 1A), RemoteServerService, assinatura/applicationId. Backups em `_backup_etapa1B/`.
- Limite do teste: a regeneração real com servidor desligado não é exercida no autoteste (apagaria a chave e os pareamentos); só a decisão de liberar é testada.

## Etapa 2A — Timeout de autenticação (CONCLUÍDA no código; verificada numa JVM, NÃO compilada com Gradle/Android)
Arquivos modificados: `RemoteServer.kt`, `RemoteBridgeTest.kt`, `HANDOFF_WINLAUNCHER.md`. Backups em `_backup_etapa2A/`. Não alterados: protocolo, pareamento, RemoteBridge.kt, RemoteAuth.kt, limite de conexões por IP, Etapas 1A/1B.
- `RemoteServer`: novo parâmetro `authMs` (padrão `AUTH_TIMEOUT_MS = 15_000`). Uma thread vigia por servidor (`WinRemote-<tag>-watchdog`, daemon) verifica a cada ≤250 ms e fecha com RST todo cliente que NUNCA se autenticou e passou de `authMs` desde o accept() (o prazo inclui o handshake TLS; cliente mudo, cliente só com hello e cliente ativo com ping/pong são todos desconectados; atividade não estende o prazo; fechar o socket também destrava handshake parado).
- Clientes autenticados nunca são desconectados por isso. `Client.authenticated` agora tem setter que marca `authSeen`; se o pareamento for revogado depois (`authenticated=false`) o prazo não reabre.
- Liberação: a thread do cliente cai no `finish()` existente (remove da lista, devolve a vaga, `onClientClosed` -> o bridge descarta pedido de pareamento pendente do cliente). A vigia é interrompida e aguardada no `stop()`; `liveThreads()` a conta. Novos: `authTimeoutMs`, `authTimeoutCount()`.
- ATENÇÃO (decisão do dono): o prazo é duro e vale também para pedido de pareamento aguardando "Permitir" (antes o pedido durava até 120 s; agora o usuário precisa tocar em Permitir em até 15 s desde a conexão do Remote). Para isentar clientes com pedido pendente, basta o vigia pular o cliente que for o `pending` do bridge (alteração pequena, não feita).
- O servidor não envia mensagem de erro antes de fechar por timeout (RST direto, para o vigia nunca travar em escrita); o cliente vê a conexão cair.
- Testes novos: `RemoteServerTest.selfTest` +7 itens (prazo padrão 15 s; 15 s reais ~15 s de duração; cliente mudo; cliente ativo sem autenticar; TCP sem handshake TLS; autenticado sobrevive e o vizinho não autenticado cai, inclusive após `authenticated=false`; vagas voltam e threads não sobram; desligamento confere `liveThreads()==0`). `RemoteBridgeTest.selfTest` +1 item (servidor 4, prazo 3 s, id `BridgeTestDevD04`: pedido pendente descartado, cliente mudo desconectado, autenticado permanece, novo pedido aceito depois). Nenhum teste existente removido. O autoteste do servidor fica ~17 s mais longo.
- VERIFICAÇÃO REAL feita aqui (kotlinc 1.9.24 + JVM 21, pasta `_harness_jvm_etapa2A/`): `RemoteProtocol.kt`, `RemoteServer.kt`, `RemoteBridge.kt`, `RemoteBridgeTest.kt` compilados juntos e os dois autotestes executados com TLS real em 127.0.0.1: servidor 23/23 OK (33 s), integração 20/20 OK (9 s), incluindo todos os testes antigos. Prazo real medido ~15,0–15,2 s.
- LIMITES: o harness usa stubs de `android.*`, `org.json` e `MediaSessionHub`, e um `RemoteAuth` falso (chave de keytool, pareamentos em memória). NÃO foram compilados nem executados: `RemoteAuth.kt` real, Android Keystore, Gradle/AGP, Conscrypt (comportamento de `close()` durante handshake no Android), notificações, painel. Rodar os dois autotestes no aparelho e anotar ✔/✘.
- Pendente para o aparelho: confirmar que o prazo de 15 s é suficiente para o fluxo real de pareamento (tocar em Permitir).


## Etapa 2B — Limite de 2 conexões simultâneas por IP (CONCLUÍDA no código; verificada numa JVM; NÃO compilada com Gradle/Android)
Arquivos modificados: `RemoteServer.kt`, `RemoteBridgeTest.kt`, `HANDOFF_WINLAUNCHER.md`. Backups em `_backup_etapa2B/`. Não alterados: protocolo, pareamento, RemoteBridge.kt, RemoteAuth.kt, MediaSessionHub, RemoteServerService (usa o padrão), prazo de 15 s da 2A, Etapas 1A/1B.
- Nova classe `IpLimiter(max)` (em `RemoteServer.kt`): `tryAcquire(ip)` reserva a vaga de forma atômica sob um lock; devolve `Slot` cuja `release()` é idempotente (AtomicBoolean). Registro do IP some quando chega a 0; contador nunca negativo; `reset()` troca a "época" (liga/desliga do servidor) e vagas antigas liberadas depois são ignoradas.
- `RemoteServer`: parâmetro `maxPerIp` (padrão `MAX_PER_IP = 2`). Em `handleAccepted`, depois do filtro de IP de rede local e ANTES do handshake TLS e da criação da thread: sem vaga por IP => recusa imediata com RST (conta em `rejectedCount()` e `ipRejectedCount()`); se o limite global (4) estourar, a vaga por IP é devolvida. A vaga é devolvida em `Client.finish()` (todo caminho de término, incluindo erro de handshake, erro de protocolo, timeout de 2A, desligamento) e em `abandon()` se a thread não puder iniciar. Clientes existentes nunca são tocados por uma recusa. Novos: `maxConnectionsPerIp`, `ipRejectedCount()`, `ipClientCount(ip)`, `trackedIpCount()`.
- Testes: `RemoteServerTest` +8 itens "Limite por IP" (constante 2; 2 aceitas e a 3ª recusada sem prejudicar as existentes; vaga reaproveitada; outro IP via 127.0.0.2 [informativo]; falhas liberam vaga: TCP sem TLS, bytes não-TLS, erro de protocolo, timeout de auth; corrida com 16 conexões simultâneas => exatamente 2; 25 rodadas de conectar/desconectar com contador final 0 e nenhum IP registrado; IpLimiter direto com 64 threads, liberação repetida, reset). Desligamento confere `trackedIpCount()==0`. Servidores de teste ANTIGOS (todos conectam de 127.0.0.1) passaram a ser criados com `maxPerIp = 16` para continuar testando o que testavam (limite de 4 clientes, bridge etc.); nenhum teste removido.
- VERIFICAÇÃO feita aqui (kotlinc 1.9.24 + JVM 21, `_harness_jvm_etapa2A/`, TLS real em 127.0.0.1): autoteste do servidor 31/31 OK (23 antigos + 8 novos, 42 s); autoteste da integração 20/20 OK (9 s).
- LIMITES: mesmos da 2A (stubs de android.*, org.json, MediaSessionHub; RemoteAuth falso). NÃO compilado/executado: RemoteAuth real, Keystore, Gradle/AGP, Android. O teste de "outro IP" usa 127.0.0.2 como origem, que pode não funcionar em todo Android (item informativo; a lógica por IP também é coberta pelo teste direto do IpLimiter).
- Riscos: vários aparelhos atrás do mesmo NAT/hotspot dividem o limite de 2; um Remote que reconecta antes de a conexão antiga cair (até 45 s de inatividade, ou 15 s se ainda não autenticado) pode ser recusado se já houver 2 conexões do seu IP.

## Etapa 3 — ESTABILIDADE DO SERVIDOR (EM ANDAMENTO — PONTO DE RESTAURAÇÃO INICIAL)
Este ZIP (`WinLauncher_2_5_0_etapa3_backup_inicial`) é um ponto de restauração no meio do Bloco 1. Partiu do ZIP validado da Etapa 2B (conferido: idêntico à 2B entregue; versionCode 8 / 2.5.0; `IpLimiter` presente).

### Escopo confirmado pelo dono
1. Proteger contra escritas travadas em sockets.
2. Corrigir problemas de desligamento e religamento rápido do servidor.
3. Melhorar o gerenciamento da fila de capas dos álbuns.
4. Criar testes para todas essas situações; preservar todos os testes e funcionalidades das Etapas 1A, 1B, 2A e 2B.
Decisões: manter o timeout de autenticação de 15 s, inclusive para pedido de pareamento pendente; NÃO implementar substituição de conexão por deviceId; NÃO implementar protocolo v2 (é a Etapa 4); NÃO alterar o protocolo atual; NÃO modificar o MediaSessionHub sem necessidade comprovada; manter o limite de 2 conexões por IP. Versão: preparar versionCode 9 / versionName 2.5.1 (applicationId e assinatura intactos). NÃO iniciar Etapa 4 ou 5 sem autorização.

### Analisado (código lido, achados)
- Escrita: `Client.send()` não tinha prazo; cliente autenticado que para de ler prende a thread do bridge (`Out.drain`), segura o `writeLock` e bloqueia a leitura do próprio cliente (pongs/erros também passam por `send`). O prazo de autenticação (2A) não alcança autenticados.
- Desligamento/religamento (a implementar, Bloco 2): (a) `RemoteServerService` cria a thread `WinRemote-starter` que chama `srv.start()`; se `shutdown()` roda antes do `start()`, o `stop()` é no-op e o servidor sobe DEPOIS (servidor órfão escutando); (b) `onStartCommand(ACTION_START)` com `shuttingDown` retorna sem fazer nada (um "Ligar" durante o desligamento é ignorado e, se já tiver saído do primeiro plano, não chama `startForeground`: risco de exceção do Android); (c) bind sem `SO_REUSEADDR` explícito nem nova tentativa: religar rápido na mesma porta pode dar "Address already in use". Plano: `RemoteServer.stop()` numa instância nunca iniciada cancela o `start()` seguinte; bind com `setReuseAddress(true)` + novas tentativas curtas; no serviço, "Ligar" durante o desligamento vira religamento pendente (`restartPending`) tratado em `finishStop()`, e "Desligar" o cancela; lógica de decisão extraída para uma classe pura testável na JVM.
- Capas (Bloco 3): cada capa tem até 22 blocos de 9000 B e a fila por cliente (`MAX_QUEUE = 64`) acumula blocos de capas antigas quando o cliente é lento (troca rápida de faixa) e pode desconectar um cliente saudável; jobs de codificação usam o pool sem cancelar jobs obsoletos. Plano: pool de uma thread para capas com descarte de job obsoleto; `Out.postArt` atômico que remove da fila capas antigas ainda não iniciadas, e se não couber, manda só o estado com `artId` vazio para aquele cliente (sem desconectar); contadores para testes.

### Implementado até aqui (Bloco 1 — escrita travada; EM ANDAMENTO)
Arquivo alterado: `RemoteServer.kt` (backups em `_backup_etapa3/`).
- Novos parâmetros do `RemoteServer`: `writeMs` (padrão `WRITE_TIMEOUT_MS = 10_000`), `sndBufBytes` (só testes). `Client.send()` registra `writeSince` dentro do `writeLock`; o vigia da 2A (a mesma thread `WinRemote-<tag>-watchdog`) chama `Client.enforceWriteDeadline(now)` e fecha com RST a conexão cuja escrita passou de `writeMs` (vale para autenticados). Novos: `writeTimeoutMs`, `writeTimeoutCount()`. Passo do vigia = min(authMs, writeMs)/4 (50–250 ms).
- Testes novos no `RemoteServerTest`: "Escrita travada" ×4 (prazo padrão 10 s; cliente que para de ler é derrubado no prazo e a vaga volta; cliente lento que continua lendo NÃO é derrubado; `stop()` com escrita presa não trava e libera a thread). Servidores de teste `srvW` (1,5 s) e `srvW2` (120 s) com buffer de envio de 8 KB.
- Última execução na JVM (antes do último ajuste): servidor 35 itens, 34 OK e 1 falha DO TESTE (a mensagem de enchimento não era um bloco de capa válido para o decodificador do cliente: "campo 'id' fora do formato"); integração 20/20 OK. O ajuste (usar `RemoteProtocol.artChunks(...)[0]`) JÁ ESTÁ GRAVADO no código mas NÃO foi reexecutado: rodar o harness e confirmar.

### Ainda falta
- Bloco 1: reexecutar e confirmar os 4 testes de escrita; ZIP do bloco.
- Bloco 2: desligamento/religamento rápido (servidor + serviço) e testes (religar 20× na mesma porta, stop antes do start, stop durante start, lógica do religamento pendente); ZIP do bloco.
- Bloco 3: fila de capas (RemoteBridge.kt) e testes no `RemoteBridgeTest`; versionCode 9 / versionName 2.5.1 em `app/build.gradle.kts` (hoje ainda 8 / 2.5.0); regressão completa; HANDOFF final; ZIP `WinLauncher_2_5_0_etapa3_...`.
- Nada da Etapa 3 foi compilado com Gradle nem testado no Android. Verificação é só na JVM com stubs (`_harness_jvm_etapa2A/`; harness de trabalho em `/home/claude/work/harness`, script `run.sh`).

### [PONTO DE RESTAURAÇÃO] Bloco 1 CONCLUÍDO — escrita travada (ZIP `WinLauncher_2_5_0_etapa3_bloco1_escrita`)
Teste na JVM após o ajuste: servidor 35/35 OK (4 itens "Escrita travada" incluídos), integração 20/20 OK. Parada de escrita medida: 1,69 s para prazo de 1,5 s; `stop()` com escrita presa levou ~1 ms. Falta: Bloco 2 (desligamento/religamento) e Bloco 3 (capas + versão 9 / 2.5.1). Não compilado com Gradle; não testado no Android.

### [PONTO DE RESTAURAÇÃO] Estado ao fim do Bloco 1 (ZIP `WinLauncher_2_5_0_etapa3_parcial_bloco1`)
- Código alterado até agora: SÓ `RemoteServer.kt` (Bloco 1). Bloco 2 e Bloco 3 NÃO foram iniciados no código (nenhuma edição em `RemoteServerService.kt`, `RemoteBridge.kt`, `RemoteBridgeTest.kt` nem `build.gradle.kts`; versão continua 8 / 2.5.0).
- Detalhes extras levantados para o Bloco 2: além dos itens já listados, `RemoteServerService.start(ctx)` (companion) retorna sem fazer nada se `instance != null` (serviço ainda existe durante o desligamento), então "Ligar" logo após "Desligar" é ignorado já na origem; `onStartCommand` também ignora com `shuttingDown`. Plano: classe pura `RemoteLifecycleGate` (fases IDLE/RUNNING/STOPPING + `restartPending`) usada pelo serviço, `startForeground` repetido ao receber "Ligar" durante o desligamento (contrato do Android), religamento em `finishStop()`, "Desligar" cancela o religamento; no `RemoteServer`: `stop()` em instância nunca iniciada cancela o `start()` seguinte; bind com `SO_REUSEADDR` e novas tentativas curtas em "Address already in use" (com fallback para o `createServerSocket(port, backlog, addr)` atual).
- Verificação: JVM com stubs, servidor 35/35 e integração 20/20 (último rodízio, Bloco 1). Nada compilado com Gradle nem testado no Android.

### [PONTO DE RESTAURAÇÃO] Bloco 2 CONCLUÍDO — desligamento/religamento (ZIP `WinLauncher_2_5_0_etapa3_parcial_bloco2`)
Arquivos alterados: `RemoteServer.kt`, `RemoteServerService.kt`; NOVO `RemoteLifecycleGate.kt`; harness (`run.sh` inclui o gate; `svc_stubs/`). Originais pré-Bloco 2 em `_backup_etapa3_bloco2/`. NÃO alterados: `MediaSessionHub`, `RemoteBridge`, `RemoteProtocol`, `RemoteAuth`, `build.gradle.kts` (versão continua 8 / 2.5.0; a subida para 9 / 2.5.1 é do Bloco 3). Protocolo, prazo de autenticação de 15 s, limite de 2 conexões por IP e prazo de escrita de 10 s preservados.

Problemas corrigidos
1. Servidor órfão (stop antes do fim da inicialização): `RemoteServer.stop()` sinaliza o cancelamento ANTES de pegar o lock (contador `pendingStops`). Um `stop()` numa instância que nunca ligou marca `cancelled` e o `start()` seguinte devolve false (estado STOPPED, sem erro). Um `stop()` durante o `start()` interrompe a espera por porta e o start termina em STOPPED. A thread `WinRemote-starter` do serviço ainda faz um `stop()` extra se `server !== srv` (cinto de segurança).
2. "Ligar" durante o desligamento: `RemoteLifecycleGate` (IDLE/ACTIVE/STOPPING + `restartPending`). O companion `start()` registra o religamento; `finishStop()` liga um servidor NOVO no mesmo serviço, sem sair do primeiro plano. "Desligar" cancela o religamento e também cancela "Ligar" ainda em trânsito (o Android entrega o pedido e o serviço o descarta). `onStartCommand` chama `startForeground()` em TODOS os caminhos (contrato do `startForegroundService`). Eventos agora são por servidor (`ServerEvents.owner`): avisos atrasados de um servidor antigo não afetam o novo. `onDestroy` só zera `instance` se for o próprio e devolve o gate a IDLE.
3. Porta ocupada: bind com `SO_REUSEADDR` (socket não ligado + `bind`; se a fábrica não oferecer, cai no `createServerSocket(porta, backlog, endereço)` de antes) e até `BIND_ATTEMPTS = 12` tentativas de `BIND_RETRY_MS = 250` ms (~3 s) só para "Address already in use". Parâmetros `bindAttempts`/`bindRetryMs` no construtor (testes usam valores curtos).

Testes (JVM com stubs): +9 itens no `RemoteServerTest` (gate: sequências e corrida com 8 threads; stop antes do start; stop/start concorrentes em 40 rodadas com atrasos variados; porta ocupada: liga ao liberar, ERROR sem liberar, stop durante a espera; 20 ciclos na mesma porta com instância nova a cada ciclo e 20 com a mesma instância).
- Servidor 44/44 (35 antigos + 9 novos): 6 execuções sozinhas sem falha. Integração 20/20 (2 execuções).
- Mutação: sem a proteção de cancelamento, 3 testes falham (os testes detectam o defeito).
- INSTABILIDADE CONHECIDA (anterior ao Bloco 2): os testes de "Limite por IP" usam conexões reais e dependem de tempo. Rodando 3 execuções em paralelo (CPU carregada), o código NOVO falhou 1 de 3 em "contador correto depois de muitas conexões" ("1ª recusada") e o código ORIGINAL do Bloco 1 falhou 1 de 6 em "falhas liberam a vaga" ("Broken pipe"). Sozinhos, passam. Os testes antigos não foram alterados.
- `RemoteServerService.kt` foi compilado contra stubs de Android (`_harness_jvm_etapa2A/svc_stubs/`), só para checar tipos; o serviço NÃO é executado em nenhum teste.

NÃO VALIDADO: build com Gradle/AGP; funcionamento no Android real (foreground service, notificação, `startForegroundService` durante o desligamento, WifiLock, religamento pelo painel, `Address already in use` real do Android). Teste manual sugerido no aparelho: ligar, desligar e religar em sequência rápida pelo painel e pela notificação; desligar logo após ligar; ligar com a porta 48655 ocupada por outro app.
Limitação conhecida: o painel (`CustomizeUi`) ignora o botão durante STARTING/STOPPING; o religamento pendente vale para chamadas diretas (início automático, permissão de notificação etc.). Isso não foi mudado.

Falta: Bloco 3 (fila de capas em `RemoteBridge.kt`; versionCode 9 / 2.5.1; regressão completa; HANDOFF final). NÃO iniciado.

### [HISTÓRICO — SUPERADO pela seção "Bloco 3 (estado final)" abaixo] Bloco 3 EM ANDAMENTO (ZIP `WinLauncher_2_5_0_etapa3_bloco3_wip`)
Base: ZIP final do Bloco 2 (o único anexo da conversa continua sendo o ZIP do Bloco 1; o Bloco 3 partiu do ZIP do Bloco 2 entregue antes).
Escrito em `RemoteBridge.kt` (único arquivo de código alterado; original do Bloco 2 em `/tmp` não vai no ZIP, use `_backup_etapa3_bloco2/` só para RemoteServer/Service; para o RemoteBridge do Bloco 2 use o ZIP `..._parcial_bloco2`):
- Preparação de capa numa ÚNICA thread (`WinRemote-<tag>-art`) com no máximo 1 trabalho esperando (o mais novo substitui o anterior e libera o bitmap copiado); trabalho em andamento obsoleto (faixa mudou, sem capa, detach) para nos pontos de controle; faixa sem capa cancela o trabalho esperando.
- `Out.postArt` atômico: remove capas antigas ainda não iniciadas (bloco 0 ainda na fila), não duplica capa já na fila, e se capa+estado não couberem em `maxQueue` envia só o estado com `artId` vazio, sem desconectar; estados seguintes só citam um `artId` que o cliente realmente recebeu.
- Contadores/diagnóstico para testes (`artJobsSubmitted/Encoded/Discarded`, `artChunksDropped`, `artSkippedCount`, `artLiveSnapshots`, `artPendingJobs`, `outCount`), `maxQueue` no construtor, `artEncodeDelayMs` (só testes).
Status: COMPILA no harness JVM. Testes novos NÃO escritos; integração e servidor NÃO reexecutados depois da mudança. Versão ainda 8 / 2.5.0 (falta subir para 9 / 2.5.1). Nada compilado com Gradle nem testado no Android.


### Etapa 3 — Bloco 3 (estado final): fila de capas — CÓDIGO E TESTES ESCRITOS, NADA COMPILADO NEM EXECUTADO (2.5.1 / code 9)
ZIP: `WinLauncher_2_5_1_etapa3_bloco3_completo_nao_validado`. Partiu do ZIP `..._bloco3_wip`.

**Arquivos alterados no Bloco 3** (todo o Bloco 3, contando o trabalho anterior):
- `RemoteBridge.kt` — implementação da fila de capas (escrita na sessão anterior; NÃO foi tocada na sessão final).
- `RemoteBridgeTest.kt` — 8 verificações novas + auxiliares (esta sessão; só acréscimos, ver abaixo).
- `app/build.gradle.kts` — `versionCode = 9`, `versionName = "2.5.1"` (esta sessão).
- `HANDOFF_WINLAUNCHER.md` — esta seção, a linha de versões e a correção sobre o workflow.
Não alterados no Bloco 3: `RemoteServer.kt`, `RemoteServerService.kt`, `RemoteLifecycleGate.kt` (Blocos 1 e 2), `RemoteProtocol`, `RemoteAuth`, `MediaSessionHub`, protocolo, prazo de autenticação de 15 s, limite de 2 conexões por IP, prazo de escrita de 10 s, manifesto, assinatura. `RemoteBridge.kt` dos Blocos 1 e 2 era idêntico ao de `_backup_etapa3/RemoteBridge.kt`, que serve de base para o diff do Bloco 3.

**Implementação (RemoteBridge.kt)**
- Preparação de capa numa ÚNICA thread (`WinRemote-<tag>-art`), com no máximo 1 trabalho esperando: o mais novo substitui o anterior e libera a cópia do bitmap (`ArtJob.release()`, idempotente). Trabalho em andamento obsoleto (faixa mudou, faixa sem capa, detach) para nos pontos de controle (antes, durante e depois da codificação do JPEG). Faixa sem capa cancela o trabalho que esperava.
- `Out.postArt` (atômico, sob o monitor da fila do cliente): remove capas antigas ainda NÃO iniciadas (bloco 0 ainda na fila); não duplica capa cujo id já está na fila; se capa + estado não couberem em `maxQueue`, NÃO envia a capa e manda só o estado com `artId` vazio, sem desconectar. `artReady` guarda a capa que o cliente tem (ou terá) inteira; `adjusted()` troca por `artId` vazio qualquer estado que cite outra capa. A capa que já começou a ser enviada termina.
- Cliente cuja fila está realmente cheia (sem espaço nem para o estado) continua sendo desconectado, como antes.
- Diagnóstico para testes: `maxQueue` no construtor (`MAX_QUEUE` agora público), `artEncodeDelayMs` (só testes), `artJobsSubmitted/Encoded/Discarded`, `artChunksDropped`, `artSkippedCount`, `artLiveSnapshots`, `artPendingJobs`, `outCount`.

**Testes novos (`RemoteBridgeTest.selfTest`, botão do painel)** — aparelhos de teste E, F e G (`BridgeTestDevE05/F06/G07`, incluídos na limpeza); bridges 5 (fila normal), 6 (`maxQueue = 2`) e 7 (servidor com buffer de envio de 8 KB e prazo de escrita de 120 s; cliente com buffer de recepção de 4 KB que deixa de ler).
1. Servidores de teste das capas ligam (portas aleatórias, 48655 não é usada).
2. Pareamento dos aparelhos E, F e G (caminho completo; depois cada teste entra com `auth` e conexão nova).
3. Troca rápida de faixas (5 faixas, codificação artificial de 400 ms): recebidos = 5, codificados < recebidos, descartados >= 1, no máximo 1 thread de capa, cópias vivas e trabalho esperando voltam a 0, a capa final chega inteira (conferida pelo `ArtAssembler`) e nenhum estado cita `artId` de capa que não chegou.
4. Faixa sem capa cancela o trabalho que esperava: 0 codificações novas, nenhum bloco de capa nem `artId` depois do estado sem capa, cópias vivas 0.
5. Capa que não cabe (fila de 2): `artSkippedCount` sobe, o cliente recebe só estados com `artId` vazio (inclusive um segundo estado da mesma faixa), nenhum bloco de capa, Ping/Pong ok, continua conectado.
6. Cliente lento + 16 faixas (as duas últimas com o mesmo bitmap): o cliente não é desconectado enquanto não lê, depois recebe a capa final inteira, nenhum estado cita capa que não chegou. (Com o código antigo, 16 capas de vários blocos estourariam a fila de 64 e derrubariam o cliente.)
7. INFORMATIVO (não essencial): confere se o cliente lento deixou de receber capas antigas (`artChunksDropped > 0` ou menos capas completas que faixas). Falha com explicação se os buffers do sistema não travaram o envio (o teste 6 então não exercitou a remoção).
8. `detach()` com trabalho de 3 s em andamento: cópias vivas 0, nenhuma thread `-art`, filas vazias, servidores 5, 6 e 7 desligados (`liveThreads() == 0`).
Alterações em código de teste existente (só estas): `TEST_IDS` ganhou E, F, G; `connect()`/`open()` ganharam o parâmetro opcional `rcvBuf` (padrão 0 = comportamento antigo); os laços do `finally` incluem os bridges/servidores 5–7. Nenhuma verificação existente foi removida ou alterada: o autoteste da integração tinha 20 verificações e agora tem 28 (27 essenciais + 1 informativa).

**O QUE FOI E O QUE NÃO FOI VERIFICADO (honestidade)**
- NESTA sessão não havia `kotlinc` nem rede (o `bash` está sem acesso): NADA foi compilado e NENHUM teste foi executado. Não há resultado de teste do Bloco 3.
- Feito apenas por leitura: chaves de `RemoteBridge.kt` balanceadas; nomes e tipos usados nos testes conferidos contra `RemoteBridge`, `RemoteProtocol` (`ArtChunk`, `ArtAssembler`, `artIdOf`, `sha256Hex`), `RemoteServer` (`writeMs`, `sndBufBytes`, `liveThreads`, `boundPort`) e os auxiliares do próprio teste; diff mostrando que só 6 linhas de teste antigas mudaram (assinaturas/listas).
- A frase da sessão anterior "COMPILA no harness JVM" (`RemoteBridge.kt`) é um registro dela e NÃO foi reverificada. Os números "servidor 44/44" e "integração 20/20" são do fim do Bloco 2, ANTES do código do Bloco 3 e dos testes novos: não valem para este ZIP.
- Os testes novos NUNCA foram compilados. Podem ter erro de compilação ou de lógica de teste; se falharem, suspeitar primeiro do teste, depois do código.

**Pontos de atenção dos testes novos (dependem de tempo/SO)**
- Teste 3 e 4 dependem de `artEncodeDelayMs` (400/700 ms) ser maior que o tempo de postar 5 faixas na thread principal; em aparelho muito lento pode falhar sem haver defeito.
- Teste 5 exige que o JPEG de teste tenha pelo menos 2 blocos de 9000 bytes (a capa tem 900 retângulos coloridos; deve ter vários).
- Teste 6/7 dependem de o envio travar (SO_SNDBUF 8 KB, SO_RCVBUF 4 KB); o Android pode ajustar esses valores. O 7 é informativo por isso.
- O autoteste da integração fica ~15–25 s mais longo.

**NÃO coberto por teste**: não duplicação de capa já na fila (só registrada no texto do teste 6, sem verificação); falha ao copiar o bitmap (reciclado, `HARDWARE`); `RejectedExecutionException` ao reenviar trabalho depois do detach; desconexão de cliente cuja fila está cheia de outras mensagens (comportamento antigo mantido); estouro do estado no caminho "capa não coube".

**FALTA VALIDAR**
1. Harness JVM (`_harness_jvm_etapa2A/run.sh`, kotlinc 1.9.24 + JVM 17+; recriar `/home/claude/work/{tc,harness,proj}`): compilar e rodar. Esperado: servidor 44/44 e integração 28/28 (27 essenciais + 1 informativa). Anotar ✔/✘ de cada item, repetir várias vezes (instabilidade conhecida do "Limite por IP" sob CPU carregada).
2. GitHub Actions (`assembleDebug`): compilação real com Gradle/AGP/Kotlin 1.9.24 de TODO o projeto. Segundo este HANDOFF, os arquivos de rede da 3B e da Etapa 3 (RemoteServer, RemoteServerService, RemoteLifecycleGate, RemoteBridge, RemoteBridgeTest) nunca foram compilados com Gradle. Conferir APK 2.5.1 (versionCode 9) e que sobe por cima da 2.5.0.
3. Android real: autotestes do painel (servidor e integração, ✔/✘); religar/desligar rápido pelo painel e pela notificação; Remote conectado trocando faixas rápido (YouTube Music) com Wi-Fi ruim; verificar que a capa certa aparece e o Remote não é derrubado; Conscrypt/`close()` durante handshake; WifiLock; foreground service.
4. Teste manual Bloco 1/2 já listado nas seções anteriores.

**Onde continuar** (ver a seção de validação no harness JVM, ao fim deste arquivo): rodar o item 1 ou 2 acima, corrigir o que aparecer (código ou teste), atualizar este HANDOFF com os resultados reais e só então considerar o Bloco 3 concluído. NÃO iniciar Etapa 4 ou 5 sem autorização do dono.


### Etapa 3 — Validação no harness JVM e correção de 1 linha de TESTE (2026-11-04)
ZIP: `WinLauncher_2_5_1_etapa3_harness_validado.zip`. Partiu do ZIP original 2.5.1 (SHA-256 64385fe37e820ed92e39c5e1932d4635474fc0b8506924772cde2c9bf9e0f854), preservado sem alterações.

**Único arquivo de código alterado: `RemoteBridgeTest.kt` (linha 483, `artThreadNames()`).** Nenhum código de produção foi tocado (`RemoteBridge.kt`, `RemoteServer.kt`, `RemoteServerService.kt` etc. idênticos ao original). Versão continua 9 / 2.5.1. Backups do original em `_backup_etapa3_fix_teste/` (`RemoteBridgeTest.kt` e `HANDOFF_WINLAUNCHER.md`).
- Antes: `testThreads().filter { it.endsWith("-art") }`
- Depois: `testThreads().filter { it.endsWith("-art") && (it.contains("btest5") || it.contains("btest6") || it.contains("btest7")) }`
- Motivo: o teste "Capas: detach() com trabalho em andamento…" desliga só os bridges 5–7, mas o filtro antigo também via a thread `WinRemote-btest1-art` do bridge 1 (desligado só no teste "Desligamento", depois). Era defeito do teste, não do app.

**Resultados reais (kotlinc 1.9.24, JDK 21, harness JVM com stubs de Android e RemoteAuth falso, TLS real em 127.0.0.1)**
- Compilação de RemoteProtocol, RemoteLifecycleGate, RemoteServer, RemoteBridge e RemoteBridgeTest: sem erros.
- ANTES da correção (código do ZIP original): integração 27/28 em 4 de 4 execuções (falha única: o item acima). Servidor 44/44 em 6 de 6 execuções (3 sequenciais + 3 simultâneas com CPU carregada).
- DEPOIS da correção: integração 28/28 (27 essenciais + 1 informativa), 0 falhas essenciais, em 3 de 3 execuções (15 s cada). Servidor 44/44, 0 falhas essenciais, em 2 de 2 execuções (50 s cada). O item de detach passou: "cópias vivas 0, nenhuma thread de capa, filas vazias, servidores 5, 6 e 7 desligados".
- Ajuste só do harness (fora do app): `ks.p12` gerado com keytool (EC P-256, alias k, senha changeit) e caminho em `harness/kt/RemoteAuth.kt` apontado para a cópia de testes; o harness dentro do ZIP NÃO foi modificado (ainda aponta para /home/claude/work/harness/ks.p12, que não existe no ZIP: gerar o keystore ao recriar o harness).

**Continua NÃO validado**: build com Gradle/AGP (GitHub Actions), RemoteAuth real/Android Keystore, Conscrypt, RemoteServerService (foreground service, notificação, WifiLock), painel, MediaSessionHub real, qualquer teste em aparelho. Os resultados acima substituem a observação anterior de que o Bloco 3 "nunca foi compilado nem executado" apenas na JVM; os itens de Gradle e Android acima seguem pendentes.

**Onde continuar**: build no GitHub Actions e autotestes no aparelho. Etapas 4A/4B NÃO iniciadas; aguardar planejamento do dono.


<!-- 4A-BEGIN -->
## Etapa 4A — WinLauncher Remote: INTERFACE (app independente) — EM ANDAMENTO

**Regra de continuidade:** esta seção é reescrita a cada checkpoint. O estado exato está na tabela abaixo. Nenhuma integração com servidor/protocolo v2 (isso é Etapa 4B, NÃO iniciada).

### Decisões aprovadas pelo dono
- Projeto Gradle INDEPENDENTE em `WinLauncherRemote/` (próprio `settings.gradle.kts`; NÃO é módulo do build da raiz, então um erro no Remote não quebra o launcher).
- `applicationId = com.winlauncher.remote`, versão 0.1.0 (code 1), só framework Android (Views por código, sem AndroidX/Compose, sem dependências externas), permissão só INTERNET.
- Assinatura: reutiliza `../../app/debug.keystore` SOMENTE LEITURA (conferido por SHA-256 que o arquivo não mudou).
- Workflow NOVO `.github/workflows/build-remote-debug.yml` (compila só `WinLauncherRemote/`, artefato `WinLauncherRemote-debug-apk`). O `build-debug.yml` do launcher NÃO foi modificado.
- Design: referência = imagem enviada pelo dono. Fundo cinza SÓLIDO (#38393B), nunca dinâmico; cartões/botões de vidro fosco desenhados por código (película translúcida, reflexo no topo, borda de luz, sombra suave, granulado), cantos grandes.

### Progresso por parte (checkpoints)
| Parte | Conteúdo | Estado |
|---|---|---|
| 1 | Estrutura independente + Gradle + workflow + manifesto mínimo | CONCLUÍDA (ZIP `WinLauncher_2_5_1_4A_parte1`) |
| 2 | Identidade (ícone), tema, componentes visuais (vidro, ícones, capas, slider) | ESCRITA + **VERIFICAÇÃO ESTÁTICA CONCLUÍDA (0 erros encontrados, 0 linhas de código alteradas)**. **NÃO COMPILADA** (sem kotlinc/Gradle/Android SDK neste ambiente) ⇒ **NÃO DECLARADA VALIDADA**. ZIP `WinLauncher_2_5_1_4A_parte2_verificacao` |
| 3 | Tela inicial + player (dados demo, repositório) | pendente — NÃO iniciada; aguardar autorização do dono |
| 4 | Biblioteca, fila, explorar, configurações | pendente |
| 5 | Verificações, compilação (Actions), entrega final | pendente |

### Arquivos criados (Parte 1)
`WinLauncherRemote/settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `res/values/strings.xml`, `res/values/themes.xml`, `java/com/winlauncher/remote/MainActivity.kt` (PROVISÓRIA: só um texto), `.github/workflows/build-remote-debug.yml`.
Arquivos existentes modificados: nenhum além deste HANDOFF (e, antes da 4A, `RemoteBridgeTest.kt` linha 483, correção aprovada).

### Arquivos criados (Parte 2)
Em `WinLauncherRemote/app/src/main/`: `AndroidManifest.xml` (agora com ícone), `res/values/themes.xml` (+ cor do ícone), `res/mipmap-anydpi-v26/ic_launcher.xml` e `ic_launcher_round.xml`, `res/drawable/ic_launcher_foreground.xml`, `ic_logo.xml` e 18 ícones vetoriais (corrigido de "17": a lista tem 18 e há 18 arquivos) (`ic_home, ic_search, ic_settings, ic_music, ic_queue, ic_equalizer, ic_play, ic_pause, ic_next, ic_prev, ic_shuffle, ic_repeat, ic_repeat_one, ic_volume, ic_more, ic_chevron, ic_back, ic_player`, ícones Material, Apache 2.0).
Kotlin (`java/com/winlauncher/remote/`): `Ui.kt` (cores, dp, textos, aviso "disponível na próxima etapa"), `GlassDrawable.kt` (vidro fosco: sombra em anéis, película, reflexo, sombreamento, granulado, borda de luz; intensidade global `Glass.strength`), `CoverArt.kt` (6 capas demo geradas por código + `RoundedCoverDrawable`), `GlassSlider.kt`, `Components.kt` (cartão de vidro, botões, pílulas, cabeçalho de seção, linha de faixa, item de capa), `Models.kt`, `MainActivity.kt` (PROVISÓRIA: galeria dos componentes).

### Verificação da Parte 2 (sessão de verificação) — o que foi e o que NÃO foi feito

**Preservação:** o ZIP recebido (`WinLauncher_2_5_1_4A_parte2.zip`, SHA-256 `ac464efd39a51d87d9c6f5557e7b5ba47998c2d4e0e02f6e574b92e668029f39`) ficou intacto em `/mnt/user-data/uploads`; trabalho feito em cópia. O HANDOFF enviado era byte a byte igual ao `HANDOFF_WINLAUNCHER.md` de dentro do ZIP. `app/debug.keystore` não foi tocado (SHA-256 `4937c4ef9ba9a3eccc73c2959aefdbfb3a86d0574c36d2968ad0f523aa109a4c`, igual ao original). Nenhum arquivo do launcher, RemoteBridge/RemoteServer/RemoteProtocol/RemoteAuth, nem `build-debug.yml` foi alterado (conferido por comparação do ZIP novo com o recebido).

**TESTES EXECUTADOS (todos estáticos, sem compilador):**
1. Leitura integral, linha a linha, dos 7 arquivos Kotlin (`Ui.kt`, `Models.kt`, `GlassDrawable.kt`, `GlassSlider.kt`, `CoverArt.kt`, `Components.kt`, `MainActivity.kt`), de `settings/build/app build.gradle.kts`, `gradle.properties`, manifesto, `values/*.xml`, 2 `adaptive-icon` e 20 vetores. Revisão manual de tipos, sobrecargas (Int×Float), smart casts, `when` como instrução, lambdas finais, ordem `background`→`setPadding`, construtores de `LinearGradient`/`RadialGradient`/`RectF`/`FrameLayout.LayoutParams`, conversão de `LayoutParams` em `addView`, `Drawable` (`getPadding`, `isStateful`, `getOpacity`), propriedades sintéticas (`isEmpty`, `isClickable`…), colisões de nomes (`px`/`pxf` em `Context` e `View`, `private var value` × `setValue`). Nada incorreto encontrado.
2. `_verificacao_4A_parte2/check_recursos.py` (saída em `saida_check_recursos.txt`): 25 XMLs bem formados; 20 vetores com `width/height/viewportWidth/viewportHeight`; `pathData` sem caracteres inválidos, começando com M e com nº de argumentos coerente por comando; as 10 referências `R.drawable.*` do Kotlin existem; todas as referências `@drawable/@mipmap/@color/@string/@style` dos XMLs resolvem. RESULTADO OK. (Um falso positivo inicial do PRÓPRIO script — regex cortava `Theme.WinLauncherRemote` no ponto — foi corrigido no script; o projeto não tinha erro ali.)
3. `_verificacao_4A_parte2/check_kotlin.py` (saída em `saida_check_kotlin.txt`): Pygments `KotlinLexer` sem tokens de erro; parênteses/colchetes/chaves balanceados nos 7 arquivos; `package com.winlauncher.remote` em todos; sem CRLF/BOM; chamadas × assinaturas das funções de topo sem divergência. RESULTADO OK. **Limite:** a conferência de assinaturas é heurística (a regex de declaração trunca parâmetros com tipo-função, p.ex. `sectionHeader`, `iconButton`); essas chamadas foram conferidas à mão.
4. Conferência cruzada: todos os `Ui.*` usados existem; `GlassStyle.*`, `CoverArt.KINDS`/`get`, `Glass.noise/strength/version` existem; em todos os gradientes de `CoverArt` nº de cores = nº de posições e posições não decrescentes.
5. Gradle/workflow lidos: `app/build.gradle.kts` do Remote segue o mesmo padrão do launcher (AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7, JDK 17, compileSdk/targetSdk 34, minSdk 26); caminho `../../app/debug.keystore` aponta para a raiz do repositório; workflow do Remote espelha o do launcher e usa `build-root-directory: WinLauncherRemote`. Sem `gradlew` (igual ao launcher: o Gradle 8.7 vem da action).

**TESTES NÃO EXECUTADOS (continuam pendentes):**
- `kotlinc` / checagem parcial de compilação: NÃO executada. `kotlinc` não existe aqui e não há rede (pip, curl e DNS falham) para obtê-lo. A tentativa de achar qualquer compilador Kotlin no sistema não encontrou nenhum.
- Compilação com Gradle/AGP, `aapt2` (link de recursos), resolução real dos símbolos da API Android (não há `android.jar`; o que foi dito sobre a API vem de leitura/conhecimento, não de compilador), lint, geração de APK, execução do workflow `build-remote-debug.yml` no GitHub Actions, instalação e conferência visual no aparelho.

**Correções feitas:** nenhuma no código nem nos recursos do `WinLauncherRemote/`. Única correção: documentação (este HANDOFF: "17 ícones" → 18).

**Observações (não são erros):** ficam sem uso até a Parte 3 `fmt`, `invalidateTree`, `trackRow`, `coverItem`, `SquareImageView`, `Glass.set`, `Ui.DIM/GREEN/AMBER/RED`, `Models.kt` (Track, Playlist, PlayerState…) e os ícones `ic_back, ic_equalizer, ic_play, ic_player, ic_repeat_one, ic_search, ic_settings, ic_volume, ic_logo` — era esperado. `@Suppress("OVERRIDE_DEPRECATION")` em `getOpacity()` é só para silenciar aviso. A Parte 2 só será considerada VALIDADA depois de compilar (Actions) e conferir no aparelho.

### Arquivos/pastas novos neste checkpoint
`_backup_4A_parte2_antes_verificacao/HANDOFF_WINLAUNCHER.md` (HANDOFF exatamente como recebido) e `_verificacao_4A_parte2/` (scripts + saídas, fora de qualquer build). Backups anteriores (`_backup_etapa1A … _backup_etapa3_fix_teste`, `_harness_jvm_etapa2A`) mantidos sem alteração.

### O QUE FALTA (a partir daqui)
1. **Validar a Parte 2 de verdade:** rodar o workflow `build-remote-debug.yml` no GitHub Actions (ou kotlinc/Gradle em ambiente com SDK) e corrigir só o que o compilador apontar. Decisão do dono: fazer isso antes ou junto com a Parte 3.
2. Parte 3: `RemoteRepository` (interface) + `DemoRepository` (ticker 1 s, play/pause, próxima, anterior, aleatório, repetir, seek, volume, tocar faixa), `NowPlayingView` (player compacto e grande), `HomePage` (Recentes e Fila), `MainActivity` real (cabeçalho com indicador de conexão, abas Início/Biblioteca/Fila/Explorar, barra inferior Início/Player/Biblioteca, navegação e botão voltar). **NÃO iniciar sem autorização do dono.** A `MainActivity` provisória (galeria) continua como está.
3. Parte 4: Biblioteca, Fila, Explorar, Player em tela cheia, Configurações (intensidade do vidro funcional; o resto com aviso "próxima etapa").
4. Parte 5: checagem final, HANDOFF final, ZIP final, instruções para o GitHub Actions gerar o APK. O APK NÃO existe ainda.

### Limitações conhecidas
- Neste ambiente NÃO há Android SDK nem acesso a Google/Maven Central (proxy recusa) e nem ao `android.jar` no GitHub: o APK NÃO pode ser compilado aqui. O APK só sai do GitHub Actions (workflow novo). Nada da 4A foi compilado (nem com kotlinc nem com Gradle) até este checkpoint.
- Fidelidade visual não pode ser conferida em tela aqui; depende de instalar o APK.
<!-- 4A-END -->

## Mouse Flow — ETAPA 1 (SÓ PROTOCOLO) — código e autoteste escritos; NADA COMPILADO NEM EXECUTADO (launcher 2.5.2 / code 10; Remote 0.2.1 / code 3)

Decisão do dono: Opção A (ampliar o MESMO protocolo v1 e a MESMA conexão TLS, só com acréscimos). Escopo desta etapa: novos tipos de mensagem + codificação/decodificação + testes. NÃO há captura de mouse, NÃO há cursor virtual, o servidor NÃO anuncia a capacidade e NÃO envia nada de mouse.

### O que mudou (backups dos originais em `_backup_mouseflow_etapa1/` em cada projeto)
Launcher (`com.example.winlauncher`):
- `RemoteProtocol.kt`: ADITIVO. `Hello` ganhou `caps: List<String> = emptyList()` (campo opcional; vazio não vai no JSON). Tipos `mouse_sub` (cliente→servidor, `{on}`), `mouse_state` (servidor→cliente, `{active}`), `mouse` (servidor→cliente, `{seq,dx,dy,wx,wy,b}`). Bloco "Mouse Flow" com constantes/limites, `clampMouseDelta/Scroll`, `optCaps`, `reqWhole` e `selfTestMouse()`. `VERSION` continua 1. `Command` (música) intacto. Única linhas existentes alteradas: a declaração do `Hello` (3 linhas) e `role = ...` no decode (para acrescentar `caps`).
- `RemoteAuth.kt`: +1 check no diagnóstico existente ("Mouse Flow: protocolo...") que chama `RemoteProtocol.selfTestMouse()` (Configurações > Rede e Internet > Diagnóstico do Remote).
- `app/build.gradle.kts`: versionCode 9→10, versionName 2.5.1→2.5.2 (só para o APK atualizar por cima).
- NÃO mexidos: `RemoteServer.kt`, `RemoteBridge.kt`, `RemoteServerService.kt`, `MediaSessionHub.kt`, `MainActivity.kt`, TLS, pareamento, autenticação.
Remote (`com.winlauncher.remote`):
- `RemoteProtocol.kt`: as MESMAS mudanças (bloco "Mouse Flow" byte a byte igual).
- `RemoteClient.kt`: ADITIVO. `Listener.onMouse/onMouseState` com corpo padrão vazio (MainActivity, MediaControlService e RemoteHub compilam sem mudar); `serverSupportsMouse`; `setMouseSubscription(on)` (devolve false e NÃO envia nada se o servidor não anunciou "mouse"); campos `serverMouse`/`mouseWanted` na `Session`; ramos novos no `loop()` (quadros de mouse só são repassados se houve pedido). Única linha existente alterada: o `Hello` enviado agora leva `caps=["mouse"]` (servidores antigos ignoram o campo).
- `app/build.gradle.kts`: versionCode 2→3, versionName 0.2.0→0.2.1.

### Regras de compatibilidade (obrigatórias nas próximas etapas)
1. Quem recebe um tipo desconhecido encerra a conexão (decode lança; no Remote, sem reconexão automática). Por isso: o servidor só manda `mouse`/`mouse_state` a cliente que fez `mouse_sub`; o cliente só faz `mouse_sub` se o hello do servidor trouxe `caps` com "mouse".
2. Quadros de mouse NUNCA passam pela fila geral `Out.post` (64 mensagens; estourar derruba o cliente): usar um slot próprio que soma dx/dy/rolagem (Etapa 3).
3. Quem envia limita os valores; `toJson` também limita, para nunca gerar quadro que o outro lado recusaria.
4. O servidor (Etapa 3) ainda precisa de `setTcpNoDelay(true)` em `RemoteServer.handleAccepted` (hoje só o cliente liga).

### Verificação feita (ESTÁTICA + MODELO; ver `_verificacao_mouseflow_etapa1/`)
`check_mouseflow_etapa1.py` (saída em `saida_check_mouseflow_etapa1.txt`): só acréscimos (diff contra os backups), blocos idênticos nas duas cópias, `when` de `toJson` exaustivo sobre a sealed class e `decode` cobrindo todos os `Types`, balanceamento/lexer, e um MODELO em Python (não é o Kotlin) do decode antigo x novo e da matriz de versões. 49 checagens OK.
### NÃO verificado
Nada foi compilado (sem kotlinc/Gradle/Android SDK) e o `selfTestMouse` nunca rodou. Falta: (1) build no GitHub Actions dos dois projetos; (2) rodar o diagnóstico do Remote no aparelho (o novo item deve vir ✔); (3) Remote novo + launcher 2.5.1 antigo, e Remote 0.2.0 antigo + launcher novo: parear, conectar e usar play/pause/próxima/anterior.
### Próxima etapa (NÃO iniciada)
Etapa 3 do plano: servidor anuncia `caps`, aceita `mouse_sub`, slot de coalescência, `tcpNoDelay`, chave nas Preferências, gerador sintético. Só depois de aprovação.


## Fila real do YouTube Music (launcher 2.5.3 / code 11) — ESCRITO, NADA COMPILADO NEM TESTADO EM APARELHO

Problema: o Hub nunca lia `MediaController.getQueue()` e o protocolo não tinha mensagem de fila.
- `MediaSessionHub.kt` (só acréscimos): `QueueStatus` (OK/EMPTY/NOT_PUBLISHED/NO_SESSION/NO_ACCESS), `QueueEntry`, `Queue`, `NO_QUEUE`, `queue()`;
  lê `getQueue()`, `getQueueTitle()`, `activeQueueItemId` (fallback: único item com o mesmo `mediaId` da faixa atual; nunca por título);
  callbacks `onQueueChanged`/`onQueueTitleChanged`; releitura na troca de sessão e em `refresh()`; `Listener.onQueue` com corpo padrão vazio.
- `RemoteProtocol.kt` (só acréscimos): mensagem `queue`, capacidade `queue`, `SERVER_CAPS`, `queueOf` (janela de até 50 itens, 5 antes do atual, limite de bytes do quadro), `selfTestQueue`.
- `RemoteServer.kt`: guarda `Client.caps` e anuncia `SERVER_CAPS` no hello (3 linhas).
- `RemoteBridge.kt`: `MediaPort.queue()` (padrão), `onHubQueue`, envio só a cliente autenticado que anunciou "queue", coalescência, fila atual no `sendFull`.
- `RemoteAuth.kt`: +1 check; `RemoteBridgeTest.kt`: fila no `FakeMediaPort` e 3 testes de integração; `CustomizeUi.kt`: linha "Fila (MediaSession)" no diagnóstico do YouTube Music.
- Backups em `_backup_fila_remote/`. Instruções do Remote em `REMOTE_FILA_INSTRUCOES.md`.
Verificação feita: lexer/balanceamento e modelo Python do cálculo da janela (8000 casos, 0 falhas). NÃO compilado, NÃO executado.

## Integração da fila Launcher <-> Remote (launcher 2.5.4 / code 12; Remote 0.4.0 / code 5) — ESCRITO, NADA COMPILADO NEM EXECUTADO

**Causa raiz (confirmada comparando os dois `RemoteProtocol.kt`):** o launcher 2.5.3 já enviava a mensagem `queue` (fila real, janela de 50 itens)
e o Remote já a recebia, mas o Remote tinha um protocolo de seleção que o launcher NÃO conhecia: o comando `play_queue_item` com o campo
`queueId`. No launcher `Command` só tinha play_pause/next/previous e `CommandMsg` não tinha `queueId`; um `play_queue_item` seria recusado
como "comando desconhecido" (bad_request). Além disso, a linha da fila no Remote só reagia ao toque no item atual.

**Launcher (acréscimos; nada removido):**
- `RemoteProtocol.kt`: `Command.PLAY_QUEUE_ITEM("play_queue_item")`; `CommandMsg(id, command, queueId: Long? = null)`; `decodeCommand` (exige `queueId` no
  play_queue_item, ignora nos outros); capacidade `queue_select` (`CAP_QUEUE_SELECT`) em `SERVER_CAPS`; checks novos em `selfTestQueue` (ida e volta, rejeições, caps do hello).
- `MediaSessionHub.kt` (só uma função nova, `skipToQueueItem(queueId)`): só toca ids que estão na fila atual e exige `ACTION_SKIP_TO_QUEUE_ITEM`; senão UNAVAILABLE.
- `RemoteBridge.kt`: `MediaPort.playQueueItem` (padrão UNAVAILABLE), `HubPort.playQueueItem`, ramo no `handleCommand`.
- `RemoteBridgeTest.kt`: `FakeMediaPort.playQueueItem` e 1 teste de integração ("Fila: play_queue_item ...").
- `app/build.gradle.kts`: versionCode 12 / versionName 2.5.4.

**Remote (em `WinLauncherRemote_..._fila_integrada.zip`):** `RemoteProtocol` (+`CAP_QUEUE_SELECT`), `RemoteClient` (`serverSupportsQueueSelect`),
`RemoteHub.command(ctx, c, queueId)`, `QueueModel.tapAction` (decisão pura), `QueueUi` (toda linha é tocável), `MainActivity.onQueueTrack`
(item atual = play/pause; outro item = `play_queue_item` com o id real; sem `queue_select` no hello = aviso "atualize o WinLauncher", nada é enviado). versionCode 5 / 0.4.0.

**Sincronização:** o Remote não troca a fila localmente. Depois do toque, o app de música muda o item ativo e o Hub publica a nova fila/estado
(`onQueueChanged`/PlaybackState), que o bridge empurra aos clientes. Cliente Remote antigo (sem `queue_select`) continua funcionando como antes.

**Verificação feita (só estática):** lexer/balanceamento nos dois projetos (os 19 avisos de `$` em regex são os mesmos do ZIP original), comparação textual
das definições de fila/comando entre os dois `RemoteProtocol.kt` (iguais). **NÃO feito:** compilação (sem kotlinc/Android SDK), `selfTest`/`RemoteBridgeTest` no
aparelho, teste com o YouTube Music real. Backups dos originais em `_backup_fila_integracao/`.


## 2.5.5 (versionCode 13) — capas individuais da fila (queue_art / art_req / qart)
NÃO COMPILADO nem executado aqui (sem kotlinc/Android SDK): compilar pelo GitHub Actions e testar no aparelho com o WinLauncher Remote 0.4.1.
Contrato completo: `CAPAS_FILA_041.md` do projeto do Remote. Originais dos arquivos alterados: `_backup_capas_queue_art/`.

Arquivo CRIADO: `QueueArtStore.kt` (+ classe `QueueArtSource`): prepara as capas FORA da thread principal (1 thread "WinRemote-<tag>-qart"),
decodifica iconBitmap ou iconUri (content/file/http(s), 4 s, 8 MB), reduz para 256 px, JPEG (qualidade 85 com quedas até caber em 192 KB),
id = 16 primeiros hex do SHA-256 do JPEG. Cache LRU (96 capas / 6 MB); origem que falha só é tentada de novo após 60 s.
Arquivos MODIFICADOS (só acréscimos, exceto a assinatura de `queueOf`, que ganhou um parâmetro com padrão):
- `RemoteProtocol.kt`: tipos `qart` e `art_req`, `CAP_QUEUE_ART` (agora em `SERVER_CAPS`), `MAX_ART_REQ`, `QueueRow.artId` (padrão ""), campo opcional "art" nos itens da fila (inválido = ignorado), `QueueArtChunk`, `ArtReq`, `queueArtChunks`, `ArtAssembler.add(QueueArtChunk)`, `queueOf(q, artOf)` e `selfTestQueueArt()`.
- `MediaSessionHub.kt`: guarda os itens crus da fila (só ±100 em volta do ativo se a fila passa de 300) e expõe `queueArtSource(queueId)` (iconBitmap; senão iconUri; nunca captura de tela nem ícone de app). Nada do resto mudou.
- `RemoteBridge.kt`: `MediaPort.queueArtSource` (padrão null), `artStore`, montagem da fila com ids de capa, reenvio quando uma capa fica pronta, `handleArtReq` (só autenticado e com "queue_art"; 20 pedidos/s por cliente), `Out.postQueueArt` (capa inteira ou nada; nunca derruba o cliente).
- `RemoteServer.kt`: `art_req` do cliente agora é encaminhado ao bridge (antes seria "tipo não aceito").
- `RemoteAuth.kt`: nova linha no diagnóstico do Remote ("Capas da fila: protocolo").
- `app/build.gradle.kts`: 2.5.4/12 -> 2.5.5/13.
Compatibilidade: cliente sem "queue_art" (Remote 0.4.0 ou anterior) nunca recebe o campo "art" nem "qart"; só reenvio da fila se o retrato sem capas mudou.
Não alterados: comandos, pareamento, estado e capa do player ("art"), TaskbarMusic/QuickMusicCard/MusicWidget, MediaSessionHub (leitura de sessão, estado, comandos).

## 2.5.6 (versionCode 14) — tocar item da fila em apps que não anunciam ACTION_SKIP_TO_QUEUE_ITEM
`MediaSessionHub.skipToQueueItem`: se o app não anuncia a ação, em vez de UNAVAILABLE usa `stepToQueueItem` (skipToNext/skipToPrevious pela diferença entre o item ativo e o escolhido, até 20 passos, só se a posição é conhecida e o app anuncia próxima/anterior). NÃO compilado nem testado. Original: `_backup_capas_queue_art/MediaSessionHub_antes_2_5_6.kt`.
Limite: se o app tiver embaralhar ligado, a ordem da fila pode não ser a de reprodução.

## 2.5.7 (versionCode 15) — 5 ajustes do launcher (NÃO COMPILADO; só conferência de parênteses/chaves)
1. Wallpaper (Configurações > Personalização > Wallpaper): botão direito numa miniatura salva abre menu "Remover" (só tira da lista; o arquivo não é apagado). Segurar o dedo continua removendo. (`CustomizeUi.wallpaperPanel`)
2. Gerenciador de arquivos: "Nova pasta" agora aparece direto no menu de botão direito do fundo (já existia em "Novo" e Ctrl+Shift+N). (`FileManagerWindow.showBgMenu`)
3. Configurações: botão minimizar na barra de título; `SettingsWindow.minimize()/restore()/toggleFromTaskbar()/isMinimized`; ícone da engrenagem na barra de tarefas restaura/minimiza; Alt+I e visão de tarefas ajustados.
4. Notificações do sino: `MainActivity.openNotification` envia o contentIntent com permissão de abrir atividade (API 34) e, se não houver/falhar, abre o app pelo pacote.
5. Barra de pesquisa: botão direito → "Mostrar apenas a lupa" / "Mostrar barra de pesquisa". Pref `ui_tb_search_icon` (`Prefs.tbSearchIcon`), vale também para a barra sobre outros apps (`TaskbarOverlayService`). Só a lupa esconde o clima.
