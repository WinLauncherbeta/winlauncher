# HANDOFF 15 — Mapeador de gamepad, ETAPA 4 (ESCRITA NO CÓDIGO): perfil automático, botão flutuante, importar/exportar, polimento (WinLauncher 2.10.0 / code 23)

NÃO compilado com Gradle, NÃO testado em aparelho e NÃO executado na JVM. Neste ambiente não havia kotlinc nem android.jar: a única checagem feita foi
léxica (Pygments: 0 tokens de erro e delimitadores balanceados em PadModel, PadEngine, PadStore, PadPanel, PadMapperService, PadFloatingButton, PadFiles,
MainActivity). As 77 verificações da Etapa 3 NÃO foram reexecutadas, e a lógica nova (exportar/importar/mesclar) não tem teste. As etapas 1, 2 e 3 também
seguem sem teste no aparelho. Quem compila é o GitHub Actions: se acusar erro, mandar o log.

## O que mudou
1. Perfil automático ao abrir o jogo
   - A troca por pacote já existia desde a Etapa 1 (`PadEngine.onForeground`). Agora ela é visível e robusta:
   - `PadEngine.candidateProfile()` = perfil do app da frente, mesmo com a chave geral desligada. `activeProfile()` = candidato só se a chave estiver ligada (comportamento igual ao anterior).
   - Aviso ao ativar: MiniToast "Gamepad: perfil de X ativo (N botões)" (opção "Avisar quando o perfil do jogo ficar ativo", ligada por padrão). Feito em `PadMapperService.syncOverlay()`, ligado ao motor por `PadEngine.addListener`.
   - Rotação: `PadMapperService.onConfigurationChanged` -> `PadEngine.onScreenChanged()` solta os dedos, reavalia paisagem/retrato e reposiciona o botão.
   - Painel: linha "Último app visto: pacote - perfil ..." para conferir se o jogo foi reconhecido.
2. Botão flutuante liga/desliga (`PadFloatingButton.kt`)
   - Janela TYPE_ACCESSIBILITY_OVERLAY (sem permissão extra). Só aparece enquanto o jogo da frente tem perfil e o editor está fechado; continua visível com o mapeamento desligado (para poder religar).
   - Toque = liga/desliga (`PadEngine.setMaster` + `PadStore.setMaster`); arrastar = mover (posição guardada por orientação em `PadPrefs`). Opção "Botão flutuante..." no painel (ligada por padrão).
   - Ignora toque enquanto há dedo injetado (`planner.hasWork()`), para um toque mapeado que caia sobre ele não desligar o mapeamento por engano. Mesmo assim, esse toque NÃO chega ao jogo: o usuário deve deixar o botão longe dos pontos.
3. Importar/exportar (`PadFiles.kt`, `PadJson.export/parseImport/merge`)
   - Exportar: seletor de arquivos (CREATE_DOCUMENT) grava `winlauncher_gamepad_perfis.json` com todos os perfis (sem a chave geral).
   - Importar: OPEN_DOCUMENT, limite de 2 MB, aceita também o `pad_profiles.json` interno. Dois botões: "manter os que já tenho" e "substituir os do mesmo jogo". Um perfil por jogo (pacote); o substituto herda o id do antigo; id repetido de outro jogo ganha id novo. Resumo em toast.
   - `MainActivity.onActivityResult` repassa para `PadFiles.onResult` (códigos 24 e 25; sem conflito com os existentes).
4. Polimento: linha do perfil mostra paisagem/retrato; chave geral passou a avisar os ouvintes (`PadEngine.setMaster`).
5. `app/build.gradle.kts`: versionName 2.10.0, versionCode 23. Backups dos arquivos alterados em `_backup_etapa4/`.

## Arquivos
Novos: PadFloatingButton.kt, PadFiles.kt. Alterados: PadModel.kt (PadJson: APP_TAG, export, ImportResult, parseImport, MergeResult, merge), PadEngine.kt (candidateProfile, setMaster, onScreenChanged), PadStore.kt (exportText, importText, PadPrefs), PadMapperService.kt (syncOverlay, onConfigurationChanged, refreshOverlay), PadPanel.kt, MainActivity.kt (1 linha), app/build.gradle.kts. Formato JSON dos perfis inalterado (v3); o arquivo exportado só ganha o campo "app".

## Para conferir no build
1. `override fun onConfigurationChanged(newConfig: Configuration)` em PadMapperService (AccessibilityService herda de Service).
2. `if (r.error != null) return r.error` em PadStore.importText (smart cast de val da mesma classe) e o try/catch com `return` nos dois ramos em PadJson.parseImport.
3. PadFloatingButton: uso de `svc.screenWidth()/screenHeight()` (públicos em PadMapperService).

## Para testar no aparelho
1. Abrir um jogo com perfil: aparece o aviso e o botão PAD ON; sair para o launcher: o botão some.
2. Tocar no botão: vira PAD OFF e os botões do controle passam direto ao jogo; tocar de novo religa.
3. Arrastar o botão, girar a tela e conferir que a posição é lembrada por orientação e que o perfil de paisagem só vale em paisagem.
4. Abrir o editor sobre o jogo: o botão some; ao fechar, volta.
5. Exportar, apagar um perfil, importar (manter e substituir) e conferir o resumo; importar um arquivo qualquer (.txt, outro JSON) deve só mostrar erro, sem apagar nada.
6. Desligar o serviço de acessibilidade com o botão na tela: ele deve sumir.

## Limites conhecidos
- O jogo da frente só é reconhecido na próxima troca de janela (sem `canRetrieveWindowContent`, de propósito, para não pedir permissão de ler a tela). Se o jogo já estava aberto ao ligar o serviço, sair e voltar.
- Um perfil por jogo: não há perfis separados de paisagem e retrato para o mesmo pacote.
- Pressão real do gatilho continua impossível pelo serviço de acessibilidade ("Gradual" é a alternativa).
- Mapeamento de eixos no Android 13- (getevent via Shizuku) continua heurístico (`GetEventParser.layoutFor`).

## Gamepad: fim do plano de 4 etapas no código; falta validar no aparelho (etapas 1 a 4).
