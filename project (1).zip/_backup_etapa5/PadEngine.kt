package com.example.winlauncher

/**
 * Mapeador de gamepad (Etapa 1) - motor. Recebe os eventos de tecla do controle (vindos do [PadMapperService]),
 * decide se algum perfil os trata e entrega ao [TouchPlanner]. Também mantém o "monitor ao vivo" mostrado no painel.
 *
 * Sem dependência de Android (testado numa JVM). TUDO roda na thread principal: o serviço de acessibilidade, os
 * callbacks de gesto e a interface chamam daqui, então não há travas.
 */

/** Ponte com o Android, implementada pelo serviço. */
interface PadHost {
    /** Tamanho REAL da tela em pixels, na rotação atual. */
    fun screenWidth(): Int
    fun screenHeight(): Int

    /** Avisa que há dedos novos para despachar (o serviço chama [TouchPlanner.nextChunk] e injeta). */
    fun pump()

    /**
     * Etapa 3: liga/desliga a escuta dos eixos do controle. No Android 14+ os eixos escutados NÃO chegam mais ao
     * resto do sistema, por isso o motor só liga quando o perfil da frente precisa deles (ou o painel está medindo).
     */
    fun setAxesWanted(on: Boolean)
}

/** Evento de tecla já "traduzido" pelo serviço (sem tipos do Android). */
class PadKey(
    val code: Int,
    val down: Boolean,
    val repeat: Int,
    val deviceName: String,
    /** true se veio de um controle (fonte gamepad/joystick ou código BUTTON_*). */
    val fromPad: Boolean,
    val now: Long,
    /** true = tecla fabricada a partir de um eixo (D-pad/gatilho analógico), não um KeyEvent de verdade. */
    val synthetic: Boolean = false
)

/** Etapa 3: um instante dos eixos do controle. Analógicos -1..1 (Y positivo = para baixo), gatilhos 0..1, hat -1..1. */
class PadAxes(
    val lx: Float,
    val ly: Float,
    val rx: Float,
    val ry: Float,
    val lt: Float,
    val rt: Float,
    val hx: Float,
    val hy: Float,
    val deviceName: String,
    val now: Long
)

object PadEngine {

    val planner = TouchPlanner()

    @Volatile
    var host: PadHost? = null

    /** Chave geral "Mapeamento ligado". */
    @Volatile
    var masterOn = true

    /** Pacote do app que está na frente (última janela de outro app vista pelo serviço). */
    @Volatile
    var foregroundPkg = ""

    /** true enquanto o próprio launcher está na frente: nesse caso o mapeamento fica parado. */
    @Volatile
    var launcherFront = false

    /** Perfis atuais (a mesma lista que o [PadStore] edita). */
    @Volatile
    var profiles: List<PadProfile> = emptyList()

    // ---- estado do mapeamento
    /** Teclas cujo DOWN foi tratado por nós: o UP e os repeats delas também são consumidos. */
    private val consumed = HashSet<Int>()

    // ---- monitor ao vivo (painel)
    private val pressed = LinkedHashSet<Int>()
    private val log = ArrayList<String>()
    var lastDevice = ""
        private set
    var eventCount = 0
        private set
    var mappedCount = 0
        private set

    /** Último botão apertado (o editor usa para selecionar a linha do botão). */
    var lastButton: PadButton? = null
        private set

    /**
     * Etapa 2: true enquanto o editor sobre o jogo está aberto (fora do modo de teste). Os botões do controle
     * NÃO viram toque: só selecionam o botão no editor, e são consumidos para o jogo de baixo não reagir.
     */
    @Volatile
    var editing = false
        private set

    /** Quem recebe o botão apertado durante a edição (o editor sobre o jogo). */
    var editHook: ((PadButton) -> Unit)? = null

    /** Sobe a cada gravação feita pelo editor sobre o jogo (o painel relê o perfil quando muda). */
    var editVersion = 0
        private set

    // ---- Etapa 3: eixos
    /** false abaixo do Android 14 (o serviço ajusta): lá o Android não entrega os eixos ao serviço. */
    @Volatile
    var axesSupported = true

    /** true enquanto o painel mostra o monitor de eixos (liga a escuta só para medir). */
    var diagWanted = false
        private set

    /** Últimos eixos recebidos e quantos eventos de eixo já chegaram (monitor do painel). */
    var lastAxes: PadAxes? = null
        private set
    var axisEvents = 0
        private set

    private var axesOn = false
    private var lastAxisNotify = 0L

    /** Analógicos com dedo na tela (id = código negativo do botão). */
    private val stickActive = HashSet<Int>()

    /** Teclas fabricadas por eixo que estão apertadas agora. */
    private val synth = HashSet<Int>()

    /** Botões "Gradual" (L2/R2) cuja tecla digital está comandando o dedo (o controle não manda o eixo). */
    private val slideKey = HashSet<Int>()

    /** Teclas "Gradual" consumidas (o UP delas não solta o dedo do eixo). */
    private val slideConsumed = HashSet<Int>()

    /** Quem entrega os eixos agora (mostrado no painel). */
    var axesSource: String? = null
        private set

    private val listeners = ArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun changed() {
        for (l in ArrayList(listeners)) {
            try {
                l()
            } catch (e: Exception) {
            }
        }
        refreshAxes()
    }

    /** O botão [b] está apertado agora? (o editor usa para acender o ponto no modo de teste) */
    fun isPressed(b: PadButton): Boolean = pressed.contains(b.key)

    /** Liga/desliga o modo de edição. Ao ligar, solta tudo o que estiver sendo segurado. */
    fun setEditing(on: Boolean) {
        if (editing == on) return
        editing = on
        if (on) releaseAll()
        changed()
    }

    /** O editor sobre o jogo gravou ou descartou mudanças no perfil. */
    fun notifyProfileEdited() {
        editVersion++
        changed()
    }

    /** Botões apertados agora (nomes amigáveis, na ordem em que foram apertados). */
    fun pressedLabels(): List<String> = pressed.map { codeLabel(it) }

    /** Últimas linhas do registro, da mais nova para a mais velha. */
    fun recentLog(): List<String> = log.reversed()

    fun codeLabel(code: Int): String = PadButton.fromKey(code)?.label ?: ("tecla " + code)

    private fun addLog(s: String) {
        log.add(s)
        while (log.size > 12) log.removeAt(0)
    }

    // ---- perfis

    /**
     * Etapa 4: o perfil do app que está na frente, MESMO com a chave geral desligada (ou null: launcher na frente, app sem
     * perfil, perfil desativado, orientação diferente). O botão flutuante e o aviso de "perfil ativo" usam este: o botão
     * precisa continuar na tela com o mapeamento desligado, senão não haveria como religar.
     */
    fun candidateProfile(): PadProfile? {
        if (launcherFront) return null
        val pkg = foregroundPkg
        if (pkg.isEmpty()) return null
        val prof = profiles.firstOrNull { it.enabled && it.pkg == pkg } ?: return null
        val h = host ?: return null
        val w = h.screenWidth()
        val hh = h.screenHeight()
        if (w <= 0 || hh <= 0) return null
        // perfil de paisagem só vale com a tela em paisagem (e vice-versa): os pontos seriam outros
        if ((w > hh) != prof.landscape) return null
        return prof
    }

    /** Perfil que vale agora, ou null (chave geral desligada, launcher na frente, app sem perfil...). */
    fun activeProfile(): PadProfile? {
        if (!masterOn) return null
        return candidateProfile()
    }

    /** Liga/desliga o mapeamento todo (chave geral). Ao desligar, solta tudo. Avisa quem está ouvindo (botão flutuante, painel). */
    fun setMaster(on: Boolean) {
        masterOn = on
        if (!on) releaseAll()
        changed()
    }

    /** A tela girou (ou mudou de tamanho): o perfil de paisagem/retrato pode ter trocado. Solta os dedos e reavalia. */
    fun onScreenChanged() {
        releaseAll()
        changed()
    }

    // ---- entradas

    /**
     * Evento de tecla. Devolve true se o evento foi CONSUMIDO (o app em primeiro plano não deve recebê-lo).
     * Só consome botões que o perfil ativo mapeia (e o UP/repeat deles); o resto passa.
     */
    fun onKey(k: PadKey): Boolean {
        if (!k.fromPad) return false
        // tecla de verdade chegou: ela vira a dona (o eixo equivalente não solta o botão por engano)
        if (!k.synthetic && k.down) synth.remove(k.code)
        // monitor: sempre, mesmo sem perfil e com o launcher na frente
        if (k.repeat == 0) {
            eventCount++
            lastDevice = k.deviceName
            if (k.down) pressed.add(k.code) else pressed.remove(k.code)
            PadButton.fromKey(k.code)?.let { if (k.down) lastButton = it }
            addLog(codeLabel(k.code) + (if (k.down) " apertado" else " solto") +
                (if (k.deviceName.isNotEmpty()) "  (" + k.deviceName + ")" else ""))
            changed()
        }

        // editor sobre o jogo aberto: o botão só seleciona o ponto no editor e não chega ao jogo
        if (editing) {
            if (k.down && k.repeat == 0) {
                PadButton.fromKey(k.code)?.let { b ->
                    try {
                        editHook?.invoke(b)
                    } catch (e: Exception) {
                    }
                }
            }
            return true
        }

        val h = host
        if (!k.down) {
            // soltou: se o DOWN foi nosso, o UP também é
            if (consumed.remove(k.code)) {
                if (slideConsumed.remove(k.code)) {
                    // gradual: só a tecla digital solta o dedo; se o eixo comanda, ele é quem solta
                    if (slideKey.remove(k.code)) {
                        val pb = PadButton.fromKey(k.code)
                        if (pb != null && stickActive.remove(pb.key)) planner.release(pb.key)
                        h?.pump()
                    }
                    return true
                }
                planner.release(k.code)
                h?.pump()
                return true
            }
            return false
        }
        if (k.repeat > 0) return consumed.contains(k.code)

        val btn = PadButton.fromKey(k.code) ?: return false
        val prof = activeProfile() ?: return false
        val b = prof.bindingFor(btn) ?: return false
        if (b.mode == BindMode.OFF) return false
        val w = h?.screenWidth() ?: return false
        val hh = h.screenHeight()
        val px = b.x * (w - 1)
        val py = b.y * (hh - 1)
        if (b.mode == BindMode.SLIDE) {
            // gatilho gradual: se o eixo já está dizendo quanto apertou, ele comanda; senão a tecla vale "tudo"
            val axisLevel = if (btn == PadButton.R2) freshAxes(k.now)?.rt ?: 0f else freshAxes(k.now)?.lt ?: 0f
            consumed.add(k.code)
            slideConsumed.add(k.code)
            if (axisLevel < 0.05f) {
                slideKey.add(k.code)
                slide(btn, 1f, prof, h, k.now)
            }
            mappedCount++
            changed()
            return true
        }
        if (b.mode == BindMode.MACRO) {
            val pts = ArrayList<TouchPlanner.MStep>()
            for (st in b.steps) {
                pts.add(TouchPlanner.MStep(st.x * (w - 1), st.y * (hh - 1), st.hold.toLong(), st.wait.toLong()))
            }
            if (pts.isEmpty()) pts.add(TouchPlanner.MStep(px, py, 60L, 0L))
            planner.pressMacro(k.code, pts, b.loop, k.now)
        } else if (b.mode == BindMode.TURBO) {
            planner.pressTurbo(k.code, px, py, 1000L / Math.max(2, Math.min(10, b.rate)), k.now)
        } else {
            planner.press(k.code, px, py, b.mode == BindMode.TAP, k.now)
        }
        // consome mesmo se o limite de dedos estourou: não deixa o jogo receber um botão que o perfil reivindicou
        consumed.add(k.code)
        mappedCount++
        h.pump()
        changed()
        return true
    }

    // ------------------------------------------------------------ Etapa 3: eixos

    /** O painel começou/parou de mostrar o monitor de eixos. */
    fun setDiag(on: Boolean) {
        if (diagWanted == on) return
        diagWanted = on
        refreshAxes()
    }

    /** O perfil da frente precisa dos eixos? (analógico mapeado, ou D-pad/gatilhos lidos como eixo) */
    private fun axesNeeded(): Boolean {
        if (!axesSupported) return false
        if (diagWanted) return true
        if (editing) return false
        val prof = activeProfile() ?: return false
        if (prof.axisKeys) return true
        return prof.bindings.any { it.mode == BindMode.JOYSTICK || it.mode == BindMode.CAMERA || it.mode == BindMode.SLIDE }
    }

    /** O serviço (re)avalia quem entrega os eixos: Android 14+ pela acessibilidade; abaixo disso, só com o Shizuku. */
    fun setAxesAvailability(supported: Boolean, source: String?) {
        axesSupported = supported
        axesSource = source
        refreshAxes()
    }

    /** Pede ao serviço para ligar/desligar a escuta dos eixos conforme a necessidade atual. */
    fun refreshAxes() {
        val need = axesNeeded()
        if (need == axesOn) return
        axesOn = need
        host?.setAxesWanted(need)
    }

    /**
     * Eixos do controle (vindos do serviço, só no Android 14+). Analógicos viram joystick/câmera, e, se o perfil
     * pediu, o D-pad (hat) e os gatilhos analógicos viram os botões correspondentes.
     */
    fun onAxes(a: PadAxes) {
        lastAxes = a
        axisEvents++
        lastDevice = a.deviceName
        if (a.now - lastAxisNotify >= 100L) {
            lastAxisNotify = a.now
            changed()
        }
        if (editing) return
        val prof = activeProfile() ?: return
        val h = host ?: return
        if (prof.axisKeys) {
            axisKey(PadButton.DPAD_LEFT.key, -a.hx, a)
            axisKey(PadButton.DPAD_RIGHT.key, a.hx, a)
            axisKey(PadButton.DPAD_UP.key, -a.hy, a)
            axisKey(PadButton.DPAD_DOWN.key, a.hy, a)
            // gatilho "Gradual" usa o valor do eixo direto, não a tecla fabricada
            if (prof.bindingFor(PadButton.L2)?.mode != BindMode.SLIDE) axisKey(PadButton.L2.key, a.lt, a)
            if (prof.bindingFor(PadButton.R2)?.mode != BindMode.SLIDE) axisKey(PadButton.R2.key, a.rt, a)
        }
        stick(PadButton.LSTICK, a.lx, a.ly, prof, h, a.now)
        stick(PadButton.RSTICK, a.rx, a.ry, prof, h, a.now)
        if (!slideKey.contains(PadButton.L2.key)) slide(PadButton.L2, a.lt, prof, h, a.now)
        if (!slideKey.contains(PadButton.R2.key)) slide(PadButton.R2, a.rt, prof, h, a.now)
    }

    /** Últimos eixos, se forem recentes (o controle está mesmo mandando eixos agora). */
    private fun freshAxes(now: Long): PadAxes? {
        val a = lastAxes ?: return null
        return if (axesOn && now - a.now < 500L) a else null
    }

    /**
     * Gatilho gradual: [level] 0..1 (quanto o gatilho foi apertado). O dedo nasce no ponto e anda na direção
     * escolhida, até [PadBinding.radius] vezes o lado menor da tela, na proporção do aperto.
     */
    private fun slide(btn: PadButton, level: Float, prof: PadProfile, h: PadHost, now: Long) {
        val b = prof.bindingFor(btn) ?: return
        if (b.mode != BindMode.SLIDE) return
        val id = btn.key
        if (level <= b.dead) {
            if (stickActive.remove(id)) {
                planner.release(id)
                h.pump()
            }
            return
        }
        val w = h.screenWidth()
        val hh = h.screenHeight()
        if (w <= 0 || hh <= 0) return
        val scale = Math.min(1f, (level - b.dead) / (1f - b.dead))
        val dx = if (b.dir == 2) -1f else if (b.dir == 3) 1f else 0f
        val dy = if (b.dir == 0) -1f else if (b.dir == 1) 1f else 0f
        val ox = b.x * (w - 1)
        val oy = b.y * (hh - 1)
        val dist = b.radius * Math.min(w, hh) * scale
        val tx = Math.max(0f, Math.min((w - 1).toFloat(), ox + dx * dist))
        val ty = Math.max(0f, Math.min((hh - 1).toFloat(), oy + dy * dist))
        if (stickActive.add(id)) {
            planner.pressJoystick(id, ox, oy, tx, ty, now)
        } else {
            planner.moveTo(id, tx, ty)
        }
        h.pump()
    }

    /** Eixo -> tecla com histerese (liga acima de 0,5, desliga abaixo de 0,3). */
    private fun axisKey(code: Int, value: Float, a: PadAxes) {
        val on = if (synth.contains(code)) value > 0.3f else value > 0.5f
        val was = synth.contains(code)
        if (on == was) return
        if (on) {
            // o controle também manda a tecla de verdade: ela manda, o eixo não duplica
            if (pressed.contains(code)) return
            synth.add(code)
        } else {
            synth.remove(code)
        }
        onKey(PadKey(code, on, 0, a.deviceName, true, a.now, true))
    }

    private fun stick(btn: PadButton, x: Float, y: Float, prof: PadProfile, h: PadHost, now: Long) {
        val b = prof.bindingFor(btn) ?: return
        if (b.mode != BindMode.JOYSTICK && b.mode != BindMode.CAMERA) return
        val id = btn.key
        val mag = Math.sqrt((x * x + y * y).toDouble()).toFloat()
        if (mag <= b.dead) {
            if (stickActive.remove(id)) {
                planner.release(id)
                h.pump()
            }
            return
        }
        val w = h.screenWidth()
        val hh = h.screenHeight()
        if (w <= 0 || hh <= 0) return
        val scale = Math.min(1f, (mag - b.dead) / (1f - b.dead))
        val dx = x / mag
        val dy = y / mag
        val ox = b.x * (w - 1)
        val oy = b.y * (hh - 1)
        val minDim = Math.min(w, hh).toFloat()
        if (b.mode == BindMode.JOYSTICK) {
            val r = b.radius * minDim * scale
            val tx = Math.max(0f, Math.min((w - 1).toFloat(), ox + dx * r))
            val ty = Math.max(0f, Math.min((hh - 1).toFloat(), oy + dy * r))
            if (stickActive.add(id)) {
                planner.pressJoystick(id, ox, oy, tx, ty, now)
            } else {
                planner.moveTo(id, tx, ty)
            }
        } else {
            val sp = scale * minDim * 0.9f * b.speed
            if (stickActive.add(id)) planner.pressCamera(id, ox, oy, b.radius * minDim, now)
            planner.setVelocity(id, dx * sp, dy * sp)
        }
        h.pump()
    }

    /** Janela de outro app apareceu na frente. */
    fun onForeground(pkg: String) {
        if (pkg == foregroundPkg) return
        foregroundPkg = pkg
        // saiu do app: solta o que estava segurando
        releaseAll()
        changed()
    }

    fun updateLauncherFront(front: Boolean) {
        if (front == launcherFront) return
        launcherFront = front
        if (front) releaseAll()
        changed()
    }

    /** Solta todos os dedos que a gente está segurando (o dedo sai no próximo pedaço). */
    fun releaseAll() {
        stickActive.clear()
        synth.clear()
        slideKey.clear()
        slideConsumed.clear()
        if (consumed.isEmpty() && !planner.hasWork()) return
        planner.releaseAll()
        consumed.clear()
        host?.pump()
    }

    /** O Android cancelou ou recusou o gesto: nenhum dedo nosso existe mais. */
    fun onInjectionLost(reason: String) {
        planner.clear()
        consumed.clear()
        stickActive.clear()
        synth.clear()
        slideKey.clear()
        slideConsumed.clear()
        addLog("injeção interrompida: " + reason)
        changed()
    }

    /** Serviço ligou/desligou. */
    fun onServiceState(running: Boolean) {
        if (!running) {
            planner.clear()
            consumed.clear()
            pressed.clear()
            stickActive.clear()
            synth.clear()
            slideKey.clear()
            slideConsumed.clear()
            editing = false
            editHook = null
            axesOn = false
        }
        changed()
    }

    /** Para os testes: volta tudo ao início. */
    fun resetForTest() {
        planner.clear()
        consumed.clear()
        pressed.clear()
        log.clear()
        listeners.clear()
        host = null
        masterOn = true
        foregroundPkg = ""
        launcherFront = false
        profiles = emptyList()
        lastDevice = ""
        eventCount = 0
        mappedCount = 0
        lastButton = null
        editing = false
        editHook = null
        editVersion = 0
        axesSupported = true
        diagWanted = false
        lastAxes = null
        axisEvents = 0
        axesOn = false
        lastAxisNotify = 0L
        stickActive.clear()
        synth.clear()
        slideKey.clear()
        slideConsumed.clear()
        axesSource = null
    }
}
