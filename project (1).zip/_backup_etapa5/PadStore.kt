package com.example.winlauncher

import android.content.Context
import java.io.File

/**
 * Mapeador de gamepad (Etapa 1) - guarda os perfis em `pad_profiles.json` (pasta interna do app).
 * O serviço de acessibilidade e o painel rodam no mesmo processo e compartilham esta lista.
 * Só a thread principal mexe nela.
 */
object PadStore {
    private const val FILE = "pad_profiles.json"

    val profiles = ArrayList<PadProfile>()
    private var loaded = false

    /** Último erro de leitura/gravação (aparece no painel). */
    var lastError: String? = null
        private set

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, FILE)

    /** Lê o arquivo uma vez por processo. [force] = relê. */
    fun load(ctx: Context, force: Boolean = false) {
        if (loaded && !force) return
        try {
            val f = file(ctx)
            val text = if (f.exists()) f.readText(Charsets.UTF_8) else null
            val parsed = PadJson.read(text)
            profiles.clear()
            profiles.addAll(parsed.profiles)
            PadEngine.masterOn = parsed.on
            lastError = null
        } catch (e: Exception) {
            lastError = "Não foi possível ler os perfis: " + e.javaClass.simpleName
        }
        loaded = true
        PadEngine.profiles = profiles
        PadEngine.refreshAxes()
    }

    /** Grava (atomicamente: arquivo temporário + renomear) e avisa o motor. */
    fun save(ctx: Context) {
        PadEngine.profiles = profiles
        PadEngine.refreshAxes()
        try {
            val f = file(ctx)
            val tmp = File(f.parentFile, FILE + ".tmp")
            tmp.writeText(PadJson.write(PadEngine.masterOn, profiles), Charsets.UTF_8)
            if (!tmp.renameTo(f)) {
                f.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8)
                tmp.delete()
            }
            lastError = null
        } catch (e: Exception) {
            lastError = "Não foi possível salvar os perfis: " + e.javaClass.simpleName
        }
    }

    fun profileFor(pkg: String): PadProfile? = profiles.firstOrNull { it.pkg == pkg }

    /** Perfil existente do app ou um novo (já na lista, ainda sem botões). */
    fun getOrCreate(ctx: Context, pkg: String, name: String): PadProfile {
        profileFor(pkg)?.let { return it }
        val p = PadProfile(java.lang.Long.toString(System.currentTimeMillis(), 36), pkg, name)
        profiles.add(p)
        save(ctx)
        return p
    }

    fun delete(ctx: Context, p: PadProfile) {
        profiles.remove(p)
        save(ctx)
    }

    fun setMaster(ctx: Context, on: Boolean) {
        PadEngine.setMaster(on)
        save(ctx)
    }

    /** Etapa 4: texto do arquivo de backup com todos os perfis. */
    fun exportText(ctx: Context): String {
        load(ctx)
        return PadJson.export(profiles)
    }

    /**
     * Etapa 4: junta os perfis de [text] aos atuais e grava. Devolve a mensagem para o usuário (erro ou resumo).
     * [replace] = true troca o perfil de apps que já têm um; false mantém o que já existe.
     */
    fun importText(ctx: Context, text: String?, replace: Boolean): String {
        load(ctx)
        val r = PadJson.parseImport(text)
        if (r.error != null) return r.error
        val m = PadJson.merge(profiles, r.profiles, replace)
        save(ctx)
        if (lastError != null) return lastError ?: "Não foi possível salvar os perfis"
        val parts = ArrayList<String>()
        if (m.added > 0) parts.add(m.added.toString() + " novo(s)")
        if (m.replaced > 0) parts.add(m.replaced.toString() + " substituído(s)")
        if (m.kept > 0) parts.add(m.kept.toString() + " mantido(s) (o app já tinha perfil)")
        if (r.skipped > 0) parts.add(r.skipped.toString() + " ignorado(s)")
        return "Importação: " + parts.joinToString(", ")
    }
}

/**
 * Etapa 4: opções do mapeador que não são perfis (guardadas em SharedPreferences "pad_prefs").
 * [floating] = botão flutuante liga/desliga sobre o jogo; [announce] = aviso ao ativar o perfil de um jogo.
 */
object PadPrefs {
    private const val SP = "pad_prefs"

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(SP, Context.MODE_PRIVATE)

    fun floating(ctx: Context): Boolean = sp(ctx).getBoolean("floating", true)

    fun setFloating(ctx: Context, on: Boolean) {
        sp(ctx).edit().putBoolean("floating", on).apply()
    }

    fun announce(ctx: Context): Boolean = sp(ctx).getBoolean("announce", true)

    fun setAnnounce(ctx: Context, on: Boolean) {
        sp(ctx).edit().putBoolean("announce", on).apply()
    }

    /** Posição do botão flutuante em pixels da tela (canto superior esquerdo), uma por orientação. -1 = nunca movido. */
    fun floatPos(ctx: Context, landscape: Boolean): Pair<Int, Int> {
        val k = if (landscape) "l" else "p"
        val s = sp(ctx)
        return Pair(s.getInt("fx_" + k, -1), s.getInt("fy_" + k, -1))
    }

    fun setFloatPos(ctx: Context, landscape: Boolean, x: Int, y: Int) {
        val k = if (landscape) "l" else "p"
        sp(ctx).edit().putInt("fx_" + k, x).putInt("fy_" + k, y).apply()
    }
}
