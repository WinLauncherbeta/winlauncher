# HANDOFF 17 — Mapeador de gamepad como APP NATIVO (WinLauncher 2.12.0 / code 25)

NÃO compilado com Gradle e NÃO testado em aparelho. Neste ambiente não há kotlinc nem Android SDK. A única checagem feita foi léxica
(Pygments: 0 tokens de erro e delimitadores balanceados em PadMapperWindow, PadMapperService, MainActivity, AppCustom, PadOverlayEditor)
e leitura do código contra o molde da janela do Reprodutor de música. Quem compila é o GitHub Actions: se acusar erro, mandar o log.

## O que o usuário pediu
App do mapeador de gamepad na janela de aplicativos e na barra de tarefas, com as mesmas opções de personalização dos outros apps nativos,
atalho ALT + M para a janela de mapeamento, interface para adicionar jogo, e só mapear quando se está dentro do jogo. Ícone: `475.png`.

## O que foi feito
1. App nativo "Mapeador de gamepad" (`AppCustom.PADMAP`, componente virtual `native.PadMapper`), ícone `res/drawable-nodpi/ic_pad_app.png`
   (475.png recortado e reduzido para 192x192, transparente).
   - Janela de aplicativos (Menu Iniciar) e busca: entra em `nativeApps()`. Botão direito: Abrir, Fixar/Desafixar, Trocar ícone, Restaurar ícone
     (as mesmas opções do Reprodutor de música e do Monitor de desempenho; os apps nativos não têm "Renomear").
   - Barra de tarefas: fixado na primeira vez (flag `padMapPinnedOnce`, logo depois da galeria; depois disso desafixar é escolha do usuário).
     Ícone fixado com indicador, mover esquerda/direita, menu de botão direito, botão extra enquanto a janela estiver aberta e desafixada,
     miniatura ao passar o mouse e entrada na Visão de Tarefas. Tudo copiado do padrão do Reprodutor de música (`TB_PADMAP = "__padmap__"`).
2. `PadMapperWindow.kt` (novo): janela própria (título com arrastar, minimizar, maximizar, fechar, grip de redimensionar; botão direito na
   barra de título = menu da janela; botão voltar do Android volta de subpágina ou fecha).
   - Página "Meus jogos": estado do serviço de acessibilidade (com botão para abrir Acessibilidade se estiver desligado), chave "Mapeamento ligado",
     passo a passo de uso, lista de jogos (ícone do app, nome, "Ainda não mapeado..." ou "N botões mapeados", chave ativar/desativar,
     "Abrir jogo", "Remover" com confirmação em 2 toques).
   - Página "Adicionar jogo": lista dos apps instalados com busca (sem o próprio WinLauncher e sem os que já estão na lista). Tocar adiciona o jogo
     (perfil vazio, `PadStore.getOrCreate`) e volta à lista. NÃO existe editor de posições dentro da janela: de propósito.
   - "Mais opções": embute o `PadPanel` já existente (Shizuku, ajustes, teste, importar/exportar). Configurações > Jogos > Mapeador de gamepad continua igual.
   - A lista só é refeita quando algo muda (assinatura), para não voltar ao topo a cada tecla do controle.
3. ALT + M:
   - Com o launcher na frente: `MainActivity.dispatchKeyEvent` abre/fecha a janela do Mapeador (mesmo padrão do ALT + I / ALT + Z).
   - Com outro app na frente: `PadMapperService.onKeyEvent` (acompanha o Alt por conta própria) chama `openMapperFromShortcut()`:
     jogo na lista -> abre o editor sobre o jogo (`startEditor`); editor já aberto -> `saveAndExit()` (salva e fecha); app fora da lista ->
     aviso "Este app não está na lista do Mapeador"; jogo ainda não reconhecido -> aviso. Perfil sem botões nasce na orientação atual da tela.
   - Só teclado físico (`SOURCE_KEYBOARD`), sem Ctrl/Meta/Shift. Exige o serviço de acessibilidade do mapeador ligado.
4. `PadOverlayEditor.saveAndExit` deixou de ser `private` (o atalho usa). `app/build.gradle.kts`: 2.11.0/24 -> 2.12.0/25.

## Arquivos
Novos: `PadMapperWindow.kt`, `res/drawable-nodpi/ic_pad_app.png`, este HANDOFF.
Modificados: `AppCustom.kt` (PADMAP), `MainActivity.kt` (TB_PADMAP, janela, nativeApps/menus, barra de tarefas, Visão de Tarefas, voltar, ALT + M,
ícone), `PadMapperService.kt` (ALT + M), `PadOverlayEditor.kt` (1 palavra), `app/build.gradle.kts`, `HANDOFF_WINLAUNCHER.md`.
Backups dos originais: `_backup_padapp/`. Não alterados: PadEngine, PadStore, PadModel, PadPanel, ShortcutService, Remote, assinatura, package.

## Para conferir no build
1. `PadMapperWindow`: `private val grip: View` atribuído no `init`; lambdas do `init` usando `grip`.
2. `MainActivity`: `addPadMapPinned/addPadMapButton` usam `rightClick`, `pinTouch`, `tbHover`, `indBottom` como as do Reprodutor de música.
3. `PadMapperService.onKeyEvent`: `if (handleMapperShortcut(event)) return true` dentro de `return try { ... }`.

## Para testar no aparelho (nesta ordem)
1. O app aparece na janela de aplicativos com o ícone do gamepad e na barra de tarefas (fixado). Botão direito: Trocar ícone / Restaurar ícone funcionam.
2. Abrir o app: serviço "ativado"? Adicionar jogo: o jogo entra na lista com "Ainda não mapeado".
3. ALT + M no launcher abre/fecha a janela.
4. "Abrir jogo", e com o jogo na frente ALT + M: o editor aparece sobre o jogo. Posicionar botões, ALT + M de novo: salva e fecha; a lista mostra "N botões mapeados".
5. ALT + M num app que não está na lista: aparece o aviso, nada abre.
6. Girar a tela, minimizar/restaurar a janela, Visão de Tarefas, desafixar da barra e reabrir pelo menu.

## Limites conhecidos
- Sem teclado físico não há como abrir o editor (não criei botão alternativo). Se precisar, dá para abrir o editor por toque longo no botão flutuante PAD.
- O jogo da frente só é reconhecido na próxima troca de janela (limite herdado da Etapa 4): se o jogo já estava aberto ao ligar o serviço, saia e volte.
- O ALT + M dentro do jogo depende do serviço de acessibilidade do MAPEADOR (não do ShortcutService).
- A janela do Mapeador não tem tela cheia (só janela/maximizada).
